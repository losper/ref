/**************************************************************************************
*
* FILE NAME   : otgcore.c
* DESCRIPTION : This is a OTG CORE driver source code
*
* ====================================================================================
*
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
* ====================================================================================
*
* FILE HISTORY:
* 	Date: 2009.03.16	Start source coding
*
**************************************************************************************/
#include "bsp.h"
#include "tcc89x_structures.h"
#include "usb_defs.h"
#include "TCC_otg.h"
#include "reg_physical.h"
#include "otgregs.h"


/* For Signature */
#define OTGCORE_SIGNATURE			'O','T','G','C','O','R','E','_'
#define OTGCORE_VERSION				'V','2','.','0','0','0'
static const unsigned char OTGCORE_C_Version[] = {SIGBYAHONG, OTGCORE_SIGNATURE, SIGN_OS ,SIGN_CHIPSET, OTGCORE_VERSION, NULL};


//#define SLAVE_MODE_INCLUDE
//#define DMA_MODE_INCLUDE

extern PUSB20OTG pOTG;
extern PUSBOTGCFG pOTGCFG;


unsigned char* OTGCORE_TellLibraryVersion(void)
{
	return (unsigned char*)OTGCORE_C_Version;
}

void OTGCORE_Init(void)
{
#if defined(SLAVE_MODE_INCLUDE)
	pOTG->GUSBCFG |= GUSBCFG_PHYIf_16BITS|GUSBCFG_TOutCal(7);	// set interface, timeout
	pOTG->GOTGCTL |= GOTGCTL_SesReq;	// session request
	pOTG->GINTSTS = 0xFFFFFFFF;		// clear interrupts
	pOTG->GAHBCFG |= GAHBCFG_NPTXFEmpLvl_COMPLETELY|GAHBCFG_GlblIntrMsk_UNMASK;	// enable global interrupt
#elif defined(DMA_MODE_INCLUDE)
	// device mode
	HwUSBOTGCFG->OTGID |= OTGID_ID_DEVICE;

	// Core Initialization
	pOTG->GINTSTS = 0xFFFFFFFF;		// clear interrupts
	pOTG->GAHBCFG = GAHBCFG_DMAEn|GAHBCFG_HBstLen_SINGLE|GAHBCFG_GlblIntrMsk_MASK;
	pOTG->GUSBCFG = GUSBCFG_USBTrdTim_16BIT_UTMIP|GUSBCFG_PHYIf_16BITS|GUSBCFG_TOutCal(7);
	pOTG->GOTGCTL |= GOTGCTL_SesReq;	// session request
	pOTG->GINTMSK = GINTMSK_OTGIntMsk_UNMASK|GINTMSK_ModeMisMsk_UNMASK;
#endif
}

void OTGCORE_SetID(unsigned int ID)
{
	if( ID )
		pOTGCFG->OTGID |= OTGID_ID_DEVICE;
	else
		pOTGCFG->OTGID &= OTGID_ID_HOST;
}

void OTGCORE_Reset(void)
{
	// Core Soft Reset
	pOTG->GRSTCTL |= GRSTCTL_CSftRst;
	// wait self clear
	while( (pOTG->GRSTCTL & GRSTCTL_CSftRst) != 0 );

	// wait 3 PHY clocks (synchronization delay)
	{
		volatile unsigned int i,cnt=0;
		for(i=0;i<1000000;i++)
			cnt++;
	}

	// wait AHB idle
	while( !(pOTG->GRSTCTL & GRSTCTL_AHBIdle) );
}

void OTGDEV_IO_Init(void)
{
	pOTG->DCTL = 0;
#if defined(SLAVE_MODE_INCLUDE)
	// Unmask core interrupt
	pOTG->GINTMSK |= GINTMSK_EnumDoneMsk_UNMASK|GINTMSK_USBRstMsk_UNMASK|GINTMSK_RxFLvlMsk_UNMASK;
#elif defined(DMA_MODE_INCLUDE)
	pOTG->DCFG = DCFG_PerFrInt(0)|DCFG_NZStsOUTHShk_STALL|DCFG_DevSpd_HS;
	pOTG->GINTMSK |= GINTMSK_USBRstMsk_UNMASK|GINTMSK_EnumDoneMsk_UNMASK|GINTMSK_ErlySuspMsk_UNMASK|GINTMSK_USBSuspMsk_UNMASK|GINTMSK_SofMsk_UNMASK;
#endif
}

void OTGDEV_IO_Reset(void)
{
#if defined(SLAVE_MODE_INCLUDE)
	pOTG->GRXFSIZ = 1024;	// Receive FIFO size : 512
	pOTG->GNPTXFSIZ = GNPTXFSIZ_INEPTxF0Dep(1024)|GNPTXFSIZ_INEPTxF0StAddr(1024);	// DEVICE INEP0(Non-periodic) Transmit FIFO size : 512
	pOTG->DIEPTXFn[0] = DIEPTXF_INEPnTxFDep(1024)|DIEPTXF_INEPnTxFStAddr(1024+1024);
	pOTG->DIEPTXFn[1] = DIEPTXF_INEPnTxFDep(1024)|DIEPTXF_INEPnTxFStAddr(1024+1024+1024);

	// OUTEP0 Control
	//pOTG->DOEPCTL0 |= DOEPCTL0_EPEna|DOEPCTL0_CNAK;

	// OUTEP2 Control
	//pOTG->DEVOUTENDPT[1][DOEPCTL_INDEX] |= DOEPCTL_EPEna|DOEPCTL_SetD0PID|DOEPCTL_CNAK|DOEPCTL_EPType_BULK|DOEPCTL_USBActEP|DOEPCTL_MPS(512);

	// INEP1 Control
	//pOTG->DEVINENDPT[0][DOEPCTL_INDEX] |= DIEPCTL_SetD0PID|DIEPCTL_TxFNum(1)|DIEPCTL_EPType_BULK|DIEPCTL_USBActEP|DIEPCTL_MPS(512);

	// Reset - set and flush All TxFIFO, flush RxFIFO
	pOTG->GRSTCTL |= GRSTCTL_TxFNum(0x10)|GRSTCTL_TxFFlsh|GRSTCTL_RxFFlsh;

	///for(i=0;i<16;i++)
	///	gEpOutBuffer[i].fEmpty = TRUE;

	// Unmask INEP0, OUTEP0
	//pOTG->DAINTMSK |= DAINTMSK_OutEPInt(0)|DAINTMSK_InEPInt(0);

	// Unmask core interrupt
	//pOTG->GINTMSK |= GINTMSK_OEPIntMsk_UNMASK|GINTMSK_IEPIntMsk_UNMASK|GINTMSK_USBRstMsk_UNMASK|GINTMSK_RxFLvlMsk_UNMASK;
	
#elif defined(DMA_MODE_INCLUDE)
	unsigned int i;
	// Set the NAK bit for all OUT endpoints
	pOTG->DOEPCTL0 = DOEPCTL0_SNAK;
	for(i=0;i<15;i++)
		pOTG->DEVOUTENDPT[i][DOEPCTL_INDEX] = DOEPCTL_SNAK;

	// Unmask some interrupt bits
	pOTG->DAINTMSK = DAINTMSK_InEPInt(0)|DAINTMSK_OutEPInt(0);
	pOTG->DOEPMSK = DOEPMSK_SetUPMsk_UNMASK|DOEPMSK_XferComplMsk_UNMASK;
	pOTG->DIEPMSK = DIEPMSK_XferComplMsk_UNMASK|DIEPMSK_TimeOUTMsk_UNMASK;

	// Set up the Data FIFO RAM for each of the FIFOs
	pOTG->GRXFSIZ = 1024;
	pOTG->GNPTXFSIZ = GNPTXFSIZ_INEPTxF0Dep(1024)|GNPTXFSIZ_INEPTxF0StAddr(1024);
	pOTG->DIEPTXFn[0] = DIEPTXF_INEPnTxFDep(1024)|DIEPTXF_INEPnTxFStAddr(1024+1024);
	pOTG->DIEPTXFn[1] = DIEPTXF_INEPnTxFDep(1024)|DIEPTXF_INEPnTxFStAddr(1024+1024+1024);
	pOTG->GRSTCTL = GRSTCTL_TxFNum(0x10)|GRSTCTL_TxFFlsh|GRSTCTL_RxFFlsh;
	do
	{
		if( (pOTG->GRSTCTL&(GRSTCTL_TxFFlsh|GRSTCTL_RxFFlsh)) == 0 )
			break;
	} while(1);

	// Program endpoint-specific registers for control OUT endpoint 0
	pOTG->DOEPTSIZ0 = DOEPTSIZ0_PktCnt(1)|DOEPTSIZ0_XferSize(8);
	pOTG->DOEPDMA0 = OUTEP0_DMA_ADDR;
#endif
	//--------------------------------------------------
	// Setting Control Registers
	//--------------------------------------------------

	/* Setting USB Device Type */
	//if ( USBDEV_GetSpeedLimit() == USBDEV_HIGH_SPEED )
	//	HwUTST = 0x0000; 	// SET DEVICE AS USB 2.0 HIGH SPEED
	//else
	//	HwUTST = 0x0080; 	// SET DEVICE AS USB 1.1 FULLSPEED
	//
	//HwSCR		=	0xA000 				|
	//				//HwSCR_DTZIEN_EN		|	// DMA Total Conter Zero Interrupt Enable
	//				HwSCR_DIEN_EN		|	// DUAL Interrupt Enable
	//				//HwSCR_EIE_EN		|	// Error Interrupt Enable
	//				HwSCR_SDE_EN		|	// Speed Detect End Interrupt Enable
	//				HwSCR_RRDE_EN		|	// Reverse Read Data Enable
	//				//HwSCR_HSUSPE_EN		|	// Suspend Enable
	//				HwSCR_HRESE_EN;			// Reset Enable
	//
	//HwFAR		= 0x00000000;
	//
	////--------------------------------------------------
	//// [ EP0 ] SET UP
	////--------------------------------------------------
	//HwIR		= 0;
	//HwEP0CR		= 0x00000000;
	//HwMPR		= 64;
	//HwECR		= HwECR_FLUSH_EN + HwECR_CDP_CLR;
	//
	////--------------------------------------------------
	//// Clear Endpoint
	////--------------------------------------------------
	//HwEIR		= HwEIR_EP0INT + HwEIR_EP1INT + HwEIR_EP2INT + HwEIR_EP3INT;	// Clear Endpoint Interrupt.
	//HwEIER		= HwEIER_EP0INT_EN;
	//
	//g_OTGDEV_IO_Driver.currentSpeed = USBDEV_FULL_SPEED;
	//gOTGDEV_IO_StallFlag = 0;
}


void OTGDEV_IO_EnumDone(void)
{
/*	unsigned int enumSpeed;	// 0:high speed(30/60MHz), 1:full speed(30/60MHz), 2:low speed(6MHz), 3: full speed(48MHz)
	enumSpeed = DSTS_EnumSpd_Read(pOTG->DSTS);
	if( enumSpeed == 0 )
	{
		g_OTGDEV_IO_Driver.currentSpeed = USBDEV_HIGH_SPEED;
	}
	else
	{
		g_OTGDEV_IO_Driver.currentSpeed = USBDEV_FULL_SPEED;
	}
	*/
#if defined(SLAVE_MODE_INCLUDE)
	// OUTEP0 Control
	pOTG->DOEPCTL0 |= DOEPCTL0_EPEna|DOEPCTL0_CNAK;

	// OUTEP2 Control
	pOTG->DEVOUTENDPT[1][DOEPCTL_INDEX] |= DOEPCTL_EPEna|DOEPCTL_SetD0PID|DOEPCTL_CNAK|DOEPCTL_EPType_BULK|DOEPCTL_USBActEP|DOEPCTL_MPS(512);

	// INEP1 Control
	pOTG->DEVINENDPT[0][DOEPCTL_INDEX] |= DIEPCTL_SetD0PID|DIEPCTL_TxFNum(1)|DIEPCTL_EPType_BULK|DIEPCTL_USBActEP|DIEPCTL_MPS(512);
#elif defined(DMA_MODE_INCLUDE)
	BITCSET(pOTG->DIEPCTL0,DIEPCTL0_MPS_MASK,DIEPCTL0_MPS_64BYTES);
	pOTG->DOEPCTL0 |= DOEPCTL0_EPEna|DOEPCTL0_CNAK;
#endif
}