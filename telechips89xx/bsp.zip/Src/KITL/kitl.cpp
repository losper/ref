//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
// -----------------------------------------------------------------------------
//
//      THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
//      ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//      THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//      PARTICULAR PURPOSE.
//
// -----------------------------------------------------------------------------
#include <windows.h>
#include <bsp.h>
#include <kitl_cfg.h>
#include <oal_kitl.h>

#ifdef KITL_ETHERNET
#include <oal_ethdrv.h>
#endif

#define KITL_DBON 1

#define USBKITL_POLL
BOOL USBSerKitl_POLL = FALSE;

OAL_KITL_DEVICE g_kitlDevice;

/************************************************************************************************
* GLOBAL
************************************************************************************************/

#ifdef	KITL_ETHERNET
#define BSP_BASE_REG_PA_CS8900A_IOBASE         0xF05C0000
#define BSP_DEVICE_PREFIX       "TCC89X"        // Device name prefix

static OAL_KITL_ETH_DRIVER g_kitlEthCS8900A = OAL_ETHDRV_CS8900A;

OAL_KITL_DEVICE g_kitlDevices[] = {
    { 
        L"CS8900A", Internal, BSP_BASE_REG_PA_CS8900A_IOBASE, 0, OAL_KITL_TYPE_ETH, 
        &g_kitlEthCS8900A
    }, {
        NULL, 0, 0, 0, (OAL_KITL_TYPE)0, NULL
    }
};
#endif

#ifdef	KITL_USBSERIAL
#define TCC8900_BASE_PA_USBOTG_LINK				0xB0550000
const OAL_KITL_SERIAL_DRIVER *GetKitlUSBSerialDriver (void);

BOOL InitKitlUSBSerialArgs (OAL_KITL_ARGS *pKitlArgs)
{
	DWORD dwIoBase = TCC8900_BASE_PA_USBOTG_LINK;

	// Initialize flags
	pKitlArgs->flags = OAL_KITL_FLAGS_ENABLED;
#ifdef USBKITL_POLL
	pKitlArgs->flags |= OAL_KITL_FLAGS_POLL;
	USBSerKitl_POLL = TRUE;
#endif

	pKitlArgs->devLoc.LogicalLoc	= dwIoBase;
	pKitlArgs->devLoc.IfcType		= 0; //InterfaceTypeUndefined;		// Get IRQ, when interface is undefined use Pin as IRQ
	pKitlArgs->devLoc.Pin			= 48;

	g_kitlDevice.name				= L"TCC8900USBSerial";
	g_kitlDevice.ifcType			= pKitlArgs->devLoc.IfcType;
	//g_kitlDevice.id					= 0x18000300;
	g_kitlDevice.resource			= 0;
	g_kitlDevice.type				= OAL_KITL_TYPE_SERIAL;
	g_kitlDevice.pDriver			= (VOID*)GetKitlUSBSerialDriver ();
	
	RETAILMSG(1,(TEXT("[**InitKitlUSBSerialArgs**]\r\n")));
	return TRUE;
}
#endif

//------------------------------------------------------------------------------
//
// Platform entry point for KITL. Called when KITLIoctl (IOCTL_KITL_STARTUP, ...) is called.
//

BOOL OEMKitlStartup(void)
{
	
	OAL_KITL_ARGS kitlArgs;
	OAL_KITL_ARGS *pkitlArgs;
	BOOL bRet = FALSE;
	UCHAR *szDeviceId,buffer[OAL_KITL_ID_SIZE]="\0";



	tSYSTEM_PARAM		*gpBOOTARGS;
	gpBOOTARGS = (tSYSTEM_PARAM*)OALPAtoVA(SYSTEM_PARAM_BASEADDRESS,FALSE);

	OALMSG(1,(TEXT("---------------------------------------------\r\n")));
	OALMSG(TC_LOG_LEVEL(TC_LOG), (L"[KERNEL-KITL ]+OEMKitlStartup()\r\n"));

	memset(&kitlArgs, 0, sizeof (kitlArgs));

	pkitlArgs = (OAL_KITL_ARGS *)OALArgsQuery(OAL_ARGS_QUERY_KITL);
	szDeviceId = (UCHAR*)OALArgsQuery(OAL_ARGS_QUERY_DEVID);
	// Common parts
	//kitlArgs.devLoc.IfcType	= InterfaceTypeUndefined;
	//g_kitlDevice.ifcType	= InterfaceTypeUndefined;
	
	if((gpBOOTARGS->SYSTEM_ARGS.SetFlag & OAL_KITL_FLAGS_ENABLED) == 0)
	{
		RETAILMSG(1,(TEXT("KITL was Disabled from EBOOT !!\r\nPlease set KITL Configuration in EBoot !!\r\n")));
		return FALSE;
	}
#ifdef KITL_ETHERNET
	KITLOutputDebugString ("[KERNEL-KITL ] KITL: Ethernet\n");

	pkitlArgs->flags = OAL_KITL_FLAGS_ENABLED | OAL_KITL_FLAGS_VMINI | OAL_KITL_FLAGS_POLL;
	
	if (pArgs->SetFlag == 1) 
		pkitlArgs->flags &= ~(OAL_KITL_FLAGS_PASSIVE);

	pkitlArgs->devLoc.IfcType		= Internal;
	pkitlArgs->devLoc.BusNumber		= 0;
	pkitlArgs->devLoc.LogicalLoc	= BSP_BASE_REG_PA_CS8900A_IOBASE;
	pkitlArgs->devLoc.Pin			= 0;

	//OALKitlStringToMAC(CS8900A_MAC,pkitlArgs->mac);
	//OALKitlCreateName(BSP_DEVICE_PREFIX, kitlArgs.mac, buffer);
	strcpy((char*)buffer,"TCC89XETHKITL");

	szDeviceId = buffer;
	
	kitlArgs.flags = ( OAL_KITL_FLAGS_ENABLED | OAL_KITL_FLAGS_POLL | OAL_KITL_FLAGS_VMINI);
	kitlArgs.flags &= ~(OAL_KITL_FLAGS_PASSIVE);
	kitlArgs.devLoc.PhysicalLoc = (PVOID)BSP_BASE_REG_PA_CS8900A_IOBASE;
	kitlArgs.devLoc.LogicalLoc	= (DWORD)kitlArgs.devLoc.PhysicalLoc;
	kitlArgs.ipAddress = pArgs->mKitl.nIPAddr;
	memcpy(kitlArgs.mac, pArgs->mKitl.chMACAddr, sizeof(kitlArgs.mac));;
//	strcpy((char*)buffer,"TCC89XETHKITL");
	
	pkitlArgs = &kitlArgs;
	bRet = TRUE;
#endif

#ifdef	KITL_USBSERIAL

	KITLOutputDebugString ("[KERNEL-KITL ] KITL: USB Serial\n");
	bRet = InitKitlUSBSerialArgs (&kitlArgs);
	strcpy((char*)buffer,"TCC89XUSBKITL");
	g_kitlDevice.id = kitlArgs.devLoc.LogicalLoc;
	szDeviceId = buffer;

#endif

	OALMSG(1, (L"DeviceId................. %hs\r\n", szDeviceId));
	OALMSG(1, (L"kitlArgs.flags............. 0x%x\r\n", kitlArgs.flags));
	OALMSG(1, (L"kitlArgs.devLoc.IfcType.... %d\r\n",   kitlArgs.devLoc.IfcType));
	OALMSG(1, (L"kitlArgs.devLoc.LogicalLoc. 0x%x\r\n", kitlArgs.devLoc.LogicalLoc));
	OALMSG(1, (L"kitlArgs.devLoc.PhysicalLoc 0x%x\r\n", kitlArgs.devLoc.PhysicalLoc));
	OALMSG(1, (L"kitlArgs.devLoc.Pin........ %d\r\n",   kitlArgs.devLoc.Pin));
	OALMSG(1, (L"kitlArgs.ip4address........ %s\r\n",   OALKitlIPtoString(kitlArgs.ipAddress)));
	OALMSG(1, (L"kitlArgs.mac[3]............ %s\r\n",   OALKitlMACtoString(kitlArgs.mac)));
	
	if (bRet == FALSE)
	{
		KITLOutputDebugString ("[KERNEL-KITL ] KITL: None\n");
		RETAILMSG(TRUE, (TEXT("[KERNEL-KITL ] KITL Argument Initialize Fail !!\n")));

		return FALSE;
	}
#ifdef	KITL_USBSERIAL
	bRet = OALKitlInit ((LPCSTR)szDeviceId, &kitlArgs, &g_kitlDevice);
#endif
#ifdef KITL_ETHERNET
	bRet = OALKitlInit ((LPCSTR)szDeviceId, &kitlArgs, g_kitlDevices);
#endif

	OALMSG(TC_LOG_LEVEL(TC_LOG), (L"[KERNEL-KITL ]-OEMKitlStartup()--%d\r\n",bRet));
	OALMSG(1,(TEXT("---------------------------------------------\r\n")));
	return bRet;
}

DWORD OEMKitlGetSecs (void)
{
	SYSTEMTIME st;
	DWORD dwRet;
	static DWORD dwBias;
	static DWORD dwLastTime;

	OEMGetRealTime( &st );
	dwRet = ((60UL * (60UL * (24UL * (31UL * st.wMonth + st.wDay) + st.wHour) + st.wMinute)) + st.wSecond);
	dwBias = dwRet;

	if (dwRet < dwLastTime)
	{
		KITLOutputDebugString("[KITL] Time went backwards (or wrapped): cur: %u, last %u\n", dwRet,dwLastTime);
	}

	dwLastTime = dwRet;

	return (dwRet);
}

//------------------------------------------------------------------------------
//
//  Function:  OALGetTickCount
//
//  This function is called by some KITL libraries to obtain relative time
//  since device boot. It is mostly used to implement timeout in network
//  protocol.
//
UINT32 OALGetTickCount()
{
    return OEMKitlGetSecs () * 1000;
}

