/***************************************************************************************
*	FileName    : lcd.h
*	Description : TCBOOT LCD Driver
****************************************************************************************
*
*	TCC Board Support Package
*	Copyright (c) Telechips, Inc.
*	ALL RIGHTS RESERVED
*
****************************************************************************************/
#ifndef __LCD_H__
#define __LCD_H__

//#define ROADSHOW_DEMO_TYPE1
//#define DEMO_TYPE2			// LCD(UI:LCDC0) + LVDS(VIDEO:LCDC1)

//#define USE_LVDSLCD


#if defined(DEMO_TYPE2)
	#ifndef USE_LVDSLCD
	#define USE_LVDSLCD
	#endif
#endif

#if defined(USE_LVDSLCD) || defined(DEMO_TYPE2)
//	#define LVDS_CLAA104XA01CW_10_4_1024X768
	#define LVDS_HT121WX2_103_12_1_1280X800
#endif


typedef struct {
	unsigned int res_width;
	unsigned int res_height;

	unsigned int devide;

	unsigned int vpw;
	unsigned int vbp;
	unsigned int vfp;

	unsigned int hpw;
	unsigned int hbp;
	unsigned int hfp;

	unsigned int pwdx;	// 0xC : 24Bit(888)
						// 0x5 : 18Bit(565)

	unsigned int freq;	// freq

} lcd_cfg_t;


static lcd_cfg_t	lcd_cfg[3] = 
{
//////	W		H		DIV		VPW		VBP		VFP		HPW		HBP		HFP		PWDX	FREQ//
#if (0)
//	[TCCXXXX_LCD_5.0WVGA&24B_SV0.1]	- LW500AC9601
	{	800,	480,	0,		2,		33,		10,	  128,		88,		40,		0xC,	60	},	
#else
//	[TCCXXXX_LCD_4.8WVGA&24B_SV0.1]
	{	800,	480,	3,		3,		5,		5,		3,		13,		8,		0xC,	60	},
#endif
//	[CLAA104XA01CW 10"4 Color TFT LCD (LVDS)]
	{	1024,	768,	1,		1,		1,		36,		1,		1,		318,	0xC,	60	},

//	[HT121WX2-103 12"1 Color TFT LCD (LVDS)]
	{	1280,	800,	1,		1,		3,		20,		1,		10,		150,	0xC,	60	},
};


/*	Boot-logo Color depth	*/
#if (0)
#define DISP_SRC_32BPP		// Enable : RGB888 (32bpp)
							// Disable: RGB565 (16bpp)
#endif

#if defined(USE_LVDSLCD)

#if defined(LVDS_CLAA104XA01CW_10_4_1024X768)
#define DISP_WIDTH	1024
#define DISP_HEIGHT	768
#elif defined(LVDS_HT121WX2_103_12_1_1280X800)
#define DISP_WIDTH	1280
#define DISP_HEIGHT	800
#endif

#else
#define DISP_WIDTH	800
#define DISP_HEIGHT	480
#endif

#if (0) || defined(DEMO_TYPE2)
#undef DISP_WIDTH
#undef DISP_HEIGHT
#define DISP_WIDTH	800
#define DISP_HEIGHT	480
#endif

#define DISP_MEM_SIZE		0x300000	// 3MB

#if defined(_DRAM_SIZE_128_)
#define DISP_MEM_PHYBASE	(0x46400000)
#else

#define DISP_MEM_PHYBASE	(0x4C800000)

#endif


#if defined(DISP_SRC_32BPP)
#define DISP_BYTESPERPIXEL	4
#else
#define DISP_BYTESPERPIXEL	2
#endif


#define DISP_BOOTIMG0_BASE_ADDR	(DISP_MEM_PHYBASE)
#define DISP_BOOTIMG0_SIZE_MAX	(0x180000)	//1// 1.5MB

#define DISP_BOOTIMG1_BASE_ADDR	(DISP_BOOTIMG0_BASE_ADDR + DISP_BOOTIMG0_SIZE_MAX)
#define DISP_BOOTIMG1_SIZE_MAX	(0x180000)	// 1.5MB

//
#define IMAGE1_START		(DISP_MEM_PHYBASE)

#define TELECHIPS_LOGO_BUFF_SIZE (DISP_WIDTH*DISP_HEIGHT*DISP_BYTESPERPIXEL)

void disp_init(void);

#endif	/*__LCD_H__*/
