/****************************************************************************
 *   FileName    :TCC_Board.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/   
#include "bsp.h"
#include "debug.h"
#include "ckc.h"
#include "func.h"
#include "..\inc\nand\Disk.h"
#include "..\inc\sdmmc\sdupdate.h"
#ifdef TRIFLASH_INCLUDE
#include "..\inc\sdmmc\mmc_ext.h"
#endif
/************************************************************************************************
*  Extern.
************************************************************************************************/
extern void init_gpio(void);
extern void init_clock(void);
extern void init_copybootddr(void);
extern void init_stack(void);
extern void init_vtcopy(unsigned uLoadBase, unsigned uDestBase, unsigned uCopyLength, unsigned uZIBase, unsigned uZILength);
extern void init_mmu(unsigned uTLBBase, unsigned uCacheControl);
extern void enable_irq(void);
extern unsigned enable_interrupt(void);
extern void jumptokernel(unsigned int startofkernel);

extern int	NAND_HDReadPage( unsigned int nHDPageAddr, unsigned int nPageSize, void* nReadBuffer );
extern int	NAND_HDWritePage( unsigned int nHDPageAddr, unsigned short nPageSize, void* nWriteBuffer );
extern int	NAND_Ioctl( int function, void *param );
extern int  VerifyROMFile(unsigned int *pBuffer,unsigned int size );
extern int  VerifyROMFile_128K(unsigned int *pBuffer,unsigned int size );

extern void BootloaderMain (void);
extern void Loader(int type);
extern void FWDN_Check(void);
#ifdef LOADXIPKERNEL	
extern unsigned char	*gNAND_PageBuffer;
#endif	
//extern int readbyte();
//extern int OEMReadDebugByte();
//static BOOL ShellMenu();
void SetDelay();
void SetIP();
void SetMask();
void SetMACAddress();

extern void writebyte(unsigned char cChar);
extern BOOL BootArgsSetting(void);
extern DWORD OEMEthGetSecs(void);


void CheckSuspend(void);
extern 		void		IO_ARM_RestoreREG(void);
extern int BootLogoImageChange();

/************************************************************************************************
*  Globals.
************************************************************************************************/
tSYSTEM_PARAM		*gpBOOTARGS;

PSYSTEMPARAM	g_pBootCfg;

/************************************************************************************************
*  Internal Functions.
************************************************************************************************/

/************************************************************************************************
*  Defines.
************************************************************************************************/
extern unsigned char _vectors;
extern unsigned char ResetHandler;
#define LOAD_VECTOR_BASE			(unsigned int)&_vectors
#define IMAGE_VECTOR_BASE			0x00000000
#define IMAGE_VECTOR_LENGTH		(unsigned int)(&ResetHandler - &_vectors)
#define IMAGE_VECTOR_ZI_BASE		IMAGE_VECTOR_LENGTH
#define IMAGE_VECTOR_ZI_LENGTH	0x00000000
#define TOC_STORE_ADDR				0x40000044
#define TOC_BASE_ADDR				(*(volatile unsigned long *)TOC_STORE_ADDR)

#define HIDDEN_OFFSET_OF_WINCE	8	// WinCE Image Offset is Page #8 (4096 Bytes per Page)

/************************************************************************************************
* FUNCTION		: void init_gpio(void)
*
* DESCRIPTION	: Initialize Basic System Status (I/O ports)
*
************************************************************************************************/
#if 0
void init_gpio(void)
{
	PGPIO		pGPIO = (GPIO *)&HwGPIO_BASE;
	// GPIO A
	pGPIO->GPADAT = Hw2|Hw3;
//	pGPIO->GPAEN  = (Hw32-Hw0);	// All Output
	pGPIO->GPAEN  &= ~Hw4; // All Output
	pGPIO->GPAEN  = (Hw32-Hw5)|(Hw4-Hw0); // All Output
	pGPIO->GPAFN0 = Hw4|Hw0;		// SDA0,SCL0
	pGPIO->GPAFN1 = Hw4|Hw0;		// SDA1,SCL1
	pGPIO->GPAFN2 = HwZERO;
	pGPIO->GPAFN3 = HwZERO;

	// GPIO B - NAND, ETH, SD1
	pGPIO->GPBDAT = HwZERO; 		//LCD_BL_EH
	pGPIO->GPBEN  = (Hw32-Hw0);
	pGPIO->GPBFN0 = HwZERO;
	pGPIO->GPBFN1 = HwZERO;
	pGPIO->GPBFN2 = HwZERO;
	pGPIO->GPBFN3 = HwZERO;

	// GPIO C - LCD , BT_HWAKE, FM_IRQ, EXB0
	pGPIO->GPCDAT	= HwZERO;
	pGPIO->GPCEN 	= (Hw32-Hw0);			// LCD_DISP
	pGPIO->GPCFN0	= HwZERO;
	pGPIO->GPCFN1	= HwZERO;
	pGPIO->GPCFN2	= HwZERO;
	pGPIO->GPCFN3	= HwZERO;

	// GPIO D - CODEC, CAS, GPS, SPD,
	pGPIO->GPDDAT = HwZERO;
	pGPIO->GPDEN  = (Hw26-Hw0);
	pGPIO->GPDFN0 = (Hw28|Hw24||Hw20|Hw17|Hw13|Hw9|Hw5|Hw1); //BCLK(0),LRCK(0),MRCLK(0),DAO(0),DAI(0)
	pGPIO->GPDFN1 = (Hw16|Hw12|Hw8|Hw4|Hw0);
	pGPIO->GPDFN2 = HwZERO;
	pGPIO->GPDFN3 = HwZERO;
	
// GPIO E - Debug
	pGPIO->GPEDAT = HwZERO;
	pGPIO->GPEEN  = (Hw24-Hw0);
	pGPIO->GPEFN0 = (Hw4|Hw0); // UTXD0, URXD0
	pGPIO->GPEFN1 = HwZERO;
	pGPIO->GPEFN2 = HwZERO;
	pGPIO->GPEFN3 = HwZERO;
	
// GPIO F
	pGPIO->GPFDAT = HwZERO;
	pGPIO->GPFEN  = (Hw28-Hw0);
	pGPIO->GPFFN0 = HwZERO;
	pGPIO->GPFFN1 = HwZERO;
	pGPIO->GPFFN2 = HwZERO;
	pGPIO->GPFFN3 = HwZERO;
// EINTSEL
	pGPIO->EINTSEL0 =HwZERO;
	pGPIO->EINTSEL1 =HwZERO;
	pGPIO->EINTSEL2 =HwZERO;
}
#endif

void CheckSuspend(void){
	ptSYSTEM_PARAM sysparam = (ptSYSTEM_PARAM)SYSTEM_PARAM_BASEADDRESS;
	PRTC pRTC = (PRTC)(((unsigned int)&HwRTC_BASE));

	if(sysparam->POWER_KEY == PWRCTL_SUSPEND)
	{

		//check for valid DDR 
		if(*(volatile unsigned long *)(SUS_DRAM_VALID1_PADDR) != PWRCTL_DRAMMASK1)
			return;
		if(*(volatile unsigned long *)(SUS_DRAM_VALID2_PADDR) != PWRCTL_DRAMMASK2)
			return;

		*(volatile unsigned long *)0xF01020E4 = 0x00000000;
		*(volatile unsigned long *)0xF01020E8 = 0x00000000;
		*(volatile unsigned long *)0xF01020EC = 0x00000000;
		*(volatile unsigned long *)0xF01020F0 = 0x00000000;
		*(volatile unsigned long *)0xF01020C0 = 0x00000000;
		*(volatile unsigned long *)0xF01020C4 = 0xffffffff;

		IO_ARM_RestoreREG();
	}
}
/************************************************************************************************
* FUNCTION		: void init_regioncache(void)
*
* DESCRIPTION	: Region setting & Cache initializing
*
************************************************************************************************/
void init_regioncache(void)
{
	unsigned	uCacheControl, uTLBBase;
	PVMTREGION		pVMTREGION = (VMTREGION *)&HwREGION_BASE;

	// Total
	pVMTREGION->REGION4 =  0x00000000 + HwVMT_SZ(SIZE_4GB) + HwVMT_DOMAIN(4) +
			HwVMT_REGION_AP_ALL + HwVMT_REGION_EN + HwVMT_CACHE_ON + HwVMT_BUFF_ON;

	//SRAM 0x10000000 ~ 0x18000000  :SIZE_128MB
	pVMTREGION->REGION5 =  0x10000000 + HwVMT_SZ(SIZE_128MB) + HwVMT_DOMAIN(5) +
			HwVMT_REGION_AP_ALL + HwVMT_REGION_EN + HwVMT_CACHE_OFF + HwVMT_BUFF_OFF;

	//SRAM 0x40100000 ~ 0x40200000  :SIZE_1MB
	pVMTREGION->REGION6 =  0x40100000 + HwVMT_SZ(SIZE_1MB) + HwVMT_DOMAIN(6) +
			HwVMT_REGION_AP_ALL + HwVMT_REGION_EN + HwVMT_CACHE_OFF + HwVMT_BUFF_OFF;

	// Region 7 for Peripheral Register (0x80000000 ~ 0xFFFFFFFF)
	pVMTREGION->REGION7 =  0x80000000 + HwVMT_SZ(SIZE_2GB) + HwVMT_DOMAIN(7) +
			HwVMT_REGION_AP_ALL + HwVMT_REGION_EN + HwVMT_CACHE_OFF + HwVMT_BUFF_OFF;

	uTLBBase		=(unsigned int)&HwVMT_BASE; // 0x20000000
	uCacheControl	=	0x00050078		// should be one
					+ Hw14			// round-robin replacement
				//	+ Hw13			// Vector address = 0xFFFF0000
					+ Hw12			// I-Cache Enable
				//	+ Hw9			// Rom Protection
				//	+ Hw8			// System Protection
				//	+ Hw7			// Big Endian
					+ Hw2			// D-Cache Enable
				//	+ Hw1			// Align fault enable
  					+ Hw0			// MMU enable
					;
	init_mmu(uTLBBase, uCacheControl);
}

/************************************************************************************************
* FUNCTION		: void init_vtc(void)
*
* DESCRIPTION	: Vector Table copy
*
************************************************************************************************/
void init_vtc(void)
{
	unsigned long EntryOffset, NumOfCopyEntry, loop;
	unsigned long CopyEntrySrc, CopyEntryDest, CopyEntryCLen, CopyEntryDLen;
	
	PMISCCOREBUS		pMISCCOREBUS = (MISCCOREBUS *)&HwCORECFG_BASE;

	pMISCCOREBUS->CORECFG |= Hw0; // REMAP Reset Value [1:0] = 0, If Remap is 01b, On-chip memory for region R.1  SRAM

	init_vtcopy(LOAD_VECTOR_BASE, 
					IMAGE_VECTOR_BASE, 
					IMAGE_VECTOR_LENGTH,
					IMAGE_VECTOR_ZI_BASE, 
					IMAGE_VECTOR_ZI_LENGTH);

	// RW data and ZI(bss) area copy
	NumOfCopyEntry = *(volatile unsigned long *)(TOC_BASE_ADDR + 8*sizeof(unsigned long));
	EntryOffset = *(volatile unsigned long *)(TOC_BASE_ADDR + 9*sizeof(unsigned long));
	for (loop = 0; loop < NumOfCopyEntry; loop++)
	{
		CopyEntrySrc  = *(volatile unsigned long *)(EntryOffset + loop*4*sizeof(unsigned long));
		CopyEntryDest = *(volatile unsigned long *)(EntryOffset + loop*4*sizeof(unsigned long) + 1*sizeof(unsigned long));
		CopyEntryCLen = *(volatile unsigned long *)(EntryOffset + loop*4*sizeof(unsigned long) + 2*sizeof(unsigned long));
		CopyEntryDLen = *(volatile unsigned long *)(EntryOffset + loop*4*sizeof(unsigned long) + 3*sizeof(unsigned long));

		init_vtcopy(CopyEntrySrc,
						CopyEntryDest,
						CopyEntryCLen,
						CopyEntryDest + CopyEntryCLen,
						CopyEntryDLen - CopyEntryCLen);
	}


}

/************************************************************************************************
* FUNCTION		: void init_clock(void)
*
* DESCRIPTION	: Clock Setting & IRQ Enable Func call
*
************************************************************************************************/
void BootloaderMainMenu(void)
{
	ULONG count;
#ifndef _IMGNOKITL_
	UINT8 KeySelect;
	UINT32 dwStartTime=0, dwPrevTime, dwCurrTime;
#endif

	// Display boot message - user can halt the autoboot by pressing any key on the serial terminal emulator.
	count = gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay;

	KITLOutputDebugString("--------------------------------------------------------------\n");
	KITLOutputDebugString("[TCBOOT      ]Telechips Bootloader Ver %d.%d for Windows Embedded CE 6.0\n",gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nVerMajor, gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nVerMinor);
	KITLOutputDebugString("[TCBOOT      ]DATE:"__DATE__ ", TIME:" __TIME__ "\r\n");
	KITLOutputDebugString("--------------------------------------------------------------\n");

    FWDN_Check();

	SDUpdate();

#ifndef _IMGNOKITL_

	KITLOutputDebugString("[TCBOOT      ]Press [ENTER] or [SPACE] to enter boot monitor.\r\n");
	KITLOutputDebugString("[TCBOOT      ]Initiating image download in %d seconds.",count--);

	dwStartTime = OEMEthGetSecs();

	dwPrevTime  = dwStartTime;
	dwCurrTime  = dwStartTime;
	KeySelect   = 0;

	while((dwCurrTime - dwStartTime) < gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay)
	{
		KeySelect = readbyte();		// Input Key
		dwCurrTime = OEMEthGetSecs();

		// Show Main Menu
		if ((KeySelect == 0x20) || (KeySelect == 0x0d))
		{
			ShellMenu();
			break;
		}

		if(dwCurrTime > dwPrevTime)
		{
			int i, j;
			dwPrevTime = dwCurrTime;

			if(count < 9)
				i=10;
			else if(count < 99)
				i=11;
			else if(count < 999)
				i=12;

			for(j=0;j<i;j++)
			{
				OEMWriteDebugByte((BYTE)0x08); // print back space
			}
			KITLOutputDebugString( "%d seconds.", count--);
		}
	}
#endif
	KITLOutputDebugString ( "\r\n");
	Loader(1);
}

#ifdef LOADXIPKERNEL	
typedef struct _PARTENTRY {
		BYTE			Part_BootInd;			// If 80h means this is boot partition
		BYTE			Part_FirstHead; 		// Partition starting head based 0
		BYTE			Part_FirstSector;		// Partition starting sector based 1
		BYTE			Part_FirstTrack;		// Partition starting track based 0
		BYTE			Part_FileSystem;		// Partition type signature field
		BYTE			Part_LastHead;			// Partition ending head based 0
		BYTE			Part_LastSector;		// Partition ending sector based 1
		BYTE			Part_LastTrack; 		// Partition ending track based 0
		DWORD			Part_StartSector;		// Physical starting sector based 0
		DWORD			Part_TotalSectors;		// Total physical sectors in partition
} PARTENTRY;
typedef PARTENTRY UNALIGNED *PPARTENTRY;

#define DEFAULT_SECTOR_SIZE		512
#define MAX_PARTTABLE_ENTRIES	4
#define SIZE_PARTTABLE_ENTRIES	16

#define PARTTABLE_OFFSET		(DEFAULT_SECTOR_SIZE - 2 - (SIZE_PARTTABLE_ENTRIES * MAX_PARTTABLE_ENTRIES))
#endif

void Loader(int type) 
{
	//////////////////////////////////////////////////////////////////////////
	//	 Kernel Image Loading
	//////////////////////////////////////////////////////////////////////////
	unsigned int		nKernelLength, nCRC;
	unsigned long 		pageCount;
	unsigned char		*ptr;
	unsigned short 		retry;
#ifdef LOADXIPKERNEL	
	unsigned char		arrTempMBR[512];
	PPARTENTRY pPartEntry;
	int ret;
	
	KITLOutputDebugString("[TCBOOT      ]XIP Bootting...\n");
	gNAND_PageBuffer = (unsigned char *)(((unsigned int)gNAND_PageBuffer + 8) & 0xFFFFFFF8);
#endif	
	#ifdef NAND_INCLUDE
	if(NAND_Ioctl(DEV_INITIALIZE, NULL))
	{
		KITLOutputDebugString("[TCBOOT      ]Nand Init Fail!\n");
		while(1);
	}
	
	KITLOutputDebugString("[TCBOOT      ]Normal Bootting...\n");
	BootLogoImageChange();
	#elif TRIFLASH_INCLUDE
	if(DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_INITIALIZE, NULL ) > 0)
		B_RETAILMSG("[TCBOOT      ]Triflash booting initializing...\n");
	else
		B_RETAILMSG("[TCBOOT      ]ERROR: Triflash initializing Fail...\n");	
	#endif

    retry = 3;
#ifdef LOADXIPKERNEL	
	ret = NAND_ReadSector(0, 0x0, 0x1, arrTempMBR);
	pPartEntry = (PPARTENTRY)(arrTempMBR + PARTTABLE_OFFSET);
	#if 0	
	KITLOutputDebugString ("[TCBOOT      ]Part_BootInd = 0x%x .\r\n",pPartEntry->Part_BootInd);
	KITLOutputDebugString ("[TCBOOT      ]Part_FirstHead = 0x%x .\r\n",pPartEntry->Part_FirstHead);
	KITLOutputDebugString ("[TCBOOT      ]Part_FirstSector = 0x%x .\r\n",pPartEntry->Part_FirstSector);
	KITLOutputDebugString ("[TCBOOT      ]Part_FirstTrack = 0x%x .\r\n",pPartEntry->Part_FirstTrack);
	KITLOutputDebugString ("[TCBOOT      ]Part_FileSystem = 0x%x .\r\n",pPartEntry->Part_FileSystem);
	KITLOutputDebugString ("[TCBOOT      ]Part_LastHead = 0x%x .\r\n",pPartEntry->Part_LastHead);
	KITLOutputDebugString ("[TCBOOT      ]Part_LastSector = 0x%x .\r\n",pPartEntry->Part_LastSector);
	KITLOutputDebugString ("[TCBOOT      ]Part_LastTrack = 0x%x .\r\n",pPartEntry->Part_LastTrack);
	KITLOutputDebugString ("[TCBOOT      ]Part_StartSector = 0x%x .\r\n",pPartEntry->Part_StartSector);
	KITLOutputDebugString ("[TCBOOT      ]Part_TotalSectors = 0x%x .\r\n",pPartEntry->Part_TotalSectors);
	#endif
	ptr = (unsigned char *)KERNEL_BASEADDRESS;
	ret = NAND_ReadSector(0, pPartEntry->Part_StartSector, 0x2E00, ptr);
	B_RETAILMSG("[TCBOOT      ] XIPKERNEL is loaded!!!!!\n");
    KITLOutputDebugString("[TCBOOT      ]Load Ok!Jump to 0x%x=0x%x\n",KERNEL_BASEADDRESS,*(unsigned long *)KERNEL_BASEADDRESS);
	KITLOutputDebugString("\n");
	jumptokernel(KERNEL_BASEADDRESS);
#else
    while( retry-- )
    {
        ptr = (unsigned char *)KERNEL_BASEADDRESS;
        #ifdef NAND_INCLUDE
		NAND_HDReadPage(HIDDEN_OFFSET_OF_WINCE, 1, ptr);
		#elif TRIFLASH_INCLUDE
		if(MMC_HDReadPage(HARP_PUN, HIDDEN_OFFSET_OF_WINCE, 1, ptr) < 0)
			B_RETAILMSG("[TCBOOT      ]ERROR: Reading Fail...\n");
		#endif
        memcpy(&nKernelLength,ptr+0x1C,4);
        memcpy(&nCRC,ptr+0x18,4);

        B_RETAILMSG("[TCBOOT      ]length = 0x%x,CRC = 0x%x\n",nKernelLength, nCRC);
		if(nKernelLength >= 0xffffffff)
			return; //error
			
        pageCount = ( ( nKernelLength + ( 512 - 1)  ) / 512 );

        #ifdef NAND_INCLUDE
		NAND_HDReadPage((HIDDEN_OFFSET_OF_WINCE), pageCount, ptr);   
		#elif TRIFLASH_INCLUDE
		{
			unsigned short	nSector;
			unsigned int	cntAddr = 0;
			if(pageCount > 65535)
			{
				while(pageCount>65535)
				{
					if(MMC_HDReadPage(HARP_PUN, HIDDEN_OFFSET_OF_WINCE, 65535, (ptr+cntAddr)) < 0)
						B_RETAILMSG("[TCBOOT      ]ERROR: Reading Fail...\n");

					cntAddr = cntAddr + (65535*512);
					pageCount = pageCount - 65535;
				}
				if(MMC_HDReadPage(HARP_PUN, HIDDEN_OFFSET_OF_WINCE, pageCount, (ptr+cntAddr)) < 0)
					B_RETAILMSG("[TCBOOT      ]ERROR: Reading Fail...\n");				
			}
			else
			{
				if(MMC_HDReadPage(HARP_PUN, HIDDEN_OFFSET_OF_WINCE, pageCount, ptr) < 0)
					B_RETAILMSG("[TCBOOT      ]ERROR: Reading Fail...\n");
			}
		}
		#endif
#ifdef _FULL_CRC_CHECK_
        if( VerifyROMFile ( (unsigned int*)KERNEL_BASEADDRESS,nKernelLength) == 1)
#else
		if( VerifyROMFile_128K ( (unsigned int*)KERNEL_BASEADDRESS,nKernelLength) == 1)
#endif
        {
            KITLOutputDebugString("[TCBOOT      ]Load Ok!Jump to 0x%x=0x%x\n",KERNEL_BASEADDRESS,*(unsigned long *)KERNEL_BASEADDRESS);
			KITLOutputDebugString("\n");

			jumptokernel(KERNEL_BASEADDRESS);
        }
    }
#endif	
	KITLOutputDebugString("[TCBOOT      ]Load Fail.. Please Check NK.ROM file \n");		
}

void init_systeminfo(void)
{
	KITLOutputDebugString("\n*************************************************************\n");
	KITLOutputDebugString("*                    < Telechips TCC89x >                   *\n");	
	KITLOutputDebugString("*                < PLL0:%d ,CPU:%d ,BUS:%d >             *\n",(tca_ckc_getpll(0)/10000),(tca_ckc_getcpu()/10000),(tca_ckc_getbus()/10000));
	KITLOutputDebugString("*               < PLL1:%d ,PLL2:%d ,PLL3:%d >            *\n",(tca_ckc_getpll(1)/10000),(tca_ckc_getpll(2)/10000),(tca_ckc_getpll(3)/10000));
	KITLOutputDebugString("*               < Fddi:%d ,Fgrp:%d ,Fiob:%d >            *\n",(tca_ckc_getfbusctrl(CLKCTRL1)/10000),(tca_ckc_getfbusctrl(CLKCTRL3)/10000),(tca_ckc_getfbusctrl(CLKCTRL4)/10000));
	KITLOutputDebugString("*               < Fvbus:%d ,Fvpu:%d ,Fsmu:%d >            *\n",(tca_ckc_getfbusctrl(CLKCTRL5)/10000),(tca_ckc_getfbusctrl(CLKCTRL6)/10000),(tca_ckc_getfbusctrl(CLKCTRL7)/10000));
	KITLOutputDebugString("*************************************************************\n");
}

/************************************************************************************************
* FUNCTION		: static BOOL ShellMenu()
*
* DESCRIPTION	:  Manages the Telechips bootloader main menu.
*
************************************************************************************************/
static BOOL ShellMenu(PSYSTEMPARAM pBootCfg)
{
    BYTE KeySelect = 0;
    BOOL bConfigChanged = FALSE;
    BOOLEAN bDownload = TRUE;
    while(1)
    {
		KeySelect = 0;
        KITLOutputDebugString( "\r\n**Telechips Windows CE Ethernet Bootloader Configuration:**\r\n");
		KITLOutputDebugString( "---------------------------------------------------------------\n");
        KITLOutputDebugString ( "0) IP address: %s\n", inet_ntoa(gpBOOTARGS->SYSTEM_ARGS.mKitl.nIPAddr));
		KITLOutputDebugString ( "1) Subnet mask: %s\n", inet_ntoa(gpBOOTARGS->SYSTEM_ARGS.mKitl.nSubnetMask));
        KITLOutputDebugString ( "2) DHCP: %s\n", (gpBOOTARGS->SYSTEM_ARGS.nConfigFlags & CONFIG_FLAGS_DHCP)?"Enabled":"Disabled");
		KITLOutputDebugString ( "3) CS8900 MAC address: %x:%x:%x:%x:%x:%x\n",
			gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[0] & 0x00FF, gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[0] >> 8,
			gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[1] & 0x00FF, gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[1] >> 8,
			gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[2] & 0x00FF, gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[2] >> 8);
		KITLOutputDebugString ( "4) Boot delay time: %d seconds\n", gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay);
        KITLOutputDebugString ( "5) USB Downloading (FWDN)\n");
        KITLOutputDebugString ( "6) Reset Configuration\n");

		KITLOutputDebugString ( "K) KITL Mode Setiing: %s\n",(gpBOOTARGS->SYSTEM_ARGS.SetFlag == 1 )?"Enabled":"Disabled");
        KITLOutputDebugString ( "W) Write Configuration Right Now\n");
		
        KITLOutputDebugString ( "L) LAUNCH existing Boot Media image\n");
		
		KITLOutputDebugString( "---------------------------------------------------------------\n");
        KITLOutputDebugString( "Enter your selection: ");
		
        while (! ( ( (KeySelect >= '0') && (KeySelect <= '9') ) ||
			( (KeySelect == 'K') || (KeySelect == 'k') ) ||
			( (KeySelect == 'L') || (KeySelect == 'l') ) ||
			( (KeySelect == 'W') || (KeySelect == 'w') ) ||
			( (KeySelect == 'X') || (KeySelect == 'x') ) ))
        {
			KITLOutputDebugString(" ");	 
			OEMWriteDebugByte((unsigned char) 0x08);
			KeySelect = readbyte();
		}
		KITLOutputDebugString ( "%c\n", KeySelect);

        switch(KeySelect)
        {
        case '0':           // Change IP address.
            SetIP();
            gpBOOTARGS->SYSTEM_ARGS.nConfigFlags &= ~CONFIG_FLAGS_DHCP;   // clear DHCP flag
            bConfigChanged = TRUE;
            break;
        case '1':           // Change subnet mask.
            SetMask();
            bConfigChanged = TRUE;
            break;
        case '2':           // Toggle static/DHCP mode.
            gpBOOTARGS->SYSTEM_ARGS.nConfigFlags = (gpBOOTARGS->SYSTEM_ARGS.nConfigFlags ^ CONFIG_FLAGS_DHCP);
            bConfigChanged = TRUE;
            break;
        case '3':           // Configure Crystal CS8900 MAC address.
			SetMACAddress();
            bConfigChanged = TRUE;
            break;
        case '4':           // Change autoboot delay.
			SetDelay();
            bConfigChanged = TRUE;
            break;
		case '5':           // Run ConnectToFWDN.
 //           ConnectToFWDN();
            bConfigChanged = TRUE;
            break;
		case '6':           // Run ConnectToFWDN.
            BootArgsSetting();
            bConfigChanged = TRUE;
            break;
		case 'k':			// Toggle KITL disable/active mode.
        case 'K':
			if(gpBOOTARGS->SYSTEM_ARGS.SetFlag)
			{
				gpBOOTARGS->SYSTEM_ARGS.SetFlag = 0; // (gpBOOTARGS->SetFlag ^ SET_KITL_NO);
				KITLOutputDebugString("[TCBOOT      ]KITL Disbled!!!\n");
			}
			else
			{
				gpBOOTARGS->SYSTEM_ARGS.SetFlag = 1;
				KITLOutputDebugString("[TCBOOT      ]KITL Enabled!!!\n");
			}
            bConfigChanged = TRUE;
            break;
        case 'W':           // Configuration Write
        case 'w':
			//	SaveParamToNand(gpBOOTARGS);
            break;

		case 'L':			// OS Launch
		case 'l':
			Loader(1);
		default:
			break;
		}
	}
}


/************************************************************************************************
* FUNCTION		: void SetIP()
*
* DESCRIPTION	: Accepts IP address from user input.
*
************************************************************************************************/
void SetIP()
{
    CHAR   szDottedD[16];   // The string used to collect the dotted decimal IP address.
    USHORT cwNumChars = 0;
    USHORT InChar = 0;

    KITLOutputDebugString("\r\nEnter new IP address: ");

    while(!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = readbyte();
        
        // If it's a number or a period, add it to the string.
        //
        if (InChar == '.' || (InChar >= '0' && InChar <= '9')) 
        {
            if (cwNumChars < 16) 
            {
                szDottedD[cwNumChars++] = (char)InChar;
                OEMWriteDebugByte((BYTE)InChar);

            }
        }
        // If it's a backspace, back up.
        //
        else if (InChar == 8) 
        {
            if (cwNumChars > 0) 
            {
                cwNumChars--;
                OEMWriteDebugByte((BYTE)InChar);
            }
        }
	}

    // If it's a carriage return with an empty string, don't change anything.
    //
    if (cwNumChars) 
    {
        szDottedD[cwNumChars] = '\0';
        gpBOOTARGS->SYSTEM_ARGS.mKitl.nIPAddr = inet_addr(szDottedD);
    }
}

/************************************************************************************************
* FUNCTION		: void SetMask()
*
* DESCRIPTION	: Accepts subnet mask from user input.
*
************************************************************************************************/
void SetMask()
{
    CHAR szDottedD[16]; // The string used to collect the dotted masks.
    USHORT cwNumChars = 0;
    USHORT InChar = 0;

    KITLOutputDebugString("\r\nEnter new subnet mask: ");

    while(!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        {
			InChar = readbyte();  //
        }

        // If it's a number or a period, add it to the string.
        //
        if (InChar == '.' || (InChar >= '0' && InChar <= '9')) 
        {
            if (cwNumChars < 16) 
            {
                szDottedD[cwNumChars++] = (char)InChar;
                OEMWriteDebugByte((BYTE)InChar);
            }
        }
        // If it's a backspace, back up.
        //
        else if (InChar == 8) 
        {
            if (cwNumChars > 0) 
            {
                cwNumChars--;
                OEMWriteDebugByte((BYTE)InChar);
            }
        }
    }

    // If it's a carriage return with an empty string, don't change anything.
    //
    if (cwNumChars) 
    {
        szDottedD[cwNumChars] = '\0';
        gpBOOTARGS->SYSTEM_ARGS.mKitl.nSubnetMask = inet_addr(szDottedD);
    }
}

/************************************************************************************************
    @func   void | SetDelay | Accepts an autoboot delay value from user input.
    @rdesc  N/A.
    @comm
    @xref
************************************************************************************************/
void SetDelay()
{
    CHAR szCount[16];
    USHORT cwNumChars = 0;
    USHORT InChar = 0;
	unsigned int nTemp=0;

    KITLOutputDebugString("\r\nEnter number of seconds to delay [1-255]: ");

    while(!((InChar == 0x0d) || (InChar == 0x0a)))
    {
        InChar = readbyte();
        
        // If it's a number or a period, add it to the string.
        //
        if ((InChar >= '0' && InChar <= '9')) 
        {
            if (cwNumChars < 16) 
            {
                szCount[cwNumChars++] = (char)InChar;
                writebyte((BYTE)InChar);
            }
        }
        // If it's a backspace, back up.
        //
        else if (InChar == 8) 
        {
            if (cwNumChars > 0) 
            {
                cwNumChars--;
                writebyte((BYTE)InChar);

            }
        }
    }
    // If it's a carriage return with an empty string, don't change anything.
    //
    if (cwNumChars) 
    {
        szCount[cwNumChars] = '\0';
		nTemp = atoi(szCount);
        gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay = ((nTemp/10) *10)+((nTemp%10));
        if (gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay > 255)
        {
            gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay = 255;
        }
        else if (gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay < 1)
        {
            gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay = 1;
        }
    }
}

/************************************************************************************************
* FUNCTION		: ULONG mystrtoul(PUCHAR pStr, UCHAR nBase)
*
* DESCRIPTION	: Accepts subnet mask from user input.
*
************************************************************************************************/
ULONG mystrtoul(PUCHAR pStr, UCHAR nBase)
{
	UCHAR nPos=0;
	BYTE c;
	ULONG nVal = 0;
	UCHAR nCnt=0;
	ULONG n=0;

	// fulllibc doesn't implement isctype or iswctype, which are needed by
	// strtoul, rather than including coredll code, here's our own simple strtoul.

	if (pStr == NULL)
		return(0);

	for (nPos=0 ; nPos < strlen((const char *)pStr) ; nPos++)
	{
		c = tolower(*(pStr + strlen((const char *)pStr) - 1 - nPos));
		if (c >= '0' && c <= '9')
			c -= '0';
		else if (c >= 'a' && c <= 'f')
		{
			c -= 'a';
			c  = (0xa + c);
		}

		for (nCnt = 0, n = 1 ; nCnt < nPos ; nCnt++)
		{
			n *= nBase;
		}
		nVal += (n * c);
	}

	return(nVal);
}

/************************************************************************************************
* FUNCTION		: void CvtMAC(USHORT MacAddr[3], char *pszDottedD )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void CvtMAC(USHORT MacAddr[3], char *pszDottedD )
{
	DWORD cBytes;
	char *pszLastNum;
	int atoi (const char *s);
	int i=0;
	BYTE *p = (BYTE *)MacAddr;

	// Replace the dots with NULL terminators
	pszLastNum = pszDottedD;
	for(cBytes = 0 ; cBytes < 6 ; cBytes++)
	{
		while(*pszDottedD != '.' && *pszDottedD != '\0')
		{
			pszDottedD++;
		}
		if (pszDottedD == '\0' && cBytes != 5)
		{
			// zero out the rest of MAC address
			while(i++ < 6)
			{
				*p++ = 0;
			}
			break;
		}
		*pszDottedD = '\0';
		*p++ = (BYTE)(mystrtoul((PUCHAR)pszLastNum, 16) & 0xFF);
		i++;
		pszLastNum = ++pszDottedD;
	}
}
/************************************************************************************************
* FUNCTION		: void SetMACAddress()
*
* DESCRIPTION	: 
*
************************************************************************************************/
void SetMACAddress()
{
	CHAR szDottedD[24];
	USHORT cwNumChars = 0;
	USHORT InChar = 0;

	memset(szDottedD, '0', 24);

	KITLOutputDebugString("\r\nEnter new MAC address in hexadecimal (hh.hh.hh.hh.hh.hh): ");

	while(!((InChar == 0x0d) || (InChar == 0x0a)))
	{
		InChar = readbyte();
        InChar = tolower(InChar);
        if (InChar != OEM_DEBUG_COM_ERROR && InChar != OEM_DEBUG_READ_NODATA) 
        {
            // If it's a hex number or a period, add it to the string.
            //
            if (InChar == '.' || (InChar >= '0' && InChar <= '9') || (InChar >= 'a' && InChar <= 'f')) 
            {
                if (cwNumChars < 17) 
                {
                    szDottedD[cwNumChars++] = (char)InChar;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
            else if (InChar == 8)       // If it's a backspace, back up.
            {
                if (cwNumChars > 0) 
                {
                    cwNumChars--;
                    OEMWriteDebugByte((BYTE)InChar);
                }
            }
        }
    }

    KITLOutputDebugString ( "\r\n");

    // If it's a carriage return with an empty string, don't change anything.
    //
    if (cwNumChars) 
    {
        szDottedD[cwNumChars] = '\0';
        CvtMAC(gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr, szDottedD);

        KITLOutputDebugString("INFO: MAC address set to: %x:%x:%x:%x:%x:%x\r\n",
                  gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[0] & 0x00FF, gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[0] >> 8,
                  gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[1] & 0x00FF, gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[1] >> 8,
                  gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[2] & 0x00FF, gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[2] >> 8);
    }
    else
    {
        KITLOutputDebugString("WARNING: SetMACAddress: Invalid MAC address.\r\n");
    }
}

/************************************************************************************************
* FUNCTION		: void main(void)
* DESCRIPTION	: Initialize Basic System Status (I/O ports)
************************************************************************************************/
void main(void)
{

	init_copybootddr();

	init_gpio();			// Set the GPIO

	init_stack();			// Set the ARM Mode Stack Pointer

	init_regioncache();		// Set the REGION and TLB and I/D Cache

	init_vtc();				// Set the Vetor Table Copy

	init_clock();			// Set the System Clock and Peri. Clock

	init_i2c();

    init_gpioexpander();
       
	init_serial();
	
	init_disp(1);

	
	enable_interrupt();	// Enable IRQ and FIQ Interrupt

	enable_irq();

//	Argument Value Setting

// 	SD Update

//	Kitl

	CheckSuspend();

	init_systeminfo();

	BootloaderMain();
    // Should never get here.
	//while(1){;}
}
