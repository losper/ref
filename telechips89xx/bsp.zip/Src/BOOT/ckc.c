/****************************************************************************
 *	 FileName	 : ckc.c
 *	 Description : 
 ****************************************************************************
*
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
*
 ****************************************************************************/

#include "ckc.h"

#define PLLFREQ(P, M, S)		(( 120000 * (M) )  / (P) ) >> (S) // 100Hz Unit..
#define FPLL_t(P, M, S) 	PLLFREQ(P,M,S), P, M, S
// PLL table for XIN=12MHz
 // P,	 M,  S
sfPLL	pIO_CKC_PLL[]	=
{
		 {FPLL_t(3, 78,   1)}			// 156MHz 
		,{FPLL_t(3, 120, 1)}			// 240 MHz
		,{FPLL_t(3, 135, 1)}			// 270.0 MHz
		,{FPLL_t(2, 52,   0)}			// 312 MHz
		,{FPLL_t(3, 95,   0)}			// 380 MHz
		,{FPLL_t(1, 39,   0)}			// 468 MHz
		,{FPLL_t(1, 40,   0)}			// 480 MHz
		,{FPLL_t(1, 44,   0)}			// 528 MHz
		,{FPLL_t(2, 104,   0)}			// 624 MHz
		,{FPLL_t(2, 116,   0)}			// 696 MHz		

};
#define NUM_PLL 				(sizeof(pIO_CKC_PLL)/sizeof(sfPLL))

#define	tca_wait()				{ volatile int i; for (i=0; i<0x2000; i++); }
#define iomap_p2v(pa)		((unsigned int)(pa))

/****************************************************************************************
* Global Variable
* ***************************************************************************************/
PCKC	pCKC ;
PPMU	pPMU ; 
PIOBUSCFG pIOBUSCFG;
sfPLL		*pPLL;

/****************************************************************************************
* FUNCTION :void tca_ckc_init(void)
* DESCRIPTION :
* ***************************************************************************************/
volatile void tca_ckc_init(void)
{
	pCKC = (CKC *)iomap_p2v(&HwCLK_BASE);
	pPMU = (PMU *)iomap_p2v(&HwPMU_BASE);
	pIOBUSCFG = (IOBUSCFG *)iomap_p2v(&HwIOBUSCFG_BASE);

    /* IOBUS AHB2AXI: flushs prefetch buffer when bus state is IDLE or WRITE 
					enable:  A2XMOD1 (Audio DMA, GPSB, DMA2/3, EHI1)
					disable: A2XMOD0 (USB1.1Host, USB OTG, SD/MMC, IDE, DMA0/1, MPEFEC, EHI0)
	*/
    pIOBUSCFG->IO_A2X = 0x01;
	
}
/****************************************************************************************
* FUNCTION :unsigned int tca_ckc_getpll(unsigned int ch)
* DESCRIPTION :
* ***************************************************************************************/
volatile unsigned int tca_ckc_getpll(unsigned int ch)
{
	volatile unsigned	int tPLL;
	volatile unsigned	int tPLLCFG;
	unsigned int tPCO; 
	unsigned	iP=0, iM=0, iS=0;

	switch(ch)
	{
		case 0:
			tPLLCFG = pCKC->PLL0CFG;
			break;
		case 1:
			tPLLCFG = pCKC->PLL1CFG;
			break;
		case 2:
			tPLLCFG = pCKC->PLL2CFG;
			break;
		case 3:
			tPLLCFG = pCKC->PLL3CFG;
			break;
	}

	//Fpll Clock
	iS	= (tPLLCFG & 0x7000000) >> 24;
	iM	= (tPLLCFG & 0xFFF00) >> 8;
	iP	= (tPLLCFG & 0x0003F) >> 0;

	tPCO = (120000 * iM ) / iP;
	tPLL= ((tPCO) >> (iS));
	
	return tPLL;

}

/****************************************************************************************
* FUNCTION :unsigned int tca_ckc_getcpu(void)
* DESCRIPTION : 
* ***************************************************************************************/
volatile unsigned int tca_ckc_getcpu(void)
{
	unsigned int lcpu = 0;
	unsigned int lconfig = 0;
	unsigned int lcnt = 0;
	unsigned int li = 0;
	unsigned int lclksource = 0;
	
	lconfig = ((pCKC->CLK0CTRL & (Hw20-Hw4))>>4);
	
	for(li = 0; li < 16; li++)
	{
		if((lconfig & Hw0) == 1)
			lcnt++;
		lconfig = (lconfig >> 1);
	}

	switch(pCKC->CLK0CTRL & (Hw3-Hw0)) // Check CPU Source
	{
		case PCDIRECTPLL0 :
			lclksource =  tca_ckc_getpll(0);
			break;
		case PCDIRECTPLL1 :
			lclksource =  tca_ckc_getpll(1);
			break;
		case PCDIRECTPLL2 :
			lclksource =  tca_ckc_getpll(2);
			break;
		case PCDIRECTPLL3 :
			lclksource =  tca_ckc_getpll(3);
			break;
		case PCDIRECTXIN :
			lclksource =  120000;
			break;
		case PCHDMI :
			lclksource =  270000;
			break;
		case PCSATA :
			lclksource =  250000;		
			break;
		case PCUSBPHY:
			lclksource =  480000;		
			break;
		default : 
			lclksource =  tca_ckc_getpll(1);
			break;
	}

	if(pCKC->CLK0CTRL & Hw20) // Dynamic Mode
	{
		lcnt = pCKC->CLK0CTRL & (Hw8-Hw4);
		lcnt = lcnt>>4;
		lcpu = (lclksource / lcnt);
	}
	else
		lcpu = (lclksource * lcnt)/16;

	return lcpu;
}

/****************************************************************************************
* FUNCTION :unsigned int tca_ckc_getbus(void)
* DESCRIPTION : 
* ***************************************************************************************/
volatile unsigned int tca_ckc_getbus(void)
{
	unsigned int lbus = 0;
	unsigned int lconfig = 0;
	unsigned int lclksource = 0;
	
	lconfig = ((pCKC->CLK2CTRL & (Hw8-Hw4))>>4);

	switch(pCKC->CLK2CTRL & (Hw3-Hw0)) // Check CPU Source
	{
		case PCDIRECTPLL0 :
			lclksource =  tca_ckc_getpll(0);
			break;
		case PCDIRECTPLL1 :
			lclksource =  tca_ckc_getpll(1);
			break;
		case PCDIRECTPLL2 :
			lclksource =  tca_ckc_getpll(2);
			break;
		case PCDIRECTPLL3 :
			lclksource =  tca_ckc_getpll(3);
			break;
		case PCDIRECTXIN :
			lclksource =  120000;
			break;
		case PCHDMI :
			lclksource =  270000;
			break;
		case PCSATA :
			lclksource =  250000;		
			break;
		case PCUSBPHY:
			lclksource =  480000;		
			break;
		default : 
			lclksource =  tca_ckc_getpll(1);
			break;
	}

	lbus = lclksource /(lconfig+1);

	return lbus;
}

/****************************************************************************************
* FUNCTION :static unsigned int tca_ckc_setclkctrlx(unsigned int isenable,unsigned int md,unsigned int config,unsigned int sel)
* DESCRIPTION : not ctrl 0 and ctrl 2 (CPU, BUS CTRL)
* ***************************************************************************************/
volatile static unsigned int tca_ckc_gclkctrlx(unsigned int isenable,unsigned int md,unsigned int config,unsigned int sel)
{
	unsigned int retVal = 0;

	retVal = ((isenable?1:0)<<21)|(md<<20)|(config<<4)|(sel<<0);
	
	return retVal;
}

/****************************************************************************************
* FUNCTION :static unsigned int tca_ckc_clkctrly(unsigned int isenable,unsigned int md,unsigned int config,unsigned int sel)
* DESCRIPTION : ctrl 0 and ctrl 2 (CPU and BUS CTRL)
*				config is divider (md = 0)
* ***************************************************************************************/
volatile static unsigned int tca_ckc_gclkctrly(unsigned int isenable,unsigned int md,unsigned int config,unsigned int sel, unsigned int ch)
{
	unsigned int retVal = 0;
//	md = 0;	// Normal Mode

	if(ch == CLKCTRL0)
	{
		switch(config)
		{
			case CLKDIV0:
					config = 0xFFFF; // 1111111111111111b 16/16
				break;
			case CLKDIV2:
					config = 0xAAAA; // 1010101010101010b 8/16
				break;
			case CLKDIV3:
					config = 0x9249; // 1001001001001001b 6/16
				break;
			case CLKDIV4:
					config = 0x8888; // 1000100010001000b 4/16
				break;
			case CLKDIVNONCHANGE:
					config = 0xFFFF; // 1111111111111111b
				break;
			default:
					config = 0xFFFF; // 1111111111111111b
				break;
		}
	}

	if(config == CLKDIVNONCHANGE)
	{
		if(ch == 0) // Fcpu
			retVal = (pCKC->CLK0CTRL & (Hw20-Hw4));
		else		// Fmem_bus 
			retVal = (pCKC->CLK2CTRL & (Hw20-Hw4));
			
		retVal |= ((isenable?1:0)<<21)|(md<<20)|(sel<<0);

	}
	else
		retVal = ((isenable?1:0)<<21)|(md<<20)|(config<<4)|(sel<<0);
	
	return retVal;
}

/****************************************************************************************
* FUNCTION :void tca_ckc_setfbusctrl(unsigned int clkname,unsigned int isenable,unsigned int freq, unsigned int sor)
* DESCRIPTION :
* ***************************************************************************************/
volatile void tca_ckc_setfbusctrl(unsigned int clkname,unsigned int isenable,unsigned int md,unsigned int freq, unsigned int sor)
{
	volatile unsigned	*pCLKCTRL;
	unsigned int clkdiv = 0;
	unsigned int clksource = 0;
	unsigned int lconfig = 0;
	
	pCLKCTRL =(volatile unsigned	*)((&pCKC->CLK0CTRL)+clkname); 

	switch(sor)
	{
		case DIRECTPLL0 :
			clksource =  tca_ckc_getpll(0);
			break;
		case DIRECTPLL1 :
			clksource =  tca_ckc_getpll(1);
			break;
		case DIRECTPLL2 :
			clksource =  tca_ckc_getpll(2);
			break;
		case DIRECTPLL3 :
			clksource =  tca_ckc_getpll(3);
			break;
		case DIRECTXIN:
			clksource =  120000;
			break;
		default : 
			clksource =  tca_ckc_getpll(1);
			break;
	}

	if (freq != 0)
	{
		clkdiv	= (clksource + (freq>>1)) / freq ;	// should be even number of division factor
		clkdiv -= 1;
	}
	else
		clkdiv	= 1;

	if(clkdiv == CLKDIV0) // The config value should not be "ZERO" = 1/(config+1)
		clkdiv = 1;


	if(md == DYNAMIC_MD && !(clkname == CLKCTRL0 || clkname == CLKCTRL2))
	{
		/*
			CONFIG[3:0] 	: Curretn Divisor(Read-only)
			CONFIG[7:4] 	: Max. Divisor
			CONFIG[11:8]	: Min. Divisor
			CONFIG[15:12]	: Update Cycle Period
		*/
			lconfig = (clkdiv<<8); //Min. Divisor
			clkdiv = 10; //Max. Divisor
			lconfig |= ((clkdiv<<4)| 0xF000);	// Min. Divisor = Max. Divisor/2, Update Cycle Period = F

			clkdiv = lconfig;
	}

	if(clkname == CLKCTRL0 || clkname == CLKCTRL2)
	{
		*pCLKCTRL = tca_ckc_gclkctrly(isenable,md,clkdiv,sor,clkname);
	}
	else
	{
		if(isenable == 0)
			*pCLKCTRL &= ~Hw21;
		else
			*pCLKCTRL = tca_ckc_gclkctrlx(isenable,md,clkdiv,sor);
	}
	
}

void tca_ckc_setfbusdynamicctrl(unsigned int clkname, unsigned int maxdiv, unsigned int minmax, unsigned int ucycle)
{
	volatile unsigned	*pCLKCTRL;
	unsigned int lsel = 0;
	unsigned int lconfig = 0;
	
	pCLKCTRL =(volatile unsigned	*)((&pCKC->CLK0CTRL)+clkname); 

	if(!(clkname == CLKCTRL0 || clkname == CLKCTRL2))
	{
		/*
			CONFIG[3:0] 	: Curretn Divisor(Read-only)
			CONFIG[7:4] 	: Max. Divisor
			CONFIG[11:8]	: Min. Divisor
			CONFIG[15:12]	: Update Cycle Period
		*/
		lconfig = (ucycle << 12 |minmax<<8|maxdiv<<4) ;	// Min. Divisor = Max. Divisor/2, Update Cycle Period = F
		
		lsel = ((*pCLKCTRL) & 0x7);	// Current Source
		
		*pCLKCTRL = tca_ckc_gclkctrlx(1,1,lconfig,lsel);
	}
	
}

/****************************************************************************************
* FUNCTION :void tca_ckc_getfbusctrl(unsigned int clkname)
* DESCRIPTION :
* ***************************************************************************************/
volatile int tca_ckc_getfbusctrl(unsigned int clkname)
{
	volatile unsigned	*pCLKCTRL;
	unsigned int lcheck = 0;
	unsigned int lmd = 0;
	unsigned int lconfig = 0;
	unsigned int lsel = 0;
	unsigned int clksource = 0;	

	pCLKCTRL =(volatile unsigned	*)((&pCKC->CLK0CTRL)+clkname); 

	lcheck = ((*pCLKCTRL >> 21) & Hw0);
	lmd = ((*pCLKCTRL >> 20) & Hw0);
	lconfig = ((*pCLKCTRL >> 4) & 0xF);
	lsel = ((*pCLKCTRL) & 0x7);
	
	if(!lcheck || (clkname == CLKCTRL0 || clkname == CLKCTRL2))
		return -1;

	if(lmd == 0)
	{
		switch(lsel)
		{
			case DIRECTPLL0 :
				clksource =  tca_ckc_getpll(0);
				break;
			case DIRECTPLL1 :
				clksource =  tca_ckc_getpll(1);
				break;
			case DIRECTPLL2 :
				clksource =  tca_ckc_getpll(2);
				break;
			case DIRECTPLL3 :
				clksource =  tca_ckc_getpll(3);
				break;
			case DIRECTXIN:
				clksource =  120000;
				break;
			default : 
				clksource =  tca_ckc_getpll(1);
				break;
		}

	}
	else
		return 0;
			
	return (clksource / (lconfig+1));
}

/****************************************************************************************
* FUNCTION :static unsigned int tca_ckc_setpllxcfg(unsigned int isEnable, int P, int M, int S)
* DESCRIPTION :
* ***************************************************************************************/
volatile static unsigned int tca_ckc_gpllxcfg(unsigned int isenable, unsigned int p, unsigned int m, unsigned int s)
{
	unsigned int retVal = Hw31;//Disable
	
	if(isenable > 0)
	{
		retVal = (s<<24)|(m<<8)|(p<<0);
		retVal |= Hw31;	//Enable
	}

	return retVal;
}

/****************************************************************************************
* FUNCTION :static void tca_ckc_pll(unsigned int p, unsigned int m, unsigned int s,unsigned int ch)
* DESCRIPTION :
* ***************************************************************************************/
volatile static void tca_ckc_pll(unsigned int p, unsigned int m, unsigned int s,unsigned int ch)
{
	volatile unsigned	*pPLLCFG;

	pPLLCFG =(volatile unsigned	*)((&pCKC->PLL0CFG)+ch);	

	if(ch == 0)	// PLL0 is System Clock Source
	{
		// Change System Clock Souce --> XIN (12Mhz)
	//	pCKC->CLK0CTRL = tca_ckc_gclkctrly(ENABLE,NORMAL_MD,CLKDIVNONCHANGE,DIRECTXIN,0);
		pCKC->CLK0CTRL = tca_ckc_gclkctrly(ENABLE,NORMAL_MD,CLKDIVNONCHANGE,DIRECTPLL2,0);
//		pCKC->CLK2CTRL = tca_ckc_gclkctrly(ENABLE,NORMAL_MD,CLKDIVNONCHANGE,DIRECTXIN,2);
		tca_wait();	
	}
	
	//Disable PLL
	*pPLLCFG &= ~Hw31;
	//Set PMS
	*pPLLCFG = tca_ckc_gpllxcfg(ENABLE,p,m,s);
	//Enable PLL
	*pPLLCFG |= Hw31;
	tca_wait();	
	//Restore System Clock Source
	if(ch == 0)
	{
//		pCKC->CLK2CTRL = tca_ckc_gclkctrly(ENABLE,NORMAL_MD,CLKDIVNONCHANGE,DIRECTPLL0,2);
		pCKC->CLK0CTRL = tca_ckc_gclkctrly(ENABLE,NORMAL_MD,CLKDIVNONCHANGE,DIRECTPLL0,0);
	}
	
}


/****************************************************************************************
* FUNCTION :void tca_ckc_validpll(unsigned int * pvalidpll)
* DESCRIPTION :
* ***************************************************************************************/
volatile void tca_ckc_validpll(unsigned int * pvalidpll)
{
	unsigned int uCnt;

	pPLL	= &pIO_CKC_PLL[0];
	for (uCnt = 0; uCnt < NUM_PLL; uCnt ++, pPLL ++)
	{
		*pvalidpll = pPLL->uFpll ;	

		pvalidpll++;
	}
};

/****************************************************************************************
* FUNCTION :int tca_ckc_setpll(unsigned int pll, unsigned int ch)
* DESCRIPTION :
* ***************************************************************************************/
volatile int tca_ckc_setpll(unsigned int pll, unsigned int ch)
{
	unsigned	uCnt;
	int			retVal = -1;

	if(pll != 0 )
	{
		pPLL	= &pIO_CKC_PLL[0];
		for (uCnt = 0; uCnt < NUM_PLL; uCnt ++, pPLL ++)
			if (pPLL->uFpll == pll)
				break;
		
		if (uCnt < NUM_PLL)
		{
			tca_ckc_pll(pPLL->P,pPLL->M ,pPLL->S,ch);
			retVal = 0;
			return 1;
		}
	}

	return -1;
}

/****************************************************************************************
* FUNCTION :void tca_ckc_setcpu(unsigned int n)
* DESCRIPTION :  n is n/16 
* example : CPU == PLL : n=16 - CPU == PLL/2 : n=8
* ***************************************************************************************/
volatile void tca_ckc_setcpu(unsigned int n)
{
	 unsigned int lckc0ctrl;	
	 unsigned int lindex[] = {0x0,0x8000,0x8008,0x8808,0x8888,0xA888,0xA8A8,0xAAA8,0xAAAA,
							0xECCC,0xEECC,0xEEEC,0xEEEE,0xFEEE,0xFFEE,0xFFFE,0xFFFF};


    lckc0ctrl = pCKC->CLK0CTRL;
    lckc0ctrl &= ~(Hw20-Hw4);
    lckc0ctrl |= (lindex[n] << 4);

    pCKC->CLK0CTRL = lckc0ctrl;
}

/****************************************************************************************
* FUNCTION :void tca_ckc_setpmupwroff( unsigned int periname , unsigned int isenable)
* DESCRIPTION : 
* ***************************************************************************************/
volatile void tca_ckc_setpmupwroff( unsigned int periname , unsigned int isenable)
{
	unsigned int retVal = 0;

	switch(periname)
	{
		case PMU_VIDEODAC:
				retVal = (Hw0);	
			break;
		case PMU_HDMIPHY:
				retVal = (Hw1);	
			break;
		case PMU_LVDSPHY:
				retVal = (Hw2);	
			break;
		case PMU_USBNANOPHY:
				retVal = (Hw3);	
			break;
		case PMU_SATAPHY:
				retVal = (Hw4);	
			break;
		case PMU_MEMORYBUS:
				retVal = (Hw5);	
			break;
		case PMU_VIDEOBUS:
				retVal = (Hw6);	
			break;
		case PMU_DDIBUS:
				retVal = (Hw7);	
			break;
		case PMU_GRAPHICBUS:
				retVal = (Hw8);	
			break;
		case PMU_IOBUS:
				retVal = (Hw9);	
			break;
		default:
			break;
	}

	if(isenable)
		pPMU->PWROFF &= ~(retVal);
	else
		pPMU->PWROFF |= (retVal);
	
}
/****************************************************************************************
* FUNCTION :void tca_ckc_getpmupwroff( unsigned int pmuoffname)
* DESCRIPTION : 
* ***************************************************************************************/
volatile int tca_ckc_getpmupwroff( unsigned int pmuoffname)
{
	unsigned int retVal = 0;
	
	switch(pmuoffname)
	{
		case PMU_VIDEODAC:
				retVal =  (pPMU->PWROFF >> 0)  & Hw0;	
			break;
		case PMU_HDMIPHY:
				retVal =  (pPMU->PWROFF >> 1)  & Hw0;	
			break;
		case PMU_LVDSPHY:
				retVal =  (pPMU->PWROFF >> 2)  & Hw0;	
			break;
		case PMU_USBNANOPHY:
				retVal =  (pPMU->PWROFF >> 3)  & Hw0;	
			break;
		case PMU_SATAPHY:
				retVal =  (pPMU->PWROFF >> 4)  & Hw0;	
			break;
		case PMU_MEMORYBUS:
				retVal =  (pPMU->PWROFF >> 5)  & Hw0;	
			break;
		case PMU_VIDEOBUS:
				retVal =  (pPMU->PWROFF >> 6)  & Hw0;	
			break;
		case PMU_DDIBUS:
				retVal =  (pPMU->PWROFF >> 7)  & Hw0;	
			break;
		case PMU_GRAPHICBUS:
				retVal =  (pPMU->PWROFF >> 8)  & Hw0;	
			break;
		case PMU_IOBUS:
				retVal =  (pPMU->PWROFF >> 9)  & Hw0;	
			break;
		default:
			break;
	}

	return retVal;
}

/****************************************************************************************
* FUNCTION :static unsigned int tca_ckc_setpckxxx(unsigned int isenable, unsigned int sel, unsigned int div)
* DESCRIPTION : 
* ***************************************************************************************/
volatile static unsigned int tca_ckc_gpckxxx(unsigned int isenable, unsigned int sel, unsigned int div)
{
	unsigned int retVal = Hw28;	//Enable

	//if(isenable > 0)
	{
		retVal = ((isenable?1:0)<<28)|(sel<<24)|(div<<0);
	}

	return retVal;
}

/****************************************************************************************
* FUNCTION :static unsigned int tca_ckc_setpckyyy(unsigned int isenable, unsigned int sel, unsigned int div)
* DESCRIPTION : md (1: divider Mode, 0:DCO Mode)
* ***************************************************************************************/
volatile static unsigned int tca_ckc_gpckyyy(unsigned int isenable, unsigned int md, unsigned int sel, unsigned int div)
{
	unsigned int retVal = Hw28;//Enable

	//if(isenable > 0)
	{
		retVal = (md<<31)|((isenable?1:0)<<28)|(sel<<24)|(div<<0);
	}

	return retVal;
}

/****************************************************************************************
* FUNCTION :void tca_ckc_setperi(unsigned int periname,unsigned int isenable, unsigned int freq, unsigned int sor)
* DESCRIPTION : 
* ***************************************************************************************/
volatile void tca_ckc_setperi(unsigned int periname,unsigned int isenable, unsigned int freq, unsigned int sor)
{
	unsigned  uPll;
	unsigned int clkdiv = 0;
	unsigned int lclksource = 0;
	unsigned int clkmode = 1;
	
	volatile unsigned	*pPERI;
	pPERI =(volatile unsigned	*)((&pCKC->PCLK_TCX)+periname); 

	switch(sor)
	{
		case PCDIRECTPLL0 :
			lclksource =  tca_ckc_getpll(0);
			break;
		case PCDIRECTPLL1 :
			lclksource =  tca_ckc_getpll(1);
			break;
		case PCDIRECTPLL2 :
			lclksource =  tca_ckc_getpll(2);
			break;
		case PCDIRECTPLL3 :
			lclksource =  tca_ckc_getpll(3);
			break;
		case PCDIRECTXIN :
			lclksource =  120000;
			break;
		case PCHDMI :
			lclksource =  270000;
			break;
		case PCSATA :
			lclksource =  250000;		
			break;
		case PCUSBPHY:
			lclksource =  480000;		
			break;
		default : 
			lclksource =  tca_ckc_getpll(1);
			break;
	}
	
	if (freq != 0)
	{
		clkdiv	= (lclksource + (freq>>1)) / freq ;	// should be even number of division factor
		clkdiv -= 1;
	}
	else
		clkdiv	= 0;
	
	if(periname == PERI_ADC || periname == PERI_SPDIF ||periname == PERI_AUD || periname == PERI_DAI)
	{
		if(periname == PERI_DAI || periname == PERI_SPDIF )
		{
			clkmode = 0;	// DCO Mode

            if (periname == PERI_SPDIF)
                freq /= 2;
			if(freq >= 131071)
			{
				clkdiv = (freq *16384);
				uPll = lclksource;
				clkdiv = clkdiv/uPll;
				clkdiv <<= 2;			
				clkdiv = clkdiv + 1;
			}
			else
			{
				clkdiv = (freq *32768);
				uPll = lclksource;
				clkdiv = clkdiv/uPll;
				clkdiv <<= 1;			
				clkdiv = clkdiv + 1;
			}
            if (periname == PERI_SPDIF)
                clkdiv *= 2;
		}
		
		*pPERI = tca_ckc_gpckyyy(isenable,clkmode,sor,clkdiv);
	}
	else
	{
		*pPERI = tca_ckc_gpckxxx(isenable,sor,clkdiv);

	}
}

/****************************************************************************************
* FUNCTION : static int tca_ckc_gperi(unsigned int lclksrc, unsigned int ldiv,unsigned int lmd)
* DESCRIPTION :
* ***************************************************************************************/
volatile static int tca_ckc_gperi(unsigned int lclksrc, unsigned int ldiv,unsigned int lmd)
{
	if(lmd == 1)
	{
		if(lclksrc == PCDIRECTXIN)
			return 120000/(ldiv+1);
		else if(lclksrc == PCDIRECTPLL0){
			return (tca_ckc_getpll(0)/(ldiv+1));
		}
		else if(lclksrc == PCDIRECTPLL1){
			return (tca_ckc_getpll(1)/(ldiv+1));
		}
		else if(lclksrc == PCDIRECTPLL2){
			return (tca_ckc_getpll(2)/(ldiv+1));
		}
		else if(lclksrc == PCDIRECTPLL3){
			return (tca_ckc_getpll(3)/(ldiv+1));
		}
		else if(lclksrc == PCHDMI){
			return (270000/(ldiv+1));
		}
		else if(lclksrc == PCSATA){
			return (250000/(ldiv+1));
		}
		else if(lclksrc == PCUSBPHY){
			return (480000/(ldiv+1));
		}
		else
			return -1; // Not Support Others

	}
	else
		return -1; // TO DO
}

/****************************************************************************************
* FUNCTION : int tca_ckc_getperi(unsigned int periname)
* DESCRIPTION :
* ***************************************************************************************/
volatile int tca_ckc_getperi(unsigned int periname)
{
	unsigned int lreg = 0;
	unsigned int lmd = 1; // DIVIDER mode
	unsigned int lclksrc = 0;
	unsigned int ldiv = 0;
	
	lreg =*(volatile unsigned	*)((&pCKC->PCLK_TCX)+periname); 
	lclksrc = (lreg&0xF000000)>>24;
	
	if(periname == PERI_ADC || periname == PERI_SPDIF ||periname == PERI_AUD || periname == PERI_DAI)
	{
		lmd = (lreg&0x80000000);
		ldiv = (lreg & 0xFFFF);
		return tca_ckc_gperi(lclksrc, ldiv,lmd);
	}
	else
	{
		ldiv = (lreg & 0xFFF);
		return tca_ckc_gperi(lclksrc, ldiv,1);
	}
}

/****************************************************************************************
* FUNCTION :void tca_ckc_setswresetprd(unsigned int prd)
* DESCRIPTION : 
* ***************************************************************************************/
volatile void tca_ckc_setswresetprd(unsigned int prd)
{
	pCKC->SWRESETPRD = prd<<0;
}

/****************************************************************************************
* FUNCTION :unsigned int tca_ckc_set_iobus_swreset(unsigned int sel, unsigned int mode)
* DESCRIPTION : 
* ***************************************************************************************/
volatile unsigned int tca_ckc_set_iobus_swreset(unsigned int sel, unsigned int mode)
{
	unsigned int lindex[] = {Hw0,Hw1,Hw2,Hw3,Hw4,Hw5,Hw6,Hw7,Hw8,Hw9,Hw10,Hw11,Hw12,Hw13,Hw14,Hw15
							,Hw16,Hw17,Hw18,Hw19,Hw20,Hw21,Hw22,Hw23,Hw24,Hw25,Hw26,Hw27,Hw28,Hw29,Hw30,Hw31};

	unsigned int lrb_min;
	unsigned int lrb_max;
	unsigned int lrb_seperate;

	lrb_min = RB_USB11H;
	lrb_max = RB_ALLPERIPERALS;
	lrb_seperate = RB_ADMACONTROLLER;

	if(sel <  lrb_min || sel >=	lrb_max)
	{
		return 0;
	}

	if(sel >  lrb_seperate)
	{
		sel -=	(lrb_seperate+1);
		
		if(mode)
			pIOBUSCFG->HRSTEN1 |= lindex[sel];
		else
			pIOBUSCFG->HRSTEN1 &= ~lindex[sel];
	}
	else
	{
		if(mode)
			pIOBUSCFG->HRSTEN0 |= lindex[sel];
		else
			pIOBUSCFG->HRSTEN0 &= ~lindex[sel];
	}

	return 1;
}

/****************************************************************************************
* FUNCTION :unsigned int tca_ckc_setswreset(unsigned int sel, unsigned int mode)
* DESCRIPTION : 
* ***************************************************************************************/

volatile unsigned int tca_ckc_setswreset(unsigned int lfbusname, unsigned int mode)
{
	unsigned int hIndex[] = {Hw0,Hw1,Hw2,Hw3,Hw4,Hw5,Hw6,Hw7};

	if(mode)
		pCKC->SWRESET |= hIndex[lfbusname];
	else
		pCKC->SWRESET &= ~(hIndex[lfbusname]);
}

/****************************************************************************************
* FUNCTION :  int tca_ckc_setiobus(unsigned int sel, unsigned int mode)
* DESCRIPTION : 
* ***************************************************************************************/
volatile int tca_ckc_setiobus(unsigned int sel, unsigned int mode)
{
	unsigned int lindex[] = {Hw0,Hw1,Hw2,Hw3,Hw4,Hw5,Hw6,Hw7,Hw8,Hw9,Hw10,Hw11,Hw12,Hw13,Hw14,Hw15
							,Hw16,Hw17,Hw18,Hw19,Hw20,Hw21,Hw22,Hw23,Hw24,Hw25,Hw26,Hw27,Hw28,Hw29,Hw30,Hw31};

	unsigned int lrb_min;
	unsigned int lrb_max;
	unsigned int lrb_seperate;

	lrb_min = RB_USB11H;
	lrb_max = RB_ALLPERIPERALS;
	lrb_seperate = RB_ADMACONTROLLER;

	if(sel <  lrb_min || sel >=  lrb_max)
	{
		return -1;
	}

	if(sel >  lrb_seperate)
	{
		sel -=	(lrb_seperate+1);
		
		if(mode)
			pIOBUSCFG->HCLKEN1 |= lindex[sel];
		else
			pIOBUSCFG->HCLKEN1 &= ~lindex[sel];
	}
	else
	{
		if(mode)
			pIOBUSCFG->HCLKEN0 |= lindex[sel];
		else
			pIOBUSCFG->HCLKEN0 &= ~lindex[sel];
	}

	return 1;
}

/****************************************************************************************
* FUNCTION :  int tca_ckc_getiobus(unsigned int sel)
* DESCRIPTION : 
* ***************************************************************************************/
volatile int tca_ckc_getiobus(unsigned int sel)
{
	unsigned int lindex[] = {Hw0,Hw1,Hw2,Hw3,Hw4,Hw5,Hw6,Hw7,Hw8,Hw9,Hw10,Hw11,Hw12,Hw13,Hw14,Hw15
							,Hw16,Hw17,Hw18,Hw19,Hw20,Hw21,Hw22,Hw23,Hw24,Hw25,Hw26,Hw27,Hw28,Hw29,Hw30,Hw31};
	unsigned int lrb_min;
	unsigned int lrb_max;
	unsigned int lrb_seperate;
	int lretVal = 0;
	
	lrb_min = RB_USB11H;
	lrb_max = RB_ALLPERIPERALS;
	lrb_seperate = RB_ADMACONTROLLER;

	
	if(sel <  lrb_min || sel >=  lrb_max)
	{
		return -1;
	}
		
	if(sel >  lrb_seperate)
	{
		sel -=	(lrb_seperate+1);

		lretVal = (pIOBUSCFG->HCLKEN1  & lindex[sel]) ;

	}
	else
	{
		lretVal = (pIOBUSCFG->HCLKEN0  & lindex[sel]) ;
	}

	if(lretVal != 0)
		lretVal = 1; // Enable
		
	return lretVal;
}

/****************************************************************************************
* FUNCTION : void tca_ckc_setddipwdn(unsigned int lpwdn , unsigned int lmode)
* DESCRIPTION : Power Down Register of DDI_CONFIG 
* ***************************************************************************************/
void tca_ckc_setddipwdn(unsigned int lpwdn , unsigned int lmode)
{
	PDDICONFIG lDDIPWDN;
	unsigned int lindex[] = {Hw0,Hw1,Hw2,Hw3,Hw4,Hw5,Hw6,Hw7,Hw8};

	lDDIPWDN = (PDDICONFIG)(iomap_p2v((unsigned int)&HwDDI_CONFIG_BASE)); //0xF0400000

	if(lmode) // Power Down
		lDDIPWDN->PWDN &= ~lindex[lpwdn];
	else // Normal
		lDDIPWDN->PWDN |= lindex[lpwdn];

}
/****************************************************************************************
* FUNCTION : int tca_ckc_getddipwdn(unsigned int lpwdn)
* DESCRIPTION : Power Down Register of DDI_CONFIG 
* ***************************************************************************************/
int tca_ckc_getddipwdn(unsigned int lpwdn)
{
	PDDICONFIG lDDIPWDN;
	unsigned int lindex[] = {Hw0,Hw1,Hw2,Hw3,Hw4,Hw5,Hw6,Hw7,Hw8};

	lDDIPWDN = (PDDICONFIG)(iomap_p2v((unsigned int)&HwDDI_CONFIG_BASE)); //0xF0400000

	return (lDDIPWDN->PWDN &  lindex[lpwdn]);
}

/****************************************************************************************
* DESCRIPTION : End Clock 
* ***************************************************************************************/
	
