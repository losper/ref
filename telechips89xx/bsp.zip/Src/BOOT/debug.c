/****************************************************************************
 *	 FileName	 : debug.c
 *	 Description : 
 ****************************************************************************
*
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include "bsp.h"
#include "string.h"
#include "debug.h"

/************************************************************************************************
*  Globals.
************************************************************************************************/
unsigned int uartRxCount;
unsigned int uartRxStart;
unsigned char uartRxBuf[128];
unsigned char uartTmpBuf[128];

/************************************************************************************************
*  Define.
************************************************************************************************/

/************************************************************************************************
*  extern.
************************************************************************************************/
extern void *memcpy(void *, const void *, unsigned int);

/************************************************************************************************
* FUNCTION		: void OEMInitDebugSerial() 
*
* DESCRIPTION	: Initializes the debug serial port
*
************************************************************************************************/
void init_serial(void) 
{
	PUART		pUART = (UART *)&HwUARTCH0_BASE;
	PGPIO		pGPIO = (GPIO *)&HwGPIO_BASE;


	//GPIO
	pGPIO->GPEFN0	|= (Hw4|Hw0); // UTXD0, URXD0
	//pGPIO->GPEFN0	|= (Hw12|Hw8); // UTXD0, URXD0

	//pGPIO->GPECD0  &= ~0xf;

	pUART->LCR		= Hw4 | Hw2 | Hw1 | Hw0;	
	pUART->LCR		&= ~Hw7;	//HwUART0_LCR_DLAB_OFF; //HwUART1_LCR_DLAB_OFF; 
	pUART->REG2.IER = 0;

	pUART->LCR		|= Hw7; //HwUART0_LCR_DLAB_ON;
	pUART->REG3.FCR = Hw5|Hw4|Hw2|Hw1|Hw0; //HwUART0_FCR_TXFR_EN | HwUART0_FCR_RXFR_EN | HwUART0_FCR_FE_EN;
	pUART->REG1.DLL = 28;
	pUART->REG2.DLM = 0;
	pUART->LCR		&= ~Hw7;
#ifndef _IMGNOKITL_
	pUART->REG2.IER = Hw0;
#endif
	

}


/************************************************************************************************
* FUNCTION		: void OEMWriteDebugByte(UINT8 cChar) 
*
* DESCRIPTION	: Transmits a character out the debug serial port.
*
************************************************************************************************/
void writebyte(unsigned char cChar) 
{
	PUART		pUART = (UART *)&HwUARTCH0_BASE;

	if (cChar=='\n')
	{
		writebyte('\r');
	}

	while (ISZERO(pUART->LSR, Hw5));
	pUART->REG1.THR = cChar;

}
void OEMWriteDebugByte(UINT8 cChar)
{
	writebyte(cChar);
}

/************************************************************************************************
* FUNCTION		: VOID OEMWriteDebugString(const char *string)
*
* DESCRIPTION	: 
*
************************************************************************************************/
static void writestring(const char *string)
{
	while(*string!=0)
		writebyte(*string++);
}


/************************************************************************************************
* FUNCTION		: void OEMWriteDebugData(const char *ccptrString,int length)
*
* DESCRIPTION	: 
*
************************************************************************************************/
static void writedata(const char *ccptrString,int length)
{
	while(length--)
		writebyte(*ccptrString++);
}

/************************************************************************************************
* FUNCTION		: int OEMReadDebugByte()
*
* DESCRIPTION	: 
*
************************************************************************************************/
int readbyte()
{
	unsigned int nTemp = uartRxCount;

	if ( nTemp )
	{
		memcpy(uartTmpBuf,uartRxBuf,uartRxCount);
		uartRxCount = 0;
	}
	else return 0;
	
	return *uartTmpBuf;
}

int clearbytes()
{
	uartRxCount = 0;
}

static void pOutputNumHex(unsigned long n, long depth)
{
	if (depth)	  
		depth--;

	if ((n & ~0xf) || depth)
	{
		pOutputNumHex(n >> 4, depth);
		n &= 0xf;
	}

	if (n < 10)
	{
		writebyte((unsigned char)(n + '0'));
	}
	else
	{
		writebyte((unsigned char)(n - 10 + 'A'));
	}
}


static void pOutputNumDecimal(unsigned long n)
{
	if (n >= 10) 
	{
		pOutputNumDecimal(n / 10);
		n %= 10;
	}
	writebyte((unsigned char)(n + '0'));
}

#if !defined(_LINUX_)
void B_RETAILMSG(const char * sz, ...)
{
    unsigned char    c;
    va_list         vl;
	
	va_start(vl, sz);
	
	while (*sz) {
		c = *sz++;
		switch (c) {
		case '%':
			c = *sz++;
			switch (c) { 
			case 'x':
				pOutputNumHex(va_arg(vl, unsigned long), 0);
				break;
			case 'B':
				pOutputNumHex(va_arg(vl, unsigned long), 2);
				break;
			case 'H':
				pOutputNumHex(va_arg(vl, unsigned long), 4);
				break;
			case 'X':
				pOutputNumHex(va_arg(vl, unsigned long), 8);
				break;
			case 'd':
				{
					long	l;
				
					l = va_arg(vl, long);
					if (l < 0) { 
						writebyte('-');
						l = - l;
					}
					pOutputNumDecimal((unsigned long)l);
				}
				break;
			case 'u':
				pOutputNumDecimal(va_arg(vl, unsigned long));
				break;
			case 's':
				writestring(va_arg(vl, char *));
				break;
			case '%':
				writebyte('%');
				break;
			case 'c':
				c = va_arg(vl, unsigned char);
				writebyte(c);
				break;
				
			default:
				writebyte(' ');
				break;
			}
			break;
		case '\r':
			if (*sz == '\n')
				sz ++;
			c = '\n';
			// fall through
		case '\n':
			writebyte('\r');
			// fall through
		default:
			writebyte(c);
		}
	}
	
	va_end(vl);
}
#endif

