#include "bsp.h"
#include "tcc_gpioexp.h"
#include "tca_ckc.h"
#include "disk.h"
#include "mmc_basic.h"
#include "sdupdate.h"
#include "lcd.h"

#define SDUPDATE_CHOICE_STR "DO YOU WANT TO UPDATE SYSTEM BY SD CARD?"
#define SDUPDATE_DELETE_STR "DO YOU WANT TO DELETE BINARY FILES IN SD CARD?"

#define NAND_PAGE_SIZE 512
#define HIDDENAREA_OFFSET_OF_WINCE 8
int gSDUpgrading = 0;

extern int FWUG_MainFunc(int iFilehandle, int iFileSize);


/*****************************************************************************
* Function Name : SDUpdate_CheckFiles 
******************************************************************************
* Desription  	: Check whether TCBOOT.ROM, NK.ROM or Bootlogo.BIN is existed
*				  in SD Card.
* Parameter   	: 
* Return      	: 0  : At least, One file to be updated existed.
*				  -1 : None file to be updated is existed. 	
*
* Note          : 
******************************************************************************/
int SDUpdate_CheckFiles(int *iHandleOfTCBOOTROM, int *iHandleOfNKROM, int *iHandleOfBootlogoBIN)
{
	*iHandleOfTCBOOTROM	= FILE_OpenName("TCBOOT.ROM", "r", 1);
	*iHandleOfNKROM		= FILE_OpenName("NK.ROM", "r", 1);
	*iHandleOfBootlogoBIN	= FILE_OpenName("BOOTLOGO.BIN", "r", 1);

	if(*iHandleOfTCBOOTROM > 0 || *iHandleOfNKROM > 0 || *iHandleOfBootlogoBIN > 0 )
		return 0;
	else
		return -1;
}


/*****************************************************************************
* Function Name : SDUpdate_UpdateBootloader 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
int SDUpdate_UpdateBootloader(int iFileHandle)
{
	int iRetVal;
	int iLength;

	EdbgOutputDebugString("TCBOOT.ROM was found in SD Card. \nStart updating TCBOOT.ROM...Wait..\n");

	iLength = FILE_Length(iFileHandle);

	iRetVal = FWUG_MainFunc(iFileHandle, iLength);

	if(iRetVal < 0 )
	{
		EdbgOutputDebugString("Failed to update TCBOOT.ROM..\n");
		return -1;
	}

	EdbgOutputDebugString("Suceeded to update TCBOOT.ROM..\n");

	return 0;
}


/*****************************************************************************
* Function Name : SDUpdate_UpdateKernelImage 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
int SDUpdate_UpdateKernelImage(int iFileHandle)
{
    unsigned char* ptr;
    unsigned long pageCount;
    unsigned long i;
    unsigned long percentcount=0,percentpoint=0;
    unsigned int uiProgramLength=0;
    unsigned int uiReadSize = 512, uiWritePage = 128;// 128 page = 64Kbyte
    unsigned int uiTotalSize;
    unsigned int uiHiddenAddr;
    unsigned int ProgramLength;
    unsigned int CRC;

    //TEST
    unsigned char TempBuf[64*1024];

    EdbgOutputDebugString("NK.ROM was found in SD Card. \nReading NK.ROM from SD Card...\n");

    /* Load NK.ROM image from File and verify */

    ptr = (unsigned char *)KERNEL_BASEADDRESS;

    FILE_Read(iFileHandle, ptr, uiReadSize);

    memcpy(&ProgramLength,ptr+0x1C,4);
    memcpy(&CRC,ptr+0x18,4);

    ptr += uiReadSize;

    EdbgOutputDebugString("NK.ROM File length is 0x%x, CRC Value is 0x%x\nNow Loding...\n",ProgramLength,CRC);

    if( ProgramLength >= 0xffffffff)
        return -1; //error

    pageCount = ProgramLength / NAND_PAGE_SIZE;

    if ( ProgramLength % NAND_PAGE_SIZE )
        pageCount++;

    percentcount=pageCount/100;

    percentpoint=0;

    //memset(ptr,0,gProgramLength);
    for (i=0;i<pageCount;i++)
    {
        if ( (i%128) == 0 )
            EdbgOutputDebugString(".");

        if(((i%percentcount)==0)&&(percentpoint<99))
            percentpoint++;

        FILE_Read(iFileHandle, ptr, uiReadSize);

        ptr += uiReadSize;
    }

    EdbgOutputDebugString("\nNK.ROM File Loading is Completed.. Check CRC...\n");

    if( VerifyROMFile ( (unsigned int*)KERNEL_BASEADDRESS,ProgramLength) == 1) // Success
    {
        EdbgOutputDebugString("CRC Check is Valid... NK.ROM File Writing Started...\n");
        memcpy((unsigned long *)(SYSTEM_PARAM_BASEADDRESS),(unsigned long *)(SYSTEM_PARAM_BASEADDRESS-SYSTEM_ARGSMAXSIZE),512);
    }
    else
        return -1;

    ptr = (unsigned char *)KERNEL_BASEADDRESS;

    uiTotalSize = pageCount;

    percentcount=pageCount/100;

    percentpoint=0;

    i = 0;

    uiHiddenAddr = HIDDENAREA_OFFSET_OF_WINCE;

    for (i=0;i<pageCount;i++)
    {
        if ( (i%128) == 0 )
            EdbgOutputDebugString(".");

        if(((i%percentcount)==0)&&(percentpoint<99))
            percentpoint++;

        if( (i% uiWritePage) == 0)
        {
            NAND_HDWritePage(uiHiddenAddr, uiWritePage, ptr);
            NAND_HDReadPage(uiHiddenAddr, uiWritePage, TempBuf);
            if( memcmp(ptr, TempBuf, 64*1024) != 0 )
                return -1;

            uiTotalSize -= uiWritePage;

            ptr += (uiWritePage*NAND_PAGE_SIZE);

            uiHiddenAddr += uiWritePage;

            if(uiTotalSize < uiWritePage)
                uiWritePage = uiTotalSize;

            if(uiWritePage == 0)
                break;
        }
    }

    EdbgOutputDebugString("\nNK.ROM File Writing is Completed...\n");
    return 0;
}

int SDUpdate_UpdateBootlogoImage(int iFileHandle)
{
#if defined(NAND_INCLUDE)
	unsigned char BootLogoInfo[512];
	unsigned char TmpBuff[128*512];
	unsigned char TmpReadBuff[128*512];
	unsigned int LogoBinSecNum = 0;
	unsigned int SpareSize = 0, SecNumPerTmBuff = 0;
	char *LcdBuff = (char *)DISP_BOOTIMG0_BASE_ADDR;
	unsigned int uiHDAddr, uiReadSize;

	EdbgOutputDebugString("BOOTLOGO.BIN was found in SD Card. \nReading BOOTLOGO.BIN from SD Card...\n");

	if(NAND_HDReadSector(0, 0, 1, BootLogoInfo) < 0)
	{
		EdbgOutputDebugString("Multi Hidden area doesn't exist for BootLogo...\n");
		return -1;
	}
	
	if(FILE_Length(iFileHandle) > TELECHIPS_LOGO_BUFF_SIZE)
	{
		EdbgOutputDebugString("BOOTLOGO.BIN size is invalid....\n");
		return -1;
	}

	if(TELECHIPS_LOGO_BUFF_SIZE%512 == 0)
		LogoBinSecNum = TELECHIPS_LOGO_BUFF_SIZE / 512;
	else
		LogoBinSecNum = (TELECHIPS_LOGO_BUFF_SIZE / 512) + 1;
	
	SecNumPerTmBuff = sizeof(TmpBuff) / 512; 

	if(BootLogoInfo[0] == 0xF1)
		uiHDAddr = 1;
	else
		uiHDAddr = 1 + LogoBinSecNum;
		
	while( uiReadSize = FILE_Read(iFileHandle, TmpBuff, sizeof(TmpBuff)) )
	{
		if( uiReadSize != sizeof(TmpBuff) )
		{
			SpareSize = uiReadSize % 512;
			SecNumPerTmBuff = uiReadSize / 512;
			if(SpareSize)
				SecNumPerTmBuff++;
		}

		NAND_HDWriteSector(0, uiHDAddr, SecNumPerTmBuff, TmpBuff);
		NAND_HDReadSector(0, uiHDAddr, SecNumPerTmBuff, TmpReadBuff);
        if( memcmp(TmpReadBuff, TmpBuff, SecNumPerTmBuff*512) != 0 )
        	return -1;
		
		uiHDAddr+=SecNumPerTmBuff;
	}

	if(BootLogoInfo[0] == 0xF1)
		BootLogoInfo[0] = 0xF0;
	else
		BootLogoInfo[0] = 0xF1;
	
	NAND_HDWriteSector(0, 0, 1, BootLogoInfo);
	EdbgOutputDebugString("\nBOOTLOGO.BIN File Writing is Completed...\n");
	return 0;
#endif	
}

/*****************************************************************************
* Function Name : SDUpdateConfirm
******************************************************************************
* Desription  	:
* Parameter   	:	string to be written to LCD
* Return      	:	0 	: When "YES" button was touched, return 0
*					-1 	: When "No" button was touched, ruturn -1
* Note          : 
******************************************************************************/
int SDUpdateConfirm(unsigned char *pStr, int iStatusSDUpdate)
{
    // This function should be implemented..
    int Yes_button_touched = 1;
    
    if( Yes_button_touched )
        return 0;
    else
        return -1;
}


int SDUpdate(void)
{
	int iStatusOfSDUpdate = 0;
	int iRetValTCBOOT = -1, iRetValNK = -1, iRetValBootlogo = -1;
	int iHandleOfNKROM, iHandleOfTCBOOTROM, iHandleOfBootlogoBIN;
    
    PGPION  pGPIOE;
    PGPION  pGPIOA;
    PSDCHCTRL   pSDCTRL;
    PTIMER  pTIMER;
    
    // Filesystem Initialize
    if( !Initialize_FileSystem(DISK_DEVICE_MMC, 0) )
        return FALSE;
//    else
//        return TRUE;


    if(SDUpdate_CheckFiles(&iHandleOfTCBOOTROM, &iHandleOfNKROM, &iHandleOfBootlogoBIN) == 0)
    {
        if(iHandleOfTCBOOTROM > 0)
            iStatusOfSDUpdate |= Hw0; 

        if(iHandleOfNKROM > 0)		
            iStatusOfSDUpdate |= Hw1; 

        if(iHandleOfBootlogoBIN > 0 )		
            iStatusOfSDUpdate |= Hw2; 

        if(SDUpdateConfirm(SDUPDATE_CHOICE_STR,iStatusOfSDUpdate) < 0 )
        {
            if(iHandleOfTCBOOTROM > 0)
                FILE_Close(iHandleOfTCBOOTROM);

            if(iHandleOfNKROM > 0)
                FILE_Close(iHandleOfNKROM);

            if(iHandleOfBootlogoBIN > 0)
                FILE_Close(iHandleOfBootlogoBIN);

            return;
        }

        gSDUpgrading = 1; 
    }
    else
    {
        gSDUpgrading = 0;	
        return;
    }

    /* Update system by Binary files */

    iStatusOfSDUpdate |= Hw6;

    if(iHandleOfTCBOOTROM > 0)
        iRetValTCBOOT = SDUpdate_UpdateBootloader(iHandleOfTCBOOTROM);

    if(iHandleOfNKROM > 0)
        iRetValNK = SDUpdate_UpdateKernelImage(iHandleOfNKROM);

    if(iHandleOfBootlogoBIN > 0)
    	iRetValBootlogo = SDUpdate_UpdateBootlogoImage(iHandleOfBootlogoBIN);

    if(iRetValTCBOOT == 0)
        iStatusOfSDUpdate |= Hw3;

    if(iRetValNK == 0)
        iStatusOfSDUpdate |= Hw4;

    if(iRetValBootlogo == 0)
        iStatusOfSDUpdate |= Hw5;

    /* Delete Binary files */
    if(SDUpdateConfirm(SDUPDATE_DELETE_STR, iStatusOfSDUpdate) == 0)
    {

        if(iHandleOfTCBOOTROM > 0 )
        {
            if(FILE_RemoveWithHandle(1, iHandleOfTCBOOTROM) ==iHandleOfTCBOOTROM)
                EdbgOutputDebugString("TCBOOT.ROM is Removed...\n");
            else
                EdbgOutputDebugString("TCBOOT.ROM Remove Failed...\n");
        }

        if(iHandleOfNKROM > 0 )
        {
            if(FILE_RemoveWithHandle(1, iHandleOfNKROM) == iHandleOfNKROM)
                EdbgOutputDebugString("NK.ROM is Removed...\n");
            else
                EdbgOutputDebugString("NK.ROM Remove Failed...\n");
        }

        if(iHandleOfBootlogoBIN > 0 )
        {
            if(FILE_RemoveWithHandle(1, iHandleOfBootlogoBIN) == iHandleOfBootlogoBIN)
                EdbgOutputDebugString("BOOTLOG.BIN is Removed...\n");
            else
                EdbgOutputDebugString("BOOTLOG.BIN Remove Failed...\n");
        }
    }

    if(iHandleOfTCBOOTROM > 0 )
        FILE_Close(iHandleOfTCBOOTROM);

    if(iHandleOfNKROM > 0 )
        FILE_Close(iHandleOfNKROM);

    if(iHandleOfBootlogoBIN > 0 )
        FILE_Close(iHandleOfBootlogoBIN);

    return 0;
}
