#if defined(_WINCE_)
#include "bsp.h"
#elif defined(_LINUX_)
#include <common.h>
#endif

void    init_gpio(void)
{
    PGPIO   pGPIO = (GPIO*)&HwGPIO_BASE;


	*(volatile int *)0xf0102194 = 0;

    // GPIOA Setting
    pGPIO->GPAEN = 0xFFAF; // All Output
    pGPIO->GPADAT = Hw2|Hw3; // Low
    //pGPIO->GPACD0
    //pGPIO->GPACD1
    //pGPIO->GPAPD0
    //pGPIO->GPAPD1
    pGPIO->GPAFN0 = HwZERO; // GPIO
    pGPIO->GPAFN1 = HwZERO; // GPIO
    pGPIO->GPAFN2 = HwZERO; // GPIO
    pGPIO->GPAFN3 = HwZERO; // GPIO

    // GPIOB Setting
    pGPIO->GPBEN = 0xFFFFFFFF; // All Output
    pGPIO->GPBDAT = HwZERO; // Low
    //pGPIO->GPBCD0
    //pGPIO->GPBCD1
    //pGPIO->GPBPD0
    //pGPIO->GPBPD1
    pGPIO->GPBFN0 = HwZERO; // GPIO
    pGPIO->GPBFN1 = HwZERO; // GPIO
    pGPIO->GPBFN2 = HwZERO; // GPIO
    pGPIO->GPBFN3 = HwZERO; // GPIO

    // GPIOC Setting
    pGPIO->GPCEN = 0xFFFFFFFF; // All Output
    pGPIO->GPCDAT = HwZERO;// Low
    //pGPIO->GPCCD0
    //pGPIO->GPCCD1
    //pGPIO->GPCPD0
    //pGPIO->GPCPD1
    pGPIO->GPCFN0 = HwZERO; // GPIO
    pGPIO->GPCFN1 = HwZERO; // GPIO
    pGPIO->GPCFN2 = HwZERO; // GPIO
    pGPIO->GPCFN3 = HwZERO; // GPIO


    // GPIOD Setting
    pGPIO->GPDEN = 0xFFFFFFFF; // All Output
    pGPIO->GPDDAT = HwZERO; // Low
//    pGPIO->GPDDAT = Hw14; // 
    //pGPIO->GPDCD0
    //pGPIO->GPDCD1
    //pGPIO->GPDPD0 = 0xAAAAAAAA;
    //pGPIO->GPDPD1 = 0x000AAAAA;
    pGPIO->GPDFN0 = HwZERO; // GPIO
    pGPIO->GPDFN1 = HwZERO; // GPIO
    pGPIO->GPDFN2 = HwZERO; // GPIO
    pGPIO->GPDFN3 = HwZERO; // GPIO


    // GPIOE Setting
    pGPIO->GPEEN = 0xFFFFF00F; // All Output - BT,DXB Input 
    pGPIO->GPEDAT = HwZERO; // Low
    //pGPIO->GPECD0
    //pGPIO->GPECD1
    //pGPIO->GPEPD0 = 0xAAAAAAAA;
    //pGPIO->GPEPD1 = 0xAAAAAAAA;
    pGPIO->GPEFN0 = HwZERO; // GPIO
    pGPIO->GPEFN1 = HwZERO; // GPIO
    pGPIO->GPEFN2 = HwZERO; // GPIO
    pGPIO->GPEFN3 = HwZERO; // GPIO

    // GPIOF Setting
    pGPIO->GPFEN = 0xFFFFFFFF; // All Output
    pGPIO->GPFDAT = HwZERO; // Low
    //pGPIO->GPFCD0
    //pGPIO->GPFCD1
    //pGPIO->GPFPD0 // No Pullup/down register
    //pGPIO->GPFPD1 // No Pullup/down register
    pGPIO->GPFFN0 = HwZERO; // GPIO
    pGPIO->GPFFN1 = HwZERO; // GPIO
    pGPIO->GPFFN2 = HwZERO; // GPIO
    pGPIO->GPFFN3 = HwZERO; // GPIO

    pGPIO->GPAPD0 = 0;
    pGPIO->GPAPD1 = 0;
 //   pGPIO->GPBPD0 = 0;
 //   pGPIO->GPBPD1 = 0;
    pGPIO->GPCPD0 = 0;
    pGPIO->GPCPD1 = 0;
    pGPIO->GPDPD0 = 0;
    pGPIO->GPDPD1 = 0;
    pGPIO->GPEPD0 = 0;
    pGPIO->GPEPD1 = 0;
	
    // EINTSEL
    pGPIO->EINTSEL0 =HwZERO;
    pGPIO->EINTSEL1 =HwZERO;
    pGPIO->EINTSEL2 =HwZERO;
	
      
}
