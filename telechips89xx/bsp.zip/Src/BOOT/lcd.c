/***************************************************************************************
*	FileName    : lcd.c 
*	Description : TCBOOT LCD Driver
****************************************************************************************
*
*	TCC Board Support Package
*	Copyright (c) Telechips, Inc.
*	ALL RIGHTS RESERVED
*
****************************************************************************************/


//#include <stdio.h>
//#include <string.h>
#include "bsp.h"
#include "lcd.h"


#if defined(DISP_SRC_32BPP)
 #include "logo_24bit.h"
#else
 #include "logo.h"
#endif

#define LCD_DEBUG	0

#if LCD_DEBUG
#define DPRINTF	KITLOutputDebugString
#else
#define DPRINTF
#endif

extern tSYSTEM_PARAM *gpBOOTARGS;

static int BootLogoFromNandFlag = 0;

// lcdc_idx			- 0: LCDC0, 1: LCDC1
// interface_type	- 0: RGB 24bit Interface, 1: LVDS Interface
typedef struct {
	volatile unsigned int	LIxC;				//   LCD Image x Control Register 
	volatile unsigned int	LIxP;				//   LCD Image x Position Register 
	volatile unsigned int	LIxS;				//   LCD Image x Size Register 
	volatile unsigned int	LIxBA0;				//   LCD Image x Base Address 0 Register. 
	volatile unsigned int	LIxCA;				//   LCD Image x Current Address Register. 
	volatile unsigned int	LIxBA1;				//   LCD Image x Base Address 1 Register 
	volatile unsigned int	LIxBA2;				//   LCD Image x Base Address 2 Register 
	volatile unsigned int	LIxO;				//   LCD Image x Offset Register 
	volatile unsigned int	LIxSR;				//   LCD Image x Scale ratio 
	volatile unsigned int	LIxA;				//   LCD Image x Alpha Configuration Register 
	volatile unsigned int	LIxKR;				//   LCD Image x Keying Register for RED or LUMA(Y) 
	volatile unsigned int	LIxKG;				//   LCD Image x Keying Register for BLUE or CHROMA(Cb) 
	volatile unsigned int	LIxKB;				//   LCD Image x Keying Register for GREEN or CHROMA(Cr) 
	volatile unsigned int	LIxEN;				//   LCD Image x Enhancement Register 
} LCDC_IMG, *PLCDC_IMG;

unsigned int makepixel_16(unsigned int a, unsigned int r, unsigned int g, unsigned int b)
{
	return (unsigned int)(((r>>3)<<11)|((g>>2)<<5|(b>>3)));
}

void fill_rect_16(void *buf, unsigned int pixel, int xpos1, int ypos1, int xpos2, int ypos2)
{
    unsigned short *pfbdata = 0;
	int offset;
	int t, tt;

    if (buf) {
        pfbdata = (unsigned short *)buf;

        if (xpos1 > xpos2) {
            t = xpos1;
            xpos1 = xpos2;
            xpos2 = t;
        }

        if (ypos1 > ypos2) {
            t = ypos1;
            ypos1 = ypos2;
            ypos2 = t;
        }

        for (t = ypos1; t <= ypos2; t++) {
            offset = t * DISP_WIDTH;

            for (tt = xpos1; tt <= xpos2; tt++) {
                *(pfbdata + offset + tt) = (unsigned short)pixel;
            }
        }
    }
}


/****************************************************************************************
* FUNCTION :void init_logo(void)
* DESCRIPTION :
* ***************************************************************************************/
char *pBootImageBuffer[2] = {(char *)DISP_BOOTIMG0_BASE_ADDR, 
							 (char *)DISP_BOOTIMG1_BASE_ADDR};

void init_logo(void)
{
	#define LOGO_WIDTH	480
	#define LOGO_HEIGHT	272
	
	int offset_x=0;
	int offset_y=0;
	
	offset_x = (DISP_WIDTH  - LOGO_WIDTH) /2;
	offset_y = (DISP_HEIGHT - LOGO_HEIGHT)/2;

	// !! must be DISP size >= LOGO size.
	
	if(BootLogoFromNandFlag == 0)
	{
		unsigned int	i,j,k = 0;
		char *Buf;

		memset((char *)pBootImageBuffer[0], 0, DISP_WIDTH * DISP_HEIGHT * DISP_BYTESPERPIXEL);
		for (i = 0; i < LOGO_HEIGHT; i++)
		{
			Buf = (char *)(pBootImageBuffer[0] + ((i + offset_y) * (DISP_WIDTH*DISP_BYTESPERPIXEL)) + (offset_x * DISP_BYTESPERPIXEL));
			
			for (j = 0; j < LOGO_WIDTH*DISP_BYTESPERPIXEL; j++)
			{
				*Buf++ = telechips_logo[k++];
			}
		}
	}
	
	//memcpy((char *)pBootImageBuffer[1], (char *)pBootImageBuffer[0], DISP_WIDTH * DISP_HEIGHT * DISP_BYTESPERPIXEL);
}

void ddic_setdefault(void)
{
    PDDICACHE   pDDICache   = (DDICACHE *)&HwDDI_CACHE_BASE;

	pDDICache->DDIC_CTRL = 0;
	pDDICache->DDIC_CFG1 = 0xffffffff;
	pDDICache->DDIC_CFG0 = 0xffffffff;

#if defined(DEMO_TYPE2)
	BITCSET(pDDICache->DDIC_CTRL, Hw26-Hw0, (Hw5|Hw6|Hw7)|(Hw10|Hw11|Hw0));
#else
	BITCSET(pDDICache->DDIC_CTRL, Hw26-Hw0, (Hw5|Hw6|Hw7)|(Hw9|/*Hw10|Hw11|*/Hw8));
#endif

	BITCSET(pDDICache->DDIC_CFG0, Hw21-Hw16, (5)<<16);	//SEL26		// LCDC1.IMG0.BA0(Y)
	BITCSET(pDDICache->DDIC_CFG0, Hw29-Hw24, (6)<<24);	//SEL27		// LCDC1.IMG0.BA1(U)

	BITCSET(pDDICache->DDIC_CFG1, Hw5 -Hw0 , (7)<<0);	//SEL28		// LCDC1.IMG0.BA2(V)
	BITCSET(pDDICache->DDIC_CFG1, Hw13-Hw8 , (9)<<8);	//SEL29		// LCDC1.IMG2.BA0

//	BITCSET(pDDICache->DDIC_CFG1, Hw13-Hw8 , (10)<<8);	//SEL29		// M2M0.SRCBASEY
//	BITCSET(pDDICache->DDIC_CFG1, Hw21-Hw16, (11)<<16);	//SEL30		// M2M0.SRCBASEU
#if defined(DEMO_TYPE2)
	BITCSET(pDDICache->DDIC_CFG1, Hw29-Hw24, (0)<<24);	//SEL31		// LCDC0.IMG0.BA0
#else
	BITCSET(pDDICache->DDIC_CFG1, Hw29-Hw24, (8)<<24);	//SEL31		// LCDC1.IMG1.BA0
#endif
}

void lcd_interface_init(int lcdc_idx)
{
	PGPIO	pGPIO 	= (GPIO *)&HwGPIO_BASE;
	
	//LCD_RST#	(not used for rgb i/f)
	BITCLR(pGPIO->GPDDAT, Hw22);
	BITSET(pGPIO->GPDEN, Hw22);
	BITCLR(pGPIO->GPDFN2, Hw28-Hw24);
	
	//LCD_DISP
	BITCLR(pGPIO->GPCDAT, Hw28);	//DISP Off
	BITSET(pGPIO->GPCEN, Hw28);
	BITCLR(pGPIO->GPCFN3, Hw20-Hw16);
	
	//LCD_BL_EN
	BITCLR(pGPIO->GPADAT, Hw7);		//Backlight Off: GPIO mode
	BITSET(pGPIO->GPAEN, Hw7);
	BITCLR(pGPIO->GPAFN0, Hw32-Hw28);

	BITCLR(pGPIO->GPCFN0, 0xFFFFFFFF);
	BITCLR(pGPIO->GPCFN1, 0xFFFFFFFF);
	BITCLR(pGPIO->GPCFN2, 0xFFFFFFFF);
	BITCLR(pGPIO->GPCFN3, (Hw16-Hw0));

	//LCD_DISP
	BITSET(pGPIO->GPCDAT, Hw28);	//DISP On
//	BITSET(pGPIO->GPCCD0, 0x55555555);
//	BITSET(pGPIO->GPCCD1, 0x55555555);

	if (lcdc_idx == 0)
	{
		//LCDC0 RGB Interface
		BITSET(pGPIO->GPCFN0, 0x22222222);
		BITSET(pGPIO->GPCFN1, 0x22222222);
		BITSET(pGPIO->GPCFN2, 0x22222222);
		BITCSET(pGPIO->GPCFN3, (Hw16-Hw0), 0x2222);
	}
	else
	{
		//LCDC1 RGB Interface
		BITSET(pGPIO->GPCFN0, 0x55555555);
		BITSET(pGPIO->GPCFN1, 0x55555555);
		BITSET(pGPIO->GPCFN2, 0x55555555);
		BITCSET(pGPIO->GPCFN3, (Hw16-Hw0), 0x5555);
	}
}

void lcd_init(int lcdc_idx, lcd_cfg_t *cfg, unsigned int phy_dispaddr, int islvds, int enable)
{
	PDDICONFIG	pDDICfg			= (DDICONFIG *)&HwDDI_CONFIG_BASE;
//	PDDICACHE	pDDICache		= (DDICACHE *)&HwDDI_CACHE_BASE;
	PLCDC		pLCDC_BASE[2]	= {(LCDC *)&HwLCDC0_BASE,
								   (LCDC *)&HwLCDC1_BASE};

	PGPIO		pGPIO 			= (GPIO *)&HwGPIO_BASE;

	PLCDC		pLCDC;
	PLCDC_IMG	pIMG;

//	LCDC Init.
	if	(lcdc_idx == 0)
	{
		pLCDC = pLCDC_BASE[0];
		
	//	LCDC0 Power Down disable
		BITCLR(pDDICfg->PWDN, Hw2);

	//	LCDC1, LCDC0 SW Reset
		BITSET(pDDICfg->SWRESET, Hw2);
		BITCLR(pDDICfg->SWRESET, Hw2);
	}
	else
	{
		pLCDC = pLCDC_BASE[1];
		
	//	LCDC1 Power Down disable
		BITCLR(pDDICfg->PWDN, Hw3);

	//	LCDC1, LCDC0 SW Reset
		BITSET(pDDICfg->SWRESET, Hw3);
		BITCLR(pDDICfg->SWRESET, Hw3);
	}

	//	Power and Reset Control H/W Init.
	if (islvds == 0)
		lcd_interface_init(lcdc_idx);


//	Set LCD controller
	pLCDC->LCTRL = (
	//			Hw31|			// EVP[31] - External VSYNC Polarity	(0: Direct Input, 1: Inverted Input)
	//			Hw30|			// EVS[30] - External VSYNC Enable		(0: Disabled, 1: Enabled)
				(0<<28)|		// R2YMD[29:28] - RGB to YCbCr Conversion Option (type0)
	//			(1<<28)|		// 												 (type1)
	//			(2<<28)|		//												 (type2)
	//			(3<<28)|		//												 (type3)
				(0<<26)|		// LUT[27:26] - LUT Option Bits	(Not used)
	//			(1<<26)|		// 								(Used for Image 0)
	//			(2<<26)|		//								(Used for Image 0)
	//			(3<<26)|		//								(Used for Image 0)
	//			Hw25|			// GEN[25] - Gamma Corection Enable Bit (0: Disabled, 1: Enabled)
	//			Hw24|			// 656[24] - CCIR 656 Mode (0: Disabled, 1: Enabled)
	//			Hw23|			// CKG[23] - Clock Gating Enable for Timing Generator
	//			Hw22|Hw21|Hw20| // BPP[22:20] - Bit Per Pixel for STN-LCD
				(cfg->pwdx<<16)|		//PXDW[19:16] - C : 24Bit(888) Hw19(1)|Hw18(1)|Hw17(0)|Hw16(0)|
										//PXDW[19:16] - 5 : 18Bit(666) Hw19(0)|Hw18(1)|Hw17(0)|Hw16(1)|
	//			Hw15|			// Inverted Data Enable (ACBIAS pin)
				Hw14|			// Inverted Vertical Sync
				Hw13|			// Inverted Horizontal Sync
	//			Hw12|			// Inverted Pixel Clock
	//			Hw11|			// Clipping Enable
	//			Hw10|			// RGB to YCbCr Converter Enable for OUTPUT
	//			Hw9 |			// Double Pixel Data
				Hw8 |			// Non-interlace
				(0x2<<5)|		// TFT-LCD mode: STN(Hw5), TFT(Hw6), TV(Hw7)
	//			Hw4 |			// Master Select for IMG0
				(0x5<<1)|		// OVP[3:1] - 5 : Image2 > Image1 > Image0
	//			Hw0 |			// LCD Controller Enable
				0); 			// End Of Value

// Set LCD clock
	pLCDC->LCLKDIV &= 0xFF00FF00;
	pLCDC->LCLKDIV |= ( (1 << 16) | cfg->devide); //((PCK_LCD+1)/2)/((LCD_DEVIDE)*2)

// Background color
//	pLCDC->LBC = 0x80FFFFFF;
	pLCDC->LBC = 0x80202020;

//  Horizontal timing
    pLCDC->LHTIME1 = ((cfg->hpw-1) << 16) | (cfg->res_width - 1);
    pLCDC->LHTIME2 = ((cfg->hbp-1) << 16) | (cfg->hfp-1);

//  Vertical timing
    pLCDC->LVTIME1 = ((cfg->vpw-1) << 16) | (cfg->res_height - 1);
    pLCDC->LVTIME2 = ((cfg->vbp-1) << 16) | (cfg->vfp-1);
    pLCDC->LVTIME3 = ((cfg->vpw-1) << 16) | (cfg->res_height - 1);
    pLCDC->LVTIME4 = ((cfg->vbp-1) << 16) | (cfg->vfp-1);

//	Display Size
	pLCDC->LDS = (cfg->res_height << 16) | cfg->res_width;

//	Interrupt mask
	pLCDC->LIM &= 0xFFFFFFE6;
	pLCDC->LIM |= ((1 << 4) | 1);

	if (lcdc_idx == 0)
	{
	//	LCD Image 0 Control Register
		pIMG = (LCDC_IMG *)&pLCDC->LI0C;
	}
	else
	{
		#if (1)
		if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType == 2)
		{
		//	LCD Image 0 Control Register
			BITCSET (pLCDC->LI1C, Hw28, (0) << 28); // Disable Image

		//	LCD Image 2 Control Register
			BITCSET (pLCDC->LI2C, Hw28, (0) << 28); // Disable Image

		//	LCD Image 1 Control Register
			pIMG = (LCDC_IMG *)&pLCDC->LI0C;

		}
		else
		#endif
		{
		//	LCD Image 0 Control Register
			BITCSET (pLCDC->LI0C, Hw28, (0) << 28); // Disable Image

		//	LCD Image 2 Control Register
			BITCSET (pLCDC->LI2C, Hw28, (0) << 28); // Disable Image

		//	LCD Image 1 Control Register
			pIMG = (LCDC_IMG *)&pLCDC->LI1C;
		}
	}

//	LCD Image X Control Register

	BITCSET (pIMG->LIxBA0, 0xffffffff, 0 + phy_dispaddr); // base address
	BITCSET (pIMG->LIxO, 0xffff << 0, (DISP_WIDTH*DISP_BYTESPERPIXEL) << 0); // address offset (RGB or Y)
	BITCSET (pIMG->LIxO, 0xffff <<16, (0) <<16); // address offset (Cb or Cr)

	BITCSET (pIMG->LIxC, 0x1<< 31,    (0)  << 31); // DMA interlace mode
	BITCSET (pIMG->LIxC, 0x1<< 30,    (0)  << 30); // alpha enable
	BITCSET (pIMG->LIxC, 0x1<< 29,    (0)  << 29); // chroma-keying
	BITCSET (pIMG->LIxC, 0x3<< 25,    (2)  << 25); // alpha opt
	BITCSET (pIMG->LIxC, 0x1<< 24,    (0)  << 24); // alpha select
	BITCSET (pIMG->LIxC, 0x1<< 15,    (0)  << 15); // padding option
	BITCSET (pIMG->LIxC, 0x3<<  9,    (1)  <<  9); // y2r converter mode
	BITCSET (pIMG->LIxC, 0x1<<  8,    (0)  <<  8); // y2r converter enable
	BITCSET (pIMG->LIxC, 0x1<<  7,    (0)  <<  7); // bit-reverse
#if defined(DISP_SRC_32BPP)
	BITCSET (pIMG->LIxC, 0x1f<< 0,    (12) <<  0); // format	// RGB888
#else
	BITCSET (pIMG->LIxC, 0x1f<< 0,    (10) <<  0); // format	// RGB565
#endif
	BITCSET (pIMG->LIxP, 0xffff<< 16, (0)  << 16); // position y
	BITCSET (pIMG->LIxP, 0xffff<<  0, (0)  <<  0); // position x
	BITCSET (pIMG->LIxS, 0xffff<< 16, (DISP_HEIGHT) << 16); // height
	BITCSET (pIMG->LIxS, 0xffff<<  0, (DISP_WIDTH) <<  0); // width
	BITCSET (pIMG->LIxSR , 0xf <<0,   (0)  <<  0); // x_scale
	BITCSET (pIMG->LIxSR , 0xf <<4,   (0)  <<  4); // y_scale
	BITCSET (pIMG->LIxA, 0xffff<<16,  (95)<< 16); // alpha1
	BITCSET (pIMG->LIxA, 0xffff<< 0,  (95)<<  0); // alpha0
	BITCSET (pIMG->LIxKR, 0xff <<  0, (0)  <<  0); // key
	BITCSET (pIMG->LIxKR, 0xff << 16, (0)  << 16); // keymask
	BITCSET (pIMG->LIxKG, 0xff <<  0, (0)  <<  0); // key
	BITCSET (pIMG->LIxKG, 0xff << 16, (0)  << 16); // keymask
	BITCSET (pIMG->LIxKB, 0xff <<  0, (0)  <<  0); // key
	BITCSET (pIMG->LIxKB, 0xff << 16, (0)  << 16); // keymask
	BITCSET (pIMG->LIxEN, 0xff << 0,  (32) <<  0); // contrast  
	BITCSET (pIMG->LIxEN, 0xff << 8,  (0)  <<  8); // brightness
	BITCSET (pIMG->LIxEN, 0xff <<16,  (0)  << 16); // hue       
    BITCSET (pIMG->LIxC, 0x1<<28,     (1)  << 28); // Enable Image

//	LVDS Init.
	if (islvds == 1)
	{
		//	LVDS Select
		if	(lcdc_idx == 0)
			BITCLR(pDDICfg->LVDS_CTRL, Hw0); //LCDC0
		else
			BITSET(pDDICfg->LVDS_CTRL, Hw0); //LCDC1

		pDDICfg->LVDS_TXO_SEL0 = 0x15141312; // SEL_03, SEL_02, SEL_01, SEL_00,
		pDDICfg->LVDS_TXO_SEL1 = 0x0B0A1716; // SEL_07, SEL_06, SEL_05, SEL_04,
		pDDICfg->LVDS_TXO_SEL2 = 0x0F0E0D0C; // SEL_11, SEL_10, SEL_09, SEL_08,
		pDDICfg->LVDS_TXO_SEL3 = 0x05040302; // SEL_15, SEL_14, SEL_13, SEL_12,
		pDDICfg->LVDS_TXO_SEL4 = 0x1A190706; // SEL_19, SEL_18, SEL_17, SEL_16,
		pDDICfg->LVDS_TXO_SEL5 = 0x1F1E1F18; //                         SEL_20,
		pDDICfg->LVDS_TXO_SEL6 = 0x1F1E1F1E;
		pDDICfg->LVDS_TXO_SEL7 = 0x1F1E1F1E;
		pDDICfg->LVDS_TXO_SEL8 = 0x1F1E1F1E;

	    // lvds reset
	    BITSET(pDDICfg->LVDS_CTRL, Hw1);    // reset
	    BITCLR(pDDICfg->LVDS_CTRL, Hw1);    // normal

	    // lvds enable
	    BITSET(pDDICfg->LVDS_CTRL, Hw2);    // enable
		
	}


	if (enable)
	{
	//	Enable LCDC
		BITSET(pLCDC->LCTRL, Hw0);
	}


//	BITCLR(pDDICfg->HDMI_CTRL, Hw15);	// hdmi - lcdc0
	BITSET(pDDICfg->HDMI_CTRL, Hw15);	// hdmi - lcdc1

}

void lcd_disp_on(int islvds)
{
	PGPIO	pGPIO 	= (GPIO *)&HwGPIO_BASE;
	PTIMER	pTIMER	= (TIMER *)&HwTMR_BASE;

	if (islvds == 0)
	{
	//	LCD_DISP On
		BITSET(pGPIO->GPCDAT, Hw28);

	//	LCD_BL_EN(Backlight) On
		if (0)
		{	//TCO0(PWM) mode
			pTIMER->TCFG0 = 0x124;
			pTIMER->TREF0 = 50;
			pTIMER->TMREF0= 50;
			pTIMER->TCFG0 = 0x125;

			BITCSET(pGPIO->GPAFN0, Hw32-Hw28, 2<<28);
		}
		else
		{	//GPIO mode
			BITSET(pGPIO->GPADAT, Hw7);
		}
	}
	else
	{
		// todo.

	}
}

void lcd_setclock(int lcdc_id, lcd_cfg_t *pLcdCfg)
{
	PLCDC	pLCDC_BASE[2]   = {(LCDC *)&HwLCDC0_BASE,
							   (LCDC *)&HwLCDC1_BASE};
	PLCDC	pLCDC;

	unsigned int dst_lclk;
	unsigned int dst_pxclk;
	unsigned int dst_freq;

	unsigned int v_total;
	unsigned int h_total;

	unsigned int pxclkdiv;
	unsigned int div;

	unsigned int src_pll;
	
	unsigned int ret_lclk;
	unsigned int ret_pxclk;
	unsigned int ret_freq_dHz;

	unsigned int tmp_h_total;
	unsigned int tmp_freq_dHz;
	unsigned int tmp_hbp, tmp_hfp;
	unsigned int bak_src_pll, bak_diff_tmp, bak_hbp, bak_hfp, bak_h_total;
	unsigned int bak_lclk;
	unsigned int flag_opt_timming;
	unsigned int diff_h_total;
	
	unsigned int diff_cur, diff_tmp;
	int i;

	pLCDC = pLCDC_BASE[lcdc_id];

	v_total = pLcdCfg->vpw + pLcdCfg->vbp + pLcdCfg->res_height + pLcdCfg->vfp;
	h_total = pLcdCfg->hpw + pLcdCfg->hbp + pLcdCfg->res_width + pLcdCfg->hfp;
	dst_freq = pLcdCfg->freq;
	
	pxclkdiv = pLcdCfg->devide;
	div = pxclkdiv?pxclkdiv*2:1;
	
	dst_pxclk = (h_total*v_total*(dst_freq))/100;
	dst_lclk = dst_pxclk*div;

	DPRINTF("\n");
	DPRINTF("--------------------------------------------------------------\n");
	DPRINTF("[LCDC%d       ] (LCLK %d) (PXCLK %d) (%dHz)\r\n", lcdc_id, dst_lclk, dst_lclk/div, dst_freq);

	src_pll  = PCDIRECTPLL0;
	diff_tmp = dst_lclk*2;

	flag_opt_timming = 0;
	bak_h_total = 0;

	for(i=PCDIRECTPLL0; i<=PCDIRECTPLL3; i++)
	{
		tca_ckc_setperi(PERI_LCD0+lcdc_id,ENABLE,dst_lclk,i);
		ret_lclk = tca_ckc_getperi(PERI_LCD0+lcdc_id);

		diff_cur = (ret_lclk>dst_lclk)?(ret_lclk-dst_lclk):(dst_lclk-ret_lclk);

		if(diff_cur <= diff_tmp)
		{
			src_pll = i;
			diff_tmp = diff_cur;
		}

		ret_pxclk = ret_lclk/div;

		DPRINTF("(Check PLL%d) - (LCLK %d) (PXCLK %d)", i, ret_lclk, ret_pxclk);
		ret_freq_dHz = ((ret_pxclk*10)*100)/(h_total*v_total);

		#if (1)	// auto timming setting.
		{
			tmp_h_total = (ret_pxclk*100)/(v_total*dst_freq);
			tmp_freq_dHz = ((ret_pxclk*10)*100)/(tmp_h_total*v_total);

			if (tmp_h_total > (pLcdCfg->res_width+pLcdCfg->hpw + 2))
			{
				#if 0
				// modify HBP, HFP
				tmp_hbp = (tmp_h_total - (pLcdCfg->hpw + pLcdCfg->res_width))>>1;
				tmp_hfp = (tmp_h_total - (pLcdCfg->hpw + pLcdCfg->res_width))-tmp_hbp;
				#else
				// modify only HFP
				tmp_hbp = pLcdCfg->hbp;
				tmp_hfp = (tmp_h_total - (pLcdCfg->hpw + pLcdCfg->res_width))-tmp_hbp;
				#endif

				DPRINTF( " -> H_TOTAL(%d%c%d->%d[hbp:%d,hfp:%d])->%d.%dHz ", //\r\n", 
					h_total,
					(tmp_h_total>=h_total)?'+':'-', 
					(tmp_h_total>=h_total)?tmp_h_total-h_total:h_total-tmp_h_total,
					tmp_h_total,
					tmp_hbp,
					tmp_hfp,
					tmp_freq_dHz/10, 
					tmp_freq_dHz%10);

				if ((tmp_hbp < 1) || (tmp_hfp < 1) || (tmp_hbp > 512) || (tmp_hfp > 512))
					continue;

				if ((bak_h_total == 0)
				|| (((bak_h_total>h_total)?(bak_h_total-h_total):(h_total-bak_h_total)) > ((tmp_h_total>h_total)?(tmp_h_total-h_total):(h_total-tmp_h_total))))
				{
					bak_hbp = tmp_hbp;
					bak_hfp = tmp_hfp;
					bak_h_total = tmp_h_total;
					bak_src_pll = i;
					bak_lclk = ret_lclk;
				}

				flag_opt_timming = 1;
			}
		}
		#endif

		DPRINTF("\r\n");
	}
	
	tca_ckc_setperi(PERI_LCD0+lcdc_id,ENABLE,dst_lclk,src_pll);
	ret_lclk = tca_ckc_getperi(PERI_LCD0+lcdc_id);
	ret_pxclk = ret_lclk/div;
	ret_freq_dHz = ((ret_pxclk*10)*100)/(h_total*v_total);
	DPRINTF( "            -> [LCLK %d] [PXCLK %d] (%d.%dHz) - (PLL%d)\r\n", ret_lclk, ret_pxclk, ret_freq_dHz/10, ret_freq_dHz%10, src_pll);

	if ((ret_freq_dHz != (pLcdCfg->freq*10)) && flag_opt_timming)
	{

		DPRINTF( "            !! Change Timming: HBP(%d)HFP(%d) -> HBP(%d)HFP(%d)\r\n",
			pLcdCfg->hbp, pLcdCfg->hfp,	bak_hbp, bak_hfp);

		pLcdCfg->hbp = bak_hbp;
		pLcdCfg->hfp = bak_hfp;
		src_pll = bak_src_pll;

		v_total = pLcdCfg->vpw + pLcdCfg->vbp + pLcdCfg->res_height + pLcdCfg->vfp;
		h_total = pLcdCfg->hpw + pLcdCfg->hbp + pLcdCfg->res_width + pLcdCfg->hfp;
		dst_freq = pLcdCfg->freq;
		
		pxclkdiv = pLcdCfg->devide;
		div = pxclkdiv?pxclkdiv*2:1;
		
		dst_pxclk = (h_total*v_total*(dst_freq))/100;
		dst_lclk = dst_pxclk*div;

		tca_ckc_setperi(PERI_LCD0+lcdc_id,ENABLE,dst_lclk,src_pll);
		ret_lclk = tca_ckc_getperi(PERI_LCD0+lcdc_id);
		ret_pxclk = ret_lclk/div;
		ret_freq_dHz = ((ret_pxclk*10)*100)/(h_total*v_total);
		DPRINTF( "            -> [LCLK %d] [PXCLK %d] (%d.%dHz) - (PLL%d)\r\n", ret_lclk, ret_pxclk, ret_freq_dHz/10, ret_freq_dHz%10, src_pll);
	}
	DPRINTF("--------------------------------------------------------------\n");
	DPRINTF("\n");
	
	pLCDC->LCLKDIV = div/2;
}

void init_disp(int flag)
{
	enum {
		VAL_LCDIF_RGB	= 0,
		VAL_LCDIF_LVDS	= 1,
	};

	ptSYSTEM_PARAM sysparam = (ptSYSTEM_PARAM)SYSTEM_PARAM_BASEADDRESS;

	int lcdc_idx=0;

	int ret_lclk;
	int src;
	int cfgidx=0;

//  LCD Information Setting for DISPLAY Driver
	gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nWidth = DISP_WIDTH;
	gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nHeight = DISP_HEIGHT;
	gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nMode = DISP_BYTESPERPIXEL;
	gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdcIdxForUI = 1;

#if defined(ROADSHOW_DEMO_TYPE1)
	gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType = 1;
#else
	gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType = 0;
#endif

#if defined(USE_LVDSLCD)
 #if defined(LVDS_CLAA104XA01CW_10_4_1024X768)
	cfgidx = 1;
 #elif defined(LVDS_HT121WX2_103_12_1_1280X800)
	cfgidx = 2;
 #endif
#else
	cfgidx = 0;
#endif

	gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx = cfgidx;

	if (flag)
	{
		#if 1
		// TVOUT pwdn
		{
			#define	HwTVECMDA	*(volatile unsigned long *)(((unsigned long)&HwTVE_BASE) + 0x4)//0xF0240004	// R/W, Encoder Mode Control Register A
			#define	HwTVEDACPD	*(volatile unsigned long *)(((unsigned long)&HwTVE_BASE) + 0x50)//0xF0240050	// R/W, DAC Power Down
			#define	HwTVEVENCON	*(volatile unsigned long *)(((unsigned long)&HwTVE_BASE) + 0x800)//0xF0240800	// R/W, Connection between LCDC & TVEncoder Control
			#define	HwTVECMDA_PWDENC_PD		Hw7		// Power down mode for entire digital logic of TV encoder
			
			HwTVEVENCON  = 0;
			HwTVEDACPD   = 1; 						// Power Down
			HwTVECMDA   |= (HwTVECMDA_PWDENC_PD);	// Power Down
		}
		#endif

	//	Boot logo
	if((*(volatile unsigned long *)(SUS_DRAM_VALID1_PADDR) != PWRCTL_DRAMMASK1) && (*(volatile unsigned long *)(SUS_DRAM_VALID2_PADDR) != PWRCTL_DRAMMASK2))
		init_logo();				// Boot Screen Image

	//	Display Device Initialize.
	#if defined(USE_LVDSLCD)

		{ PPMU lPMU = (PMU *)&HwPMU_BASE;
		  lPMU->PWROFF &= ~Hw2; /*LVDS*/ };

	#if defined(DEMO_TYPE2)

		gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType = 2;
		gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdcIdxForUI = 0;

		// LVDS - LCDC1
		lcdc_idx = 1;

		lcd_setclock(lcdc_idx, &lcd_cfg[cfgidx]);
		lcd_init(lcdc_idx, &lcd_cfg[cfgidx], DISP_BOOTIMG0_BASE_ADDR, VAL_LCDIF_LVDS, 1);
	//	lcd_disp_on(VAL_LCDIF_LVDS);

		#if (0)
		if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType == 2)
		{
			PLCDC pLCDC = (LCDC *)&HwLCDC1_BASE;
			BITCSET(pLCDC->LCTRL, Hw4-Hw1, (0x3)<<1);		// OVP[3:1] - 3 : Image2 > Image0 > Image1
		}
		#endif

		// LCD - LCDC0
		lcdc_idx = 0;

		lcd_setclock(lcdc_idx, &lcd_cfg[0]);
		lcd_init(lcdc_idx, &lcd_cfg[0], DISP_BOOTIMG0_BASE_ADDR, VAL_LCDIF_RGB, 1);
		lcd_disp_on(VAL_LCDIF_RGB);

	#else	// #if defined(DEMO_TYPE2)

		if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType == 1)
		{
			lcdc_idx = 0;

			lcd_setclock(lcdc_idx, &lcd_cfg[cfgidx]);
			lcd_init(lcdc_idx, &lcd_cfg[cfgidx], DISP_BOOTIMG0_BASE_ADDR, VAL_LCDIF_LVDS, 0);
			lcd_disp_on(VAL_LCDIF_LVDS);
		}

		lcdc_idx = 1;

		lcd_setclock(lcdc_idx, &lcd_cfg[cfgidx]);
		lcd_init(lcdc_idx, &lcd_cfg[cfgidx], DISP_BOOTIMG0_BASE_ADDR, VAL_LCDIF_LVDS, 1);
		lcd_disp_on(VAL_LCDIF_LVDS);

	#endif	// #if defined(DEMO_TYPE2)

	#else

		if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType == 1)
		{
			lcdc_idx = 0;

			lcd_setclock(lcdc_idx, &lcd_cfg[0]);
			lcd_init(lcdc_idx, &lcd_cfg[0], DISP_BOOTIMG0_BASE_ADDR, VAL_LCDIF_RGB, 0);
			lcd_disp_on(VAL_LCDIF_RGB);
		}

		lcdc_idx = 1;

		lcd_setclock(lcdc_idx, &lcd_cfg[0]);
		lcd_init(lcdc_idx, &lcd_cfg[0], DISP_BOOTIMG0_BASE_ADDR, VAL_LCDIF_RGB, 1);
		lcd_disp_on(VAL_LCDIF_RGB);

	#endif	//#if defined(USE_LVDSLCD)

		ddic_setdefault();
	}
}

int BootLogoImageChange()
{
#if defined(NAND_INCLUDE)
	unsigned char BootLogoInfo[512];
	unsigned char TmpBuff[512];
	unsigned int StartImgSecNum = 0, LogoBinSecNum = 0;
	unsigned int SpareSize = 0, LogoSecNum = 0;
	char *LcdBuff = (char *)DISP_BOOTIMG0_BASE_ADDR;

//	KITLOutputDebugString("[TCBOOT      ] BootLogo Loading\n");

	memset(BootLogoInfo, 0, 512);
	
	if(NAND_HDReadSector(0, 0, 1, BootLogoInfo) < 0)
	{
		KITLOutputDebugString("[TCBOOT      ] Multi Hidden area doesn't exist for BootLogo...\n");
		goto BOOTLOGOLODINGERROR;
	}

	if(TELECHIPS_LOGO_BUFF_SIZE%512 == 0)
		LogoBinSecNum = TELECHIPS_LOGO_BUFF_SIZE / 512;
	else
		LogoBinSecNum = (TELECHIPS_LOGO_BUFF_SIZE / 512) + 1;

	if(BootLogoInfo[0] == 0xF0)
		StartImgSecNum = 1;
	else if(BootLogoInfo[0] == 0xF1)
		StartImgSecNum = LogoBinSecNum + 1;
	else
		goto BOOTLOGOLODINGERROR;

	KITLOutputDebugString("[TCBOOT      ] BootLogo addr %d, Logo SecNum: %d, Logo info: 0x%x...\n", StartImgSecNum, LogoBinSecNum, BootLogoInfo[0]);

	SpareSize = TELECHIPS_LOGO_BUFF_SIZE % 512;
	LogoSecNum = TELECHIPS_LOGO_BUFF_SIZE / 512; 
	
	if(SpareSize == 0)
		NAND_HDReadSector(0, StartImgSecNum, LogoSecNum, LcdBuff);
	else
	{
		
		NAND_HDReadSector(0, StartImgSecNum, LogoSecNum, LcdBuff);

		NAND_HDReadSector(0, StartImgSecNum + LogoSecNum, 1, TmpBuff);

		memcpy(&LcdBuff[LogoSecNum*512], TmpBuff, SpareSize);
	}

	BootLogoFromNandFlag = 1;
#endif	
	init_disp(1);
	return TRUE;
BOOTLOGOLODINGERROR:
	BootLogoFromNandFlag = 0;
	init_disp(1);
	return FALSE;
}

/************* end of file *************************************************************/
