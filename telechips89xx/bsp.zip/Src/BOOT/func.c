#include "TCC89x_Physical.h"
#include "func.h"
#include "i2c.h"
#include "tcc_gpioexp.h"
#include "bsp.h"

/************************************************************************************************
*                                        DEFINE                                                 *
************************************************************************************************/

/************************************************************************************************
*  Extern.
************************************************************************************************/
extern void loadkernel(void);

/************************************************************************************************
* FUNCTION		: void args_func(void)
* DESCRIPTION	: 
************************************************************************************************/
void init_args(void)
{
	//BootArgs address setting & memset

	// For KITL
	// Ready to send info to "nk.exe"

	// Read ChipID

}

/************************************************************************************************
* FUNCTION		: void init_i2c(void)
* DESCRIPTION	: To enable I2C Block
************************************************************************************************/
void	init_i2c(void)
{
	I2C_Reset();
	I2C_GpioSetting();
	I2C_Initialize();
	}

/************************************************************************************************
* FUNCTION		: void	ExpandGPIO(unsigned char DevID, unsigned short Param)
* DESCRIPTION	: To enable External Peri Power Control
************************************************************************************************/
void	ExpandGPIO(unsigned char DevID, unsigned short Param)
	{
        int ByteCnt, CmdReg, DataReg;	    
	//Command, PORT0, PORT1
	unsigned char		i2cCfgData[3];
	unsigned char		i2cOutData[3];

        switch( DevID)
        {
            case PCA9539HIGH:
                i2cCfgData[0] = CMD_PORT0_CONFIG;
                i2cCfgData[1] = PCA9539H_P0CFG;
                i2cCfgData[2] = PCA9539H_P1CFG;
                DataReg = CMD_PORT0_OUTPUT;
                ByteCnt = 3;
                break;
                
            case PCA9539LOW:
                i2cCfgData[0] = CMD_PORT0_CONFIG;
                i2cCfgData[1] = PCA9539L_P0CFG;
                i2cCfgData[2] = PCA9539L_P1CFG;
                DataReg = CMD_PORT0_OUTPUT;
                ByteCnt = 3;    
                break;
            
            case PCA9538:
                i2cCfgData[0] = CMD_PORT_CONFIG;
                i2cCfgData[1] = PCA9538_PCFG;
                DataReg = CMD_PORT_OUTPUT;
                ByteCnt = 2;
                break;
        }
	

	i2cOutData[0] = DataReg;//{2,0x06,0x80}; // OutReg, (1.2) High, (8) High
	i2cOutData[1] = (Param&0x00FF);
	i2cOutData[2] = (Param&0xFF00)>>8;

	I2C_Write( DevID, ByteCnt, i2cCfgData);
	I2C_Write( DevID, ByteCnt, i2cOutData);       
}


/************************************************************************************************
* FUNCTION		: void init_gpioexpander(void)
* DESCRIPTION	: To enable I2C Block
************************************************************************************************/
void	init_gpioexpander(void)
{
	#include "lcd.h"


//Refer to TCC89x Schematics
#if defined(USE_LVDSLCD)
	#ifndef _IMGNOKITL_
		ExpandGPIO(PCA9539LOW, 0x00
		#if defined(DEMO_TYPE2)
					|LCD
		#endif
					|CODEC|LVDSIVT|LVDSLPCTRL|ETH); // PCA9539_U3 : Device Power ON, Others are OFF (Supported Eth_KITL)
	#else
		ExpandGPIO(PCA9539LOW, 0x00
		#if defined(DEMO_TYPE2)
					|LCD
		#endif
					|CODEC|LVDSIVT|LVDSLPCTRL); // PCA9539_U3 : Device Power ON, Others are OFF
	#endif
#else
	#ifndef _IMGNOKITL_
		ExpandGPIO(PCA9539LOW, 0x00|LCD|CODEC|ETH);	// PCA9539_U3 : Device Power ON, Others are OFF (Supported Eth_KITL)
	#else
		ExpandGPIO(PCA9539LOW, 0x00|LCD|CODEC); // PCA9539_U3 : Device Power ON, Others are OFF
	#endif
#endif

	ExpandGPIO(PCA9539HIGH, 0x00); // PCA9539_U2 : Initialize Signal Reset En/Disable State
#if defined(USE_LVDSLCD)
	// SATAHDMI --> HDMI_LVDS_ON
	ExpandGPIO(PCA9538, 0x00|SATAHDMI); // PCA9538_U4 : Device Power ON, Others are OFF
#else
    ExpandGPIO(PCA9538, 0x00); // PCA9538_U4 : Device Power ON, Others are OFF
#endif
}

/************************************************************************************************
* FUNCTION		: void shellmenu_func(void)
* DESCRIPTION	: 
************************************************************************************************/
void shellmenu_func(void)
{
    unsigned char KeySelect = 0;
    unsigned int bConfigChanged = FALSE;
    unsigned int bDownload = TRUE;
	
    while(1)
    {
        KeySelect = 0;
		
        //EdbgOutputDebugString( "\r\n**Telechips Windows CE Ethernet Boot Loader Configuration:**\r\n");
		// TO DO Menu Print
		//EdbgOutputDebugString( "---------------------------------------------------------\n");
        //EdbgOutputDebugString ( "Enter your selection: ");
		
        while (! ( ( (KeySelect >= '0') && (KeySelect <= '9') ) ||
			( (KeySelect == 'K') || (KeySelect == 'k') ) ||
			( (KeySelect == 'E') || (KeySelect == 'e') ) ||
			( (KeySelect == 'L') || (KeySelect == 'l') ) ||
			( (KeySelect == 'W') || (KeySelect == 'w') ) ||
			( (KeySelect == 'X') || (KeySelect == 'x') ) ))
			
        {
		//	EdbgOutputDebugString ( " ");	
		//	OEMWriteDebugByte((unsigned char)0x08);
		//	KeySelect = OEMReadDebugByte();  // Ű�Է��� �޴´�.
        }
		
        //EdbgOutputDebugString ( "%c\n", KeySelect);
        switch(KeySelect)
        {
        case '0':           // Change IP address.
            bConfigChanged = TRUE;
            break;
        case '1':           // Change subnet mask.
            bConfigChanged = TRUE;
            break;
        case '2':           // Toggle static/DHCP mode.
            bConfigChanged = TRUE;
            break;
        case '3':           // Configure Crystal CS8900 MAC address.
            bConfigChanged = TRUE;
            break;
        case '4':           // Change autoboot delay.
            bConfigChanged = TRUE;
            break;
		case '5':           // Run ConnectToFWDN.
            bConfigChanged = TRUE;
            break;
        case 'k':			// Toggle KITL disable/active mode.
        case 'K':
            bConfigChanged = TRUE;
            break;
        case 'W':           // Configuration Write
        case 'w':
			//	SaveParamToNand(gpBOOTARGS);
            break;

		case 'L':			// OS Launch
		case 'l':
			//loadkernel();
		default:
			break;
		}
	}

}

/************************************************************************************************
* FUNCTION		: void kitlmenu_func(void) 
* DESCRIPTION	: 
************************************************************************************************/
void kitlmenu_func(void) 
{
	/*
    unsigned char KeySelect;
	unsigned int count = 0;
	unsigned int nVerMajor = 0;
	unsigned int nVerMinor = 0;
	unsigned int nVerPatch = 0;	

	EdbgOutputDebugString("*************************************************************\n");
	EdbgOutputDebugString("TcBoot Ver %d.%d Patch %d for Telechips Windows CE 5.0\r\n",nVerMajor, nVerMinor, nVerPatch);
	EdbgOutputDebugString("DATE:"__DATE__ ", TIME:" __TIME__ "\r\n");
	EdbgOutputDebugString("Telechips Inc.\r\n");
	EdbgOutputDebugString("*************************************************************\n");
    EdbgOutputDebugString("Press [ENTER] or [SPACE] to enter boot monitor.\r\n");
    EdbgOutputDebugString("\r\nInitiating image download : %d\n",count);

	while( count-- > 0 )
	{
		KeySelect=OEMReadDebugByte();
		if ((KeySelect == 0x20) || (KeySelect == 0x0d))
		{
			shellmenu_func(); // Call ShellMenu()
			break;
		}
	
		OEMWriteDebugByte((unsigned char)0x08); //print back space
		EdbgOutputDebugString("%d", count);
//		Delay(10000000);
	}
	EdbgOutputDebugString("\n");
	

#ifdef FWDN_INCLUDE
    EdbgOutputDebugString("FWDN: checking...\n");
 //   FWDN_Check();
#endif
*/
}

/****************************************************************************
*  Function:  OEMGetRealTime
*  Reads the current RTC value and returns a system time.
****************************************************************************/
	
BOOL OEMGetRealTime(SYSTEMTIME *pTime)
{
	rtctime lpTime;

	BOOL lret = TRUE;
	PRTC pRTC = (PRTC)((unsigned int)&HwRTC_BASE);

	if (pTime == NULL) 
	{
		lret = FALSE;
		goto cleanUp;
	}

	tcc_rtc_gettime((unsigned int)pRTC,&lpTime);

	pTime->wSecond		=	lpTime.wSecond;
	pTime->wMinute		=	lpTime.wMinute;
	pTime->wHour		=	lpTime.wHour;
	pTime->wDayOfWeek	=	lpTime.wDayOfWeek;
	pTime->wDay 		=	lpTime.wDay;
	pTime->wMonth		=	lpTime.wMonth;
	pTime->wYear		=	lpTime.wYear;
	pTime->wMilliseconds = 0;

	cleanUp:
		return lret;
}
/*
    @func   DWORD | OEMEthGetSecs | Returns a free-running seconds count.
    @rdesc  Number of elapsed seconds since last roll-over.
    @comm
    @xref
*/
DWORD OEMEthGetSecs(void)
{
	SYSTEMTIME sTime;
	OEMGetRealTime(&sTime);
	return((60UL * (60UL * (24UL * (31UL * sTime.wMonth + sTime.wDay) + sTime.wHour) + sTime.wMinute)) + sTime.wSecond);
}

