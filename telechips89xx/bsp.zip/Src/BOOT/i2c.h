/****************************************************************************
 *   FileName    : I2C.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
 #include "TCC89x_Physical.h"
 #define I2C_WR	0
#define I2C_RD	1


#define	HwI2CM_CTRL_EN_ON					Hw7										// Enabled
#define	HwI2CM_CTRL_EN_OFF					HwZERO									// Disabled
#define	HwI2CM_CTRL_IEN_ON					Hw6										// Enabled
#define	HwI2CM_CTRL_IEN_OFF					HwZERO									// Disabled
#define	HwI2CM_CTRL_MOD_16					Hw5										// 16bit Mode
#define	HwI2CM_CTRL_MOD_8					HwZERO									// 8bit Mode
#define	HwI2CM_CMD_STA_EN					Hw7 									// Start Condition Generation Enabled
#define	HwI2CM_CMD_STA_DIS					HwZERO 									// Start Condition Generation Disabled
#define	HwI2CM_CMD_STO_EN					Hw6 									// Stop Condition Generation Enabled
#define	HwI2CM_CMD_STO_DIS					HwZERO 									// Stop Condition Generation Disabled
#define	HwI2CM_CMD_RD_EN					Hw5 									// Read From Slave Enabled
#define	HwI2CM_CMD_RD_DIS					HwZERO 									// Read From Slave Disabled
#define	HwI2CM_CMD_WR_EN					Hw4 									// Wrtie to Slabe Enabled
#define	HwI2CM_CMD_WR_DIS					HwZERO 									// Wrtie to Slabe Disabled
#define	HwI2CM_CMD_ACK_EN					Hw3 									// Sent ACK Enabled
#define	HwI2CM_CMD_ACK_DIS					HwZERO 									// Sent ACK Disalbed
#define	HwI2CM_CMD_IACK_CLR					Hw0 									// Clear a pending interrupt
#define	HwI2CM_SR_RxACK						Hw7										// 1:Acknowledge received, 0:No Acknowledge received
#define	HwI2CM_SR_BUSY						Hw6										// 1:Start signal detected, 0:Stop signal detected
#define	HwI2CM_SR_AL						Hw5										// 1:The core lost arbitration, 0:The core don't lost arbitration
#define	HwI2CM_SR_TIP						Hw1										// 1:Transfer Complete, 0:Transferring Data
#define	HwI2CM_SR_IF						Hw0										// 1:Interrupt is pending
#define	HwI2CM_TR_CKSEL						Hw5										// Clock Source Select

 
extern void I2C_Reset();
extern void I2C_GpioSetting(void);
extern void I2C_Initialize();
extern void I2C_Write(unsigned char DestAddress, unsigned char Count, unsigned char* pBuffer);