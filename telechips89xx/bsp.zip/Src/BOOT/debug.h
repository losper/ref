/****************************************************************************
 *	 FileName	 : debug.c
 *	 Description : 
 ****************************************************************************
*
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
*
 ****************************************************************************/
 
#ifndef __TCC_DEBUG_H__
#define __TCC_DEBUG_H__

#include "bsp.h"

/************************************************************************************************
* FUNCTION		: void OEMInitDebugSerial() 
* DESCRIPTION	: Initializes the debug serial port
************************************************************************************************/
extern void init_serial(void);

/************************************************************************************************
* FUNCTION		: void OEMWriteDebugByte(UINT8 cChar) 
* DESCRIPTION	: Transmits a character out the debug serial port.
************************************************************************************************/
extern void writebyte(unsigned char cChar);

/************************************************************************************************
* FUNCTION		: VOID OEMWriteDebugString(const char *string)
* DESCRIPTION	: 
************************************************************************************************/
extern void writestring(const char *string);

/************************************************************************************************
* FUNCTION		: void OEMWriteDebugData(const char *ccptrString,int length)
* DESCRIPTION	: 
************************************************************************************************/
extern void writedata(const char *ccptrString,int length);

/************************************************************************************************
* FUNCTION		: int OEMReadDebugByte()
* DESCRIPTION	: 
************************************************************************************************/
extern int readbyte(void);

#if !defined(_LINUX_)
void B_RETAILMSG(const char * fmt, ...);
#endif

#endif // __TCC_DEBUG_H__

