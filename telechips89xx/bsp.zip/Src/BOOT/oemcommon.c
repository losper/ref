
#include "bsp.h"
#include <windows.h>
#include <blcommon.h>

extern void BootloaderMainMenu(void);
BOOL BootArgsSetting(void);

extern tSYSTEM_PARAM		*gpBOOTARGS;
extern PSYSTEMPARAM	g_pBootCfg;

BOOL OEMDebugInit(void) 
{
	return TRUE; 
}
//bool OEMVerifyMemory( DWORD dwStartAddr, DWORD dwLength ) { return TRUE; }
void OEMMultiBINNotify(const PMultiBINInfo pInfo) 
{ 
}  
BOOL OEMIsFlashAddr(DWORD dwAddr) 
{ 
	return TRUE; 
}
LPBYTE OEMMapMemAddr(DWORD dwImageStart, DWORD dwAddr) 
{ 
	return NULL; 
}
BOOL OEMStartEraseFlash(DWORD dwStartAddr, DWORD dwLength) 
{ 	
	return TRUE; 
}
void OEMContinueEraseFlash(void) 
{ 
}
BOOL OEMFinishEraseFlash(void) 
{ 	
	return TRUE; 
}
BOOL OEMWriteFlash(DWORD dwStartAddr, DWORD dwLength) 
{ 
	return TRUE; 
}
/************************************************************************************************
* FUNCTION		: BOOL OEMReadData(DWORD dwData, PUCHAR pData)
*
* DESCRIPTION	: Generically read download data (abstracts actual transport read call).
*
************************************************************************************************/
BOOL OEMReadData(DWORD dwData, PUCHAR pData)
{
	
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: int SetKitlMode(int argc, char *argv[])
*
* DESCRIPTION	: 
*
************************************************************************************************/
void OEMShowProgress(DWORD dwPacketNum)
{
}

/************************************************************************************************
* FUNCTION		: void OEMLaunch(DWORD dwImageStart, DWORD dwImageLength, DWORD dwLaunchAddr, const ROMHDR *pRomHdr)
*
* DESCRIPTION	: Launch downloaded/stored image.
*
************************************************************************************************/
void OEMLaunch(DWORD dwImageStart, DWORD dwImageLength, DWORD dwLaunchAddr, const ROMHDR *pRomHdr)
{
	
}


/************************************************************************************************
* FUNCTION		: DWORD OEMPreDownload(void)
*
* DESCRIPTION	: Complete pre-download tasks - get IP address, initialize TFTP, etc.
*
************************************************************************************************/
DWORD OEMPreDownload(void)
{
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL OEMPlatformInit(void) 
*
* DESCRIPTION	: Initialize the TCC78x platform hardware.
*
************************************************************************************************/
BOOL OEMPlatformInit(void) 
{
	ULONG BootDelay;
	UINT8 KeySelect;
	BOOL bResult = FALSE;

	//Argument Value Setting
	BootArgsSetting();

	//BootloaderMain();
	init_disp(0);

	//Jump to Bootloader Main Menu
	BootloaderMainMenu();

	return TRUE;
}
/************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL BootArgsSetting(void)
{
	//BootArgs address setting & memset
	gpBOOTARGS = (tSYSTEM_PARAM *)SYSTEM_PARAM_BASEADDRESS;
//	KITLOutputDebugString("%x",gpBOOTARGS);
	memset(gpBOOTARGS, 0x00, sizeof(tSYSTEM_PARAM));
	memcpy(gpBOOTARGS->SYSTEM_ARGS.mSystemParam.SIGTCBOOT,EBOOT_VERSION_MAJOR,sizeof(EBOOT_VERSION_MAJOR));
	
	// For KITL
	// Ready to send info to "nk.exe"
	gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nSignature		= OAL_ARGS_SIGNATURE;
    gpBOOTARGS->SYSTEM_ARGS.mKitl.nKITLMode				= OAL_KITL_FLAGS_ENABLED | OAL_KITL_FLAGS_VMINI;
	gpBOOTARGS->SYSTEM_ARGS.mKitl.nIPAddr				= 0x0A0A0A0A;
	gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[0]			= 0x1A2B;
	gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[1]			= 0x3C4D;
	gpBOOTARGS->SYSTEM_ARGS.mKitl.chMACAddr[2]			= 0x4EFF;

	gpBOOTARGS->SYSTEM_ARGS.mKitl.nSubnetMask			= 0x000000FF;
	gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nBootDelay		= 1;

	gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nVerMinor		= BSP_VERSION_RELEASE;
	gpBOOTARGS->SYSTEM_ARGS.mSystemParam.nVerMajor		= EBOOT_VERSION_MAJOR;

	return TRUE;
}
