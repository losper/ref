/****************************************************************************
 *   FileName    : TCC_ISR.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/   
#include "bsp.h"

/************************************************************************************************
*  Extern.
************************************************************************************************/
extern void PutChar(unsigned char ch);
extern void asmNop6(void);
extern unsigned int uartRxCount;
extern unsigned char uartRxBuf[128];

/************************************************************************************************
* FUNCTION		: void PutChar(unsigned char ch)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void PutChar(unsigned char ch)
{
	KITLOutputDebugString("%c",ch);
    uartRxBuf[uartRxCount++] = ch;
    if ( uartRxCount >= 128 )
        uartRxCount = 0;
}

/************************************************************************************************
* FUNCTION		: void isr_uart_handler(void)
*
* DESCRIPTION	: Receive Uart
*
************************************************************************************************/
void isr_uart_handler(void)
{
    unsigned flag;
	PUART		pUART = (UART *)&HwUARTCH0_BASE;

	flag = (pUART->REG3.IIR >> 1)&7;
   if ( flag == 2 || flag == 6)
   {
	   while(pUART->LSR & Hw0)
            PutChar((unsigned char)pUART->REG1.RBR); //IO_UART_RXD(0));

   }
}

/************************************************************************************************
* FUNCTION		: void IRQHandler(void)
*
* DESCRIPTION	: detect ARM Interrupt
*
************************************************************************************************/
void IRQHandler(void)
{
    unsigned long IFLAG;
	PPIC		pPIC = (PIC *)&HwPIC_BASE;

    asmNop6();  //__asm{ nop 19 times }
    asmNop6();
    asmNop6();
    
    IFLAG = pPIC->STS0 & pPIC->MSTS0; 		// Interrupt Status 0 & Masked Status 0
	if(IFLAG)
	{
		pPIC->CLR0 = IFLAG;
	}
	else
	{
	    IFLAG = pPIC->STS1 & pPIC->MSTS1; 	// Interrupt Status 1 & Masked Status 1
	    if(IFLAG & Hw15)					//UART Interrupt
			isr_uart_handler();

		pPIC->CLR1 = IFLAG;
	}
}


/************************************************************************************************
* FUNCTION		: void enable_irq(void)
*
* DESCRIPTION	: Interrupt Enable for IRQ Handler
*
************************************************************************************************/
void enable_irq(void)
{
	PPIC		pPIC = (PIC *)&HwPIC_BASE;
#ifndef _IMGNOKITL_
	pPIC->SEL1 		|= Hw15;	// UART
	pPIC->ALLMSK 	&= ~Hw1;	// IRQ Only
	pPIC->INTMSK1	|= Hw15;	// UART
	pPIC->MODE1		|= Hw15;	// Level trigger
	pPIC->CLR1		|= Hw15;	// UART
	pPIC->IEN1		|= Hw15;	// UART	
#endif
}

void init_irq(void)
{
	PPIC		pPIC = (PIC *)&HwPIC_BASE;
	pPIC->IEN0		= 0;	
	pPIC->IEN1		= 0;		
}

/************************************************************************************************
* FUNCTION		: void FIQHandler(void)
*
* DESCRIPTION	: Interrupt FIQ Handler
*
************************************************************************************************/
void FIQHandler(void)
{
}
