#include "bsp.h"
#include "tca_ckc.h"


/************************************************************************************************
* FUNCTION		: void I2C_Reset()
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_Reset()
{
	//tcc_ckc_setswreset(RB_I2CCONTROLLER);
	
	tca_ckc_set_iobus_swreset(RB_I2CCONTROLLER,0);
	tca_ckc_set_iobus_swreset(RB_I2CCONTROLLER,1);
}


/************************************************************************************************
* FUNCTION		: void I2C_GpioSetting(void
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_GpioSetting(void)
{
	PGPIO pGPIO;
	pGPIO = (PGPIO)(&HwGPIO_BASE);


	//SCL0-GPIOA0, SDA0-GPIOA1
	BITCSET(pGPIO->GPAFN0, (Hw5-Hw0), Hw0); //GPIOA[0] function set 1
	BITCSET(pGPIO->GPAFN0, (Hw8-Hw4), Hw4); //GPIOA[1] function set 1

	//SCL1-GPIOA8, SDA1-GPIOA9
	BITCSET(pGPIO->GPAFN1, (Hw5-Hw0), Hw0); //GPIOA[8] function set 1
	BITCSET(pGPIO->GPAFN1, (Hw8-Hw4), Hw4); //GPIOA[9] function set 1
}

/************************************************************************************************
* FUNCTION		: void I2C_Initialize()
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_Initialize()
{
	//pI2C = (PI2C)tcc_allocbaseaddress((unsigned int)&HwI2CMASTER0_BASE,sizeof(GPIO));
	PI2CMASTER pI2CMASTER = (PI2CMASTER)(&HwI2CMASTER0_BASE); // I2C Controller Base Address
	
	//I2C Channel 0 setting 100kHz
	pI2CMASTER->PRES = 7; // (100K)
	pI2CMASTER->CTRL = Hw7|Hw6|HwZERO;
	BITSET( pI2CMASTER->CMD,Hw0);
	//Sleep(1);
	BITSET( pI2CMASTER->CMD,Hw0);
	
	
	//I2C Channel 1 setting 400kHz
	/* Required Frequency  */
	//pI2C->PRES1 = 2; // (400K)
	//pI2C->CTRL1 = HwI2CM_CMD_STA_EN | HwI2CM_CMD_STO_EN|HwI2CM_CTRL_MOD_8;
	//BITSET( pI2C->CMD1, HwI2CM_CMD_IACK_CLR);
	//Sleep(1);
	//BITSET( pI2C->CMD1, HwI2CM_CMD_IACK_CLR);
	
}

/************************************************************************************************
* FUNCTION		: void i2c_Write(unsigned char DestAddress, unsigned char Count, unsigned char* pBuffer)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_Write(unsigned char DestAddress, unsigned char Count, unsigned char* pBuffer)
{
	int i=0, timeout=0;
	
	PI2CMASTER pI2CMASTER = (PI2CMASTER)(&HwI2CMASTER0_BASE); // I2C Controller Base Address
	
	pI2CMASTER->TXR	= DestAddress | 0; //write 0, read 1
	pI2CMASTER->CMD	= Hw7 | Hw4; //Send to Start
	//Waiting Ack
	while( !(HwI2CSTATUS_BASE&Hw0) )
	{
		timeout++;
		if(timeout > 200000)
			break;
	}
	BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt

	for(i=0; i<Count;i++)
	{
		pI2CMASTER->TXR = pBuffer[i];
		pI2CMASTER->CMD = Hw4; //Write 
		timeout = 0;
		while( !(HwI2CSTATUS_BASE&Hw0) )
		{
			timeout++;
			if(timeout > 200000)
				break;
		}

		BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt
	}
	// Stop Condition		
	pI2CMASTER->CMD = Hw6; //Send Stop
	timeout = 0;
	while( !(HwI2CSTATUS_BASE&Hw0) )
	{
		timeout++;
		if(timeout > 200000)
			break;
	}

	BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt	
}
