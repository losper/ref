//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//

#include "private.h"
#include <svsutil.hxx>


// Perform a RegQueryValueEx for this REGINI structure
static
DWORD
ReginiQuery(
    HKEY            hkDevice,
    const REGINI   *pregini
    )
{
    DEBUGCHK(hkDevice);
    DEBUGCHK(pregini);
    
    DWORD dwType;
    DWORD dwLen = pregini->dwLen;
    DWORD dwRet = RegQueryValueEx(hkDevice, pregini->lpszVal, NULL, &dwType, 
        pregini->pData, &dwLen);

    if (dwRet != ERROR_SUCCESS) {
        goto EXIT;
    }
    else if (dwType != pregini->dwType) {
        dwRet = ERROR_INVALID_DATA;
        // Error
        goto EXIT;
    }

    if (dwType == REG_SZ) {
        // Force NULL-termination
        LPWSTR pszStr = (LPWSTR) pregini->pData;
        DWORD dwLastCh = (pregini->dwLen / sizeof(WCHAR)) - 1;
        pszStr[dwLastCh] = 0;
    }

EXIT:
    return dwRet;
}


// Verify that the serial number adheres to the Windows host PnP restrictions.
DWORD
ValidateSerialNumber(
    __out_ecount(cchSerialNumber) LPCWSTR pszSerialNumber,
    DWORD cchSerialNumber
    )
{
/* 
From http://www.microsoft.com/whdc/system/bus/USB/USBFAQ_intermed.mspx

    What characters or bytes are valid in a USB serial number? A USB device has 
    two choices for storing serial numbers in the iSerialNumber field (in the 
    USB device descriptor): 

    * iSerialNumber == 0x00 : The USB device has no serial number.
     
    * iSerialNumber != 0x00 : The USB device has a serial number and it is 
    stored at the string index indicated in iSerialNumber.
     

    If the device has a serial number, Microsoft requires that the serial 
    number uniquely identify each instance of the same device. For example, if 
    two device descriptors have identical values for the idVendor, idProduct, 
    and bcdDevice fields, the iSerialNumber field will distinguish one from the 
    other. 

    Windows Plug and Play requires that serial numbers across multiple buses 
    follow specified rules. Every byte in a USB serial number is checked for 
    correctness. If a single invalid byte is found, the serial number is 
    discarded and the device is treated as if it had no serial number.

    Invalid bytes in serial numbers are indicated below:

    * Byte values less than 0x20 are invalid.

    * Byte values greater than 0x7F are invalid.
     
    * Byte value 0x2C is invalid.

*/
    DWORD dwRet = ERROR_SUCCESS;

    for (DWORD dwChar = 0; dwChar < cchSerialNumber; ++dwChar) {
        WCHAR wch = pszSerialNumber[dwChar];

        // Check for NULL-terminator
        if (wch == 0) {
            break;
        }

        if ( (wch < L' ') || (wch > 0x007F) || (wch == L',') ) {
            dwRet = ERROR_INVALID_DATA;
            break;
        }
    }
    
    return dwRet;
}


// Read device information from the registry.
// Will fail if any values are not in the registry (excluding the serial number).
// If the serial number is found in the registry, this routine will verify that
// it adheres to the Windows host PnP restrictions. If it does not, this routine 
// will fail.
extern "C"
DWORD 
UfnGetRegistryInfo(
    LPCTSTR                 pszActiveKey,
    PUFN_CLIENT_REG_INFO    pRegInfo
    ) 
{
    DWORD dwRet = ERROR_SUCCESS;

    struct SREGINI_SUCCESS {
        REGINI regini;
        BOOL   fMustExist;
    };

    const SREGINI_SUCCESS c_rgregini[] = {
        { { UFN_IDVENDOR_VALNAME, (PBYTE) &pRegInfo->idVendor, sizeof(pRegInfo->idVendor), UFN_IDVENDOR_VALTYPE }, TRUE },
        { { UFN_MANUFACTURER_VALNAME, (PBYTE) &pRegInfo->szVendor, sizeof(pRegInfo->szVendor), UFN_MANUFACTURER_VALTYPE }, TRUE },

        { { UFN_IDPRODUCT_VALNAME, (PBYTE) &pRegInfo->idProduct, sizeof(pRegInfo->idProduct), UFN_IDPRODUCT_VALTYPE }, TRUE },
        { { UFN_PRODUCT_VALNAME, (PBYTE) &pRegInfo->szProduct, sizeof(pRegInfo->szProduct), UFN_PRODUCT_VALTYPE }, TRUE },

        { { UFN_BCDDEVICE_VALNAME, (PBYTE) &pRegInfo->bcdDevice, sizeof(pRegInfo->bcdDevice), UFN_BCDDEVICE_VALTYPE }, TRUE },
        { { UFN_SERIALNUMBER_VALNAME, (PBYTE) &pRegInfo->szSerialNumber, sizeof(pRegInfo->szSerialNumber), UFN_SERIALNUMBER_VALTYPE}, FALSE },
    };

    if ( (pszActiveKey == NULL) || (pRegInfo == NULL) || 
         (pRegInfo->dwSize != sizeof(*pRegInfo)) ) {
        dwRet = ERROR_INVALID_PARAMETER;
    }
    else {
        HKEY hkDevice = OpenDeviceKey(pszActiveKey);
        if (hkDevice == NULL) {
            dwRet = ERROR_INVALID_PARAMETER;
        }
        else {
            for (DWORD dwregini = 0; dwregini < dim(c_rgregini); ++dwregini) {
                const SREGINI_SUCCESS *pregini = &c_rgregini[dwregini];
                dwRet = ReginiQuery(hkDevice, &pregini->regini);
                if (dwRet != ERROR_SUCCESS) {
                    // Clear string
                    LPWSTR psz = (LPWSTR) pregini->regini.pData;
                    *psz = 0;

                    if (pregini->fMustExist) {
                        break;
                    }
                    else {
                        dwRet = ERROR_SUCCESS;
                        // continue
                    }
                }
            }

            RegCloseKey(hkDevice);
        }
    }

    if ( (dwRet == ERROR_SUCCESS) && *pRegInfo->szSerialNumber ) {
        // Validate the serial number
        dwRet = ValidateSerialNumber(pRegInfo->szSerialNumber, 
            dim(pRegInfo->szSerialNumber));
    }
    
    return dwRet;
}


// Get a unique device identifier from the OAL and verify that it adheres to
// the Windows host PnP restrictions.
// cchSerialNumber should be at least (MAX_STRING_DESC_WCHARS + 1)
extern "C"
DWORD 
UfnGetSystemSerialNumber(
    __out_ecount(cchSerialNumber) LPWSTR pszSerialNumber,
    DWORD cchSerialNumber
    )
{
    DWORD dwRet;

    if ( (pszSerialNumber == NULL) || (cchSerialNumber == 0) ) {
        dwRet = ERROR_INVALID_PARAMETER;
        goto EXIT;
    }

    GUID guid;
    DWORD cbWritten;
    DWORD dwInput = SPI_GETUUID ;
    BOOL fSuccess = KernelIoControl(IOCTL_HAL_GET_DEVICE_INFO, &dwInput, sizeof(dwInput), 
        &guid, sizeof(guid), &cbWritten);
    if (fSuccess) {
        ASSERT(cbWritten == sizeof(guid));
        HRESULT hr = StringCchPrintfW(pszSerialNumber, cchSerialNumber, 
            SVSUTIL_GUID_FORMAT_W, SVSUTIL_RGUID_ELEMENTS(guid));
        if (FAILED(hr)) {
            dwRet = HRESULT_CODE(hr);
            goto EXIT;
        }
    }
    else {
        dwRet = GetLastError();
        goto EXIT;
    }
    
    dwRet = ValidateSerialNumber(pszSerialNumber, cchSerialNumber);

EXIT:    
    return dwRet;
}



