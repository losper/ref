//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
#include "private.h"
#include "ufnpid.h"


typedef struct UFN_CLIENT_INTERFACE {
    HINSTANCE hiParent;
} *PUFN_CLIENT_INTERFACE;


extern "C"
DWORD
UfnInitializeInterface(
    LPCTSTR             pszActiveKey,
    UFN_HANDLE         *phDevice,
    PUFN_FUNCTIONS      pFunctions,
    PVOID              *ppvInterfaceInfo
    )
{
    SETFNAME();
    
    DWORD dwRet;
    PUFN_CLIENT_INTERFACE pInterface = NULL;
    HANDLE hBusAccess = NULL;
    UFN_CLIENT_DATA ucd;
    BOOL fSuccess;
    
    if ( !pszActiveKey || !phDevice || !pFunctions || !ppvInterfaceInfo ) {
        dwRet = ERROR_INVALID_PARAMETER;
        DEBUGMSG(1, (_T("%s Invalid parameter.\r\n"), 
            pszFname));
        goto EXIT;
    }

    pInterface = (PUFN_CLIENT_INTERFACE) LocalAlloc(LPTR, sizeof(UFN_CLIENT_INTERFACE));
    if (pInterface == NULL) {
        dwRet = GetLastError();
        DEBUGMSG(1, (_T("%s Could not allocate memory. Error %u\r\n"), 
            pszFname, dwRet));
        goto EXIT;
    }

    hBusAccess = CreateBusAccessHandle(pszActiveKey);
    if (hBusAccess == NULL) {
        dwRet = GetLastError();
        DEBUGMSG(1, (_T("%s Could not CreateBusAccessHandle. Error %u\r\n"), 
            pszFname, dwRet));
        goto EXIT;
    }

    memset(&ucd, 0, sizeof(ucd));
    ucd.dwVersion = UFN_CLIENT_INTERFACE_VERSION;
    fSuccess = BusChildIoControl(hBusAccess, IOCTL_UFN_GET_CLIENT_DATA_EX, &ucd, sizeof(ucd));
    if (!fSuccess) {
        dwRet = GetLastError();
        goto EXIT;
    }
    
    *phDevice = ucd.hDevice;
    memcpy(pFunctions, &ucd.ufnFunctions, sizeof(ucd.ufnFunctions));
    pInterface->hiParent = ucd.hiParent;
    *ppvInterfaceInfo = pInterface;
    dwRet = ERROR_SUCCESS;

EXIT:
    if (dwRet != ERROR_SUCCESS) {
        if (pInterface) {
            if (pInterface->hiParent) {
                UfnDeinitializeInterface(pInterface);
            }
            else {
                LocalFree(pInterface);
            }
        }
    }
    else {
        DEBUGCHK(pFunctions->lpRegisterDevice);
    }

    if (hBusAccess) CloseBusAccessHandle(hBusAccess);
    
    return dwRet;
}


extern "C"
DWORD
UfnDeinitializeInterface(
    PVOID       pvInterfaceInfo
    )
{
    SETFNAME();
    
    PUFN_CLIENT_INTERFACE pInterface = (PUFN_CLIENT_INTERFACE) pvInterfaceInfo;
    DWORD dwRet = ERROR_SUCCESS;

    if (!pInterface) {
        dwRet = ERROR_INVALID_PARAMETER;
        RETAILMSG(1, (_T("%s Invalid parameter.\r\n"), 
            pszFname));
    }
    else {    
        DEBUGCHK(pInterface->hiParent);
        FreeLibrary(pInterface->hiParent);
        LocalFree(pInterface);
    }
    
    return dwRet;
}


// Is this PID an MS reference PID?
static inline BOOL
IsUsingPrototypePID(
    WORD    idProduct,
    DWORD   dwReferencePID
    )
{
    BOOL fRet = ( (idProduct >= PID_MICROSOFT_PROTOTYPE_MIN) && 
                  (idProduct <= PID_MICROSOFT_PROTOTYPE_MAX) ) ||
                (idProduct == dwReferencePID);
    return fRet;
}


// Display a warning if the device descriptors are using Microsoft's vendor
// ID with a prototype product ID.
// Returns TRUE if a warning was displayed.
// Note: Shipping devices cannot use Microsoft's vendor ID.
extern "C"
BOOL
UfnCheckPID(
    __in_opt PCUSB_DEVICE_DESCRIPTOR   pHighSpeedDeviceDesc,
    __in_opt PCUSB_DEVICE_DESCRIPTOR   pFullSpeedDeviceDesc,
    DWORD                              dwReferencePID
    )
{
    BOOL fRet = FALSE;
    
    SETFNAME();
    
    PCUSB_DEVICE_DESCRIPTOR rgDeviceDescs[2];
    DWORD cDeviceDescs = 0;
    
    if (pHighSpeedDeviceDesc != NULL) {
        rgDeviceDescs[cDeviceDescs++] = pHighSpeedDeviceDesc;
    }

    if (pFullSpeedDeviceDesc != NULL) {
        rgDeviceDescs[cDeviceDescs++] = pFullSpeedDeviceDesc;
    }

    for (DWORD dwDeviceDesc = 0; dwDeviceDesc < cDeviceDescs; ++dwDeviceDesc) {
        PCUSB_DEVICE_DESCRIPTOR pDeviceDesc = rgDeviceDescs[dwDeviceDesc];

        if (pDeviceDesc->idVendor == VID_MICROSOFT) {
            if (IsUsingPrototypePID(pDeviceDesc->idProduct, dwReferencePID)) {
                RETAILMSG(TRUE, (_T("%s WARNING -- using MS reference platform VID/PID 0x%04x/0x%04x (not allowed in shipping platforms)\r\n"), 
                    pszFname, VID_MICROSOFT, pDeviceDesc->idProduct));
                fRet = TRUE;
                break; // Only print this once.
            }
        }
    }

    return fRet;
}

