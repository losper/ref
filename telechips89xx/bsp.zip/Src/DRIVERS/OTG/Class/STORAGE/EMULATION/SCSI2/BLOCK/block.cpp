//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//
/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

        block.cpp

Abstract:

        Block-based SCSI-2 direct-access device (hard disk drive) emulator.

--*/

#include <windows.h>
#include <diskio.h>
#include <storemgr.h>
#include <devload.h>
#include <atapi2.h>

#include "bsp.h"
#include "proxy.h"
#include "scsi2.h"
#include "transporttypes.h"
#include "usbmsfndbg.h"
#include "ioctl_code.h"


#include <pshpack1.h>

typedef struct _UFI_CB {
    BYTE  bOpCode;                // 0
    BYTE  bReserved1:5;           // 1
    BYTE  bLogicalUnitNumber : 3;
    DWORD dwLogicalBlockAddress;  // 2-5
    BYTE  bReserved2;             // 6
    WORD  wTransferLength;        // 7-8
    BYTE  bReserved3[3];          // 9-11
} UFI_CB, *PUFI_CB;

#include <poppack.h>
//#define DEBUGMSG(a,b) RETAILMSG(1,b)

#if DEBUG
#define DUMP_DISKINFO(di) { \
    DEBUGMSG(1, (_T("%s bytes per sector = %u\r\n"), __FUNCTION__, di.di_bytes_per_sect)); \
    DEBUGMSG(1, (_T("%s cylinders = %u\r\n"), __FUNCTION__, di.di_cylinders)); \
    DEBUGMSG(1, (_T("%s flags = 0x%x\r\n"), __FUNCTION__, di.di_flags)); \
    DEBUGMSG(1, (_T("%s heads = %u\r\n"), __FUNCTION__, di.di_heads)); \
    DEBUGMSG(1, (_T("%s sectors = %u\r\n"), __FUNCTION__, di.di_sectors)); \
    DEBUGMSG(1, (_T("%s total sectors = %u\r\n"), __FUNCTION__, di.di_total_sectors)); \
    }
#define DUMP_PARTENTRY(ppe) { \
    DEBUGMSG(1, (_T("%s bootind=0x%x \r\n"), __FUNCTION__, ppe->Part_BootInd)); \
    DEBUGMSG(1, (_T("%s filesystem=0x%x \r\n"), __FUNCTION__, ppe->Part_FileSystem)); \
    DEBUGMSG(1, (_T("%s firsthead=%u\r\n"), __FUNCTION__, ppe->Part_FirstHead)); \
    DEBUGMSG(1, (_T("%s firstsector=%u\r\n"), __FUNCTION__, ppe->Part_FirstSector)); \
    DEBUGMSG(1, (_T("%s firsttrack=%u\r\n"), __FUNCTION__, ppe->Part_FirstTrack)); \
    DEBUGMSG(1, (_T("%s lasthead=%u\r\n"), __FUNCTION__, ppe->Part_LastHead)); \
    DEBUGMSG(1, (_T("%s lastsector=%u\r\n"), __FUNCTION__, ppe->Part_LastSector)); \
    DEBUGMSG(1, (_T("%s lasttrack=%u\r\n"), __FUNCTION__, ppe->Part_LastTrack)); \
    DEBUGMSG(1, (_T("%s startsector=%u\r\n"), __FUNCTION__, ppe->Part_StartSector)); \
    DEBUGMSG(1, (_T("%s totalsectors=%u\r\n"), __FUNCTION__, ppe->Part_TotalSectors)); \
    }
#else
#define DUMP_DISKINFO(di)
#define DUMP_PARTENTRY(pe)
#endif // DEBUG

// Helpful macros
#define CLOSE_KEY(x)    if (x != NULL) RegCloseKey(x)
#define LOCAL_FREE(x)   if (x != NULL) LocalFree(x)
#define CLOSE_HANDLE(x) if (x != NULL) CloseHandle(x)

// SCSI-2 command data size definitions
#define DATASIZE_INQUIRY       36
#define DATASIZE_MODE_SENSE6   8
#define DATASIZE_MODE_SENSE10  512
#define DATASIZE_REQUEST_SENSE 18

//
// SCSI-2 direct-access device state
//static const UCHAR g_bSenseKey = 0;
//static const UCHAR g_bASC = 0;
//static const UCHAR g_bASCQ = 0;
DWORD g_TestUnitReadyCount=0;
DWORD g_LunCount=0;
static  UCHAR g_bSenseKey[MAX_LUN] = {0,0,0,0,0,0,0};
static  UCHAR g_bASC[MAX_LUN] =  {0,0,0,0,0,0,0};
static  UCHAR g_bASCQ[MAX_LUN] = {0,0,0,0,0,0,0};
static	BOOL  g_fInitialized[MAX_LUN] = {FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE};
static  DWORD	 g_dwLunStatus[MAX_LUN]={0,0,0,0,0,0,0}; //0- insert, 1- none insert 
static  DWORD	 g_dwSCSISTARTSTOP[MAX_LUN]={0,0,0,0,0,0,0}; //0- start, 1-stop(eject receive)
static  DWORD	 g_bSendChangeStatue[MAX_LUN]={0,0,0,0,0,0,0}; //0-not send, 1-already sent
static  DWORD dwStartSector[4]={0,0,0,0};
static  DWORD dwSectorNumber[4]={0,0,0,0};
DWORD	 g_dwLunType[MAX_LUN]={0,0,0,0,0,0,0};	 //0- nand,   1- sdmmc , 2- MemoryStic, 0x10 - sata/hard disk
#define PRX_PARTITION                 (_T("Partition"))
DWORD g_dwPartition = 0;
DWORD g_dwMaxPartition= 0;
PARTINFO pPartInfo;
static BOOL g_bIsChangeSDState[MAX_LUN] = {FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE};
DWORD g_nand_index=0xFF;
DWORD g_NandRead=FALSE;

// Properties of exposed device
static HANDLE    g_hStore[MAX_LUN];
static DISK_INFO g_diDiskInfo[MAX_LUN];
static TCHAR     g_szDeviceName[MAX_LUN][PRX_DEVICE_NAME_LEN];
static TCHAR     g_szHandleName[MAX_LUN][PRX_DEVICE_NAME_LEN];

static BOOL      g_fLegacyBlockDriver[MAX_LUN] = {FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE}; // IOCTL_DISK_Xxx or DISK_IOCTL_Xxx

static TCHAR     DEVICE_NAME_VAL[MAX_LUN][PRX_DEVICE_NAME_LEN]  ={_T("DeviceName"),_T("DeviceName1"),_T("DeviceName2"),_T("DeviceName3"),_T("DeviceName4"),_T("DeviceName5"),_T("DeviceName6")};
static TCHAR     DEVICE_RMB_VAL[MAX_LUN][PRX_DEVICE_NAME_LEN]  ={_T("Removable"),_T("Removable1"),_T("Removable2"),_T("Removable3"),_T("Removable4"),_T("Removable5"),_T("Removable6")};
static TCHAR     DEVICE_TYPE_VAL[MAX_LUN][PRX_DEVICE_NAME_LEN]  ={_T("Type"),_T("Type1"),_T("Type2"),_T("Type3"),_T("Type4"),_T("Type5"),_T("Type6")};
static TCHAR	 DEVICE_HANDLE_VAL[MAX_LUN][PRX_DEVICE_NAME_LEN] ={_T("Handle0"),_T("Handle1"),_T("Handle2"),_T("Handle3"),_T("Handle4"),_T("Handle5"),_T("Handle6")};
//mid pid
#define PRX_MANUFACTURE                 (_T("Manufacturer"))
#define PRX_PRODUCT		                (_T("Product"))
static TCHAR     g_dwManufacture[32];
static TCHAR     g_dwProductID[32];

//check for insert status
HANDLE hHandleofLun[MAX_LUN];

// Whether to report to USB host that exposed device is removable
static DWORD g_dwRemovable[MAX_LUN] = {1,1,1,1,1,1,1};
 DWORD STORE_Flush();
 DWORD STORE_Check(DWORD);

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------

#define PART_PRIMARY  0x00   // Part_BootInd stores the partition type; see PARTENTRY
#define PART_EXTENDED 0x05   // Part_FileSystem stores the file system type; see PARTENTRY

// Partition table entry
typedef struct _PARTENTRY {
    BYTE  Part_BootInd;      // Boot index (80h = boot partition)
    BYTE  Part_FirstHead;    // Partition starting head based 0
    BYTE  Part_FirstSector;  // Partition starting sector based 1
    BYTE  Part_FirstTrack;   // Partition starting track based 0
    BYTE  Part_FileSystem;   // Partition type signature field
    BYTE  Part_LastHead;     // Partition ending head based 0
    BYTE  Part_LastSector;   // Partition ending sector based 1
    BYTE  Part_LastTrack;    // Partition ending track based 0
    DWORD Part_StartSector;  // Physical starting sector based 0
    DWORD Part_TotalSectors; // Total physical sectors in partition
} PARTENTRY;
typedef PARTENTRY UNALIGNED *PPARTENTRY;

#define DEFAULT_SECTOR_SIZE    512
#define MAX_PARTTABLE_ENTRIES  4
#define SIZE_PARTTABLE_ENTRIES 16
#define PARTTABLE_OFFSET       (DEFAULT_SECTOR_SIZE - 2 - (SIZE_PARTTABLE_ENTRIES * MAX_PARTTABLE_ENTRIES))

typedef struct _PARTTABLE {
    PARTENTRY PartEntry[MAX_PARTTABLE_ENTRIES];
} PARTTABLE;
typedef PARTTABLE UNALIGNED *PPARTTABLE;

// List of partition names
static PTCHAR g_ptcPartitions = NULL;

// Copy of physical disk's MBR (to facilitate write-protection); it is possible
// for a host to attempt to reorganize a disk while only a subset of its
// partitions are exposed; unexposed partitions appear as unallocated space;
// we need a copy of the actual MBR to determine the sector range of an
// unexposed partition, to protect unexposed partitions from modification
static LPBYTE g_lpbPhysMBR = NULL;

// Virtual disk's MBR; this is the modified copy of the MBR that we advertise to
// the USB host when the disk is only exposing a subset of its partitions; the
// modified MBR contains "holes" where unexposed partitions exist
static LPBYTE g_lpbMBR = NULL;

// Bit mask of primary partitions selected for exposure; bit 0 = primary 1
// selected, bit 1 = primary 2 selected, etc.
static BYTE g_bmPartitions = 0;

//static UCHAR g_bSenseKey[4] = {0,0,0,0};
//static const UCHAR g_bSenseKey = 0;
static void SetSenseKey( DWORD lun, UCHAR ucSenseKey, UCHAR ucASC)
{
	g_bSenseKey[lun] = ucSenseKey;
	g_bASC[lun] = ucASC;
}

// ----------------------------------------------------------------------------
// Function: BytesPerSector
//     Return number of bytes per sector on exposed device
//
// Parameters:
//     None
// ----------------------------------------------------------------------------

static
DWORD
inline
BytesPerSector(DWORD dwLUN)
{
    DEBUGCHK(g_fInitialized);
    return g_diDiskInfo[dwLUN].di_bytes_per_sect;
}

// ----------------------------------------------------------------------------
// Function: ByteSwapUlong
//     Same as _byteswap_ulong
//
// Parameters:
//     ULONG to swap
// ----------------------------------------------------------------------------

static
inline
ULONG
ByteSwapUlong(
    ULONG ul
    )
{
    PBYTE pb = (PBYTE)&ul;
    ULONG ulRet = pb[3];
    ulRet |= pb[2] << 8;
    ulRet |= pb[1] << 16;
    ulRet |= pb[0] << 24;
    return ulRet;
}

// ----------------------------------------------------------------------------
// Function: ByteSwapUshort
//     Same as _byteswap_ushort
//
// Parameters:
//     USHORT to swap
// ----------------------------------------------------------------------------

static
inline
USHORT 
ByteSwapUshort(
    USHORT us
    )
{
    PBYTE pb = (PBYTE)&us;
    USHORT usRet = pb[1];
    usRet |= pb[0] << 8;
    return usRet;
}

static BOOL IsSdCardExist(DWORD dwLUN)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+IsSdCardExist \n")));
	BOOL tmpStatus = g_dwLunStatus[dwLUN];
	BOOL fResult = FALSE;
	DWORD dwError;
	DWORD dwBytesReturned;

	DWORD SDState=0;
	DWORD retSize=0;




	DeviceIoControl(hHandleofLun[dwLUN],
		IOCTL_SD_STATE,
		NULL,
		0,
		&SDState,
		sizeof(DWORD),
		&retSize,
		NULL) ;

	if(!SDState)
	{
		if(g_dwSCSISTARTSTOP[dwLUN])//is SCSI_START_STOP Command received ??
		{
			g_dwSCSISTARTSTOP[dwLUN] = 0; //reset
		}
		else
		{
			// sd removed
			g_dwLunStatus[dwLUN] = 1;
			
			
			if(!tmpStatus)
				g_bIsChangeSDState[dwLUN] = TRUE;
		}
		return FALSE;
	}
	else
	{
		if(g_dwSCSISTARTSTOP[dwLUN])//is SCSI_START_STOP Command received ??
		{
			g_dwLunStatus[dwLUN] = 1;

			if(!g_bSendChangeStatue[dwLUN])
			{
				g_bIsChangeSDState[dwLUN] = TRUE;
				g_bSendChangeStatue[dwLUN] = TRUE;
			}

			return FALSE;
		}

		// sd inserted
		g_dwLunStatus[dwLUN] = 0;
		if(tmpStatus){

			g_bIsChangeSDState[dwLUN] = TRUE;

			RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("change sd status OFF->ON [%s][%s]\n\r"),g_szDeviceName[dwLUN],g_szDeviceName[dwLUN]));
			for(int i=0; i < 50; i++)
			{
				g_hStore[dwLUN] = OpenStore(g_szDeviceName[dwLUN]);
				if ((g_hStore[dwLUN] == NULL) || (g_hStore[dwLUN] == INVALID_HANDLE_VALUE)) {
					dwError = GetLastError();
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T(
						"%s failed to open store %s; error = %u[%d]\r\n"
						), __FUNCTION__, g_szDeviceName[dwLUN], dwError,dwLUN));
				}
				else break;
				Sleep(200);
			}
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("%s opened store %s\r\n"), __FUNCTION__, g_szDeviceName[1]));

			fResult = DeviceIoControl(
				g_hStore[dwLUN],
				IOCTL_DISK_GETINFO,
				NULL,
				0,
				&g_diDiskInfo[dwLUN],
				sizeof(g_diDiskInfo[dwLUN]),
				&dwBytesReturned,
				NULL);
			if (fResult) {
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s IOCTL_DISK_GETINFO passed\r\n"), __FUNCTION__));
				DUMP_DISKINFO(g_diDiskInfo[dwLUN]);
			}
			else {

				dwError = GetLastError();
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T(
					"%s IOCTL_DISK_GETINFO failed; error = %u\r\n"
					), __FUNCTION__, dwError));

				// is this a legacy block driver?
				fResult = DeviceIoControl(
					g_hStore[dwLUN],
					DISK_IOCTL_GETINFO,
					&g_diDiskInfo[dwLUN],
					sizeof(g_diDiskInfo[dwLUN]),
					NULL,
					0,
					&dwBytesReturned,
					NULL);
				if (fResult) {
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s DISK_IOCTL_GETINFO passed\r\n"), __FUNCTION__));
					DUMP_DISKINFO(g_diDiskInfo[dwLUN]);
					g_fLegacyBlockDriver[dwLUN] = TRUE; // legacy block driver
				}
				else {
					dwError = GetLastError();
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T(
						"%s DISK_IOCTL_GETINFO failed; error = %u\r\n"
						), __FUNCTION__, dwError));
				}
			}

			if (!DismountStore(g_hStore[dwLUN])) {
				dwError = GetLastError();
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T(
					"%s DismountStore failed; error = %u\r\n"
					), __FUNCTION__, dwError));
			}
		}
		
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-IsSdCardExist(true) \n")));
		
		return TRUE;
	}
}
// ----------------------------------------------------------------------------
// Function: ProcessScsiInquiry
//     Process a SCSI-2 INQURY command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiInquiry(
    PTRANSPORT_COMMAND ptcCommand,
    PTRANSPORT_DATA ptdData
    )
{
    SETFNAME(_T("ProcessScsiInquiry"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    PBYTE pbData = (PBYTE) ptdData->DataBlock;
    DWORD dwResult = EXECUTE_FAIL;
	INQUIRY_DATA pRetData;
	
    DWORD dwLUN = ptcCommand->dwLun;

    // test if data block is large enough
    if (ptdData->RequestLength < DATASIZE_INQUIRY) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "%s host requesting less than required; ptdData->RequestLength < DATASIZE_INQUIRY\r\n"
            ), pszFname));
    }

    ZeroMemory(pbData, ptdData->RequestLength);
    ptdData->TransferLength = ptdData->RequestLength;

 	memset((char *)&pRetData,0x00,sizeof(INQUIRY_DATA));
	pRetData.inqRMB = ((g_dwRemovable[dwLUN] ? 1 : 0) << 7); 

	pRetData.inqAtapiVersion = 0x00; //SCSI-1:0, SCSI-2:1
	pRetData.inqLength = 0x1F;

	char *sTemp=NULL;
	int nLen = WideCharToMultiByte(CP_ACP, 0, g_dwManufacture, -1, sTemp, 0, NULL, NULL);
	sTemp =(char *) malloc(nLen+1);
	WideCharToMultiByte(CP_ACP, 0, g_dwManufacture, -1, sTemp, 128, NULL, NULL);
	memcpy((char*)&pRetData.inqVendor,sTemp,8);
	free(sTemp); 
#if 0
	if(g_dwLunType[dwLUN] == 1)
		memcpy((char*)&pRetData.inqProdID,"SDMMC",16);
	else if(g_dwLunType[dwLUN] == 2)
		memcpy((char*)&pRetData.inqProdID,"MEMORYSTIC",16);
	else
#endif
		memcpy((char*)&pRetData.inqProdID,"MassStorage",16);

	memcpy((char*)&pRetData.inqRev,"1.0",4);

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("vender[%s], proid[%s]\n"),pRetData.inqVendor,pRetData.inqProdID));
	memcpy(pbData,(char *)&pRetData,sizeof(INQUIRY_DATA));

	SetSenseKey(dwLUN,SENSE_NONE,SENSE_NONE);


    dwResult = EXECUTE_PASS;

    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiModeSense6
//     Process a SCSI-2 MODE SENSE (6) command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiModeSense6(
    PTRANSPORT_COMMAND ptcCommand,
    PTRANSPORT_DATA ptdData
    )
{
    SETFNAME(_T("ProcessScsiModeSense6"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    PBYTE pbData = (PBYTE) ptdData->DataBlock;
    DWORD dwResult = EXECUTE_FAIL;

	DWORD dwLUN = ptcCommand->dwLun;

    // test if data block is large enough
    if (ptdData->RequestLength < DATASIZE_MODE_SENSE6) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "%s host requesting less than required; ptdData->RequestLength < DATASIZE_MODE_SENSE6\r\n"
            ), pszFname));
    }    

	ZeroMemory(pbData, ptdData->RequestLength);


	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{
		if(g_dwSCSISTARTSTOP[dwLUN])
		{
			ptdData->TransferLength = 0;
			SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		}
		else
		{
			ptdData->TransferLength = ptdData->RequestLength;

			// mode data length
			pbData[0] = 0x04; // length 55Byte
			// medium type, 9.3.3
			pbData[1] = 0x00; // Medium Type Code
			// device-specific parameter, 9.3.3

			//need check write protect's status
			pbData[2] = 0x00;  // bit 7 = WP (write protected)

			// Block Descriptor Length
			pbData[3] = 0x00;   

			// Density Code 
			//	pbData[4] = 0x00;  
			// Numver of Blocks
			//	pbData[5] = ByteSwapUlong(g_diDiskInfo[dwLUN].di_total_sectors);
			// Block Length
			//	pbData[8] = ByteSwapUlong(g_diDiskInfo[dwLUN].di_total_sectors);

			dwResult = EXECUTE_PASS;

			SetSenseKey(dwLUN,SENSE_NONE,SENSE_NONE);
		}

	}

    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiModeSense10
//     Process a SCSI-2 MODE SENSE (10) command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiModeSense10(
    PTRANSPORT_COMMAND ptcCommand,
    PTRANSPORT_DATA ptdData
    )
{
    SETFNAME(_T("ProcessScsiModeSense10"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    PBYTE pbData = (PBYTE) ptdData->DataBlock;
    DWORD dwResult = EXECUTE_FAIL;

    DWORD dwLUN = ptcCommand->dwLun;

    // test if data block is large enough
    if (ptdData->RequestLength < DATASIZE_MODE_SENSE10) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "%s host requesting less than required; ptdData->RequestLength < DATASIZE_MODE_SENSE10\r\n"
            ), pszFname));
    }

    // test if DBD (disable block descriptors) bit is high
    if (!(pbCommand[1] & 0x08)) {
        DEBUGMSG(ZONE_ERROR, (_T("%s DBD is not enabled\r\n"), pszFname));
        goto EXIT;
    }

    // test if PC is 0
    if ((pbCommand[2] & 0xC0) != 0) {
        DEBUGMSG(ZONE_ERROR, (_T("%s PC is not 0\r\n"), pszFname));
        goto EXIT;
    }

    // test if page code is 0
    if ((pbCommand[2] & 0x3F) != 0) {
        DEBUGMSG(ZONE_ERROR, (_T("%s page code is not 0\r\n"), pszFname));
        goto EXIT;
    }

    ZeroMemory(pbData, ptdData->RequestLength);
	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{
		if(g_dwSCSISTARTSTOP[dwLUN])
		{
			ptdData->TransferLength = 0;
			SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		}
		else
		{
			ptdData->TransferLength = ptdData->RequestLength;

			// only return the header

			// mode data length
			pbData[0] = 0; // msb
			pbData[1] = 6; // lsb
			// medium type, 9.3.3
			pbData[2] = 0x00; // default medium type
			// device-specific parameter, 9.3.3
			pbData[3] = 0x00; // bit 7 = WP (write protected); read from registry

			dwResult = EXECUTE_PASS;
		}
	}
EXIT:;
    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiRequestSense
//     Process a SCSI-2 REQUEST SENSE command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiRequestSense(
    PTRANSPORT_COMMAND ptcCommand,
    PTRANSPORT_DATA ptdData
    )
{
    SETFNAME(_T("ProcessScsiRequestSense"));

    const BYTE bErrorCode = 0x70;
    const BYTE bAdditionalSenseLength = 10;

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    PBYTE pbData = (PBYTE) ptdData->DataBlock;
    DWORD dwResult = EXECUTE_FAIL;

    DWORD dwLUN = ptcCommand->dwLun;

    // test if data block is large enough
    if (ptdData->RequestLength < sizeof(SENSE_DATA)) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "%s host requesting less than required; ptdData->RequestLength < %u\r\n"
            ), pszFname, sizeof(SENSE_DATA)));
    }

    ZeroMemory(pbData, ptdData->RequestLength);
    ptdData->TransferLength = ptdData->RequestLength;

    PSENSE_DATA pSenseData;
    pSenseData = (PSENSE_DATA) pbData;
	pSenseData->Valid=1;
    pSenseData->ErrorCode = bErrorCode;
    pSenseData->SenseKey = g_bSenseKey[dwLUN];
    pSenseData->AdditionalSenseLength = bAdditionalSenseLength;
    pSenseData->AdditionalSenseCode = g_bASC[dwLUN];
    pSenseData->AdditionalSenseCodeQualifier = g_bASCQ[dwLUN];

    dwResult = EXECUTE_PASS;

	return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiSendDiagnostic
//     Process a SCSI-2 SEND DIAGNOSTIC command
//
// Parameters:
//     ptcCommand - command block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiSendDiagnostic(
    PTRANSPORT_COMMAND ptcCommand
    )
{
    SETFNAME(_T("ProcessScsiSendDiagnostic"));

    const BYTE bSelfTest = 0x04;

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    DWORD dwResult = EXECUTE_FAIL;

    DWORD dwLUN = ptcCommand->dwLun;

	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{
		if(g_dwSCSISTARTSTOP[dwLUN])
		{
			SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		}
		else
		{
			// test if self-test bit is high
			if (!(pbCommand[1] & bSelfTest)) {
				DEBUGMSG(ZONE_ERROR, (_T("%s only self-test is supported\r\n"), pszFname));
				goto EXIT;
			}

			// nothing to check
			dwResult = EXECUTE_PASS;
		}
	}

EXIT:;
    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiTestUnitReady
//     Process a SCSI-2 TEST UNIT READY command
//
// Parameters:
//     ptcCommand - command block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiTestUnitReady(
    PTRANSPORT_COMMAND ptcCommand
    )
{
    SETFNAME(_T("ProcessScsiTestUnitReady"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    DWORD dwResult = EXECUTE_FAIL;

	DWORD dwLUN = ptcCommand->dwLun;

	//
	if(!(g_dwLunType[dwLUN]))
	{
		RETAILMSG(0,(TEXT("+g_NandRead [%d][%d]\n"),g_NandRead,GetTickCount()));
		g_TestUnitReadyCount++;
		if(!(g_TestUnitReadyCount%20)) 
		{
			if(!g_NandRead)
			{
				STORE_Flush();
				
			}
			g_NandRead=FALSE;
			RETAILMSG(0,(TEXT("-g_NandRead [%d][%d]\n"),g_NandRead,GetTickCount()));
			if(g_TestUnitReadyCount > 100)
				g_TestUnitReadyCount=0;
		}
	}
	//
	if(g_bIsChangeSDState[dwLUN])
	{
		SetSenseKey(dwLUN, SENSE_UNIT_ATTENTION, ASC_MEDIA_CHANGED);
		g_bIsChangeSDState[dwLUN]=FALSE;
	}
	else if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ||(g_dwSCSISTARTSTOP[dwLUN])) // not nand and none insert status
	{
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{
		// nothing to check
		dwResult = EXECUTE_PASS;
		SetSenseKey(dwLUN,SENSE_NONE,SENSE_NONE);
	}
    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiRead10
//     Process a SCSI-2 READ (10) command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiRead10(
    PTRANSPORT_COMMAND ptcCommand,
    PTRANSPORT_DATA ptdData
    )
{
    SETFNAME(_T("ProcessScsiRead10"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    PBYTE pbData = (PBYTE) ptdData->DataBlock;
    DWORD dwLogicalBlockAddress;
    DWORD dwTransferLength;
    DWORD dwResult = EXECUTE_FAIL;

    SG_REQ sgSgReq;
    SG_BUF sgSgBuf;
    DWORD dwBytesReturned;
    BOOL fResult = FALSE;

    PUFI_CB pUfiCb = (PUFI_CB) pbCommand;
    DEBUGCHK(pUfiCb->bReserved1 == 0);

    DWORD dwLUN = ptcCommand->dwLun;

	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}
	
	if(!g_dwLunType[dwLUN])
	{
		g_NandRead=TRUE;
	}

		if(g_dwSCSISTARTSTOP[dwLUN])
		{
			ptdData->TransferLength = 0;
			SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		}
		else
		{

			// test if logical block address is valid
			if(g_dwLunType[dwLUN] || !g_dwRemovable[0]) 
				dwLogicalBlockAddress = ByteSwapUlong(pUfiCb->dwLogicalBlockAddress);
			else //nand
				dwLogicalBlockAddress = ByteSwapUlong(pUfiCb->dwLogicalBlockAddress)+dwStartSector[g_dwPartition];

			// test if transfer length is valid
			dwTransferLength = ByteSwapUshort(pUfiCb->wTransferLength);

			DEBUGMSG(ZONE_COMMENT, (_T(
				"%s starting LBA/sector = %u, transfer length = %u (sectors)\r\n"
				), pszFname, dwLogicalBlockAddress, dwTransferLength));

			ZeroMemory(pbData, (dwTransferLength * BytesPerSector(dwLUN)));
			ptdData->TransferLength = dwTransferLength * BytesPerSector(dwLUN);

			// is the host reading the virtual disk's MBR?
			if ((dwLogicalBlockAddress == 0) && (g_lpbMBR != NULL)) {
				// we can't handle a request to access {virtual sector 0, physical
				// sector 1, physical sector2, ...)
				DEBUGCHK(dwTransferLength == 1);
				DEBUGMSG(ZONE_COMMENT, (_T(
					"%s read request targeting virtual disk's MBR\r\n"
					), pszFname));
				// return virtual disk's MBR
				ptdData->DataBlock = g_lpbMBR;
				dwResult = EXECUTE_PASS;
				goto EXIT;
			}

			// prepare scatter/gather buffer
			sgSgBuf.sb_buf = pbData;
			sgSgBuf.sb_len = ptdData->TransferLength;

			// prepare scatter/gather request
			sgSgReq.sr_start = dwLogicalBlockAddress;
			sgSgReq.sr_num_sec = dwTransferLength;
			sgSgReq.sr_status = 0;
			sgSgReq.sr_callback = NULL;
			sgSgReq.sr_num_sg = 1;
			sgSgReq.sr_sglist[0] = sgSgBuf;

			// read from device
			DWORD dwIoControlCode = (g_fLegacyBlockDriver[dwLUN]) ? DISK_IOCTL_READ : IOCTL_DISK_READ;
			fResult = DeviceIoControl(
				g_hStore[dwLUN],
				dwIoControlCode,
				&sgSgReq,
				sizeof(sgSgReq),
				NULL,
				0,
				&dwBytesReturned,
				NULL);
			if (fResult) {
				DEBUGMSG(ZONE_COMMENT, (_T(
					"%s IOCTL_DISK_READ passed; %u bytes read\r\n"
					), pszFname, dwBytesReturned));
			}
			else {
				DWORD dwError = GetLastError();
				DEBUGMSG(ZONE_ERROR, (_T(
					"%s IOCTL_DISK_READ failed; error = %u\r\n"
					), pszFname, dwError));
				goto EXIT;
			}

			dwResult = EXECUTE_PASS;
		}

EXIT:;
    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiRead12
//     Process a SCSI-2 READ (12) command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiRead12(
				  PTRANSPORT_COMMAND ptcCommand,
				  PTRANSPORT_DATA ptdData
				  )
{
	SETFNAME(_T("ProcessScsiRead12"));

	PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
	PBYTE pbData = (PBYTE) ptdData->DataBlock;

	DWORD dwResult = EXECUTE_FAIL;

	DWORD dwLUN = ptcCommand->dwLun;


	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}

	if(g_dwSCSISTARTSTOP[dwLUN])
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{
		SetSenseKey(dwLUN,SENSE_ILLEGAL_REQUEST,ASC_INVALID_COMMAND_OPERATION);
	}

EXIT:;
	return dwResult;

}
// ----------------------------------------------------------------------------
// Function: ProcessScsiReadCapacity
//     Process a SCSI-2 READ CAPACITY command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiReadCapacity(
    PTRANSPORT_COMMAND ptcCommand,
    PTRANSPORT_DATA ptdData
    )
{
    SETFNAME(_T("ProcessScsiReadCapacity"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    PBYTE pbData = (PBYTE) ptdData->DataBlock;
    DWORD dwResult = EXECUTE_FAIL;

    DWORD dwLUN = ptcCommand->dwLun;

	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}

	if(g_dwSCSISTARTSTOP[dwLUN])
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{

		// test if data block is large enough
		if (ptdData->RequestLength < sizeof(READ_CAPACITY_DATA)) {
			DEBUGMSG(ZONE_ERROR, (_T(
				"%s host requesting less than required; ptdData->RequestLength < %u\r\n"
				), pszFname, sizeof(READ_CAPACITY_DATA)));
			goto EXIT;
		}

		ZeroMemory(pbData, ptdData->RequestLength);
		ptdData->TransferLength = ptdData->RequestLength;

		// pack logical block address
		PREAD_CAPACITY_DATA pReadCapacityData;
		pReadCapacityData = (PREAD_CAPACITY_DATA) pbData;
		// -1 to return last addressable
		if(g_dwLunType[dwLUN] ||!g_dwRemovable[0])
			pReadCapacityData->LastLogicalBlockAddress = ByteSwapUlong(g_diDiskInfo[dwLUN].di_total_sectors - 1);
		else //NAND
			pReadCapacityData->LastLogicalBlockAddress = ByteSwapUlong(dwSectorNumber[g_dwPartition]-1);

		// pack block length in bytes
		pReadCapacityData->BlockLength = ByteSwapUlong(BytesPerSector(dwLUN));

		dwResult = EXECUTE_PASS;
	}

EXIT:;
    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiStartStop
//     Process a SCSI-2 START STOP command
//
// Parameters:
//     ptcCommand - command block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiStartStop(
    PTRANSPORT_COMMAND ptcCommand
    )
{
    SETFNAME(_T("ProcessScsiStartStop"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    DWORD dwResult = EXECUTE_FAIL;

	DWORD dwLUN = ptcCommand->dwLun;

	RETAILMSG(1,(TEXT("ProcessScsiStartStop [%d]\n"),dwLUN ));
	if ( (g_dwLunType[dwLUN]&0xF) ) // not nand 
	{
		g_dwSCSISTARTSTOP[dwLUN]=1;
		g_bSendChangeStatue[dwLUN]=0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}
	else
	{
		g_dwSCSISTARTSTOP[dwLUN]=1;
		g_bSendChangeStatue[dwLUN]=0;
		g_bIsChangeSDState[dwLUN]=1;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}
#if 0

    if (pbCommand[4] & 0x02) {
        // LoEj = 1
        if (pbCommand[4] & 0x01) {
            // Start = 1
            // load medium
            DEBUGMSG(ZONE_COMMENT, (_T("%s load medium\r\n"), pszFname));
        }
        else {
            // Start = 0
            // unload medium
            DEBUGMSG(ZONE_COMMENT, (_T("%s unload medium\r\n"), pszFname));
        }
    }
    else {
        // LoEj = 0
        if (pbCommand[4] & 0x01) {
            // Start = 1
            // start medium
            DEBUGMSG(ZONE_COMMENT, (_T("%s start medium\r\n"), pszFname));
        }
        else {
            // Start = 0
            // stop medium
            DEBUGMSG(ZONE_COMMENT, (_T("%s stop medium\r\n"), pszFname));
        }
    }
#endif
EXIT:;
    dwResult = EXECUTE_PASS;

    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiWrite10
//     Process a SCSI-2 WRITE (10) command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiWrite10(
    PTRANSPORT_COMMAND ptcCommand,
    PTRANSPORT_DATA ptdData
    )
{
    SETFNAME(_T("ProcessScsiWrite10"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    PBYTE pbData = (PBYTE) ptdData->DataBlock;
    DWORD dwLogicalBlockAddress;
    DWORD dwTransferLength;
    DWORD dwResult = EXECUTE_FAIL;

    SG_REQ sgSgReq;
    SG_BUF sgSgBuf;
    DWORD dwBytesReturned;
    BOOL fResult = FALSE;

    DWORD dwIndex;

    PUFI_CB pUfiCb = (PUFI_CB) pbCommand;
    DEBUGCHK(pUfiCb->bReserved1 == 0);

	DWORD dwLUN = ptcCommand->dwLun;

	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}
	if(!g_dwLunType[dwLUN])
	{
		g_NandRead=TRUE;
	}
	if(g_dwSCSISTARTSTOP[dwLUN])
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{

		// test if logical block address is valid
		if(g_dwLunType[dwLUN] ||!g_dwRemovable[0])
			dwLogicalBlockAddress = ByteSwapUlong(pUfiCb->dwLogicalBlockAddress);
		else //nand
			dwLogicalBlockAddress = ByteSwapUlong(pUfiCb->dwLogicalBlockAddress)+dwStartSector[g_dwPartition];

		// test if transfer length is valid
		dwTransferLength = ByteSwapUshort(pUfiCb->wTransferLength);

		DEBUGMSG(ZONE_COMMENT, (_T(
			"%s starting LBA/sector = %u, transfer length = %u (sectors)\r\n"
			), pszFname, dwLogicalBlockAddress, dwTransferLength));

		ptdData->TransferLength = dwTransferLength * BytesPerSector(dwLUN);

		// is the host attempting to overwrite the virtual disk's MBR?
		if ((dwLogicalBlockAddress == 0) && (g_lpbMBR != NULL)) {
			DEBUGMSG(ZONE_COMMENT, (_T(
				"%s write request targeting virtual disk's MBR; virtual disk's MBR is write-protected\r\n"
				), pszFname));
			dwResult = EXECUTE_FAIL;
			goto EXIT;
		}

		// if partitions being exposed selectively, then an unexposed partition
		// appears as unallocated space to the host; we want to prevent access to
		// unexposed partitions; ensure write request does not target a sector in
		// an unexposed partition

		// are partitions being exposed selectively?
		if (g_lpbMBR != NULL) {

			// cycle through bit mast of partitions selected for exposure; (0
			// denotes an unexposed partition)
			for (dwIndex = 0; dwIndex < MAX_PARTTABLE_ENTRIES; dwIndex += 1) {

				if ((g_bmPartitions & (1 << dwIndex)) == 0) {

					// this partition is unexposed

					// fetch corresponding partition table entry
					PPARTENTRY pPartEntry = (PPARTENTRY) ((g_lpbPhysMBR + PARTTABLE_OFFSET) + (dwIndex * sizeof(PARTENTRY)));

					// determine whether the current write request lies in the
					// range of the unexposed partition
					if ((dwLogicalBlockAddress >= pPartEntry->Part_StartSector) &&
						(dwLogicalBlockAddress <= (pPartEntry->Part_StartSector + pPartEntry->Part_TotalSectors))
					) {
						DEBUGMSG(ZONE_COMMENT, (_T(
							"%s write request targets unexposed partition\r\n"
							), pszFname));
						dwResult = EXECUTE_FAIL;
						goto EXIT;
					}
				}
			}
		}

		// prepare scatter/gather buffer
		sgSgBuf.sb_buf = (PBYTE) pbData;
		sgSgBuf.sb_len = ptdData->TransferLength;

		// prepare scatter/gather request
		sgSgReq.sr_start = dwLogicalBlockAddress;
		sgSgReq.sr_num_sec = dwTransferLength;
		sgSgReq.sr_status = 0;
		sgSgReq.sr_callback = NULL;
		sgSgReq.sr_num_sg = 1;
		sgSgReq.sr_sglist[0] = sgSgBuf;
	    
		DWORD dwIoControlCode = (g_fLegacyBlockDriver[dwLUN]) ? DISK_IOCTL_WRITE : IOCTL_DISK_WRITE;
		fResult = DeviceIoControl(
			g_hStore[dwLUN],
			dwIoControlCode,
			&sgSgReq,
			sizeof(sgSgReq),
			NULL,
			0,
			&dwBytesReturned,
			NULL);
		if (fResult) {
			DEBUGMSG(ZONE_COMMENT, (_T(
				"%s IOCTL_DISK_WRITE passed; %u bytes read\r\n"
				), pszFname, dwBytesReturned));
		}
		else {
			DWORD dwError = GetLastError();
			DEBUGMSG(ZONE_ERROR, (_T("%s IOCTL_DISK_WRITE failed; error = %u\r\n"
			), pszFname, dwError));
			goto EXIT;
		}

		dwResult = EXECUTE_PASS;
	}

EXIT:;
    return dwResult;
}
// ----------------------------------------------------------------------------
// Function: ProcessScsiWrite12
//     Process a SCSI-2 WRITE (12) command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiWrite12(
				   PTRANSPORT_COMMAND ptcCommand,
				   PTRANSPORT_DATA ptdData
				   )
{
	SETFNAME(_T("ProcessScsiWrite12"));

	PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
	PBYTE pbData = (PBYTE) ptdData->DataBlock;
	DWORD dwResult = EXECUTE_FAIL;

	DWORD dwLUN = ptcCommand->dwLun;

	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}

	if(g_dwSCSISTARTSTOP[dwLUN])
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{
		SetSenseKey(dwLUN,SENSE_ILLEGAL_REQUEST,ASC_INVALID_COMMAND_OPERATION);
	}


EXIT:;
	return dwResult;
}
// ----------------------------------------------------------------------------
// Function: ProcessScsiPreventAllowMediumRemoval
//     Process a SCSI-2 PREVENT ALLOW MEDIUM REMOVAL command
//
// Parameters:
//     ptcCommand - command block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiPreventAllowMediumRemoval(
    PTRANSPORT_COMMAND ptcCommand
    )
{
    SETFNAME(_T("ProcessScsiPreventAllowMediumRemoval"));

    const BYTE bPreventBit = 0x01;
    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    DWORD dwResult = EXECUTE_FAIL;

	DWORD dwLUN = ptcCommand->dwLun;

	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}

	if(g_dwSCSISTARTSTOP[dwLUN])
	{
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{

		// test if prevent bit high
		if (pbCommand[4] & bPreventBit) {
			DEBUGMSG(ZONE_COMMENT, (_T("%s prevent enabled\r\n"), pszFname));
		}
		else {
			DEBUGMSG(ZONE_COMMENT, (_T("%s prevent disabled\r\n"), pszFname));
		}

		dwResult = EXECUTE_PASS;
	}
EXIT:;
    return dwResult;
}

// ----------------------------------------------------------------------------
// Function: ProcessScsiVerify
//     Process a SCSI-2 VERIFY command
//
// Parameters:
//     ptcCommand - command block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiVerify(
    PTRANSPORT_COMMAND ptcCommand
    )
{
    SETFNAME(_T("ProcessScsiVerify"));

    PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
    DWORD dwResult = EXECUTE_FAIL;

	DWORD dwLUN = ptcCommand->dwLun;

	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}
	if(g_dwSCSISTARTSTOP[dwLUN])
	{
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{
		DEBUGMSG(ZONE_COMMENT, (_T(
			"%s DPO = %u; BytChk = %u; RelAdr = %u\r\n"),
			pszFname,
			pbCommand[1] & (1 << 4), // DPO bit
			pbCommand[1] & (1 << 1), // BytChk bit
			pbCommand[1] & (1 << 0)  // RelAdr
			));

		// fake the verification
		dwResult = EXECUTE_PASS;
	}
EXIT:;
    return dwResult;
}
// ----------------------------------------------------------------------------
// Function: ProcessScsiReadFormatCapacity
//     Process a SCSI-2 READ FORMAT CAPACITY command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

static
DWORD
ProcessScsiReadFormatCapacity(
							  PTRANSPORT_COMMAND ptcCommand,
							  PTRANSPORT_DATA ptdData
							  )
{
	SETFNAME(_T("ProcessScsiReadFormatCapacity"));

	PBYTE pbCommand = (PBYTE) ptcCommand->CommandBlock;
	PBYTE pbData = (PBYTE) ptdData->DataBlock;
	DWORD dwResult = EXECUTE_FAIL;
	DWORD dwLUN = ptcCommand->dwLun;

	SetSenseKey(dwLUN,SENSE_ILLEGAL_REQUEST,ASC_INVALID_COMMAND_OPERATION);
	goto EXIT;


	if ( (g_dwLunType[dwLUN]&0xF) && (g_dwLunStatus[dwLUN]) ) // not nand and none insert status
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
		goto EXIT;
	}


	if(g_dwSCSISTARTSTOP[dwLUN])
	{
		ptdData->TransferLength = 0;
		SetSenseKey(dwLUN,SENSE_NOT_READY,ASC_MEDIUM_NOT_PRESENT);
	}
	else
	{

		// test if data block is large enough
		if (ptdData->RequestLength < sizeof(READ_FORMAT_CAPACITY_DATA)) {
			DEBUGMSG(ZONE_ERROR, (_T(
				"%s host requesting less than required; ptdData->RequestLength < %u\r\n"
				), pszFname, sizeof(READ_FORMAT_CAPACITY_DATA)));
			goto EXIT;
		}

		ZeroMemory(pbData, ptdData->RequestLength);
		ptdData->TransferLength = sizeof(READ_FORMAT_CAPACITY_DATA);

		// pack logical block address
		PREAD_FORMAT_CAPACITY_DATA pReadFormatCapacityData;
		pReadFormatCapacityData = (PREAD_FORMAT_CAPACITY_DATA) pbData;

		pReadFormatCapacityData->DataLength = ByteSwapUlong(sizeof(READ_CAPACITY_DATA));
		// -1 to return last addressable

		if(g_dwLunType[dwLUN] ||!g_dwRemovable[0])
			pReadFormatCapacityData->CapacityData.LastLogicalBlockAddress = ByteSwapUlong(g_diDiskInfo[dwLUN].di_total_sectors - 1);
		else //nand
			pReadFormatCapacityData->CapacityData.LastLogicalBlockAddress = ByteSwapUlong(dwSectorNumber[g_dwPartition]-1);
		// pack block length in bytes
		pReadFormatCapacityData->CapacityData.BlockLength = ByteSwapUlong(BytesPerSector(dwLUN));


		dwResult = EXECUTE_PASS;
	}
EXIT:;
	return dwResult;
}
// ----------------------------------------------------------------------------
// Function: STORE_Init
//     Initialize SCSI-2 direct-access device emulator
//
// Parameters:
//     pszContext - driver's configuration key
// ----------------------------------------------------------------------------

DWORD
STORE_Init(
    LPCTSTR pszActiveKey
    )
{
    SETFNAME(_T("STORE_Init"));

    HKEY hKey = NULL;
    DWORD cbData;
    DWORD dwError;
    DWORD dwType;
    BOOL fResult;
    DWORD dwBytesReturned;

    FUNCTION_ENTER_MSG();


    // mark self as uninitialized
	for(int k=0; k<MAX_LUN; k++)
		g_fInitialized[k] = FALSE;

    // open the client driver key
    hKey = OpenDeviceKey(pszActiveKey);
    if (hKey == NULL) {
        dwError = GetLastError();
        DEBUGMSG(ZONE_ERROR, (_T(
            "%s Failed to open device key for \"%s\"; Error = %u\r\n"
            ), pszFname, pszActiveKey, dwError));
        goto EXIT;
    }
	//read Manufacturer, Product

	memset(g_dwManufacture,0x00,32);
	memset(g_dwProductID,0x00,32);
	cbData = sizeof(g_dwProductID);
	dwError = RegQueryValueEx(hKey, PRX_PRODUCT, NULL, &dwType, (PBYTE) g_dwProductID, &cbData);
	if ( (dwError != ERROR_SUCCESS) || (dwType != REG_SZ) ) {
		DEBUGMSG(ZONE_WARNING, (_T(
			"%s Failed to read %s; error = %u\r\n"
			), pszFname, PRX_PRODUCT, dwError));
	}

	cbData = sizeof(g_dwManufacture);
	dwError = RegQueryValueEx(hKey, PRX_MANUFACTURE, NULL, &dwType, (PBYTE) g_dwManufacture, &cbData);
	if ( (dwError != ERROR_SUCCESS) || (dwType != REG_SZ) ) {
		DEBUGMSG(ZONE_WARNING, (_T(
			"%s Failed to read %s; error = %u\r\n"
			), pszFname, PRX_MANUFACTURE, dwError));
	}
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("[OTGDEVICE   ]Manufacturer[%s] Product[%s]\n"),g_dwManufacture,g_dwProductID));

	for(int i =0; i < MAX_LUN; i++)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("[OTGDEVIC   ]UMS LUN setting %d start..\n"),i));
		g_dwSCSISTARTSTOP[i]=0;
		// read name of store to expose
		cbData = sizeof(g_szDeviceName[i]);
		dwError = RegQueryValueEx(hKey, DEVICE_NAME_VAL[i], NULL, &dwType, (PBYTE) g_szDeviceName[i], &cbData);
		if ((dwError != ERROR_SUCCESS) || (dwType != REG_SZ)) {
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T(
				"%s Failed to read.. %s; error = %u\r\n"
				), pszFname, DEVICE_NAME_VAL[i], dwError));
			//goto EXIT;
			break;
		}
		g_szDeviceName[i][dim(g_szDeviceName[i]) - 1] = 0; // force null-termination
		DEBUGMSG(ZONE_INIT, (_T(
			"%s %s = %s\r\n"
			), pszFname, DEVICE_NAME_VAL[i], g_szDeviceName[i]));

		// g_szDeviceName should be a valid stream name, e.g., "DSK1:"
		if (_tcslen(g_szDeviceName[i]) > PRX_STREAM_NAME_LEN) {
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T(
				"%s %s is not a valid stream name\r\n"
				), pszFname, g_szDeviceName[i]));
			goto EXIT;
		}
		// read Lun Type
		cbData = sizeof(DWORD);
		dwError = RegQueryValueEx(hKey, DEVICE_TYPE_VAL[i], NULL, &dwType, (PBYTE) &g_dwLunType[i], &cbData);
		if ( (dwError != ERROR_SUCCESS) || (dwType != REG_DWORD) ) {
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T(
				"%s %s not present; default is true\r\n"
				), pszFname, DEVICE_TYPE_VAL[i], dwError));
		}
		DEBUGMSG(ZONE_INIT, (_T(
			"%s %s = %u\r\n"
			), pszFname, DEVICE_TYPE_VAL[i], g_dwLunType[i]));

		// read removable media flag; default is true if flag not present
		cbData = sizeof(DWORD);
		dwError = RegQueryValueEx(hKey, DEVICE_RMB_VAL[i], NULL, &dwType, (PBYTE) &g_dwRemovable[i], &cbData);
		if ( (dwError != ERROR_SUCCESS) || (dwType != REG_DWORD) ) {
			DEBUGMSG(ZONE_WARNING, (_T(
				"%s %s not present; default is true\r\n"
				), pszFname, DEVICE_RMB_VAL[i], dwError));
		}
		DEBUGMSG(ZONE_INIT, (_T(
			"%s %s = %u\r\n"
			), pszFname, DEVICE_RMB_VAL[i], g_dwRemovable[i]));
		
		if(g_dwLunType[i]&0xF) //0x00-nand , 0x01-sdmmc, 0x10 - sata
		{
		
			
			// read handle name for check insert status
			cbData = sizeof(g_szHandleName[i]);
			dwError = RegQueryValueEx(hKey, DEVICE_HANDLE_VAL[i], NULL, &dwType, (PBYTE) g_szHandleName[i], &cbData);
			if ((dwError != ERROR_SUCCESS) || (dwType != REG_SZ)) {
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T(
					"%s Failed to read.,. %s; error = %u\r\n"
					), pszFname, DEVICE_NAME_VAL[i], dwError));
				//goto EXIT;
				break;
			}
			g_szHandleName[i][dim(g_szHandleName[i]) - 1] = 0; // force null-termination
			DEBUGMSG(ZONE_INIT, (_T(
				"%s %s = %s\r\n"
				), pszFname, DEVICE_NAME_VAL[i], g_szHandleName[i]));

			// g_szHandleName should be a valid stream name, e.g., "SHC1:"
			if (_tcslen(g_szHandleName[i]) > PRX_STREAM_NAME_LEN) {
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR),  (_T(
					"%s %s is not a valid stream name\r\n"
					), pszFname, g_szHandleName));
				goto EXIT;
			}
			//open handle for sd
			hHandleofLun[i] = CreateFile(g_szHandleName[i],
				GENERIC_READ | GENERIC_WRITE,
				0,
				0,
				OPEN_EXISTING,
				FILE_ATTRIBUTE_NORMAL,
				NULL);
			
			IsSdCardExist(i);
			if(g_dwLunStatus[i]) //0- exists, 1- none exists
			{
				g_bmPartitions = 0x0F;
				g_fInitialized[i] = TRUE;
				g_LunCount++;
				dwError = ERROR_SUCCESS;
				DEBUGMSG(ZONE_COMMENT,(TEXT("Media not ready. but success\n")));
				continue;
			}
		}
	
		
		// open store
		g_hStore[i] = OpenStore(g_szDeviceName[i]);
		if ((g_hStore[i] == NULL) || (g_hStore[i] == INVALID_HANDLE_VALUE)) {
			dwError = GetLastError();
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T(
				"%s failed to open store %s; error = %u\r\n"
				), pszFname, g_szDeviceName[i], dwError));
			if(g_dwLunType[i]&0xF) // this case is removale disk so, don't need open store
			{
				g_bmPartitions = 0x0F;
				g_fInitialized[i] = TRUE;
				g_LunCount++;
				dwError = ERROR_SUCCESS;
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T(
				"%s SDMMC Not Insert..\r\n"
				), pszFname, g_szDeviceName[i], dwError));

				continue;
			}
			else
				goto EXIT;
		}
		DEBUGMSG(ZONE_COMMENT, (_T("%s opened store %s\r\n"), pszFname, g_szDeviceName[i]));

		// read disk information for check MBR
		fResult = DeviceIoControl(
			g_hStore[i],
			IOCTL_DISK_GETINFO,
			NULL,
			0,
			&g_diDiskInfo[i],
			sizeof(g_diDiskInfo[i]),
			&dwBytesReturned,
			NULL);
		if (fResult) {
			DEBUGMSG(ZONE_INIT, (_T("%s IOCTL_DISK_GETINFO passed\r\n"), pszFname));
			DUMP_DISKINFO(g_diDiskInfo[i]);
		}
		else {

			dwError = GetLastError();
			DEBUGMSG(ZONE_ERROR, (_T(
				"%s IOCTL_DISK_GETINFO failed; error = %u\r\n"
				), pszFname, dwError));

			// is this a legacy block driver?
			fResult = DeviceIoControl(
				g_hStore[i],
				DISK_IOCTL_GETINFO,
				&g_diDiskInfo[i],
				sizeof(g_diDiskInfo[i]),
				NULL,
				0,
				&dwBytesReturned,
				NULL);
			if (fResult) {
				DEBUGMSG(ZONE_INIT, (_T("%s DISK_IOCTL_GETINFO passed\r\n"), pszFname));
				DUMP_DISKINFO(g_diDiskInfo[i]);
				g_fLegacyBlockDriver[i] = TRUE; // legacy block driver
			}
			else {
				dwError = GetLastError();
				DEBUGMSG(ZONE_ERROR, (_T(
					"%s DISK_IOCTL_GETINFO failed; error = %u\r\n"
					), pszFname, dwError));
				goto EXIT;
			}
		}

		if(!(g_dwLunType[i]&0xF) && g_dwRemovable[i] ) //nand or sata
		{
			
			if(g_dwLunType[i]==0) //nand
			{	g_nand_index=i;
				//need for 4cs nand
				{
					DWORD dwIoControlCode = DISK_SET_ALIGN_CACHE ;
					DWORD dwTemp=TRUE;
					fResult = DeviceIoControl(
						g_hStore[i],
						dwIoControlCode,
						&dwTemp,
						sizeof(DWORD),
						NULL,
						0,
						&dwBytesReturned,
						NULL);
					if (fResult) {
						DEBUGMSG(ZONE_WARNING, (_T(
						"%s %s error DISK_SET_ALIGN_CACHE on Command \r\n"
						), pszFname, PRX_PARTITION, dwError));
					}
				}
				// end of 4cs
			}
			cbData = sizeof(g_dwPartition);
			dwError = RegQueryValueEx(hKey, PRX_PARTITION, NULL, &dwType, (PBYTE) &g_dwPartition, &cbData);
			if ( (dwError != ERROR_SUCCESS) || (dwType != REG_DWORD) ) {
				DEBUGMSG(ZONE_WARNING, (_T(
					"%s %s not present; default is 0 \r\n"
					), pszFname, PRX_PARTITION, dwError));
			}
			

			// Parsing MBR Information
			SG_REQ sgSgReq;
			SG_BUF sgSgBuf;
			DWORD pbDataSize=512;
			BYTE pbData[512];
			// prepare scatter/gather buffer
			sgSgBuf.sb_buf = pbData;
			sgSgBuf.sb_len = pbDataSize;

			// prepare scatter/gather request
			sgSgReq.sr_start = 0;
			sgSgReq.sr_num_sec = 1;
			sgSgReq.sr_status = 0;
			sgSgReq.sr_callback = NULL;
			sgSgReq.sr_num_sg = 1;
			sgSgReq.sr_sglist[0] = sgSgBuf;

			// read from device
			DWORD dwIoControlCode = DISK_IOCTL_READ ;
			fResult = DeviceIoControl(
				g_hStore[i],
				dwIoControlCode,
				&sgSgReq,
				sizeof(sgSgReq),
				NULL,
				0,
				&dwBytesReturned,
				NULL);
			if (fResult) {
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s IOCTL_DISK_READ passed; %u bytes read\r\n"), pszFname, dwBytesReturned));

				g_dwMaxPartition=0;
				for(int i=0; i <4 ;i++)
				{
					dwStartSector[i] |= (pbData[454+i*16]&0xFF);
					dwStartSector[i] |= (pbData[455+i*16]&0xFF)<< 8;
					dwStartSector[i] |= (pbData[456+i*16]&0xFF)<< 16;
					dwStartSector[i] |= (pbData[457+i*16]&0xFF)<< 24;

					dwSectorNumber[i]  |= (pbData[458+i*16]&0xFF);
					dwSectorNumber[i]  |= (pbData[459+i*16]&0xFF)<< 8;
					dwSectorNumber[i]  |= (pbData[460+i*16]&0xFF)<< 16;
					dwSectorNumber[i]  |= (pbData[461+i*16]&0xFF)<< 24;


					if(0 != dwStartSector[i])
						g_dwMaxPartition++;
					
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("[OTGDEVICE   ]MBR Information[%d][%d][%d] \r\n"), dwStartSector[i], dwSectorNumber[i],g_dwMaxPartition));
				}
				if(g_dwPartition > g_dwMaxPartition-1)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("[OTGDEVICE   ][%d] Partition is not Available change default Partition to [0] \r\n"),g_dwPartition ));
					g_dwPartition=0;
				}

			}
			else {
				DWORD dwError = GetLastError();
				RETAILMSG(0, (_T("[OTGDEVICE   ]%s IOCTL_DISK_READ failed; error = %u\r\n"), pszFname, dwError));

			}

		}
		

		if((g_dwLunType[i]) && !(g_dwRemovable[i]) )//include nand removable set 0
		{
			// dismount entire store (all partitions)
			if (!DismountStore(g_hStore[i])) {
				dwError = GetLastError();
				goto EXIT;
			}
		}
		else
		{
			pPartInfo.cbSize = sizeof(PARTINFO);
			HANDLE hSearchHandle = FindFirstPartition(g_hStore[i],&pPartInfo);
			RETAILMSG(1,(TEXT("[%s]\n"),pPartInfo.szPartitionName));
			for(unsigned int k=0; k < g_dwPartition; k++)
			{	
				FindNextPartition(hSearchHandle,&pPartInfo);
				RETAILMSG(1,(TEXT("[%s]\n"),pPartInfo.szPartitionName));
			}
			HANDLE hPartition = OpenPartition(g_hStore[i], pPartInfo.szPartitionName);
			RETAILMSG(1,(TEXT("[%s]\n"),pPartInfo.szPartitionName,hPartition));
			DismountPartition(hPartition);
		}
		g_bmPartitions = 0x0F;
		g_fInitialized[i] = TRUE;
		g_LunCount++;
		dwError = ERROR_SUCCESS;
	}
EXIT:;
   // if (!g_fInitialized[i]) {
	if(g_LunCount <=0){
        STORE_Close();
    }
	else dwError = ERROR_SUCCESS;

    CLOSE_KEY(hKey);
    FUNCTION_LEAVE_MSG();
    return dwError;
}

// ----------------------------------------------------------------------------
// Function: STORE_Close
//     Close SCSI-2 direct-access device emulator; unitialize, close associated
//     store, and remount exposed partitions
//
// Parameters:
//     None
// ----------------------------------------------------------------------------

DWORD
STORE_Close(
    )
{
    SETFNAME(_T("STORE_Close"));
    FUNCTION_ENTER_MSG();

	

    DWORD dwRet = ERROR_SUCCESS;
    TCHAR szFullDeviceName[32] = {
        '\\', 'S', 't', 'o', 'r', 'e', 'M', 'g', 'r', '\\'
        };
    ULONG ulFullDeviceNameIndex = 10;

	for(unsigned int i=0; i < g_LunCount; i++)
	{
		//close handle
		CloseHandle(hHandleofLun[i]);

		
		//need for 4cs nand
		if(!(g_dwLunType[i])){ //nand
			DWORD dwIoControlCode = DISK_SET_ALIGN_CACHE ;
			DWORD dwTemp=FALSE;
			DWORD fResult=0;
			DWORD dwBytesReturned=0;
			fResult = DeviceIoControl(
				g_hStore[i],
				dwIoControlCode,
				&dwTemp,
				sizeof(DWORD),
				NULL,
				0,
				&dwBytesReturned,
				NULL);
			if (fResult) {
				DEBUGMSG(ZONE_WARNING, (_T(
				"%s %s error DISK_SET_ALIGN_CACHE on Command \r\n"
				), pszFname, PRX_PARTITION, fResult));
			}
		}
		// end of 4cs


		if ((g_hStore[i] != NULL) && (g_hStore[i] != INVALID_HANDLE_VALUE)) {

			// a virtual MBR does not exist

			// dismount store; this isn't strictly necessary, as the store should
			// already be dismounted
			if(!(g_dwLunType[i])) //if Nand
			{
			   pPartInfo.cbSize= sizeof(PARTINFO);
			   HANDLE hSearchHandle = FindFirstPartition(g_hStore[i],&pPartInfo);
			   RETAILMSG(1,(TEXT("[%s]\n"),pPartInfo.szPartitionName));
			   for(unsigned int k=0; k < g_dwPartition; k++)
			   { 
				   FindNextPartition(hSearchHandle,&pPartInfo);
					RETAILMSG(1,(TEXT("[%s]\n"),pPartInfo.szPartitionName));
				}

			   HANDLE hPartition = OpenPartition(g_hStore[i], pPartInfo.szPartitionName);
			   RETAILMSG(1,(TEXT("[%s]\n"),pPartInfo.szPartitionName,hPartition));
			   MountPartition(hPartition);

			   CLOSE_HANDLE(hSearchHandle);
			   CLOSE_HANDLE(hPartition);    

			}
			else
			{
				DismountStore(g_hStore[i]);
				CLOSE_HANDLE(g_hStore[i]);
				g_hStore[i] = NULL;
			

				// append g_szDeviceName to "\\StoreMgr\\" to get full device name
				ULONG ulDeviceNameChars = _tcslen(g_szDeviceName[i]);
				DEBUGCHK(ulDeviceNameChars <= PRX_STREAM_NAME_LEN);
				for (ULONG ul = 0; ul < ulDeviceNameChars; ul += 1) {
					szFullDeviceName[ulFullDeviceNameIndex + ul] = g_szDeviceName[i][ul];
				}

				// force re-examination of disk's organization
				DEBUGMSG(ZONE_COMMENT, (_T(
					"%s forcing storage manager to re-examine %s\r\n"
					), pszFname, szFullDeviceName));
				if (!MoveFile(szFullDeviceName, szFullDeviceName)) {
					DEBUGMSG(ZONE_COMMENT, (_T(
						"%s failed to force storage manager to re-examine %s\r\n"
						), pszFname, szFullDeviceName));
				}
			}

			
		}
		
	}
	//reset g_LunCount value
	g_LunCount=0;
    // clean up emulator

    // deallocate list of partition names
    LOCAL_FREE(g_ptcPartitions);
    g_ptcPartitions = NULL;

    // deallocate virtual disk's MBR
    LOCAL_FREE(g_lpbMBR);
    g_lpbMBR = NULL;

    // deallocate copy of actual disk's MBR
    LOCAL_FREE(g_lpbPhysMBR);
    g_lpbPhysMBR = NULL;

    g_bmPartitions = 0;
    
	for(unsigned int i=0; i < g_LunCount; i++)
	{
		g_fLegacyBlockDriver[i] = FALSE;
		g_fInitialized[i] = FALSE;
	}

    FUNCTION_LEAVE_MSG();

    return dwRet;
}

// ----------------------------------------------------------------------------
// Function: STORE_IsCommandSupported
//     Determine whether a SCSI-2 command is supported by the SCSI-2
//     direct-access device emulator
//
// Parameters:
//     ptcCommand - command block wrapper
//     pfDataStageRequired - return whether a data stage is required, if
//                           command is supported
//     pdwDirection - return the direction of the command
//     pdwDataSize - return the size of the data stage
// ----------------------------------------------------------------------------

// Determine whether a SCSI-2 command is supported
BOOL
STORE_IsCommandSupported(
    PTRANSPORT_COMMAND ptcCommand,
    PBOOL pfDataStageRequired,
    PDWORD pdwDirection,
    PDWORD pdwDataSize,
	DWORD dwReqDataLen
    )
{
    SETFNAME(_T("STORE_IsCommandSupported"));
    FUNCTION_ENTER_MSG();

    BYTE bOpCode = 0;
    BOOL fResult = TRUE;

    PREFAST_DEBUGCHK(ptcCommand);
    DEBUGCHK(ptcCommand->CommandBlock);
    DEBUGCHK(pfDataStageRequired);
    DEBUGCHK(pdwDirection);
    DEBUGCHK(pdwDataSize);
	
	DWORD dwLUN=ptcCommand->dwLun;

    *pfDataStageRequired = FALSE;
    *pdwDirection = 0;
    *pdwDataSize = 0;
    
    // command/op code is byte 0
    bOpCode = *((PBYTE) ptcCommand->CommandBlock);

    PUFI_CB pUfiCb = (PUFI_CB) ptcCommand->CommandBlock;

    DEBUGMSG(ZONE_COMMENT, (_T("%s command 0x%x\r\n"), pszFname, bOpCode));

    switch (bOpCode) {
        case SCSI_INQUIRY:
            DEBUGMSG(ZONE_COMMENT, (_T("%s INQUIRY\r\n"), pszFname));
            *pfDataStageRequired = TRUE;
            *pdwDirection = DATA_IN;
            *pdwDataSize = DATASIZE_INQUIRY;
            break;
        case SCSI_MODE_SENSE6:
            DEBUGMSG(ZONE_COMMENT, (_T("%s MODE SENSE (6)\r\n"), pszFname));
            *pfDataStageRequired = TRUE;
            *pdwDirection = DATA_IN;
            *pdwDataSize = DATASIZE_MODE_SENSE6;
            break;
        case SCSI_MODE_SENSE10:
            DEBUGMSG(ZONE_COMMENT, (_T("%s MODE SENSE (10)\r\n"), pszFname));
            *pfDataStageRequired = TRUE;
            *pdwDirection = DATA_IN;
            *pdwDataSize = DATASIZE_MODE_SENSE10;
            break;
        case SCSI_REQUEST_SENSE:
            DEBUGMSG(ZONE_COMMENT, (_T("%s REQUEST SENSE\r\n"), pszFname));
            *pfDataStageRequired = TRUE;
            *pdwDirection = DATA_IN;
            *pdwDataSize = DATASIZE_REQUEST_SENSE;
            break;
        case SCSI_SEND_DIAGNOSTIC:
            DEBUGMSG(ZONE_COMMENT, (_T("%s SEND DIAGNOSTIC\r\n"), pszFname));
            break;
        case SCSI_TEST_UNIT_READY:
			{
				if(dwReqDataLen > 0)
				{
					*pfDataStageRequired = TRUE;
					*pdwDirection = DATA_IN;
					*pdwDataSize = dwReqDataLen;
				}
			}
            DEBUGMSG(ZONE_COMMENT, (_T("%s TEST UNIT READY\r\n"), pszFname));
            break;
        case SCSI_READ10:
            DEBUGMSG(ZONE_COMMENT, (_T("%s READ (10)\r\n"), pszFname));
            *pfDataStageRequired = TRUE;
            *pdwDirection = DATA_IN;
            // transfer length is byte 7 + 8
            *pdwDataSize  = ByteSwapUshort(pUfiCb->wTransferLength);
            *pdwDataSize *= BytesPerSector(dwLUN);
            break;
        case SCSI_READ_CAPACITY:
            DEBUGMSG(ZONE_COMMENT, (_T("%s READ CAPACITY\r\n"), pszFname));
            *pfDataStageRequired = TRUE;
            *pdwDirection = DATA_IN;
            *pdwDataSize = sizeof(READ_CAPACITY_DATA);
            break;
        case SCSI_START_STOP:
            DEBUGMSG(ZONE_COMMENT, (_T("%s START STOP\r\n"), pszFname));
            break;
        case SCSI_WRITE10:
            DEBUGMSG(ZONE_COMMENT, (_T("%s WRITE (10)\r\n"), pszFname));
            *pfDataStageRequired = TRUE;
            *pdwDirection = DATA_OUT;
            *pdwDataSize  = ByteSwapUshort(pUfiCb->wTransferLength);
            *pdwDataSize *= BytesPerSector(dwLUN);
            break;
        case SCSI_PREVENT_ALLOW_MEDIUM_REMOVAL:
            DEBUGMSG(ZONE_COMMENT, (_T("%s PREVENT ALLOW MEDIUM REMOVAL\r\n"), pszFname));
            break;
        case SCSI_VERIFY:
            DEBUGMSG(ZONE_COMMENT, (_T("%s VERIFY\r\n"), pszFname));
            break;

        // List of Recognized commands not supported by the USB Mass Function WinCE driver
        case SCSI_MODE_SELECT6:
            fResult = FALSE;
            *pdwDirection = DATA_IN;
            break;
		case SCSI_READ_FORMAT_CAPACITY:
			DEBUGMSG(ZONE_COMMENT, (_T("%s READ FORMAT CAPACITY\r\n"), pszFname));
			*pfDataStageRequired = TRUE;
			*pdwDirection = DATA_IN;
			*pdwDataSize = sizeof(READ_FORMAT_CAPACITY_DATA);
			break;
		case SCSI_READ12:
			*pfDataStageRequired = TRUE;
			*pdwDirection = DATA_IN;
			*pdwDataSize = 0;
			break;
		case SCSI_WRITE12:
			*pfDataStageRequired = TRUE;
			*pdwDirection = DATA_OUT;
			*pdwDataSize  = 0;
			break;
        // Unrecognized commands
        default:
            RETAILMSG(1, (_T("%s unsupported command 0x%x\r\n"),
                pszFname, bOpCode));
            fResult = FALSE;
            *pdwDirection = DATA_UNKNOWN;
            break;
    }

    FUNCTION_LEAVE_MSG();
    return fResult;
}

// ----------------------------------------------------------------------------
// Function: STORE_ExecuteCommand
//     Execute and/or emulate the specified command
//
// Parameters:
//     ptcCommand - command block wrapper
//     ptdData - data block wrapper
// ----------------------------------------------------------------------------

DWORD
STORE_ExecuteCommand(
    PTRANSPORT_COMMAND ptcCommand,
    PTRANSPORT_DATA ptdData
    )
{
    SETFNAME(_T("STORE_ExecuteCommand"));
    FUNCTION_ENTER_MSG();

    DWORD dwResult = EXECUTE_FAIL;
	DWORD dwLUN=ptcCommand->dwLun;

    DEBUGCHK(ptcCommand);
    DEBUGCHK(ptcCommand->CommandBlock);

	//check sdmmc or memory stick insert??
	if(g_dwLunType[dwLUN]&0xF) // don't need check nand type
		IsSdCardExist(dwLUN);


#if 0 //def DEBUG
    {
        BOOL  fDataStageRequired;
        DWORD dwDirection;
        DWORD dwDataSize;
        BOOL fSupported = STORE_IsCommandSupported(ptcCommand,&fDataStageRequired,&dwDirection,&dwDataSize);
        DEBUGCHK(fSupported);
        DEBUGCHK(!fDataStageRequired || (ptdData && ptdData->DataBlock));
    }
#endif

    // command/op code is byte 0
    BYTE bOpCode = ((PBYTE) ptcCommand->CommandBlock)[0];

    DEBUGMSG(ZONE_COMMENT, (_T("%s command 0x%x\r\n"), pszFname, bOpCode));

    switch (bOpCode) {
        case SCSI_INQUIRY:
            DEBUGMSG(ZONE_COMMENT, (_T("%s SCSI INQUIRY\r\n"), pszFname));
            dwResult = ProcessScsiInquiry(ptcCommand, ptdData);
            break;
        case SCSI_MODE_SENSE6:
            DEBUGMSG(ZONE_COMMENT, (_T("%s MODE SENSE (6)\r\n"), pszFname));
            dwResult = ProcessScsiModeSense6(ptcCommand, ptdData);
            break;
        case SCSI_MODE_SENSE10:
            DEBUGMSG(ZONE_COMMENT, (_T("%s MODE SENSE (10)\r\n"), pszFname));
            dwResult = ProcessScsiModeSense10(ptcCommand, ptdData);
            break;
        case SCSI_REQUEST_SENSE:
            DEBUGMSG(ZONE_COMMENT, (_T("%s REQUEST SENSE\r\n"), pszFname));
            dwResult = ProcessScsiRequestSense(ptcCommand, ptdData);
            break;
        case SCSI_SEND_DIAGNOSTIC:
            DEBUGMSG(ZONE_COMMENT, (_T("%s SEND DIAGNOSTIC\r\n"), pszFname));
            dwResult = ProcessScsiSendDiagnostic(ptcCommand);
            break;
        case SCSI_TEST_UNIT_READY:
            DEBUGMSG(ZONE_COMMENT, (_T("%s TEST UNIT READY\r\n"), pszFname));
            dwResult = ProcessScsiTestUnitReady(ptcCommand);
            break;
        case SCSI_READ10:
            DEBUGMSG(ZONE_COMMENT, (_T("%s READ (10)\r\n"), pszFname));
            dwResult = ProcessScsiRead10(ptcCommand, ptdData);
            break;
        case SCSI_READ_CAPACITY:
            DEBUGMSG(ZONE_COMMENT, (_T("%s READ CAPACITY\r\n"), pszFname));
            dwResult = ProcessScsiReadCapacity(ptcCommand, ptdData);
            break;
        case SCSI_START_STOP:
            DEBUGMSG(ZONE_COMMENT, (_T("%s START STOP\r\n"), pszFname));
            dwResult = ProcessScsiStartStop(ptcCommand);
            break;
        case SCSI_WRITE10:
            DEBUGMSG(ZONE_COMMENT, (_T("%s WRITE (10)\r\n"), pszFname));
            dwResult = ProcessScsiWrite10(ptcCommand, ptdData);
            break;
        case SCSI_PREVENT_ALLOW_MEDIUM_REMOVAL:
            DEBUGMSG(ZONE_COMMENT, (_T("%s PREVENT ALLOW MEDIUM REMOVAL\r\n"), pszFname));
            dwResult = ProcessScsiPreventAllowMediumRemoval(ptcCommand);
            break;
        case SCSI_VERIFY:
            DEBUGMSG(ZONE_COMMENT, (_T("%s VERIFY\r\n"), pszFname));
            dwResult = ProcessScsiVerify(ptcCommand);
            break;
		case SCSI_READ_FORMAT_CAPACITY:
			DEBUGMSG(ZONE_COMMENT,(_T("%s READ FORMAT CAPACITY\r\n"), pszFname));
			dwResult = ProcessScsiReadFormatCapacity(ptcCommand, ptdData);
			break;
		case SCSI_READ12:
			dwResult = ProcessScsiRead12(ptcCommand, ptdData);
			break;
		case SCSI_WRITE12:
			dwResult = ProcessScsiWrite12(ptcCommand, ptdData);
			break;
        default:
            DEBUGCHK(FALSE);
            break;
    }

    if (dwResult != EXECUTE_PASS) {
        DEBUGMSG(ZONE_ERROR, (_T(
            "%s failed to execute command 0x%02x\r\n"
            ), pszFname, bOpCode));
    }

    FUNCTION_LEAVE_MSG();

    return dwResult;
}

DWORD
STORE_Check(DWORD command)
{
	if(1 == command)
		return g_NandRead;
	else
		g_NandRead=FALSE;
}

DWORD
STORE_Flush()
{
	DWORD dwIoControlCode = DISK_SET_ALIGN_CACHE ;
	DWORD dwTemp=FALSE;
	DWORD fResult,dwBytesReturned,dwError;
	if(g_nand_index ==0xFF)
		return FALSE;

	if(g_hStore[g_nand_index])
	{
		fResult = DeviceIoControl(
			g_hStore[g_nand_index],
			dwIoControlCode,
			&dwTemp,
			sizeof(DWORD),
			NULL,
			0,
			&dwBytesReturned,
			NULL);
		if (fResult) {
		//	DEBUGMSG(ZONE_WARNING, (_T(
			RETAILMSG(0, (_T(
				"DISK_SET_ALIGN_CACHE off Command \r\n"
				)));
		}

		dwTemp=TRUE;
		fResult = DeviceIoControl(
			g_hStore[g_nand_index],
			dwIoControlCode,
			&dwTemp,
			sizeof(DWORD),
			NULL,
			0,
			&dwBytesReturned,
			NULL);
		if (fResult) {
			//DEBUGMSG(ZONE_WARNING, (_T(
			RETAILMSG(0,(_T(
				"DISK_SET_ALIGN_CACHE on Command [%d]\r\n"
				),GetTickCount()));
		}
		
		return TRUE;
	}

}