// VoidQueue.h /////////////////////////////////////////////////////////////////
#ifndef	_VoidQueue_h_
#define	_VoidQueue_h_

class VoidQueue
{
public:
	//
	// Constructors/Destructor
	//
	VoidQueue();
	~VoidQueue();

	//
	// VoidQueue access
	//
	void push(void *obj);
	void *peek();
	void *pop();
	int Size() {return size;}

	//
	// VoidQueue destruction
	//
	void destroy();

protected:
	//
	// These variables are to keep track of the linked list
	//
	void *head;
	void *tail;

	int size;
};

#endif 