// VoidQueue.cpp ///////////////////////////////////////////////////////////////#include "VoidQueue.h"
#include "memqueue.h"
struct VoidQueuenode
{
	VoidQueuenode	*next;
	void		*obj;
};

//***************************************************************************
// VoidQueue::VoidQueue()
//
VoidQueue::VoidQueue()
{
	head = tail = 0;
	size = 0;
}

//***************************************************************************
// VoidQueue::~VoidQueue()
//
VoidQueue::~VoidQueue()
{
	destroy();
}

//***************************************************************************
// void VoidQueue::destroy()
//
void VoidQueue::destroy()
{
	while (head)
	{
		void	*obj = pop();
		delete obj;
	}
	size = 0;
	head = tail = 0;
}

//***************************************************************************
// void VoidQueue::push(void *obj)
//    Push an object onto the VoidQueue.
//
void VoidQueue::push(void *obj)
{
	VoidQueuenode	*node = new VoidQueuenode;

	node->obj = obj;
	node->next = 0;
	if (tail)
		((VoidQueuenode *) tail)->next = node;
	tail = node;
	if (!head)
		head = tail;
	size++;
}

//***************************************************************************
// void *VoidQueue::pop()
//    Return the object at the head of the VoidQueue and remove it
//
void *VoidQueue::pop()
{
	if (size == 0)
		return 0;

	VoidQueuenode	*node = (VoidQueuenode *) head;
	void		*obj = node->obj;
	head = (void *) node->next;
	delete node;
	size--;

	if (!head)
		tail = 0;
	return obj;
}

//***************************************************************************
// void *VoidQueue::peek()
//    Return the object at the top of the VoidQueue.
//
void *VoidQueue::peek()
{
	if (size == 0)
		return 0;

	return ((VoidQueuenode *)head)->obj;
}

