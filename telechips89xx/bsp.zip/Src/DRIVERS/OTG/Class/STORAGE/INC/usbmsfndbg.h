//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name: 

        USBMSFNDBG.H

Abstract:

        USB Mass Storage Function Driver Debug Data.
        
--*/

#ifndef __USBMSFNDBG_H__
#define __USBMSFNDBG_H__


#include <usbfntypes.h>


#ifndef dim
#define dim(x) (sizeof(x)/sizeof((x)[0]))
#endif


#define UMS_REG_INTERFACE_SUBCLASS_VAL       (_T("InterfaceSubClass"))
#define UMS_REG_INTERFACE_PROTOCOL_VAL       (_T("InterfaceProtocol"))
#define UMS_REG_VENDOR_VAL                   (_T("Vendor"))
#define UMS_REG_PRODUCT_VAL                  (_T("Product"))
#define UMS_REG_BUFFER_VAL                   (_T("InitialDataBufferSize"))
#define UMS_REG_TRANSFER_THREAD_PRIORITY_VAL (_T("TransferThreadPriority"))

#define MASS_STORAGE_INTERFACE_CLASS            0x08
#define SCSI_TRANSPARENT_INTERFACE_SUBCLASS     0x06
#define CBIT_INTERFACE_PROTOCOL                 0x00
#define BOT_INTERFACE_PROTOCOL                  0x50



#ifdef DEBUG

#define ZONE_ERROR              DEBUGZONE(0)
#define ZONE_WARNING            DEBUGZONE(1)
#define ZONE_INIT               DEBUGZONE(2)
#define ZONE_FUNCTION           DEBUGZONE(3)

#define ZONE_COMMENT            DEBUGZONE(4)

extern DBGPARAM dpCurSettings;

#define FUNCTION_ENTER_MSG() RETAILMSG(1, (_T("%s ++\r\n"), pszFname))
#define FUNCTION_LEAVE_MSG() RETAILMSG(1, (_T("%s --\r\n"), pszFname))

#else

#define FUNCTION_ENTER_MSG()
#define FUNCTION_LEAVE_MSG()

#endif // DEBUG

#ifndef SHIP_BUILD
#define STR_MODULE _T("UsbMsFn!")
#define SETFNAME(name) LPCTSTR pszFname = STR_MODULE name _T(":")
#else
#define SETFNAME(name)
#endif // SHIP_BUILD


#endif // __USBMSFNDBG_H__

