#include <windows.h>
#include <stdio.h>
#include <usbfnioctl.h>
#include <svsutil.hxx>


#define ZONE_ERROR 1
#define ZONE_TRACE 1

HANDLE GetUSBfnHandle();
VOID   CloseUfnController(HANDLE hUSBfn);

BOOL USBChangeDriver(PWCHAR pNewDriver)
{
    HANDLE          hUSBfn;
    BOOL            bRet = FALSE;
    UFN_CLIENT_NAME clientDriver;

    hUSBfn = GetUSBfnHandle();
    if (hUSBfn == INVALID_HANDLE_VALUE) {
        return bRet;
    }

	
    if (pNewDriver) {
		wcscpy(clientDriver.szName, pNewDriver);
	} else {
		clientDriver.szName[0]=0;
	}

    bRet = DeviceIoControl(hUSBfn, 
                           IOCTL_UFN_CHANGE_CURRENT_CLIENT, 
                           &clientDriver, 
                           sizeof(clientDriver), 
                           NULL, 
                           0, 
                           NULL,  
                           NULL);
 
    if (bRet) {
#ifndef MDEBUG
        UFN_CLIENT_INFO uClientInfo;
        DWORD           bytesReturned;

        memset(&uClientInfo, 0, sizeof(uClientInfo));
        bRet = DeviceIoControl(hUSBfn, 
                               IOCTL_UFN_GET_CURRENT_CLIENT, 
                               NULL, 
                               0, 
                               &uClientInfo, 
                               sizeof(uClientInfo), 
                               &bytesReturned, 
                               NULL);
        if ((bRet) && (bytesReturned == sizeof(uClientInfo))) {
            if (uClientInfo.szName[0]) {
                RETAILMSG(ZONE_TRACE, (_T("Changed to USB driver %s\n"), uClientInfo.szName));
            } else {
                RETAILMSG(ZONE_TRACE, (_T("No USB driver loaded\n")));
           }   
        } else {
            RETAILMSG(ZONE_ERROR, (_T("Could not get current driver\n")));
        }
#endif
    } else {
        RETAILMSG(ZONE_ERROR, (_T("Change to client driver \"%s\" failed, error %d\n"), pNewDriver, GetLastError()));
    }

    CloseUfnController(hUSBfn);
    return bRet;
}

BOOL USBGetDefaultDriver(PUFN_CLIENT_INFO pDefaultDriver)
{
    HANDLE          hUSBfn;
    DWORD           bytesReturned;
    BOOL            bRet = FALSE;

    hUSBfn = GetUSBfnHandle();
    if (hUSBfn == INVALID_HANDLE_VALUE) {
        return bRet;
    }

    bRet = DeviceIoControl(hUSBfn, 
                           IOCTL_UFN_GET_DEFAULT_CLIENT, 
                           NULL, 
                           0, 
                           pDefaultDriver, 
                           sizeof(*pDefaultDriver), 
                           &bytesReturned, 
                           NULL);

    if (bRet) {
        ASSERT(bytesReturned == sizeof(*pDefaultDriver));
        if (pDefaultDriver->szName[0]) {
            RETAILMSG(ZONE_TRACE, (_T("Default USB client driver is \"%s\" \n"), pDefaultDriver->szName));
        } else {
            RETAILMSG(ZONE_TRACE, (_T("No default USB client driver\r\n")));
        }
    } else {
        RETAILMSG(ZONE_ERROR, (_T("IOCTL_UFN_GET_CURRENT_CLIENT failed, error %d\n"), GetLastError()));
    }

    CloseUfnController(hUSBfn);
    return bRet;
}

BOOL USBListDrivers(PUFN_CLIENT_INFO pDriverList, PDWORD RequestedNumberDrivers) 
{
    HANDLE          hUSBfn;
    UFN_CLIENT_INFO uClientInfo;
    int             bytesReturned;
    DWORD           count;
    BOOL            bRet = FALSE;

    hUSBfn = GetUSBfnHandle();
    if (hUSBfn == INVALID_HANDLE_VALUE) {
        return bRet;
    }
    
    bRet = DeviceIoControl(hUSBfn, 
                          IOCTL_UFN_ENUMERATE_AVAILABLE_CLIENTS_SETUP, 
                          NULL, 
                          0, 
                          NULL, 
                          0, 
                          NULL, 
                          NULL);
    if (bRet == FALSE) {
        RETAILMSG(ZONE_ERROR, (_T("IOCTL_UFN_ENUMERATE_AVAILABLE_CLIENTS_SETUP failed, error %d\n"), GetLastError()));
        return bRet;
    }

    count = 0;
    do {
        
        if (bRet = DeviceIoControl(hUSBfn, 
                                   IOCTL_UFN_ENUMERATE_AVAILABLE_CLIENTS, 
                                   NULL, 
                                   0, 
                                   &uClientInfo, 
                                   sizeof(uClientInfo), 
                                   (PDWORD)&bytesReturned, 
                                   NULL)) {
            ASSERT(bytesReturned == sizeof(uClientInfo));
            RETAILMSG(ZONE_TRACE, (_T("Available Client \"%s\" - %s\n"), uClientInfo.szName, uClientInfo.szDescription));
    
            if (count < *RequestedNumberDrivers) {
                wcscpy(pDriverList[count].szName, uClientInfo.szName);
                wcscpy(pDriverList[count].szDescription, uClientInfo.szDescription);
                count++;
            }
        } else {
            int error = GetLastError();
            if (error != ERROR_NO_MORE_ITEMS) {
                RETAILMSG(ZONE_ERROR, (_T("IOCTL_UFN_ENUMERATE_AVAILABLE_CLIENTS_SETUP failed, error %d\n"), GetLastError()));
            }
        }


    } while (bRet);
    
    if (count > 0) {
        bRet = TRUE;
    }
    *RequestedNumberDrivers = count;
    CloseUfnController(hUSBfn);
    return bRet;
}


BOOL USBCurrentDriver(PUFN_CLIENT_INFO pDriverList) 
{
    HANDLE          hUSBfn;
    DWORD           bytesReturned;
    BOOL            bRet = FALSE;


    hUSBfn = GetUSBfnHandle();
    if (hUSBfn == INVALID_HANDLE_VALUE) {
        return bRet;
    }
    if (bRet = DeviceIoControl(hUSBfn, 
                               IOCTL_UFN_GET_CURRENT_CLIENT, 
                               NULL, 
                               0, 
                               pDriverList, 
                               sizeof(*pDriverList), 
                               &bytesReturned, 
                               NULL)) {
        ASSERT(bytesReturned == sizeof(*pDriverList));
        RETAILMSG(ZONE_TRACE, (_T("Current Client \"%s\" \n"), pDriverList->szName));
    } else {
        RETAILMSG(ZONE_ERROR, (_T("IOCTL_UFN_GET_CURRENT_CLIENT failed, error %d\n"), GetLastError()));

    }
    CloseUfnController(hUSBfn);
    return bRet;
}

BOOL USBChangeDefaultDriver(PWCHAR pNewDefaultDriver)
{
    HANDLE          hUSBfn;
    BOOL            bRet = FALSE;
    UFN_CLIENT_NAME defaultDriver;

    hUSBfn = GetUSBfnHandle();
    if (hUSBfn == INVALID_HANDLE_VALUE) {
        return bRet;
    }
    wcscpy(defaultDriver.szName, pNewDefaultDriver);
    bRet = DeviceIoControl(hUSBfn, 
                           IOCTL_UFN_CHANGE_DEFAULT_CLIENT, 
                           &defaultDriver, 
                           sizeof(defaultDriver), 
                           NULL, 
                           0, 
                           NULL, 
                           NULL);

    CloseUfnController(hUSBfn);

    if (bRet) {
        UFN_CLIENT_INFO defaultDriver;
	if (USBGetDefaultDriver((PUFN_CLIENT_INFO) &defaultDriver)) {
            RETAILMSG(ZONE_TRACE, (_T("Changed Default USB Client driver to \"%s\" \n"), defaultDriver.szName));
	} else {
            RETAILMSG(ZONE_ERROR, (_T("USBGetDefaultDriver() failed\n")));
        }
    } else {
        RETAILMSG(ZONE_ERROR, (_T("IOCTL_UFN_CHANGE_DEFAULT_CLIENT failed, error %d\n"), GetLastError()));
    }
    return bRet;
}


VOID CloseUfnController(HANDLE hUSBfn)
{
    CloseHandle(hUSBfn);
}

HANDLE GetUSBfnHandle()
{
    HANDLE                      hUSBfn = INVALID_HANDLE_VALUE;
    BYTE                        guidBuffer[sizeof(GUID) + 4]; // +4 since scanf writes longs
    LPGUID                      pGuid = (LPGUID) guidBuffer;
    LPCTSTR                     pUSBFnGuid = _T("E2BDC372-598F-4619-BC50-54B3F7848D35");
    DEVMGR_DEVICE_INFORMATION   devInfo;
    HANDLE                      hTemp;
    DWORD                       error;


    error = _stscanf(pUSBFnGuid, SVSUTIL_GUID_FORMAT, SVSUTIL_PGUID_ELEMENTS(&pGuid));
    
    if ((error == 0) || (error == EOF)) {
        RETAILMSG(ZONE_ERROR, (_T("Can not find USB FN GUID!\r\n")));
        return hUSBfn;
    }
    ASSERT(error != 0 && error != EOF);  


    // Get a handle to the bus driver
    memset(&devInfo, 0, sizeof(devInfo));
    devInfo.dwSize = sizeof(devInfo);
    hTemp = FindFirstDevice(DeviceSearchByGuid, pGuid, &devInfo);

    if (hTemp != INVALID_HANDLE_VALUE) {
        hUSBfn = CreateFile(devInfo.szBusName, 
                            GENERIC_READ, 
                            FILE_SHARE_READ, 
                            NULL, 
                            OPEN_EXISTING, 
                            0, 
                            NULL);
    } else {
        RETAILMSG(ZONE_ERROR, (_T("No available UsbFn controller!\r\n")));
    }
    return hUSBfn;
}
