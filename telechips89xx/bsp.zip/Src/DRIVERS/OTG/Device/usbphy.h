/**************************************************************************************
 *
 * FILE NAME   : usbphy.h
 * DESCRIPTION : This is a USB PHY driver source code
 *
 * ====================================================================================
 *
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 * ====================================================================================
 *
 * FILE HISTORY:
 * 	Date: 2009.02.12	Start source coding
 *
 **************************************************************************************/
#ifndef _USBPHY_H
#define _USBPHY_H
#include "usb_manager.h"

typedef enum {
	USBPHY_MODE_RESET,
	USBPHY_MODE_HOST,
	USBPHY_MODE_DEVICE
} USBPHY_MODE_T;

void USBPHY_DEVICE_Detach(void);
void USBPHY_DEVICE_Attach(void);
void USBPHY_EnableClock(void);
void USBPHY_SetMode(USBPHY_MODE_T mode);
extern void USBPHY_SetID(unsigned int ID);

#endif //_USBPHY_H