/**************************************************************************************
 *
 * FILE NAME   : otgcore.h
 * DESCRIPTION : This is a OTG CORE driver source code
 *
 * ====================================================================================
 *
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 * ====================================================================================
 *
 * FILE HISTORY:
 * 	Date: 2009.03.16	Start source coding
 *
 **************************************************************************************/
#ifndef _OTGCORE_H
#define _OTGCORE_H

void OTGCORE_Init(void);
void OTGCORE_SetID(unsigned int ID);
void OTGCORE_Reset(void);

#endif //_OTGCORE_H
