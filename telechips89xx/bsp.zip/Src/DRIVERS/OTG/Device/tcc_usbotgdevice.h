/****************************************************************************
*   FileName    : tcc_usbotgdevice.h
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#ifndef _TCCOTGDEVICE_H_
#define _TCCOTGDEVICE_H_

#include <windows.h>
#include <ceddk.h>
#include <usbfntypes.h>
#include <usbfn.h>
#include <devload.h>
#include <bsp_cfg.h>

#define RegOpenKey(hkey, lpsz, phk) \
        RegOpenKeyEx((hkey), (lpsz), 0, 0, (phk))

#ifndef SHIP_BUILD
#define STR_MODULE _T("[OTGDEVICE   ]")
#define SETFNAME() LPCTSTR pszFname = STR_MODULE _T(__FUNCTION__) _T(":")
#else
#define SETFNAME()
#endif
#define EPCTL  0
#define EPINT  2
#define EPSIZ  4
#define EPDMA  5
#define EPSTS  6

#define EP0_FIFO				0x1000
#define EP1_FIFO				0x2000
#define EP2_FIFO				0x3000
#define EP3_FIFO				0x4000
#define EP4_FIFO				0x5000
#define EP5_FIFO				0x6000
#define EP6_FIFO				0x7000
#define EP7_FIFO				0x8000
#define EP8_FIFO				0x9000
#define EP9_FIFO				0xa000
#define EP10_FIFO				0xb000
#define EP11_FIFO				0xc000
#define EP12_FIFO				0xd000
#define EP13_FIFO				0xe000
#define EP14_FIFO				0xf000
#define EP15_FIFO				0x10000

//
#define BASE_REGISTER_OFFSET        0x0
#define REGISTER_SET_SIZE           0x200


// EP0 CSR
#define EP0_OUT_PACKET_RDY          0x1
#define EP0_IN_PACKET_RDY           0x2
#define EP0_SENT_STALL              0x4
#define DATA_END                    0x8
#define SETUP_END                   0x10
#define EP0_SEND_STALL              0x20
#define SERVICED_OUT_PKY_RDY        0x40
#define SERVICED_SETUP_END          0x80

// IN_CSR1_REG Bit definitions
#define IN_PACKET_READY             0x1
#define UNDER_RUN                   0x4  
#define FLUSH_IN_FIFO               0x8
#define IN_SEND_STALL               0x10
#define IN_SENT_STALL               0x20
#define IN_CLR_DATA_TOGGLE          0x40

// Can be used for Interrupt and Interrupt Enable Reg - common bit def
#define EP0_IN_INT          (0x1<<0)
#define EP1_IN_INT          (0x1<<1)
#define EP2_IN_INT          (0x1<<2)
#define EP3_IN_INT          (0x1<<3)
#define EP4_IN_INT          (0x1<<4)
#define EP5_IN_INT          (0x1<<5)
#define EP6_IN_INT          (0x1<<6)
#define EP7_IN_INT          (0x1<<7)
#define EP8_IN_INT          (0x1<<8)
#define EP9_IN_INT          (0x1<<9)
#define EP10_IN_INT         (0x1<<10)
#define EP11_IN_INT         (0x1<<11)
#define EP12_IN_INT         (0x1<<12)
#define EP13_IN_INT         (0x1<<13)
#define EP14_IN_INT         (0x1<<14)
#define EP15_IN_INT			(0x1<<15)
#define EP0_OUT_INT         (0x1<<16)
#define EP1_OUT_INT         (0x1<<17)
#define EP2_OUT_INT         (0x1<<18)
#define EP3_OUT_INT         (0x1<<19)
#define EP4_OUT_INT         (0x1<<20)
#define EP5_OUT_INT         (0x1<<21)
#define EP6_OUT_INT         (0x1<<22)
#define EP7_OUT_INT         (0x1<<23)
#define EP8_OUT_INT         (0x1<<24)
#define EP9_OUT_INT         (0x1<<25)
#define EP10_OUT_INT        (0x1<<26)
#define EP11_OUT_INT        (0x1<<27)
#define EP12_OUT_INT        (0x1<<28)
#define EP13_OUT_INT        (0x1<<29)
#define EP14_OUT_INT        (0x1<<30)
#define EP15_OUT_INT		(0x1<<31)

// GOTGINT 
#define SesEndDet			(0x1<<2)

// GRSTCTL
#define TxFFlsh				(0x1<<5)
#define RxFFlsh				(0x1<<4)
#define INTknQFlsh			(0x1<<3)
#define FrmCntrRst			(0x1<<2)
#define HSftRst				(0x1<<1)
#define CSftRst				(0x1<<0)

// GINTSTS 
#define INT_RESUME              	(0x1<<31)
#define INT_SSREQ					(0x1<<30)
#define INT_DISCONN              	(0x1<<29)
#define INT_OUT_EP					(0x1<<19)
#define INT_IN_EP					(0x1<<18)
#define INT_SDE                		(0x1<<13)
#define INT_RESET               	(0x1<<12)
#define INT_SUSPEND             	(0x1<<11)
#define INT_TX_FIFO_EMPTY			(0x1<<5)
#define INT_RX_FIFO_NOT_EMPTY		(0x1<<4)
#define INT_SOF						(0x1<<3)
#define INT_OTG						(0x1<<2)

// GOTGCTL
#define B_SESSION_VALID				(0x1<<19)
#define A_SESSION_VALID			(0x1<<18)

// GRX STATUS
#define PKTSTS						(0xF<<17)
#define GLOBAL_OUT_NAK				(0x1<<17)
#define OUT_PKT_RECEIVED			(0x2<<17)
#define OUT_TRF_COMPLETED			(0x3<<17)
#define SETUP_TRANS_COMPLETED		(0x4<<17)
#define SETUP_PKT_RECEIVED			(0x6<<17)

#define SETUPPHASEDONE				(0x1<<3)	//Setup Phase Done Interrupt
#define XFERCOPMPL					(0x1<<0) 	//Transfer Complete Interrupt

#define DEPCTL_SNAK					(0x1<<27)
#define DEPCTL_CNAK					(0x1<<26)

//DIEPINT
#define IN_TKN_RECEIVED				(0x1<<4)
#define TIMEOUT_CONDITION			(0x1<<3)
#define TXFIFOEMPTY					(0x1<<7)
#define TXCOMPLETE					(0x1<<0)

#define IN_EP						0
#define OUT_EP						1

// DCTL
#define SOFT_DISCONNECT				(0x1<<1)
#define CLEAR_GOUTNAK				(0x1<<10)
#define SET_GOUTNAK					(0x1<<9)
#define CLEAR_GNPINNAK				(0x1<<8)
#define SET_GNINNAK					(0x1<<7)
#endif //_TCCOTGDEVICE_H_


