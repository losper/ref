/**************************************************************************************
 *
 * FILE NAME   : otgcore.c
 * DESCRIPTION : This is a OTG CORE driver source code
 *
 * ====================================================================================
 *
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 * ====================================================================================
 *
 * FILE HISTORY:
 * 	Date: 2009.03.16	Start source coding
 *
 **************************************************************************************/
#include "otgcore.h"
#include "otgregs.h"
#include "usb_defs.h"
#include "usb_manager.h"
#include "TCC89x_structures.h"

/* For Signature */
#define OTGCORE_SIGNATURE			'O','T','G','C','O','R','E','_'
#define OTGCORE_VERSION				'V','2','.','0','0','0'
static const unsigned char OTGCORE_C_Version[] = {SIGBYAHONG, OTGCORE_SIGNATURE, SIGN_OS ,SIGN_CHIPSET, OTGCORE_VERSION, NULL};


//#define SLAVE_MODE_INCLUDE
//#define DMA_MODE_INCLUDE

#if defined(SLAVE_MODE_INCLUDE) && defined(DMA_MODE_INCLUDE)
#error alternative definition required!!!
#endif

extern PUSB20OTG	HwUSB20OTG;
extern PUSBOTGCFG	HwUSBOTGCFG;

unsigned char* OTGCORE_TellLibraryVersion(void)
{
	return (unsigned char*)OTGCORE_C_Version;
}

void OTGCORE_Init(void)
{
	// wait AHB idle
	while( !(HwUSB20OTG->GRSTCTL & GRSTCTL_AHBIdle) );

	#if defined(SLAVE_MODE_INCLUDE)
	HwUSB20OTG->GUSBCFG |= GUSBCFG_PHYIf_16BITS|GUSBCFG_TOutCal(7);	// set interface, timeout
	HwUSB20OTG->GOTGCTL |= GOTGCTL_SesReq;	// session request
	HwUSB20OTG->GINTSTS = 0xFFFFFFFF;		// clear interrupts
	HwUSB20OTG->GAHBCFG = GAHBCFG_NPTXFEmpLvl_COMPLETELY|GAHBCFG_GlblIntrMsk_UNMASK;	// enable global interrupt
	#elif defined(DMA_MODE_INCLUDE)
	// device mode
	//HwUSBOTGCFG->OTGID |= OTGID_ID_DEVICE;

	// Core Initialization
	HwUSB20OTG->GINTSTS = 0xFFFFFFFF;		// clear interrupts
	HwUSB20OTG->GAHBCFG = GAHBCFG_DMAEn|GAHBCFG_HBstLen_SINGLE|GAHBCFG_GlblIntrMsk_UNMASK;
	HwUSB20OTG->GUSBCFG |= GUSBCFG_PHYIf_16BITS|GUSBCFG_TOutCal(7);	// set interface, timeout
	//HwUSB20OTG->GUSBCFG = GUSBCFG_USBTrdTim_16BIT_UTMIP|GUSBCFG_PHYIf_16BITS|GUSBCFG_TOutCal(7);
	HwUSB20OTG->GOTGCTL |= GOTGCTL_SesReq;	// session request
	//HwUSB20OTG->GINTMSK = GINTMSK_OTGIntMsk_UNMASK|GINTMSK_ModeMisMsk_UNMASK;
	#endif
}

void OTGCORE_SetID(unsigned int ID)
{
	if( ID )
		HwUSBOTGCFG->OTGID |= OTGID_ID_DEVICE;
	else
		HwUSBOTGCFG->OTGID &= OTGID_ID_HOST;
}

void OTGCORE_Reset(void)
{
	// Core Soft Reset
	HwUSB20OTG->GRSTCTL |= GRSTCTL_CSftRst;
	// wait self clear
	while( (HwUSB20OTG->GRSTCTL & GRSTCTL_CSftRst) != 0 );

	// wait 3 PHY clocks (synchronization delay)
	{
		volatile unsigned int i,cnt=0;
		for(i=0;i<1000000;i++)
			cnt++;
	}

	// wait AHB idle
	while( !(HwUSB20OTG->GRSTCTL & GRSTCTL_AHBIdle) );
}

