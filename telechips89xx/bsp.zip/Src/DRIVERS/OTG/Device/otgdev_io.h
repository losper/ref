/**************************************************************************************
 *
 * FILE NAME   : otgdev_io.h
 * DESCRIPTION : This is OTG device I/O driver source code
 *
 * ====================================================================================
 *
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 * ====================================================================================
 *
 * FILE HISTORY:
 * 	Date: 2009.02.12	Start source coding
 *
 **************************************************************************************/
#ifndef _OTGDEV_IO_H
#define _OTGDEV_IO_H

#include "usb_device.h"

USBDEVICE_IO_DRIVER_T *OTGDEV_IO_GetDriver(void);

#endif //_OTGDEV_IO_H