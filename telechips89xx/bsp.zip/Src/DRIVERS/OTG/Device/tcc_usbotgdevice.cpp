/****************************************************************************
*   FileName    : tcc_usbotgdevice.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/
#include <bsp.h>
#include <nkintr.h>
#include <ddkreg.h>
#include "tcc_usbotgdevice.h"
#include "tcc_ckc.h"
#include "tcc_gpio.h"
#include "TCC_otg.h"
#include "usbphy.h"
#include "otgregs.h"
#include "usb_device.h"
#include "tcc_gpioexp.h"

#define TCC_FUNCTION_ENTER_MSG() RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s ++\r\n"), pszFname))
#define TCC_FUNCTION_LEAVE_MSG() RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s --\r\n"), pszFname))
#define USB_ENDPOINT_DIRECTION_OUT_(addr)          (!((addr) & USB_ENDPOINT_DIRECTION_MASK))


enum EP0_STATE {
	EP0_STATE_SETUP = 0,
	EP0_STATE_IN_DATA_PHASE,
	EP0_STATE_OUT_DATA_PHASE,
	EP0_STATE_STATUS
};

typedef enum
{
	USB_HIGH, USB_FULL, USB_LOW
} USB_SPEED;

#define HOST_ATTACH  0xFFF000
#define IN_TRANSFER  1
#define OUT_TRANSFER 2
#define MAX_ENDPOINT 2
#define MAX_RXDMABUFFSIZE 64*1024
#define MAX_TXDMABUFFSIZE 64*1024


#define EP0_STALL_BITS (EP0_SEND_STALL | EP0_SENT_STALL)

typedef struct EP_STATUS {
	DWORD                   	dwEndpointNumber;
	DWORD                   	dwDirectionAssigned;
	DWORD                   	dwPacketSizeAssigned;
	BOOL                    	fInitialized;
	DWORD                   	dwEndpointType;
	PSTransfer              	pTransfer;
	CRITICAL_SECTION      cs;
} *PEP_STATUS;

#define LOCK_ENDPOINT(peps)     EnterCriticalSection(&peps->cs)
#define UNLOCK_ENDPOINT(peps)  	LeaveCriticalSection(&peps->cs)

#define EP_0_PACKET_SIZE    0x40   
#define ENDPOINT_COUNT  16
#define EP_VALID(x)     ((x) < ENDPOINT_COUNT)
#define DEFAULT_PRIORITY 120

extern tSYSTEM_PARAM *gpPhysicalBOOTARGS;
extern tSYSTEM_PARAM *gpVirtualBOOTARGS;
extern unsigned int OTGDEV_IO_EP_Enable(USBDEV_ENDPOINT_T *pEP, unsigned int enable);

HANDLE  hGXP;
HANDLE  hHCD;
DWORD gMaxPacketSize = 512;

typedef struct CTRL_PDD_CONTEXT {

	PVOID             		pvMddContext;
	DWORD             		dwSig;
	HANDLE            		hIST;
	HANDLE            		hevInterrupt;
	BOOL              		fRunning;
	CRITICAL_SECTION 	csRegisterAccess;
	BOOL              		fSpeedReported;
	BOOL              		fRestartIST;
	BOOL              		fExitIST;
	BOOL					OGBSTATUS;
	BOOL					gRunning;
	BOOL              		attachedState;
	BOOL              		sendDataEnd;
	EP0_STATE         		Ep0State;

	USB_SPEED			eSpeed;
	DWORD				dwEp0MaxPktSize;
	// 
	BOOL				fSetUpPhaseDone;
	DWORD				CntValue;
	DWORD				dwTxBuffSize;
	DWORD				dwRxBuffSize;
	DWORD				dwRxRemainSize;
	DWORD				dwDetectedSpeed;

	// registry
	DWORD             	dwSysIntr;
	DWORD             	dwIrq;
	DWORD             	dwISTPriority;

	USB_DEVICE_REQUEST 	udr;
	DWORD				temp[512];
	EP_STATUS         		rgEpStatus[ENDPOINT_COUNT];

	PFN_UFN_MDD_NOTIFY    	pfnNotify;
	HANDLE                  hBusAccess;
	CEDEVICE_POWER_STATE   	cpsCurrent;

} *PCTRLR_PDD_CONTEXT;

#define TELECHIPS_SIG 'TCC' 

#define IS_VALID_TCC_CONTEXT(ptr) \
	( (ptr != NULL) && (ptr->dwSig == TELECHIPS_SIG) )

////////////////////
//global variable
////////////////////
PUSBOTG		pOTG =NULL;
PUSB20OTG	HwUSB20OTG =NULL;
PUSBOTGCFG  pOTGCFG=NULL;
PUSBOTGCFG  HwUSBOTGCFG=NULL;
PGPIO		pGPIO=NULL;
PPIC		pPIC =NULL;
HANDLE hDetectThread;
BOOL	bStatusEndPoint[5];
extern tSYSTEM_PARAM *gpVirtualBOOTARGS;

#ifdef DEBUG

UFN_GENERATE_DPCURSETTINGS(UFN_DEFAULT_DPCURSETTINGS_NAME,
						   _T("Power"), _T(""), _T(""), _T(""),
						   DBG_ERROR | DBG_INIT);

// Validate the context.
static
VOID
ValidateContext(
				PCTRLR_PDD_CONTEXT pContext
				)
{
	PREFAST_DEBUGCHK(pContext);
	DEBUGCHK(pContext->dwSig == TELECHIPS_SIG);
	DEBUGCHK(!pContext->hevInterrupt || pContext->hIST);
	DEBUGCHK(VALID_DX(pContext->cpsCurrent));
	DEBUGCHK(pContext->pfnNotify);
}

#else
#define ValidateContext(ptr)
#endif

volatile BYTE *g_pUDCBase;

#define CTRLR_BASE_REG_ADDR(offset) ((volatile ULONG*) ( (g_pUDCBase) + (offset)))

HANDLE g_SdCardDetectThread;

#define HIGH 1
#define FULL  0

#define SET   TRUE
#define CLEAR FALSE


static
volatile ULONG*
_GetDataRegister(
				 DWORD        dwEndpoint
				 )
{
	volatile ULONG *pulDataReg = NULL;

	//
	// find the data register (non-uniform offset)
	//
	switch (dwEndpoint)
	{
	case  0: pulDataReg = CTRLR_BASE_REG_ADDR(EP0_FIFO);  break;
	case  1: pulDataReg = CTRLR_BASE_REG_ADDR(EP1_FIFO);  break;
	case  2: pulDataReg = CTRLR_BASE_REG_ADDR(EP2_FIFO);  break;
	case  3: pulDataReg = CTRLR_BASE_REG_ADDR(EP3_FIFO);  break;
	case  4: pulDataReg = CTRLR_BASE_REG_ADDR(EP4_FIFO);  break;
	case  5: pulDataReg = CTRLR_BASE_REG_ADDR(EP5_FIFO);  break;
	case  6: pulDataReg = CTRLR_BASE_REG_ADDR(EP6_FIFO);  break;
	case  7: pulDataReg = CTRLR_BASE_REG_ADDR(EP7_FIFO);  break;
	case  8: pulDataReg = CTRLR_BASE_REG_ADDR(EP8_FIFO);  break;
	case  9: pulDataReg = CTRLR_BASE_REG_ADDR(EP9_FIFO);  break;
	case  10: pulDataReg = CTRLR_BASE_REG_ADDR(EP10_FIFO);  break;
	case  11: pulDataReg = CTRLR_BASE_REG_ADDR(EP11_FIFO);  break;
	case  12: pulDataReg = CTRLR_BASE_REG_ADDR(EP12_FIFO);  break;
	case  13: pulDataReg = CTRLR_BASE_REG_ADDR(EP13_FIFO);  break;
	case  14: pulDataReg = CTRLR_BASE_REG_ADDR(EP14_FIFO);  break;
	case  15: pulDataReg = CTRLR_BASE_REG_ADDR(EP15_FIFO);  break;

	default:
		DEBUGCHK(FALSE);
		break;
	}
	return pulDataReg;
} // _GetDataRegister

// Retrieve the endpoint status structure.
inline
static
PEP_STATUS
GetEpStatus(
			PCTRLR_PDD_CONTEXT pContext,
			DWORD dwEndpoint
			)
{
	ValidateContext(pContext);
	DEBUGCHK(EP_VALID(dwEndpoint));
	PEP_STATUS peps = &pContext->rgEpStatus[dwEndpoint];
	return peps;
}


static
VOID
EnableDisableEndpointInterrupt(
							   PCTRLR_PDD_CONTEXT  	pContext,
							   DWORD               			dwEndpoint,
							   DWORD					dwDirection,
							   BOOL                			fEnable
							   )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE    ]1. [%d][%d][%d] \r\n"),dwEndpoint,dwDirection,fEnable));
	EnterCriticalSection(&pContext->csRegisterAccess);
	if(fEnable)
	{
		if(!dwEndpoint)
		{
			pOTG->DAINTMSK |=  (1<<(BYTE)dwEndpoint) << ENDPOINT_COUNT;
		}
		else
		{
			if(dwDirection == USB_OUT_TRANSFER)
				pOTG->DAINTMSK |=  (1<<(BYTE)dwEndpoint) << ENDPOINT_COUNT;
			else if(dwDirection == USB_IN_TRANSFER)
				pOTG->DAINTMSK |= (1<<(BYTE)dwEndpoint);
			else
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("[OTGDEVICE   ] EnableDisableEndpointInterrupt Direction Error!!! \r\n")));
			}	
		}

	}
	else
	{	
		if(!dwEndpoint)
		{
			pOTG->DAINTMSK &=  (1<<(BYTE)dwEndpoint) << ENDPOINT_COUNT;
		}
		else
		{
			if(dwDirection == USB_OUT_TRANSFER)
				pOTG->DAINTMSK &= ~((1<<(BYTE)dwEndpoint) << ENDPOINT_COUNT);
			else if(dwDirection == USB_IN_TRANSFER)
				pOTG->DAINTMSK &= ~(1<<(BYTE)dwEndpoint);
			else
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("[OTGDEVICE   ] EnableDisableEndpointInterrupt Direction Error!!! \r\n")));
			}	
		}
	}
	LeaveCriticalSection(&pContext->csRegisterAccess);
}

static
inline
VOID
EnableEndpointInterrupt(
						PCTRLR_PDD_CONTEXT  	pContext,
						DWORD               			dwEndpoint,
						DWORD					dwDirection
						)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();
	EnableDisableEndpointInterrupt(pContext, dwEndpoint, dwDirection, TRUE);
	TCC_FUNCTION_LEAVE_MSG();
}

static
inline
VOID
DisableEndpointInterrupt(
						 PCTRLR_PDD_CONTEXT  	pContext,
						 DWORD               			dwEndpoint,
						 DWORD					dwDirection
						 )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();
	EnableDisableEndpointInterrupt(pContext, dwEndpoint, dwDirection, FALSE);
	TCC_FUNCTION_LEAVE_MSG();
}


// Reset an endpoint
static
VOID
ResetEndpoint(
			  PCTRLR_PDD_CONTEXT pContext,
			  EP_STATUS *peps
			  )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	ValidateContext(pContext);
	PREFAST_DEBUGCHK(peps);

	// Since Reset can be called before/after an Endpoint has been configured,
	// it is best to clear all IN and OUT bits associated with endpoint.
	DWORD dwEndpoint = (peps->dwEndpointNumber&0xF);
	if(dwEndpoint == 0)
	{
		pOTG->DEVINENDPT[dwEndpoint][EPINT]= 0x3f; //intr clear
		pOTG->DEVOUTENDPT[dwEndpoint][EPINT]= 0x3f;
	}
	else if (dwEndpoint < ENDPOINT_COUNT)
	{
		pOTG->DEVINENDPT[dwEndpoint][EPINT]= 0x3f;
		pOTG->DEVOUTENDPT[dwEndpoint][EPINT]= 0x3f;
		//DisableEndpointInterrupt(pContext, peps->dwEndpointNumber, peps->dwDirectionAssigned);
	}

	TCC_FUNCTION_LEAVE_MSG();
}

static
VOID
InitPhyCon(
		   PCTRLR_PDD_CONTEXT pContext
		   )
{

}



// Reset the device and EP0.
static
VOID
ResetDevice(
			PCTRLR_PDD_CONTEXT pContext
			)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	OTGDEV_IO_Reset();

	EnableEndpointInterrupt(pContext, 0, USB_IN_TRANSFER);
	EnableEndpointInterrupt(pContext, 0, USB_OUT_TRANSFER); 

	for(int i=0; i < 5; i++)
		bStatusEndPoint[i] = FALSE;

	TCC_FUNCTION_LEAVE_MSG();
}

static
VOID
CompleteTransfer(
				 PCTRLR_PDD_CONTEXT pContext,
				 PEP_STATUS peps,
				 DWORD dwUsbError
				 )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CompleteTransfer EP%d \n"),peps->dwEndpointNumber));
	PSTransfer pTransfer = peps->pTransfer;
	peps->pTransfer = NULL;

	pTransfer->dwUsbError = dwUsbError;
	pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_TRANSFER_COMPLETE, (DWORD) pTransfer);

	TCC_FUNCTION_LEAVE_MSG();
}

#ifdef DEBUG
static
VOID
ValidateTransferDirection(
						  PCTRLR_PDD_CONTEXT pContext,
						  PEP_STATUS peps,
						  PSTransfer pTransfer
						  )
{
	DEBUGCHK(pContext);
	PREFAST_DEBUGCHK(peps);
	PREFAST_DEBUGCHK(pTransfer);

	if ((peps->dwEndpointNumber&0xF) != 0)
	{
		DEBUGCHK(peps->dwDirectionAssigned == pTransfer->dwFlags);
	}
}
#else
#define ValidateTransferDirection(ptr1, ptr2, ptr3)
#endif


// Read data from an endpoint.
static
BYTE
HandleRx(
		 PCTRLR_PDD_CONTEXT       pContext,
		 PEP_STATUS peps,
		 PBOOL pfCompleted,
		 PDWORD pdwStatus
		 )
{
	BOOL fCompleted = FALSE;
	DWORD dwStatus = ERROR_GEN_FAILURE;
	DWORD dwEndpoint = (peps->dwEndpointNumber&0xF);
	BYTE bRet = 0;

	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	PSTransfer pTransfer = peps->pTransfer;

	pTransfer = peps->pTransfer;

	int i=0;

	if (pTransfer)
	{
		DEBUGCHK(pTransfer->dwFlags == USB_OUT_TRANSFER);
		DEBUGCHK(pTransfer->dwUsbError == UFN_NOT_COMPLETE_ERROR);

		ValidateTransferDirection(pContext, peps, pTransfer);

		DEBUGCHK(peps->fInitialized);

		
		__try
		{
			PBYTE  pbBuffer =  (PBYTE)pTransfer->pvBuffer + pTransfer->cbTransferred;

			DWORD cbBuffer = pTransfer->cbBuffer - pTransfer->cbTransferred;
			DWORD cbFifo = pContext->CntValue;
			pContext->CntValue = 0;
			DEBUGCHK(cbFifo <= peps->dwPacketSizeAssigned);

			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]EP%d HandleRx %d %d , %d\n"),dwEndpoint,cbFifo,cbBuffer,pTransfer->cbTransferred));

			const DWORD cbRead = min(cbFifo, cbBuffer);
	
			if(dwEndpoint == 0)
			{
				memcpy(pbBuffer,gpVirtualBOOTARGS->UDMA_BUFF.CON_BUFF ,((cbRead+3)/4)*4);
			}
			else
			{
				memcpy(pbBuffer,gpVirtualBOOTARGS->UDMA_BUFF.OUT_BUFF ,((cbRead+3)/4)*4);
				

			}
	
			pTransfer->cbTransferred += cbRead;

			if ( (cbRead < peps->dwPacketSizeAssigned) || (pTransfer->cbTransferred == pTransfer->cbBuffer) )
			{
				// Short packet or filled buffer. Complete transfer.
				fCompleted = TRUE;
				dwStatus = UFN_NO_ERROR;
			}
			else
			{
				if (dwEndpoint == 0)
				{
					pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ]= 1<<19 | pContext->dwEp0MaxPktSize;
					pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] = (1<<31)|(1<<26)|(0<<0);
				}
				else
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE    ]Need More Data Read \n")));
					if((cbBuffer-MAX_RXDMABUFFSIZE) >= MAX_RXDMABUFFSIZE)
					{
						pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ] = (MAX_RXDMABUFFSIZE/gMaxPacketSize)<<19|MAX_RXDMABUFFSIZE;
						pContext->dwRxBuffSize = MAX_RXDMABUFFSIZE;
					}
					else if(cbBuffer-MAX_RXDMABUFFSIZE >= gMaxPacketSize )
					{
						pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ] = (((cbBuffer-MAX_RXDMABUFFSIZE)+(gMaxPacketSize-1))/gMaxPacketSize)<<19 | (cbBuffer-MAX_RXDMABUFFSIZE);//peps->dwPacketSizeAssigned;
						pContext->dwRxBuffSize = (cbBuffer-MAX_RXDMABUFFSIZE);
					}
					else
					{
						pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ] = (1)<<19 | (cbBuffer-MAX_RXDMABUFFSIZE);//peps->dwPacketSizeAssigned;
						pContext->dwRxBuffSize =(cbBuffer-MAX_RXDMABUFFSIZE);
						//RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[OTGDEVICE    ]Need More Data Size ERROR \n")));
					}

					pOTG->DEVOUTENDPT[dwEndpoint][EPDMA]  = (unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.OUT_BUFF;
					pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |= Hw31|Hw26;
				}
			}

			if (dwEndpoint == 0)
			{
				bRet |= SERVICED_OUT_PKY_RDY;
				if (fCompleted)
				{
					bRet |= DATA_END;
					pContext->Ep0State = EP0_STATE_STATUS;
				}
			}
			else
			{
				DEBUGCHK( (bRet & 0x1) == 0);
				pOTG->DEVOUTENDPT[dwEndpoint][EPINT] = Hw4|DOEPINT_XferCompl;
			}

		}
		__except(EXCEPTION_EXECUTE_HANDLER)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s Exception!\r\n"), pszFname));
			fCompleted = TRUE;
			dwStatus = UFN_CLIENT_BUFFER_ERROR;
		}


		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Rx Ep%x BufferSize=%u,Xfrd=%u \r\n"),
			pszFname, dwEndpoint, pTransfer->cbBuffer, pTransfer->cbTransferred));

	}
	else
	{
		pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |= Hw31|Hw26;
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("[OTGDEVICE   ]pTransfer is NULL so, not receive\n")));
	}


	*pfCompleted = fCompleted;
	*pdwStatus = dwStatus;
	TCC_FUNCTION_LEAVE_MSG();

	return bRet;
}


// Write data to an endpoint.
static
BYTE
HandleTx(
		 PCTRLR_PDD_CONTEXT       pContext,
		 PEP_STATUS peps,
		 BOOL fEnableInterrupts
		 )
{
	SETFNAME();
	DEBUGCHK(pContext);
	PREFAST_DEBUGCHK(peps);

	// This routine can be entered from both ISTMain and MDD/Client threads so
	// need critical section.

	TCC_FUNCTION_ENTER_MSG();

	BYTE bRet = 0;

	BOOL fCompleted = FALSE;
	PSTransfer pTransfer = peps->pTransfer;
	DWORD dwStatus = ERROR_GEN_FAILURE;
	DEBUGCHK(peps->fInitialized);
	DWORD dwEndpoint = (peps->dwEndpointNumber&0xF);

	pTransfer = peps->pTransfer;
	DWORD WriteData = 0;
	if (pTransfer)
	{
		ValidateTransferDirection(pContext, peps, pTransfer);

		DEBUGCHK(pTransfer->dwFlags == USB_IN_TRANSFER);
		DEBUGCHK(pTransfer->dwUsbError == UFN_NOT_COMPLETE_ERROR);


		// Transfer is ready
		__try
		{
			PBYTE pbBuffer = (PBYTE) pTransfer->pvBuffer + pTransfer->cbTransferred;

			DWORD cbBuffer = pTransfer->cbBuffer - pTransfer->cbTransferred;

			DWORD cbWritten = 0;

			// Min of input byte count and supported size
			volatile DWORD cbToWrite =0;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]HandleTx[%x][%d]\n"),pTransfer->pvBuffer,pTransfer->cbBuffer));
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]HandleTx[%d][%d][%x][%x]\n"),cbBuffer,cbToWrite,pOTG->DAINT,pOTG->DAINTMSK));
			if (dwEndpoint == 0)
			{
				cbToWrite = min(cbBuffer, peps->dwPacketSizeAssigned);
				memcpy(gpVirtualBOOTARGS->UDMA_BUFF.CON_BUFF,pbBuffer, ((cbToWrite+3)/4)*4 );
				cbWritten=cbToWrite ;

				pOTG->DEVINENDPT[dwEndpoint][EPSIZ]  = 1<<19 | cbToWrite;
				pOTG->DEVINENDPT[dwEndpoint][EPDMA] =(unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.CON_BUFF;
				pOTG->DEVINENDPT[dwEndpoint][EPCTL]  = (1<<31)|(1<<26)|(1<<11)|(0<<0);
			

				pTransfer->cbTransferred += cbToWrite;
				if ((pTransfer->cbTransferred >= pTransfer->cbBuffer) && (pTransfer->pvPddData == 0))
				{
					dwStatus = UFN_NO_ERROR;
					fCompleted = TRUE;
					pContext->Ep0State = EP0_STATE_STATUS;
				}

			}
			else //ep 1
			{
				cbToWrite = min(cbBuffer, MAX_TXDMABUFFSIZE) ;
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]HandleTx: DataEP%d size:%d [%x][%x][%x][%x][%x]\n"),
					dwEndpoint, cbToWrite,pOTG->DEVINENDPT[dwEndpoint][EPCTL],pOTG->DEVINENDPT[dwEndpoint][EPINT],pOTG->DEVINENDPT[dwEndpoint][EPSIZ],pOTG->DAINTMSK,pOTG->DIEPMSK ));
				
				memcpy(gpVirtualBOOTARGS->UDMA_BUFF.IN_BUFF,pbBuffer, ((cbToWrite+3)/4)*4);
				cbWritten=((cbToWrite)) ;

				if(cbToWrite <= gMaxPacketSize)
					pOTG->DEVINENDPT[dwEndpoint][EPSIZ]  = (1)<<19 | cbToWrite;
				else
					pOTG->DEVINENDPT[dwEndpoint][EPSIZ]  = (((cbToWrite)+(gMaxPacketSize-1))/gMaxPacketSize)<<19 | cbToWrite;

				pOTG->DEVINENDPT[dwEndpoint][EPDMA]  =(unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.IN_BUFF;
				pOTG->DEVINENDPT[dwEndpoint][EPCTL] |= Hw31|Hw26; 


				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]HandleTx: DataEP%d size:%d [%x][%x][%x]\n"),dwEndpoint, cbToWrite,pOTG->DEVINENDPT[dwEndpoint][EPCTL],pOTG->DEVINENDPT[dwEndpoint][EPINT],pOTG->DEVINENDPT[dwEndpoint][EPSIZ] ));
			
				// Update the Transfered Count 
				pTransfer->cbTransferred += cbToWrite;
				pContext->dwRxRemainSize = cbBuffer-cbToWrite;

				if ( (pTransfer->cbTransferred >= pTransfer->cbBuffer) || (cbWritten == 0))
				{
					fCompleted = TRUE;
					dwStatus = UFN_NO_ERROR;
				}
			}
		}
		__except(EXCEPTION_EXECUTE_HANDLER)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s Exception!\r\n"), pszFname));
			fCompleted = TRUE;
			dwStatus = UFN_CLIENT_BUFFER_ERROR;
		}
	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s pTrandfer Not Ready!!! \n")));
		goto EXIT;
	}

	if (fCompleted)
	{
		// Disable transfer interrupts until another transfer is issued.
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Tx Done  Ep%x  Status %u\r\n"), pszFname, dwEndpoint, dwStatus));
		if(!dwEndpoint)
			CompleteTransfer(pContext, peps, dwStatus);
	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Tx EP%x BufferSize=%u, Xfrd=%u\r\n"),
			pszFname, dwEndpoint, pTransfer->cbBuffer, pTransfer->cbTransferred));
	}

EXIT:
	TCC_FUNCTION_LEAVE_MSG();

	return bRet;
}

int TCC_OnSetFeature(PCTRLR_PDD_CONTEXT pContext,DWORD dwEndpoint)
{
	DEBUGCHK(EP_VALID(dwEndpoint));

	ValidateContext(pContext);

	PEP_STATUS peps = GetEpStatus(pContext, dwEndpoint);
	DEBUGCHK(peps->fInitialized);
	LOCK_ENDPOINT(peps);

	int nRet = FALSE;
	unsigned int testvalue;

	switch ( pContext->udr.bmRequestType & 0x1F )
	{
	case 0x00 :
		// For Compliance TEST
		if ( pContext->udr.wValue == 0x02 )
		{
			nRet = TRUE;
			//send status packet
			pOTG->DEVINENDPT[0][EPINT]  |= XFERCOPMPL;
			pOTG->DEVINENDPT[0][EPSIZ]  = 1<<19 | 0;
			pOTG->DEVINENDPT[0][EPCTL]  = (1<<31)|(1<<26)|(1<<11)|(0<<0);


			testvalue = pContext->udr.wIndex >> 8;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("USB_IF_TESTMODE [%d]\n\r"),testvalue));
			if( 0 < testvalue && testvalue < 6 )
			{
				BITCSET(pOTG->DCTL, DCTL_TstCtl_MASK, DCTL_TstCtl(testvalue));
			}
			else
			{
				// Reserved
				BITCLR(pOTG->DCTL, DCTL_TstCtl_MASK);
			}
		}		
		else
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("if not USB_IF_TESTMODE \n\r")));
		break;

	case 0x01 :
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(_T("USB_RECIPIENT_INTERFACE do nothing \n\r")));
		break;

	case 0x02 :		// Endpoint Recipient
		//	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(_T("USB_RECIPIENT_ENDPOINT \n\r")));
		//	StallEndpoint(pContext, pContext->udr.wIndex && 0xFF );
		break;
	}

	UNLOCK_ENDPOINT(peps);
	return nRet;
}
static
VOID
HandleEndpoint0Event(
					 PCTRLR_PDD_CONTEXT  pContext
					 )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	ValidateContext(pContext);
	DEBUGCHK(pContext->fRunning);

	PEP_STATUS peps = GetEpStatus(pContext, 0);
	LOCK_ENDPOINT(peps);

	// Write 0 to SEND_STALL and SENT_STALL to clear them, so we need to
	// leave them unchanged by default.
	BYTE bEp0CsrToWrite = 0;
	BOOL fSendUdr = FALSE;
	BOOL fCompleted = FALSE;
	DWORD dwStatus;

	if (pContext->Ep0State == EP0_STATE_SETUP)
	{

		if (pContext->fSpeedReported == FALSE)
		{
			DWORD wDSTS = pOTG->DSTS;
			if (pContext->dwDetectedSpeed == USB_FULL)
			{
				gMaxPacketSize = 64;
				pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_SPEED, BS_FULL_SPEED);
			}
			else if(pContext->dwDetectedSpeed == USB_HIGH)
			{
				gMaxPacketSize = 512;
				pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_SPEED, BS_HIGH_SPEED);
			}
			else
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("[OTGDEVICE    ]SPEED Exeption LowSpeed \r\n")));
			}
			pContext->fSpeedReported = TRUE;
		}

		// New setup packet
		DWORD cbOutFifo = pContext->CntValue;
		pContext->CntValue = 0;
		
		PDWORD pbUdr = (PDWORD) &pContext->udr;
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE    ]New setup packet receive size :%d\n"),cbOutFifo));
		memcpy(pbUdr,gpVirtualBOOTARGS->UDMA_BUFF.CON_BUFF,cbOutFifo);

		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("EP0 Data[")));
		for(unsigned int i=0; i < cbOutFifo; i++)
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("%x"),gpVirtualBOOTARGS->UDMA_BUFF.CON_BUFF[i]));
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("]\n")));

		if (cbOutFifo != sizeof(pContext->udr))
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Setup packet was only %x bytes!\r\n"), pszFname, cbOutFifo));
			pContext->Ep0State = EP0_STATE_SETUP;	
			pOTG->DEVOUTENDPT[0][EPSIZ] = DOEPTSIZ0_SUPCnt(3)|DOEPTSIZ0_PktCnt(1)|DOEPTSIZ0_XferSize(8);
			pOTG->DEVOUTENDPT[0][EPDMA] =(unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.CON_BUFF;
			pOTG->DEVOUTENDPT[0][EPCTL] |= DOEPCTL0_EPEna|DOEPCTL0_CNAK;
		}
		else
		{

			// Determine if this is a NO Data Packet
			if (pContext->udr.wLength > 0)
			{
				// Determine transfer Direction
				if (pContext->udr.bmRequestType & USB_ENDPOINT_DIRECTION_MASK)
				{
					// Start the SW OUT State Machine
					pContext->Ep0State = EP0_STATE_IN_DATA_PHASE;
				}
				else
				{
					// Start the SW OUT State Machine
					pContext->Ep0State = EP0_STATE_OUT_DATA_PHASE;
				}
				pContext->sendDataEnd = FALSE;
			}
			else
			{  
				pContext->sendDataEnd = TRUE;
				pContext->Ep0State = EP0_STATE_STATUS;
			}
			fSendUdr = TRUE;
		}
	}
	else if (pContext->Ep0State == EP0_STATE_OUT_DATA_PHASE)
	{

		// Check For out packet read && receive fifo not empty -> out token event
		if (pContext->CntValue)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s out token packet on endpoint 0 \r\n"), pszFname));
			HandleRx(pContext, peps, &fCompleted, &dwStatus);
			pContext->sendDataEnd = TRUE;
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s status stage of control transfer on endpoint 0\r\n"), pszFname));
			pContext->Ep0State = EP0_STATE_STATUS;
		}
	}
	else if(pContext->Ep0State ==EP0_STATE_STATUS)
	{
		
		
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s EP0_STATE_STATUS on endpoint 0 \r\n"), pszFname));
		//setting idle
		pContext->Ep0State = EP0_STATE_SETUP;	
		pOTG->DEVOUTENDPT[0][EPSIZ] = DOEPTSIZ0_SUPCnt(3)|DOEPTSIZ0_PktCnt(1)|DOEPTSIZ0_XferSize(8);
		pOTG->DEVOUTENDPT[0][EPDMA] =(unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.CON_BUFF;
		pOTG->DEVOUTENDPT[0][EPCTL] |= DOEPCTL0_EPEna|DOEPCTL0_CNAK;

	}
	else
	{

		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("ep0 send data \n")));
		HandleTx(pContext, peps, 1);
	}
	
	// Clear any interrupts
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Writing 0x%02x to EP0_CSR\r\n"), pszFname, bEp0CsrToWrite));
	if (fCompleted)
	{
		CompleteTransfer(pContext, peps, dwStatus);
	}
	if (fSendUdr)
	{
		if((&pContext->udr)->bRequest == USB_REQUEST_SET_FEATURE )
		{
			if(!(TCC_OnSetFeature(pContext,0)))
				pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_SETUP_PACKET, (DWORD) &pContext->udr);
			else
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("HandleEndpoint0Event():  UFN_MSG_SETUP_PACKET setup call (%x) \r\n"),(&pContext->udr)->bmRequestType));
		}
		else
			pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_SETUP_PACKET, (DWORD) &pContext->udr);
	}


	TCC_FUNCTION_LEAVE_MSG();
	UNLOCK_ENDPOINT(peps);
}


// Process an endpoint interrupt.  Call interrupt-specific handler.
static
VOID
HandleEndpointEvent(
					PCTRLR_PDD_CONTEXT  pContext,
					DWORD               dwEndpoint,
					DWORD               epIrqStat
					)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	ValidateContext(pContext);
	DEBUGCHK(pContext->fRunning);
	DEBUGCHK(dwEndpoint != 0);

	DWORD dwPendingEvents = 0;
	EP_STATUS *peps = GetEpStatus(pContext, dwEndpoint);
	PREFAST_DEBUGCHK(peps);

	LOCK_ENDPOINT(peps);

	if (peps->dwDirectionAssigned == USB_IN_TRANSFER)
	{
		dwPendingEvents = IN_TRANSFER;
	}
	else
	{
		dwPendingEvents = OUT_TRANSFER;
	}


	BOOL fCompleted = FALSE;
	DWORD dwStatus;

	if (dwPendingEvents == IN_TRANSFER)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("ep%d tx data \n"),dwEndpoint));
		HandleTx(pContext, peps, 0);
	}
	else if (dwPendingEvents == OUT_TRANSFER)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("ep%d receive data \n"),dwEndpoint));
		HandleRx(pContext, peps, &fCompleted, &dwStatus);
	}

	if (fCompleted)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("ep%d transfer Complete \n"),dwEndpoint));
		CompleteTransfer(pContext, peps, dwStatus);
	}

	TCC_FUNCTION_LEAVE_MSG();
	UNLOCK_ENDPOINT(peps);
}

static
VOID
SetMaxPktSizes(
			   PCTRLR_PDD_CONTEXT  pContext,
			   USB_SPEED eSpeed
			   )
{
	if (eSpeed == USB_HIGH)
	{
		pContext->eSpeed = USB_HIGH;
		pContext->dwEp0MaxPktSize = 64;
	}
	else
	{
		pContext->eSpeed = USB_FULL;
		pContext->dwEp0MaxPktSize = 8;
	}
}

static
VOID
SetAllOutEpNak(
			   PCTRLR_PDD_CONTEXT  pContext
			   )
{

	for(DWORD dwEndpoint=0; dwEndpoint<ENDPOINT_COUNT; dwEndpoint++)
	{
		if(!dwEndpoint)
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |=DEPCTL_SNAK;
		else
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |=DEPCTL_SNAK;
	}
}

static
VOID
ClearAllOutEpNak(
				 PCTRLR_PDD_CONTEXT  pContext
				 )
{
	for(DWORD dwEndpoint=0; dwEndpoint<ENDPOINT_COUNT; dwEndpoint++)
	{
		if(!dwEndpoint)
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |=DEPCTL_CNAK;
		else
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |=DEPCTL_CNAK;
	}
}


// Process USB Bus interrupt
static
VOID
HandleUSBBusIrq(
				PCTRLR_PDD_CONTEXT  pContext,
				DWORD                bUSBBusIrqStat
				)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();
	SetAllOutEpNak(pContext);

	if (bUSBBusIrqStat & INT_RESET)
	{
		pOTG->GINTSTS = INT_RESET;
		pContext->Ep0State = EP0_STATE_SETUP;

		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(_T("%s Reset\n"), pszFname));
		pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_EVENTS, UFN_RESET);
		ClearAllOutEpNak(pContext);

		if (pContext->OGBSTATUS == UFN_DETACH)
		{
			if(pOTG->GOTGCTL & (B_SESSION_VALID|A_SESSION_VALID))
			{

				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] OTG Cable Attached\r\n")));


				pContext->fSpeedReported = FALSE;
				pContext->fSetUpPhaseDone = FALSE;
				pContext->Ep0State = EP0_STATE_SETUP;
				pContext->CntValue = 0;
				pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_EVENTS, UFN_ATTACH);
				pContext->OGBSTATUS = UFN_ATTACH;
			}
		}
		else
		{
			if(!(pOTG->GOTGCTL & (B_SESSION_VALID|A_SESSION_VALID)))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] OTG Cable Detached\r\n")));
				pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_EVENTS, UFN_DETACH);
				pContext->OGBSTATUS = UFN_DETACH;
			}
			else
			{
				OTGDEV_IO_Reset();
			}
		}

		
	}

	if (bUSBBusIrqStat & INT_SDE)
	{
		pOTG->GINTSTS = INT_SDE;
		DWORD dwDSTS = pOTG->DSTS;
		if (((dwDSTS & 0x6)>>1) == USB_HIGH)
		{
			pContext->dwDetectedSpeed = USB_HIGH;
			SetMaxPktSizes(pContext, USB_HIGH);
		}
		else if(((dwDSTS & 0x6) >> 1) == USB_FULL)
		{
			pContext->dwDetectedSpeed = USB_FULL;
			SetMaxPktSizes(pContext, USB_FULL);
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("[OTGDEVICE   ] INT_SDE_EXEPTION Occured! \r\n")));
		}
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(_T("%s OTGDEV_IO_EnumDone\r\n"), pszFname));
		OTGDEV_IO_EnumDone();
	}
		if (bUSBBusIrqStat & INT_SUSPEND)
	{
		pOTG->GINTSTS = INT_SUSPEND;
		pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_EVENTS, UFN_SUSPEND);
	}
	if (bUSBBusIrqStat & INT_RESUME)
	{
		pOTG->GINTSTS = INT_RESUME;
		pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_EVENTS, UFN_RESUME);
	}


	if (bUSBBusIrqStat & INT_OTG)
	{
		volatile DWORD dwGotgint = pOTG->GOTGINT;
		if (dwGotgint & SesEndDet)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] OTG Cable Detached OTG \r\n")));
			pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_EVENTS, UFN_DETACH);
			//pContext->attachedState = UFN_DETACH;
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("[OTGDEVICE   ] OTG Interrupt Exeption %x\r\n"),dwGotgint));
		}
		pOTG->GOTGINT=dwGotgint;

	}
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]HandleUSBBusIrq[%x][%x] \r\n"),pOTG->GOTGINT,pOTG->GINTSTS));

	TCC_FUNCTION_LEAVE_MSG();
}


static
VOID
HandleUSBEvent(
			   PCTRLR_PDD_CONTEXT pContext
			   )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();
	ValidateContext(pContext);

	volatile DWORD dwGintsts = pOTG->GINTSTS;
	volatile DWORD dwDaint   = pOTG->DAINT;

	if (dwGintsts & (INT_RESUME | INT_SDE | INT_RESET | INT_SUSPEND | INT_OTG))
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("HandleUSBEvent [%x] HandleUSBBusIrq\n"),dwGintsts));
		HandleUSBBusIrq(pContext, dwGintsts);
	}

	if ((dwGintsts & INT_IN_EP)) 
	{
		
		if (dwDaint & EP0_IN_INT)
		{
			
			volatile DWORD dwDiepint0 = pOTG->DEVINENDPT[0][EPINT];

			if(dwDiepint0 & TXCOMPLETE)
			{
								HandleEndpoint0Event(pContext); 

				pOTG->DEVINENDPT[0][EPINT] = DOEPINT_XferCompl;
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]EP0 IN Transfer Complete[%x](%d)\n"),dwGintsts,pContext->Ep0State));


			}
			else
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("HandleUSBEvent [%x] INT_IN_EP0 dwDiepint0[%x] \n"),dwGintsts,dwDiepint0));

			pOTG->DEVINENDPT[0][EPINT] =  dwDiepint0;
		}
		else //ep1
		{
			
			DWORD dwEndpoint=1;		
			if (dwDaint & EP1_IN_INT)
			{

				volatile DWORD dwDiepint = pOTG->DEVINENDPT[dwEndpoint][EPINT];

				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]EP%d , dwDiepint: %x \n"), dwEndpoint, dwDiepint ));

				if(dwDiepint & TXCOMPLETE)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]EP1 IN Transfer Complete[%x]\n"),dwGintsts));
			
					PEP_STATUS peps = GetEpStatus(pContext, dwEndpoint);
					pOTG->DEVINENDPT[dwEndpoint][EPINT] = dwDiepint;
					if(pContext->dwRxRemainSize <= 0)
					{
						CompleteTransfer(pContext,peps,UFN_NO_ERROR);
						pGPIO->GPEDAT &= ~Hw5;
					}
					else
						HandleTx(pContext, peps, dwEndpoint);
									
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]EP1 IN Transfer EPINT[%x]\n"),pOTG->DEVINENDPT[dwEndpoint][EPINT]));
				}
				else
					RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("HandleUSBEvent [%x] INT_IN_EP%d dwDiepint[%x] \n"),dwEndpoint,dwGintsts,dwDiepint));

				//test
			}
		}
	}

	if (dwGintsts & INT_OUT_EP) //OUT Endpoint Occured
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] [%x] INT_OUT_EP\n"),dwGintsts));
		if (dwDaint & EP0_OUT_INT)
		{
			volatile DWORD dwDiepint0 = pOTG->DEVOUTENDPT[0][EPINT];
			if( pOTG->DEVOUTENDPT[0][EPINT] & DOEPINT_SetUP )
			{
				pContext->CntValue =8;
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("SETUP Packet Msg receive!\n")));
				pOTG->DEVOUTENDPT[0][EPINT] = dwDiepint0;
				HandleEndpoint0Event(pContext);
			}
			else if( pOTG->DEVOUTENDPT[0][EPINT] & DOEPINT_XferCompl )
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("DATA Packet Msg receive!\n")));
				pContext->CntValue =  64 - (pOTG->DEVOUTENDPT[0][EPSIZ]&0x7FFFF);
				HandleEndpoint0Event(pContext);
				
				pOTG->DEVOUTENDPT[0][EPINT] = DOEPINT_XferCompl;
				pOTG->DEVOUTENDPT[0][EPINT] = dwDiepint0;
			}
			else
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("KNOWN Msg receive!![%x]\n"),pOTG->DEVOUTENDPT[0][EPINT]));

			
		}
		else //ep2
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]EP2 Data Receive [%x][%x]\n"),pOTG->DEVOUTENDPT[2][EPINT],pOTG->DEVOUTENDPT[2][EPSTS]));

			for(int dwEpnum=2; dwEpnum <= MAX_ENDPOINT; dwEpnum++)
			{
				if( pOTG->DEVOUTENDPT[dwEpnum][EPINT] & DOEPINT_XferCompl )
				{
					pContext->CntValue = pContext->dwRxBuffSize - (pOTG->DEVOUTENDPT[dwEpnum][EPSIZ]&0x7FFFF);
					HandleEndpointEvent(pContext, dwEpnum, dwDaint);
				}
				else RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("EP%d UNKNOWN Msg[%x] receive!\n"),dwEpnum,pOTG->DEVOUTENDPT[dwEpnum][EPINT]));
			}
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]EP2 Data Receive [%x][%x]\n"),pOTG->DEVOUTENDPT[2][EPINT],pOTG->DEVOUTENDPT[2][EPSTS]));
		}
	}

	if(!(dwGintsts & INT_OUT_EP)&&!(dwGintsts & INT_IN_EP))
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("###[%x][%x][%x]\n"),dwGintsts,pOTG->DAINT,pOTG->DAINTMSK));

	pOTG->DCTL |= CLEAR_GOUTNAK;

	TCC_FUNCTION_LEAVE_MSG();
}

BOOL setIntr=FALSE;
// interrupt service routine.
static
DWORD
WINAPI
ISTMain(
		LPVOID lpParameter
		)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] +ISTMain\r\n")));

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) lpParameter;
	ValidateContext(pContext);

	CeSetThreadPriority(pContext->hIST, pContext->dwISTPriority);
	pContext->fExitIST = FALSE;

	while (!(pContext->fExitIST)) 
	{
		pContext->fRestartIST = FALSE;
		//ResetDevice(pContext);

		if(pContext->gRunning)
		{
		// Disable All Endpoint interrupts
		pOTG->DAINTMSK = 0; // Disable All Endpoint

		// Enable Device General interrupts
		pOTG->GINTSTS = INT_RESUME | INT_SDE | INT_RESET | INT_SUSPEND;	
		pOTG->GINTMSK = INT_RESUME | INT_IN_EP|INT_OUT_EP|INT_SDE|INT_RESET |INT_SUSPEND| INT_OTG;	

		// Enable Endpoint interrupt 0
		EnableEndpointInterrupt(pContext, 0, USB_IN_TRANSFER);
		EnableEndpointInterrupt(pContext, 0, USB_OUT_TRANSFER);

			BOOL fSuccess = KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &pContext->dwIrq,
				sizeof(DWORD), &pContext->dwSysIntr, sizeof(DWORD), NULL);
			if (!fSuccess)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s IOCTL_HAL_REQUEST_SYSINTR failed!\r\n"),
					pszFname));
				//goto EXIT;
			}
		
			fSuccess = InterruptInitialize(pContext->dwSysIntr, pContext->hevInterrupt, NULL, 0);
			if (fSuccess == FALSE)
			{
				DEBUGMSG(ZONE_ERROR, (_T("%s  interrupt initialization failed\r\n"), pszFname));
				//goto EXIT;
			}
			InterruptDone(pContext->dwSysIntr);
			setIntr=TRUE;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]ISTMain: Sysintr:%d \n"),pContext->dwSysIntr));
		}

		while (pContext->gRunning)
		{
			DWORD dwWait = WaitForSingleObject(pContext->hevInterrupt, INFINITE);
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Interrupt Occur. \r\n"), pszFname));
			if (pContext->fExitIST || pContext->fRestartIST)//||!pContext->gRunning)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s stop  pContext->fExitIST: %d,  pContext->fRestartIST:%d , pContext->gRunning:%d \r\n"), pszFname,pContext->fExitIST,pContext->fRestartIST,pContext->gRunning));
				break;
			}

			if (dwWait == WAIT_OBJECT_0)
			{
				HandleUSBEvent(pContext);
				InterruptDone(pContext->dwSysIntr);
			}
			else
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s WaitForSingleObject failed. Exiting IST.[%x]\r\n"), pszFname,dwWait));
				break;
			}
		}
		Sleep(10);
		if(setIntr)
		{
			setIntr=FALSE;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] Release IST Interrupt: %d \r\n"),pContext->dwSysIntr));
			pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_EVENTS, UFN_DETACH);
			KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &pContext->dwSysIntr, sizeof(DWORD), NULL, 0, NULL);	
			InterruptDisable(pContext->dwSysIntr);
			pContext->OGBSTATUS = UFN_DETACH;

		}
		if(pContext->fRestartIST)
		{
		// Send detach, moved code for reset interrupt
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] OTG Cable Detached IstMain Close\r\n")));
		pContext->pfnNotify(pContext->pvMddContext, UFN_MSG_BUS_EVENTS, UFN_DETACH);
		pContext->fSpeedReported = FALSE;
		pContext->attachedState = UFN_DETACH;
		}
		if(pContext->fExitIST == TRUE)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] ISTMain stop[%d]....\r\n"),pContext->fExitIST ));
			break;
		}
		else
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] ISTMain restart[%d]....\r\n"),pContext->fExitIST ));
	}

	TCC_FUNCTION_LEAVE_MSG();
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] -ISTMain\r\n")));
	return 0;
}



static
VOID
StartTransfer(
			  PCTRLR_PDD_CONTEXT pContext,
			  PEP_STATUS peps,
			  PSTransfer pTransfer
			  )
{
	SETFNAME();

	DEBUGCHK(pContext);
	PREFAST_DEBUGCHK(peps);

	DEBUGCHK(!peps->pTransfer);
	ValidateTransferDirection(pContext, peps, pTransfer);

	LOCK_ENDPOINT(peps);
	TCC_FUNCTION_ENTER_MSG();

	//if (pTransfer->dwFlags != USB_IN_TRANSFER)
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Setting up %s transfer on ep %u for %u bytes\r\n"),
		pszFname, (pTransfer->dwFlags == USB_IN_TRANSFER) ? _T("in") : _T("out"),
		peps->dwEndpointNumber, pTransfer->cbBuffer));

	// Enable transfer interrupts.
	peps->pTransfer = pTransfer;
	DWORD dwEndpoint = (peps->dwEndpointNumber&0xF);

	if (pTransfer->dwFlags == USB_IN_TRANSFER)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ]Issue IN %d[%d][%x][%x]...\n"),pTransfer->cbBuffer,pTransfer->cbTransferred,pOTG->DAINT,pOTG->DAINTMSK));
		if (dwEndpoint== 0)
		{
			HandleTx(pContext, peps, 0);
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE    ]Send Ready ep%d (%d)\n"), dwEndpoint, pTransfer->cbBuffer));

			if(!bStatusEndPoint[dwEndpoint])
			{
				HandleTx(pContext, peps, dwEndpoint);
			}
		}
	}
	else //out
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE    ]Issue OUT EP%d[%x][%x] %d(%d)[%d](%d)...\n"),dwEndpoint,pOTG->DEVOUTENDPT[dwEndpoint][EPINT],pOTG->DEVOUTENDPT[dwEndpoint][EPCTL], pTransfer->cbBuffer,peps->dwPacketSizeAssigned,pTransfer->cbTransferred,pContext->CntValue));
		if (dwEndpoint == 0)
		{
			pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ]  =  1<<19 | pContext->dwEp0MaxPktSize;
			pOTG->DEVOUTENDPT[dwEndpoint][EPDMA]  = (unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.CON_BUFF;
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL]  |= Hw31|Hw26;
		}
		else
		{
			if(1) //!(pOTG->DEVOUTENDPT[dwEndpoint][EPCTL]&Hw31))
			{
				if(pTransfer->cbBuffer <= gMaxPacketSize)
				{
					pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ]  = (1<<19 | (peps->dwPacketSizeAssigned&0x7FFFF));
					pContext->dwRxBuffSize = peps->dwPacketSizeAssigned;
				}
				else if(pTransfer->cbBuffer <= MAX_RXDMABUFFSIZE)
				{
					pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ]  = (((pTransfer->cbBuffer)+(gMaxPacketSize-1))/gMaxPacketSize)<<19 | pTransfer->cbBuffer;
					pContext->dwRxBuffSize = pTransfer->cbBuffer;
				}
				else
				{
					pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ]  = ((MAX_RXDMABUFFSIZE/gMaxPacketSize<<19) | (MAX_RXDMABUFFSIZE));
					pContext->dwRxBuffSize = MAX_RXDMABUFFSIZE;
				}

				pOTG->DEVOUTENDPT[dwEndpoint][EPDMA]  = (unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.OUT_BUFF;
				//if(!(pOTG->DEVOUTENDPT[dwEndpoint][EPCTL]&Hw31))
					pOTG->DEVOUTENDPT[dwEndpoint][EPCTL]  |= Hw31|Hw26;
				//else
				//	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[OTGDEVICE    ]EP%d is stall so, not send...\n"),dwEndpoint));
			}
			else
				RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[OTGDEVICE    ]EP%d is stall so, not send...\n"),dwEndpoint));
			//else need to aborttransfer??????
		}
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE    ]Issue OUT EP%d[%x][%x] %d(%d)[%d](%d)...\n"),dwEndpoint,pOTG->DEVOUTENDPT[dwEndpoint][EPINT],pOTG->DEVOUTENDPT[dwEndpoint][EPCTL], pTransfer->cbBuffer,peps->dwPacketSizeAssigned,pTransfer->cbTransferred,pContext->CntValue));
	}

	TCC_FUNCTION_LEAVE_MSG();
	UNLOCK_ENDPOINT(peps);
}

DWORD
WINAPI
UfnPdd_IssueTransfer(
					 PVOID  pvPddContext,
					 DWORD  dwEndpoint,
					 PSTransfer pTransfer
					 )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	DEBUGCHK(EP_VALID(dwEndpoint));
	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("UfnPdd_IssueTransfer %d \n"),dwEndpoint));
	PEP_STATUS peps = GetEpStatus(pContext, dwEndpoint);
	LOCK_ENDPOINT(peps);
	DEBUGCHK(peps->fInitialized);
	DEBUGCHK(pTransfer->cbTransferred == 0);

	DWORD dwRet = ERROR_SUCCESS;

	DEBUGCHK(peps->pTransfer == NULL);
	StartTransfer(pContext, peps, pTransfer);

	UNLOCK_ENDPOINT(peps);

	TCC_FUNCTION_LEAVE_MSG();

	return dwRet;
}



DWORD
WINAPI
UfnPdd_AbortTransfer(
					 PVOID           pvPddContext,
					 DWORD           dwEndpoint,
					 PSTransfer      pTransfer
					 )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	PREFAST_DEBUGCHK(pTransfer);
	DEBUGCHK(EP_VALID(dwEndpoint));

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	PEP_STATUS peps = GetEpStatus(pContext, dwEndpoint);
	LOCK_ENDPOINT(peps);
	DEBUGCHK(peps->fInitialized);

	ValidateTransferDirection(pContext, peps, pTransfer);

	DEBUGCHK(pTransfer == peps->pTransfer);
	CompleteTransfer(pContext, peps, UFN_CANCELED_ERROR);

	if (dwEndpoint == 0)
	{
		pContext->Ep0State = EP0_STATE_SETUP;
	}
	else
	{
		if(pTransfer->dwFlags == USB_OUT_TRANSFER)
		{
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |= Hw31|Hw28|Hw26|(2<<18)|Hw15|(gMaxPacketSize);
			pOTG->DEVINENDPT[IN_TRANSFER][EPCTL] |=Hw28; // for MSC IF Test 
		}


	}
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("UfnPdd_AbortTransfer [%d]\n"),dwEndpoint));

	ResetEndpoint( pContext,peps);


	UNLOCK_ENDPOINT(peps);

	TCC_FUNCTION_LEAVE_MSG();

	return ERROR_SUCCESS;
}


// This does not do much because there is not any way to control
// power on this controller.
static CEDEVICE_POWER_STATE SetPowerState(PCTRLR_PDD_CONTEXT pContext,CEDEVICE_POWER_STATE cpsNew)
{
	SETFNAME();

	PREFAST_DEBUGCHK(pContext);
	DEBUGCHK(VALID_DX(cpsNew));
	ValidateContext(pContext);

	// Adjust cpsNew.
	if (cpsNew != pContext->cpsCurrent)
	{
		if (cpsNew == D1 || cpsNew == D2)
		{
			// D1 and D2 are not supported.
			cpsNew = D0;
		}
		else if (pContext->cpsCurrent == D4)
		{
			// D4 can only go to D0.
			cpsNew = D0;
		}
	}

	if (cpsNew != pContext->cpsCurrent)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Going from D%u to D%u\r\n"),
			pszFname, pContext->cpsCurrent, cpsNew));

		if ( (cpsNew < pContext->cpsCurrent) && pContext->hBusAccess )
		{
			SetDevicePowerState(pContext->hBusAccess, cpsNew, NULL);
		}

		switch (cpsNew)
		{
		case D0:
			BITCSET(pOTGCFG->UPCR2,Hw10|Hw9/*UPCR2_OPMODE_MASK*/,0/*UPCR2_OPMODE_NORMAL*/);
			pOTGCFG->UPCR0 = 0x2842;			

			/*if (pContext->fRunning) {
			// Cause the IST to restart.
			pContext->fRestartIST = TRUE;
			SetInterruptEvent(pContext->dwSysIntr);
			}*/
			break;

		case D3:
			break;

		case D4:

			BITCSET(pOTGCFG->UPCR2,Hw10|Hw9/*UPCR2_OPMODE_MASK*/,Hw9/*UPCR2_OPMODE_NON_DRVING*/);
			pOTGCFG->UPCR0 = 0x4840;
			pOTGCFG->UPCR0 = 0x6940;
			break;
		}

		if ( (cpsNew > pContext->cpsCurrent) && pContext->hBusAccess )
		{
			SetDevicePowerState(pContext->hBusAccess, cpsNew, NULL);
		}

		pContext->cpsCurrent = cpsNew;
	}

	return pContext->cpsCurrent;
}

static
VOID
FreeCtrlrContext(
				 PCTRLR_PDD_CONTEXT pContext
				 )
{
	PREFAST_DEBUGCHK(pContext);
	DEBUGCHK(!pContext->hevInterrupt);
	DEBUGCHK(!pContext->hIST);
	DEBUGCHK(!pContext->fRunning);
	pContext->dwSig = GARBAGE_DWORD;

	if (pContext->hBusAccess) CloseBusAccessHandle(pContext->hBusAccess);

	if (pContext->dwSysIntr)
	{
		KernelIoControl(IOCTL_HAL_DISABLE_WAKE, &pContext->dwSysIntr, sizeof(pContext->dwSysIntr), NULL, 0, NULL);
	}

	if (pContext->dwIrq != IRQ_UNSPECIFIED)
	{
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &pContext->dwSysIntr, sizeof(DWORD), NULL, 0, NULL);
	}

	CloseHandle(g_SdCardDetectThread);
	g_SdCardDetectThread = NULL;	

	DeleteCriticalSection(&pContext->csRegisterAccess);
	LocalFree(pContext);
}


DWORD
WINAPI
UfnPdd_Deinit(
			  PVOID pvPddContext
			  )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	TCC_FUNCTION_ENTER_MSG();

	FreeCtrlrContext(pContext);
	CloseHandle(hGXP);
	CloseHandle(hHCD);

	TCC_FUNCTION_LEAVE_MSG();

	return ERROR_SUCCESS;
}
DWORD fCheckVBUSValue(unsigned int temp)
{
#if defined(_USING_GPIOMODE_)
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("fCheckVBUSValue [%08x]\n"), (pGPIO->GPFDAT&Hw27 )));
	return (pGPIO->GPFDAT&Hw27);
#else
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("fCheckVBUSValue [%08x]\n"), (pPIC->SRC0 & Hw4 )));
	return (pPIC->SRC0 & Hw4 ) ;//EI1 using for vbus detect
#endif
}
void USBPHY_DEVICE_Detach(void)
{
	BITCSET(pOTGCFG->UPCR2,Hw10|Hw9/*UPCR2_OPMODE_MASK*/,Hw9/*UPCR2_OPMODE_NON_DRVING*/);
	pOTGCFG->UPCR0 = 0x4840;
	pOTGCFG->UPCR0 = 0x6940;
	Sleep(100);
}

DWORD CheckIDPin()
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("CheckIDPin [%08x]\n"), (pGPIO->GPADAT&Hw13)));
	return (pGPIO->GPADAT&Hw13);
}

void USBPHY_DEVICE_Attach(void)
{
	BITCSET(pOTGCFG->UPCR2,Hw10|Hw9/*UPCR2_OPMODE_MASK*/,0/*UPCR2_OPMODE_NORMAL*/);
	pOTGCFG->UPCR0 = 0x2842;
}


static DWORD fDetectThread(LPVOID lpParameter)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) lpParameter;
	#if 0
	{
		//send to HOST stop command
		DeviceIoControl(  hHCD, IOCTL_USBOTG_STOP_OTGHOST,  NULL,   0,  NULL, 0, NULL, NULL);

		//DVBUS Power Down
		GXPINFO gxpInfo;
		DWORD dwByteReturned;
		gxpInfo.uiDevice = PCA9538;
		gxpInfo.uiPort = DVBUS;
		gxpInfo.uiState = OFF;

		DWORD dwret = WriteFile(  hGXP,  &gxpInfo,  sizeof(gxpInfo),   &dwByteReturned,  NULL);
		if( dwret == 0)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("%s DVBUS Power Down.\r\n"), pszFname));
		}

#if defined(_USING_GPIOMODE_)
		//GPIO F27 Setting for VBUS Detect
		BITCLR(pGPIO->GPFFN3,Hw16-Hw12); //GPIOF27 using gpio Mode
		BITCLR(pGPIO->GPFEN, Hw27); //GPIOF27 using Input Mode
#else
		BITCSET(pGPIO->EINTSEL0,Hw14-Hw8,Hw14-Hw9); // EINT1 setting 62 0x3E
		
		//initial OTG Phy - already change on HOST Driver
		USBPHY_DEVICE_Detach();
		USBPHY_DEVICE_Attach();
		USBPHY_SetMode(USBPHY_MODE_RESET);
		tcc_ckc_set_iobus_swreset(RB_USB20OTG);
		OTGCORE_Init();
		OTGDEV_IO_Init();
		USBPHY_SetID(1);
#endif

		//GPIO A13 Setting for ID Detect
		BITCLR(pGPIO->GPAFN1,Hw24-Hw20); //GPIOA13 using gpio Mode	
		BITCLR(pGPIO->GPAEN, Hw13); //GPIOA13 using Input Mode

		//Phy disable - for low power mode
		USBPHY_DEVICE_Detach();

		#if defined(_USING_GPIOMODE_)
			tcc_ckc_setiobus(RB_USB20OTG, DISABLE);
		#endif

		pContext->attachedState = UFN_DETACH;
        }
	#else
	{
		#if defined(_USING_GPIOMODE_)
		//GPIO F27 Setting for VBUS Detect
		BITCLR(pGPIO->GPFFN3,Hw16-Hw12); //GPIOF27 using gpio Mode
		BITCLR(pGPIO->GPFEN, Hw27); //GPIOF27 using Input Mode
		#else
		BITCSET(pGPIO->EINTSEL0,Hw14-Hw8,Hw14-Hw9); // EINT1 setting 62 0x3E
		
		#endif

		//GPIO A13 Setting for ID Detect
		BITCLR(pGPIO->GPAFN1,Hw24-Hw20); //GPIOA13 using gpio Mode	
		BITCLR(pGPIO->GPAEN, Hw13); //GPIOA13 using Input Mode

		//Phy disable - for low power mode
		////USBPHY_DEVICE_Detach();

		#if defined(_USING_GPIOMODE_)
			tcc_ckc_setiobus(RB_USB20OTG, DISABLE);
		#endif

		if (CheckIDPin()) {		//if 1 is Device
			pContext->attachedState = UFN_DETACH;
		} else {
			pContext->attachedState = HOST_ATTACH;
		}
	}
	#endif
	while (!pContext->fExitIST)
	{
		Sleep(100);
		if( CheckIDPin()) //if 1 is Device
		{
	
		if ( fCheckVBUSValue(1) ) 
		{
			if ( pContext->attachedState == UFN_DETACH )
			{
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("%s UFN_ATTACH.\r\n"), pszFname));
					pContext->gRunning = TRUE;
					Sleep(500);//wait for Interrupt setting and Initialize

					//set usdevice core setting
					#if defined(_USING_GPIOMODE_)
						tcc_ckc_setiobus(RB_USB20OTG, ENABLE);
					
						USBPHY_DEVICE_Attach();
						USBPHY_SetMode(USBPHY_MODE_RESET);
						tcc_ckc_set_iobus_swreset(RB_USB20OTG);
						OTGCORE_Init();
						OTGDEV_IO_Init();
						USBPHY_SetID(1);
					#else
						USBPHY_DEVICE_Attach();
					#endif
				

					ResetDevice(pContext);
					USBPHY_SetMode(USBPHY_MODE_DEVICE);
					
					#if defined(_USING_GPIOMODE_)
						//DVBUS ON - DVBUS and OTG VBUS does not connect 
						GXPINFO gxpInfo;
						DWORD dwByteReturned;
						gxpInfo.uiDevice = PCA9538;
						gxpInfo.uiPort = DVBUS;
						gxpInfo.uiState = ON;
					    
						DWORD dwret = WriteFile(  hGXP,  &gxpInfo,  sizeof(gxpInfo),   &dwByteReturned,  NULL);
						if( dwret == 0)
						{
							RETAILMSG(TRUE,(TEXT("[OTGDEVICE   ]:ERROR:Can't Power ON DVBUS!!\n")));
						}
					#endif

					pContext->attachedState = UFN_ATTACH;
				}
				else if(pContext->attachedState == HOST_ATTACH) // Host Detach
				{
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("%s HOST DETACH.\r\n"), pszFname));
					
					DWORD dwret = DeviceIoControl(  hHCD, IOCTL_USBOTG_STOP_OTGHOST,  NULL,   0,  NULL, 0, NULL, NULL);
					if( dwret == 0)
					{
						RETAILMSG(TRUE,(TEXT("[OTGDEVICE   ]:ERROR:Can't Stop OTG HOST!!\n")));
					}
					Sleep(500);
					
					USBPHY_DEVICE_Detach();

					GXPINFO gxpInfo;
					DWORD dwByteReturned;
					gxpInfo.uiDevice = PCA9538;
					gxpInfo.uiPort = DVBUS;
					gxpInfo.uiState = OFF;
				    
					dwret = WriteFile(  hGXP,  &gxpInfo,  sizeof(gxpInfo),   &dwByteReturned,  NULL);
					if( dwret == 0)
					{
						RETAILMSG(TRUE,(TEXT("[OTGDEVICE   ]:ERROR:Can't Power OFF DVBUS!!\n")));
					}

					USBPHY_DEVICE_Detach();
					USBPHY_DEVICE_Attach();
					USBPHY_SetMode(USBPHY_MODE_RESET);
					tcc_ckc_set_iobus_swreset(RB_USB20OTG);
					OTGCORE_Init();
					OTGDEV_IO_Init();
					USBPHY_SetID(1);

					pContext->attachedState = UFN_DETACH;

					//set off Power Control
					USBPHY_DEVICE_Detach();
					#if defined(_USING_GPIOMODE_)
						tcc_ckc_setiobus(RB_USB20OTG, DISABLE);
					#endif
			}
		}
		else
		{
				if ( pContext->attachedState == UFN_ATTACH )
				{
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("%s UFN_DETACH.\r\n"), pszFname));
					pContext->gRunning = FALSE;
					SetEvent(pContext->hevInterrupt);

					#if defined(_USING_GPIOMODE_)
						GXPINFO gxpInfo;
						DWORD dwByteReturned;
						gxpInfo.uiDevice = PCA9538;
						gxpInfo.uiPort = DVBUS;
						gxpInfo.uiState = OFF;
					    
						DWORD dwret = WriteFile(  hGXP,  &gxpInfo,  sizeof(gxpInfo),   &dwByteReturned,  NULL);
						if( dwret == 0)
					{
							RETAILMSG(TRUE,(TEXT("[OTGDEVICE   ]:ERROR:Can't Power OFF DVBUS!!\n")));
							//CloseHandle(hGXP);
					}
					#endif

					USBPHY_SetMode(USBPHY_MODE_DEVICE);
					pContext->attachedState = UFN_DETACH;

					//set off Power Control
					USBPHY_DEVICE_Detach();

					#if defined(_USING_GPIOMODE_)
						tcc_ckc_setiobus(RB_USB20OTG, DISABLE);
					#endif
				}
			}
		}
		else //host
		{
			if(pContext->attachedState == UFN_DETACH)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("%s HOST ATTACH.\r\n"), pszFname));
				
				#if defined(_USING_GPIOMODE_)
					tcc_ckc_setiobus(RB_USB20OTG, ENABLE);
					USBPHY_DEVICE_Attach();
					USBPHY_SetMode(USBPHY_MODE_HOST);
				#endif

				GXPINFO gxpInfo;
				DWORD dwByteReturned;
				gxpInfo.uiDevice = PCA9538;
				gxpInfo.uiPort = DVBUS;
				gxpInfo.uiState = ON;
			    
				DWORD dwret = WriteFile(  hGXP,  &gxpInfo,  sizeof(gxpInfo),   &dwByteReturned,  NULL);
				if( dwret == 0)
				{
					RETAILMSG(TRUE,(TEXT("[OTGDEVICE   ]:ERROR:Can't Power ON DVBUS!!\n")));
				}
				
				//Sleep(500);

				dwret = DeviceIoControl(  hHCD, IOCTL_USBOTG_START_OTGHOST,  NULL,   0,  NULL, 0, NULL, NULL);
				if( dwret == 0)
				{
					RETAILMSG(TRUE,(TEXT("[OTGDEVICE   ]:ERROR:Can't Start OTG HOST!!\n")));
				}

				pContext->attachedState = HOST_ATTACH;

			}
		}
	}
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s finished.\r\n"), pszFname));

	TCC_FUNCTION_LEAVE_MSG();
	return 0;
}

DWORD
WINAPI
UfnPdd_Start(
			 PVOID        pvPddContext
			 )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	DWORD dwRet;
	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);
	TCC_FUNCTION_ENTER_MSG();

	DEBUGCHK(!pContext->fRunning);

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE   ] UfnPdd_Start\r\n")));
	pContext->gRunning = FALSE;
	pContext->hIST = CreateThread(NULL, 0, ISTMain, pContext, 0, NULL);
	if (pContext->hIST == NULL)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s IST creation failed\r\n"), pszFname));
		dwRet = GetLastError();
		goto EXIT;
	}

	hDetectThread = CreateThread(0, 0, (LPTHREAD_START_ROUTINE) fDetectThread, pContext, 0, NULL);
	if ( fDetectThread == NULL )
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Create DetectUsbAttachThread: FAILED\r\n"), pszFname));

	pContext->fRunning = TRUE;
	dwRet = ERROR_SUCCESS;

EXIT:
	if (pContext->fRunning == FALSE)
	{
		DEBUGCHK(dwRet != ERROR_SUCCESS);

		if (pContext->hevInterrupt) CloseHandle(pContext->hevInterrupt);
		pContext->hevInterrupt = NULL;
	}

	TCC_FUNCTION_LEAVE_MSG();

	return dwRet;
}



DWORD
WINAPI
UfnPdd_Stop(
			PVOID pvPddContext
			)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	DEBUGCHK(pContext->fRunning);

	// Stop the IST
	pContext->fExitIST = TRUE;
	SetEvent(pContext->hevInterrupt);
	WaitForSingleObject(pContext->hIST,INFINITE);
#if 0
	WaitForSingleObject(pContext->hIST, INFINITE);
	KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &pContext->dwSysIntr, sizeof(DWORD), NULL, 0, NULL);
	InterruptDisable(pContext->dwSysIntr);

	CloseHandle(pContext->hevInterrupt);
	CloseHandle(pContext->hIST);

	pContext->hIST = NULL;
	pContext->hevInterrupt = NULL;
#endif
	//USBPHY_DEVICE_Detach();
	//USBPHY_DEVICE_Attach();

	pContext->fRunning = FALSE;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Device has been stopped\r\n"),
		pszFname));

	TCC_FUNCTION_LEAVE_MSG();

	return ERROR_SUCCESS;
}


DWORD
WINAPI
UfnPdd_IsConfigurationSupportable(
								  PVOID                       pvPddContext,
								  UFN_BUS_SPEED               Speed,
								  PUFN_CONFIGURATION          pConfiguration
								  )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	DEBUGCHK(Speed == BS_FULL_SPEED);

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	// This PDD does not have any special requirements that cannot be
	// handled through IsEndpointSupportable.
	DWORD dwRet = ERROR_SUCCESS;

	TCC_FUNCTION_LEAVE_MSG();

	return dwRet;
}


//
// Is this endpoint supportable.
DWORD
WINAPI
UfnPdd_IsEndpointSupportable(
							 PVOID                       pvPddContext,
							 DWORD                       dwEndpoint,
							 UFN_BUS_SPEED               Speed,
							 PUSB_ENDPOINT_DESCRIPTOR    pEndpointDesc,
							 BYTE                        bConfigurationValue,
							 BYTE                        bInterfaceNumber,
							 BYTE                        bAlternateSetting
							 )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	DEBUGCHK(EP_VALID(dwEndpoint));
	DEBUGCHK(Speed == BS_FULL_SPEED);
	DWORD dwRet = ERROR_SUCCESS;
	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	if (dwEndpoint == 0)
	{
		DEBUGCHK(pEndpointDesc->bmAttributes == USB_ENDPOINT_TYPE_CONTROL);

		if (pEndpointDesc->wMaxPacketSize < EP_0_PACKET_SIZE)
		{
			DEBUGMSG(ZONE_ERROR, (_T("%s Endpoint 0 only supports %u byte packets\r\n"), pszFname, EP_0_PACKET_SIZE));
			dwRet = ERROR_INVALID_PARAMETER;
		}
		else
		{
			pEndpointDesc->wMaxPacketSize = EP_0_PACKET_SIZE;
		}
	}
	else if (dwEndpoint < ENDPOINT_COUNT)
	{
		BYTE bTransferType = pEndpointDesc->bmAttributes & USB_ENDPOINT_TYPE_MASK;
		DEBUGCHK(bTransferType != USB_ENDPOINT_TYPE_CONTROL);
		DWORD wPacketSize = (pEndpointDesc->wMaxPacketSize & USB_ENDPOINT_MAX_PACKET_SIZE_MASK);
		switch(bTransferType)
		{
		case USB_ENDPOINT_TYPE_ISOCHRONOUS:
			DEBUGMSG(ZONE_ERROR, (_T("%s Isochronous endpoints are not supported\r\n"), pszFname));
			dwRet = ERROR_INVALID_PARAMETER;
			break;

		case USB_ENDPOINT_TYPE_BULK:
		case USB_ENDPOINT_TYPE_INTERRUPT:
			if((wPacketSize >= 8) && (wPacketSize < 16))
			{
				wPacketSize = 8;
			}
			else if ((wPacketSize >= 16) && (wPacketSize < 32))
			{
				wPacketSize = 16;
			}
			else if((wPacketSize >= 32) && (wPacketSize < 64))
			{
				wPacketSize = 32;
			}
			else if ((wPacketSize >= 64) && (wPacketSize < 128))
			{
				wPacketSize = 64;
			}
			else if((wPacketSize >= 128) && (wPacketSize < 256))
			{
				wPacketSize = 128;
			}
			else if ((wPacketSize >= 256) && (wPacketSize < 512))
			{
				wPacketSize = 256;
			}
			else if (wPacketSize >= 512)
			{
				wPacketSize = 512;
			}
			else
			{ // wPacketSize < 8
				dwRet = ERROR_INVALID_PARAMETER;
			}
			break;

		default:
			dwRet = ERROR_INVALID_PARAMETER;
			break;
		}

		if ( (wPacketSize != (pEndpointDesc->wMaxPacketSize & USB_ENDPOINT_MAX_PACKET_SIZE_MASK)) && (dwRet == ERROR_SUCCESS) )
		{
			pEndpointDesc->wMaxPacketSize &= ~USB_ENDPOINT_MAX_PACKET_SIZE_MASK;
			pEndpointDesc->wMaxPacketSize |= wPacketSize;
		}
	}

	TCC_FUNCTION_LEAVE_MSG();
	return dwRet;
}



// Initialize an endpoint.
DWORD
WINAPI
UfnPdd_InitEndpoint(
					PVOID                       		pvPddContext,
					DWORD                       		dwEndpoint,
					UFN_BUS_SPEED               	Speed,
					PUSB_ENDPOINT_DESCRIPTOR    pEndpointDesc,
					PVOID                       		pvReserved,
					BYTE                        		bConfigurationValue,
					BYTE                        		bInterfaceNumber,
					BYTE                        		bAlternateSetting
					)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	DEBUGCHK(EP_VALID(dwEndpoint));
	PREFAST_DEBUGCHK(pEndpointDesc);

#ifdef DEBUG
	{
		USB_ENDPOINT_DESCRIPTOR EndpointDesc;
		memcpy(&EndpointDesc, pEndpointDesc, sizeof(EndpointDesc));
		DEBUGCHK(UfnPdd_IsEndpointSupportable(pvPddContext, dwEndpoint, Speed,
			&EndpointDesc, bConfigurationValue, bInterfaceNumber, bAlternateSetting) == ERROR_SUCCESS);
		DEBUGCHK(memcmp(&EndpointDesc, pEndpointDesc, sizeof(EndpointDesc)) == 0);
	}
#endif


	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);
	BYTE bEndpointAddress = 0;
	DWORD dwRegTemp = 0;
	BOOL fModeOut;
	BYTE bTransferType;

	PEP_STATUS peps = GetEpStatus(pContext, dwEndpoint);
	DEBUGCHK(!peps->fInitialized);

	InitializeCriticalSection(&peps->cs);

	DWORD wMaxPacketSize = pEndpointDesc->wMaxPacketSize & USB_ENDPOINT_MAX_PACKET_SIZE_MASK;
	DEBUGCHK(wMaxPacketSize);

	// If the target is endpoint 0, then only allow the function driver
	// to register a notification function.
	if (dwEndpoint == 0)
	{
		peps->dwPacketSizeAssigned = wMaxPacketSize;
		// Interrupts for endpoint 0 are enabled in ISTMain
	}
	else if (dwEndpoint < ENDPOINT_COUNT)
	{
		bEndpointAddress = pEndpointDesc->bEndpointAddress;
		fModeOut = USB_ENDPOINT_DIRECTION_OUT_(bEndpointAddress);
		//if (fModeOut)
		if(dwEndpoint==2)
		{
			peps->dwDirectionAssigned = USB_OUT_TRANSFER;
		}
		else
		{
			peps->dwDirectionAssigned = USB_IN_TRANSFER;
		}

		// Set Transfer Type
		bTransferType = pEndpointDesc->bmAttributes & USB_ENDPOINT_TYPE_MASK;
		DEBUGCHK(bTransferType != USB_ENDPOINT_TYPE_CONTROL);
		switch(bTransferType)
		{
		case USB_ENDPOINT_TYPE_ISOCHRONOUS:
			if ( peps->dwDirectionAssigned == USB_IN_TRANSFER)
			{
				dwRegTemp |= Hw18;
			}
			else
			{
				dwRegTemp |= Hw18;
			}
			break;

		case USB_ENDPOINT_TYPE_BULK:
		case USB_ENDPOINT_TYPE_INTERRUPT:
		default:
			// Clear ISO bit - Set type to Bulk
			if ( peps->dwDirectionAssigned == USB_IN_TRANSFER)
			{
				dwRegTemp |= Hw19;
			}
			else
			{
				dwRegTemp |= Hw19;
			}
		}
		peps->dwEndpointType = bTransferType;
		peps->dwPacketSizeAssigned = wMaxPacketSize;
		
		//to do
		USBDEV_ENDPOINT_T EP1;
		EP1.index=(unsigned char)dwEndpoint;
		if(dwEndpoint==1)
			EP1.isIn=1;
		else
			EP1.isIn=0;
		EP1.transferType=USBDEV_EP_TRANSFER_TYPE_BULK;
		EP1.maximumPacketSize=(unsigned short)wMaxPacketSize;
		OTGDEV_IO_EP_Enable(&EP1,1);
	}



	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("EP%d Dir:%d Interface:%d, transfertype:%d \n"),dwEndpoint,fModeOut,bInterfaceNumber,bTransferType ));
	
	peps->fInitialized = TRUE;
	TCC_FUNCTION_LEAVE_MSG();
	return ERROR_SUCCESS;
}


// Deinitialize an endpoint.
DWORD
WINAPI
UfnPdd_DeinitEndpoint(
					  PVOID pvPddContext,
					  DWORD dwEndpoint
					  )
{

	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	DEBUGCHK(EP_VALID(dwEndpoint));

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	PEP_STATUS peps = GetEpStatus(pContext, dwEndpoint);
	LOCK_ENDPOINT(peps);

	DEBUGCHK(peps->fInitialized);
	DEBUGCHK(peps->pTransfer == NULL);

	// Reset and disable the endpoint
	// Mask endpoint interrupts
	ResetEndpoint(pContext, peps);

	peps->fInitialized = FALSE;
	UNLOCK_ENDPOINT(peps);

	DeleteCriticalSection(&peps->cs);

	TCC_FUNCTION_LEAVE_MSG();

	return ERROR_SUCCESS;
}


// Stall an endpoint.
DWORD
WINAPI
UfnPdd_StallEndpoint(
					 PVOID pvPddContext,
					 DWORD dwEndpoint
					 )
{

	DWORD dwRet = ERROR_SUCCESS;
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	DEBUGCHK(EP_VALID(dwEndpoint));

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	PEP_STATUS peps = GetEpStatus(pContext, dwEndpoint);
	DEBUGCHK(peps->fInitialized);
	LOCK_ENDPOINT(peps);
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[OTGDEVICE   ] UfnPdd_StallEndpoint: dwEndpoint %x direction %x\r\n"),dwEndpoint,peps->dwDirectionAssigned));
	bStatusEndPoint[dwEndpoint] = TRUE;
	if (dwEndpoint == 0)
	{
		if(pOTG->DEVINENDPT[dwEndpoint][EPCTL] & Hw31)
			pOTG->DEVINENDPT[dwEndpoint][EPCTL]  = (1<<30)|(1<<21);
		else
			pOTG->DEVINENDPT[dwEndpoint][EPCTL]  = (1<<21);
		pContext->sendDataEnd = FALSE;
		
		pContext->Ep0State = EP0_STATE_SETUP;
		pOTG->DEVOUTENDPT[0][EPSIZ] = DOEPTSIZ0_SUPCnt(3)|DOEPTSIZ0_PktCnt(1)|DOEPTSIZ0_XferSize(8);
		pOTG->DEVOUTENDPT[0][EPDMA]=(unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.CON_BUFF;
		pOTG->DEVOUTENDPT[0][EPCTL] |= DOEPCTL0_EPEna|DOEPCTL0_CNAK;
	}
	else if (peps->dwDirectionAssigned == USB_IN_TRANSFER)
	{
		pOTG->DEVINENDPT[dwEndpoint][EPCTL] |= Hw21;//stall ep
		pOTG->DEVINENDPT[dwEndpoint][EPDMA]=(unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.IN_BUFF;
	
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[OTGDEVICE   ] Stall ep%d IN %08X \n"),dwEndpoint, pOTG->DEVOUTENDPT[dwEndpoint][EPCTL]));
	}
	else if (peps->dwDirectionAssigned == USB_OUT_TRANSFER)
	{ 
		pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |= Hw21;
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[OTGDEVICE   ] Stall ep%d OUT %08X \n"),dwEndpoint, pOTG->DEVINENDPT[dwEndpoint][EPCTL]));
	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[OTGDEVICE    ]STALL ERROR Endpoint number!!\n")));
	}
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[OTGDEVICE   ] UfnPdd_StallEndpoint: dwEndpoint %x direction %x\r\n"),dwEndpoint,peps->dwDirectionAssigned));

	UNLOCK_ENDPOINT(peps);
	TCC_FUNCTION_LEAVE_MSG();

	return ERROR_SUCCESS;
}

// Clear an endpoint stall.
DWORD
WINAPI
UfnPdd_ClearEndpointStall(
						  PVOID pvPddContext,
						  DWORD dwEndpoint
						  )
{
	DWORD dwRet = ERROR_SUCCESS;


	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	DEBUGCHK(EP_VALID(dwEndpoint));

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);


	PEP_STATUS peps = GetEpStatus(pContext, dwEndpoint);
	PSTransfer pTransfer = peps->pTransfer;
	LOCK_ENDPOINT(peps);
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[OTGDEVICE   ] UfnPdd_ClearEndpointStall: dwEndpoint %x direction %x\r\n"),dwEndpoint,peps->dwDirectionAssigned));
	bStatusEndPoint[dwEndpoint] = FALSE;
	if (dwEndpoint == 0)
	{
		pOTG->DEVINENDPT[dwEndpoint][EPCTL]  = (0<<31)|(0<<26)|(0<<21)|(1<<11)|(0<<0);
		pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] = (0<<31)|(0<<26)|(0<<21)|(0<<0);
	}
	else if (peps->dwDirectionAssigned == USB_IN_TRANSFER)
	{
		if(pOTG->DEVINENDPT[dwEndpoint][EPCTL] &(Hw21))
		{
			pOTG->DEVINENDPT[dwEndpoint][EPCTL] |= Hw28; //pid setting
			pOTG->DEVINENDPT[dwEndpoint][EPCTL] &= ~(Hw21);

			if(pTransfer)
			{
				HandleTx(pContext, peps, dwEndpoint);
			}
		}		
		pOTG->DEVINENDPT[dwEndpoint][EPCTL] |= Hw28; //pid setting
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[OTGDEVICE   ] Clear Stall ep%d IN %08X \n"),dwEndpoint, pOTG->DEVINENDPT[dwEndpoint][EPCTL]));
	}
	else
	{ // Out Endpoint
		if(pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] &(Hw21))
		{
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |= Hw28;
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] &= ~(Hw21);
			//pOTG->DEVOUTENDPT[dwEndpoint][EPDMA]=(unsigned int)gpPhysicalBOOTARGS->UDMA_BUFF.OUT_BUFF;
			if(pTransfer)
				pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |= Hw31|Hw26;
		}
		pOTG->DEVOUTENDPT[dwEndpoint][EPCTL] |= Hw28; //pid setting
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[OTGDEVICE   ] Clear Stall ep%d OUT %08X \n"),dwEndpoint,pOTG->DEVOUTENDPT[dwEndpoint][EPCTL]));
	}

	UNLOCK_ENDPOINT(peps);
	TCC_FUNCTION_LEAVE_MSG();
	return ERROR_SUCCESS;
}



// Send the control status handshake.
DWORD
WINAPI
UfnPdd_SendControlStatusHandshake(
								  PVOID           pvPddContext,
								  DWORD           dwEndpoint
								  )
{

	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	DEBUGCHK(dwEndpoint == 0);
	
	// This function is only valid for Endpoint 0
	EP_STATUS *peps = GetEpStatus(pContext, 0);
	DEBUGCHK(peps->fInitialized);
	LOCK_ENDPOINT(peps);

	if(dwEndpoint == 0)
		pContext->Ep0State = EP0_STATE_STATUS;

	if(pContext->sendDataEnd)
	{
		pOTG->DEVINENDPT[dwEndpoint][EPSIZ]  = 1<<19 | 0<<0;
		pOTG->DEVINENDPT[dwEndpoint][EPCTL]  = (1<<31)|(1<<26)|(1<<11)|(0<<0);
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Sending 0 packet \r\n"), pszFname));
		pContext->sendDataEnd = FALSE;
	}
	else
	{

		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Sending 0 packet!!!! \r\n"), pszFname));
		if(bStatusEndPoint[dwEndpoint] == TRUE)
		{
			bStatusEndPoint[dwEndpoint] = FALSE;
			pContext->Ep0State = EP0_STATE_SETUP;
		}
		else
		{
			pOTG->DEVOUTENDPT[dwEndpoint][EPSIZ] = 1<<29|1<<19|0<<0;
			pOTG->DEVOUTENDPT[dwEndpoint][EPCTL]  = 1<<31|1<<26;
		}
	}
	UNLOCK_ENDPOINT(peps);
	TCC_FUNCTION_LEAVE_MSG();
	return ERROR_SUCCESS;
}


// Set the address of the device on the USB.
DWORD
WINAPI
UfnPdd_SetAddress(
				  PVOID pvPddContext,
				  BYTE  bAddress
				  )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("UfnPdd_SetAddress (%d)\n"),bAddress));
	// Device Address setting to DCFG
	volatile DWORD wDCFG = pOTG->DCFG;
	pOTG->DCFG = (wDCFG & ~(0x7f<<4)) | (bAddress<<4);

	TCC_FUNCTION_LEAVE_MSG();

	return ERROR_SUCCESS;
}



// Is endpoint Stalled?
DWORD
WINAPI
UfnPdd_IsEndpointHalted(
						PVOID pvPddContext,
						DWORD dwEndpoint,
						PBOOL pfHalted
						)
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[OTGDEVICE   ] UfnPdd_IsEndpointHalted [%d]\r\n"),bStatusEndPoint[dwEndpoint]));

	DWORD dwRet = 0;

	*pfHalted = bStatusEndPoint[dwEndpoint];
	TCC_FUNCTION_LEAVE_MSG();

	return dwRet;

}


DWORD
WINAPI
UfnPdd_InitiateRemoteWakeup(
							PVOID pvPddContext
							)
{

	return ERROR_SUCCESS;
}


DWORD
WINAPI
UfnPdd_RegisterDevice(
					  PVOID                           pvPddContext,
					  PCUSB_DEVICE_DESCRIPTOR         pHighSpeedDeviceDesc,
					  PCUFN_CONFIGURATION             pHighSpeedConfig,
					  PCUSB_CONFIGURATION_DESCRIPTOR  pHighSpeedConfigDesc,
					  PCUSB_DEVICE_DESCRIPTOR         pFullSpeedDeviceDesc,
					  PCUFN_CONFIGURATION             pFullSpeedConfig,
					  PCUSB_CONFIGURATION_DESCRIPTOR  pFullSpeedConfigDesc,
					  PCUFN_STRING_SET                pStringSets,
					  DWORD                           cStringSets
					  )
{
	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	// Nothing to do.

	return ERROR_SUCCESS;
}


DWORD
WINAPI
UfnPdd_DeregisterDevice(
						PVOID   pvPddContext
						)
{
	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	return ERROR_SUCCESS;
}


VOID
WINAPI
UfnPdd_PowerDown(
				 PVOID pvPddContext
				 )
{
	SETFNAME();

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	USBPHY_SetMode(USBPHY_MODE_DEVICE);
	pContext->attachedState = UFN_DETACH;

	//set off Power Control
	USBPHY_DEVICE_Detach();
	
}


VOID
WINAPI
UfnPdd_PowerUp(
			   PVOID pvPddContext
			   )
{
	SETFNAME();

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

			BITCSET(pGPIO->EINTSEL0,Hw14-Hw8,Hw14-Hw9); // EINT1 setting 62 0x3E
		
		//initial OTG Phy - already change on HOST Driver
		USBPHY_DEVICE_Detach();
		USBPHY_DEVICE_Attach();
		USBPHY_SetMode(USBPHY_MODE_RESET);
		tcc_ckc_set_iobus_swreset(RB_USB20OTG);
		OTGCORE_Init();
		OTGDEV_IO_Init();
		USBPHY_SetID(1);
		pContext->attachedState = UFN_DETACH ;
}


DWORD
WINAPI
UfnPdd_IOControl(
				 PVOID           pvPddContext,
				 IOCTL_SOURCE    source,
				 DWORD           dwCode,
				 PBYTE           pbIn,
				 DWORD           cbIn,
				 PBYTE           pbOut,
				 DWORD           cbOut,
				 PDWORD          pcbActualOut
				 )
{
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();

	PCTRLR_PDD_CONTEXT pContext = (PCTRLR_PDD_CONTEXT) pvPddContext;
	ValidateContext(pContext);

	DWORD dwRet = ERROR_INVALID_PARAMETER;

	switch (dwCode)
	{
	case IOCTL_UFN_GET_PDD_INFO:
		if ( source != BUS_IOCTL || pbOut == NULL || cbOut != sizeof(UFN_PDD_INFO) )
		{
			break;
		}
		// Not currently supported.
		break;

	case IOCTL_BUS_GET_POWER_STATE:
		if (source == MDD_IOCTL)
		{
			PREFAST_DEBUGCHK(pbIn);
			DEBUGCHK(cbIn == sizeof(CE_BUS_POWER_STATE));

			PCE_BUS_POWER_STATE pCePowerState = (PCE_BUS_POWER_STATE) pbIn;
			PREFAST_DEBUGCHK(pCePowerState->lpceDevicePowerState);

			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s IOCTL_BUS_GET_POWER_STATE\r\n"), pszFname));
			*pCePowerState->lpceDevicePowerState = pContext->cpsCurrent;

			dwRet = ERROR_SUCCESS;
		}
		break;

	case IOCTL_BUS_SET_POWER_STATE:
		if (source == MDD_IOCTL)
		{
			PREFAST_DEBUGCHK(pbIn);
			DEBUGCHK(cbIn == sizeof(CE_BUS_POWER_STATE));
			PCE_BUS_POWER_STATE pCePowerState = (PCE_BUS_POWER_STATE) pbIn;

			PREFAST_DEBUGCHK(pCePowerState->lpceDevicePowerState);
			DEBUGCHK(VALID_DX(*pCePowerState->lpceDevicePowerState));

			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s IOCTL_BUS_GET_POWER_STATE(D%u)\r\n"), pszFname, *pCePowerState->lpceDevicePowerState));
			SetPowerState(pContext, *pCePowerState->lpceDevicePowerState);

			dwRet = ERROR_SUCCESS;
		}
		break;
	}
	TCC_FUNCTION_LEAVE_MSG();
	return dwRet;
}

// Initialize the device.
DWORD
WINAPI
UfnPdd_Init(
			LPCTSTR                     pszActiveKey,
			PVOID                       pvMddContext,
			PUFN_MDD_INTERFACE_INFO     pMddInterfaceInfo,
			PUFN_PDD_INTERFACE_INFO     pPddInterfaceInfo
			)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("[OTGDEVICE   ]+USB FUNCTION Driver\r\n")));
	SETFNAME();
	TCC_FUNCTION_ENTER_MSG();
	BOOL fIntInitialized = FALSE;
	static const UFN_PDD_INTERFACE_INFO sc_PddInterfaceInfo =
	{
		UFN_PDD_INTERFACE_VERSION,
		(UFN_PDD_CAPS_SUPPORTS_FULL_SPEED|UFN_PDD_CAPS_SUPPORTS_HIGH_SPEED),
		ENDPOINT_COUNT,
		NULL, // This gets filled in later

		&UfnPdd_Deinit,
		&UfnPdd_IsConfigurationSupportable,
		&UfnPdd_IsEndpointSupportable,
		&UfnPdd_InitEndpoint,
		&UfnPdd_RegisterDevice,
		&UfnPdd_DeregisterDevice,
		&UfnPdd_Start,
		&UfnPdd_Stop,
		&UfnPdd_IssueTransfer,
		&UfnPdd_AbortTransfer,
		&UfnPdd_DeinitEndpoint,
		&UfnPdd_StallEndpoint,
		&UfnPdd_ClearEndpointStall,
		&UfnPdd_SendControlStatusHandshake,
		&UfnPdd_SetAddress,
		&UfnPdd_IsEndpointHalted,
		&UfnPdd_InitiateRemoteWakeup,
		&UfnPdd_PowerDown,
		&UfnPdd_PowerUp,
		&UfnPdd_IOControl,
	};

	DWORD dwType;
	DWORD dwRet;

	HKEY hkDevice = NULL;
	HKEY hKey = NULL;
	PCTRLR_PDD_CONTEXT pContext = NULL;

	DEBUGCHK(pszActiveKey);
	DEBUGCHK(pMddInterfaceInfo);
	DEBUGCHK(pPddInterfaceInfo);
	hkDevice = OpenDeviceKey(pszActiveKey);

	if (!hkDevice)
	{
		dwRet = GetLastError();
		DEBUGMSG(ZONE_ERROR, (_T("%s Could not open device key. Error: %d\r\n"), pszFname, dwRet));
		goto EXIT;
	}

	pContext = (PCTRLR_PDD_CONTEXT) LocalAlloc(LPTR, sizeof(*pContext));
	if (pContext == NULL)
	{
		dwRet = GetLastError();
		PREFAST_DEBUGCHK(dwRet != ERROR_SUCCESS);
		DEBUGMSG(ZONE_ERROR, (_T("%s LocalAlloc failed. Error: %d\r\n"), pszFname, dwRet));
		goto EXIT;
	}

	pContext->dwSig = TELECHIPS_SIG;

	pContext->pvMddContext = pvMddContext;
	pContext->cpsCurrent = D4;
	pContext->dwIrq = IRQ_UNSPECIFIED;
	pContext->pfnNotify = pMddInterfaceInfo->pfnNotify;
	pContext->dwDetectedSpeed = USB_FULL;
	InitializeCriticalSection(&pContext->csRegisterAccess);

	for (DWORD dwEp = 0; dwEp < dim(pContext->rgEpStatus); ++dwEp)
	{
		pContext->rgEpStatus[dwEp].dwEndpointNumber = dwEp;
	}

	DWORD dwDataSize;
	DWORD dwPriority;

	DDKISRINFO dii;
	DDKWINDOWINFO dwi;

	// read window configuration from the registry
	dwi.cbSize = sizeof(dwi);
	dwRet = DDKReg_GetWindowInfo(hkDevice, &dwi);
	if(dwRet != ERROR_SUCCESS)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s DDKReg_GetWindowInfo() failed %d\r\n"),
			pszFname, dwRet));
	}

	// get ISR configuration information
	dii.cbSize = sizeof(dii);
	dwRet = DDKReg_GetIsrInfo(hkDevice, &dii);
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Irq info %d,%d\r\n"), pszFname, dii.dwIrq, dii.dwSysintr));
	if (dwRet != ERROR_SUCCESS)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s DDKReg_GetIsrInfo() failed %d\r\n"),
			pszFname, dwRet));
		goto EXIT;
	}
	else if( (dii.dwSysintr == SYSINTR_NOP) && (dii.dwIrq == IRQ_UNSPECIFIED) )
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s no IRQ or SYSINTR value specified\r\n"), pszFname));
		dwRet = ERROR_INVALID_DATA;
		goto EXIT;
	}
	else
	{
		if (dii.dwSysintr == SYSINTR_NOP)
		{
		/*	BOOL fSuccess = KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dii.dwIrq,
				sizeof(DWORD), &dii.dwSysintr, sizeof(DWORD), NULL);
			if (!fSuccess)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s IOCTL_HAL_REQUEST_SYSINTR failed!\r\n"),
					pszFname));
				goto EXIT;
			}
		*/
			pContext->dwIrq = dii.dwIrq;
			pContext->dwSysIntr = dii.dwSysintr;
		}
		else
		{
			pContext->dwSysIntr = dii.dwSysintr;
		}
	}

	// Read the IST priority
	dwDataSize = sizeof(dwPriority);
	dwRet = RegQueryValueEx(hkDevice, _T("Priority256"), NULL, &dwType,
		(LPBYTE) &dwPriority, &dwDataSize);
	if (dwRet != ERROR_SUCCESS)
	{
		dwPriority = DEFAULT_PRIORITY;
	}

	pContext->hBusAccess = CreateBusAccessHandle(pszActiveKey);
	if (pContext->hBusAccess == NULL)
	{
		// This is not a failure.
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (_T("%s Could not create bus access handle\r\n"),
			pszFname));
	}

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Using SysIntr %u\r\n"),
		pszFname, pContext->dwSysIntr));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (_T("%s Using IST priority %u\r\n"),
		pszFname, dwPriority));

	pContext->dwISTPriority = dwPriority;
	// base address mapping
	pOTG	 = (PUSBOTG)tcc_allocbaseaddress((unsigned int)&HwUSB20OTG_BASE);
	HwUSB20OTG= (PUSB20OTG)tcc_allocbaseaddress((unsigned int)&HwUSB20OTG_BASE);
	pOTGCFG  = (PUSBOTGCFG)tcc_allocbaseaddress((unsigned int)&HwUSBOTGCFG_BASE);
	HwUSBOTGCFG  = (PUSBOTGCFG)tcc_allocbaseaddress((unsigned int)&HwUSBOTGCFG_BASE);
	pPIC	 = (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);
	pGPIO	 = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	g_pUDCBase =(volatile BYTE *)tcc_allocbaseaddress((unsigned int)&HwUSB20OTG_BASE);

	pContext->hevInterrupt = CreateEvent(0, FALSE, FALSE, NULL);
	if (pContext->hevInterrupt == NULL)
	{
		dwRet = GetLastError();
		DEBUGMSG(ZONE_ERROR, (_T("%s Error creating  interrupt event. Error = %d\r\n"), pszFname, dwRet));
		goto EXIT;
	}

/*
	fIntInitialized = InterruptInitialize(pContext->dwSysIntr, pContext->hevInterrupt, NULL, 0);
	if (fIntInitialized == FALSE)
	{
		dwRet = ERROR_GEN_FAILURE; 
		DEBUGMSG(ZONE_ERROR, (_T("%s  interrupt initialization failed\r\n"), pszFname));
		goto EXIT;
	}
	InterruptDone(pContext->dwSysIntr);
*/
	pContext->attachedState = UFN_DETACH;
/*
	//set usdevice core setting
	USBPHY_SetMode(USBPHY_MODE_RESET);
	tcc_ckc_set_iobus_swreset(RB_USB20OTG);
	OTGCORE_Init();
	OTGDEV_IO_Init();
	USBPHY_SetID(1);
*/
	ValidateContext(pContext);

	memcpy(pPddInterfaceInfo, &sc_PddInterfaceInfo, sizeof(sc_PddInterfaceInfo));
	pPddInterfaceInfo->pvPddContext = pContext;

	hGXP = CreateFile(L"GXP1:",
                    GENERIC_READ | GENERIC_WRITE,
					NULL,
					NULL,
					OPEN_ALWAYS,
					FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,
					NULL);

    if(!hGXP)
        RETAILMSG(TRUE,(TEXT("[OTGDEVICE   ]Can't open GXP Driver!!\n")));

	hHCD = CreateFile(L"HCD2:",
                GENERIC_READ | GENERIC_WRITE,
				NULL,
				NULL,
				OPEN_ALWAYS,
				FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,
				NULL);

    if(!hHCD)
        RETAILMSG(TRUE,(TEXT("[OTGDEVICE   ]Can't open HCD Driver!!\n")));

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (_T("[OTGDEVICE   ]-USB FUNCTION Driver\r\n")));

EXIT:
	if (hkDevice) RegCloseKey(hkDevice);

	if (dwRet != ERROR_SUCCESS && pContext)
	{
		if (fIntInitialized) InterruptDisable(pContext->dwSysIntr);
		FreeCtrlrContext(pContext);
	}
	TCC_FUNCTION_LEAVE_MSG();

	return dwRet;
}


// Called by MDD's DllEntry.
extern "C"
BOOL
UfnPdd_DllEntry(
				HANDLE hDllHandle,
				DWORD  dwReason,
				LPVOID lpReserved
				)
{
	SETFNAME();

	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		g_pUDCBase = NULL;
		break;
	}

	return TRUE;
}
