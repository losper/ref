/**************************************************************************************
*
* FILE NAME   : usbphy.c
* DESCRIPTION : This is a USB PHY (UTMI+) driver source code
*
* ====================================================================================
*
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
* ====================================================================================
*
* FILE HISTORY:
* 	Date: 2009.02.12	Start source coding
*
**************************************************************************************/
#include "usb_defs.h"
#include "usbphy.h"
#include "reg_physical.h"
#include "otgregs.h"

/* For Signature */
#define USBPHY_SIGNATURE			'U','S','B','P','H','Y','_'
#define USBPHY_VERSION				'V','2','.','0','0','0'
static const unsigned char USBPHY_C_Version[] = {SIGBYAHONG, USBPHY_SIGNATURE, SIGN_OS ,SIGN_CHIPSET, USBPHY_VERSION, NULL};

#define	UPCR0_PR						Hw14					// (1:enable)/(0:disable) Port Reset
#define	UPCR0_CM_EN						Hw13					// Common Block Power Down Enable
#define	UPCR0_CM_DIS					~Hw13					// Common Block Power Down Disable
#define	UPCR0_RCS_11					(Hw12+Hw11)				// Reference Clock Select for PLL Block ; The PLL uses CLKCORE as reference
#define	UPCR0_RCS_10					Hw12					// Reference Clock Select for PLL Block ; The PLL uses CLKCORE as reference
#define	UPCR0_RCS_01					Hw11					// Reference Clock Select for PLL Block ; The XO block uses an external clock supplied on the XO pin
#define	UPCR0_RCS_00					((~Hw12)&(~Hw11))		// Reference Clock Select for PLL Block ; The XO block uses the clock from a crystal
#define	UPCR0_RCD_48					Hw10					// Reference Clock Frequency Select ; 48MHz
#define	UPCR0_RCD_24					Hw9						// Reference Clock Frequency Select ; 24MHz
#define	UPCR0_RCD_12					((~Hw10)&(~Hw9))		// Reference Clock Frequency Select ; 12MHz
#define	UPCR0_SDI_EN					Hw8						// IDDQ Test Enable ; The analog blocks are powered down
#define	UPCR0_SDI_DIS					~Hw8					// IDDQ Test Disable ; The analog blocks are not powered down
#define	UPCR0_FO_SI						Hw7						// UTMI/Serial Interface Select ; Serial Interface
#define	UPCR0_FO_UTMI					~Hw7					// UTMI/Serial Interface Select ; UTMI
#define UPCR0_VBDS						Hw6
#define UPCR0_DMPD						Hw5						// 1:enable / 0:disable the pull-down resistance on D-
#define UPCR0_DPPD						Hw4						// 1: enable, 0:disable the pull-down resistance on D+
#define UPCR0_VBD						Hw1						// The VBUS signal is (1:valid)/(0:invalid), and the pull-up resistor on D+ is (1:enabled)/(0:disabled)

#define UPCR1_TXFSLST(x)				((x&0xF)<<12)
#define UPCR1_SQRXT(x)					((x&0x7)<<8)
#define UPCR1_OTGT(x)					((x&0x7)<<4)
#define UPCR1_CDT(x)					(x&0x7)

#define UPCR2_TM_FS						Hw14
#define UPCR2_TM_HS						0
#define UPCR2_XCVRSEL_LS_ON_FS			(Hw13|Hw12)
#define UPCR2_XCVRSEL_LS				Hw13
#define UPCR2_XCVRSEL_FS				Hw12
#define UPCR2_XCVRSEL_HS				0
#define UPCR2_OPMODE_MASK				(Hw10|Hw9)
#define UPCR2_OPMODE_SYNC_EOP			(Hw10|Hw9)
#define UPCR2_OPMODE_DIS_BITS_NRZI		Hw10
#define UPCR2_OPMODE_NON_DRVING			Hw9
#define UPCR2_OPMODE_NORMAL				0
#define UPCR2_TXVRT(x)					((x&0xF)<<5)
#define UPCR2_TXRT(x)					((x&0x3)<<2)
#define UPCR2_TP_EN						Hw0
#define UPCR2_TP_DIS					0

extern PUSBOTGCFG pOTGCFG;

unsigned char* USBPHY_TellLibraryVersion(void)
{
	return (unsigned char*)USBPHY_C_Version;
}

void USBPHY_SetMode(USBPHY_MODE_T mode)
{
	if( mode == USBPHY_MODE_RESET )
	{
		pOTGCFG->UPCR0	= 0x4870;
	}
	else if( mode == USBPHY_MODE_HOST )
	{
		pOTGCFG->UPCR0	= 0x2800;
		pOTGCFG->UPCR1	=
						UPCR1_TXFSLST(7)	// FS/LS Pull-Up Resistance Adjustment = Design default
						| UPCR1_SQRXT(3)	// Squelch Threshold Tune = -5%
						| UPCR1_OTGT(4)	// VBUS Valid Threshold Adjustment = Design default
						| UPCR1_CDT(3);	// Disconnect Threshold Adjustment = Design default
		pOTGCFG->UPCR2	=
						UPCR2_TM_HS
						| UPCR2_XCVRSEL_HS
						| UPCR2_OPMODE_NORMAL
						| UPCR2_TXVRT(8)	// HS DC voltage level adjustment = Design default
						| UPCR2_TXRT(0)	// HS Transmitter Rise/Fall Time Adjustment = Design default
						| UPCR2_TP_DIS;
		//pOTGCFG->UPCR3	= 0x9000;	// OTG disable
	}
	else if( mode == USBPHY_MODE_DEVICE )
	{
		pOTGCFG->UPCR0	= 0x2800;
		pOTGCFG->UPCR1	=
						UPCR1_TXFSLST(7)	// FS/LS Pull-Up Resistance Adjustment = Design default
						| UPCR1_SQRXT(3)	// Squelch Threshold Tune = -5%
						| UPCR1_OTGT(4)	// VBUS Valid Threshold Adjustment = Design default
						| UPCR1_CDT(3);	// Disconnect Threshold Adjustment = Design default
		pOTGCFG->UPCR2	=
						UPCR2_TM_HS
						| UPCR2_XCVRSEL_HS
						| UPCR2_OPMODE_NORMAL
						| UPCR2_TXVRT(8)	// HS DC voltage level adjustment = Design default
						| UPCR2_TXRT(0)	// HS Transmitter Rise/Fall Time Adjustment = Design default
						| UPCR2_TP_DIS;
		//pOTGCFG->UPCR3	= 0x9000;	// OTG disable
	}
}

#ifndef OTGID_ID_HOST
#define OTGID_ID_HOST						(~Hw9)
#endif
#ifndef OTGID_ID_DEVICE
#define OTGID_ID_DEVICE						Hw9
#endif
void USBPHY_SetID(unsigned int ID)
{
	if ( ID )
		pOTGCFG->OTGID |= OTGID_ID_DEVICE;
	else
		pOTGCFG->OTGID &= OTGID_ID_HOST;
}