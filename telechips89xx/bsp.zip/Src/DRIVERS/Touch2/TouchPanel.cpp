
/****************************************************************************
 *   FileName    : TouchPanel.cpp
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include <bsp.h>
#include "globals.h"
#include <types.h>
#include <memory.h>
#include <nkintr.h>
#include <tchddsi.h>
#include <tchpdd.h>
#include "tcc_gpio.h"


extern "C"
{
#include "tcc_touch.h"
}

DWORD m_nScreenHeight,m_nScreenWidth;
DWORD gIntrTouch;
DWORD gIntrTouchChanged=SYSINTR_NOP;


static HANDLE gTouchPenUpThread;
static HANDLE	ghTSADC;

static int prevX, prevY;    // record the last position
static unsigned int last_ticks;      // record the ticks when pendown
static TOUCH_PANEL_SAMPLE_FLAGS lastSampleFlag;     // record the sample flag

 PGPIO  pGPIO ;
 PTSADC g_pADCReg ;
void StartCalibrationThread();


#define PEN_DOWN -1
#define PEN_UP   -2
static int nStatus=0;

extern "C"{
     const int MIN_CAL_COUNT = 40;
	 BYTE	gI2CChNum;
}

extern PFN_TOUCH_PANEL_CALLBACK v_pfnPointCallback;


static BOOL TSP_CalibrationPointGet(TPDC_CALIBRATION_POINT *pTCP)
{

    INT32   cDisplayWidth  = pTCP->cDisplayWidth;
    INT32   cDisplayHeight = pTCP->cDisplayHeight;

    //RETAILMSG(1, (TEXT("[TOUCH       ]TSP_CalibrationPointGet:%d,%d\r\n"), cDisplayWidth, cDisplayHeight));

    int CalibrationRadiusX = cDisplayWidth  / 20;
    int CalibrationRadiusY = cDisplayHeight / 20;

    switch (pTCP -> PointNumber)
    {
    case    0:
        pTCP->CalibrationX = cDisplayWidth  / 2;
        pTCP->CalibrationY = cDisplayHeight / 2;
        break;

    case    1:
        pTCP->CalibrationX = CalibrationRadiusX * 2;
        pTCP->CalibrationY = CalibrationRadiusY * 2;
        break;

    case    2:
        pTCP->CalibrationX = CalibrationRadiusX * 2;
        pTCP->CalibrationY = cDisplayHeight - CalibrationRadiusY * 2;
        break;

    case    3:
        pTCP->CalibrationX = cDisplayWidth  - CalibrationRadiusX * 2;
        pTCP->CalibrationY = cDisplayHeight - CalibrationRadiusY * 2;
        break;

    case    4:
        pTCP->CalibrationX = cDisplayWidth - CalibrationRadiusX * 2;
        pTCP->CalibrationY = CalibrationRadiusY * 2;
        break;

    default:
        pTCP->CalibrationX = cDisplayWidth  / 2;
        pTCP->CalibrationY = cDisplayHeight / 2;

        SetLastError(ERROR_INVALID_PARAMETER);
        return (FALSE);
    }

    RETAILMSG(1, (TEXT("[TOUCH       ]::: TSP_CalibrationPointGet()\r\n")));
    RETAILMSG(1, (TEXT("[TOUCH       ]cDisplayWidth        : %4X\r\n"), cDisplayWidth     ));
    RETAILMSG(1, (TEXT("[TOUCH       ]cDisplayHeight       : %4X\r\n"), cDisplayHeight    ));
    RETAILMSG(1, (TEXT("[TOUCH       ]CalibrationRadiusX   : %4d\r\n"), CalibrationRadiusX));
    RETAILMSG(1, (TEXT("[TOUCH       ]CalibrationRadiusY   : %4d\r\n"), CalibrationRadiusY));
    RETAILMSG(1, (TEXT("[TOUCH       ]pTCP -> PointNumber  : %4d\r\n"), pTCP->PointNumber));
    RETAILMSG(1, (TEXT("[TOUCH       ]pTCP -> CalibrationX : %4d\r\n"), pTCP->CalibrationX));
    RETAILMSG(1, (TEXT("[TOUCH       ]pTCP -> CalibrationY : %4d\r\n"), pTCP->CalibrationY));

    return (TRUE);
}



extern "C"
BOOL DdsiTouchPanelGetDeviceCaps(INT iIndex,LPVOID  lpOutput)
{

    RETAILMSG(0, (TEXT("[TOUCH       ]::: DdsiTouchPanelGetDeviceCaps\r\n")));

    if ( lpOutput == NULL )
    {
        ERRORMSG(0, (__TEXT("TouchPanelGetDeviceCaps: invalid parameter.\r\n")));
        SetLastError(ERROR_INVALID_PARAMETER);
        DebugBreak();
        return (FALSE);
    }

    switch ( iIndex )
    {
        case TPDC_SAMPLE_RATE_ID:
            {
                TPDC_SAMPLE_RATE    *pTSR = (TPDC_SAMPLE_RATE*)lpOutput;
                RETAILMSG(0, (TEXT("[TOUCH       ]TouchPanelGetDeviceCaps::TPDC_SAMPLE_RATE_ID\r\n")));
    
                pTSR->SamplesPerSecondLow      = 3;
                pTSR->SamplesPerSecondHigh     = 10;
                pTSR->CurrentSampleRateSetting = 1;
            }
            break;
    
        case TPDC_CALIBRATION_POINT_COUNT_ID:
            {
                TPDC_CALIBRATION_POINT_COUNT *pTCPC = (TPDC_CALIBRATION_POINT_COUNT*)lpOutput;
                RETAILMSG(0, (TEXT("[TOUCH       ]TouchPanelGetDeviceCaps::TPDC_CALIBRATION_POINT_COUNT_ID\r\n")));
    
                pTCPC->flags              = 0;
                pTCPC->cCalibrationPoints = 5;
            }
            break;
    
        case TPDC_CALIBRATION_POINT_ID:
            RETAILMSG(0, (TEXT("[TOUCH       ]TouchPanelGetDeviceCaps::TPDC_CALIBRATION_POINT_ID\r\n")));
            return(TSP_CalibrationPointGet((TPDC_CALIBRATION_POINT*)lpOutput));
    
        default:
            ERRORMSG(1, (__TEXT("TouchPanelGetDeviceCaps: invalid parameter.\r\n")));
            SetLastError(ERROR_INVALID_PARAMETER);
            DebugBreak();
            return (FALSE);
    }

	return TRUE;
}


BOOL DdsiTouchPanelSetMode(INT iIndex,LPVOID  lpInput)
{
    BOOL  ReturnCode = FALSE;

    switch ( iIndex )
    {
        case TPSM_SAMPLERATE_LOW_ID:
        case TPSM_SAMPLERATE_HIGH_ID:
            SetLastError( ERROR_SUCCESS );
            ReturnCode = TRUE;
            break;

        default:
            SetLastError( ERROR_INVALID_PARAMETER );
            break;
    }


    return ( ReturnCode );
}

#include "tcc_ckc.h"
BOOL DdsiTouchPanelEnable(VOID)
{
	RETAILMSG(0,(TEXT("[TOUCH       ]+DdsiTouchPanelEnable\n")));

	// zminc 1. Open ADC Driver
	ghTSADC = CreateFile(L"ADC1:",
                        GENERIC_READ | GENERIC_WRITE,
						NULL,
						NULL,
						OPEN_ALWAYS,
						FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,
						NULL);

	if(!ghTSADC)
        RETAILMSG(TRUE,(TEXT("[TOUCH       ]:ERROR:Can't open ADC Driver!!\n")));

	RETAILMSG(1,(TEXT("[TOUCH       ]ADC setting end\n")));
	
	//kerneliocontrol get sysintr
	//return sysintr
	BITCSET(pGPIO->EINTSEL0,Hw22-Hw16,58<<16);

	PPIC pPIC;
	pPIC = (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);
	BITSET(pPIC->POL0,Hw5);
	
	DWORD IRQ = IRQ_EI2;

	KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &IRQ, sizeof(DWORD), &gIntrTouch, sizeof(UINT32), NULL);

		// Create a calibration thread. This thread will check to see if calibration is needed.
	StartCalibrationThread();
	RETAILMSG(0,(TEXT("[TOUCH       ]-DdsiTouchPanelEnable\n")));
	
	return gIntrTouch;
}



VOID DdsiTouchPanelDisable(VOID)
{
}


// To grab PENUP event
static void TouchPenUpThread(void)
{

}

LONG DdsiTouchPanelAttach(VOID)
{	
	HKEY    hk;
	DWORD   dwStatus;
	DWORD	dwSize,dwType;
	
	m_nScreenHeight=m_nScreenWidth=0;

	dwStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Drivers\\Display\\Magellan\\CONFIG", 0, 0, &hk);
	dwType = REG_DWORD;

	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hk, _T("LCD_Width"), NULL, &dwType, (LPBYTE) &m_nScreenWidth, &dwSize);
	}

	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hk, _T("LCD_Height"), NULL, &dwType, (LPBYTE) &m_nScreenHeight, &dwSize);
	}
	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{
		gI2CChNum=0;
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hk, _T("TouchI2C"), NULL, &dwType, (LPBYTE) &gI2CChNum, &dwSize);
	}
	if(hk != NULL) 
	{
		RegCloseKey(hk);
	}
	pGPIO = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	g_pADCReg = (PTSADC)tcc_allocbaseaddress((unsigned int)&HwTSADC_BASE);
	
	
    RETAILMSG(1, (TEXT("[TOUCH       ]Touchpanel DRV :LCD Size = %dX%d,I2C Channel Num(%d)\r\n"),m_nScreenWidth,m_nScreenHeight,gI2CChNum));
    return 1;
}


LONG DdsiTouchPanelDetach(VOID)
{
    return 0;
}

void tca_touchbubblesort(unsigned int Number[],unsigned int num) 
{
	int i,j;
	unsigned int temp;
	for(i=0 ; i<(int)(num-1) ; i++)   
	{    
		for(j=i+1;j<(int)num;j++)
		{ 
			if(Number[i]>Number[j]) 
			{ 
				temp   = Number[i]; 
				Number[i] = Number[j]; 
				Number[j] = temp;
			}
		} 
	}
}


#ifdef _USING_GPIO_MODE_	
#define MAX_X  	3890
#define MIN_X  	230
#define MAX_Y 	3690
#define MIN_Y  	440
#else
#if _OLD_BOARD_
#define MAX_X  	3100
#define MIN_X  	1050
#define MAX_Y 	2680
#define MIN_Y  	1360
#else
#define MAX_X  	3150
#define MIN_X  	970
#define MAX_Y 	2690
#define MIN_Y  	1340
#endif
#endif
//for the digi_int_handle
#define TOUCH_COLLECT_NR		16  // (TOUCH_COLLECT_NR-TOUCH_VALID_VALUE) must be even
#define TOUCH_VALID_VALUE		8  // among COLLECT_NR samples, OK should be over 
#define TOUCH_PRESSURE_LIMIT	8000

typedef struct _XYPOS{
        int xpos;
        int ypos;
        int xp;
        int ym;
}TSXYPOS, *PTSXYPOS;

int tca_getrawdata(int * x, int * y)
{

	unsigned int  i;
	unsigned int r_x[TOUCH_COLLECT_NR], r_y[TOUCH_COLLECT_NR];
	unsigned long  x_tol, y_tol;
	unsigned int m_pos_x, m_pos_y;
	unsigned int validcnt=0;
	unsigned int index;

	m_pos_x = m_pos_y = 0;


	//RETAILMSG(1,(TEXT("get data:%d \n"),GetTickCount()-tmp));

#if 0
	for(i = 0; i < TOUCH_COLLECT_NR; i ++)
	{

		int x, y, xp, ym;
		//TSXYPOS POS;
#ifdef _USING_GPIO_MODE_		
		//DeviceIoControl(ghTSADC, IOCTL_TSADC_TOUCHSCREEN_GPIO, NULL, 0, &POS, sizeof(TSXYPOS), NULL, NULL);
		x = POS[i].xpos;
		y = POS[i].ypos;
		xp = POS[i].xp;
		ym = POS[i].ym;

		RETAILMSG(1, (TEXT("[TOUCH       ]RAW:(%d,%d,%d,%d,(%d))\r\n"), x, y,xp,ym,ym-xp));


		if(
			(x <= MAX_X) && (x >= MIN_X) 
			&& (y <= MAX_Y) && (y >= MIN_Y) 
			&& (ym-xp < 250)
		  )
		{
			r_x[validcnt]=x;
			r_y[validcnt]=y;
			validcnt++;
		}
#else
		DeviceIoControl(ghTSADC, IOCTL_TSADC_TOUCHSCREEN, NULL, 0, &POS, sizeof(TSXYPOS), NULL, NULL);
		
		x = POS.xpos;
		y = POS.ypos;
		
		RETAILMSG(0, (TEXT("[TOUCH       ]RAW:(%d,%d)\r\n"), x, y));

		if(
			(x <= MAX_X) && (x >= MIN_X) 
			&& (y <= MAX_Y) && (y >= MIN_Y) 
		  )
		{

			r_x[validcnt]=x;
			r_y[validcnt]=y;
			validcnt++;
		}
#endif
	}
	
	if(validcnt<TOUCH_VALID_VALUE)
	{
		goto digi_int_exit;
	}

	tca_touchbubblesort(r_x,TOUCH_COLLECT_NR);	
	tca_touchbubblesort(r_y,TOUCH_COLLECT_NR);

	x_tol = y_tol = 0; //sum the coordinate values
	index = (validcnt-TOUCH_VALID_VALUE)>>1;

	for(i=index;i<(index+TOUCH_VALID_VALUE);++i)
	{

		x_tol += r_x[i];
		y_tol += r_y[i];		
	}
	m_pos_x = x_tol/TOUCH_VALID_VALUE;
	m_pos_y = y_tol/TOUCH_VALID_VALUE;
	*x = m_pos_x;
	*y = m_pos_y;
#else

#ifndef _USING_GPIO_MODE_
	TSXYPOS POS[16];
	DWORD tmp=GetTickCount();
	for(i=0; i<16; i++)
	{
		DeviceIoControl(ghTSADC, IOCTL_TSADC_TOUCHSCREEN, NULL, 0, &POS[i], sizeof(TSXYPOS), NULL, NULL);
		r_x[i] = POS[i].xpos;
		r_y[i] = POS[i].ypos;
	}

	tca_touchbubblesort(r_x,16);	
	tca_touchbubblesort(r_y,16);

	x_tol = y_tol = 0; //sum the coordinate values
	index = 4;

	for(i=index;i<(index+TOUCH_VALID_VALUE);++i)
	{

		x_tol += r_x[i];
		y_tol += r_y[i];		
	}
	m_pos_x = x_tol/8;
	m_pos_y = y_tol/8;

	RETAILMSG(1, (TEXT("%d,%d\r\n"), m_pos_x, m_pos_y));
	*x = m_pos_x;
	*y = m_pos_y;

#else
	TSXYPOS POS[16];
	DWORD tmp=GetTickCount();
	DeviceIoControl(ghTSADC, IOCTL_TSADC_TOUCHSCREEN_GPIO, NULL, 0, POS, sizeof(TSXYPOS)*16, NULL, NULL);

	x_tol = y_tol = 0;
	validcnt=0;
	for(int k=0; k < TOUCH_COLLECT_NR; k++)
	{
//		RETAILMSG(1, (TEXT("[TOUCH       ]RAW:(%d,%d,%d,%d,(%d))\r\n"), POS[k].xpos, POS[k].ypos,POS[k].xp,POS[k].ym,(POS[k].ym*1000)/POS[k].xp));
	//	RETAILMSG(1, (TEXT("%d,%d,%d,%d\r\n"), POS[k].xpos, POS[k].ypos,POS[k].xp,POS[k].ym));
		if((POS[k].xp > 100))
		{
			r_x[validcnt] = POS[k].xpos;
			r_y[validcnt] = POS[k].ypos;
			validcnt++;
		}
	}
	if(validcnt < 8)
	{
		*x = 0;
		*y = 0;
		return -1;
	}

	tca_touchbubblesort(r_x,validcnt);	
	tca_touchbubblesort(r_y,validcnt);

	x_tol = y_tol = 0; //sum the coordinate values
	index = (validcnt-8)/2;

	for(i=index;i<(index+8);++i)
	{

		x_tol += r_x[i];
		y_tol += r_y[i];		
	}
	m_pos_x = x_tol/8;
	m_pos_y = y_tol/8;

	//RETAILMSG(1, (TEXT("%d,%d\r\n"), m_pos_x, m_pos_y));
	*x = m_pos_x;
	*y = m_pos_y;
	//RETAILMSG(1, (TEXT("[TOUCH       ]RAW:(%d,%d)\r\n"),*x, *y));
#endif
#endif

	if(1) //(*x <= MAX_X && *x >= MIN_X)&&(*y <= MAX_Y && *y >= MIN_Y))
	{
		return 0;
	}
	else
	{
		return -1;
	}
digi_int_exit:
	*x = 0;
	*y = 0;
	return -1;


}

void tca_rawtoscreen(int *x, int *y, unsigned int iScreenWidth, unsigned int iScreenHeight)
{
	unsigned int posX, posY;


	if(*x>MAX_X)
		*x=MAX_X;
	else if(*x<MIN_X)
		*x=MIN_X;

	if(*y>MAX_Y)
		*y=MAX_Y;
	else if(*y<MIN_Y)
		*y=MIN_Y;

	posX = (MAX_X-*x)*iScreenWidth/(MAX_X-MIN_X);
	posY = (*y-MIN_Y)*iScreenHeight/(MAX_Y-MIN_Y);

	*x = posX<<2;
	*y = posY<<2;
}
/*
void tca_tch_poweroff()
{
	g_pADCReg->ADCCLRINT = Hw0;
	g_pADCReg->ADCCLRUPDN = Hw0;
	g_pADCReg->ADCTSC |= ADCTSC_WAIT_PENDOWN;

}
*/
void DdsiTouchPanelGetPoint(TOUCH_PANEL_SAMPLE_FLAGS *pTipStateFlags,INT *pUncalX,INT *pUncalY)
{
    int posX,posY;
    int retFlag;
    //static unsigned int last_ticks=0;
    RETAILMSG(0, (TEXT("[TOUCH       ]+DdsiTouchPanelGetPoint\r\n")));
    retFlag = tca_getrawdata(&posX, &posY);
    RETAILMSG(0, (TEXT("[TOUCH       ]RAW:(%d,%d)\r\n"), posX, posY));

//	tca_tch_poweroff();
	
	Sleep(20);   // Release some time to other threads

	//tca_rawtoscreen(&posX, &posY, m_nScreenWidth, m_nScreenHeight);

    if (retFlag == 0) // Valid touch pen
    {
        RETAILMSG(0, (TEXT("[TOUCH       ]-->(%d,%d)\r\n"), posX/4,posY/4));
        *pTipStateFlags =*pTipStateFlags | TouchSampleValidFlag | TouchSampleDownFlag;			
        *pTipStateFlags &= ~TouchSampleIgnore;           
        nStatus = PEN_DOWN;    
        prevX = posX;
        prevY = posY;
    }
    else
    {
        posX = prevX;
        posY = prevY;
        *pTipStateFlags |= TouchSampleIgnore;
        *pTipStateFlags &= ~(TouchSampleValidFlag);
    }
    lastSampleFlag = *pTipStateFlags;            
    *pUncalX = posX;
    *pUncalY = posY;
    RETAILMSG(0, (TEXT("[TOUCH       ](%d,%d, %x)\n"), posX/4,posY/4, *pTipStateFlags));

	InterruptDone(gIntrTouch);
	RETAILMSG(0, (TEXT("[TOUCH       ]-DdsiTouchPanelGetPoint\r\n")));
    return;
}

void DdsiTouchPanelPowerHandler(BOOL bOff)
{


}

#define RK_TOUCH  	(TEXT("HARDWARE\\DEVICEMAP\\TOUCH"))
#define RV_DATA		(TEXT("CalibrationData"))

static DWORD CalibrationThread()
{
	HKEY hKey;
	DWORD dwType;
	DWORD dwRet;
	HANDLE hEvent;

	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, RK_TOUCH, 0, KEY_ALL_ACCESS, &hKey))
	{
		dwRet = RegQueryValueEx(hKey, RV_DATA, 0, &dwType, NULL, NULL);
		RegCloseKey(hKey);
		if (dwRet == ERROR_SUCCESS)
		{
			RETAILMSG(1, (TEXT("[TOUCH       ] Exist Calibration Data..!\n")));
			return 1;
		}

		//wait until ready of GWES
		hEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, TEXT("SYSTEM/GweApiSetReady"));
		if (hEvent)
		{
			WaitForSingleObject(hEvent, INFINITE);
			CloseHandle(hEvent);
		}
		//calibration execute
		TouchCalibrate();
	}
	
	if(hKey != NULL) 
	{
		RegCloseKey(hKey);
	}


	return 1;
}

void StartCalibrationThread()
{
	HANDLE hThread;
	hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CalibrationThread, NULL, 0, NULL);
	CloseHandle(hThread);
}
