/****************************************************************************
 *   FileName    : tca_tsc2003tchctl.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCA_TSC2003TCHCTL_H__
#define __TCA_TSC2003TCHCTL_H__

#if !defined(_TCA_TSC2003CTRL_)
#define _TCA_TSC2003CTRL_

void tca_tsc2003_init(void);
void tca_tsc2003_poweroff(void);
void tca_tsc2003_setreadcmd(int channel, unsigned char *nBfrTXD);

#endif

#endif	/*__TCA_TSC2003TCHCTL_H__*/

