/****************************************************************************
 *   FileName    : tca_tchhwctl.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#if !defined(_TCA_TCH_HWCTRL_)
#define _TCA_TCH_HWCTRL_

#ifdef CONFIG_TOUCHSCREEN_TCC_AK4183
#define _TOUCH_AK4183_
#endif
#ifdef CONFIG_TOUCHSCREEN_TCC_TSC2003
#define _TOUCH_TSC2003__
#endif

void tca_tchhw_enableirq(void);
void tca_tchhw_disableirq(void);
unsigned int tca_tchhw_getirqnum(void);
void tca_tchhw_initport(void);

#endif

