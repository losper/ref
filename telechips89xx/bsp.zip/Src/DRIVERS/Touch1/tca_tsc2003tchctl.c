#include "tca_tchcontrol.h"
#include "tca_tchhwctl.h"

#define SC2003_CMD_MEASURE_X	(12<<4)
#define SC2003_CMD_MEASURE_Y	(13<<4)

#define SC2003_CMD_MEASURE_Z1	(14<<4)
#define SC2003_CMD_MEASURE_Z2	(15<<4)

#define SC2003_CMD_XY_OFF		(0<<4)

#define SC2003_CMD_POWER_0		(0<<2)
#define SC2003_CMD_POWER_1		(1<<2)
#define SC2003_CMD_POWER_2		(2<<2)
#define SC2003_CMD_POWER_3		(3<<2)

void tca_tsc2003_setreadcmd(int channel, unsigned char *nBfrTXD)
{
	if(channel == READ_X)
		nBfrTXD[0] = SC2003_CMD_MEASURE_X | SC2003_CMD_POWER_3;
	else if(channel == READ_Y)
		nBfrTXD[0] = SC2003_CMD_MEASURE_Y | SC2003_CMD_POWER_3;
	else if(channel == READ_Z1)
		nBfrTXD[0] = SC2003_CMD_MEASURE_Z1 | SC2003_CMD_POWER_3;
	else if(channel == READ_Z2)
		nBfrTXD[0] = SC2003_CMD_MEASURE_Z2 | SC2003_CMD_POWER_3;

}

void tca_tsc2003_poweroff(void)
{
	tea_tch_writei2c(SC2003_CMD_XY_OFF | SC2003_CMD_POWER_0);	
}

void tca_tsc2003_init(void)
{
	tca_tsc2003_poweroff();
}


