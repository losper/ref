/****************************************************************************
 *   FileName    : tca_tchcontrol.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include "tca_tchcontrol.h"
#include "tca_tchhwctl.h"

#if defined(_TOUCH_AK4183_)
#include "tca_ak4183tchctl.h"
#else
#include "tca_tsc2003tchctl.h"
#endif

#define MAX_X  	3870
#define MIN_X  	170
#define MAX_Y 	3800
#define MIN_Y  	290


//for the digi_int_handle
#define TOUCH_COLLECT_NR		4  // (TOUCH_COLLECT_NR-TOUCH_VALID_VALUE) must be even
#define TOUCH_VALID_VALUE		2  // among COLLECT_NR samples, OK should be over 
#define TOUCH_PRESSURE_LIMIT	8000


// Initialize related registers
void tca_tch_init(void)
{

	tea_tch_openi2c();
	
	tca_tchhw_initport();

#if	defined(_TOUCH_AK4183_)
	tca_ak4183_init();
#else
	tca_tsc2003_init();
#endif

}

void tca_tch_poweroff(void)
{
#if	defined(_TOUCH_AK4183_)
#ifdef __KERNEL__
    tca_ak4183_poweroff();
#endif
#else
	tca_tsc2003_poweroff();
#endif
}


void tca_touchbubblesort(unsigned int Number[],unsigned int num) 
{
	int i,j;
	unsigned int temp;
	for(i=0 ; i<(int)(num-1) ; i++)   
	{    
		for(j=i+1;j<(int)num;j++)
		{ 
			if(Number[i]>Number[j]) 
			{ 
				temp   = Number[i]; 
				Number[i] = Number[j]; 
				Number[j] = temp;
			}
		} 
	}
}

int tca_getrawdata2(int * x, int * y)
{
	int i;
	unsigned int nDatax, nDatay,nDataz1,nDataz2;
	for(i=0; i < 1; i++)
	{
		nDatax = tea_tch_readi2c(READ_X);
		nDatay = tea_tch_readi2c(READ_Y);
		nDataz1 = tea_tch_readi2c(READ_Z1);

		if(nDataz1!=0)
		{
			nDataz2 = tea_tch_readi2c(READ_Z2);
			if((nDatax*nDataz2/nDataz1-nDatax)<TOUCH_PRESSURE_LIMIT)
			{
				*x = nDatax;
				*y = nDatay;
				return 0;
			}
		}
		else
		{
		}
			
	}	
	return -1;
}

int tca_getrawdata(int * x, int * y)
{
	unsigned int  i, ValidNum;
	unsigned int r_x[TOUCH_COLLECT_NR], r_y[TOUCH_COLLECT_NR];
	unsigned long  x_tol, y_tol;
	unsigned int m_pos_x, m_pos_y;
	unsigned int z1,z2;
	unsigned int index;
	
	m_pos_x = m_pos_y = 0;
	ValidNum = 0; 
	for(i = 0; i < TOUCH_COLLECT_NR; i ++)
	{
		r_x[ValidNum] = tea_tch_readi2c(READ_X);
		r_y[ValidNum] = tea_tch_readi2c(READ_Y);

		if((r_x[ValidNum] != 0)&&(r_y[ValidNum] != 0)) 
		{		
			z1 = tea_tch_readi2c(READ_Z1);
			if(z1!=0)
			{
				z2 = tea_tch_readi2c(READ_Z2);
				if((r_x[ValidNum]*z2/z1-r_x[ValidNum])<TOUCH_PRESSURE_LIMIT)
					ValidNum++;
			}				
		}
		
	}
	if(ValidNum<TOUCH_VALID_VALUE)
	{
		goto digi_int_exit;
	}
    
	tca_touchbubblesort(r_x,ValidNum);	
	tca_touchbubblesort(r_y,ValidNum);
	
	x_tol = y_tol = 0; //sum the coordinate values
	index = (ValidNum-TOUCH_VALID_VALUE)>>1;
	
	for(i=index;i<(index+TOUCH_VALID_VALUE);++i)
	{
		x_tol += r_x[i];
		y_tol += r_y[i];		
	}
	m_pos_x = x_tol/TOUCH_VALID_VALUE;
	m_pos_y = y_tol/TOUCH_VALID_VALUE;
    
digi_int_exit:
	*x = m_pos_x;
	*y = m_pos_y;
	if(m_pos_x && m_pos_y)
	{
		return 0;
	}
	else
	{
		return -1;
	}


 }

void tca_rawtoscreen(int *x, int *y, unsigned int iScreenWidth, unsigned int iScreenHeight)
{
    unsigned int posX, posY;
    

	if(*x>MAX_X)
		*x=MAX_X;
	else if(*x<MIN_X)
		*x=MIN_X;

	if(*y>MAX_Y)
		*y=MAX_Y;
	else if(*y<MIN_Y)
		*y=MIN_Y;

	posX = (MAX_X-*x)*iScreenWidth/(MAX_X-MIN_X);
	posY = (*y-MIN_Y)*iScreenHeight/(MAX_Y-MIN_Y);

    *x = posX<<2;
    *y = posY<<2;
}


