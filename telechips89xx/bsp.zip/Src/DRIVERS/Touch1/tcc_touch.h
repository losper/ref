/****************************************************************************
 *   FileName    : tcc_touch.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#if !defined(_TCC_TOUCH_)
#define _TCC_TOUCH_

unsigned int tcc_tch_getsysintr(void);
void tcc_tch_enableinterrupt(void);

#endif