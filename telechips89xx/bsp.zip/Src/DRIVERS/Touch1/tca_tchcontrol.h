/****************************************************************************
 *   FileName    : tca_tchcontrol.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef _TCHCONTROL_H_
#define _TCHCONTROL_H_

#define READ_X	0
#define READ_Y	1
#define READ_Z1 2
#define READ_Z2 3

void tca_tch_init(void);
void tca_tch_poweroff(void);
void tca_rawtoscreen(int *, int *, unsigned int, unsigned int);
int tca_getrawdata(int * x, int *y);
int tca_getrawdata2(int * x, int *y);
void tca_touchbubblesort(unsigned int Number[],unsigned int num) ;
extern void tea_tch_openi2c(void);
extern short tea_tch_readi2c(int channel);
extern int tea_tch_writei2c(unsigned char cmd);
extern void Serial_Printf(int x, int y, int z1, int z2, int tmp);

#endif
