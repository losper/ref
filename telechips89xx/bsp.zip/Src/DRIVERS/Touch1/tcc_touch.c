#include <windows.h>
#include <types.h>
#include <nkintr.h>
#include "bsp.h"

#include "tca_tchhwctl.h"
#include "tca_tchcontrol.h"
#include "tca_tsc2003tchctl.h"
#include "../I2c1/TCC_I2C.h"
#include "../inc/ioctl_code.h"
#include "tcc_gpio.h"



HANDLE  ghI2C;
extern BYTE gI2CChNum;
extern DWORD gIntrTouch;





int tea_tch_writei2c(unsigned int cmd)
{
	BOOL nRet;
	DWORD nTemp=cmd;
	DWORD returned_bytes;
	I2C_Param sendParam;

	RETAILMSG(0,(TEXT("tea_tch_writei2c command [%x]\n"), nTemp));

	sendParam.DeviceAddr = 0x90;
	sendParam.nMode = 1;
	sendParam.nWriteByte = 1;
	sendParam.pWriteBuffer =(BYTE *)&nTemp;
	sendParam.nPort = gI2CChNum;
	sendParam.nTimeout	 = 100;


	nRet = DeviceIoControl(ghI2C,
		IOCTL_I2C_WRITE,
		&sendParam,
		sizeof(I2C_Param),
		NULL,
		0,
		&returned_bytes,
		NULL) ;

	if(!returned_bytes)
	{
		RETAILMSG(1,(TEXT("[%d]IOCTL_I2C_WRITE Ret Value FAIL\n"),nRet));
	}

	return nRet;
}

short tea_tch_readi2c(int channel)
{
	short value;
	I2C_Param sendParam;
	RetParam recvParam;
	BYTE nBfrTXD[2], nBfrRXD[2];
	DWORD returned_bytes;
	BOOL bRet;

	RETAILMSG(0,(TEXT("tea_tch_readi2c command [%x][%d]\n"),channel,GetTickCount()));
	sendParam.DeviceAddr = 0x90;
	sendParam.nMode = 1;
	sendParam.nPort = gI2CChNum;
	sendParam.nTimeout	 = 100;


	sendParam.nWriteByte = 1;
	tca_tsc2003_setreadcmd(channel, nBfrTXD);


	sendParam.pWriteBuffer = nBfrTXD;
	sendParam.nReadByte    = 2;
	sendParam.pReadBuffer  = nBfrRXD;

	bRet = DeviceIoControl(ghI2C,
		IOCTL_I2C_READ,
		&sendParam,
		sizeof(I2C_Param),
		&recvParam,
		sizeof(RetParam),
		&returned_bytes,
		NULL);

	if(returned_bytes) 
	{

		RETAILMSG(0,(TEXT("[%d]RET Value[%x][%x][%d]\n"),
			bRet,
			(unsigned long)recvParam.pReadBuffer[0],
			(unsigned long)recvParam.pReadBuffer[1],
			recvParam.nReadByte));		

		value  = ( recvParam.pReadBuffer[0] & 0x00ff) << 4;
		value |= (recvParam.pReadBuffer[1] & 0x00ff) >> 4;
		value &= 0xfff;

		RETAILMSG(0,(TEXT("[%x][%d]\n"),value,GetTickCount()));

		return value;
	}
	else
		RETAILMSG(0,(TEXT("[%d]IOCTL_I2C_READ Ret Value FAIL\n"),bRet));
	return 0;
}


void tea_tch_openi2c(void)
{
	ghI2C =  CreateFile(L"I2C1:",
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	if(!ghI2C)
		RETAILMSG(0,(TEXT("ERROR: Can't open I2C Driver !!\n")));

}

unsigned int tcc_tch_getsysintr(void)
{	

    UINT32 irq;
	PGPIO pGPIO;
	PPIC pPIC;
	irq = IRQ_EI4;
	pPIC = (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);
	
	BITSET(pPIC->POL0,Hw7);

	
	pGPIO = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	BITCSET(pGPIO->EINTSEL1,0x3F,4);

	BITCLR(pGPIO->GPAFN0, (Hw20-Hw16)); //GPIOA[4] function set 0
	BITCLR(pGPIO->GPAEN, Hw4); //GPIOA[4] InputMode

    if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &irq, sizeof(UINT32), &gIntrTouch, sizeof(UINT32), NULL))
    {
        RETAILMSG(0, (TEXT("ERROR: Failed to request the touch panel sysintr.\r\n")));
        gIntrTouch = SYSINTR_UNDEFINED;
		return FALSE;
    }


	return TRUE;
}

void tcc_tch_enableinterrupt(void)
{
  InterruptDone(gIntrTouch);
}

