
/****************************************************************************
 *   FileName    : tchbasic.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include    <windows.h>
#include    <types.h>
#include    <memory.h>
#include    <nkintr.h>
#include    <tchddi.h>
#include    <tchddsi.h>

PFN_TOUCH_PANEL_CALLBACK v_pfnCgrPointCallback;
PFN_TOUCH_PANEL_CALLBACK v_pfnCgrCallback = NULL;
extern ULONG   culReferenceCount;              //@globalvar ULONG | culReferenceCount | Count of attached threads
extern PFN_TOUCH_PANEL_CALLBACK v_pfnPointCallback;
extern HANDLE hThread;


/*++
Autodoc Information:

    @func BOOL | TouchPanelDllEntry |
    Dll entry point.

    @rdesc
    TRUE if the function succeeds. Otherwise, FALSE.

--*/
BOOL
TouchPanelDllEntry(
    HANDLE  hinstDll,    //@parm Process handle.
    DWORD   fdwReason,   //@parm Reason for calling the function.
    LPVOID  lpvReserved  //@parm Reserved, not used.
    )
{

    BOOL ReturnCode = TRUE;

    switch ( fdwReason )
    {
        case DLL_PROCESS_ATTACH:
            DisableThreadLibraryCalls((HMODULE) hinstDll);
             //
             // Process is attaching.  We allow only 1 process to be attached.
             // If our global counter (maintained by the PDD) is greater than 0,
             //   error.
             //

            if ( DdsiTouchPanelAttach() > 1 )
            {
                DEBUGMSG( ZONE_FUNCTION, (TEXT("DdsiTouchPanelAttach > 1\r\n")) );
                DdsiTouchPanelDetach(); // if a process attach fails, the detach is
                 // never called. So adjust the count here.
                ReturnCode = FALSE;
            }

            break;
        case DLL_PROCESS_DETACH:
            DEBUGMSG( ZONE_FUNCTION,
                      (TEXT("Dll Process Detach\r\n")) );

             //
             // Process is detaching.
             // If the detaching process is the process that was allowed
             // to attach, we reset the callback functions,
             // reference count, disable the touch panel, and disconnect from the
             // logical interrupt.
             //
             //
            ASSERT(hThread==NULL);
            DdsiTouchPanelDetach();
            break;
    }
    return ( ReturnCode );
}
