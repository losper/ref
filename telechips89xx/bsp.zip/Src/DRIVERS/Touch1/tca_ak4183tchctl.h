/****************************************************************************
 *   FileName    : tca_ak4183tchctl.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#if !defined(_TCA_AK4180CTRL_)
#define _TCA_AK4180CTRL_

void tca_ak4183_setreadcmd(int channel, unsigned char *nBfrTXD);
void tca_ak4183_init(void);
void tca_ak4183_sleep(void);
void tca_ak4183_poweroff(void);

#endif
