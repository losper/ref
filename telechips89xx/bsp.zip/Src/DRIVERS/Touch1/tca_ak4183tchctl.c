/****************************************************************************
 *   FileName    : tca_ak4183tchctl.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include "tca_tchcontrol.h"


#define	AK4183_CMD_ACTIVATE_X	(0x84)
#define	AK4183_CMD_ACTIVATE_Y	(0x94)

#define	AK4183_CMD_MEASURE_X	(0xC4)
#define	AK4183_CMD_MEASURE_Y	(0xD0)

#define AK4183_CMD_ACTIVATE_Z1	(0xA4)
#define AK4183_CMD_ACTIVATE_Z2	(0xB4)

#define	AK4183_CMD_MEASURE_Z1	(0xE4)
#define	AK4183_CMD_MEASURE_Z2	(0xF0)

#define AK4183_CMD_SLEEP_NO     (0x80)
#define AK4183_CMD_ACCEL_OFF    (0x40)
#define AK4183_CMD_ADC_ON       (0x04)

#define AK4183_CMD_SLEEP_HIZ	(0x72) //penirqn - high impedance
#define AK4183_CMD_SLEEP_H		(0x70) //penirqn - "H" output



void tca_ak4183_setreadcmd(int channel, unsigned char *nBfrTXD)
{
	if(channel == READ_X)
	{
		nBfrTXD[0] = AK4183_CMD_ACTIVATE_X;
		nBfrTXD[1] = AK4183_CMD_MEASURE_X;
	}
	else if	(channel == READ_Y)
	{
		nBfrTXD[0] = AK4183_CMD_ACTIVATE_Y;
		nBfrTXD[1] = AK4183_CMD_MEASURE_Y;
	}
	else if(channel == READ_Z1)
	{
		nBfrTXD[0] = AK4183_CMD_ACTIVATE_Z1;
		nBfrTXD[1] = AK4183_CMD_MEASURE_Z1;
	}
	else if(channel == READ_Z2)
	{
		nBfrTXD[0] = AK4183_CMD_ACTIVATE_Z2;
		nBfrTXD[1] = AK4183_CMD_MEASURE_Z2;
	}

}

void tca_ak4183_poweroff(void)
{
	tea_tch_writei2c(AK4183_CMD_SLEEP_NO| AK4183_CMD_ACCEL_OFF);	
}

void tca_ak4183_init(void)
{
#ifdef __KERNEL__
    tca_ak4183_poweroff();
#else
	tea_tch_readi2c(READ_X);
	tea_tch_readi2c(READ_Y);
#endif
}
void tca_ak4183_sleep(void)
{
	tea_tch_writei2c(AK4183_CMD_SLEEP_H);
}
