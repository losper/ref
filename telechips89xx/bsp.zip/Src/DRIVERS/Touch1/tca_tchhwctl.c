#ifdef __KERNEL__
#   if defined(_TCC79x_)
#       include <asm/arch/tcc79x.h>
#   elif defined(_TCC83x_)
#       include <asm/arch/tcc83x_virt.h>
#       include <asm/arch/irqs.h>
#   endif
#else
#   if defined(_TCC79x_)
#       include "TCC89x_Physical.h"
#   elif defined(_TCC83x_)
#       include "TCC83x_Virtual.h"
#   endif
#endif

void tca_tchhw_initport(void)
{



}



