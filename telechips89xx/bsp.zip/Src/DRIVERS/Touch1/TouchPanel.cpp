
/****************************************************************************
 *   FileName    : TouchPanel.cpp
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include <windows.h>
#include <types.h>
#include <memory.h>
#include <nkintr.h>
#include <tchddsi.h>
#include <tchpdd.h>


extern "C"
{
#include "tca_tchcontrol.h"
#include "tca_tchhwctl.h"
#include "tcc_touch.h"
#if defined(_TOUCH_AK4183_)
#include "tca_ak4183tchctl.h"
#else
#include "tca_tsc2003tchctl.h"
#endif
}

DWORD m_nScreenHeight,m_nScreenWidth;
DWORD gIntrTouch;
DWORD gIntrTouchChanged=SYSINTR_NOP;


static HANDLE gTouchPenUpThread;

static int prevX, prevY;    // record the last position
static unsigned int last_ticks;      // record the ticks when pendown
static TOUCH_PANEL_SAMPLE_FLAGS lastSampleFlag;     // record the sample flag


#define PEN_DOWN -1
#define PEN_UP   -2
static int nStatus=0;

extern "C"{
     const int MIN_CAL_COUNT = 40;
	 BYTE	gI2CChNum;
}

extern PFN_TOUCH_PANEL_CALLBACK v_pfnPointCallback;


static BOOL TSP_CalibrationPointGet(TPDC_CALIBRATION_POINT *pTCP)
{

    INT32   cDisplayWidth  = pTCP->cDisplayWidth;
    INT32   cDisplayHeight = pTCP->cDisplayHeight;

    //RETAILMSG(1, (TEXT("TSP_CalibrationPointGet:%d,%d\r\n"), cDisplayWidth, cDisplayHeight));

    int CalibrationRadiusX = cDisplayWidth  / 20;
    int CalibrationRadiusY = cDisplayHeight / 20;

    switch (pTCP -> PointNumber)
    {
    case    0:
        pTCP->CalibrationX = cDisplayWidth  / 2;
        pTCP->CalibrationY = cDisplayHeight / 2;
        break;

    case    1:
        pTCP->CalibrationX = CalibrationRadiusX * 2;
        pTCP->CalibrationY = CalibrationRadiusY * 2;
        break;

    case    2:
        pTCP->CalibrationX = CalibrationRadiusX * 2;
        pTCP->CalibrationY = cDisplayHeight - CalibrationRadiusY * 2;
        break;

    case    3:
        pTCP->CalibrationX = cDisplayWidth  - CalibrationRadiusX * 2;
        pTCP->CalibrationY = cDisplayHeight - CalibrationRadiusY * 2;
        break;

    case    4:
        pTCP->CalibrationX = cDisplayWidth - CalibrationRadiusX * 2;
        pTCP->CalibrationY = CalibrationRadiusY * 2;
        break;

    default:
        pTCP->CalibrationX = cDisplayWidth  / 2;
        pTCP->CalibrationY = cDisplayHeight / 2;

        SetLastError(ERROR_INVALID_PARAMETER);
        return (FALSE);
    }

    RETAILMSG(1, (TEXT("::: TSP_CalibrationPointGet()\r\n")));
    RETAILMSG(1, (TEXT("cDisplayWidth        : %4X\r\n"), cDisplayWidth     ));
    RETAILMSG(1, (TEXT("cDisplayHeight       : %4X\r\n"), cDisplayHeight    ));
    RETAILMSG(1, (TEXT("CalibrationRadiusX   : %4d\r\n"), CalibrationRadiusX));
    RETAILMSG(1, (TEXT("CalibrationRadiusY   : %4d\r\n"), CalibrationRadiusY));
    RETAILMSG(1, (TEXT("pTCP -> PointNumber  : %4d\r\n"), pTCP->PointNumber));
    RETAILMSG(1, (TEXT("pTCP -> CalibrationX : %4d\r\n"), pTCP->CalibrationX));
    RETAILMSG(1, (TEXT("pTCP -> CalibrationY : %4d\r\n"), pTCP->CalibrationY));

    return (TRUE);
}



extern "C"
BOOL DdsiTouchPanelGetDeviceCaps(INT iIndex,LPVOID  lpOutput)
{

    RETAILMSG(0, (TEXT("::: DdsiTouchPanelGetDeviceCaps\r\n")));

    if ( lpOutput == NULL )
    {
        ERRORMSG(0, (__TEXT("TouchPanelGetDeviceCaps: invalid parameter.\r\n")));
        SetLastError(ERROR_INVALID_PARAMETER);
        DebugBreak();
        return (FALSE);
    }

    switch ( iIndex )
    {
        case TPDC_SAMPLE_RATE_ID:
            {
                TPDC_SAMPLE_RATE    *pTSR = (TPDC_SAMPLE_RATE*)lpOutput;
                RETAILMSG(0, (TEXT("TouchPanelGetDeviceCaps::TPDC_SAMPLE_RATE_ID\r\n")));
    
                pTSR->SamplesPerSecondLow      = 3;
                pTSR->SamplesPerSecondHigh     = 10;
                pTSR->CurrentSampleRateSetting = 1;
            }
            break;
    
        case TPDC_CALIBRATION_POINT_COUNT_ID:
            {
                TPDC_CALIBRATION_POINT_COUNT *pTCPC = (TPDC_CALIBRATION_POINT_COUNT*)lpOutput;
                RETAILMSG(0, (TEXT("TouchPanelGetDeviceCaps::TPDC_CALIBRATION_POINT_COUNT_ID\r\n")));
    
                pTCPC->flags              = 0;
                pTCPC->cCalibrationPoints = 5;
            }
            break;
    
        case TPDC_CALIBRATION_POINT_ID:
            RETAILMSG(0, (TEXT("TouchPanelGetDeviceCaps::TPDC_CALIBRATION_POINT_ID\r\n")));
            return(TSP_CalibrationPointGet((TPDC_CALIBRATION_POINT*)lpOutput));
    
        default:
            ERRORMSG(1, (__TEXT("TouchPanelGetDeviceCaps: invalid parameter.\r\n")));
            SetLastError(ERROR_INVALID_PARAMETER);
            DebugBreak();
            return (FALSE);
    }

	return TRUE;
}


BOOL DdsiTouchPanelSetMode(INT iIndex,LPVOID  lpInput)
{
    BOOL  ReturnCode = FALSE;

    switch ( iIndex )
    {
        case TPSM_SAMPLERATE_LOW_ID:
        case TPSM_SAMPLERATE_HIGH_ID:
            SetLastError( ERROR_SUCCESS );
            ReturnCode = TRUE;
            break;

        default:
            SetLastError( ERROR_INVALID_PARAMETER );
            break;
    }


    return ( ReturnCode );
}


BOOL DdsiTouchPanelEnable(VOID)
{
	tca_tch_init();

	return tcc_tch_getsysintr();
}



VOID DdsiTouchPanelDisable(VOID)
{
}


// To grab PENUP event
static void TouchPenUpThread(void)
{

}

LONG DdsiTouchPanelAttach(VOID)
{
	HKEY    hk;
	DWORD   dwStatus;
	DWORD	dwSize,dwType;
	
	m_nScreenHeight=m_nScreenWidth=0;

	dwStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Drivers\\Display\\Magellan\\CONFIG", 0, 0, &hk);
	dwType = REG_DWORD;

	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hk, _T("LCD_Width"), NULL, &dwType, (LPBYTE) &m_nScreenWidth, &dwSize);
	}

	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hk, _T("LCD_Height"), NULL, &dwType, (LPBYTE) &m_nScreenHeight, &dwSize);
	}
	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{
		gI2CChNum=0;
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hk, _T("TouchI2C"), NULL, &dwType, (LPBYTE) &gI2CChNum, &dwSize);
	}
	if(hk != NULL) 
	{
		RegCloseKey(hk);
	}

    RETAILMSG(1, (TEXT("Touchpanel DRV :LCD Size = %dX%d,I2C Channel Num(%d)\r\n"),m_nScreenWidth,m_nScreenHeight,gI2CChNum));
    return 1;
}


LONG DdsiTouchPanelDetach(VOID)
{
    return 0;
}

void DdsiTouchPanelGetPoint(TOUCH_PANEL_SAMPLE_FLAGS *pTipStateFlags,INT *pUncalX,INT *pUncalY)
{
    int posX,posY;
    int retFlag;
    //static unsigned int last_ticks=0;
    
    retFlag = tca_getrawdata(&posX, &posY);
    RETAILMSG(0, (TEXT("RAW:(%d,%d)\r\n"), posX, posY));

	tca_tch_poweroff();
	
	Sleep(10);   // Release some time to other threads

	tca_rawtoscreen(&posX, &posY, m_nScreenWidth, m_nScreenHeight);

    if (retFlag == 0) // Valid touch pen
    {
        RETAILMSG(0, (TEXT("-->(%d,%d)\r\n"), posX/4,posY/4));
        *pTipStateFlags =*pTipStateFlags | TouchSampleValidFlag | TouchSampleDownFlag;			
        *pTipStateFlags &= ~TouchSampleIgnore;           
        nStatus = PEN_DOWN;    
        prevX = posX;
        prevY = posY;
    }
    else
    {
        posX = prevX;
        posY = prevY;
        *pTipStateFlags |= TouchSampleIgnore;
        *pTipStateFlags &= ~(TouchSampleValidFlag);
    }
    lastSampleFlag = *pTipStateFlags;            
    *pUncalX = posX;
    *pUncalY = posY;
    RETAILMSG(0, (TEXT("(%d,%d, %x)\r\n"), posX/4,posY/4, *pTipStateFlags));

	tcc_tch_enableinterrupt();
    return;
}

void DdsiTouchPanelPowerHandler(BOOL bOff)
{

	if(bOff == 0) // Power Up : Why 0 ?
	{
		tca_tchhw_initport();

#if	defined(_TOUCH_AK4183_)
		tca_ak4183_init();
#else
		tca_tsc2003_init();
#endif
	}
	else
	{
#if	defined(_TOUCH_AK4183_)
		tca_ak4183_sleep();
#endif
	}
}
