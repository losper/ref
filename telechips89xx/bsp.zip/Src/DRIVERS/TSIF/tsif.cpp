/****************************************************************************
 *   FileName    : tsif.cpp
 *   Description : Telechips GPSB (General Purpose Serial Bus) Driver
 *                 TSIF Slave Mode
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include <windows.h>
#include "bsp.h"
#include "tcc_tsif.h"
#include "tcc_gpioexp.h"


DWORD get_registry(LPCTSTR p_path, LPCTSTR p_value_name, LPBYTE p_data, DWORD dw_data_size)
{
    DWORD data_size = 0, dw_type = 0, ret = 0;
    HKEY h_key;

    if (p_path) {
        if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, p_path, 0, 0, &h_key) == ERROR_SUCCESS) {
            RegQueryValueEx(h_key, p_value_name, NULL, &dw_type, p_data, &dw_data_size);
            RegCloseKey(h_key);
            ret = dw_data_size;
        }

    }
    return ret;
}

int get_device_info(LPCTSTR p_path, int *num, int *dmasize)
{
    int ret = -1;
    TCHAR p_drv_path[1024];
    memset(p_drv_path, 0, sizeof(TCHAR) * 1024);

    if (get_registry(p_path, _T("Key"), (LPBYTE)p_drv_path, 1024) > 0) {
        get_registry(p_drv_path, _T("Index"), (LPBYTE)num, 4);
		get_registry(p_drv_path, _T("DmaSize"), (LPBYTE)dmasize, 4);
		ret = 0;
    }
    return ret;
}

//static BOOL DXB_PowerControl(unsigned int status)
//{
//	HANDLE hGXP;
//	BOOL ret;
//	DWORD dwByteReturned;
//	GXPINFO GxpInfo, GxpRead;
//	BYTE GxpData[5];
//
//	hGXP = CreateFile(L"GXP1:",
//			GENERIC_READ | GENERIC_WRITE,
//			NULL,
//			NULL,
//			OPEN_ALWAYS,
//			FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,
//			NULL);
//
//	if (!hGXP)
//		RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s Can't open GXP Driver\r\n")));
//
//	GxpInfo.uiDevice = PCA9539LOW; // GPIO Expander Device
//	GxpInfo.uiPort = DXB;
//	GxpInfo.uiState = status; // Power On/Off
//
//	ret = WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL);
//	if (ret == FALSE) {
//		RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s DXB Power control failed\r\n")));
//		goto exit;
//	}
//
//	GxpRead.uiDevice = PCA9539LOW;
//	GxpRead.uiPort = PORTOUTPUT;
//	ReadFile(hGXP, &GxpRead, 2, dwByteReturned, NULL);
//	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s 0x%x \r\n"), DEV, GxpRead.uiState ));
//	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("%s DXB Power %s\r\n"), DEV, (((gxpRead.uiState & DXB)>>12)?L"ON":L"OFF") ));
//
//exit:
//	CloseHandle(hGXP);
//	return ret;
//}

BOOL DllEntry(HINSTANCE hinst_dll, DWORD reason, LPVOID reserved)
{
    switch (reason) {
    case DLL_PROCESS_ATTACH:
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s Process Attach\r\n"), DEV));
        break;
    case DLL_PROCESS_DETACH:
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s Process Detach\r\n"), DEV));
        break;
    }
    
    return TRUE;
}

DWORD TSI_Init(PVOID p_context)
{
    LPCTSTR p_tsif_path = (LPCTSTR)p_context;
    tsif_core_c *p_tsif = NULL;
    int tsif_num = 0, tsif_dmasize = 0; 

    get_device_info(p_tsif_path, &tsif_num, &tsif_dmasize);

    _try {
        p_tsif = new tsif_core_c();
    } _except (1) {
        if (p_tsif) {
            delete p_tsif;
            p_tsif = NULL;
        }
    }

    if (p_tsif) {
        p_tsif->set_tsif_num(tsif_num);
		if (p_tsif->set_tsif_dma(tsif_dmasize)) {
			goto err;
		}

		/*
		 * GPIO_EXPAND DXB Power-on
		 */
		//if (FALSE == DXB_PowerControl(ON)) {
		//	goto err;
		//}

		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s(%d, 0x%x)\r\n"), DEV, _T(__FUNCTION__), tsif_num, tsif_dmasize));
        return (DWORD)p_tsif;
    }

err:
    RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Cannot init SPI driver(%d) !!!\r\n"), DEV, tsif_num));
    return NULL;
}

DWORD TSI_Open(DWORD p_context, DWORD access_code, DWORD share_mode)
{
    DWORD ret = 0;
    int open_cnt = 0;
    tsif_core_c *p_tsif = (tsif_core_c *)p_context;

    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    p_tsif->lock();
    open_cnt = p_tsif->inc_open_cnt();
    if (open_cnt == 1) {
        if (p_tsif->open(access_code, share_mode)) {
            ret = (DWORD)p_context;
        }
    } else if (open_cnt > 1) {
        p_tsif->dec_open_cnt();
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s Cannot open spi !!! Already spi open !!!\r\n"), DEV, _T(__FUNCTION__)));
    }
    p_tsif->unlock();
    return ret;
}

BOOL TSI_Close(DWORD p_context)
{
    tsif_core_c *p_tsif = (tsif_core_c *)p_context;

    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    p_tsif->lock();
//	p_tsif->gpsb_ckc_control(FALSE);	// bugfix: SVN r1014
    p_tsif->dec_open_cnt();
	p_tsif->close();
    p_tsif->unlock();
    return TRUE;
}

DWORD TSI_Read(DWORD h_open_context, LPVOID p_buffer, DWORD count)
{
    DWORD ret = 0;
    tsif_core_c *p_tsif = (tsif_core_c *)h_open_context;
    p_tsif->lock();

    ret = p_tsif->tsif_read_dma((char *)p_buffer, count);

    p_tsif->unlock();
    return ret;
}

DWORD TSI_Write(DWORD h_open_context, LPVOID p_buffer, DWORD count)
{
    DWORD ret = 0;
    return ret;
}

BOOL TSI_IOControl(DWORD h_open_context,
					DWORD code,
					PBYTE p_inbuf,
					DWORD inbuf_size,
					PBYTE p_outbuf,
					DWORD outbuf_size,
					LPDWORD p_retruned)
{
    tsif_core_c *p_tsif = (tsif_core_c *)h_open_context;
	BOOL ret = TRUE;

    //p_tsif->lock();

	switch (code) {
		case IOCTL_TSIF_SET_MODE:
		{
			tsif_mode_param_t *p_tsif_mode_param = (tsif_mode_param_t *)p_inbuf;

			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s IOCTL_TSIF_SETUP CPL(%d), CPH(%d), LSB(%d), FP(%d)\r\n"), DEV,
				p_tsif_mode_param->CPL, p_tsif_mode_param->CPH, p_tsif_mode_param->LSB, p_tsif_mode_param->FP));

			p_tsif->tsif_set_mode(p_tsif_mode_param);
			break;
		}
		case IOCTL_TSIF_DMA_START:
		{
			tsif_dma_param_t *p_tsif_dma_param = (tsif_dma_param_t *)p_inbuf;
			ret = p_tsif->tsif_dma_start(p_tsif_dma_param);
			break;
		}
		case IOCTL_TSIF_DMA_STOP:
		{
			p_tsif->tsif_dma_stop();
			break;
		}
		case IOCTL_TSIF_WAIT_DMA_DONE:
		{
			//tsif_dma_param_t *p_tsif_dma_in_param = (tsif_dma_param_t *)p_inbuf;
			//tsif_dma_param_t *p_tsif_dma_out_param = (tsif_dma_param_t *)p_outbuf;
			//ret = p_tsif->tsif_wait_for_dma_done(p_tsif_dma_in_param);
			//outbuf_size = sizeof(tsif_dma_param_t);
			
			tsif_dma_param_t *p_tsif_dma_param = (tsif_dma_param_t *)p_inbuf;
			ret = p_tsif->tsif_wait_for_dma_done(p_tsif_dma_param->timeout);
			break;
		}
		case IOCTL_TSIF_GET_MAX_DMA_SIZE:
		{
			tsif_dma_param_t *p_tsif_dma_param = (tsif_dma_param_t *)p_outbuf;
			p_tsif->tsif_get_max_dma_size(p_tsif_dma_param);
			break;
		}
		case IOCTL_TSIF_SET_PID:
		{
			tsif_pid_param_t *p_tsif_pid_param = (tsif_pid_param_t *)p_inbuf;
			ret = p_tsif->tsif_set_pid(p_tsif_pid_param);
			break;
		}
		default:
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Unknown IOCTL[%x]\n"), DEV, code));
			ret = FALSE;
			break;
	}
	
    //p_tsif->unlock();
    return ret;
}

DWORD TSI_Seek(DWORD h_open_context, long amount, DWORD type)
{
    tsif_core_c *p_tsif = (tsif_core_c *)h_open_context;
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    p_tsif->lock();
    p_tsif->unlock();
    return 0;
}

void TSI_PowerDown(DWORD p_context)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
}

void TSI_PowerUp(DWORD p_context)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
}

void TSI_Deinit(DWORD p_context)
{
    tsif_core_c *p_tsif = (tsif_core_c *)p_context;
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    if (p_tsif) {
        delete p_tsif;

		/* 
		 * GPIO_EXPAND DXB Power-off
		 */
		//DXB_PowerControl(OFF);
    }
}

