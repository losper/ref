/****************************************************************************
 *   FileName    : tcc_tsif.cpp
 *   Description : Telechips GPSB (General Purpose Serial Bus) Driver
 *                 TSIF Slave Mode
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include <windows.h>
#include <giisr.h>
#include "bsp.h"
#include "tcc_ckc.h"
#include "tcc_gpio.h"
#include "tcc_tsif.h"

#define CLOSE_HANDLE(H, N, F) do { if ((H) != (N)) { (F)(H); (H) = (N); } } while (0)

//#define OVERRUN_TEST
#ifdef OVERRUN_TEST
int before_pos;
#endif

struct tcc_peri_id_table {
    unsigned int bus_id;
    unsigned int clk_id;
};

struct tcc_peri_id_table sa_peri_id_table[] = {
    { RB_GPSBCONTROLLER0, PERI_GPSB0 },
    { RB_GPSBCONTROLLER1, PERI_GPSB1 },
//	{ RB_GPSBCONTROLLER2, PERI_GPSB2 },
//	{ RB_GPSBCONTROLLER3, PERI_GPSB3 },
//	{ RB_GPSBCONTROLLER4, PERI_GPSB4 },
//	{ RB_GPSBCONTROLLER5, PERI_GPSB5 },
};

static void tea_free_dma_wince(struct tea_dma_buf *tdma)
{
    if (tdma) {
        CLOSE_HANDLE(tdma->v_addr, NULL, FreePhysMem);
    }
}

static int tea_alloc_dma_wince(struct tea_dma_buf *tdma, unsigned int size)
{
    int ret = -1;
    if (tdma) {
        DWORD tmp = 0;
        tea_free_dma_wince(tdma);
        tdma->v_addr = (unsigned char *)AllocPhysMem(size, PAGE_READWRITE, 0, 0, &tmp);
        if (tdma->v_addr) {
            tdma->buf_size = size;
            tdma->dma_addr = (unsigned int)tmp;
            RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("%s DMA physical address [0x%X]\r\n"), DEV, tmp));
            ret = 0;
        }
    }
    return ret;
}

static DWORD WINAPI tsif_dma_handler(LPVOID p_context)
{
	DWORD status;
	tsif_core_c *p_tsif = (tsif_core_c *)p_context;
	tca_spi_handle_t *tsif_handle = p_tsif->m_tsif_handle;

	p_tsif->m_ioctl_evt = CreateEvent(0, FALSE, FALSE, NULL);
	
	p_tsif->m_intr_evt = CreateEvent(0, FALSE, FALSE, NULL);
	if ((InterruptInitialize(p_tsif->m_sysirq, p_tsif->m_intr_evt, 0, 0)) == FALSE) {
	    RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Cannot initialize interrupt \r\n"), DEV));
	}

#ifdef OVERRUN_TEST
	before_pos = 0;
#endif
	while (1) {
	    status = WaitForSingleObject(p_tsif->m_intr_evt, WAIT_TIME_FOR_DMA_DONE);
		if (p_tsif->exit_dmahandler) {
			return 0;
		}
	    if (status == WAIT_OBJECT_0) {
			//if (tsif_handle->regs->DMAICR & (Hw29 | Hw28)) {
			//	BITSET(tsif_handle->regs->DMAICR, (Hw29 | Hw28));

				// SetEvent to IOCTL WaitForSingleObject
				if (p_tsif->m_open_cnt_0 > 0) {
					tsif_handle->cur_q_pos = (int)(tsif_handle->regs->DMASTR >> 17);
#ifdef OVERRUN_TEST
					if (tsif_handle->q_pos >= before_pos && tsif_handle->q_pos < tsif_handle->cur_q_pos) {
						RETAILMSG(1, (TEXT("%s %s DMA Overrun !!!\r\n"), DEV, _T(__FUNCTION__)));
					} else if (before_pos > tsif_handle->cur_q_pos) {
						if (tsif_handle->q_pos >= before_pos || tsif_handle->q_pos < tsif_handle->cur_q_pos) {
							RETAILMSG(1, (TEXT("%s %s DMA Overrun !!!\r\n"), DEV, _T(__FUNCTION__)));
						}
					}
					before_pos = tsif_handle->cur_q_pos;
#endif
					SetEvent(p_tsif->m_ioctl_evt);
				}
				
			//} else {
			//	RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s unknown DMAICR\r\n"), DEV, _T(__FUNCTION__)));
			//}
	    } else if (status == WAIT_TIMEOUT) {
	        RETAILMSG(0, (TEXT("%s %s  recv timeout [%dms] !!! \r\n"), DEV, _T(__FUNCTION__), WAIT_TIME_FOR_DMA_DONE));
	    } else {
	        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s  WaitForSingleObject unknown error !!!\r\n"), DEV, _T(__FUNCTION__)));
	    }
		InterruptDone(tsif_handle->irq);
	}

	return 0;
}
	
tsif_core_c::tsif_core_c()
{
    m_tsif_num = -1;
    m_intr_evt = NULL;
    m_open_cnt_0 = 0;
    m_tsif_handle = NULL;
    m_is_init = FALSE;
	m_tsif_loopback = 0;
	exit_dmahandler = FALSE;
    InitializeCriticalSection(&m_lock);
}

tsif_core_c::~tsif_core_c()
{
    tca_spi_clean(m_tsif_handle);
    CLOSE_HANDLE(m_tsif_handle, NULL, free);

    DeleteCriticalSection(&m_lock);
	InterruptDisable(m_tsif_handle->irq);
    CLOSE_HANDLE(m_intr_evt, NULL, CloseHandle);
}

void tsif_core_c::set_tsif_num(int tsif_num)
{
    m_tsif_num = tsif_num;
}

int tsif_core_c::set_tsif_dma(int tsif_dmasize)
{
	return tea_alloc_dma_wince(&m_dma_t, tsif_dmasize);
}

BOOL tsif_core_c::set_interrupt(int irq, int sys_irq, DWORD port_addr)
{
	//Install ISR 
	m_hGpsbIsrHandler = LoadIntChainHandler(L"tcc_giisr.dll", L"GPSBISRHandler", irq);
	if(m_hGpsbIsrHandler == NULL){
		DWORD dwRet = GetLastError();	
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s LoadIntChainHandler return fail %d\r\n"), DEV, dwRet));			
		return FALSE;
	}
	else{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s LoadIntChainHandler success\r\n"), DEV));					
	}

	// Set up ISR handler
	if(m_hGpsbIsrHandler){
		GIISR_INFO Info;
		memset(&Info, 0, sizeof(GIISR_INFO));
		Info.CheckPort = TRUE; //irq happen then chk port <-> false means don't chk port == no shared IRQ
		Info.PortIsIO = FALSE; // memory mapped - not real port (TRUE only used X86)
		Info.SysIntr = sys_irq;
		Info.PortSize = sizeof(DWORD);// size of GPSB_CIRQST
		Info.UseMaskReg = FALSE;
		Info.MaskAddr = 0;

		switch(m_tsif_num) {
		case 0:
			Info.Mask = Hw28;	// check DMAICR.ISP
			break;
		case 1:			
			Info.Mask = Hw28;	// check DMAICR.ISP
			break;
		default:
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s Unknown SPI\r\n"), DEV));
			return FALSE;
			break;
		}

		Info.PortAddr = port_addr;

		if (!KernelLibIoControl(m_hGpsbIsrHandler, IOCTL_GIISR_INFO,  &Info, sizeof(GIISR_INFO), NULL, 0, 0)){
			DWORD dwRet = GetLastError();	
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s KernelLibIoControl return fail %d\r\n"), DEV, dwRet));			
			return FALSE;
		}
		else
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s KernelLibIoControl return success\r\n"), DEV));
	}

	return TRUE;
}

BOOL tsif_core_c::init(int tsif_num)
{
    int val = 0;
    BOOL ret = FALSE;
	HANDLE hDMAThread;
    volatile struct tca_spi_regs *p_spi_regs = (tsif_num == 0)
		? (volatile struct tca_spi_regs *)tcc_allocbaseaddress((unsigned int)&(HwGPSBCH0_BASE))
		: (volatile struct tca_spi_regs *)tcc_allocbaseaddress((unsigned int)&(HwGPSBCH1_BASE));

    m_tsif_num = tsif_num;
    tca_spi_clean(m_tsif_handle);
    CLOSE_HANDLE(m_tsif_handle, NULL, free);

    m_tsif_handle = (tca_spi_handle_t *)malloc(sizeof(tca_spi_handle_t));
    if (m_tsif_handle) {
		tcc_ckc_set_iobus_swreset(sa_peri_id_table[m_tsif_num].bus_id);
		tcc_ckc_setiobus(sa_peri_id_table[m_tsif_num].bus_id, ENABLE);

		m_irq = IRQ_GPSB;
		KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &m_irq, sizeof(UINT32), &m_sysirq, sizeof(UINT32), NULL);

		// IISR
		set_interrupt(m_irq, m_sysirq, (DWORD)&(p_spi_regs->DMAICR));
		
        val = tca_spi_init(m_tsif_handle,
                            p_spi_regs,
                            m_sysirq,
                            NULL,	/* Already, tsif has rx_dma buf */
                            NULL,	/* Already, tsif has rx_dma buf */
                            m_dma_t.buf_size,
                            m_tsif_num,
                            1 /* slave mode */);
        if (val == 0) {
			/* Already, tsif has rx_dma buf */
			m_tsif_handle->rx_dma.v_addr = m_dma_t.v_addr;
			m_tsif_handle->rx_dma.dma_addr = m_dma_t.dma_addr;
			m_tsif_handle->rx_dma.buf_size = m_dma_t.buf_size;

            m_tsif_handle->clear_fifo_packet(m_tsif_handle);
			m_tsif_handle->dma_stop(m_tsif_handle);
			m_tsif_handle->dma_total_packet_cnt = m_tsif_handle->dma_total_size / TSIF_PACKET_SIZE;
			m_tsif_handle->dma_intr_packet_cnt = 1;
			m_tsif_handle->set_packet_cnt(m_tsif_handle, MPEG_PACKET_SIZE);

			exit_dmahandler = FALSE;
			if ((hDMAThread = CreateThread(0, 0, tsif_dma_handler, this, 0, NULL)) != NULL) {
				if (CeSetThreadPriority(hDMAThread, 4) == FALSE) {
					RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Error: Failed CeSetThreadPriority(4)\r\n"), DEV));
				}
				ret = TRUE;
			} else {
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Error: Failed to create Thread\r\n"), DEV));
			}
        }
    } else {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Cannot allocate memory for tsif-handle \r\n"), DEV));
    }

    if (!ret) {
        tca_spi_clean(m_tsif_handle);
        CLOSE_HANDLE(m_tsif_handle, NULL, free);
        CLOSE_HANDLE(m_intr_evt, NULL, CloseHandle);
    } else {
        m_is_init = TRUE;
    }

    return ret;
}

BOOL tsif_core_c::open(DWORD access_code, DWORD share_mode)
{
    //if (!m_is_init) {
        if (!init(m_tsif_num)) {
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s tsif open fail !!!\r\n"), DEV, _T(__FUNCTION__)));
			return FALSE;
        }
    //}
	
    m_tsif_handle->hw_init(m_tsif_handle);
    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    return TRUE;
}

void tsif_core_c::close()
{
	tca_spi_clean(m_tsif_handle);
	CLOSE_HANDLE(m_tsif_handle, NULL, free);

	DeleteCriticalSection(&m_lock);

	exit_dmahandler = TRUE;
	SetEvent(m_ioctl_evt);
	
	InterruptDisable(m_sysirq);
	CLOSE_HANDLE(m_intr_evt, NULL, CloseHandle);
	CLOSE_HANDLE(m_ioctl_evt, NULL, CloseHandle);
	CLOSE_HANDLE(m_hGpsbIsrHandler, NULL, FreeIntChainHandler);
	KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &m_sysirq, sizeof(UINT32), NULL, 0, NULL);
}

void tsif_core_c::gpsb_ckc_control(BOOL enable)
{
	if (enable) {
		tcc_ckc_setiobus(sa_peri_id_table[m_tsif_num].bus_id, ENABLE);
	} else {
		tcc_ckc_setiobus(sa_peri_id_table[m_tsif_num].bus_id, DISABLE);
	}
}

/*----------------------------------------------------------------------------
 * TSIF Interface functions
 *---------------------------------------------------------------------------*/
void tsif_core_c::tsif_set_mode(tsif_mode_param_t *param)
{
	// SPI Timing setting	
	tca_spi_setCPOL(m_tsif_handle->regs, param->CPL);
    tca_spi_setCPHA(m_tsif_handle->regs, param->CPH);
    tca_spi_setCS_HIGH(m_tsif_handle->regs, param->FP);
    tca_spi_setLSB_FIRST(m_tsif_handle->regs, param->LSB);
	
	m_tsif_handle->dma_mode = param->DMA_MODE;
	if (m_tsif_handle->dma_mode == 0) {
		m_tsif_handle->set_mpegts_pidmode(m_tsif_handle, 0);
	}
	
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s MODE reg(0x%08x), %s dma mode\r\n"), DEV, 
		m_tsif_handle->regs->MODE, m_tsif_handle->dma_mode?TEXT("MPEG2-TS"):TEXT("Normal")));
}

BOOL tsif_core_c::tsif_dma_start(tsif_dma_param_t *param)
{
	if (((TSIF_PACKET_SIZE * param->ts_total_packet_cnt) > (unsigned int)(m_tsif_handle->dma_total_size)) || (param->ts_total_packet_cnt <= 0)) {
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s so big ts_total_packet_cnt\r\n"), DEV));
		return FALSE;
	}

	m_tsif_handle->dma_stop(m_tsif_handle);

	m_tsif_handle->dma_total_packet_cnt = param->ts_total_packet_cnt;
	m_tsif_handle->dma_intr_packet_cnt = param->ts_intr_packet_cnt;

	m_tsif_handle->clear_fifo_packet(m_tsif_handle);
	m_tsif_handle->q_pos = m_tsif_handle->cur_q_pos = 0;

	m_tsif_handle->set_packet_cnt(m_tsif_handle, MPEG_PACKET_SIZE);
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s interrupt packet count [%u]\r\n"), DEV, m_tsif_handle->dma_intr_packet_cnt));
	
	m_tsif_handle->dma_start(m_tsif_handle);
	return TRUE;
}

void tsif_core_c::tsif_dma_stop()
{
	m_tsif_handle->dma_stop(m_tsif_handle);
}

void tsif_core_c::tsif_get_max_dma_size(tsif_dma_param_t *param)
{
	param->ts_total_packet_cnt = m_tsif_handle->dma_total_size / TSIF_PACKET_SIZE;
	param->ts_intr_packet_cnt = 1;
}

BOOL tsif_core_c::tsif_set_pid(tsif_pid_param_t *param)
{
	volatile GPSBPIDTABLE *pid_table = (volatile GPSBPIDTABLE *)tcc_allocbaseaddress((unsigned int)&(HwGPSBPIDTABLE_BASE));
	
	if (param->valid_data_cnt <= PID_MATCH_TABLE_MAX_CNT) {
		unsigned int i = 0;
		for (i = 0; i < PID_MATCH_TABLE_MAX_CNT; i++) {
			pid_table->PIDT[i] = 0;
		}
		if (param->valid_data_cnt > 0) {
			for (i = 0; i < param->valid_data_cnt; i++) {
				pid_table->PIDT[i] = param->pid_data[i] & 0x1FFFFFFF;
				BITSET(pid_table->PIDT[i], (m_tsif_num == 0) ? HwGPSB_PIDT_CH0 : HwGPSB_PIDT_CH1);
			}
			m_tsif_handle->set_mpegts_pidmode(m_tsif_handle, 1);
		} else {
			m_tsif_handle->set_mpegts_pidmode(m_tsif_handle, 0);
		}
	} else {
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s PID TABLE is so big\r\n"), DEV));
		return FALSE;
	}
	return TRUE;
}

DWORD tsif_core_c::tsif_read_dma(char *buf, DWORD len)
{
	DWORD readable_cnt = 0, copy_cnt = 0;
    DWORD copy_byte = 0;

    readable_cnt = tsif_get_readable_cnt(m_tsif_handle);
    if (readable_cnt > 0) {
        copy_byte = readable_cnt * TSIF_PACKET_SIZE;
        if (copy_byte > len) {
            copy_byte = len;
        }

        copy_byte -= copy_byte % TSIF_PACKET_SIZE;
        copy_cnt = copy_byte / TSIF_PACKET_SIZE;
        copy_cnt -= copy_cnt % m_tsif_handle->dma_intr_packet_cnt;
        copy_byte = copy_cnt * TSIF_PACKET_SIZE;

        if (copy_cnt >= m_tsif_handle->dma_intr_packet_cnt) {
            int offset = m_tsif_handle->q_pos * TSIF_PACKET_SIZE;
            if (copy_cnt > m_tsif_handle->dma_total_packet_cnt - m_tsif_handle->q_pos) {
                int first_copy_byte = (m_tsif_handle->dma_total_packet_cnt - m_tsif_handle->q_pos) * TSIF_PACKET_SIZE;
                int first_copy_cnt = first_copy_byte / TSIF_PACKET_SIZE;
                int second_copy_byte = (copy_cnt - first_copy_cnt) * TSIF_PACKET_SIZE;

                memcpy(buf, (void *)((char *)(m_tsif_handle->rx_dma.v_addr) + offset), first_copy_byte);
                memcpy(buf + first_copy_byte, m_tsif_handle->rx_dma.v_addr, second_copy_byte);

                m_tsif_handle->q_pos = copy_cnt - first_copy_cnt;
            } else {
                memcpy(buf, (void *)((char *)(m_tsif_handle->rx_dma.v_addr) + offset), copy_byte);

                m_tsif_handle->q_pos += copy_cnt;
                if ((DWORD)m_tsif_handle->q_pos >= m_tsif_handle->dma_total_packet_cnt) {
                    m_tsif_handle->q_pos = 0;
                }
            }
            return copy_byte;
        }
    }
    return 0;
}

BOOL tsif_core_c::tsif_wait_for_dma_done(DWORD dwMilliseconds)
{
    BOOL ret = FALSE;
    DWORD status, timeout;

	if (dwMilliseconds) {
		timeout = dwMilliseconds;
	} else {
		timeout = WAIT_TIME_FOR_DMA_DONE;
	}
	
    status = WaitForSingleObject(m_ioctl_evt, timeout);
    if (status == WAIT_OBJECT_0) {
		ret = TRUE;
    } else if (status == WAIT_TIMEOUT) {
        RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s  recv timeout [%dms] !!! \r\n"), DEV, _T(__FUNCTION__), timeout));
    } else {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s  WaitForSingleObject unknown error !!!\r\n"), DEV, _T(__FUNCTION__)));
    }

    return ret;
}

int tsif_core_c::tsif_get_readable_cnt(tca_spi_handle_t *H)
{
    if (H) {
        int dma_pos = H->cur_q_pos;
        int q_pos = H->q_pos;
        int readable_cnt = 0;

        if (dma_pos > q_pos) {
            readable_cnt = dma_pos - q_pos;
        } else if (dma_pos < q_pos) {
            readable_cnt = H->dma_total_packet_cnt - q_pos;
            readable_cnt += dma_pos;
        } 
        return readable_cnt;
    }
    return 0;
}

