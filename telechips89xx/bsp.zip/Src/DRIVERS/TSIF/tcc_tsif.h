/****************************************************************************
 *   FileName    : tcc_tsif.h
 *   Description : Telechips GPSB (General Purpose Serial Bus) Driver
 *                 TSIF Slave Mode
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCC_TSIF_H__
#define __TCC_TSIF_H__

#include <windows.h>
#include "tca_spi_hwset.h"

#define DEV TEXT("[        TSIF]")

//#define TSIF_DMA_SIZE			0x100000
#define TSIF_PACKET_SIZE		188
#define PID_MATCH_TABLE_MAX_CNT 32

typedef struct _tsif_mode_param {
	BOOL CPL;			// SCK Polarity (= PCK) - TRUE: PCK == 1, FALSE: PCK == 0 
	BOOL CPH;			// SCK Phase (= PWD,PRD) - TRUE: PWD & PRD == 1, FLASE: PWD & PRD == 0 
	BOOL LSB;			// MSB/LSB (= SD) - TRUE: SD == 1, FALSE: SD == 0
	BOOL FP;			// Frame Pulse Polarity (= PCS,PCD) - TRUE: PCS, PCD == 1, FALSE: PCS, PCD == 0
	int DMA_MODE;		// DMACTR[MD]: DMA mode register
#define DMA_NORMAL_MODE		0x00
#define DMA_MPEG2TS_MODE	0x01
} tsif_mode_param_t;

typedef struct _tsif_dma_param {
	unsigned int ts_total_packet_cnt;
    unsigned int ts_intr_packet_cnt;
	unsigned int timeout;
} tsif_dma_param_t;

typedef struct _tsif_pid_param {
    unsigned int pid_data[PID_MATCH_TABLE_MAX_CNT];
    unsigned int valid_data_cnt;
} tsif_pid_param_t;


class tsif_core_c
{
public:
    tsif_core_c();
    virtual ~tsif_core_c();

public:
    BOOL init(int tsif_num);
    BOOL open(DWORD access_code, DWORD share_mode);
	void close();
	BOOL set_interrupt(int irq, int sys_irq, DWORD port_addr);
	void set_tsif_num(int tsif_num);
	int set_tsif_dma(int tsif_dmasize);

    void lock()   { EnterCriticalSection(&m_lock); }
    void unlock() { LeaveCriticalSection(&m_lock); }
    int inc_open_cnt() { m_open_cnt_0++; return m_open_cnt_0; }
    int dec_open_cnt() { if (m_open_cnt_0 > 0) m_open_cnt_0--; return m_open_cnt_0; }

	void gpsb_ckc_control(BOOL enable);

	/*----------------------------------------------------------------------------
	 * TSIF Interface functions
	 *---------------------------------------------------------------------------*/
	void tsif_set_mode(tsif_mode_param_t *param);
	BOOL tsif_dma_start(tsif_dma_param_t *param);
	void tsif_dma_stop(void);
	void tsif_get_max_dma_size(tsif_dma_param_t *param);
	BOOL tsif_set_pid(tsif_pid_param_t *param);
	DWORD tsif_read_dma(char *buf, DWORD len);
	BOOL tsif_wait_for_dma_done(DWORD timeout);
	int tsif_get_readable_cnt(tca_spi_handle_t *H);

public:
    tca_spi_handle_t *m_tsif_handle;
    HANDLE m_intr_evt;
	HANDLE m_ioctl_evt;
	int m_tsif_loopback;
    BOOL m_is_init;
	int m_open_cnt_0;
	int m_irq, m_sysirq;
	BOOL exit_dmahandler;
	struct tea_dma_buf m_dma_t;

protected:
    CRITICAL_SECTION m_lock;
    int m_tsif_num;
	HANDLE m_hGpsbIsrHandler;
};


#endif /*__TCC_TSIF_H__*/
