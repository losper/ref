/****************************************************************************
 *   FileName    : CIFDriver.h
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/



///////////////////////////////////////////////////////////////////////
// Y Address: 0x20100000
// U Address: 0x20300000
// V Address: 0x20380000
#define YUV420		0
#define YUV422		1
#define RGB_FORMAT	2

#define OPEN_AS_CCIR601 0 	
#define OPEN_AS_CCIR656 1

enum{
	EFFECT_NORMAL,
	EFFECT_NEGATIVE,
	EFFECT_SEPIA,
	EFFECT_EMBOSS,
	EFFECT_SKETCH,
	EFFECT_GRAY,
};

enum{
	CIF_FUNCTION_INTERRUPT,
	CIF_FUNCTION_OPERATING,
	CIF_FUNCTION_CAMERAMODULEONOFF,
	CIF_FUNCTION_INPUTIMAGEADDRESS,
};

enum{
	CIF_FRAMERATE_30FS,
	CIF_FRAMERATE_15FS,
	CIF_FRAMERATE_10FS,
};

enum
{
	CAM_ON_STATUS,
	CAM_PREVIEW_STATUS,
	CAM_CAPTURE_STATUS,
	CAM_STOPPREVIEW_STATUS,
	CAM_OFF_STATUS,
};

typedef struct	_CIF_FUNCTION{
	unsigned int	FunctionName;
	void*		pFuncParam;
	void*		Mode;
}CIF_FUNCTION;

typedef struct	_IMAGE_ADDRESS{
	unsigned int	ImageBaseAddressY;
	unsigned int	ImageBaseAddressU;
	unsigned int	ImageBaseAddressV;
}IMAGE_ADDRESS;

typedef struct	_PREVIEW_PROP{
	unsigned int 	PrevHSize;
	unsigned int	PrevVSize;
//	unsigned int	InImgHSize;
//	unsigned int	InImgVSize;
	
	IMAGE_ADDRESS	InImageAddress[3];
	HANDLE			InImageEvent[3];
	unsigned int	InImageAddressIndex;	

	unsigned int 	PrevFrameRate;
}PREVIEW_PROP;

typedef struct	_CAPTURE_PROP{
	unsigned int 	Resolution;
	unsigned int	DataFormat;
	unsigned int	FrameSize;
	unsigned int	CapHSize;
	unsigned int	CapVSize;
//	unsigned int 	InImgHSize;
//	unsigned int	InImgVSize;
	unsigned int	CaptureBaseAddress0;
	unsigned int	CaptureBaseAddress1;
	unsigned int	CaptureBaseAddress2;
	HANDLE			CaptureEvent;
//	unsigned int 	CaptureFrameRate;
}CAPTURE_PROP;

typedef struct _CAM_USER_INFO{
	PREVIEW_PROP	pPrevProp;
	CAPTURE_PROP	pCapProp;
	unsigned int	EffectMode;
	unsigned int	InitializationMode;
}CAM_USER_INFO;
