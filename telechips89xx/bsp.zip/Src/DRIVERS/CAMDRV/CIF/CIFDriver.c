/****************************************************************************
 *   FileName    : CIFDriver.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/



/************************************************************************************************
* HEADER FILES
*
************************************************************************************************/
#include <windows.h>
#include <devload.h>
#include <pm.h>
#include <nkintr.h>
#include "camdef.h"
#include "ioctl_code.h"
#include "CIFRegisterSet.h"
#include "CIFDriver.h"
#include "tcc_cifdriver.h"
#include "bsp.h"
#include "tcc_gpio.h"

/************************************************************************************************
* STRUCTURES
*
************************************************************************************************/
typedef struct _CAM_INTERRUPT_
{
	DWORD		iIrq;
	DWORD		iSysIntr;
	HANDLE		hThreadHandle;
	HANDLE		hFrameCompleteEvent;
	DWORD		dwPermission;
	HANDLE		hCallerProcess;
	BOOL		bKillThread;
	CAM_USER_INFO CamUserInfo;
}CAMINTR, *PCAMINTR;

enum
{
	CIF_STATUS_CLOSE = 0,
	CIF_STATUS_OPEN
};

/************************************************************************************************
* GLOBALS
*
************************************************************************************************/
static unsigned int gCIFMode = 1;
static CAMINTR gCIFIntr;
static HANDLE gCaptureEvent = NULL;
static HANDLE gInImageEvent[3] = {NULL, NULL, NULL};
static unsigned int gCamMod = NONE_CAMMOD;
static unsigned int gCIFDevStatus = CIF_STATUS_CLOSE;

CIF *pCIF_Reg = NULL;
GPIO *pGPIO_Reg = NULL;
CKC *pCKC_Reg = NULL;
DDICONFIG *pDDICONFIG_Reg = NULL;
EFFECT *pEFFECT_Reg = NULL;
CIFSCALER *pCIFSCALER_Reg = NULL;

/************************************************************************************************
* LOCAL FUNCTIONS
*
************************************************************************************************/

int LFCIF_SetEffect(unsigned int EffectMode);
int LFCIF_Initialize(CAM_USER_INFO *pCamUserInfo);
int LFCIF_PortConfigure(void);
int LFCIF_FunctionControl(void* pParam);
int LFCIF_ScalerConfigure(CAM_USER_INFO *pCamUserInfo, unsigned int ControlMode);
int LFCIF_GetCapturedFrame(void);
//int LFCIF_InitialConfigure(unsigned int ImgHSize, unsigned int ImgVSize, unsigned int Initialization, unsigned int FrameRate);
int LFCIF_InitialConfigure(unsigned int Initialization, unsigned int FrameRate, unsigned int DataFormat);
/************************************************************************************************
* FUNCTION		: BOOL DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
*
* DESCRIPTION	: FMT Driver DLL Entry
*
************************************************************************************************/
BOOL WINAPI DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
{
	switch ( dwReason ) {
	case DLL_PROCESS_ATTACH:
		//RETAILMSG(1, (TEXT("[CIFDRV      ]DLLEntry : DLL_PROCESS_ATTACH\r\n")));
		DisableThreadLibraryCalls((HMODULE) hInstDll);
		break;
	}
	return (TRUE);
}

/************************************************************************************************
* FUNCTION		: DWORD	CIF_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD	CIF_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{
	return TRUE;
}
/************************************************************************************************
* FUNCTION		: BOOL	CIF_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL	CIF_Deinit( DWORD hDeviceContext )
{
	return TRUE;
}


/************************************************************************************************
* FUNCTION		: DWORD CameraThread(PVOID arg)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD CameraThread(PVOID arg)
{
	DWORD ret;
	CAMINTR*pCam = (CAMINTR*)arg;
	DWORD tick1 = 0, tick2 = 0;
	unsigned int Status = 0;
	unsigned int FlagforCompensation = 0;
	unsigned int uiBackupReg = 0;
	
	SetProcPermissions(pCam->dwPermission);

	while(!pCam->bKillThread)
	{
		ret = WaitForSingleObject(pCam->hFrameCompleteEvent, INFINITE);

		if(pCam->bKillThread){
			break;
		}
		
		if(ret == WAIT_OBJECT_0)
		{
			//Error Exception for interlace YUV422
			if(gCamMod==TVP5150A_PAL)
			{
				if(gCIFMode != 1)
				{
					if(!(pCIF_Reg->CIRQ & Hw11) || FlagforCompensation)
					{
						//printf("-Odd Error!!\r\n");
						if(!FlagforCompensation)
						{
							uiBackupReg = pCIF_Reg->ICPCR1 & (Hw21-Hw18);
							BITCLR(pCIF_Reg->ICPCR1, (Hw21-Hw18));
							FlagforCompensation = 1;
						}
						else
						{
							BITSET(pCIF_Reg->ICPCR1, uiBackupReg);
							FlagforCompensation = 0;
						}

						tcc_cif_setinterrupt(pCIF_Reg, SET_CIF_INT_CLEAR);
						InterruptDone(pCam->iSysIntr);
						continue;
					}
				}
			}

			if(pCam->CamUserInfo.pPrevProp.InImageAddressIndex == 0)
			{
				if(gInImageEvent[0] != NULL)
				{
					pCam->CamUserInfo.pPrevProp.InImageAddressIndex = 1;
					tcc_cif_opstop(pCIF_Reg, pGPIO_Reg);
					tcc_cif_set_addr(pCIF_Reg, IN_IMG,
								pCam->CamUserInfo.pPrevProp.InImageAddress[1].ImageBaseAddressY,
								pCam->CamUserInfo.pPrevProp.InImageAddress[1].ImageBaseAddressU,
								pCam->CamUserInfo.pPrevProp.InImageAddress[1].ImageBaseAddressV);
					tcc_cif_opresume(pCIF_Reg, pGPIO_Reg, gCamMod);

					SetEvent(gInImageEvent[0]);		
				}
			}
			else if(pCam->CamUserInfo.pPrevProp.InImageAddressIndex == 1)
			{
				if(gInImageEvent[1] != NULL)
				{
					pCam->CamUserInfo.pPrevProp.InImageAddressIndex = 2;
					tcc_cif_opstop(pCIF_Reg, pGPIO_Reg);
					tcc_cif_set_addr(pCIF_Reg, IN_IMG,
								pCam->CamUserInfo.pPrevProp.InImageAddress[2].ImageBaseAddressY,
								pCam->CamUserInfo.pPrevProp.InImageAddress[2].ImageBaseAddressU,
								pCam->CamUserInfo.pPrevProp.InImageAddress[2].ImageBaseAddressV);
					tcc_cif_opresume(pCIF_Reg, pGPIO_Reg, gCamMod);

					SetEvent(gInImageEvent[1]);
				}
			}
			else
			{
				if(gInImageEvent[2] != NULL)
				{
					pCam->CamUserInfo.pPrevProp.InImageAddressIndex = 0;
					tcc_cif_opstop(pCIF_Reg, pGPIO_Reg);
					tcc_cif_set_addr(pCIF_Reg, IN_IMG,
								pCam->CamUserInfo.pPrevProp.InImageAddress[0].ImageBaseAddressY,
								pCam->CamUserInfo.pPrevProp.InImageAddress[0].ImageBaseAddressU,
								pCam->CamUserInfo.pPrevProp.InImageAddress[0].ImageBaseAddressV);
					tcc_cif_opresume(pCIF_Reg, pGPIO_Reg, gCamMod);

					SetEvent(gInImageEvent[2]);

					if(gCamMod==TVP5150A || gCamMod==TVP5150A_PAL)
					{
						if(gCIFMode == 1)
							BITSET(pCIF_Reg->ICPCR1, Hw26);
					}
					else
						BITCLR(pCIF_Reg->ICPCR1, Hw26);
				}
			}
		}
		tcc_cif_setinterrupt(pCIF_Reg, SET_CIF_INT_CLEAR);
		InterruptDone(pCam->iSysIntr);
	}

	return 0;
}


/************************************************************************************************
* FUNCTION		: int LFCIF_PortConfigure(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
int LFCIF_PortConfigure(void)
{
	tcc_cif_portopen(pCIF_Reg, pGPIO_Reg, pCKC_Reg, pDDICONFIG_Reg);
	return 0;
}
/************************************************************************************************
* FUNCTION		: int LFCIF_InitialConfigure(unsigned int ImgHSize,
*											 unsigned int ImgVSize,
*											 unsigned int Initialization,
*											 unsigned int FrameRate)
*
* DESCRIPTION	: 
*
************************************************************************************************/
//int LFCIF_InitialConfigure(unsigned int ImgHSize, unsigned int ImgVSize, unsigned int Initialization, unsigned int FrameRate)
int LFCIF_InitialConfigure(unsigned int Initialization, unsigned int FrameRate, unsigned int DataFormat)
{
	unsigned int skipNum = 0;
	
	if( Initialization == OPEN_AS_CCIR601)// micron_MT9D111 
	{
		//micro_MT9D111 : total input 30fs
		if(FrameRate == 15)
			skipNum = 2;
		else if(FrameRate == 10 )
			skipNum = 3;
		else
			skipNum = 0; // 30fs
		
		tcc_cif_set_info(pCIF_Reg, SET_CIF_ALL, SEPARATE, MSB_FIRST, MODE_YUV, FMT422, BAYER_RGB, MODE16, SEQYUYV, SWI_BUS);
		if(DataFormat == YUV420)
		{
			tcc_cif_set_ctrl(pCIF_Reg, (SET_CIF_OPERATING_DISABLE|SET_CIF_PWDN_DISABLE|SET_CIF_TVSIGNAL_DISABLE|SET_CIF_SKIPFRAME_ENABLE|SET_CIF_420CONVERT_ENABLE|SET_CIF_656CONVERT_DISABLE),	 skipNum, 3);
		}
		else//YUV422
		{
			tcc_cif_set_ctrl(pCIF_Reg, (SET_CIF_OPERATING_DISABLE|SET_CIF_PWDN_DISABLE|SET_CIF_TVSIGNAL_DISABLE|SET_CIF_SKIPFRAME_ENABLE|SET_CIF_420CONVERT_DISABLE|SET_CIF_656CONVERT_DISABLE), skipNum, 3);
		}
		tcc_cif_sync_pol(pCIF_Reg, ACT_HIGH, ACT_HIGH);
	
	}
	if (Initialization == OPEN_AS_CCIR656) // TVP5150
	{
		//TVP5150 : total input 60fs
		// if mode is YUV422, use Deinterlace Mode
		if(DataFormat == YUV422)
			skipNum = 0; // 30fs
		else
		{
		/*
			if(FrameRate == 30)
				skipNum = 1;
			else if(FrameRate == 15 )
				skipNum = 3;
			else if(FrameRate == 10 )
				skipNum = 5;
			else
				skipNum = 1; // 30fs
			*/
			skipNum = 3;
		
		}
			
		tcc_cif_set_info(pCIF_Reg, SET_CIF_ALL, SEPARATE, MSB_FIRST, MODE_YUV, FMT422, BAYER_RGB, MODE16, SEQYUYV, SWI_BUS);
		if(DataFormat == YUV422)
			tcc_cif_set_ctrl(pCIF_Reg, (SET_CIF_OPERATING_DISABLE|SET_CIF_PWDN_DISABLE|SET_CIF_TVSIGNAL_ENABLE|SET_CIF_656CONVERT_ENABLE|SET_CIF_BYPASS_SCALER_ENABLE),	 skipNum, 3);
		else
			tcc_cif_set_ctrl(pCIF_Reg, (SET_CIF_OPERATING_DISABLE|SET_CIF_PWDN_DISABLE|SET_CIF_TVSIGNAL_ENABLE|SET_CIF_SKIPFRAME_ENABLE|SET_CIF_420CONVERT_ENABLE|SET_CIF_656CONVERT_ENABLE|SET_CIF_BYPASS_SCALER_ENABLE),	 skipNum, 3);
		tcc_cif_sync_pol(pCIF_Reg, ACT_HIGH, ACT_LOW);
		tcc_cif_set656formatconfig(pCIF_Reg, SET_CIF_656_H_BLANK, 0,0,0,0,9,0);
	}
	
	tcc_cif_setinterrupt(pCIF_Reg, SET_CIF_INT_DISABLE|SET_CIF_RESPONCEINT_ENABLE|SET_CIF_REGISTERUP_ALWAYS|SET_CIF_INTTYPE_HOLDUP);
	tcc_cif_set_transfer(pCIF_Reg, SET_CIF_TRANSFER_ALL, BURST_TRANS, TRANS8, NO_LOCK);
	//tcc_cif_set_img(pCIF_Reg, IN_IMG, ImgHSize, ImgVSize, 0, 0, 0, 0);
	tcc_cif_scale(pCIF_Reg, OFF,SCALE1,SCALE1);

	return 0;
}
/************************************************************************************************
* FUNCTION		: int LFCIF_SetEffect(unsigned int EffectMode)
*
* DESCRIPTION	: 
*
************************************************************************************************/
int LFCIF_SetEffect(unsigned int EffectMode)
{

	tcc_cif_seteffectmode(pEFFECT_Reg, SET_CIF_EFFECT_NEGATIVE_DISABLE|SET_CIF_EFFECT_SEPIA_DISABLE
						|SET_CIF_EFFECT_EMBOSS_DISABLE|SET_CIF_EFFECT_SKETCH_DISABLE
						|SET_CIF_EFFECT_GRAY_DISABLE);	

	switch(  EffectMode )
	{
		case EFFECT_NEGATIVE:
			tcc_cif_seteffectmode(pEFFECT_Reg, SET_CIF_EFFECT_EFFECT_MODE|SET_CIF_EFFECT_NEGATIVE_ENABLE);
			break;
			
		case EFFECT_SEPIA:	
			tcc_cif_seteffectmode(pEFFECT_Reg, SET_CIF_EFFECT_EFFECT_MODE|SET_CIF_EFFECT_SEPIA_ENABLE);
			tcc_cif_seteffectsepiauv(pEFFECT_Reg, 0x70,0x90);
			break;		

		case EFFECT_EMBOSS:	
			tcc_cif_seteffectmode(pEFFECT_Reg, SET_CIF_EFFECT_EFFECT_MODE|SET_CIF_EFFECT_EMBOSS_ENABLE); 	
			break;		

		case EFFECT_SKETCH:
			tcc_cif_seteffectmode(pEFFECT_Reg, SET_CIF_EFFECT_EFFECT_MODE|SET_CIF_EFFECT_SKETCH_ENABLE); 	
			tcc_cif_seteffectsketchclampth(pEFFECT_Reg, SET_CIF_EFFECT_SKETCH_THRE|SET_CIF_EFFECT_CLAMP_THRE,0xD0,0xD0);
			break;

		case EFFECT_GRAY:	
			tcc_cif_seteffectmode(pEFFECT_Reg, SET_CIF_EFFECT_EFFECT_MODE|SET_CIF_EFFECT_GRAY_ENABLE); 	
			break;

		case EFFECT_NORMAL:	
		default:
			tcc_cif_seteffectmode(pEFFECT_Reg, SET_CIF_EFFECT_NORMAL_MODE);
		break;		
	}	
	
	return 0;
}
/************************************************************************************************
* FUNCTION		: int LFCIF_PreviewConfigure(CAM_USER_INFO *pCamUserInfo)
*
* DESCRIPTION	: 
*
************************************************************************************************/
int LFCIF_PreviewConfigure(CAM_USER_INFO *pCamUserInfo)
{
	memcpy(&gCIFIntr.CamUserInfo, pCamUserInfo, sizeof(CAM_USER_INFO));
//	LFCIF_InitialConfigure(pCamUserInfo->pPrevProp.InImgHSize, pCamUserInfo->pPrevProp.InImgVSize, pCamUserInfo->InitializationMode,pCamUserInfo->pPrevProp.PrevFrameRate);
	LFCIF_InitialConfigure(pCamUserInfo->InitializationMode,pCamUserInfo->pPrevProp.PrevFrameRate, pCamUserInfo->pCapProp.DataFormat);

	if(gCamMod == TVP5150A || gCamMod==TVP5150A_PAL)
		LFCIF_SetEffect(EFFECT_NORMAL);
	else
		LFCIF_SetEffect(pCamUserInfo->EffectMode);

	LFCIF_ScalerConfigure(pCamUserInfo, IOCTL_CIF_PREVIEWCONFIG);
	gCIFMode = pCamUserInfo->pCapProp.DataFormat;
	return 0;
}

/************************************************************************************************
* FUNCTION		: int LFCIF_CaptureConfigure(CAM_USER_INFO *pCamUserInfo)
*
* DESCRIPTION	: 
*
************************************************************************************************/
int LFCIF_CaptureConfigure(CAM_USER_INFO *pCamUserInfo)
{
//	LFCIF_InitialConfigure(pCamUserInfo->pCapProp.InImgHSize, pCamUserInfo->pCapProp.InImgVSize, pCamUserInfo->InitializationMode,pCamUserInfo->pCapProp.CaptureFrameRate);
	LFCIF_InitialConfigure(pCamUserInfo->InitializationMode,0,pCamUserInfo->pCapProp.DataFormat);
	
	if(gCamMod==TVP5150A || gCamMod==TVP5150A_PAL)
		LFCIF_SetEffect(EFFECT_NORMAL);
	else
		LFCIF_SetEffect(pCamUserInfo->EffectMode);

	LFCIF_ScalerConfigure(pCamUserInfo, IOCTL_CIF_CAPTURECONFIG);
	gCIFMode = pCamUserInfo->pCapProp.DataFormat;

	return 0;
}
/************************************************************************************************
* FUNCTION		: int LFCIF_GetCapturedFrame(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
int LFCIF_GetCapturedFrame(void)
{
	tcc_cif_getcapturedframe(pCIF_Reg, pGPIO_Reg);
	SetEvent(gCaptureEvent);	
	return 0; //Success
}

/************************************************************************************************
* FUNCTION		: int LFCIF_ScalerConfigure(CAM_USER_INFO *pCamUserInfo, unsigned int ControlMode)
*
* DESCRIPTION	: 
*
************************************************************************************************/
int LFCIF_ScalerConfigure(CAM_USER_INFO *pCamUserInfo, unsigned int ControlMode)
{
	unsigned int	ImageBaseAddrY;
	unsigned int	ImageBaseAddrU;
	unsigned int	ImageBaseAddrV;
	unsigned int	InImageHSize;
	unsigned int	InImageVSize;
	unsigned int	DstHSize, DstVSize;
	unsigned int	HScale, VScale;
	unsigned int	ScalerSkip = 0;

	switch( ControlMode)
	{
		case IOCTL_CIF_PREVIEWCONFIG:
			ImageBaseAddrY= pCamUserInfo->pPrevProp.InImageAddress[0].ImageBaseAddressY;
			ImageBaseAddrU= pCamUserInfo->pPrevProp.InImageAddress[0].ImageBaseAddressU;
			ImageBaseAddrV= pCamUserInfo->pPrevProp.InImageAddress[0].ImageBaseAddressV;
//			InImageHSize = pCamUserInfo->pPrevProp.InImgHSize;
//			InImageVSize = pCamUserInfo->pPrevProp.InImgVSize;

			if(gCamMod == TVP5150A || gCamMod==TVP5150A_PAL)
			{
				InImageHSize = 720;
				if(pCamUserInfo->pCapProp.DataFormat == YUV422)
				{
					if(gCamMod==TVP5150A_PAL)
						InImageVSize = 576;
					else
						InImageVSize = 486;
					
					ScalerSkip = TRUE;
				}
				else
				{
					if(gCamMod==TVP5150A_PAL)
						InImageVSize = 288;
					else
						InImageVSize = 243;
					ScalerSkip = FALSE;
				}
			}
			else if(gCamMod == MT9D112)
			{
				InImageHSize = 800;
				InImageVSize = 600;
				ScalerSkip = FALSE;
			}
			
			DstHSize = pCamUserInfo->pPrevProp.PrevHSize;
			DstVSize = pCamUserInfo->pPrevProp.PrevVSize;
			HScale = InImageHSize* 256 / DstHSize;
			VScale = InImageVSize* 256 / DstVSize;
			break;
			
		case IOCTL_CIF_CAPTURECONFIG:
			ImageBaseAddrY= pCamUserInfo->pCapProp.CaptureBaseAddress0;
			ImageBaseAddrU= pCamUserInfo->pCapProp.CaptureBaseAddress1;
			ImageBaseAddrV= pCamUserInfo->pCapProp.CaptureBaseAddress2;
//			InImageHSize = pCamUserInfo->pCapProp.InImgHSize;
//			InImageVSize = pCamUserInfo->pCapProp.InImgVSize-2;

			if(gCamMod == TVP5150A || gCamMod==TVP5150A_PAL)
			{
				InImageHSize = 720;
				if(pCamUserInfo->pCapProp.DataFormat == YUV422)
				{
					if(gCamMod==TVP5150A_PAL)
						InImageVSize = 576;
					else
						InImageVSize = 486;
				}
				else
				{
					if(gCamMod==TVP5150A_PAL)
						InImageVSize = 288;
					else
						InImageVSize = 243;
				}
			}
			else if(gCamMod == MT9D112)
			{
				InImageHSize = 1600;
				InImageVSize = 1200-2;
			}
	
			DstHSize = pCamUserInfo->pCapProp.CapHSize;
			DstVSize = pCamUserInfo->pCapProp.CapVSize;

			if( DstHSize < InImageHSize )
			{
				HScale = InImageHSize* 256 / DstHSize;
				VScale = InImageVSize* 256 / DstVSize;
				ScalerSkip = FALSE;
			}
			else
				ScalerSkip = TRUE;
				
			if(gCamMod == TVP5150A)
				ScalerSkip = TRUE;
			
			break;
	}

	tcc_cif_set_addr(pCIF_Reg, IN_IMG, ImageBaseAddrY, ImageBaseAddrU, ImageBaseAddrV);		
	tcc_cif_set_ctrl(pCIF_Reg, SET_CIF_BYPASS_SCALER_ENABLE, 0, 0);
	tcc_cif_setscalerctrl(pCIFSCALER_Reg, SET_CIF_SCALER_DISABLE);

	if( ControlMode == IOCTL_CIF_CAPTURECONFIG)
	{
		tcc_cif_setinterrupt(pCIF_Reg, SET_CIF_INT_DISABLE);
		tcc_cif_readfifostate(pCIF_Reg, SET_CIF_FIFO_STATE_CLR);
		tcc_cif_setcapturectrl(pCIF_Reg, SET_CIF_VEN_DISABLE);
		tcc_cif_setinterrupt(pCIF_Reg, SET_CIF_VCNT_DISABLE);
		tcc_cif_setinterrupt(pCIF_Reg, SET_CIF_RESPONCEINT_ENABLE);
		tcc_cif_setencrolskipnum(pCIF_Reg, SET_CIF_SKIP_NUM, 0,0,0,0,3,0);
		tcc_cif_setinterrupt(pCIF_Reg, SET_CIF_CAPFRAME_ENABLE);
	}

	tcc_cif_seteffectinimgsize(pEFFECT_Reg, InImageHSize, InImageVSize);

	if( ScalerSkip == FALSE)
	{
		tcc_cif_setscalerimgsizeoffsetscale(pCIFSCALER_Reg, SET_CIF_SCALER_ALL, InImageHSize, InImageVSize, 0, 0,
									DstHSize, DstVSize, HScale, VScale);
		tcc_cif_set_img(pCIF_Reg, IN_IMG, DstHSize, DstVSize,0,0,0,0);
		tcc_cif_set_ctrl(pCIF_Reg, SET_CIF_BYPASS_SCALER_DISABLE, 0, 0);
		tcc_cif_setscalerctrl(pCIFSCALER_Reg, SET_CIF_SCALER_ENABLE);
	}
	else
	{
		tcc_cif_set_img(pCIF_Reg, IN_IMG, InImageHSize, InImageVSize,0,0,0,0);
	}

	return 0;
}

/************************************************************************************************
* FUNCTION		: int LFCIF_FunctionControl(void* pParam)
*
* DESCRIPTION	: 
*
************************************************************************************************/
int LFCIF_FunctionControl(void* pParam)
{
	CIF_FUNCTION*	pFunc = (CIF_FUNCTION*)pParam;
	unsigned int *ParamData;

	switch(pFunc->FunctionName)
	{
		case	CIF_FUNCTION_INTERRUPT:
			tcc_cif_setinterrupt(pCIF_Reg, *(unsigned int*)pFunc->pFuncParam);
			break;

		case	CIF_FUNCTION_OPERATING:
			if( *(unsigned int*)pFunc->pFuncParam == ON)
				tcc_cif_opstart(pCIF_Reg, pGPIO_Reg,*(unsigned int*)pFunc->Mode, gCamMod); 
			else
				tcc_cif_opstop(pCIF_Reg, pGPIO_Reg);

			break;
		case	CIF_FUNCTION_INPUTIMAGEADDRESS:
			ParamData = (unsigned int*)pFunc->pFuncParam;
			tcc_cif_set_addr(pCIF_Reg, IN_IMG, *ParamData++, *ParamData++, *ParamData);
			break;
			
		default:
			break;
	}
	
	return 0;
}

/************************************************************************************************
* FUNCTION		: DWORD	CIF_Open(DWORD Context, DWORD Access, DWORD ShareMode)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD	CIF_Open(DWORD Context, DWORD Access, DWORD ShareMode)
{
	HKEY hk;
	DWORD dwStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Drivers\\Magellan\\CONFIG", 0, 0, &hk);
	DWORD dwType = REG_DWORD;
	DWORD dwSize = sizeof(DWORD);

	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{	
		dwStatus = RegQueryValueEx(hk, _T("CIFMODULE_TYPE"), NULL, &dwType, (LPBYTE) &gCamMod, &dwSize);
	}
	
	if(hk != NULL) 
	{
		RegCloseKey(hk);
	}

	UNREFERENCED_PARAMETER(Context);	
	UNREFERENCED_PARAMETER(Access);
	UNREFERENCED_PARAMETER(ShareMode);

	RETAILMSG(1, (TEXT("[CIFDRV      ]+CIF_Open \n")));
	
	//init CIF register map 
	pCIF_Reg = (CIF *)tcc_allocbaseaddress((unsigned int)&(HwCIF_BASE));
	pGPIO_Reg = (GPIO *)tcc_allocbaseaddress((unsigned int)&(HwGPIO_BASE));
	pCKC_Reg = (CKC *)tcc_allocbaseaddress((unsigned int)&(HwCLK_BASE));
	pDDICONFIG_Reg = (DDICONFIG*)tcc_allocbaseaddress((unsigned int)&(HwDDI_CONFIG_BASE));
	pEFFECT_Reg = (EFFECT*)tcc_allocbaseaddress((unsigned int)&(HwCEM_BASE));
	pCIFSCALER_Reg = (CIFSCALER*)tcc_allocbaseaddress((unsigned int)&(HwCSC_BASE));

	//cif power up
	tcc_cif_powerupdown(pCKC_Reg, 1);

	memset(&gCIFIntr,0,sizeof(CAMINTR));
	gCIFIntr.hFrameCompleteEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	gCIFIntr.iIrq = IRQ_CAM;

	if(!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &gCIFIntr.iIrq, sizeof(DWORD), &gCIFIntr.iSysIntr, sizeof(DWORD), NULL) )
	{
		//printf("%s fail at line %d\r\n", __FUNCTION__, __LINE__);
		return 0;
	}

	if(!InterruptInitialize(gCIFIntr.iSysIntr, gCIFIntr.hFrameCompleteEvent, 0, 0) )
	{
		//printf("%s fail at line %d\r\n", __FUNCTION__, __LINE__);
		return 0;
	}

	gCIFIntr.bKillThread = FALSE;
	gCIFIntr.CamUserInfo.pPrevProp.InImageAddressIndex = 0;
	gCIFIntr.dwPermission = GetCurrentPermissions();

	gCIFIntr.hThreadHandle = CreateThread(0, 0, (LPTHREAD_START_ROUTINE) CameraThread, &gCIFIntr, 0, NULL);

	CeSetThreadPriority(gCIFIntr.hThreadHandle, 248);

	gCIFDevStatus = CIF_STATUS_OPEN;
	RETAILMSG(1, (TEXT("[CIFDRV      ]-CIF_Open \n")));
	return TRUE;
	
}
/************************************************************************************************
* FUNCTION		: BOOL CIF_Close(DWORD Context)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL CIF_Close(DWORD Context)
{
	RETAILMSG(1, (TEXT("[CIFDRV      ]+CIF_Close \n")));
	if(gCaptureEvent != NULL)
	{
		CloseHandle(gCaptureEvent);	
		gCaptureEvent = NULL;
	}
	if(gInImageEvent[0] != NULL)
	{
		CloseHandle(gInImageEvent[0]);
		gInImageEvent[0] = NULL;
	}
	if(gInImageEvent[1] != NULL)
	{
		CloseHandle(gInImageEvent[1]);
		gInImageEvent[1] = NULL;
	}
		
	if(gInImageEvent[2] != NULL)
	{
		CloseHandle(gInImageEvent[2]);
		gInImageEvent[2] = NULL;
	}
	
	if(gCIFIntr.hThreadHandle)
	{
		gCIFIntr.bKillThread = TRUE;
		SetEvent(gCIFIntr.hFrameCompleteEvent);
		WaitForSingleObject(gCIFIntr.hThreadHandle, INFINITE);
		CloseHandle(gCIFIntr.hThreadHandle);
	}

	KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &gCIFIntr.iSysIntr, sizeof(DWORD), NULL, 0, NULL);
	InterruptDisable(gCIFIntr.iSysIntr);
	
	CloseHandle(gCIFIntr.hFrameCompleteEvent);
	
	//cif power down
	tcc_cif_powerupdown(pCKC_Reg, 0);

	gCIFDevStatus = CIF_STATUS_CLOSE;
	RETAILMSG(1, (TEXT("[CIFDRV      ]-CIF_Close \n")));
	return TRUE;
}
/************************************************************************************************
* FUNCTION		: BOOL CIF_IOControl( DWORD Handle,
*									  DWORD dwIoControlCode, 
*				   					  PBYTE pInBuf,
*				   					  DWORD nInBufSize, 
*				   					  PBYTE pOutBuf,
*				   					  DWORD nOutBufSize,
*				   					  PDWORD pBytesReturned)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL CIF_IOControl( DWORD Handle, DWORD dwIoControlCode, 
				   PBYTE pInBuf, DWORD nInBufSize, 
				   PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
{
	CAM_USER_INFO *pCamUserInfo = (CAM_USER_INFO *)pInBuf;
	void *pParam = (CAM_USER_INFO *)pInBuf;
	
	switch( dwIoControlCode )
	{
		case IOCTL_CIF_PORTINITIALIZE:
			LFCIF_PortConfigure();
			break;
			
		case IOCTL_CIF_PREVIEWCONFIG:
			if(gInImageEvent[0] != NULL)
			{
				CloseHandle(gInImageEvent[0]);
				gInImageEvent[0] = NULL;
			}
			if(gInImageEvent[1] != NULL)
			{
				CloseHandle(gInImageEvent[1]);
				gInImageEvent[1] = NULL;
			}
			if(gInImageEvent[2] != NULL)
			{
				CloseHandle(gInImageEvent[2]);
			gInImageEvent[2] = NULL;
			}
			
			gInImageEvent[0] = OpenEvent(EVENT_ALL_ACCESS, FALSE, _T("IMGIN0_EVENT"));
			gInImageEvent[1] = OpenEvent(EVENT_ALL_ACCESS, FALSE, _T("IMGIN1_EVENT"));
			gInImageEvent[2] = OpenEvent(EVENT_ALL_ACCESS, FALSE, _T("IMGIN2_EVENT"));

			LFCIF_PreviewConfigure(pCamUserInfo);
			break;

		case IOCTL_CIF_CAPTURECONFIG:
			if(gCaptureEvent != NULL)
			{
				CloseHandle(gCaptureEvent);
				gCaptureEvent = NULL;				
			}
			
			gCaptureEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, _T("CAPTURE_EVENT"));
	
			LFCIF_CaptureConfigure(pCamUserInfo);
			break;

		case IOCTL_CIF_STARTCAPTURE:
			LFCIF_GetCapturedFrame();
		break;

		case IOCTL_CIF_FUNCTIONCONTROL:
			LFCIF_FunctionControl(pParam);
			break;
			
		case IOCTL_CIF_SETEFFECT:
			LFCIF_SetEffect(pCamUserInfo->EffectMode);
			break;
			
		case IOCTL_CIF_STARTOPERATING:
			tcc_cif_onoff_new(pCIF_Reg, pCKC_Reg, pGPIO_Reg, pDDICONFIG_Reg, ON);
			break;

		case IOCTL_CIF_STOPOPERATING:
			tcc_cif_onoff_new(pCIF_Reg, pCKC_Reg, pGPIO_Reg, pDDICONFIG_Reg, OFF);
			tcc_cif_portclose(pGPIO_Reg, pCKC_Reg, pDDICONFIG_Reg);
			break;
			
		default:
		break;
	}
	return TRUE;
}
/************************************************************************************************
* FUNCTION		: void CIF_PowerUp( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
VOID CIF_PowerUp( DWORD hDeviceContext )
{
	RETAILMSG(1,(TEXT("[CIFDRV      ]+CIF_PowerUp\n")));
	if(gCIFDevStatus != CIF_STATUS_CLOSE)
	{
		tcc_cif_powerupdown(pCKC_Reg, 1);
	}
	RETAILMSG(1,(TEXT("[CIFDRV      ]-CIF_PowerUp\n")));
}

/************************************************************************************************
* FUNCTION		: void CIF_PowerDown( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
VOID CIF_PowerDown( DWORD hDeviceContext )
{
	RETAILMSG(1,(TEXT("[CIFDRV      ]+CIF_PowerDown\n")));
	if(gCIFDevStatus != CIF_STATUS_CLOSE)
	{
		tcc_cif_powerupdown(pCKC_Reg, 0);
	}
	RETAILMSG(1,(TEXT("[CIFDRV      ]-CIF_PowerDown\n")));	
}

/************************************************************************************************
* FUNCTION		: DWORD CIF_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD CIF_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
{
	RETAILMSG(1,(TEXT("[CIFDRV      ]+CIF_Read\n")));
	RETAILMSG(1,(TEXT("[CIFDRV      ]-CIF_Read\n")));	
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD CIF_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD CIF_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
{
	RETAILMSG(1,(TEXT("[CIFDRV      ]+CIF_Write\n")));
	RETAILMSG(1,(TEXT("[CIFDRV      ]-CIF_Write\n")));	
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD CIF_Seek( DWORD hOpenContext, long Amount, WORD Type )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD CIF_Seek( DWORD hOpenContext, long Amount, WORD Type )
{
	RETAILMSG(1,(TEXT("[CIFDRV      ]+CIF_Seek\n")));
	RETAILMSG(1,(TEXT("[CIFDRV      ]-CIF_Seek\n")));	
	return 0;
}

/* end of file */

