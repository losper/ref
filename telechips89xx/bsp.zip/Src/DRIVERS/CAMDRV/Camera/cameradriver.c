/****************************************************************************
 *   FileName    : cameradriver.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/

/************************************************************************************************
*					 INLCUDES
*************************************************************************************************/
#include <windows.h>
#include <devload.h>
#include <pm.h>
#include <nkintr.h>

#include "camdef.h"
#include "ioctl_code.h"
#include "../CIF/CIFDriver.h"
#include "../CIF/CIFRegisterSet.h"
#include "../ModuleDrv/CamModuleDrv.h"
#include "tcc_ckc.h"


/************************************************************************************************
*					 DEFINES
*************************************************************************************************/
#ifdef DEBUG

DBGPARAM dpCurSettings = {
    _T("usbmsfn"),
    {
        _T("Error"), _T("Warning"), _T("Init"), _T("Function"),
        _T("Comments"), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""), 
        _T(""), _T(""), _T(""), _T("")
    },
    0x5
};

#endif // DEBUG
/*	Divice Driver Sample	*/
#define	LOCK(pd)			EnterCriticalSection(&(pd)->csDevice)
#define	UNLOCK(pd)			LeaveCriticalSection(&(pd)->csDevice)
#define	dim(x)				(sizeof(x) / sizeof(x[0]))
#define	MAXDEVICES			1
#define	SYSERRORSTRING(s)		SysErrorString((s), szErrorString, dim(szErrorString))

#define		ON			1
#define		OFF			0
#define		SNAPSHOT_PREVIEW			1
#define		CAMCODER_PREVIEW			2

/*
enum
{
	CAM_ON_STATUS,
	CAM_PREVIEW_STATUS,
	CAM_CAPTURE_STATUS,
	CAM_STOPPREVIEW_STATUS,
	CAM_OFF_STATUS,
};
*/
/************************************************************************************************
*					 TYPE DEFINES
*************************************************************************************************/
// this structure keeps track of each device instance
typedef struct _DeviceState_tag {
	CRITICAL_SECTION		csDevice;		// serialize access to this device's state
	HANDLE					hevStop;		// when signaled, the device thread exits
	HANDLE					htDevice;		// device thread handle
	HANDLE					htActivity;		// activity generating thread
	TCHAR					szName[16];		// should be of the format"CAMn" (no colon)
	CEDEVICE_POWER_STATE	CurrentDx;		// current power level
	DWORD					dwInactivityTimeout;	// in ms
	DWORD					dwMaxActivityTimeout;	// in ms
	BOOL                    fBoostRequested;      // TRUE if we request a power state increase
	BOOL                    fReductionRequested;  // TRUE if we request a power state decrease
} DEVICESTATE, *PDEVICESTATE;

/************************************************************************************************
*					 STRUCTURES
*************************************************************************************************/


/************************************************************************************************
*					 GLOBALS
*************************************************************************************************/
DEVICESTATE e4[MAXDEVICES];
INT giDevices = 0;
HANDLE ghevResume = NULL;
CAM_USER_INFO gCamUserInfo;

static HANDLE	gCamModule;
static HANDLE gCIFHandle;
static CIF_FUNCTION gCifLocalFunction;
static gDevStatus = CAM_OFF_STATUS;
static unsigned int gCamMod = NONE_CAMMOD;

/************************************************************************************************
*					 EXTERNAL FUNCTION PROTOTYPE
*************************************************************************************************/


/************************************************************************************************
*					 LOCAL FUNCTION PROTOTYPE
*************************************************************************************************/
int	StartPreview(CAM_USER_INFO *pCamUserInfo);
int	StopPreview(void);
int	StartCapture(CAM_USER_INFO *pCamUserInfo);
int	ContinuePreview(CAM_USER_INFO *pCamUserInfo);
int	SetCameraEffect(CAM_USER_INFO *pCamUserInfo);


/************************************************************************************************
*					 LOCAL FUNCTIONS
*************************************************************************************************/
static void delayLoop(int count)
{
	volatile int j,k;
	for(j = 0; j < count; j++)
	{
		for(k=0;k<100000;k++);
	}
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int StartPreview(CAM_USER_INFO *pCamUserInfo)
{
	unsigned int	Status = 0;
	unsigned int	funcparam=0;
	unsigned int 	mode =0;
	DWORD			nONOFF=1;
	// Port Configuratioin for Camera interface
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_PORTINITIALIZE, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);
	delayLoop(10);
	
	if(gCamMod==TVP5150A || gCamMod==TVP5150A_PAL)
	{
		Status = DeviceIoControl(gCamModule, IOCTL_MODULE_MODE, &nONOFF, sizeof(DWORD), NULL, 0, NULL, NULL);
		delayLoop(50);
	}
	else if(gCamMod==MT9D112)
	{
		Status = DeviceIoControl(gCamModule, IOCTL_MODULE_PREVIEW, NULL, 0,NULL, 0, NULL, NULL);
		delayLoop(100);
	}
	
	// CIF Controller Setting here for Preview Mode.
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_PREVIEWCONFIG, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);

	// Operation Start..
	funcparam = ON;
	gCifLocalFunction.FunctionName = CIF_FUNCTION_OPERATING;
	gCifLocalFunction.pFuncParam = &funcparam;
	mode = pCamUserInfo->pCapProp.DataFormat;
	gCifLocalFunction.Mode = &mode;
	
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_FUNCTIONCONTROL, &gCifLocalFunction, sizeof(gCifLocalFunction), NULL, 0, NULL, NULL );

	// Interrupt Enable when getting one frame from a cam module.
	funcparam = SET_CIF_INT_ENABLE;
	gCifLocalFunction.FunctionName = CIF_FUNCTION_INTERRUPT;
	gCifLocalFunction.pFuncParam = &funcparam;
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_FUNCTIONCONTROL, &gCifLocalFunction, sizeof(gCifLocalFunction), NULL, 0, NULL, NULL);

	return 0; // success
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int StopPreview(void)
{
	unsigned int	Status=0;
	unsigned int	funcparam =0;
	gCifLocalFunction.pFuncParam = &funcparam;

	funcparam = SET_CIF_INT_DISABLE;
	gCifLocalFunction.FunctionName = CIF_FUNCTION_INTERRUPT;
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_FUNCTIONCONTROL, &gCifLocalFunction, sizeof(gCifLocalFunction), NULL, 0, NULL, NULL);

	funcparam = OFF;
	gCifLocalFunction.FunctionName = CIF_FUNCTION_CAMERAMODULEONOFF;
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_FUNCTIONCONTROL, &gCifLocalFunction, sizeof(gCifLocalFunction), NULL, 0, NULL, NULL );

	Status = DeviceIoControl( gCIFHandle, IOCTL_CIF_STOPOPERATING, NULL,0, NULL, 0, NULL, NULL);

	return 0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int StartCapture(CAM_USER_INFO *pCamUserInfo)
{
	unsigned int		Status = 0;
	unsigned int		funcparam = 0;

	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_STOPOPERATING, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);

	if(gCamMod==MT9D112)
		Status = DeviceIoControl(gCamModule, IOCTL_MODULE_CAPTURE, NULL, 0, NULL, 0, NULL, NULL);
	
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_PORTINITIALIZE, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);
	delayLoop(10);

	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_CAPTURECONFIG, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);
	delayLoop(50);

	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_STARTOPERATING, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);
	delayLoop(200);

	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_STARTCAPTURE, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);

	return 0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int ContinuePreview(CAM_USER_INFO *pCamUserInfo)
{
	unsigned int	Status=0;
	unsigned int	funcparam = 0;
	DWORD			nONOFF=1;

	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_STOPOPERATING, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);

	if(gCamMod == TVP5150A || gCamMod==TVP5150A_PAL)
		Status = DeviceIoControl(gCamModule, IOCTL_MODULE_MODE, &nONOFF, sizeof(DWORD), NULL, 0, NULL, NULL);	
	else
		Status = DeviceIoControl(gCamModule, IOCTL_MODULE_PREVIEW, NULL, 0, NULL, 0, NULL, NULL);
	
	delayLoop(50);

	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_PORTINITIALIZE, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);
	delayLoop(10);

	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_PREVIEWCONFIG, pCamUserInfo, sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);

	funcparam = ON;
	gCifLocalFunction.FunctionName = CIF_FUNCTION_OPERATING;
	gCifLocalFunction.pFuncParam = &funcparam;
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_FUNCTIONCONTROL, &gCifLocalFunction, sizeof(gCifLocalFunction), NULL, 0, NULL, NULL );

	funcparam = SET_CIF_INT_ENABLE;
	gCifLocalFunction.FunctionName = CIF_FUNCTION_INTERRUPT;
	gCifLocalFunction.pFuncParam = &funcparam;
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_FUNCTIONCONTROL, &gCifLocalFunction, sizeof(gCifLocalFunction), NULL, 0, NULL, NULL);

	return 0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int SetCameraEffect(CAM_USER_INFO *pCamUserInfo)
{
	DeviceIoControl(gCIFHandle, IOCTL_CIF_SETEFFECT, pCamUserInfo,sizeof(CAM_USER_INFO), NULL, 0, NULL, NULL);
	return 0;
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
// this routine returns a pointer to an error string for a given GetLastError() value.
// See public\common\sdk\winerror.h for error codes.
LPTSTR
SysErrorString(DWORD dwStatus, LPTSTR pszBuf, DWORD nSize)
{
	if(FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwStatus, 0, pszBuf, nSize, NULL) == 0) {
		_tcsncpy(pszBuf, _T("<FormatMessage() failed>"), nSize);
	}

	return pszBuf;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD
CAM_Init(
    PVOID Context
    )
{
	UNREFERENCED_PARAMETER(Context);
	RETAILMSG( 1, (_T("[CAMDRV      ]CAM_Init: context %s\n\r"), Context));
	return 1;
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL
CAM_Deinit(
    DWORD dwContext
    )
{
	PDEVICESTATE pds = (PDEVICESTATE) dwContext;
	BOOL fOk = FALSE;
    //DEBUGMSG(ZONE_INIT, (_T("CAM_Deinit\r\n")));
    return TRUE;
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/BOOL
CAM_IOControl(
    DWORD  dwContext,
    DWORD  Ioctl,
    PUCHAR pInBuf,
    DWORD  InBufLen, 
    PUCHAR pOutBuf,
    DWORD  OutBufLen,
    PDWORD pdwBytesTransferred
   )
{
	switch(Ioctl)
	{
		case IOCTL_CAM_STARTPREVIEW:
			memcpy(&gCamUserInfo, pInBuf, sizeof(CAM_USER_INFO));
			StartPreview((CAM_USER_INFO*)pInBuf);
			gDevStatus = CAM_PREVIEW_STATUS;
			break;

		case IOCTL_CAM_STOPPREVIEW:
			StopPreview();
			gDevStatus = CAM_STOPPREVIEW_STATUS;
			break;
			
		case IOCTL_CAM_STARTCAPTURECAMERA:
			StartCapture((CAM_USER_INFO*)pInBuf);
			gDevStatus = CAM_CAPTURE_STATUS;
			break;

		case IOCTL_CAM_CONTINUEPREVIEW:
			memcpy(&gCamUserInfo, pInBuf, sizeof(CAM_USER_INFO));
			ContinuePreview((CAM_USER_INFO*)pInBuf);
			gDevStatus = CAM_PREVIEW_STATUS;
			break;
		case IOCTL_CAM_EFFECT:
			memcpy(&gCamUserInfo, pInBuf, sizeof(CAM_USER_INFO));
			SetCameraEffect((CAM_USER_INFO*)pInBuf);
			break;
	}
	return 1;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
VOID
CAM_PowerDown(
	DWORD dwContext
    )
{
	UNREFERENCED_PARAMETER(dwContext);
	RETAILMSG(1,(TEXT("[CAMDRV      ]+CAMERA_PowerDown\n")));

	if(gDevStatus != CAM_OFF_STATUS)
	{
		unsigned int	Status;
		StopPreview();
		Status = DeviceIoControl(gCamModule, IOCTL_MODULE_DEINIT, NULL, 0,NULL, 0, NULL, NULL);

		if(gCamMod==MT9D112)
			tcc_ckc_setperi(PERI_CIFMC, DISABLE, 245000, PCDIRECTPLL2);

		tcc_ckc_setperi(PERI_CIFSC, DISABLE, 1000000, PCDIRECTPLL3);
	}

	RETAILMSG(1,(TEXT("[CAMDRV      ]-CAMERA_PowerDown\n")));
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
VOID
CAM_PowerUp(
   DWORD dwContext
   )
{
	UNREFERENCED_PARAMETER(dwContext);
	if(ghevResume != NULL) {
	    CeSetPowerOnEvent(ghevResume);
	}
	RETAILMSG(1,(TEXT("[CAMDRV      ]+CAMERA_PowerUp\n")));

	if(gDevStatus != CAM_OFF_STATUS)
	{
		unsigned int	Status;
		if(gCamMod==MT9D112)
			tcc_ckc_setperi(PERI_CIFMC, ENABLE, 245000, PCDIRECTPLL2);
		tcc_ckc_setperi(PERI_CIFSC, ENABLE, 1000000, PCDIRECTPLL3);

		// Port Configuratioin for Camera interface
		Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_PORTINITIALIZE, NULL, 0, NULL, 0, NULL, NULL);
		Status = DeviceIoControl(gCamModule, IOCTL_MODULE_INIT, NULL, 0,NULL, 0, NULL, NULL);
		
		SetCameraEffect(&gCamUserInfo);
		if(gDevStatus == CAM_STOPPREVIEW_STATUS)
			StopPreview();			
 		else if(gDevStatus == CAM_PREVIEW_STATUS)
			StartPreview(&gCamUserInfo);
		else if(gDevStatus == CAM_CAPTURE_STATUS)
			StartCapture(&gCamUserInfo);
	}

	RETAILMSG(1,(TEXT("[CAMDRV      ]-CAMERA_PowerUp\n")));	
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD
CAM_Open(
    DWORD Context, 
    DWORD Access,
    DWORD ShareMode)
{
//	DEBUGMSG(ZONE_FUNCTION,(_T("CAM_Open(%x, 0x%x, 0x%x)\r\n"),Context, Access, ShareMode));
//	UNREFERENCED_PARAMETER(Context);	
//	UNREFERENCED_PARAMETER(Access);
//	UNREFERENCED_PARAMETER(ShareMode);
	HKEY hk;
	DWORD dwStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Drivers\\Magellan\\CONFIG", 0, 0, &hk);
	DWORD dwType = REG_DWORD;
	DWORD dwSize = sizeof(DWORD);
	unsigned int	Status;

	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{	
		dwStatus = RegQueryValueEx(hk, _T("CIFMODULE_TYPE"), NULL, &dwType, (LPBYTE) &gCamMod, &dwSize);
	}
	
	if(hk != NULL) 
	{
		RegCloseKey(hk);
	}
	
	if(gCamMod == MT9D112)
	{
		tcc_ckc_setperi(PERI_CIFMC, ENABLE, 245000, PCDIRECTPLL2);
	}
	tcc_ckc_setperi(PERI_CIFSC, ENABLE, 1000000, PCDIRECTPLL3);

	if(gCamMod == TVP5150A || gCamMod==TVP5150A_PAL)
		gCamModule = CreateFile(L"DEC1:", GENERIC_READ|GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
	else//MT9D112
		gCamModule = CreateFile(L"MOD1:", GENERIC_READ|GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );

	gCIFHandle = CreateFile(L"CIF1:", GENERIC_READ|GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );

	if(!gCamModule || !gCIFHandle)
		RETAILMSG(1,(TEXT("[CAMDRV		]ERROR: Can't open Drivers for Camera!!\n")));

	RETAILMSG(1,(TEXT("[CAMDRV      ]CAMERA_Open\n")));
	
	// Port Configuratioin for Camera interface
	Status = DeviceIoControl(gCIFHandle, IOCTL_CIF_PORTINITIALIZE, NULL, 0, NULL, 0, NULL, NULL);
	Status = DeviceIoControl(gCamModule, IOCTL_MODULE_INIT, NULL, 0,NULL, 0, NULL, NULL);

	gDevStatus = CAM_ON_STATUS;
	return TRUE;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL  
CAM_Close(
    DWORD Context
    ) 
{
    //DEBUGMSG(ZONE_FUNCTION,(_T("CAM_Close(%x)\r\n"), Context));
	unsigned int	Status;
	RETAILMSG(1,(TEXT("[CAMDRV      ]+CAMERA_Close\n")));
	Status = DeviceIoControl(gCamModule, IOCTL_MODULE_DEINIT, NULL, 0,NULL, 0, NULL, NULL);
	StopPreview();

	CloseHandle(gCIFHandle);
	CloseHandle(gCamModule);

	if(gCamMod == MT9D112)
			tcc_ckc_setperi(PERI_CIFMC, DISABLE, 245000, PCDIRECTPLL2);
		
	tcc_ckc_setperi(PERI_CIFSC, DISABLE, 1000000, PCDIRECTPLL3);

	RETAILMSG(1,(TEXT("[CAMDRV      ]-CAMERA_Close\n")));
	gDevStatus = CAM_OFF_STATUS;

    return TRUE;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD
CAM_Read(
    DWORD  dwContext,
    LPVOID pBuf,
    DWORD  Len
    ) 
{
    UNREFERENCED_PARAMETER(dwContext);
    UNREFERENCED_PARAMETER(pBuf);
    UNREFERENCED_PARAMETER(Len);
    
    //DEBUGMSG(ZONE_ERROR | ZONE_FUNCTION,(_T("CAM_Read\r\n")));
    SetLastError(ERROR_INVALID_FUNCTION);
    return  0;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD
CAM_Write(
    DWORD  dwContext,
    LPVOID pBuf,
    DWORD  Len
    ) 
{
    UNREFERENCED_PARAMETER(dwContext);
    UNREFERENCED_PARAMETER(pBuf);
    UNREFERENCED_PARAMETER(Len);
    
    //DEBUGMSG(ZONE_ERROR | ZONE_FUNCTION,(_T("CAM_Read\r\n")));
    SetLastError(ERROR_INVALID_FUNCTION);
    return  0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
ULONG
CAM_Seek(
   PVOID Context,
   LONG Position,
   DWORD Type
   )
{
    UNREFERENCED_PARAMETER(Context);
    UNREFERENCED_PARAMETER(Position);
    UNREFERENCED_PARAMETER(Type);
    
    //return (DWORD)-1;
	return 0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL 
DllEntry(
   HANDLE hDllHandle, 
   DWORD  dwReason, 
   LPVOID lpreserved
   ) 
{
    BOOL bRc = TRUE;
    
    UNREFERENCED_PARAMETER(hDllHandle);
    UNREFERENCED_PARAMETER(lpreserved);
    
    switch (dwReason) {
        case DLL_PROCESS_ATTACH: 
            {
                DEBUGREGISTER((HINSTANCE)hDllHandle);
                //DEBUGMSG(ZONE_INIT,(_T("*** DLL_PROCESS_ATTACH - Current Process: 0x%x, ID: 0x%x ***\r\n"),
                //GetCurrentProcess(), GetCurrentProcessId()));
                //memset(&gDevices, 0, sizeof(gDevices));
                DisableThreadLibraryCalls(hDllHandle);
            } 
            break;

        case DLL_PROCESS_DETACH: 
            {
                //DEBUGMSG(ZONE_INIT,(_T("*** DLL_PROCESS_DETACH - Current Process: 0x%x, ID: 0x%x ***\r\n"),
                //GetCurrentProcess(), GetCurrentProcessId()));
            } 
            break;

        default:
            break;
    }
	
    return bRc;
}
