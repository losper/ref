
/****************************************************************************
*   FileName    : CamModuleDrv.CPP
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/
#include "camdef.h"
#include "bsp.h"
#include "tcc_gpio.h"
#include "tcc_camsensor.h"
#include "ioctl_code.h"
#include "cammoduledrv.h"

enum
{
	RST_OFF = 0,
	RST_ON,
	RST_RESET
};

GPIO *pGPIO_Reg = NULL;
static unsigned int gCamMod = NONE_CAMMOD;

/************************************************************************************************
* FUNCTION		: BOOL DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
*
* DESCRIPTION	: Camera Module Driver DLL Entry
*
************************************************************************************************/
BOOL WINAPI DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
{
	switch ( dwReason ) {
	case DLL_PROCESS_ATTACH:
		//RETAILMSG(1, (TEXT("[CAMDRV      ]DLLEntry : DLL_PROCESS_ATTACH\r\n")));
		DisableThreadLibraryCalls((HMODULE) hInstDll);
		break;
	}
	return (TRUE);
}

/************************************************************************************************
* FUNCTION		: DWORD	MOD_Init(( LPCTSTR pContext, LPCVOID lpvBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD	MOD_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{
	RETAILMSG(1, (TEXT("[MODDRV      ]+MODULE_Init \n")));
	RETAILMSG(1, (TEXT("[MODDRV      ]-MODULE_Init \n")));

	return TRUE;
}
/************************************************************************************************
* FUNCTION		: MOD_Deinit(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL	MOD_Deinit( DWORD hDeviceContext )
{
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: void	MOD_Open(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void	MOD_Open(void)
{
	// Open I2C Driver
	// Get I2C Driver Handle
	HKEY hk;
	DWORD dwStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Drivers\\Magellan\\CONFIG", 0, 0, &hk);
	DWORD dwType = REG_DWORD;
	DWORD dwSize = sizeof(DWORD);
	
	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) 
	{	
		dwStatus = RegQueryValueEx(hk, _T("CIFMODULE_TYPE"), NULL, &dwType, (LPBYTE) &gCamMod, &dwSize);
	}
	
	if(hk != NULL) 
	{
		RegCloseKey(hk);
	}

	RETAILMSG(1, (TEXT("[MODDRV      ]+MODULE_Open \n")));

	// Open I2C Driver
	tcc_camsensor_initi2c();
	pGPIO_Reg = (GPIO *)tcc_allocbaseaddress((unsigned int)&(HwGPIO_BASE));
		
	RETAILMSG(1, (TEXT("[MODDRV      ]-MODULE_Open \n")));
}

/************************************************************************************************
* FUNCTION		: void MOD_Close(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void MOD_Close(void)
{
	RETAILMSG(1, (TEXT("[MODDRV      ]+MODULE_Close \n")));
	// Close I2C Handle
	tcc_camsensor_deiniti2c();
	RETAILMSG(1, (TEXT("[MODDRV      ]-MODULE_Close \n")));
}

/************************************************************************************************
* FUNCTION		: BOOL MOD_IOControl( DWORD Handle, DWORD dwIoControlCode, 
*									   PBYTE pInBuf, DWORD nInBufSize, 
*									   PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL MOD_IOControl( DWORD Handle, DWORD dwIoControlCode, 
				   PBYTE pInBuf, DWORD nInBufSize, 
				   PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
{
	static int iCurModMode = 0;
	
	switch( dwIoControlCode)
	{
		case IOCTL_MODULE_INIT:
			tcc_gpioexp_setcampwrctl(1);	
			tcc_camreset_onoff(pGPIO_Reg, RST_RESET);
			
			if(!tcc_cam_checki2s(gCamMod))
			{
				return FALSE;
			}
			
			tcc_camsensor_cameramoduleinit(0);
			iCurModMode = MOD_PREVIEMODE;
			break;
		case IOCTL_MODULE_PREVIEW:
			if(iCurModMode != MOD_PREVIEMODE)
			{
				tcc_camsensor_capture(OFF);
				iCurModMode = MOD_PREVIEMODE;
			}
			break;			
		case IOCTL_MODULE_CAPTURE:
			if(iCurModMode != MOD_CAPTUREMODE)
			{
				tcc_camsensor_capture(ON);
				iCurModMode = MOD_CAPTUREMODE;
			}
			break;
		case IOCTL_MODULE_MODE:
			break;
		case IOCTL_MODULE_DEINIT:
			//Keep this order - mt9d112 
			tcc_gpioexp_setcampwrctl(0);
			tcc_camreset_onoff(pGPIO_Reg, RST_OFF);			
			break;		
	}
	return TRUE;
}
/************************************************************************************************
* FUNCTION		: void MOD_PowerUp( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void MOD_PowerUp( DWORD hDeviceContext )
{
	RETAILMSG(1,(TEXT("[MODDRV      ]+MODULE_PowerUp\n")));
	RETAILMSG(1,(TEXT("[MODDRV      ]-MODULE_PowerUp\n")));
}

/************************************************************************************************
* FUNCTION		: void MOD_PowerDown( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void MOD_PowerDown( DWORD hDeviceContext )
{
	RETAILMSG(1,(TEXT("[MODDRV      ]+MODULE_PowerDown\n")));
	RETAILMSG(1,(TEXT("[MODDRV      ]-MODULE_PowerDown\n")));	
}

/************************************************************************************************
* FUNCTION		: DWORD MOD_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD MOD_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
{
	RETAILMSG(1,(TEXT("[MODDRV      ]+MODULE_Read\n")));
	RETAILMSG(1,(TEXT("[MODDRV      ]-MODULE_Read\n")));	
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD MOD_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD MOD_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
{
	RETAILMSG(1,(TEXT("[MODDRV      ]+MODULE_Write\n")));
	RETAILMSG(1,(TEXT("[MODDRV      ]-MODULE_Write\n")));	
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD MOD_Seek( DWORD hOpenContext, long Amount, WORD Type )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD MOD_Seek( DWORD hOpenContext, long Amount, WORD Type )
{
	RETAILMSG(1,(TEXT("[MODDRV      ]+MODULE_Seek\n")));
	RETAILMSG(1,(TEXT("[MODDRV      ]-MODULE_Seek\n")));	
	return 0;
}
