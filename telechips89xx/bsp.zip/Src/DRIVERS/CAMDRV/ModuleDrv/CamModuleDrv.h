
/****************************************************************************
*   FileName    : CamModuleDrv.h
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/
enum
{
	MOD_PREVIEMODE = 0,
	MOD_CAPTUREMODE,
};
