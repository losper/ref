/****************************************************************************
 *   FileName    : Video_Dec.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include "bsp.h"
#include "tcc_gpio.h"
#include "tcc_vdec.h"
#include <windows.h>
#include <devload.h>
#include <nkintr.h>
#include <windev.h>
#include "ioctl_code.h"
#include "../../../drivers/i2c1/TCC_I2C.h"

//#define _VDEC_TEST_

/************************************************************************************************
* Define 
************************************************************************************************/
HANDLE h_CAMDetThread;
HANDLE h_CAMDetEvent;
HANDLE ghI2C;

/************************************************************************************************
* Define Global 
************************************************************************************************/
GPIO *pGPIO_Reg = NULL;

/************************************************************************************************
* FUNCTION		: BOOL DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
*
* DESCRIPTION	: Video Decoder Driver DLL Entry
*
************************************************************************************************/
BOOL WINAPI DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
{
	switch ( dwReason ) {
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls((HMODULE) hInstDll);
//			RETAILMSG(1, (TEXT("DllEntry : DLL_PROCESS_ATTACH\r\n")));
			break;
	}      
	return (TRUE);
}

/************************************************************************************************
* FUNCTION		: DWORD CAM_DetectThread(PVOID pArg)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD CAM_DetectThread(PVOID pArg)
{
	h_CAMDetEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if (!h_CAMDetEvent )
		return ( FALSE );

	while (1)
	{
		WaitForSingleObject(h_CAMDetEvent, 1000);

		//Detect Check
		if (tcc_vdec_outputdetect(pGPIO_Reg))
			// Enable Outputs
			tcc_vdec_outputctrl(TRUE);
		else
			// Disable Outputs
			tcc_vdec_outputctrl(FALSE);
	}
}


/************************************************************************************************
* FUNCTION		: DWORD DEC_Init(DWORD dwContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD DEC_Init(DWORD dwContext)
{
    RETAILMSG(1, (TEXT("[VIDEO DEC   ]+ DEC_Init()\n")));
	/*
	pGPIO_Reg = (GPIO *)tcc_allocbaseaddress((unsigned int)&(HwGPIO_BASE));	

	//I2C Init
	tcc_vdec_initializei2c();

	BITCSET(pGPIO_Reg->GPEFN1, 0xFFFF0000, Hw28|Hw24|Hw20|Hw16);
	//CCKI, CVS, CHS, CCKO, CPD[7] - CPD[4]
	BITCSET(pGPIO_Reg->GPEFN2, 0xFFFFFFFF, Hw28|Hw24|Hw20|Hw16|Hw12|Hw8|Hw4|Hw0);
	BITCLR(pGPIO_Reg->GPEEN, 0x7FF000); // CPD Data bus as Input mode
	BITSET(pGPIO_Reg->GPEEN, 0x4800000); // CCKO output mode
	
	//Hw Reset
	tcc_vdec_hwreset(pGPIO_Reg);
	//CPD[0] - CPD[3]

	
	//TVP5150A Initialize
	tcc_vdec_initialize();

	#ifdef _VDEC_TEST_
		tcc_vdec_regcheck();
	#endif
	*/
	
    RETAILMSG(1, (TEXT("[VIDEO DEC   ]- DEC_Init()\n")));
	return 1;
}


/************************************************************************************************
* FUNCTION		: BOOL DEC_IOControl(HANDLE Handle,
*				  DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, 
*				  PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL DEC_IOControl(HANDLE Handle,
				  DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, 
				  PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
	switch(dwCode)
	{
		case IOCTL_MODULE_INIT:
			//RETAILMSG(1, (TEXT("::: Vidoe Decoder Initialize\r\n")));
			tcc_vdec_initialize();
			break;
			
		case IOCTL_MODULE_MODE:
			{
				{
					BOOL OnOff = (BOOL) *pBufIn;
					PCIF lCIF = (CIF *)tcc_allocbaseaddress((unsigned int)&(HwCIF_BASE));	
			
					//RETAILMSG(1, (TEXT("::: Vidoe Decoder %s\r\n"),OnOff?L"ON":L"OFF"));
					tcc_vdec_hwreset(pGPIO_Reg);
					tcc_vdec_initialize();
	#ifdef _VDEC_TEST_
					tcc_vdec_regcheck();
	#endif
				}
			}
			break;
	}
	return TRUE;
}


/************************************************************************************************
* FUNCTION		: BOOL DEC_Deinit(DWORD dwContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL DEC_Deinit(DWORD dwContext)
{
	RETAILMSG(1, (TEXT("[DEC_Deinit]\r\n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD DEC_Open(DWORD dwData, DWORD dwAccess, DWORD dwShareMode)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD DEC_Open(DWORD dwData, DWORD dwAccess, DWORD dwShareMode)
{
    RETAILMSG(1, (TEXT("[VIDEO DEC   ]+ DEC_Open()\n")));
	tcc_vdec_setcampwrctl(1);
	//I2C Init
	tcc_vdec_initializei2c();
	
    RETAILMSG(1, (TEXT("[VIDEO DEC   ]- DEC_Open()\n")));
	
	return 1;
}


/************************************************************************************************
* FUNCTION		: BOOL DEC_Close(DWORD Handle)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL DEC_Close(DWORD Handle)
{
	RETAILMSG(1, (TEXT("-DEC_Close\r\n")));
	tcc_vdec_setcampwrctl(0);
	tcc_vdec_deiniti2c();
	return TRUE;
}


/************************************************************************************************
* FUNCTION		: DWORD DEC_Read(DWORD Handle, DWORD *pBuffer, DWORD dwNumBytes)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD DEC_Read(DWORD Handle, DWORD *pBuffer, DWORD dwNumBytes)
{
	return 0;
}


/************************************************************************************************
* FUNCTION		: DWORD DEC_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD DEC_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes)
{
	return 0;
}


/************************************************************************************************
* FUNCTION		: DWORD DEC_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD DEC_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod)
{
	return 0;
}


/************************************************************************************************
* FUNCTION		: void DEC_PowerUp(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void DEC_PowerUp(void)
{
}


/************************************************************************************************
* FUNCTION		: void DEC_PowerDown(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void DEC_PowerDown(void)
{
}
