/****************************************************************************
*   FileName    : tcc_battdrv.c
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#include <windows.h>
#include <winuser.h>
#include <winuserm.h>
#include <ceddk.h>
#include <devload.h>
#include <winbase.h>
#include <nkintr.h>

#include "globals.h"
#include "ioctl_code.h"
#include "stubbattery.h"

/************************************************************************************************
*	DEFINES
************************************************************************************************/
#if DEBUG
#define ZONE_ERROR              DEBUGZONE(0)
#define ZONE_WARNING            DEBUGZONE(1)
#define ZONE_INIT               DEBUGZONE(2)
#define ZONE_FUNCTION           DEBUGZONE(3)

#define ZONE_COMMENT            DEBUGZONE(4)

DBGPARAM dpCurSettings = {
    _T("usbmsfn"),
    {
        _T("Error"), _T("Warning"), _T("Init"), _T("Function"),
        _T("Comments"), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""), 
        _T(""), _T(""), _T(""), _T("")
    },
    0x5
};


#endif

#define MUTEX_TIMEOUT 5000


// Battery Level
/*
#define VOLTAGE_MAX     4200
#define VOLTAGE_LOW     3600
#define VOLTAGE_MIN     3500
#define VOLTAGE_EMPTY   3300
*/

//    The Estimation Rate of Battery Voltage by ADC Value is about 185 ->  4.2V * 185 = 780
// 4.2V * 185 = 780
// 3.7V is limit Voltage of Working. Its ADC Value is 2446 avr(2418~2469, 51)
// 2446 = 3.75*652

#define ESTIMATE_RATE 660

#define MAXCAPACITY  2780
#define LOWLIMIT 2778 //(2600~2643, 43)
#define MINLIMIT 2628 // (2418~2469, 51)
#define EMPTLIMIT 2478 //
#define INTR 1

#define BATTVOLSAMPLE 8





/************************************************************************************************
* GLOBAL VARIABLES
************************************************************************************************/
HANDLE	hBatteryFileMutex;
HANDLE	hFileMap;
LPVOID	lpMemBlock;
BOOL	ThreadFlag; // Kill Thread or Not

HANDLE  ghBattADC;
HANDLE	ghStateUpdateEvent;
HANDLE	ghStateUpdateThread;

DWORD	gACInsSysIntr = SYSINTR_UNDEFINED;
DWORD   gAvrVoltage[8];
DWORD   gIndex = 0;



/************************************************************************************************
*   LOCAL FUNCTIONS
*
************************************************************************************************/
DWORD	BATT_PowerSrcIntrInitialize(void);
BOOL BATT_PowerSrcInterrupt(DWORD dwMode);
DWORD	BATT_GetStatus(void);
DWORD	BATT_GetVoltage(void);
void	BATT_UpdateStatus( BATTERY_STATUS* pstBattStatus );
DWORD BATT_StateUpdateThread(void *pParam);
DWORD BATT_SendDatatoPMIC( BYTE SubAddr, BYTE Buffer);
BYTE BATT_ReadDatafromPMIC(BYTE SubAddr);
void  BATT_PMICInitialize(void);
DWORD BATT_PMICWhichInterrupt(void);


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
HKEY	OpenRegistryKey( LPTSTR	ActiveKey )
{
	TCHAR	DevKey[256];
	HKEY	hDevKey;
	HKEY	hActive;
	DWORD	State;
	DWORD	ValueLength;
	DWORD	ValueType;
	
	State = RegOpenKeyEx(HKEY_LOCAL_MACHINE, ActiveKey, 0, 0, &hActive);
	
	if(State)
		return NULL;
		
	hDevKey = NULL;
	
	ValueLength = sizeof(DevKey);
	State = RegQueryValueEx(hActive, DEVLOAD_DEVKEY_VALNAME, NULL,&ValueType, (PUCHAR)DevKey, &ValueLength);
	
	if(State)
		return NULL ; // Fail
		
	State = RegOpenKeyEx(HKEY_LOCAL_MACHINE, DevKey,0,0,&hDevKey);
	
	if(State)
	{
		hDevKey = NULL;
		return NULL; // Fail
	}
	
	return hDevKey;
	
	
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL OpenMemSegment(void)
{
	ASSERT(hFileMap == NULL);
	ASSERT(lpMemBlock == NULL);
	hFileMap = CreateFileMapping((HANDLE)INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, 
									sizeof(BATTERY_STATUS), BATTERY_STATUS_FILE);
	if(hFileMap == NULL) {
		RETAILMSG(1, (TEXT("Could not create file mapping for battery info file\r\n")));
		return FALSE;
	}

	lpMemBlock = MapViewOfFile(hFileMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(BATTERY_STATUS));
	if(NULL == lpMemBlock){
		RETAILMSG(1, (_T("Can't map view of memory mapped file\r\n")));
		CloseHandle(hFileMap);
		hFileMap = NULL;
		return FALSE;
	}
	return TRUE;
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void CloseSegment(void)
{
	if(lpMemBlock)
	{
		UnmapViewOfFile(lpMemBlock);
		lpMemBlock = NULL;
	}
	if(hFileMap){
		CloseHandle(hFileMap);
		hFileMap=NULL;
	}
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD	BATT_AcquireMutex(void)
{
	DWORD dwMutexResult = WaitForSingleObject(hBatteryFileMutex, MUTEX_TIMEOUT);
	return dwMutexResult;
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD	BATT_ReleaseMutex(void)
{
	DWORD dwMutexResult = ReleaseMutex(hBatteryFileMutex);
	return dwMutexResult;
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL SetBatteryState(PBATTERY_STATUS pstatus)
{
	DWORD dwMutexState = 0;
	dwMutexState = BATT_AcquireMutex();
	if(dwMutexState == WAIT_OBJECT_0)
	{
		memcpy(lpMemBlock, (VOID*)pstatus, sizeof(BATTERY_STATUS));
		dwMutexState = BATT_ReleaseMutex();
		return TRUE;
	}
	else
		return FALSE; // Fail	
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL GetBatteryState(PBATTERY_STATUS pstatus)
{
	DWORD dwMutexState = 0;
	dwMutexState = BATT_AcquireMutex();
	if(dwMutexState == WAIT_OBJECT_0)
	{
		memcpy((VOID*)pstatus,(PBATTERY_STATUS)lpMemBlock, sizeof(BATTERY_STATUS));
		dwMutexState = BATT_ReleaseMutex();
		return TRUE;
	}
	else
		return FALSE; // Fail	
}





/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD	BATT_PowerSrcIntrInitialize(void)
{
	return 0;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL BATT_PowerSrcInterrupt(DWORD dwMode)
{
	return TRUE;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD	BATT_GetStatus(void)
{
	DWORD	ResultVal = 0;
#if 0
	// Return Condition is that Battery is connected , charged or in another conditions
#endif

	return ResultVal;
	
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD	BATT_GetVoltage(void)
{
    DWORD	ResultVal = 0;

    BATT_SendDatatoPMIC(0xFF, 0xFF); // Measurement Bridge Setting for Getting Battery Voltage
    BATT_ReadDatafromPMIC(0xFF);
    DeviceIoControl(ghBattADC, IOCTL_TSADC_CHANNEL1, NULL, 0, &ResultVal, sizeof(ResultVal), NULL, NULL);

    return ResultVal;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void	BATT_UpdateStatus( BATTERY_STATUS* pstBattStatus )
{
    DWORD	BattVoltage = 0, adcValue = 0;
    int i;

    if(pstBattStatus->sps.ACLineStatus == AC_LINE_OFFLINE)
    {
        // Getting Main Battery Information

        for (i=0; i<8; i++)
            adcValue += gAvrVoltage[i];
            
        BattVoltage = adcValue/BATTVOLSAMPLE;
        //RETAILMSG(1, (TEXT("BAT = %d\r\n"), BattVoltage));

        if( LOWLIMIT < BattVoltage)
            pstBattStatus->sps.BatteryFlag = BATTERY_FLAG_HIGH;
        else if( MINLIMIT < BattVoltage && BattVoltage < LOWLIMIT )
            pstBattStatus->sps.BatteryFlag = BATTERY_FLAG_LOW;
        else if( EMPTLIMIT < BattVoltage && BattVoltage < MINLIMIT )
            pstBattStatus->sps.BatteryFlag = BATTERY_FLAG_CRITICAL;
        else
            pstBattStatus->sps.BatteryFlag = BATTERY_FLAG_UNKNOWN;

        pstBattStatus->sps.BatteryLifePercent = (BYTE)(100 - ( ( MAXCAPACITY -BattVoltage)*100)/(MAXCAPACITY- EMPTLIMIT) ); // 0~ 100 in the range
        pstBattStatus->sps.BatteryVoltage = (BattVoltage * 1000) /ESTIMATE_RATE; // mV
        //RETAILMSG(1, (TEXT("BATT Voltage = %d\r\n"), pstBattStatus->sps.BatteryVoltage ));

    }
    else if (pstBattStatus->sps.ACLineStatus == AC_LINE_ONLINE)
    {
        pstBattStatus->sps.BatteryFlag = BATTERY_FLAG_HIGH;
        pstBattStatus->sps.BatteryLifePercent = 100; // 0~ 100 in the range
        pstBattStatus->sps.BatteryVoltage = 3800; // mV
    }

    // Getting Backup Battery Information
    pstBattStatus->sps.BackupBatteryFlag = BATTERY_FLAG_HIGH;
    pstBattStatus->sps.BackupBatteryLifePercent = 100; //BATTERY_LIFE_UNKNOWN; // Percent
    pstBattStatus->sps.BackupBatteryLifeTime = 365*24*60*60;//BATTERY_LIFE_UNKNOWN ; //Seconds
    pstBattStatus->sps.BackupBatteryFullLifeTime = 10*365*24*60*60;//BATTERY_LIFE_UNKNOWN ; // Seconds
    pstBattStatus->sps.BackupBatteryVoltage = 3000;//BATTERY_FLAG_UNKNOWN;//mV

    pstBattStatus->sps.BatteryLifeTime = BATTERY_LIFE_UNKNOWN ; // Seconds
    pstBattStatus->sps.BatteryFullLifeTime = BATTERY_LIFE_UNKNOWN ; // Seconds

    pstBattStatus->sps.BatteryCurrent = 500;// PMIC Max Output Current, temporary //mA
    pstBattStatus->sps.BatteryAverageCurrent = 300; //mA
    pstBattStatus->sps.BatteryAverageInterval = 2000;//ms

    pstBattStatus->sps.BatterymAHourConsumed = 1500;//mAH

    pstBattStatus->sps.BatteryTemperature = 32;// Degrees in Celsius
    pstBattStatus->sps.BatteryChemistry = BATTERY_CHEMISTRY_LION;
}



DWORD   BATT_GetBatteryVoltageSample(void)
{
    DWORD   adcValue;
    adcValue= BATT_GetVoltage();

    // If invalid value is read, Get value again
    if( MAXCAPACITY < adcValue || adcValue < EMPTLIMIT)
    {
        adcValue= BATT_GetVoltage();
    }

    // Find Max Average Voltage
    gAvrVoltage[gIndex++%BATTVOLSAMPLE] = adcValue;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD BATT_StateUpdateThread(void *pParam)
{
	BATTERY_STATUS	stBattStatus;
       DWORD CurrPmicIntr = 0;

	while(ThreadFlag)
	{
		Sleep(500); // 500ms
		BATT_GetBatteryVoltageSample();

		if( gIndex%BATTVOLSAMPLE == 0)
		{
        	    GetBatteryState(&stBattStatus);	
        	    BATT_UpdateStatus(&stBattStatus);
        	    SetBatteryState(&stBattStatus);
        	}
		//RETAILMSG(1, (_T("BATT Check\r\n")));
	}

	return 0;

}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD BATT_SendDatatoPMIC( BYTE SubAddr, BYTE Buffer)
{
	BOOL Ret = TRUE;
    
	if(Ret)
		return TRUE;
	else
		return FALSE;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BYTE BATT_ReadDatafromPMIC(BYTE SubAddr)
{
	BYTE Ret = 0;

	if(SubAddr)
	{
	    Ret = SubAddr;
	    return Ret;
	}
	else
		return 0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void  BATT_PMICInitialize(void)
{
        BYTE  regdata = 0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD BATT_PMICWhichInterrupt(void)
{
	DWORD AllIntrState = 0;
	DWORD EachIntrState =0;
        return AllIntrState;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL BAT_Init(LPCTSTR	pszContext, LPCVOID pBusContext)
{
    BATTERY_STATUS stBattStatus;
    DWORD ThreadID1;
    BYTE     regdata;

    RETAILMSG(1, (_T("[BATTERY     ]+BATT INIT\r\n")));

    hBatteryFileMutex = CreateMutex(NULL, FALSE, BATTERY_FILE_MUTEX);
    
    if(hBatteryFileMutex == NULL)
        return FALSE; // Mutex Creation Fail
    
    if(!OpenMemSegment())
        return FALSE; // Segment init fail


    // Open ADC Driver handle
    ghBattADC = CreateFile(L"ADC1:", GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);

    if(!ghBattADC)
        RETAILMSG(TRUE,(TEXT("[BATTERY     ]:ERROR:Can't open ADC Driver!!\n")));

    GetBatteryState(&stBattStatus);
    
    // Read ChargeStatus Reg to confirm whether power src is Battery or AC Line.
    regdata = BATT_ReadDatafromPMIC(0x00); 
    
    if( regdata&0x1)    // AC Powered or USB Line Powered
        stBattStatus.sps.ACLineStatus = AC_LINE_ONLINE;
    else    // Battery Powered
        stBattStatus.sps.ACLineStatus = AC_LINE_OFFLINE;
    
    BATT_UpdateStatus(&stBattStatus);
    
    SetBatteryState(&stBattStatus);
    
    // Create PowerSrc Detect Thread
    ghStateUpdateThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) BATT_StateUpdateThread, NULL, 0, &ThreadID1);
    ThreadFlag = TRUE;
    
    RETAILMSG(1, (_T("[BATTERY     ]-BATT INIT\r\n")));
    
    return TRUE;
	
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL BAT_Deinit(DWORD context)
{
	if(ghStateUpdateThread != NULL )
		CloseHandle(ghStateUpdateThread);
	
	if(hBatteryFileMutex != NULL)
		CloseHandle(hBatteryFileMutex);

	CloseSegment();
	
	return TRUE;
}




/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD BAT_Open(DWORD context, DWORD accessCode, DWORD shareMode)
{
	DWORD rc = (DWORD)NULL;
	return rc;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL BAT_Close(DWORD context)
{
	BOOL rc = TRUE;
	return rc;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD BAT_Read(DWORD context, PVOID pBuffer, DWORD count)
{
	DWORD rc = 0;
	return rc;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD BAT_Write(DWORD context, PVOID pBuffer, DWORD count)
{
	DWORD rc = 0;
	return rc;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
DWORD BAT_Seek(DWORD context, LONG amount, WORD type)
{
	DWORD rc = 0;
	return rc;
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL BAT_IOControl(
	DWORD context, DWORD code, BYTE *pInBuffer, DWORD inSize, BYTE *pOutBuffer,
	DWORD outSize, DWORD *pOutSize
) {
	BOOL rc = FALSE;

	DEBUGMSG(ZONE_FUNCTION, (
		L"+BAT_IOControl(0x%08x, 0x%08x, 0x%08x, %d, 0x%08x, %d, 0x%08x)\r\n", 
		context, code, pInBuffer, inSize, pOutBuffer, outSize, pOutSize
	));

	DEBUGMSG (ZONE_FUNCTION, (L"-BAT_IOControl(rc = %d)\r\n", rc));
	return rc;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void BAT_PowerUp(DWORD context)
{

}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void BAT_PowerDown(DWORD context)
{

}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
BOOL DllEntry(HANDLE hDLL, DWORD reason, VOID *pReserved)
{
    UNREFERENCED_PARAMETER(hDLL);
    UNREFERENCED_PARAMETER(pReserved);

	switch (reason) {
	case DLL_PROCESS_ATTACH:
		DEBUGREGISTER((HMODULE)hDLL);
		DisableThreadLibraryCalls((HMODULE)hDLL);
		break;
	case DLL_PROCESS_DETACH:
		
		break;
	}
	return TRUE;
}
