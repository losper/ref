/*=====================================================================================
*
* @File Name	: SDHCLIB.CPP
*
* @File Version	: SIGBYAHONG_SDHCLIB_WINCE6_TCCXXXX_V2000
*
=====================================================================================*/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//

// Copyright (c) 2002 BSQUARE Corporation.  All rights reserved.
// DO NOT REMOVE --- BEGIN EXTERNALLY DEVELOPED SOURCE CODE ID 40973--- DO NOT REMOVE

#include <SDHCD.h>

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

static SDHOST_API_FUNCTIONS g_SDHostFuncs;


// Call to get the host controller function table
SD_API_STATUS SDHCDGetHCFunctions(PSDHOST_API_FUNCTIONS);


// SDHCDInitializeHCLib - Initialize the host controller library
//
// Return: SD_API_STATUS 
// Notes: Call from DLL entry
//
SD_API_STATUS SDHCDInitializeHCLib()
{
#ifdef DEBUG
    memset(&g_SDHostFuncs, 0xCC, sizeof(g_SDHostFuncs));
#endif

    g_SDHostFuncs.dwSize = sizeof(g_SDHostFuncs);
    SD_API_STATUS status = SDHCDGetHCFunctions(&g_SDHostFuncs);

    if (SD_API_SUCCESS(status)) {
        DEBUGCHK(g_SDHostFuncs.pAllocateContext);
        DEBUGCHK(g_SDHostFuncs.pDeleteContext);
        DEBUGCHK(g_SDHostFuncs.pRegisterHostController);
        DEBUGCHK(g_SDHostFuncs.pDeregisterHostController);
        DEBUGCHK(g_SDHostFuncs.pIndicateSlotStateChange);
        DEBUGCHK(g_SDHostFuncs.pIndicateBusRequestComplete);
        DEBUGCHK(g_SDHostFuncs.pUnlockRequest);
        DEBUGCHK(g_SDHostFuncs.pGetAndLockCurrentRequest);
        DEBUGCHK(g_SDHostFuncs.pPowerUpDown);
    }
    else {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDHCDInitializeHCLib: Failed to get HC functions\n")));
    }

    return status;
}


// SDHCDDeinitializeHCLib - Deinitialize the host controller library
//
// Return: SD_API_STATUS 
// Notes: Call from DLL entry
//
SD_API_STATUS SDHCDDeinitializeHCLib()
{
    return SD_API_STATUS_SUCCESS;
}


// SDHCDAllocateContext - Allocate an HCD Context
//
// Input: NumberOfSlots - Number of slots
// Output:
//        ppHostContext - caller supplied storage for the host context
// Return: SD_API_STATUS 
// Notes:
//
SD_API_STATUS SDHCDAllocateContext(
    DWORD               cSlots,
    PSDCARD_HC_CONTEXT *ppHostContext
    ) 
{
    // If this DEBUGCHK fires, verify that your DLL entry point is 
    // set to the proper routine name (DllMain versus DllEntry, etc.).
    // Then step through your DLL entry point and verify that it is
    // calling SDHCDInitializeHCLib().
    PREFAST_DEBUGCHK(g_SDHostFuncs.pAllocateContext);
    
    SD_API_STATUS status = g_SDHostFuncs.pAllocateContext(cSlots, ppHostContext);

    if (*ppHostContext) {
        SDHCDSetVersion(*ppHostContext);
    }
    
    return status;
}

// SDHCDDeleteContext - Delete an HCD context
//
// Input: pHCContext - Host Context to delete
// Output:
// Return:
//
VOID SDHCDDeleteContext(PSDCARD_HC_CONTEXT pHCContext)
{
    PREFAST_DEBUGCHK(g_SDHostFuncs.pDeleteContext);
    g_SDHostFuncs.pDeleteContext(pHCContext);
}


// SDHCDRegisterHostController - Register a host controller with the bus driver
//
// Input: pHCContext - Allocated Host controller context
//
// Output:
// Return: SD_API_STATUS 
// Notes:      
//      the caller must allocate a host controller context and 
//      initialize the various parameters
SD_API_STATUS SDHCDRegisterHostController(PSDCARD_HC_CONTEXT pHCContext)
{
    PREFAST_DEBUGCHK(g_SDHostFuncs.pRegisterHostController);
    return g_SDHostFuncs.pRegisterHostController(pHCContext);
}


// SDHCDDeregisterHostController - Deregister a host controller 
//
// Input: pHCContext - Host controller context that was previously registered
//        
// Output:
// Return: SD_API_STATUS 
// Notes:       
//      A host controller must call this api before deleting the HC context
//      
// returns SD_API_STATUS
SD_API_STATUS SDHCDDeregisterHostController(PSDCARD_HC_CONTEXT pHCContext)
{
    PREFAST_DEBUGCHK(g_SDHostFuncs.pDeregisterHostController);
    return g_SDHostFuncs.pDeregisterHostController(pHCContext);
}


// SDHCDIndicateSlotStateChange - indicate a change in the SD Slot 
//
// Input: pHCContext - Host controller context that was previously registered
//        SlotNumber - Slot Number
//        Event     - new event code
// Output:
// Return:
// Notes:        
//      A host controller driver calls this api when the slot changes state (i.e.
//      device insertion/deletion).
//      
// 
VOID SDHCDIndicateSlotStateChange(PSDCARD_HC_CONTEXT pHCContext, 
    DWORD              SlotNumber,
    SD_SLOT_EVENT      Event)
{
    PREFAST_DEBUGCHK(g_SDHostFuncs.pIndicateSlotStateChange);
    g_SDHostFuncs.pIndicateSlotStateChange(pHCContext, SlotNumber, Event);
}


// SDHCDIndicateBusRequestComplete - indicate to the bus driver that
//                                   the request is complete
//
// Input: pHCContext - host controller context
//        pRequest   - the request to indicate
//        Status     - the ending status of the request
// Output:
// Return: 
// Notes:       
//     
VOID SDHCDIndicateBusRequestComplete(PSDCARD_HC_CONTEXT pHCContext,
    PSD_BUS_REQUEST    pRequest,
    SD_API_STATUS      Status)
{
    PREFAST_DEBUGCHK(g_SDHostFuncs.pIndicateBusRequestComplete);
    g_SDHostFuncs.pIndicateBusRequestComplete(pHCContext, pRequest, Status);
}


// SDHCDUnlockRequest - Unlock a request that was previous locked
//                             
// Input:   pHCContext - host controller context   
//          pRequest  - the request to lock
// Output:
// Return:    
// Notes:   This function unlocks the request that was returned from the
//          function SDHCDGetAndLockCurrentRequest()
//          
//          This request can now be cancelled from any thread context
VOID SDHCDUnlockRequest(PSDCARD_HC_CONTEXT  pHCContext,
    PSD_BUS_REQUEST     pRequest)
{
    PREFAST_DEBUGCHK(g_SDHostFuncs.pUnlockRequest);
    g_SDHostFuncs.pUnlockRequest(pHCContext, pRequest);
}


// SDHCDGetAndLockCurrentRequest - get the current request in the host controller
//                                 slot and lock it to keep it from being cancelable
// Input:   pHCContext - host controller context   
//          SlotIndex  - the slot number 
// Output:
// Return: current bus request  
// Notes:
//          This function retrieves the current request and marks the
//          request as NON-cancelable.  To return the request back to the
//          cancelable state the caller must call SDHCDUnlockRequest()     
//          This function returns the current request which can be NULL if 
//          the request was previously marked cancelable and the host controller's
//          cancelIo Handler completed the request 
PSD_BUS_REQUEST SDHCDGetAndLockCurrentRequest(PSDCARD_HC_CONTEXT pHCContext, 
    DWORD              SlotIndex)
{
    PREFAST_DEBUGCHK(g_SDHostFuncs.pGetAndLockCurrentRequest);
    return g_SDHostFuncs.pGetAndLockCurrentRequest(pHCContext, SlotIndex);
}


// SDHCDPowerUpDown - Indicate a power up/down event
//                             
// Input:   pHCContext - host controller context   
//          PowerUp    - set to TRUE if powering up
//          SlotKeepPower - set to TRUE if the slot maintains power to the
//                          slot during power down
// Output:
// Return:        
// Notes:   This function notifies the bus driver of a power up/down event.
//          The host controller driver can indicate to the bus driver that power
//          can be maintained for the slot.  If power is removed, the bus driver
//          will unload the device driver on the next power up event.
//          This function can only be called from the host controller's XXX_PowerOn
//          and XXX_PowerOff function.
VOID SDHCDPowerUpDown(PSDCARD_HC_CONTEXT  pHCContext, 
    BOOL                PowerUp, 
    BOOL                SlotKeepPower,
    DWORD               SlotIndex)
{
    PREFAST_DEBUGCHK(g_SDHostFuncs.pPowerUpDown);
    g_SDHostFuncs.pPowerUpDown(pHCContext, PowerUp, SlotKeepPower, SlotIndex);
}


#ifdef __cplusplus
}
#endif //__cplusplus

// DO NOT REMOVE --- END EXTERNALLY DEVELOPED SOURCE CODE ID --- DO NOT REMOVE

