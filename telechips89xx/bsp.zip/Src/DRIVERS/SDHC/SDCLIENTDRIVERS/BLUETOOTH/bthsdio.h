//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//
#define BT_USE_CELOG    1


#ifndef __BTHSDIO_H__
#define __BTHSDIO_H__

#include <SDCardDDK.h>
#include <bt_hcip.h>

#include <svsutil.hxx>

#include <bt_buffer.h>
#include <bt_os.h>
#include <bt_debug.h>

#include <bt_tdbg.h>

#include <pm.h>

#define SDIO_HEADER_SIZE            4
#define PACKET_SIZE_R               65536
#define PACKET_SIZE_W               65536

enum {
    DETACHED,
    ATTACHED,
    SHUTDOWN_IN_PROGRESS
};


typedef struct _SD_TRANSPORT_HEADER {
    union {
        struct {
            UCHAR   PacketLength[3];
            UCHAR   ServiceID;
        } AsUCHAR;
        ULONG   AsULONG;
    } u;
} SD_TRANSPORT_HEADER, *PSD_TRANSPORT_HEADER;


class CSdioDevice {
public:
    CSdioDevice();
    ~CSdioDevice();

    BOOL Init(void);
    BOOL Attach(DWORD dwContext);
    void Detach(void);
    BOOL OpenConnection(void);
    void CloseConnection(void);
    BOOL ReadPacket(unsigned char* pBuffer, unsigned int* pcbBuffer, BYTE* pbType);
    BOOL WritePacket(unsigned char* pBuffer, int cbBuffer);
 
    inline BOOL IsAttached(void)
    {
        return (m_dwState == ATTACHED);
    }

    static SD_API_STATUS SDIOIsrCallBack(SD_DEVICE_HANDLE hDevice, PVOID pContext);
    SD_API_STATUS SDIOIsrCallback_Int(void);
    static void CSdioDevice::SignalRefCountZero(void *pv);
    void CSdioDevice::SignalRefCountZero_Int(void);

    DWORD IOControl(DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, 
        DWORD dwLenOut, PDWORD pdwActualOut);

private:
            
    SD_API_STATUS SDSend(unsigned char* pBuffer, unsigned int cbBuffer);
    SD_API_STATUS SDRecv(unsigned char* pBuffer, unsigned int* pcbBuffer);
    BOOL InitializeBTRegisters(void);
    BOOL GetBTCardType(void);
    BOOL GetMaxBlockLen(void);

    inline SD_API_STATUS CSdioDevice::SDGetRegister(BYTE bRegister, UCHAR ucFunction, unsigned char* pucRegValue, int iLen)
    {
        return SDReadWriteRegistersDirect(m_hDevice, SD_IO_READ, ucFunction, bRegister, FALSE, pucRegValue, iLen);
    }
    inline SD_API_STATUS CSdioDevice::SDSetRegister(BYTE bRegister, UCHAR ucFunction, unsigned char* pucRegValue, int iLen)
    {
        return SDReadWriteRegistersDirect(m_hDevice, SD_IO_WRITE, ucFunction, bRegister, FALSE, pucRegValue, iLen);
    }


    SVSSignallingRefObj m_refIO;
    SD_DEVICE_HANDLE m_hDevice;
    PWSTR m_pRegPath;
    UCHAR m_ucFunction;
    USHORT m_usBlockLen;
    USHORT m_usBTCardType;
    DWORD m_dwState;
    HANDLE m_hReadPacketEvent;
    HANDLE m_hIOStoppedEvent;
    HANDLE m_hBusAccess;
    CEDEVICE_POWER_STATE m_cpsCurrent;
    HANDLE m_hRecvCompleteEvent;

    BOOL m_fInterruptConnected : 1;
    BOOL m_fBlockMode : 1;
    BOOL m_fCancelIO : 1;
    BOOL m_fGoTo4BitModeOnResume : 1;
    
};


typedef struct _SDIO_GLOBALS {
    HCI_TransportCallback pfnHCICallback;
    BOOL fCeLog;
    BOOL fStopHardware;
} SDIO_GLOBALS;


extern SDIO_GLOBALS	g_Data;
extern CSdioDevice*	g_pSdioDevice;

#endif

