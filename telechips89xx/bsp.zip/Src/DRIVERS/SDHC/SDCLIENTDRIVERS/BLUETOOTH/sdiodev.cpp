/*=====================================================================================
*
* @File Name	: SDIODEV.CPP
*
* @File Version	: SIGBYAHONG_SDIODEV_WINCE6_TCCXXXX_V2000
*
=====================================================================================*/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//
#include "bthsdio.h"

#ifdef DEBUG

// Need this for sdcard modules
DBGPARAM dpCurSettings = {
    _T("BTHSDIO"), 
    {
        _T(""), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T("") 
    },
    0x0 
};

#endif


/*

This function is called by the SDHC when the BT device is inserted.

*/
extern "C" DWORD BSD_Init(DWORD dwContext)
{
    BOOL fRetVal = TRUE;

    // Only support one device
    if (g_pSdioDevice->IsAttached()) {
        fRetVal = FALSE;
        goto exit;
    }
    
    if (! g_pSdioDevice->Attach(dwContext)) {
        fRetVal = FALSE;
        goto exit;
    }
    
exit:    
    DWORD dwRet;
    if (fRetVal) {
        dwRet = (DWORD) g_pSdioDevice;
    }
    else {
        dwRet = 0;
    }
    
    return dwRet;
}


/*

This function is called by the SDHC when the BT device is ejected.

*/
extern "C" BOOL BSD_Deinit(DWORD hDeviceContext)
{
    g_pSdioDevice->Detach();
    return TRUE;
}

extern "C" DWORD BSD_Open(DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode)
{
    return hDeviceContext;
}

extern "C" BOOL BSD_Close(DWORD hOpenContext)
{
    return TRUE;
}

extern "C" BOOL BSD_IOControl(DWORD hOpenContext, DWORD dwCode, 
    PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
    CSdioDevice *pSdioDevice = (CSdioDevice*) hOpenContext; 
    DEBUGCHK(pSdioDevice == g_pSdioDevice);

    DWORD dwErr = pSdioDevice->IOControl(dwCode, pBufIn, dwLenIn, pBufOut, dwLenOut, pdwActualOut);
    if (dwErr != ERROR_SUCCESS) {
        SetLastError(dwErr);
    }
    
    return (dwErr == ERROR_SUCCESS);
}



