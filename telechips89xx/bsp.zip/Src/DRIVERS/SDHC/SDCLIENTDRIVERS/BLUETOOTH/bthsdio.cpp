/*=====================================================================================
*
* @File Name	: BTHSDIO.CPP
*
* @File Version	: SIGBYAHONG_BTHSDIO_WINCE6_TCCXXXX_V2000
*
=====================================================================================*/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//
#include "bthsdio.h"
#include <ceddk.h>


// Bluetooth SDIO registers
#define REG_DATAPORT            0x00        // Send/Recv data
#define REG_PCRRT               0x10        // Read Packet Control
#define REG_PCWRT               0x11        // Write Packet Control
#define REG_RTC                 0x12        // Retry Control
#define REG_INTRD               0x13        // Interrupt
#define REG_ENINTRD             0x14        // Interrupt Enable
#define REG_MDSTAT              0x20        // Bluetooth Mode Status

// SDIO registers
#define REG_CCCR_CARD_CAP       0x08

// BT card types
#define BT_CARD_TYPE_A          0x02
#define BT_CARD_TYPE_B          0x03

// Constants
#define DEFAULT_HOST_BLOCK_SIZE             512
#define DEFAULT_HOST_NUM_BLOCKS             8
#define DEFAULT_SDIO_FUNCTION_RETRIES       5
#define DEFAULT_SDIO_FUNCTION_RETRY_TIMEOUT 1000


CSdioDevice::CSdioDevice()
{
    m_hDevice = 0;
    m_dwState = DETACHED;
    m_ucFunction = 0;
    m_fInterruptConnected = FALSE;
    m_pRegPath = NULL;
    m_hReadPacketEvent = NULL;
    m_hIOStoppedEvent = NULL;
    m_hRecvCompleteEvent = NULL;
    m_usBlockLen = 0;
    m_usBTCardType = 0;
    m_fBlockMode = FALSE;
    m_fCancelIO = FALSE;
    m_hBusAccess = NULL;
    m_cpsCurrent = D0;
    m_fGoTo4BitModeOnResume = FALSE;

    // SVSRefObj always starts at 1.  For our purposes, we want
    // it to initially be 0
    ASSERT(m_refIO.GetRefCount() == 1);
    m_refIO.SetSignal(SignalRefCountZero, (PVOID)this);
    m_refIO.DelRef();
}

CSdioDevice::~CSdioDevice()
{
    if (m_hReadPacketEvent) {
        CloseHandle(m_hReadPacketEvent);
    }
    if (m_hIOStoppedEvent) {
        CloseHandle(m_hIOStoppedEvent);
    }
    if (m_hRecvCompleteEvent) {
    	CloseHandle(m_hRecvCompleteEvent);
    }
}


/*

This method is called to initialize the object.

*/
BOOL CSdioDevice::Init(void)
{
    BOOL fRetVal = TRUE;
    
    if (! m_hReadPacketEvent) {
        m_hReadPacketEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
        if (NULL == m_hReadPacketEvent) {
            ASSERT(0);
            fRetVal = FALSE;
            goto exit;
        }
    }
    if (! m_hIOStoppedEvent) {
        m_hIOStoppedEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
        if (NULL == m_hIOStoppedEvent) {
            ASSERT(0);
            fRetVal = FALSE;
            goto exit;
        }
    }
    if (! m_hRecvCompleteEvent) {
        m_hRecvCompleteEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
        if (NULL == m_hRecvCompleteEvent) {
            ASSERT(0);
            fRetVal = FALSE;
            goto exit;
        }
    }

exit:
    return fRetVal;
}


/*

This method is called when a card is inserted into the host controller.  This method will
initialize the SDIO card.

*/
BOOL CSdioDevice::Attach(DWORD dwContext)
{
    BOOL fRetVal = TRUE;
    SDCARD_CLIENT_REGISTRATION_INFO clientInfo;
    SD_IO_FUNCTION_ENABLE_INFO functionEnable;
    SDIO_CARD_INFO sdioInfo;

    Init();

    m_hDevice = SDGetDeviceHandle(dwContext, &m_pRegPath);
    if (NULL == m_hDevice) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    SDRegisterDebugZones(m_hDevice, m_pRegPath);
    
    memset(&clientInfo, 0, sizeof(clientInfo));
    wcscpy(clientInfo.ClientName, TEXT("Bluetooth Card"));

    if (! SD_API_SUCCESS(SDRegisterClient(m_hDevice, this, &clientInfo))) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    if (! SD_API_SUCCESS(SDIOConnectInterrupt(m_hDevice, SDIOIsrCallBack))) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    m_hBusAccess = CreateBusAccessHandle((LPCTSTR) dwContext);

    m_fInterruptConnected = TRUE;

    functionEnable.Interval = DEFAULT_SDIO_FUNCTION_RETRY_TIMEOUT;
    functionEnable.ReadyRetryCount = DEFAULT_SDIO_FUNCTION_RETRIES;

    if (! SD_API_SUCCESS(SDSetCardFeature(m_hDevice, SD_IO_FUNCTION_ENABLE, &functionEnable, sizeof(functionEnable)))) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    if (! SD_API_SUCCESS(SDCardInfoQuery(m_hDevice, SD_INFO_SDIO, &sdioInfo, sizeof(sdioInfo)))) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    m_ucFunction = sdioInfo.FunctionNumber;
    
    m_dwState = ATTACHED;

exit:

    if (m_dwState != ATTACHED) {
        Detach();
    }
    else if(g_Data.pfnHCICallback && !g_Data.fStopHardware) {
        g_Data.pfnHCICallback(DEVICE_UP, NULL);
    }

    return fRetVal;
}


/*

This method is called when the card is ejected from the host controller.  Anything that
was initialized in Attach() must be deinitialized.

*/
void CSdioDevice::Detach(void)
{
    if ((m_dwState == ATTACHED) && g_Data.pfnHCICallback && !g_Data.fStopHardware) {
        g_Data.pfnHCICallback(DEVICE_DOWN, NULL);
    }

    m_dwState = SHUTDOWN_IN_PROGRESS;

    // Signal IO to stop.  Detach() must wait until IO
    // has completed to return.
    SetEvent(m_hReadPacketEvent);
    WaitForSingleObject(m_hIOStoppedEvent, INFINITE);

    if (m_hBusAccess) {
        CloseBusAccessHandle(m_hBusAccess);
        m_hBusAccess = NULL;
    }

    if (m_fInterruptConnected) {
        SDIODisconnectInterrupt(m_hDevice);
        m_fInterruptConnected = FALSE;
    }

    if (m_pRegPath) {
        SDFreeMemory(m_pRegPath);
        m_pRegPath = NULL;
    }

    m_dwState = DETACHED;
}


/*

This is a static method which just calls a method on the object passed in pv.

*/
void CSdioDevice::SignalRefCountZero(void *pv)
{
    CSdioDevice* pInst = (CSdioDevice*)pv;
    pInst->SignalRefCountZero_Int();
}


/*

This method is called when m_refIO becomes zero.  If a detach is in progress
this should signal that all IO has completed.  At this point no new IO will begin
since m_dwState will equal SHUTDOWN_IN_PROGRESS.

*/
void CSdioDevice::SignalRefCountZero_Int(void)
{
    if ((m_dwState == SHUTDOWN_IN_PROGRESS) || m_fCancelIO) {
        IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] CSdioDevice::SignalRefCountZero - IO completed, detach can proceed.\n"));
        SetEvent(m_hIOStoppedEvent);
    }
}


/*

This method initializes Bluetooth card in preparation for read/write.

*/
BOOL CSdioDevice::OpenConnection(void)
{
    BOOL fRetVal = TRUE;
    UCHAR ucRegVal;
    
    m_refIO.AddRef();

    m_fCancelIO = FALSE; // reset

    if (m_dwState != ATTACHED) {
        IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] CSdioDevice::OpenConnection - currently not attached, aborting.\n"));    
        fRetVal = FALSE;
        goto exit;
    }

    if (! GetMaxBlockLen()) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    // Is block mode supported?
    if (! SD_API_SUCCESS(SDGetRegister(REG_CCCR_CARD_CAP, 0, &ucRegVal, 1))) {
        fRetVal = FALSE;
        goto exit;
    }

    m_fBlockMode = (ucRegVal & 0x2) >> 1; // SMB is bit 1

    IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] Block Mode: %d  Max Block Size: %d\n", m_fBlockMode, m_usBlockLen));

    if (! InitializeBTRegisters()) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }    

exit:

    m_refIO.DelRef();

    if (! fRetVal) {
        CloseConnection();
    }

    return fRetVal;
}


/*

This method cleans up anything required from OpenConnection.

*/
void CSdioDevice::CloseConnection(void)
{
    m_fCancelIO = TRUE;
    if (m_refIO.GetRefCount()) {
        // Signal IO to stop
        SetEvent(m_hReadPacketEvent);
    }
}


/*

This method waits for an event to be signalled which indicates a packet is ready.  It reads the packet
header followed by the rest of the packet.

*/
BOOL CSdioDevice::ReadPacket(unsigned char* pBuffer, unsigned int* pcbBuffer, BYTE* pbType)
{
    BOOL fRetVal = TRUE;
    unsigned int cHeader = SDIO_HEADER_SIZE;
    SD_TRANSPORT_HEADER header;
    UCHAR ucRegVal;

    m_refIO.AddRef();

    if (m_dwState != ATTACHED) {
        IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] CSdioDevice::ReadPacket - currently not attached, aborting.\n"));    
        fRetVal = FALSE;
        goto exit;
    }

    WaitForSingleObject(m_hReadPacketEvent, INFINITE);

    if ((m_dwState != ATTACHED) || m_fCancelIO) {
        fRetVal = FALSE;
        goto exit;
    }

    // Get SDIO header
    if (! SD_API_SUCCESS(SDRecv(pBuffer, &cHeader))) {
        fRetVal = FALSE;
        goto exit;
    }

    ASSERT(cHeader == SDIO_HEADER_SIZE);
    ASSERT(sizeof(header) == SDIO_HEADER_SIZE);

#if defined (BT_USE_CELOG)
    if (g_Data.fCeLog) {
        CELOGDATAFLAGGED(TRUE, CELID_RAW_UCHAR, pBuffer, cHeader, 0, CELZONE_ALWAYSON, CELOG_FLAG_RAW_IN);
    }
#endif
    
    memcpy(&header, pBuffer, sizeof(header));

    if ((header.u.AsULONG & 0xFFFFFF) <= 4) {
        IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] CSdioDevice::ReadPacket - Received a zero-length packet.\n"));
        fRetVal = FALSE;
        goto exit;         
    }

    // SDIO service ID maps directly to HCI_TYPE
    *pcbBuffer = (header.u.AsULONG & 0xFFFFFF) - SDIO_HEADER_SIZE;
    *pbType = (BYTE)header.u.AsUCHAR.ServiceID;
    
    IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] CSdioDevice::ReadPacket - type=%d size=%d\n", *pbType, *pcbBuffer));

    if (*pcbBuffer > PACKET_SIZE_R) {
        IFDBG(DebugOut (DEBUG_ERROR, L"[SDIO] CSdioDevice::ReadPacket - Header is specifying invalid size of data.  Bailing...\n", *pbType, *pcbBuffer));    
        fRetVal = FALSE;
        goto exit;
    }

    // Get the payload
    if (! SD_API_SUCCESS(SDRecv(pBuffer, pcbBuffer))) {
        fRetVal = FALSE;
        goto exit;
    }

#if defined (BT_USE_CELOG)
    if (g_Data.fCeLog) {
        CELOGDATAFLAGGED(TRUE, CELID_RAW_UCHAR, pBuffer, *pcbBuffer, 0, CELZONE_ALWAYSON, CELOG_FLAG_RAW_IN);
    }
#endif    

    // Acknowledge the packet
    ucRegVal = 0x00;
    if (! SD_API_SUCCESS(SDSetRegister(REG_PCRRT, m_ucFunction, &ucRegVal, 1))) {
        fRetVal = FALSE;
        goto exit;
    }
    
exit:
    m_refIO.DelRef();
    return fRetVal;
}
 

/*

This method just calls down to SDSend to write packet to SDIO card.

*/
BOOL CSdioDevice::WritePacket(unsigned char* pBuffer, int cbBuffer)
{
    BOOL fRetVal = TRUE;
    
    m_refIO.AddRef();

     if (m_dwState != ATTACHED) {
        IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] CSdioDevice::WritePacket - currently not attached, aborting.\n"));    
        fRetVal = FALSE;
        goto exit;
    }
    
    fRetVal = SD_API_SUCCESS(SDSend(pBuffer, cbBuffer));

exit:
    m_refIO.DelRef();
    return fRetVal;
}


/*

This is a static method which just calls a method on the object passed in pContext.

*/
SD_API_STATUS CSdioDevice::SDIOIsrCallBack(SD_DEVICE_HANDLE hDevice, PVOID pContext)
{
    CSdioDevice* pInst = (CSdioDevice*) pContext;
    return pInst->SDIOIsrCallback_Int();
}


/*

This method is called when an interrupt occurs.  It checks if data is ready to
be transferred from the card and if so, sets an event to indicate this.

*/
SD_API_STATUS CSdioDevice::SDIOIsrCallback_Int(void)
{
    SD_API_STATUS status = SD_API_STATUS_SUCCESS;
    UCHAR ucRegValue;

    m_refIO.AddRef();

    if (m_dwState != ATTACHED) {
        ASSERT(0); // not attached
        goto exit;
    }

    // Check for packet to read
    status = SDGetRegister(REG_INTRD, m_ucFunction, &ucRegValue, 1);
    if (!SD_API_SUCCESS(status)) {
        ASSERT(0);
        goto exit;
    }
    if (ucRegValue) {
        SetEvent(m_hReadPacketEvent);

        // Clear INTRD register
        ucRegValue = 0x01;
        status = SDSetRegister(REG_INTRD, m_ucFunction, &ucRegValue, 1);
        if (!SD_API_SUCCESS(status)) {
            ASSERT(0);
            goto exit;
        }
    }
       
exit:
    m_refIO.DelRef();
    return status;
}


/*

This method writes a specified amount of data to the card.

*/
SD_API_STATUS CSdioDevice::SDSend(unsigned char* pBuffer, unsigned int cbBuffer)
{
    SD_API_STATUS status = SD_API_STATUS_SUCCESS;
    DWORD dwArgument;
    SD_COMMAND_RESPONSE response;

#ifdef DEBUG
    DWORD dwCardStatus;
#endif

#if defined (BT_USE_CELOG)
    if (g_Data.fCeLog) {
        CELOGDATAFLAGGED(TRUE, CELID_RAW_UCHAR, pBuffer, (unsigned short)cbBuffer, 0, CELZONE_ALWAYSON, CELOG_FLAG_RAW_OUT);
    }
#endif

    //
    // We have to send data down to card in blocks no larger than m_usBlockLen.
    //

    while (cbBuffer > 0) {
        USHORT cbNextBlock;

        if (cbBuffer > m_usBlockLen) {
            cbNextBlock = m_usBlockLen;
        }
        else {
            cbNextBlock = cbBuffer;
        }

        dwArgument = BUILD_IO_RW_EXTENDED_ARG(SD_IO_OP_WRITE, 
                            SD_IO_BYTE_MODE, 
                            m_ucFunction, 
                            REG_DATAPORT, 
                            SD_IO_FIXED_ADDRESS, 
                            cbNextBlock);

        status = SDSynchronousBusRequest(m_hDevice,
                            SD_CMD_IO_RW_EXTENDED,
                            dwArgument,
                            SD_WRITE,
                            ResponseR5,
                            &response,
                            1,
                            cbNextBlock,
                            pBuffer,
                            0);
            
        if (!SD_API_SUCCESS(status)) {
            goto exit;
        }

        pBuffer += cbNextBlock;
        cbBuffer -= cbNextBlock;
    
#ifdef DEBUG
        SDGetCardStatusFromResponse(&response, &dwCardStatus);
        IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] CSdioDevice::SDSend - CardStatus from response = 0x%X\n", dwCardStatus));
#endif    
    }
    
exit:
    return status;        
}


/*

This function is called when a synchronous bus request completes.

*/
void SDRecvCallback(SD_DEVICE_HANDLE hDevice, PSD_BUS_REQUEST pRequest, PVOID pDeviceContext, DWORD dwParam)
{
	SDFreeBusRequest(pRequest);
	if (dwParam) {
		// Set event when last block is returned
		SetEvent((HANDLE)dwParam);
	}
}


/*

This method reads a specified amount of data from the card.

*/
SD_API_STATUS CSdioDevice::SDRecv(unsigned char* pBuffer, unsigned int* pcbBuffer)
{
    SD_API_STATUS status = SD_API_STATUS_SUCCESS;
    DWORD dwArgument;
    ULONG cbBytesRead = 0;
    BOOL fLastBlock = FALSE;

    //
    // We have to recv data from the card in blocks no larger than m_usBlockLen.
    //

    while (cbBytesRead < *pcbBuffer) {
        USHORT cbNextBlock;
        PSD_BUS_REQUEST pBusRequest;
        
        if ((*pcbBuffer - cbBytesRead) > m_usBlockLen) {
            cbNextBlock = m_usBlockLen;
        }
        else {
            cbNextBlock = (USHORT) (*pcbBuffer - cbBytesRead);
        }

        if ((cbBytesRead + cbNextBlock) == *pcbBuffer) {
            fLastBlock = TRUE;
        }

        dwArgument = BUILD_IO_RW_EXTENDED_ARG(SD_IO_OP_READ, 
                            SD_IO_BYTE_MODE, 
                            m_ucFunction, 
                            REG_DATAPORT, 
                            SD_IO_FIXED_ADDRESS, 
                            cbNextBlock);

		//[eugeun] High Speed Support
        status = SDBusRequest(m_hDevice,
                            SD_CMD_IO_RW_EXTENDED,
                            dwArgument,
                            SD_READ,
                            ResponseR5,
                            1,
                            cbNextBlock,
                            pBuffer,
                            SDRecvCallback,
                            (DWORD)(fLastBlock ? m_hRecvCompleteEvent : 0),
                            &pBusRequest,
                            0);

        if (!SD_API_SUCCESS(status)) {
            goto exit;
        }

        pBuffer += cbNextBlock;
        cbBytesRead += cbNextBlock;
    }

    WaitForSingleObject(m_hRecvCompleteEvent, INFINITE);

exit:
    return status;
}


/*

This method calculates the largest block length supported by
both the card and host controller.

*/
BOOL CSdioDevice::GetMaxBlockLen(void)
{
    BOOL fRetVal = TRUE;
    SD_HOST_BLOCK_CAPABILITY blockCapability;
    UCHAR rgucTuple[SD_CISTPLE_MAX_BODY_SIZE];
    PSD_CISTPL_FUNCE_FUNCTION pFunce = (PSD_CISTPL_FUNCE_FUNCTION) rgucTuple;
    ULONG ulLength = 0;
    USHORT usHostBlockLen, usCardBlockLen;

    if (! SD_API_SUCCESS(SDGetTuple(m_hDevice, SD_CISTPL_FUNCE, NULL, &ulLength, FALSE)) ||
          (ulLength > sizeof(rgucTuple)) ) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    if (! SD_API_SUCCESS(SDGetTuple(m_hDevice, SD_CISTPL_FUNCE, rgucTuple, &ulLength, FALSE)) ||
          (pFunce->bType != SD_CISTPL_FUNCE_FUNCTION_TYPE) ) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    usCardBlockLen = pFunce->wMaxBlkSize;

    blockCapability.ReadBlocks = DEFAULT_HOST_NUM_BLOCKS;
    blockCapability.WriteBlocks = DEFAULT_HOST_NUM_BLOCKS;
    blockCapability.ReadBlockSize = DEFAULT_HOST_BLOCK_SIZE;
    blockCapability.WriteBlockSize = DEFAULT_HOST_BLOCK_SIZE;
    if (! SD_API_SUCCESS(SDCardInfoQuery(m_hDevice, SD_INFO_HOST_BLOCK_CAPABILITY, &blockCapability, sizeof(blockCapability)))) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] Block Capability on host: read_blocks=%d write_blocks=%d read_size=%d write_size=%d\n",
        blockCapability.ReadBlocks,
        blockCapability.WriteBlocks,
        blockCapability.ReadBlockSize,
        blockCapability.WriteBlockSize));

    usHostBlockLen = (blockCapability.ReadBlockSize < blockCapability.WriteBlockSize) ? blockCapability.ReadBlockSize : blockCapability.WriteBlockSize;

    m_usBlockLen = (usHostBlockLen < usCardBlockLen) ? usHostBlockLen : usCardBlockLen;

exit:    
    return fRetVal;
}

/*

This method reads tuple 0x91 to determine if this is a type A or B BT card.

*/
BOOL CSdioDevice::GetBTCardType(void)
{
    BOOL fRetVal = TRUE;
    PUCHAR pucTuple = NULL;
    ULONG ulLength = 0;
    
    if (! SD_API_SUCCESS(SDGetTuple(m_hDevice, SD_CISTPL_SDIO_STD, NULL, &ulLength, FALSE))) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    pucTuple = (UCHAR*) LocalAlloc(0, ulLength);
    if (! pucTuple) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    if (! SD_API_SUCCESS(SDGetTuple(m_hDevice, SD_CISTPL_SDIO_STD, pucTuple, &ulLength, FALSE))) {
        ASSERT(0);
        fRetVal = FALSE;
        goto exit;
    }

    m_usBTCardType = (BYTE) *pucTuple; // card type is first byte in tuple

exit:
    if (pucTuple) {
        LocalFree(pucTuple);
    }
    
    return fRetVal;
}

/*

This method handles power management IOCTLs.

*/
DWORD CSdioDevice::IOControl(DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
    DWORD dwRet = ERROR_SUCCESS;
    
    switch(dwCode) {
        case IOCTL_POWER_CAPABILITIES: {
            if ( !pBufOut || dwLenOut != sizeof(POWER_CAPABILITIES) || 
                 !pdwActualOut ) {
                dwRet = ERROR_INVALID_PARAMETER;
            }
            else {
                PPOWER_CAPABILITIES pPowerCaps = (PPOWER_CAPABILITIES)pBufOut;
                memset(pPowerCaps, 0, sizeof(POWER_CAPABILITIES));

                pPowerCaps->DeviceDx = DX_MASK(D0) | DX_MASK(D3) | DX_MASK(D4);
                pPowerCaps->WakeFromDx = DX_MASK(D0) | DX_MASK(D3);
                *pdwActualOut = sizeof(POWER_CAPABILITIES);
            }
            break;
        }

        case IOCTL_POWER_SET: {
            if ( !pBufOut || dwLenOut != sizeof(CEDEVICE_POWER_STATE) || 
                 !pdwActualOut ) {
                dwRet = ERROR_INVALID_PARAMETER;
            }
            else {
                PCEDEVICE_POWER_STATE pcps = (PCEDEVICE_POWER_STATE) pBufOut;

                if (m_hBusAccess) {
                    SD_CARD_INTERFACE ci;
                    SD_API_STATUS status = SDCardInfoQuery(m_hDevice,
                        SD_INFO_CARD_INTERFACE,
                        &ci,
                        sizeof(ci));

                    if (SD_API_SUCCESS(status)) {
                        if (*pcps == D3) {
                            m_fGoTo4BitModeOnResume = FALSE;
                            
                            if (ci.InterfaceMode == SD_INTERFACE_SD_4BIT) {
                                // Place card into 1-bit mode so card 
                                // interrupts can wake the system.
                                ci.InterfaceMode = SD_INTERFACE_SD_MMC_1BIT;
                                status = SDSetCardFeature(m_hDevice,
                                    SD_SET_CARD_INTERFACE,
                                    &ci,
                                    sizeof(ci));
                                m_fGoTo4BitModeOnResume = SD_API_SUCCESS(status);
                            }
                            // else already in 1-bit mode
                            SetDevicePowerState(m_hBusAccess, *pcps, NULL);
                        }
                        else if (*pcps == D0 && m_cpsCurrent != D0) {
                            // Turn on power first since SDSetCardFeature
                            // performs a bus request.
                            SetDevicePowerState(m_hBusAccess, *pcps, NULL);
                            
                            if (m_fGoTo4BitModeOnResume) {
                                DEBUGCHK(ci.InterfaceMode == SD_INTERFACE_SD_MMC_1BIT);
                                ci.InterfaceMode = SD_INTERFACE_SD_4BIT;
                                status = SDSetCardFeature(m_hDevice,
                                    SD_SET_CARD_INTERFACE,
                                    &ci,
                                    sizeof(ci));
                                m_fGoTo4BitModeOnResume = FALSE;
                            }
                        }
                        else {
                            SetDevicePowerState(m_hBusAccess, *pcps, NULL);
                        }
                    }
                    
                    m_cpsCurrent = *pcps;
                    *pdwActualOut = sizeof(*pcps);
                }
                else {
                    dwRet = ERROR_INVALID_PARAMETER;
                }
            }
            break;
        }

        case IOCTL_POWER_GET: {
            if ( !pBufOut || dwLenOut != sizeof(CEDEVICE_POWER_STATE) || 
                 !pdwActualOut ) {
                dwRet = ERROR_INVALID_PARAMETER;
            }
            else {
                PCEDEVICE_POWER_STATE pcps = (PCEDEVICE_POWER_STATE) pBufOut;
                
                if (m_hBusAccess) {
                    BOOL fSuccess = GetDevicePowerState(m_hBusAccess, pcps, NULL);
                    if (fSuccess) {
                        *pdwActualOut = sizeof(*pcps);
                    }
                    else {
                        dwRet = GetLastError();
                    }
                }
                else {
                    dwRet = ERROR_INVALID_PARAMETER;
                }
            }
        }

        default:
            dwRet = ERROR_INVALID_PARAMETER;
    }

    return dwRet;
}

/*

This method initializes the BT registers in preparation for reading/writing data.

*/
BOOL CSdioDevice::InitializeBTRegisters(void)
{
    BOOL fRetVal = TRUE;
    UCHAR ucRegVal;

    fRetVal = GetBTCardType();
    if (! fRetVal) {
        ASSERT(0);
        goto exit;
    }

    ASSERT((m_usBTCardType == BT_CARD_TYPE_A) || (m_usBTCardType == BT_CARD_TYPE_B));

    if (m_usBTCardType == BT_CARD_TYPE_B) {
        ucRegVal = 0x00;
        if (! SD_API_SUCCESS(SDSetRegister(REG_MDSTAT, m_ucFunction, &ucRegVal, 1))) {
            ASSERT(0);
            fRetVal = FALSE;
            goto exit;
        }
    }

#ifdef DEBUG
    if (! SD_API_SUCCESS(SDGetRegister(REG_MDSTAT, m_ucFunction, &ucRegVal, 1))) {
        fRetVal = FALSE;
        goto exit;
    }

    IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] MDSTAT register: %d\n", ucRegVal));
#endif

    ucRegVal = 0x00;
    if (! SD_API_SUCCESS(SDSetRegister(REG_RTC, m_ucFunction, &ucRegVal, 1))) {
        fRetVal = FALSE;
        goto exit;
    }

#ifdef DEBUG
    if (! SD_API_SUCCESS(SDGetRegister(REG_RTC, m_ucFunction, &ucRegVal, 1))) {
        fRetVal = FALSE;
        goto exit;
    }

    IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] RTC STAT register: %d\n", ucRegVal));
#endif

    ucRegVal = 0x01;
    if (! SD_API_SUCCESS(SDSetRegister(REG_ENINTRD, m_ucFunction, &ucRegVal, 1))) {
        fRetVal = FALSE;
        goto exit;
    }

#ifdef DEBUG
    if (! SD_API_SUCCESS(SDGetRegister(REG_ENINTRD, m_ucFunction, &ucRegVal, 1))) {
        fRetVal = FALSE;
        goto exit;
    }

    IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] ENINTRD register: %d\n", ucRegVal));

    if (! SD_API_SUCCESS(SDGetRegister(REG_INTRD, m_ucFunction, &ucRegVal, 1))) {
        fRetVal = FALSE;
        goto exit;
    }

    IFDBG(DebugOut (DEBUG_HCI_TRANSPORT, L"[SDIO] INTRD register: %d\n", ucRegVal));
#endif

exit:
    return fRetVal;
}

