/*=====================================================================================
*
* @File Name	: SDMEMAPI.CPP
*
* @File Version	: SIGBYAHONG_SDMEMAPI_WINCE6_TCCXXXX_V2000
*
=====================================================================================*/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//

// Copyright (c) 2002 BSQUARE Corporation.  All rights reserved.
// DO NOT REMOVE --- BEGIN EXTERNALLY DEVELOPED SOURCE CODE ID 40973--- DO NOT REMOVE

// Implementation of memory lists and memory tagging

#include <SDCardDDK.h>
#include <svsutil.hxx>
#include <block_allocator.hxx>


static LONG g_lMemoryListCount = 0; // Reduces the likelihood of race 
// conditions when SDInitializeCardLib
// is not called. (For legacy drivers.)

static volatile BOOL g_fInitialized = FALSE; // Has svsutils been initialized?
static BOOL g_fInitializeCardLibCalled = FALSE; // Has SDInitializeCardLib been called?


// Initializes the svsutil subsystem.
static BOOL InitCardLib() 
{
    DEBUGCHK(g_fInitialized == FALSE);
    svsutil_Initialize();
    g_SDClientApiFunctions.dwSize = sizeof(g_SDClientApiFunctions);
    g_fInitialized = TRUE;

    return TRUE;
}


// Deinitializes the svsutil subsystem.
static BOOL DeinitCardLib() 
{
    DEBUGCHK(g_fInitialized);
    g_fInitialized = FALSE;
    svsutil_DeInitialize();

    return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
//  SDInitializeCardLib - initializes the card library
//  Input:
//  Output:
//  Return: success or failure
//  Notes:  call this in your DLL entry upon attach to
//          avoid race conditions in the memory subsystem
///////////////////////////////////////////////////////////////////////////////
extern "C"
BOOL SDInitializeCardLib() 
{
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: +SDInitializeCardLib\n")));
    DEBUGCHK(g_fInitializeCardLibCalled == FALSE);
    BOOL fRet = InitCardLib();
    g_fInitializeCardLibCalled = TRUE;
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: -SDInitializeCardLib\n")));

    return fRet;
}


///////////////////////////////////////////////////////////////////////////////
//  SDDeinitializeCardLib - initializes the card library
//  Input:
//  Output:
//  Return: success or failure
//  Notes:  call this in your DLL entry upon detach to
//          avoid race conditions in the memory subsystem
///////////////////////////////////////////////////////////////////////////////
extern "C"
BOOL SDDeinitializeCardLib() 
{
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: +SDDeinitializeCardLib\n")));
    DEBUGCHK(g_fInitializeCardLibCalled);
    g_fInitializeCardLibCalled = FALSE;
    BOOL fRet = DeinitCardLib();
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: -SDDeinitializeCardLib\n")));

    return fRet;
}


///////////////////////////////////////////////////////////////////////////////
//  SDAllocateMemoryWithTag - allocates memory with a tag
//  Input:  Size - size of the allocation
//          Tag - tag in the form of 4 ASCII characters to track the allocation
//  Output:
//  Return: returns a pointer to a block of allocated memory
//  Notes:  
//          must use SDFreeMemory to free the allocated memory
///////////////////////////////////////////////////////////////////////////////
extern "C"
PVOID SDAllocateMemoryWithTag(ULONG Size, ULONG Tag)
{
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: +AllocateMemoryWithTag\n")));
    PVOID pMemory = LocalAlloc(LPTR, Size);
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: -AllocateMemoryWithTag\n")));

    return pMemory;
}

///////////////////////////////////////////////////////////////////////////////
//  SDFreeMemory - frees memory allocated with MemAllocateMemory/WithTag
//  Input:  pMemory - the memory to free
//  Output:
//  Return:
//  Notes:  
///////////////////////////////////////////////////////////////////////////////
extern "C"
VOID SDFreeMemory(PVOID pMemory)
{
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: +SDFreeMemory\n")));
    LocalFree(pMemory);
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: -SDFreeMemory\n")));
}


// Memory list class. This basically wraps ce::fixed_block_allocator.
class CSDMemList {
public:
    CSDMemList(DWORD dwDepth, DWORD cbEntry) : m_fba(dwDepth) {
        m_cbEntry = cbEntry;
    }

    ~CSDMemList() {}

    // Make sure that all our initial entries are pre-allocated
    BOOL Init() {
        PVOID pvTemp = Alloc();
        if (pvTemp) {
            // Memory is allocated. Free our temp variable.
            Free(pvTemp);
        }

        return (pvTemp != NULL);
    }

    PVOID Alloc() {
        return m_fba.allocate(m_cbEntry);
    }

    VOID Free(PVOID pv) {
        m_fba.deallocate(pv, m_cbEntry);
    }

private:
    ce::fixed_block_allocator<> m_fba;
    size_t                      m_cbEntry;
};


///////////////////////////////////////////////////////////////////////////////
//  SDDeleteMemList - delete a memory list
//      
//  Input:
//          hList - memory list to delete
//        
//  Output: 
//  Return:          
//  Notes:  
//          
///////////////////////////////////////////////////////////////////////////////
extern "C"
VOID SDDeleteMemList(SD_MEMORY_LIST_HANDLE hList) 
{
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: +SDDeleteMemList\n")));
    CSDMemList *pList = (CSDMemList*) hList;

    if (pList) {
        delete pList;

        if (!g_fInitializeCardLibCalled) {
            // We are dealing with a legacy driver. We will try to avoid
            // race conditions, but they are still possible.
            LONG lNewCount = InterlockedDecrement(&g_lMemoryListCount);
            if (lNewCount == 0) {
                // Last MemList. Deinitialize the cardlib.
                DeinitCardLib();
                DEBUGCHK(!g_fInitialized);
            }
        }
    }
    else {
        RETAILMSG(1, (_T("[SDBUS       ]SDCard: SDDeleteMemList: Invalid parameter\n")));
        DEBUGCHK(FALSE);
    }

    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: -SDDeleteMemList\n")));
} 


///////////////////////////////////////////////////////////////////////////////
//  SDCreateMemoryList - create a memory list
//      
//  Input:  Tag      - Memory Tag
//          Depth    - threshold of committed memory list size, also initial number of 
//                     entries
//          EntrySize - Size of each entry/block
//          
//  Output: 
//  Return: memory list handle
//  Notes:  
//          Initializes a mem list structure for use in allocating and deallocating
//          fixed blocks of memory.  This is a mechanism to reduce heap fragmentation.  
//          Allocations are dynamic (i.e. the list grows to accomodate allocations), 
//          however, deallocated blocks are recycled rather than returned to the process heap.
//          
//          The  depth specifies the maximum number of heap committed allocations.  Additional
//          allocations beyond the maximum depth are allocated normally, but returned to the heap rather
//          than re-cycled.
// 
//            
//          Must call SDDeleteMemList to free the list.
///////////////////////////////////////////////////////////////////////////////
extern "C"
SD_MEMORY_LIST_HANDLE SDCreateMemoryList(
    ULONG Tag,
    ULONG Depth,
    ULONG EntrySize)
{
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: +SDCreateMemoryList\n")));

    DEBUGCHK(Depth);
    DEBUGCHK(EntrySize);

    if (!g_fInitializeCardLibCalled) {
        // We are dealing with a legacy driver. We will try to avoid
        // race conditions, but they are still possible.
        DEBUGMSG(SDCARD_ZONE_WARN, 
            (TEXT("SDCard: Warning: Please call SDInitializeCardLib to avoid race conditions\n")));

        LONG lOldCount = InterlockedIncrement(&g_lMemoryListCount) - 1;
        if (lOldCount == 0) {
            // First MemList. Initialize the cardlib.
            InitCardLib();
            DEBUGCHK(g_fInitialized);
        }
        else {
            while (!g_fInitialized) {
                // Wait for the first calling thread to finish initializing.
                Sleep(1);
            }
        }
    }

    CSDMemList *pNewList = new CSDMemList(Depth, EntrySize);
    if (pNewList) {
        if (!pNewList->Init()) {
            delete pNewList;
            pNewList = NULL;
        }
    }

    if (NULL == pNewList) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDCard: SDCreateMemoryList - Failed to create memory list\n")));
    }

    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: -SDCreateMemoryList\n")));

    // return the list as an opague object
    return (SD_MEMORY_LIST_HANDLE) pNewList;
}


///////////////////////////////////////////////////////////////////////////////
//  SDFreeToMemList - free a block of memory to the memory list
//      
//  Input:  hList - mem list object
//          pMemory - block of memory to free 
//  Output: 
//  Return:         
//  Notes:  
//          returns memory block to mem list
///////////////////////////////////////////////////////////////////////////////
extern "C"
VOID SDFreeToMemList(
    IN SD_MEMORY_LIST_HANDLE  hList,
    IN PVOID                  pMemory)
{
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: +SDFreeToMemList\n")));
    CSDMemList *pList = (CSDMemList*) hList;

    if (pList) {
        pList->Free(pMemory);
    }
    else {
        RETAILMSG(1, (_T("[SDBUS       ]SDCard: SDFreeToMemList: Invalid parameter\n")));
        DEBUGCHK(FALSE);
    }

    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: -SDFreeToMemList\n")));
}


///////////////////////////////////////////////////////////////////////////////
//  SDAllocateFromMemList - Allocate a block from the memory list
//      
//  Input:
//          hList - memory list
//        
//  Output: 
//  Return:        
//  Notes:  
//          returns memory block from mem list
///////////////////////////////////////////////////////////////////////////////
extern "C"
PVOID SDAllocateFromMemList(IN SD_MEMORY_LIST_HANDLE hList)
{
    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: +SDAllocateFromMemList\n")));
    CSDMemList *pList = (CSDMemList*) hList;
    PVOID pv;

    if (pList) {
        pv = pList->Alloc();
    }
    else {
        pv = NULL;
        RETAILMSG(1, (_T("[SDBUS       ]SDCard: SDAllocateFromMemList: Invalid parameter\n")));
        DEBUGCHK(FALSE);
    }

    DEBUGMSG(SDCARD_ZONE_FUNC, (TEXT("SDCard: -SDAllocateFromMemList\n")));

    return pv;
}


// DO NOT REMOVE --- END EXTERNALLY DEVELOPED SOURCE CODE ID --- DO NOT REMOVE

