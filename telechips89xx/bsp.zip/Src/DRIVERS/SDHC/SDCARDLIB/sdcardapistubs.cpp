/*=====================================================================================
*
* @File Name	: SDCARDAPISTUBS.CPP
*
* @File Version	: SIGBYAHONG_SDCARDAPISTUBS_WINCE6_TCCXXXX_V2000
*
=====================================================================================*/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//

// Copyright (c) 2002 BSQUARE Corporation.  All rights reserved.
// DO NOT REMOVE --- BEGIN EXTERNALLY DEVELOPED SOURCE CODE ID 40973--- DO NOT REMOVE

// Functions to setup API stubs

#include <SDCardDDK.h>
#include <cesdbus.h>
extern "C" {

// global stucture containing pointer to Client API functions
SDCARD_API_FUNCTIONS g_SDClientApiFunctions = { sizeof(g_SDClientApiFunctions) };


#ifdef DEBUG
///////////////////////////////////////////////////////////////////////////////
//  SDRegisterDebugZones - register a client device
//  Input:  hDevice     - device handle
//          pRegPath    - pointer to registry path
//          
//  Output: 
//  Return:
//  Notes:  
//      
///////////////////////////////////////////////////////////////////////////////
VOID SDRegisterDebugZones(SD_DEVICE_HANDLE , PTSTR)
{
    // Registry DebugZone should do at DLLEntry.
    // We don't have good way to support it during initalization. So, we drop it.
}
#endif

extern "C"    SD_API_STATUS SDBusGetClientFunctions( PSDCARD_API_FUNCTIONS pFunctions);

///////////////////////////////////////////////////////////////////////////////
//  SDRegisterClient - register a client device
//  Input:  hDevice         - device handle
//          pDeviceContext  - device specific context allocated by driver
//          pInfo           - registration information
//          
//  Output: 
//  Return: SD_API_STATUS code
//  Notes:  
//      This function sets up the function pointers
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS SDRegisterClient(SD_DEVICE_HANDLE                 hDevice, 
                               PVOID                            pDeviceContext, 
                               PSDCARD_CLIENT_REGISTRATION_INFO pInfo)

{
    DEBUGCHK(hDevice);
    DEBUGCHK(pInfo);

    SD_API_STATUS status;

    // get APIs using a direct call into the bus driver
    if (IsKModeAddr((DWORD)SDRegisterClient)) {
        DWORD dwActSize = 0 ;
        BOOL fRet = BusIoControl(GetBusAccessHandle(),IOCTL_BUS_SD_GETCLIENT_FUNCTION,
            NULL,0,
            &g_SDClientApiFunctions,sizeof(g_SDClientApiFunctions),
            &dwActSize,NULL);
        status = GetLastError();
        if (!fRet ||  dwActSize!=sizeof(g_SDClientApiFunctions)) { 
            status = SDBusGetClientFunctions(&g_SDClientApiFunctions);
        }
        
    }
    else
        status = SDBusGetClientFunctions(&g_SDClientApiFunctions);

    if (SD_API_SUCCESS(status)) {
        PREFAST_DEBUGCHK(g_SDClientApiFunctions.pSDRegisterClient);
        DEBUGCHK(g_SDClientApiFunctions.pSDSynchronousBusRequest);
        DEBUGCHK(g_SDClientApiFunctions.pSDBusRequest);
        DEBUGCHK(g_SDClientApiFunctions.pSDFreeBusRequest);
        DEBUGCHK(g_SDClientApiFunctions.pSDCardInfoQuery);
        DEBUGCHK(g_SDClientApiFunctions.pSDReadWriteRegistersDirect);
        DEBUGCHK(g_SDClientApiFunctions.pSDCancelBusRequest);
        DEBUGCHK(g_SDClientApiFunctions.pSDIOConnectInterrupt);
        DEBUGCHK(g_SDClientApiFunctions.pSDIODisconnectInterrupt);
        DEBUGCHK(g_SDClientApiFunctions.pSDSetCardFeature);

        // Call the actual registration function.
        status = g_SDClientApiFunctions.pSDRegisterClient(hDevice, pDeviceContext, pInfo);
    }
    else {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDRegisterClient: Failed to get client functions\n")));
    }

    return status;
}

}

// DO NOT REMOVE --- END EXTERNALLY DEVELOPED SOURCE CODE ID --- DO NOT REMOVE

