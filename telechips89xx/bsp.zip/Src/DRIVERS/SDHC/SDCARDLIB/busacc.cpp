/*=====================================================================================
*
* @File Name	: BUSACC.CPP
*
* @File Version	: SIGBYAHONG_BUSACC_WINCE6_TCCXXXX_V2000
*
=====================================================================================*/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//
#include <windows.h>
#include <types.h>
#include <ceddk.h>
#include <CeSDBus.h>
#include "busacc.hpp"

SDBusAccess * g_pSDBusAccess  = NULL ;
SDBusAccess * CreateSDBusAcess(LPCTSTR lpActivePath)
{
    if (!g_pSDBusAccess) {
        SDBusAccess * l_pSDBusAccess = new SDBusAccess(lpActivePath);
        if (l_pSDBusAccess && l_pSDBusAccess->Init()) {
            g_pSDBusAccess = l_pSDBusAccess;
        }
        else if (l_pSDBusAccess!=NULL)
            delete l_pSDBusAccess;
    }
    return g_pSDBusAccess;            
}


SDBusAccess::SDBusAccess(LPCTSTR lpActivePath)
{
    m_hBusAccess = CreateBusAccessHandle(lpActivePath);
    m_hCallback = CeDriverMapCallbackFunction(SDBusCallback);
    pSDRegisterClient = SDRegisterClient__X;
    pSDSynchronousBusRequest = SDSynchronousBusRequest__X;
    pSDBusRequest = SDBusRequest__X;
    pSDFreeBusRequest = SDFreeBusRequest__X;
    pSDCardInfoQuery = SDCardInfoQuery__X;
    pSDReadWriteRegistersDirect = SDReadWriteRegistersDirect__X;
    pSDCancelBusRequest = SDCancelBusRequest__X;
    pSDGetTuple = SDGetTuple__X;
    pSDIOConnectInterrupt  = SDIOConnectInterrupt__X;
    pSDIODisconnectInterrupt = SDIODisconnectInterrupt__X;
    pSDSetCardFeature = SDSetCardFeature__X;
    pSdBusRequestResponse = SDBusRequestResponse__X;
    
}
SDBusAccess::~SDBusAccess()
{
    if (m_hBusAccess)
        CloseBusAccessHandle(m_hBusAccess);
    if (m_hCallback)
        CloseHandle(m_hCallback);
}
BOOL SDBusAccess::Init()
{
    return (m_hBusAccess!=NULL && m_hCallback!=NULL) ;
}
BOOL WINAPI SDBusAccess::SDBusCallback(
    DWORD dwIoControlCode, LPVOID lpInBuf, DWORD nInBufSize, LPVOID lpOutBuf, DWORD nOutBufSize, LPDWORD lpBytesReturned, LPOVERLAPPED lpOverlapped
)
{
    BOOL fReturn = FALSE;
    switch (dwIoControlCode) {
      case IOCTL_BUS_SD_REQUEST_CALLBACK:
        if (lpInBuf && nInBufSize>=sizeof(IO_BUS_SD_REQUEST_CALLBACK)) {
            PIO_BUS_SD_REQUEST_CALLBACK pCallbackBlock = (PIO_BUS_SD_REQUEST_CALLBACK)lpInBuf;
            if (pCallbackBlock->pRequestCallback) {
                (*pCallbackBlock->pRequestCallback)(pCallbackBlock->hDevice,(PSD_BUS_REQUEST)pCallbackBlock->hBusRequest,pCallbackBlock->pDeviceContext,pCallbackBlock->dwRequestParam);
                fReturn = TRUE;
            }
        }
        break;
      case IOCTL_BUS_SD_SLOT_EVENT_CALLBACK:
        if (lpInBuf && nInBufSize>=sizeof(IO_BUS_SD_SLOT_EVENT_CALLBACK)) {
            PIO_BUS_SD_SLOT_EVENT_CALLBACK pCallbackBlock = (PIO_BUS_SD_SLOT_EVENT_CALLBACK)lpInBuf;
            if (pCallbackBlock->pSdSlotEventCallback) {
                PVOID pDataPtr = (pCallbackBlock->dwDataOffset==0?NULL:((PBYTE)lpInBuf+ pCallbackBlock->dwDataOffset));
                (*pCallbackBlock->pSdSlotEventCallback) ( pCallbackBlock->hDevice,pCallbackBlock->pDeviceContext,pCallbackBlock->SdSlotEventType,pDataPtr,pCallbackBlock->dwInSize);
                fReturn = TRUE;
            }
        }
        break;
      case IOCTL_BUS_SD_INTERRUPT_CALLBACK:
        if (lpInBuf && nInBufSize>=sizeof(IO_BUS_SD_INTERRUPT_CALLBACK)) {
            PIO_BUS_SD_INTERRUPT_CALLBACK pCallbackBlock = (PIO_BUS_SD_INTERRUPT_CALLBACK)lpInBuf;
            if (pCallbackBlock->pSdInterruptCallback) {
                (*pCallbackBlock->pSdInterruptCallback) ( pCallbackBlock->hDevice,pCallbackBlock->pDeviceContext);
                fReturn = TRUE;
            }
        }
        break;
    }
    return fReturn ;
}


SD_API_STATUS SDBusAccess::SDRegisterClient__X(SD_DEVICE_HANDLE   hDevice, PVOID  pDeviceContext, PSDCARD_CLIENT_REGISTRATION_INFO pInfo)
{
    SD_API_STATUS apiStatus = SD_API_STATUS_SUCCESS ;
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess && pInfo ) {
        IO_SD_REGISTERCLIENTDEVICE sdRegisterClientParam;
        sdRegisterClientParam.hDevice = hDevice ;
        sdRegisterClientParam.pDeviceContext = pDeviceContext;
        sdRegisterClientParam.hCallbackAPI = l_pSDBusAccess->GetCallbackHandle();
        sdRegisterClientParam.sdClientRegistrationInfo = *pInfo;
        SetLastError(SD_API_STATUS_SUCCESS);
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_REGISTER_CLIENT,
            &sdRegisterClientParam,sizeof(sdRegisterClientParam),
            NULL,0,
            NULL,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_NO_SUCH_DEVICE;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDRegisterClient__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
        return apiStatus ;
    }
    else 
        return SD_API_STATUS_NO_SUCH_DEVICE ;
}
SD_API_STATUS SDBusAccess::SDSynchronousBusRequest__X(SD_DEVICE_HANDLE   hDevice, 
        UCHAR Command,DWORD Argument,SD_TRANSFER_CLASS TransferClass,SD_RESPONSE_TYPE ResponseType,PSD_COMMAND_RESPONSE  pResponse,
        ULONG NumBlocks,ULONG BlockSize,PUCHAR pBuffer,DWORD Flags,DWORD dwSize,PPHYS_BUFF_LIST pPhysBuffList )
{
    SD_API_STATUS apiStatus = SD_API_STATUS_SUCCESS ;
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        IO_SD_SYNCHRONOUS_BUS_REQUEST_EX sdSyncBusRequestParam = {
            hDevice,Command,Argument, TransferClass, ResponseType, NumBlocks,BlockSize, pBuffer, Flags,dwSize,pPhysBuffList
        };
        if ((Flags & SD_BUS_REQUEST_PHYS_BUFFER)==0) { // No Physical Buffer.
            sdSyncBusRequestParam.cbSize= 0;
            sdSyncBusRequestParam.pPhysBuffList = NULL;
        }
        SetLastError(SD_API_STATUS_SUCCESS);
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_SYNCHRONOUS_BUS_REQUEST_EX,
            &sdSyncBusRequestParam,sizeof(sdSyncBusRequestParam),
            pResponse,sizeof(SD_COMMAND_RESPONSE),
            NULL,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_NO_SUCH_DEVICE;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDSynchronousBusRequest__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
        return apiStatus ;
        
    }    
    else 
        return SD_API_STATUS_NO_SUCH_DEVICE ;
}
SD_API_STATUS SDBusAccess::SDBusRequestResponse__X(HANDLE hRequest, PSD_COMMAND_RESPONSE pSdCmdResp)
{
    SD_API_STATUS   apiStatus = SD_API_STATUS_INVALID_PARAMETER;  // intermediate status
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        SetLastError(SD_API_STATUS_SUCCESS);
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_REQUEST_RESPONSE,
            &hRequest,sizeof(hRequest),
            pSdCmdResp,sizeof(SD_COMMAND_RESPONSE),
            NULL,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_INVALID_PARAMETER;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDBusRequestResponse__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
    }
    DEBUGMSG(SDCARD_ZONE_ERROR && !SD_API_SUCCESS(apiStatus) , (TEXT("SDBusRequestResponse__X: Failed:wrong Handle 0x%08X \n"),hRequest));
    return apiStatus;
}

SD_API_STATUS SDBusAccess::SDBusRequest__X(SD_DEVICE_HANDLE hHandle,
        UCHAR Command, DWORD Argument, SD_TRANSFER_CLASS TransferClass,SD_RESPONSE_TYPE ResponseType, ULONG NumBlocks,
        ULONG BlockSize, PUCHAR pBuffer, PSD_BUS_REQUEST_CALLBACK pCallback, DWORD RequestParam, HBUS_REQUEST *phRequest, DWORD Flags,DWORD dwSize,PPHYS_BUFF_LIST pPhysBuffList)
{
    SD_API_STATUS apiStatus = SD_API_STATUS_SUCCESS ;
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        IO_SD_BUS_REQUEST_EX sdBusRequestParam = {
                hHandle,Command,Argument,TransferClass,ResponseType,NumBlocks,BlockSize, pBuffer,
                {pCallback,hHandle,{0},NULL,RequestParam}, Flags,dwSize,pPhysBuffList
        };
        if ((Flags & SD_BUS_REQUEST_PHYS_BUFFER)==0) { // No Physical Buffer.
            sdBusRequestParam.cbSize= 0;
            sdBusRequestParam.pPhysBuffList = NULL;
        }
        SetLastError(SD_API_STATUS_SUCCESS);
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_BUS_REQUEST_EX,
            &sdBusRequestParam,sizeof(sdBusRequestParam),
            phRequest,sizeof(HBUS_REQUEST),
            NULL,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_NO_SUCH_DEVICE;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDBusRequest__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
        return apiStatus ;
        
    }    
    else 
        return SD_API_STATUS_NO_SUCH_DEVICE ;
    
}

BOOLEAN SDBusAccess::SDCancelBusRequest__X(HBUS_REQUEST  HhRequest)
{
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_CANCEL_BUS_REQUEST,
            &HhRequest,sizeof(HhRequest),
            NULL,0,
            NULL,NULL);
        if (!fReturn)
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDCancelBusRequest__X: Failed GetLastError() = %d \n"),GetLastError()));            
        return fReturn;
    }
    else {
        SetLastError(ERROR_NOT_SUPPORTED);
        return FALSE;
    }
}
VOID SDBusAccess::SDFreeBusRequest__X(HBUS_REQUEST  hRequest)
{
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_FREE_BUS_REQUEST,
            &hRequest,sizeof(hRequest),
            NULL,0,
            NULL,NULL);
        if (!fReturn)
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDFreeBusRequest__X: Failed GetLastError() = %d \n"),GetLastError()));            
    }
}
SD_API_STATUS SDBusAccess::SDCardInfoQuery__X( SD_DEVICE_HANDLE hHandle,
        SD_INFO_TYPE InfoType,PVOID pCardInfo,ULONG StructureSize)
{
    SD_API_STATUS apiStatus = SD_API_STATUS_SUCCESS ;
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        IO_SD_CARD_INFO_QUERY sdCardInfoQueryParam = {
            hHandle,InfoType
        };
        SetLastError(SD_API_STATUS_SUCCESS);
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_CARD_INFO_QUERY,
            &sdCardInfoQueryParam,sizeof(sdCardInfoQueryParam),
            pCardInfo,StructureSize,
            NULL,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_NO_SUCH_DEVICE;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDCardInfoQuery__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
        return apiStatus ;
    }
    else 
        return SD_API_STATUS_NO_SUCH_DEVICE ;
}

SD_API_STATUS SDBusAccess::SDReadWriteRegistersDirect__X(SD_DEVICE_HANDLE  hDevice,
    SD_IO_TRANSFER_TYPE ReadWrite, UCHAR  Function, DWORD Address, BOOLEAN  ReadAfterWrite, PUCHAR pBuffer, ULONG Length)
{
    SD_API_STATUS apiStatus = SD_API_STATUS_SUCCESS ;
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        IO_SD_READ_WRITE_REGISTERS_DIRECT sdReadWriteDirectParam = {
                hDevice, ReadWrite, Function, Address, ReadAfterWrite,pBuffer,Length
        };
        SetLastError(SD_API_STATUS_SUCCESS);
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_READ_WRITE_REGISTERS_DIRECT,
            &sdReadWriteDirectParam,sizeof(sdReadWriteDirectParam),
            NULL,0,
            NULL,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_NO_SUCH_DEVICE;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDReadWriteRegistersDirect__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
        return apiStatus ;
    }
    else 
        return SD_API_STATUS_NO_SUCH_DEVICE ;
    
}
SD_API_STATUS SDBusAccess::SDGetTuple__X(SD_DEVICE_HANDLE hDevice,
    UCHAR TupleCode, PUCHAR pBuffer,PULONG pBufferSize,BOOL CommonCIS)
{
    SD_API_STATUS apiStatus = SD_API_STATUS_SUCCESS ;
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        IO_BUS_SD_GET_TUPLE sdGetTupleParam = {
                hDevice, TupleCode, CommonCIS
        };
        SetLastError(SD_API_STATUS_SUCCESS);
        DWORD dwReturn = 0;
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_GET_TUPLE,
            &sdGetTupleParam,sizeof(sdGetTupleParam),
            pBuffer,pBufferSize!=NULL?*pBufferSize:0,
            &dwReturn,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_NO_SUCH_DEVICE;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDReadWriteRegistersDirect__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
        else if (pBufferSize) {
            *pBufferSize = dwReturn ;
        }
        return apiStatus ;
    }
    else 
        return SD_API_STATUS_NO_SUCH_DEVICE ;
    
}
SD_API_STATUS SDBusAccess::SDIOConnectInterrupt__X(SD_DEVICE_HANDLE   hDevice, 
                                      PSD_INTERRUPT_CALLBACK   pIsrFunction)
{

    SD_API_STATUS apiStatus = SD_API_STATUS_SUCCESS ;
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        IO_SD_IO_CONNECT_INTERRUPT sdIoConnectInterruptParam = {
                hDevice, {pIsrFunction  }
        };
        SetLastError(SD_API_STATUS_SUCCESS);
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_IO_CONNECT_INTERRUPT,
            &sdIoConnectInterruptParam,sizeof(sdIoConnectInterruptParam),
            NULL,0,
            NULL,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_NO_SUCH_DEVICE;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDIOConnectInterrupt__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
        return apiStatus ;
    }
    else 
        return SD_API_STATUS_NO_SUCH_DEVICE ;
    
}

VOID SDBusAccess::SDIODisconnectInterrupt__X(SD_DEVICE_HANDLE hDevice)
{
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_IO_DISCONNECT_INTERRUPT,
            &hDevice,sizeof(hDevice),
            NULL,0,
            NULL,NULL);
        if (!fReturn)
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDIODisconnectInterrupt__X: Failed GetLastError() = %d \n"),GetLastError()));            
    }
}

SD_API_STATUS SDBusAccess::SDSetCardFeature__X(SD_DEVICE_HANDLE  hDevice,
    SD_SET_FEATURE_TYPE  CardFeature, PVOID pCardInfo, ULONG StructureSize)
{
    SD_API_STATUS apiStatus = SD_API_STATUS_SUCCESS ;
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        IO_SD_SET_CARD_FEATURE sdIoSetCardFeatureParam = {
                hDevice, CardFeature,pCardInfo,StructureSize
        };
        SetLastError(SD_API_STATUS_SUCCESS);
        BOOL fReturn= BusIoControl(l_pSDBusAccess->GetBusAccessHandle(),IOCTL_BUS_SD_SET_CARD_FEATURE,
            &sdIoSetCardFeatureParam,sizeof(sdIoSetCardFeatureParam),
            NULL,0,
            NULL,NULL);
        apiStatus = GetLastError();
        if (!fReturn) { // We failed on BusIoControl
            if (SD_API_SUCCESS(apiStatus))
                apiStatus = SD_API_STATUS_NO_SUCH_DEVICE;
            DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("BusIo for SDSetCardFeature__X: Failed GetLastError() = %d \n"),apiStatus));            
        }
        return apiStatus ;
    }
    else 
        return SD_API_STATUS_NO_SUCH_DEVICE ;
}

extern "C" 
SD_API_STATUS SDBusGetClientFunctions(PSDCARD_API_FUNCTIONS pClientFunctions)
{
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (pClientFunctions && pClientFunctions->dwSize>= sizeof(SDCARD_API_FUNCTIONS) && l_pSDBusAccess ) { 
        *pClientFunctions = *(PSDCARD_API_FUNCTIONS)l_pSDBusAccess;
        pClientFunctions->dwSize = sizeof(SDCARD_API_FUNCTIONS);
        return SD_API_STATUS_SUCCESS;
    }
    else
        return SD_API_STATUS_INVALID_PARAMETER;
}

extern "C"
HANDLE  GetBusAccessHandle()
{
    SDBusAccess * l_pSDBusAccess = g_pSDBusAccess;
    if (l_pSDBusAccess ) {
        return l_pSDBusAccess->GetBusAccessHandle();
    }
    else 
        return NULL;
}

