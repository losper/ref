//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//

// Copyright (c) 2002 BSQUARE Corporation.  All rights reserved.
// DO NOT REMOVE --- BEGIN EXTERNALLY DEVELOPED SOURCE CODE ID 40973--- DO NOT REMOVE

// SD Bus Access 


#pragma once

#include <SDCardDDK.h>
typedef PSD_BUS_REQUEST HBUS_REQUEST;

class SDBusAccess : public SDCARD_API_FUNCTIONS {
private:
    HANDLE m_hBusAccess;
    HANDLE m_hCallback;
public:
    SDBusAccess(LPCTSTR lpActivePath);
    ~SDBusAccess();
    BOOL    Init();
    HANDLE  GetCallbackHandle() { return m_hCallback; };
    HANDLE  GetBusAccessHandle() { return m_hBusAccess; };
    BOOL    CallSDBusDriver (__in  DWORD dwIoControlCode, __in_bcount_opt(nInBufferSize) LPVOID lpInBuffer, __in DWORD nInBufferSize, __out_bcount(nOutBufferSize) LPVOID lpOutBuffer,__in DWORD nOutBufferSize, __out LPDWORD lpBytesReturned,__in_opt LPOVERLAPPED lpOverlapped);
private:
    static BOOL WINAPI SDBusCallback(
        DWORD dwIoControlCode, LPVOID lpInBuf, DWORD nInBufSize, LPVOID lpOutBuf, DWORD nOutBufSize, LPDWORD lpBytesReturned, LPOVERLAPPED lpOverlapped
    );

    
    static SD_API_STATUS SDRegisterClient__X(SD_DEVICE_HANDLE                 hDevice, 
                                  PVOID                            pDeviceContext, 
                                  PSDCARD_CLIENT_REGISTRATION_INFO pInfo);

    static SD_API_STATUS SDSynchronousBusRequest__X(SD_DEVICE_HANDLE   hDevice, 
                                         UCHAR                 Command,
                                         DWORD                 Argument,
                                         SD_TRANSFER_CLASS     TransferClass,
                                         SD_RESPONSE_TYPE      ResponseType,
                                         PSD_COMMAND_RESPONSE  pResponse,
                                         ULONG                 NumBlocks,
                                         ULONG                 BlockSize,
                                         PUCHAR                pBuffer,
                                         DWORD                 Flags,
                                         DWORD dwSize,PPHYS_BUFF_LIST pPhysBuffList);

    static SD_API_STATUS SDBusRequest__X(SD_DEVICE_HANDLE         hHandle,
                              UCHAR                    Command,
                              DWORD                    Argument,
                              SD_TRANSFER_CLASS        TransferClass,
                              SD_RESPONSE_TYPE         ResponseType,
                              ULONG                    NumBlocks,
                              ULONG                    BlockSize,
                              PUCHAR                   pBuffer,
                              PSD_BUS_REQUEST_CALLBACK pCallback,
                              DWORD                    RequestParam,
                              HBUS_REQUEST            *phRequest,
                              DWORD                    Flags,
                              DWORD dwSize,PPHYS_BUFF_LIST pPhysBuffList);

    static BOOLEAN SDCancelBusRequest__X(HBUS_REQUEST  HhRequest);


    static VOID SDFreeBusRequest__X(HBUS_REQUEST  hRequest);

    static SD_API_STATUS SDBusRequestResponse__X(HANDLE hRequest, PSD_COMMAND_RESPONSE pSdCmdResp);
    
    static SD_API_STATUS SDCardInfoQuery__X( SD_DEVICE_HANDLE hHandle,
                                 SD_INFO_TYPE     InfoType,
                                 PVOID            pCardInfo,
                                 ULONG            StructureSize);

    static SD_API_STATUS SDReadWriteRegistersDirect__X(SD_DEVICE_HANDLE       hDevice,
                                            SD_IO_TRANSFER_TYPE    ReadWrite,
                                            UCHAR                  Function,
                                            DWORD                  Address,
                                            BOOLEAN                ReadAfterWrite,
                                            PUCHAR                 pBuffer,
                                            ULONG                  Length);

    static SD_API_STATUS SDGetTuple__X(SD_DEVICE_HANDLE hDevice,
                            UCHAR            TupleCode,
                            PUCHAR           pBuffer,
                            PULONG           pBufferSize,
                            BOOL             CommonCIS);


    static SD_API_STATUS SDIOConnectInterrupt__X(SD_DEVICE_HANDLE         hDevice, 
                                      PSD_INTERRUPT_CALLBACK   pIsrFunction);


    static VOID SDIODisconnectInterrupt__X(SD_DEVICE_HANDLE hDevice);


    static SD_API_STATUS SDSetCardFeature__X(SD_DEVICE_HANDLE     hDevice,
                                  SD_SET_FEATURE_TYPE  CardFeature,
                                  PVOID                pCardInfo,
                                  ULONG                StructureSize);
};

extern SDBusAccess * g_pSDBusAccess ;
SDBusAccess * CreateSDBusAcess(LPCTSTR lpActivePath);

