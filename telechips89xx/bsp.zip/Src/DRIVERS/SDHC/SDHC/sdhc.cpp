/*=====================================================================================
*
* @File Name	: SDHC.CPP
*
* @File Version	: SIGBYAHONG_SDHC_WINCE6_TCCXXXX_V2002
*
=====================================================================================*/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//

// Copyright (c) 2002 BSQUARE Corporation.  All rights reserved.
// DO NOT REMOVE --- BEGIN EXTERNALLY DEVELOPED SOURCE CODE ID 40973--- DO NOT REMOVE

// SDHC controller driver implementation

#include "SDCardDDK.h"
#include "SDHC.h"

#include "args.h"

#if defined(TCC83X)
#include "TCC83x_Virtual.h"
#elif defined(TCC79X)
#include "TCC79X_Virtual.h"
#elif defined(_TCC80x_)
#include "TCC80x_Virtual.h"
#endif
#include "TCC89x_Structures.h"
#include <bsp.h>
#include "tcc_ckc.h"
#if !defined(_TCC89x_)
#include "tca_ckc.h"
#endif
#include "tcc_gpioexp.h"
#include "tcc_gpio.h"

//#undef DEBUGMSG
//#define DEBUGMSG(a,b)	RETAILMSG(1,b)

#ifndef SHIP_BUILD
#define STR_MODULE _T("CSDHCBase::")
#define SETFNAME(name) LPCTSTR pszFname = STR_MODULE name _T(":")
#else
#define SETFNAME(name)
#endif

#ifdef DEBUG
#define MAKE_OPTION_STRING(x) _T(#x)

const LPCTSTR CSDHCBase::sc_rgpszOptions[SDHCDSlotOptionCount] = {
    MAKE_OPTION_STRING(SDHCDSetSlotPower),
    MAKE_OPTION_STRING(SDHCDSetSlotInterface),
    MAKE_OPTION_STRING(SDHCDEnableSDIOInterrupts),
    MAKE_OPTION_STRING(SDHCDDisableSDIOInterrupts),
    MAKE_OPTION_STRING(SDHCDAckSDIOInterrupt),
    MAKE_OPTION_STRING(SDHCDGetWriteProtectStatus),
    MAKE_OPTION_STRING(SDHCDQueryBlockCapability),
    MAKE_OPTION_STRING(SDHCDSetClockStateDuringIdle),
    MAKE_OPTION_STRING(SDHCDSetSlotPowerState),
    MAKE_OPTION_STRING(SDHCDGetSlotPowerState),
    MAKE_OPTION_STRING(SDHCDWakeOnSDIOInterrupts),
    MAKE_OPTION_STRING(SDHCDGetSlotInfo),
    MAKE_OPTION_STRING(SDHCDSetSlotInterfaceEx),
    MAKE_OPTION_STRING(SDHCAllocateDMABuffer),
    MAKE_OPTION_STRING(SDHCFreeDMABuffer),
};
#endif


CSDHCBase::CSDHCBase(
                     ) 
                     : m_regDevice()
{    
	m_hBusAccess				= NULL;
	m_cSlots					= 0;
	m_pSlots					= NULL;
	m_pSlotInfos				= NULL;
	m_pHCDContext				= NULL;
	//m_interfaceType = InterfaceTypeUndefined;
	//m_dwBusNumber = INVALID_BUS_NUMBER;
	m_hISRHandler				= NULL;
	m_dwSysIntr[0]				= SYSINTR_UNDEFINED;
	m_dwSysIntr[1]				= SYSINTR_UNDEFINED;
	m_dwControllerCount			= 0;
	m_dwMemBase0[0]				= 0;
	m_dwMemBase0[1]				= 0;
	m_dwMemLen0[0]				= 0;
	m_dwMemLen0[1]				= 0;	
	m_dwMemBase1[0]				= 0;
	m_dwMemBase1[1]				= 0;
	m_dwMemLen1[0]				= 0;
	m_dwMemLen1[1]				= 0;		
	m_dwIRQvalue[0]				= 0;
	m_dwIRQvalue[1]				= 0;
	m_dwPriority				= 0;

	m_hevInterrupt[0]			= NULL;
	m_hevInterrupt[1]			= NULL;
	m_htIST[0]					= NULL;
	m_htIST[1]					= NULL;

	m_cpsCurrent				= D0;

	m_fHardwareInitialized		= FALSE;
	m_fRegisteredWithBusDriver	= FALSE;
	m_fDriverShutdown			= FALSE;
	m_fInterruptInitialized[0]	= FALSE;
	m_fInterruptInitialized[1]	= FALSE;
}


CSDHCBase::~CSDHCBase(
                      )
{
    // We call PreDeinit just in case we are not being destroyed by
    // a call to SHC_PreDeinit.
    PreDeinit();

    if (m_fHardwareInitialized) {
        DeinitializeHardware();
    }

    if (m_pHCDContext) {
        // Cleanup the host context
        SDHCDDeleteContext(m_pHCDContext);
    }

    if (m_pSlots) delete [] m_pSlots;
    if (m_pSlotInfos) LocalFree(m_pSlotInfos);
    if (m_hBusAccess) CloseBusAccessHandle(m_hBusAccess);
}


BOOL
CSDHCBase::Init(
                LPCTSTR pszActiveKey
                )
{
    BOOL fRet = FALSE;
    SD_API_STATUS status;
    HKEY    hkDevice = NULL;

    hkDevice = OpenDeviceKey(pszActiveKey);
    if (!hkDevice || !m_regDevice.Open(hkDevice, _T(""))) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDHC: Failed to open device key\n")));
        goto EXIT;
    }

    // Get a handle to our parent bus.
    m_hBusAccess = CreateBusAccessHandle(pszActiveKey);
    if (m_hBusAccess == NULL) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDHC: Could not get handle to parent\n")));
        goto EXIT;
    }

    m_pSlotInfos = (PSDHC_SLOT_INFO) LocalAlloc(LPTR, 
        sizeof(SDHC_SLOT_INFO) * m_cSlots);
    if (m_pSlotInfos == NULL) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDHC Failed to allocate slot info objects\n")));
        goto EXIT;
    }

    status = SDHCDAllocateContext(m_cSlots, &m_pHCDContext);
    if (!SD_API_SUCCESS(status)) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDHC Failed to allocate context : 0x%08X \n"),
            status));
        goto EXIT;
    }
    
    // Set our extension 
    m_pHCDContext->pHCSpecificContext = this;

    if (!InitializeHardware()) {
        goto EXIT;
    }

    // Allocate slot objects
    m_pSlots = AllocateSlotObjects(m_cSlots);
    if (m_pSlots == NULL) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDHC Failed to allocate slot objects\n")));
        goto EXIT;
    }

	// eugeun_sdio
	DWORD i = 0;
	DWORD k;
	if((m_dwControllerCount > 0)&&(m_cSlots > 0))
	{
		for(i = 0; i < m_cSlots; i++)
		{
			PSDHC_SLOT_INFO	pSlotInfo = &m_pSlotInfos[i];
			PCSDHCSlotBase	pSlot = GetSlot(i);

			k = pSlotInfo->dwIPnum;
			if(!pSlot->Init(i, k, pSlotInfo->pucRegisters, m_pHCDContext, m_dwSysIntr[k], &m_regDevice))
			{
				DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDHC: slot init is failed\n")));
				goto EXIT;
			}
		}
	}
	else
		goto EXIT;

    // set the host controller name
    SDHCDSetHCName(m_pHCDContext, TEXT("SD Std Host"));

    // set init handler
    SDHCDSetControllerInitHandler(m_pHCDContext, CSDHCBase::SDHCInitialize);
    // set deinit handler    
    SDHCDSetControllerDeinitHandler(m_pHCDContext, CSDHCBase::SDHCDeinitialize);
    // set the Send packet handler
    SDHCDSetBusRequestHandler(m_pHCDContext, CSDHCBase::SDHCBusRequestHandler);   
    // set the cancel I/O handler
    SDHCDSetCancelIOHandler(m_pHCDContext, CSDHCBase::SDHCCancelIoHandler);   
    // set the slot option handler
    SDHCDSetSlotOptionHandler(m_pHCDContext, CSDHCBase::SDHCSlotOptionHandler);

    // These values must be set before calling SDHCDRegisterHostController()
    // because they are used during that call.
    m_dwPriority = m_regDevice.ValueDW(SDHC_PRIORITY_KEY, 
        SDHC_CARD_CONTROLLER_PRIORITY);

    // now register the host controller 
    status = SDHCDRegisterHostController(m_pHCDContext);

    if (!SD_API_SUCCESS(status)) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDHC Failed to register host controller: %0x08X \n"), 
            status));
        goto EXIT;
    }

    m_fRegisteredWithBusDriver = TRUE;
    fRet = TRUE;

EXIT:
    if (hkDevice) RegCloseKey(hkDevice);

    return fRet;
}


SD_API_STATUS
CSDHCBase::Start()
{
	SD_API_STATUS	status = SD_API_STATUS_INSUFFICIENT_RESOURCES;

	m_fDriverShutdown = FALSE;

	DWORD i = 0;
	DWORD k;
	if((m_dwControllerCount > 0)&&(m_cSlots > 0))
	{
		k = 0;
		while(i < m_dwControllerCount)
		{
			if(m_dwSlotCount[k] > 0)
			{
				// allocate the interrupt event
				m_hevInterrupt[k] = CreateEvent(NULL, FALSE, FALSE,NULL);
				if(m_hevInterrupt[k] ==  NULL)
					goto EXIT;

				// initialize the interrupt event
				if(!InterruptInitialize(m_dwSysIntr[k], m_hevInterrupt[k], NULL, 0))
					goto EXIT;
				
				m_fInterruptInitialized[k] = TRUE;
				
				i = i + 1;			
			}
			k = k + 1;
		}
	}
	else
		goto EXIT;
	
	// create the interrupt thread for controller interrupts
	if(m_dwSlotCount[0] > 0)
	{
		m_htIST[0] = CreateThread(NULL, 0, ISTStub0, this, 0, NULL);
		if(m_htIST[0]==NULL)
		{
			RETAILMSG(1, (_T("[SD          ] Create IST0 FAILED\r\n")));
			goto EXIT;
		}
	}
	if(m_dwSlotCount[1] > 0)
	{
		m_htIST[1] = CreateThread(NULL, 0, ISTStub1, this, 0, NULL);
		if(m_htIST[1]==NULL)
		{
			RETAILMSG(1, (_T("[SD          ] Create IST1 FAILED\r\n")));
			goto EXIT;
		}
	}

	HANDLE hTestMonitor;
	hTestMonitor = CreateThread(0, 0, (LPTHREAD_START_ROUTINE) CardDetectThreadStub, this, 0, NULL);
	if(hTestMonitor == NULL)
		RETAILMSG(1, (_T("[SD          ] Create CardDetectThread FAILED\r\n")));


	for(DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot)
	{
	    PCSDHCSlotBase pSlot = GetSlot(dwSlot);
	    status = pSlot->Start();
	    if(!SD_API_SUCCESS(status))
			goto EXIT;
	}

	i = 0;
	if((m_dwControllerCount > 0)&&(m_cSlots > 0))
	{
		k = 0;
		while(i < m_dwControllerCount)
		{
			if(m_dwSlotCount[k] > 0)
			{
				// wake up the interrupt thread to check the slot
				::SetInterruptEvent(m_dwSysIntr[k]);
				
				i = i + 1;
			}
			k = k + 1;
		}
	}
	status = SD_API_STATUS_SUCCESS;

	EXIT:
	if(!SD_API_SUCCESS(status)) {
            // Clean up
	    Stop();
	}

	return status;
}


SD_API_STATUS
CSDHCBase::Stop()
{
    // Mark for shutdown
    m_fDriverShutdown = TRUE;

	DWORD i = 0;
	DWORD k;
	if((m_dwControllerCount > 0)&&(m_cSlots > 0))
	{
		k = 0;
		while(i < m_dwControllerCount)
		{
			if(m_dwSlotCount[k] > 0)
			{
			    if(m_fInterruptInitialized[k])
				{
			        KernelIoControl(IOCTL_HAL_DISABLE_WAKE, &m_dwSysIntr[k], sizeof(m_dwSysIntr[k]), NULL, 0, NULL);
			        InterruptDisable(m_dwSysIntr[k]);
			    }
				
				// Clean up controller IST
				if(m_htIST[k])
				{    // Wake up the IST
					SetEvent(m_hevInterrupt[k]);
					WaitForSingleObject(m_htIST[k], INFINITE); 
					CloseHandle(m_htIST[k]);
					m_htIST[k] = NULL;
				}

			    // free controller interrupt event
			    if(m_hevInterrupt[k])
				{
			        CloseHandle(m_hevInterrupt[k]);
			        m_hevInterrupt[k] = NULL;
			    }


				i = i + 1;
			}
			k = k + 1;
		}
	}
	else
		return SD_API_STATUS_NO_SUCH_DEVICE;

	
    for(DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot)
	{
        PCSDHCSlotBase pSlot = GetSlot(dwSlot);
        pSlot->Stop();
    }

    return SD_API_STATUS_SUCCESS;
}


SD_API_STATUS 
CSDHCBase::SlotOptionHandler(
                             DWORD                 dwSlot, 
                             SD_SLOT_OPTION_CODE   sdOption, 
                             PVOID                 pData,
                             DWORD                 cbData
                             )
{
    SD_API_STATUS   status = SD_API_STATUS_SUCCESS;
    BOOL            fCallSlotsHandler = TRUE;

    Lock();
    Validate();
    PCSDHCSlotBase pSlot = GetSlot(dwSlot);

    DEBUGCHK(sdOption < dim(sc_rgpszOptions));
    DEBUGCHK(sc_rgpszOptions[sdOption] != NULL);
	DEBUGMSG(SDCARD_ZONE_INFO, (_T("CSDHCBase::SlotOptionHandler(slot=%u,option=%d)\n"),
            dwSlot,sdOption));

    switch (sdOption) {
    case SDHCDSetSlotPower: {
        if (cbData != sizeof(DWORD)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }

    case SDHCDSetSlotInterface: {
        if (cbData != sizeof(SD_CARD_INTERFACE)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }

    case SDHCDEnableSDIOInterrupts:
    case SDHCDDisableSDIOInterrupts:
    case SDHCDAckSDIOInterrupt:
        if (pData || cbData != 0) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;

    case SDHCDGetWriteProtectStatus: {
        if (cbData != sizeof(SD_CARD_INTERFACE)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }

    case SDHCDQueryBlockCapability: {
        if (cbData != sizeof(SD_HOST_BLOCK_CAPABILITY)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }

    case SDHCDSetSlotPowerState: {
        if (cbData != sizeof(CEDEVICE_POWER_STATE)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }

        PCEDEVICE_POWER_STATE pcps = (PCEDEVICE_POWER_STATE) pData;

        if (*pcps < m_cpsCurrent) {
            // Move controller to higher power state initially since
            // it will need to be powered for the slot to access
            // registers.
            SetControllerPowerState(*pcps);
        }

        status = pSlot->SlotOptionHandler(sdOption, pData, cbData);

        // Set the power state based on current conditions. Note that 
        // the slot may have gone to a state different from what was 
        // requested.
        CEDEVICE_POWER_STATE cps = DetermineRequiredControllerPowerState();
        SetControllerPowerState(cps);
        fCallSlotsHandler = FALSE;
        break;
    }

    case SDHCDGetSlotPowerState: {
        if (cbData != sizeof(CEDEVICE_POWER_STATE)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }

    case SDHCDWakeOnSDIOInterrupts: {
        if (cbData != sizeof(BOOL)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }

    case SDHCDGetSlotInfo: {
        if (cbData != sizeof(SDCARD_HC_SLOT_INFO)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }
    case SDHCDSetSlotInterfaceEx: {
        if (cbData != sizeof(SD_CARD_INTERFACE_EX)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }
    case SDHCAllocateDMABuffer: {
        if (pData==NULL || cbData != sizeof(SD_HOST_ALLOC_FREE_DMA_BUFFER)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
        break;
    }
    case SDHCFreeDMABuffer:{
        if (pData==NULL || cbData != sizeof(SD_HOST_ALLOC_FREE_DMA_BUFFER)) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
      break;
    }
    
    default:
        break;
    }

    if (SD_API_SUCCESS(status) && fCallSlotsHandler) {
        // Call the slots handler to do the real work.
        __try {
            status = pSlot->SlotOptionHandler(sdOption, pData, cbData);
        }__except (SDProcessException(GetExceptionInformation())) {
            status = SD_API_STATUS_INVALID_PARAMETER;
        }
    }

    Unlock();

    return status;
}


VOID
CSDHCBase::PowerDown(
                     )
{
	Validate();

#if 0
	BOOTARGS *gpBOOTARGS = (BOOTARGS*)BSPARGS_STARTADDR;

	//	if( gpBOOTARGS->mMemBuf.CHARBUF == BSP_SUSPEND_KEY )
	//	if( gpBOOTARGS->mMemBuf.CHARBUF == BSP_SUSPEND_KEY || (gpBOOTARGS->mMemBuf.CHARBUF != BSP_SUSPEND_KEY && gpBOOTARGS->mMemBuf.CHARBUF != BSP_SLEEP_KEY))
	if(gpBOOTARGS->mMemBuf.CHARBUF == BSP_SUSPEND_KEY)
	{
			m_fSuspend = TRUE;

		for(DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot)
		{
			PCSDHCSlotBase pSlot = GetSlot(dwSlot);
			pSlot->PowerDown();
		}
	}
	else
	{
		m_fSuspend = FALSE;
	}
//#else
	for (DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot) {
	PCSDHCSlotBase pSlot = GetSlot(dwSlot);
	pSlot->PowerDown();
	}

	CEDEVICE_POWER_STATE cps = DetermineRequiredControllerPowerState();
	SetControllerPowerState(cps);
#endif
}


VOID
CSDHCBase::PowerUp(
                   )
{
	Validate();

#if 0
	if(m_fSuspend == TRUE)	// suspend mode
	{
		InitializeTccHardware(TRUE);

		for(DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot)
		{
			PCSDHCSlotBase pSlot = GetSlot(dwSlot);
			pSlot->PowerUp();
		}
	}
//#elif 0
	for (DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot) {
	PCSDHCSlotBase pSlot = GetSlot(dwSlot);

	CEDEVICE_POWER_STATE cpsRequired = pSlot->GetPowerUpRequirement();
	if (cpsRequired < m_cpsCurrent) {
	// Move controller to higher power state initially since
	// it will need to be powered for the slot to access
	// registers.
	SetControllerPowerState(cpsRequired);
	}

	pSlot->PowerUp();
	}
#endif
}


VOID
CSDHCBase::PreDeinit(
                     )
{
    if (m_fRegisteredWithBusDriver) {
        if (m_fDriverShutdown == FALSE) {
            // Deregister the host controller
            SDHCDDeregisterHostController(m_pHCDContext);
        }
        // else the bus driver itself already deregistered us.

        m_fRegisteredWithBusDriver = FALSE;
    }
}


#define	_tca_delay()				{ volatile int i; for (i=0; i<100; i++); }
VOID CSDHCBase::InitializeTccHardware(BOOL fCardDetect)
{
#if defined(TCC83X)
	HwGSEL_C = HwGSEL_C_SD4_4_SD4_4;
	HwSD_CFG = HwSD_CFG_DET0 | HwSD_CFG_DET1;
	tca_ckc_com_setperi(PERI_SDMMC,MHz,48,DIRECTPLL1); //47MHz
	tca_ckc_com_setperibus(RB_SDMMC,1); //BITSET(HwBCLKCTR,HwBCLKCTR_SD_ON);

	BITSET(HwSWRESET,HwSWRESET_SD_ON);
	Sleep(100);
	BITCLR(HwSWRESET,HwSWRESET_SD_ON);
	Sleep(100);


#elif defined(TCC79X)
	//====================================================
	//	H/W pin setting for SD Slot #01
	//====================================================
	BITCSET(HwPORTCFG2,HwPORTCFG2_HPCTRL(0xF),HwPORTCFG2_HPCTRL(3));	// SD_CLK(1), SD_CMD(1), SD_D0(1), SD_D2(1), SD_D3(1)
	BITCSET(HwPORTCFG13,HwPORTCFG13_HPCSN(0xF),HwPORTCFG13_HPCSN(3));	// SD_D1(1)
	BITCSET(HwPORTCFG3, HwPORTCFG3_HPXD4(0xF), HwPORTCFG3_HPXD4(1));		// GPIO_F[4] for SD_CD(1)
	BITCSET(HwPORTCFG3, HwPORTCFG3_HPXD5(0xF), HwPORTCFG3_HPXD5(1));		// GPIO_F[5] for SD_WP(1)
	BITCLR(HwGPFEN,Hw4|Hw5);

	//====================================================
	//	H/W pin setting for SD Slot #02
	//====================================================
	#if 0
	BITCSET(HwPORTCFG2, HwPORTCFG2_HPXD17(0xF), HwPORTCFG2_HPXD17(3));		// SD_CLK(2), SD_CMD(2)
	BITCSET(HwPORTCFG2, HwPORTCFG2_HPXD11(0xF), HwPORTCFG2_HPXD11(3));		// SD_D0(2), SD_D1(2), SD_D2(2), SD_D3(2)
	BITCSET(HwPORTCFG3, HwPORTCFG3_HPXD3(0xF), HwPORTCFG3_HPXD3(1));		// GPIO_F[3] for SD_CD(2)
	BITCSET(HwPORTCFG10, HwPORTCFG10_UTXD2(0xF), HwPORTCFG10_UTXD2(1));		// GPIO_E[8] for SD_WP(2)
	BITCLR(HwGPFEN,Hw3);
	BITCLR(HwGPEEN,Hw8);
	#endif

	//tca_ckc_com_setperi(PERI_SDMMC,MHz,12,DIRECTXIN); //HwPCK_SDMMC = 0x14000000;
	tca_ckc_com_setperi(PERI_SDMMC,MHz,SDHC_SOURCE_CLOCK_FREQ_MHz,DIRECTPLL1);	// 49.8MHz
	//HwPCK_SDMMC = 0x1F000000;
	tca_ckc_com_setperibus(RB_SDMMC,1); //BITSET(HwBCLKCTR,HwBCLKCTR_SD_ON);

	BITSET(HwSWRESET,HwSWRESET_SD_ON);
	//Sleep(1);
	_tca_delay();	// for wake up from suspend
	BITCLR(HwSWRESET,HwSWRESET_SD_ON);
	//Sleep(1);
	_tca_delay();

	if( fCardDetect )
		CardDetect();
	else
		HwSD_PORTCTRL = HwSD_PORTCTRL_CD(1)|HwSD_PORTCTRL_CD(0)|HwSD_PORTCTRL_SLOT1(2)|HwSD_PORTCTRL_SLOT0(1);

	
#elif defined(_TCC80x_)										// eugeun_sdio
	HwGPIOPS_DOE	= HwZERO;
	HwSD_CFG		= Hw27 | Hw26;
	HwGPIOPS_FS1	|= 0xFFFF;								// SD Slot #01 : DATA[3:0], CMD, CLK, DET, WP
	
	tca_ckc_com_setperi(PERI_SDMMC, MHz, 48, DIRECTPLL2);	// (PLL2 = 240Mhz) / 5 = 48Mhz
	tca_ckc_com_setperi(PERI_SDMMC1, MHz, 48, DIRECTPLL2);	// (PLL2 = 240Mhz) / 5 = 48Mhz
	tca_ckc_com_setperibus(RB_SDMMC,1);
	
	BITSET(HwSWRESET,HwSWRESET_SD_ON);
	_tca_delay();
	BITCLR(HwSWRESET,HwSWRESET_SD_ON);
	_tca_delay();

#elif defined(TCC89XX)
	pGPIO					= (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	pSDCTRL					= (PSDCHCTRL)tcc_allocbaseaddress((unsigned int)&HwSDCHCTRL_BASE);
	PIOBUSCFG	pIOBUSCfg	= (PIOBUSCFG)tcc_allocbaseaddress((unsigned int)&HwIOBUSCFG_BASE);

	tcc_ckc_setiobus(RB_SDMMCCONTROLLER,1);

	// SDMMC Slot Power Up =========================================
	//==============================================================
	{
        HANDLE hGXP = CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);

        if(INVALID_HANDLE_VALUE != hGXP)
        {
            DWORD dwByteReturned;

            GXPINFO GxpInfo;
            GxpInfo.uiDevice	= PCA9539LOW;
			//GxpInfo.uiPort		= SD0;
            GxpInfo.uiPort		= SD0|SD1;
            GxpInfo.uiState		= ON;
			
            if(FALSE == WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL))
            {
                RETAILMSG(1,(TEXT("[SD          ]ERROR: SD Power On\r\n")));
            }
            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("[SD          ]ERROR: SD Driver: Can't open GXP Driver!!\n")));
        }		
    }

	//SLOT[0] SDMMC Interface Port Number 2 ========================
	//==============================================================
	// SD_CLK(2), SD_CMD(2), SD_D0(2), SD_D1(2), SD_D2(2) SD_D3(2)
	BITCSET(pGPIO->GPEFN1, 0xFFFF0000, 0x22220000);
	BITCSET(pGPIO->GPEFN2, 0x00FF0000, 0x00220000);
	// SD_CD(2)
	BITSCLR(pGPIO->GPAEN, Hw6, Hw6);
	BITCSET(pGPIO->GPAFN0, 0x0F000000, 0x00000000);

	#if 0
	//SLOT[1] SDMMC Interface Port Number 5 ========================
	//==============================================================
	// SD_CLK(5), SD_CMD(5),, SD_D0(5), SD_D1(5), SD_D2(5) SD_D3(5)
	BITCSET(pGPIO->GPBFN0, 0x0000FFFF, 0x00002222);
	BITCSET(pGPIO->GPBFN1, 0x00FF0000, 0x00220000);
	// SD_CD(5)
	BITSCLR(pGPIO->GPAEN, Hw10, Hw10);
	BITCSET(pGPIO->GPAFN1, 0x00000F00, 0x00000000);
	#endif

	BITCSET(pSDCTRL->SDPORTCTRL, 0xFFFFFFFF, 0xF0003512);
	pSDCTRL->SDPORTDLY0 = 0x00000000;
	pSDCTRL->SDPORTDLY1 = 0x00000000;
	pSDCTRL->SDPORTDLY2 = 0x00000000;
	pSDCTRL->SDPORTDLY3 = 0x00000000;

	tcc_ckc_setperi(PERI_SDMMC0, 1/*ENABLE*/, 480000/*48MH*/, PCDIRECTPLL3);
	//tcc_ckc_setperi(PERI_SDMMC1, 1/*ENABLE*/, 480000/*48MH*/, PCDIRECTPLL3);	
	_tca_delay();
	
	//IOBUS AHB Clock Enable Reg.(0xF05F5010)
	BITSET(pIOBUSCfg->HCLKEN0, Hw4);
#endif
}


BOOL 
CSDHCBase::InitializeHardware(
                              )
{
	BOOL fRet = FALSE;
	
	InitializeTccHardware(FALSE);

	DWORD i = 0;
	DWORD k;
	if((m_dwControllerCount > 0)&&(m_cSlots > 0))
	{
		k = 0;
		while(i < m_dwControllerCount)
		{
			if(m_dwSlotCount[k] > 0)
			{
				BOOL fSuccess = KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &m_dwIRQvalue[k], sizeof(DWORD), &m_dwSysIntr[k], sizeof(DWORD), NULL);
				if(!fSuccess)
				{
					RETAILMSG(1, (_T("[SD          ]KernelIoControl IOCTL_HAL_REQUEST_SYSINTR failed!\r\n")));
					goto EXIT;
				}
				i = i + 1;
			}
			k = k + 1;
		}
	}
	else
		goto EXIT;
	
	i = 0;
	if((m_dwControllerCount > 0)&&(m_cSlots > 0))
	{
		k = 0;
	    while(i < m_dwSlotCount[0])
		{
			if((m_dwMemBase0[k]!=0)&&(m_dwMemLen0[k]!=0))
			{
				m_pSlotInfos[i].pucRegisters	= (UCHAR *)m_dwMemBase0[k];
				m_pSlotInfos[i].dwExtraInfo		= m_dwMemLen0[k];
				m_pSlotInfos[i].dwIPnum			= 0;
				i = i + 1;
			}
			k = k + 1;
	    }
		
		k = 0;
	    while(i < m_cSlots)
		{
			if((m_dwMemBase1[k]!=0)&&(m_dwMemLen1[k]!=0))
			{
				m_pSlotInfos[i].pucRegisters	= (UCHAR *)m_dwMemBase1[k];
				m_pSlotInfos[i].dwExtraInfo		= m_dwMemLen1[k];
				m_pSlotInfos[i].dwIPnum			= 1;
				i = i + 1;
			}
			k = k + 1;
	    }

		m_fHardwareInitialized = TRUE;
		fRet = TRUE;
	}
	else
		goto EXIT;
	
EXIT:
	return fRet;
}


BOOL
CSDHCBase::DeinitializeHardware(
                                )
{
	DEBUGCHK(m_hBusAccess);
	PREFAST_DEBUGCHK(m_pSlotInfos);
	ValidateSlotCount();

#if 0
	for (DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot) {
	PVOID pvRegisters = (PVOID) m_pSlotInfos[dwSlot].pucRegisters;
	DWORD dwLen = m_pSlotInfos[dwSlot].dwExtraInfo;
	if (pvRegisters) MmUnmapIoSpace(pvRegisters, dwLen);
	}
#endif
	if(m_hISRHandler)
		FreeIntChainHandler(m_hISRHandler);

	return TRUE;
}

/************************************************************************
* FUNCTION                                                                
*				CSDHCBase::CardDetect()
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
VOID CSDHCBase::CardDetect()
{
#if defined(TCC83X)
	unsigned long sdCfg = HwSD_CFG_DET0|HwSD_CFG_DET1;

	if( !(HwGDATA_C&Hw12) )		// card detection for slot 0
	{
		sdCfg &= (~HwSD_CFG_DET0);

		if( HwGDATA_C & Hw14 )		// write protection for slot 0
			sdCfg |= HwSD_CFG_WP0;
		else
			sdCfg &= (~HwSD_CFG_WP0);
	}

	if( !(HwGDATA_C&Hw13) )		// card detection for slot 1
	{
		sdCfg &= (~HwSD_CFG_DET1);

		if( HwGDATA_C & Hw15 )		// card protection for slot 1
			sdCfg |= HwSD_CFG_WP1;
		else
			sdCfg &= (~HwSD_CFG_WP1);
	}

	HwSD_CFG = sdCfg;


#elif defined(TCC79X)
	unsigned long sd_portCtrl = (HwSD_PORTCTRL_CD(1) | HwSD_PORTCTRL_CD(0) | HwSD_PORTCTRL_SLOT1(2) | HwSD_PORTCTRL_SLOT0(1));

	//====================================================
	//	Card detection for SD Slot #01
	//====================================================
	if(!(HwGPFDAT&Hw4) )	// card detection for slot 0
	{
		sd_portCtrl &= (~(HwSD_PORTCTRL_CD(0)));

		if(HwGPFDAT&Hw5)	// write protection for slot 0
			sd_portCtrl |= HwSD_PORTCTRL_WP(0);
		else
			sd_portCtrl &= (~(HwSD_PORTCTRL_WP(0)));
	}

	//====================================================
	//	Card detection for SD Slot #02
	//====================================================
	#if 0
	if(!(HwGPFDAT&Hw3) )	// card detection for slot 1
	{
		sd_portCtrl &= (~(HwSD_PORTCTRL_CD(1)));
	
		if(HwGPEDAT&Hw8)	// write protection for slot 1
			sd_portCtrl |= HwSD_PORTCTRL_WP(1);
		else
			sd_portCtrl &= (~(HwSD_PORTCTRL_WP(1)));
	}
	#endif

	HwSD_PORTCTRL = sd_portCtrl;


#elif defined(_TCC80x_)					// eugeun_sdio
	unsigned long sdCfg = Hw27|Hw26;
	if(!(HwGPIOPS_DAT&Hw6))
	{
		sdCfg &= (~Hw27);								// card Inserted.
		
		if(HwGPIOPS_DAT & Hw7)		sdCfg |= Hw25;		//Write Protect.
		else						sdCfg &= (~Hw25);	//Write Enable.
	}

	if(!(HwGPIOPS_DAT&Hw8))
	{
		sdCfg &= (~Hw26);								// card Inserted.
		
		if(HwGPIOPS_DAT & Hw9)		sdCfg |= Hw24;		//Write Protect.
		else						sdCfg &= (~Hw24);	//Write Enable.
	}
	
	HwSD_CFG = sdCfg;

#elif defined(TCC89XX)
	unsigned long sdCfg = 0;

	//====================================================
	//	Card detection for SD Slot #01
	//====================================================	
	if(!(pGPIO->GPADAT&Hw6))
	{
		BITCLR(pSDCTRL->SDPORTCTRL, Hw28);	// card Inserted.
	}
	else
	{
		BITSET(pSDCTRL->SDPORTCTRL, Hw28);	// card Removed.
	}
	#if 0
	//====================================================
	//	Card detection for SD Slot #02
	//====================================================	
	if(!(pGPIO->GPADAT&Hw10))
	{
		BITCLR(pSDCTRL->SDPORTCTRL, Hw30);	// card Inserted.
	}
	else
	{
		BITSET(pSDCTRL->SDPORTCTRL, Hw30);	// card Removed.
	}
	#endif
#endif
}

/************************************************************************
* FUNCTION                                                                
*				CSDHCBase::CardDetectThread()
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
DWORD CSDHCBase::CardDetectThread()
{
	SETFNAME(_T("CardDetect"));

	DEBUGMSG( 1, (TEXT("%s Thread Start\n"),pszFname) );

	if(!CeSetThreadPriority(GetCurrentThread(), m_dwPriority))
	{
		RETAILMSG(1, (TEXT("[SD          ]%s Failed to set CEThreadPriority\n"), pszFname));
	}

	while(m_fDriverShutdown==FALSE)
	{
		Sleep(500);
		//for (DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot) {
		//	PCSDHCSlotBase pSlot = GetSlot(dwSlot);
		//	pSlot->DumpRegisters();
		//}
		// eugeun_sdio
		//RETAILMSG(1, (TEXT("[SD          ] CardDetecThread() \n")));
		CardDetect();
	}

	DEBUGMSG( 1, (TEXT("%s Thread Stop\n"),pszFname) );

	return 0;
}

/************************************************************************
* FUNCTION                                                                
*				CSDHCBase::IST0()
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
DWORD CSDHCBase::IST0()
{
    SETFNAME(_T("IST"));

    DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("%s Thread Starting\n"), pszFname));

    if(!CeSetThreadPriority(GetCurrentThread(), m_dwPriority))
        RETAILMSG(1, (TEXT("[SD          ]%s Failed to set CEThreadPriority\n"), pszFname));

    while(TRUE)
	{
        DEBUGCHK(m_hevInterrupt[0]);
        DWORD dwWaitStatus = WaitForSingleObject(m_hevInterrupt[0], INFINITE);
// eugeun_test
//RETAILMSG(1, (TEXT("[SD          ] IST0() \n")));		
        Validate();

        if(WAIT_OBJECT_0 != dwWaitStatus)
		{
            RETAILMSG(1, (TEXT("[SD          ]%s Wait Failed! 0x%08X\n"), pszFname, dwWaitStatus));
            break;
        }
        else if(m_fDriverShutdown)
		{
            break;
        }
        else
		{
            HandleInterrupt0();
            InterruptDone(m_dwSysIntr[0]);
        }
    }
RETAILMSG(1, (TEXT("[SD          ]IST0() Thread Exiting\n")));		//eugeun_sdio DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("%s Thread Exiting\n"), pszFname));
    return 0;
}

/************************************************************************
* FUNCTION                                                                
*				CSDHCBase::IST1()
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
DWORD CSDHCBase::IST1()
{
    SETFNAME(_T("IST"));

    DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("%s Thread Starting\n"), pszFname));

    if(!CeSetThreadPriority(GetCurrentThread(), m_dwPriority))
        RETAILMSG(1, (TEXT("[SD          ]%s Failed to set CEThreadPriority\n"), pszFname));

    while(TRUE)
	{
        DEBUGCHK(m_hevInterrupt[1]);
        DWORD dwWaitStatus = WaitForSingleObject(m_hevInterrupt[1], INFINITE);
// eugeun_test
//RETAILMSG(1, (TEXT("[SD          ] IST1() \n")));		
        Validate();

        if(WAIT_OBJECT_0 != dwWaitStatus)
		{
            RETAILMSG(1, (TEXT("[SD          ]%s Wait Failed! 0x%08X\n"), pszFname, dwWaitStatus));
            break;
        }
        else if(m_fDriverShutdown)
		{
            break;
        }
        else
		{
            HandleInterrupt1();
            InterruptDone(m_dwSysIntr[1]);
        }
    }
RETAILMSG(1, (TEXT("[SD          ]IST1() Thread Exiting\n")));		//eugeun_sdio DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("%s Thread Exiting\n"), pszFname));
    return 0;
}

/************************************************************************
* FUNCTION                                                                
*				CSDHCBase::HandleInterrupt0()
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
VOID CSDHCBase::HandleInterrupt0() 
{
	Lock();

	// Use slot zero to get the shared global interrupt register
	DWORD dwIntStatus = 0;
	DWORD i;
	do
	{
		DEBUGMSG(SDHC_INTERRUPT_ZONE, (TEXT("CSDHCBase::HandleInterrupt: Slot Interrupt_Status=0x%X\n"), dwIntStatus));
		i = 0;
		for (DWORD k = 0; k < m_cSlots; ++k)
		{
			PCSDHCSlotBase pSlot = GetSlot(k);
			if(pSlot->m_dwIPnum==0)
			{
				dwIntStatus = pSlot->ReadControllerInterrupts();
//RETAILMSG(1, (TEXT("[SD          ] HandleInterrupt0 dwIntStatus(0x%x) \n"),dwIntStatus));		// eugeun_test				
				if( ((1 << i) & dwIntStatus) || pSlot->NeedsServicing() )
				{
					pSlot->HandleInterrupt();
				}
				i = i + 1;
			}
		}
	}while (dwIntStatus);

	Unlock();
}

/************************************************************************
* FUNCTION                                                                
*				CSDHCBase::HandleInterrupt1()
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
VOID CSDHCBase::HandleInterrupt1() 
{
	Lock();

	// Use slot zero to get the shared global interrupt register
	DWORD dwIntStatus = 0;
	DWORD i;
	do
	{
		DEBUGMSG(SDHC_INTERRUPT_ZONE, (TEXT("CSDHCBase::HandleInterrupt: Slot Interrupt_Status=0x%X\n"), dwIntStatus));
		i = 0;
		for (DWORD k = 0; k < m_cSlots; ++k)
		{
			PCSDHCSlotBase pSlot = GetSlot(k);
			if(pSlot->m_dwIPnum==1)
			{
				dwIntStatus = pSlot->ReadControllerInterrupts();
//RETAILMSG(1, (TEXT("[SD          ] HandleInterrupt1 dwIntStatus(0x%x) \n"),dwIntStatus));		// eugeun_test				
				if( ((1 << i) & dwIntStatus) || pSlot->NeedsServicing() )
				{
					pSlot->HandleInterrupt();
				}
				i = i + 1;
			}
		}
	}while (dwIntStatus);

	Unlock();
}


DWORD
CSDHCBase::DetermineSlotCount(
                              )
{
#if 0	//eugeun_sdio
    SETFNAME(_T("DetermineSlotCount"));

    DWORD cSlots = 0;

    // Read window information
    DDKWINDOWINFO wini = { sizeof(wini) };
    DWORD dwStatus = DDKReg_GetWindowInfo(m_regDevice, &wini);
    if (dwStatus != ERROR_SUCCESS) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (_T("%s Error getting window information\r\n"),
            pszFname));
        goto EXIT;
    }

	{
		DWORD i;
        TCHAR szDll[MAX_PATH];
	
        if (m_regDevice.ValueSZ(DEVLOAD_DLLNAME_VALNAME, szDll, dim(szDll))) {
            szDll[dim(szDll) - 1] = 0; // Null-terminate
		    DEBUGMSG(SDCARD_ZONE_ERROR, (_T("SDHC_dll=\"%s\"\n"),szDll ) );
        }
	    //DEBUGMSG(SDCARD_ZONE_ERROR, (_T("wini.cbSize %d\n"),wini.cbSize ) );
    	//DEBUGMSG(SDCARD_ZONE_ERROR, (_T("wini.dwBusNumber %d\n"),wini.dwBusNumber ) );
	    //DEBUGMSG(SDCARD_ZONE_ERROR, (_T("wini.dwInterfaceType %d\n"),wini.dwInterfaceType ) );
    	DEBUGMSG(SDCARD_ZONE_ERROR, (_T("wini.dwNumIoWindows %d\n"),wini.dwNumIoWindows ) );
	    DEBUGMSG(SDCARD_ZONE_ERROR, (_T("wini.dwNumMemWindows %d\n"),wini.dwNumMemWindows ) );
		for(i=0;i<wini.dwNumMemWindows;i++)
		{
		    DEBUGMSG(SDCARD_ZONE_ERROR, (_T("wini.memWindows[%d].dwBase %X\n"),i,wini.memWindows[i].dwBase ) );
		    DEBUGMSG(SDCARD_ZONE_ERROR, (_T("wini.memWindows[%d].dwLen %X\n"),i,wini.memWindows[i].dwLen ) );
		}
    }

    cSlots = wini.dwNumMemWindows;

    if (cSlots == 0) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (_T("%s There were not any reported slots.\r\n"),
            pszFname));
        goto EXIT;
    }

EXIT:
    return cSlots;
#endif
		return 0;
}




DWORD 
CSDHCBase::DetermineFirstSlotWindow(
                                    PDDKWINDOWINFO pwini
                                    )
{
#if 0	//eugeun_sdio
    PREFAST_DEBUGCHK(pwini);
    DEBUGCHK(pwini->dwNumMemWindows >= m_cSlots);
    DEBUGCHK(pwini->dwNumMemWindows > 0);

    DWORD dwSlotZeroWindow = 0;

    return dwSlotZeroWindow;
#else
	return 0;
#endif
}


CEDEVICE_POWER_STATE
CSDHCBase::DetermineRequiredControllerPowerState(
    )
{
    CEDEVICE_POWER_STATE cps = D4;

    for (DWORD dwSlot = 0; dwSlot < m_cSlots; ++dwSlot) {
        PCSDHCSlotBase pSlot = GetSlot(dwSlot);
        cps = min(cps, pSlot->GetPowerState());
    }

    return cps;
}


SD_API_STATUS
CSDHCBase::SetControllerPowerState(
                                   CEDEVICE_POWER_STATE cpsNew
                                   )
{
	DWORD i = 0;
	DWORD k = 0;
	if(cpsNew != m_cpsCurrent)
	{
		switch (cpsNew)
		{
			case D0:
			case D4:
				while(i < m_dwControllerCount)
				{
					if(m_dwSlotCount[k] > 0)
					{
						KernelIoControl(IOCTL_HAL_DISABLE_WAKE, &m_dwSysIntr[k], sizeof(m_dwSysIntr[k]), NULL, 0, NULL);
						i = i + 1;
					}
					k = k + 1;
				}
			break;

			case D3:
				while(i < m_dwControllerCount)
				{
					if(m_dwSlotCount[k] > 0)
					{
						KernelIoControl(IOCTL_HAL_ENABLE_WAKE, &m_dwSysIntr[k], sizeof(m_dwSysIntr[k]), NULL, 0, NULL);
						i = i + 1;
					}
					k = k + 1;
				}
			break;
        }

		SetDevicePowerState(m_hBusAccess, cpsNew, NULL);
		m_cpsCurrent = cpsNew;
    }

	return SD_API_STATUS_SUCCESS;
}


#ifdef DEBUG
VOID 
CSDHCBase::Validate(
                    )
{
    DEBUGCHK(m_regDevice.IsOK());
    DEBUGCHK(m_hBusAccess);
    ValidateSlotCount();
    DEBUGCHK(m_pSlots);
    DEBUGCHK(m_pSlotInfos);
    DEBUGCHK(m_pHCDContext);
   // DEBUGCHK(m_dwBusNumber != INVALID_BUS_NUMBER);
   // DEBUGCHK(m_interfaceType != InterfaceTypeUndefined);
//    DEBUGCHK(m_dwSysIntr != SYSINTR_UNDEFINED);
    DEBUGCHK(VALID_DX(m_cpsCurrent));

    if (m_fRegisteredWithBusDriver && !m_fDriverShutdown) {
        DEBUGCHK(m_htIST);
        DEBUGCHK(m_fHardwareInitialized);
        DEBUGCHK(m_fInterruptInitialized);
    }
}
#endif


// Get the creation proc address and call it
PCSDHCBase
CSDHCBase::CreateSDHCControllerObject(
    LPCTSTR pszActiveKey
    )
{
#if 1
	// eugeun_sdio
	CSDHCBase	*pCSDHCBase		= new CSDHCBase;
	ULONG		datasize		= sizeof(ULONG);
	ULONG		kvaluetype;
	DWORD		sdhcNum, slotCountForIP0, slotCountForIP1, irq0, irq1;
	DWORD		memBase0_0, memBase0_1, memBase1_0, memBase1_1, memLen0_0, memLen0_1, memLen1_0, memLen1_1;
	
	// Open Register File ==========================================================================
	//==============================================================================================
	HKEY hKey = OpenDeviceKey((LPCTSTR)pszActiveKey);
	if(!hKey)
	{
		RETAILMSG(1, (TEXT("[SD          ]Failed to open devkeypath, SHC_Init failed\r\n")));
		RegCloseKey(hKey);
		return (NULL);
	}

	// Get SD Host Controller Number ===============================================================
	//==============================================================================================
	datasize = sizeof(DWORD);
	if(RegQueryValueEx(hKey, L"SdhcIPcount", NULL, &kvaluetype, (LPBYTE)&sdhcNum, &datasize))
	{
		RETAILMSG(1, (TEXT("[SD          ]Failed to get SdhcNum value, SHC_Init failed\r\n")));
		RegCloseKey(hKey);
		return (NULL);
	}
	pCSDHCBase->m_dwControllerCount	= sdhcNum;
	
	// Get Total Slot Number =======================================================================
	//==============================================================================================	
	datasize = sizeof(DWORD);
	if(RegQueryValueEx(hKey, L"SlotCount_IP0", NULL, &kvaluetype, (LPBYTE)&slotCountForIP0, &datasize))
		slotCountForIP0 = 0;

	if(RegQueryValueEx(hKey, L"SlotCount_IP1", NULL, &kvaluetype, (LPBYTE)&slotCountForIP1, &datasize))
		slotCountForIP1 = 0;

	pCSDHCBase->m_dwSlotCount[0] = slotCountForIP0;
	pCSDHCBase->m_dwSlotCount[1] = slotCountForIP1;
	pCSDHCBase->m_cSlots = slotCountForIP0 + slotCountForIP1;
	if(pCSDHCBase->m_cSlots > SDHC_MAX_SLOTS)
	{
		RETAILMSG(1, (TEXT("[SD          ]Too many Slot number.., SHC_Init failed\r\n")));
		return (NULL);
	}	

	// Get IRQ =====================================================================================
	//==============================================================================================	
	datasize = sizeof(DWORD);
	if(RegQueryValueEx(hKey, L"Irq0", NULL, &kvaluetype, (LPBYTE)&irq0, &datasize))
		irq0 = 0;

	if(RegQueryValueEx(hKey, L"Irq1", NULL, &kvaluetype, (LPBYTE)&irq1, &datasize))
		irq1 = 0;

	pCSDHCBase->m_dwIRQvalue[0] = irq0;
	pCSDHCBase->m_dwIRQvalue[1] = irq1;
	
	// Get Address Base ============================================================================
	//==============================================================================================
	datasize = sizeof(DWORD);
	if(RegQueryValueEx(hKey, L"MemBase0_0", NULL, &kvaluetype, (LPBYTE)&memBase0_0, &datasize))
		memBase0_0 = 0;
	else
		memBase0_0 = tcc_allocbaseaddress((unsigned int)memBase0_0);

	if(RegQueryValueEx(hKey, L"MemBase0_1", NULL, &kvaluetype, (LPBYTE)&memBase0_1, &datasize))
		memBase0_1 = 0;
	else
		memBase0_1 = tcc_allocbaseaddress((unsigned int)memBase0_1);
	
	if(RegQueryValueEx(hKey, L"MemBase1_0", NULL, &kvaluetype, (LPBYTE)&memBase1_0, &datasize))
		memBase1_0 = 0;
	else
		memBase1_0 = tcc_allocbaseaddress((unsigned int)memBase1_0);
	
	if(RegQueryValueEx(hKey, L"MemBase1_1", NULL, &kvaluetype, (LPBYTE)&memBase1_1, &datasize))
		memBase1_1 = 0;
	else
		memBase1_1 = tcc_allocbaseaddress((unsigned int)memBase1_1);	
	
	pCSDHCBase->m_dwMemBase0[0] = memBase0_0;
	pCSDHCBase->m_dwMemBase0[1] = memBase0_1;
	pCSDHCBase->m_dwMemBase1[0] = memBase1_0;
	pCSDHCBase->m_dwMemBase1[1] = memBase1_1;
		
	// Get Address Length ==========================================================================
	//==============================================================================================	
	datasize = sizeof(DWORD);
	if(RegQueryValueEx(hKey, L"MemLen0_0", NULL, &kvaluetype, (LPBYTE)&memLen0_0, &datasize))
		memLen0_0 = 0;

	if(RegQueryValueEx(hKey, L"MemLen0_1", NULL, &kvaluetype, (LPBYTE)&memLen0_1, &datasize))
		memLen0_1 = 0;
	
	if(RegQueryValueEx(hKey, L"MemLen1_0", NULL, &kvaluetype, (LPBYTE)&memLen1_0, &datasize))
		memLen1_0 = 0;

	if(RegQueryValueEx(hKey, L"MemLen1_1", NULL, &kvaluetype, (LPBYTE)&memLen1_1, &datasize))
		memLen1_1 = 0;

	pCSDHCBase->m_dwMemLen0[0] = memLen0_0;
	pCSDHCBase->m_dwMemLen0[1] = memLen0_1;
	pCSDHCBase->m_dwMemLen1[0] = memLen1_0;
	pCSDHCBase->m_dwMemLen1[1] = memLen1_1;

	RegCloseKey(hKey);

	// eugeun_sdio	
	RETAILMSG(1,(TEXT("[SD          ] SDHC IP Count     : %d \n"), pCSDHCBase->m_dwControllerCount));
	RETAILMSG(1,(TEXT("[SD          ] Total Slot Count  : %d \n"), pCSDHCBase->m_cSlots));
	RETAILMSG(1,(TEXT("[SD          ] Slot 0 (IRQ value %d) ========================================= \n"), pCSDHCBase->m_dwIRQvalue[0]));
	RETAILMSG(1,(TEXT("[SD          ] MemBase0_0 0x%x, MemLen0_0 0x%x \n"), pCSDHCBase->m_dwMemBase0[0], pCSDHCBase->m_dwMemLen0[0]));	
	RETAILMSG(1,(TEXT("[SD          ] MemBase0_1 0x%x, MemLen0_1 0x%x \n"), pCSDHCBase->m_dwMemBase0[1], pCSDHCBase->m_dwMemLen0[1]));	
	RETAILMSG(1,(TEXT("[SD          ] Slot 1 (IRQ value %d) ========================================= \n"), pCSDHCBase->m_dwIRQvalue[1]));
	RETAILMSG(1,(TEXT("[SD          ] MemBase1_0 0x%x, MemLen1_0 0x%x \n"), pCSDHCBase->m_dwMemBase1[0], pCSDHCBase->m_dwMemLen1[0]));	
	RETAILMSG(1,(TEXT("[SD          ] MemBase1_1 0x%x, MemLen1_1 0x%x \n"), pCSDHCBase->m_dwMemBase1[1], pCSDHCBase->m_dwMemLen1[1]));	

	return pCSDHCBase;
	
	//return new CSDHCBase;
#else
    PCSDHCBase pSDHC = NULL;
    HKEY hkDevice = OpenDeviceKey(pszActiveKey);

    if (hkDevice) {
        CReg regDevice(hkDevice, _T(""));
        DEBUGCHK(regDevice.IsOK());
        TCHAR szDll[MAX_PATH];

        if (regDevice.ValueSZ(DEVLOAD_DLLNAME_VALNAME, szDll, dim(szDll))) {
            szDll[dim(szDll) - 1] = 0; // Null-terminate
            
            TCHAR szProc[MAX_PATH];

            if (regDevice.ValueSZ(SDHC_CREATION_PROC_KEY, szProc, dim(szProc))) {
                szProc[dim(szProc) - 1] = 0; // Null-terminate
                
                HMODULE hMod = LoadLibrary(szDll);
                if (hMod) {
                    LPSDHC_CREATION_PROC pfnCreate = (LPSDHC_CREATION_PROC)
                        GetProcAddress(hMod, szProc);
                    if (pfnCreate) {
                        pSDHC = (*pfnCreate)();
                    }
                    
                    FreeLibrary(hMod);
                }
            }
        }

        RegCloseKey(hkDevice);
    }

    return pSDHC;
#endif
}

/************************************************************************
* FUNCTION                                                                
*				CSDHCBase::DestroySDHCControllerObject()
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
VOID CSDHCBase::DestroySDHCControllerObject(PCSDHCBase pSDHC)
{
	DEBUGCHK(pSDHC);
	delete pSDHC;
}


///////////////////////////////////////////////////////////////////////////////
//  SDHCInitialize - Initialize the the controller
//  Input:  pHCContext -  host controller context
//          
//  Output: 
//  Return: SD_API_STATUS
//  Notes:  
//          
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS CSDHCBase::SDHCInitialize(PSDCARD_HC_CONTEXT pHCContext)
{
    DEBUGMSG(SDCARD_ZONE_INIT,(TEXT("SDHCInitialize++\n")));

    PREFAST_DEBUGCHK(pHCContext);
    PCSDHCBase pController = GET_PCONTROLLER_FROM_HCD(pHCContext);
    PREFAST_DEBUGCHK(pController);
    SD_API_STATUS status = pController->Start();

    DEBUGMSG(SDCARD_ZONE_INIT,(TEXT("SDHCInitialize--\n")));

    return status;
}


///////////////////////////////////////////////////////////////////////////////
//  SDHCDeinitialize - Deinitialize the SDHC Controller
//  Input:  pHCContext - HC context
//          
//  Output: 
//  Return: SD_API_STATUS
//  Notes:  
//          
//
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS CSDHCBase::SDHCDeinitialize(PSDCARD_HC_CONTEXT pHCContext)
{
    DEBUGMSG(SDCARD_ZONE_INIT,(TEXT("SDHCDeinitialize++\n")));

    PREFAST_DEBUGCHK(pHCContext);
    PCSDHCBase pController = GET_PCONTROLLER_FROM_HCD(pHCContext);
    PREFAST_DEBUGCHK(pController);
    SD_API_STATUS status = pController->Stop();

    DEBUGMSG(SDCARD_ZONE_INIT,(TEXT("SDHCDeinitialize--\n")));

    return status;
}


///////////////////////////////////////////////////////////////////////////////
//  SDHCSDCancelIoHandler - io cancel handler 
//  Input:  pHostContext - host controller context
//          dwSlot - slot the request is going on
//          pRequest - the request to be cancelled
//          
//  Output: 
//  Return: TRUE if I/O was cancelled
//  Notes:  
//          the HC lock is taken before entering this cancel handler
//
///////////////////////////////////////////////////////////////////////////////
BOOLEAN 
CSDHCBase::SDHCCancelIoHandler(
                    PSDCARD_HC_CONTEXT  pHCContext,
                    DWORD               dwSlot,
                    PSD_BUS_REQUEST     pRequest
                    )
{
    PREFAST_DEBUGCHK(pHCContext);
    PCSDHCBase pController = GET_PCONTROLLER_FROM_HCD(pHCContext);
    PREFAST_DEBUGCHK(pController);
    return pController->CancelIoHandler(dwSlot, pRequest);
}


///////////////////////////////////////////////////////////////////////////////
//  SDHCBusRequestHandler - bus request handler 
//  Input:  pHostContext - host controller context
//          dwSlot - slot the request is going to
//          pRequest - the request
//          
//  Output: 
//  Return: SD_API_STATUS
//  Notes:  The request passed in is marked as uncancelable, this function
//          has the option of making the outstanding request cancelable    
//          returns status pending
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS 
CSDHCBase::SDHCBusRequestHandler(
                      PSDCARD_HC_CONTEXT pHCContext, 
                      DWORD              dwSlot, 
                      PSD_BUS_REQUEST    pRequest
                      ) 
{
    PREFAST_DEBUGCHK(pHCContext);
    PCSDHCBase pController = GET_PCONTROLLER_FROM_HCD(pHCContext);
    PREFAST_DEBUGCHK(pController);
    return pController->BusRequestHandler(dwSlot, pRequest);
}

///////////////////////////////////////////////////////////////////////////////
//  SDHCSlotOptionHandler - handler for slot option changes
//  Input:  pHostContext - host controller context
//          dwSlot       - the slot the change is being applied to
//          Option       - the option code
//          pData        - data associaSHC with the option
//  Output: 
//  Return: SD_API_STATUS
//  Notes:  
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS 
CSDHCBase::SDHCSlotOptionHandler(
                      PSDCARD_HC_CONTEXT    pHCContext,
                      DWORD                 dwSlot, 
                      SD_SLOT_OPTION_CODE   sdOption, 
                      PVOID                 pData,
                      ULONG                 ulOptionSize
                      )
{
    PCSDHCBase pController = GET_PCONTROLLER_FROM_HCD(pHCContext);
    PREFAST_DEBUGCHK(pController);
    return pController->SlotOptionHandler(dwSlot, sdOption, pData, ulOptionSize);
}


// DO NOT REMOVE --- END EXTERNALLY DEVELOPED SOURCE CODE ID --- DO NOT REMOVE

