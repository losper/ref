#ifndef __TCCDISP_DISP_PRIVATE_CONTEXT_H__
#define __TCCDISP_DISP_PRIVATE_CONTEXT_H__

typedef enum
{
	VB_FRONTPORCH =0,
	VB_VSYNC,
	VB_BACKPORCH
} VB_STATUS;

typedef enum
{
	OUTPUT_IF_RGB,
	OUTPUT_IF_TV
} OUTPUT_INTERFACE;

typedef enum
{
	TV_DMA_DISABLE,
	TV_DMA_PRIMARY,
	TV_DMA_OVERLAY
} TV_DMA_MODE;

typedef enum
{
	TV_DMA_RGB565,
	TV_DMA_RGBX888,
	TV_DMA_I420,
	TV_DMA_YV12,
	TV_DMA_YUYV,
	TV_DMA_YVYU,
	TV_DMA_UYVY,
	TV_DMA_VYUY
} TV_DMA_SOURCE_FORMAT;

typedef struct _OverlayContext
{
	TCCDISPSurf *pSurface;		// Current Overlay Surface
	TCCDISPSurf *pPrevSurface;	// Previous Flipped Overlay Surface

	DWORD		dwWinMode;
	DWORD		dwBPPMode;
	DWORD		dwPostSrcType;
	BOOL		bLocalPath;

	unsigned int	uiSrcWidth;
	unsigned int	uiSrcHeight;
	unsigned int	uiSrcOffsetX;
	unsigned int	uiSrcOffsetY;
	unsigned int	uiDstWidth;
	unsigned int	uiDstHeight;
	unsigned int	uiDstOffsetX;
	unsigned int	uiDstOffsetY;
	BOOL		bEnabled;		// TRUE menas FIMD window for Overlay is enabled
	BOOL		bShow;			// TRUE menas Overlay set to SHOW in HalUpdateOverlay()

	// Blending Information
	BOOL		bBlendOn;
	BOOL		bColorKey;		// TRUE measn Color Key, FALSE means Alpha Blending

	// Color Key Information
	BOOL		bSrcCKey;		// TRUE measn SrcCKey, FALSE means DestCKey
	unsigned int	CompareKey;	// Compare Key (Mask)
	unsigned int	ColorKey;		// Color Key (Value)

	// Alpha Blending Information
	BOOL		bUsePixelBlend;	// TRUE means PerPixel Blending, FALSE means PerPlane Blending
	unsigned int	Alpha;			// Alpha Value
} OverlayContext;

typedef struct _TVDMAContext
{
	DWORD		dwSourceFormat;
	unsigned int	uiSrcBaseWidth;
	unsigned int	uiSrcBaseHeight;
	unsigned int	uiSrcWidth;
	unsigned int	uiSrcHeight;
	unsigned int	uiSrcOffsetX;
	unsigned int	uiSrcOffsetY;
	unsigned int	uiBufferRGBY;
	unsigned int	uiBufferCb;
	unsigned int	uiBufferCr;
} TVDMAContext;

#define DRVESC_OUTPUT_BASE				(0x00020100)
#define DRVESC_OUTPUT_RGB					(DRVESC_OUTPUT_BASE+0)
#define DRVESC_OUTPUT_TV					(DRVESC_OUTPUT_BASE+1)
#define DRVESC_OUTPUT_SWITCH				(DRVESC_OUTPUT_BASE+2)
#define DRVESC_TV_DMA_DISABLE				(DRVESC_OUTPUT_BASE+10)
#define DRVESC_TV_DMA_PRIMARY				(DRVESC_OUTPUT_BASE+11)
#define DRVESC_TV_DMA_OVERLAY				(DRVESC_OUTPUT_BASE+12)

#ifndef DRVESC_G2D_ACCEL
#define DRVESC_G2D_ACCEL		(0x00020200)
#endif
#ifndef DRVESC_G2D_PROFILE
#define	DRVESC_G2D_PROFILE	(0x00020201)
#endif

#ifndef	GETRAWFRAMEBUFFER
#define GETRAWFRAMEBUFFER		0x00020001
#define RAW_FORMAT_565		(1)
#define RAW_FORMAT_555		(2)
#define RAW_FORMAT_OTHER		(3)
typedef struct _RawFrameBufferInfo
{
	WORD	wFormat;
	WORD	wBPP;
	VOID	*pFramePointer;
	int		cxStride;
	int		cyStride;
	int		cxPixels;
	int		cyPixels;
} RawFrameBufferInfo;
#endif

#endif __TCCDISP_DISP_PRIVATE_CONTEXT_H__