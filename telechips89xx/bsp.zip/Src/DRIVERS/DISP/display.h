#ifndef __TCCDISP_H__
#define __TCCDISP_H__

class TCCDISPSurf;


#include "priv_context.h"


class TCCDISP : public DDGPE
{

protected:


	TCCDISPSurf		*m_pVisibleSurface;
	GPEModeEx		m_ModeInfoEx[10];


	/// for Cache Region Clean
	DWORD		m_dwSourceSurfacePA;
	HANDLE		m_hVideoDrv;

private:

	DWORD		m_dwDeviceScreenWidth;		
	DWORD		m_dwDeviceScreenHeight;		
	DWORD		m_dwPixelUnit;

	DWORD		m_VideoMemoryPhysicalBase;
	DWORD		m_VideoMemoryVirtualBase;
	DWORD		m_VideoMemorySize;
	DWORD		dwDDRAWBaseAddress;
	DWORD		dwDDRAWLength;
	DWORD		dwVirtualOffset;
	SurfaceHeap	*m_pVideoMemoryHeap;			// Video Memory Surface Heap

	UCHAR		m_CursorBackingStore[64*64*4];
	UCHAR		m_CursorXorShape[64*64];
	UCHAR		m_CursorAndShape[64*64];
	BOOL		m_CursorDisabled;
	BOOL		m_CursorVisible;
	BOOL		m_CursorForcedOff;
	RECTL		m_CursorRect;
	POINTL		m_CursorSize;
	POINTL		m_CursorHotspot;

	VIDEO_POWER_STATE		m_VideoPowerState;
	OverlayContext			m_OverlayCtxt[5];

public:
	
	BOOL bFirstSetMode;
	BOOL		m_InDDraw;
	ULONG_PTR	m_fpCurrentOverlay;
	ULONG_PTR	m_fpPreviousOverlay;
	SurfaceHeap *pHWTempHeap;

	TCCDISP();

	virtual
	~TCCDISP();

	virtual
	int
	NumModes();

	virtual
	void
	SetModePalette ( HPALETTE *palette);

	virtual
	void 
	SaveLCDStatus( int Width,int Height);

	virtual
	VOID
	SetModeHW (
		DWORD dwStatus, DWORD dwHDMIWidth, DWORD dwHDMIHeight
		);

	virtual
	SCODE
	SetMode(
		int			modeId,
		HPALETTE	* palette
		);

	virtual
	int
	InDisplay(void);

	virtual
	int
	InVBlank();

	virtual
	SCODE
	SetPalette(
		const PALETTEENTRY *source,
		USHORT		firstEntry,
		USHORT		numEntries
		);

	virtual
	SCODE
	GetModeInfo(
		GPEMode * pMode,
		int       modeNo
		);

	virtual
	SCODE
	GetModeInfoEx(
		GPEModeEx *pModeEx,
		int       modeNo
		);

	virtual
	SCODE
	SetPointerShape(
		GPESurf * mask,
		GPESurf * colorSurface,
		int       xHot,
		int       yHot,
		int       cX,
		int       cY
		);

	virtual
	SCODE
	MovePointer(
		int xPosition,
		int yPosition
		);

	virtual
	void
	WaitForNotBusy();

	virtual
	int
	IsBusy();

	virtual
	void
	GetPhysicalVideoMemory(
		unsigned long * physicalMemoryBase,
		unsigned long * videoMemorySize
		);

	void
	GetVirtualVideoMemory(
		unsigned long * virtualMemoryBase,
		unsigned long * videoMemorySize
		);
	
	void
	GetAvailVideoMemory(
		unsigned long * AvailVideoMemorySize
		);

	virtual
	SCODE
	Line(
		GPELineParms * lineParameters,
		EGPEPhase      phase
		);

	// blt.cpp
	virtual
	SCODE
		BltPrepare(
		GPEBltParms * blitParameters
		);

	virtual
	SCODE
		BltComplete(
		GPEBltParms * blitParameters
		);

	SCODE TCCGraphicEngineBlt(GPEBltParms *pParms);
	SCODE TCCGraphicEngineBltNULL(GPEBltParms *pParms);
	ULONG DrvControlOutput(DWORD tMode);

	virtual
	ULONG
	DrvEscape(
		SURFOBJ * pso,
		ULONG     iEsc,
		ULONG     cjIn,
		void    * pvIn,
		ULONG     cjOut,
		void    * pvOut
		);

	int
	GetGameXInfo(
		ULONG   iEsc,
		ULONG   cjIn,
		void  * pvIn,
		ULONG   cjOut,
		void  * pvOut
		);

	SCODE
	WrappedEmulatedLine(
		GPELineParms * lineParameters
		);

	void
	CursorOn();

	void
	CursorOff();

	// surf.cpp
	SCODE
	AllocSurface(
		GPESurf    ** ppSurf,
		int           width,
		int           height,
		EGPEFormat    format,
		int           surfaceFlags
		);

	SCODE
	AllocSurface(
		DDGPESurf         ** ppSurf,
		int                  width,
		int                  height,
		EGPEFormat           format,
		EDDGPEPixelFormat    pixelFormat,
		int                  surfaceFlags
		);

	SCODE
	AllocSurfaceVideo(
		DDGPESurf		** ppSurf,
		int				width,
		int				height,
		int				stride,
		EGPEFormat           format,
		EDDGPEPixelFormat    pixelFormat
		);

	virtual
	void
	SetVisibleSurface(
		GPESurf * pSurf,
		BOOL      bWaitForVBlank,
		DWORD dwIndex
		);

	int
	GetRotateModeFromReg();

	void
	SetRotateParams();

	long
	DynRotate(
		int angle
		);

	CRITICAL_SECTION	m_csDevice;



	BOOL AllocResource(void);
	void ReleaseResource(void);

	void SetDisplayPowerState(VIDEO_POWER_STATE PowerState);
	VIDEO_POWER_STATE GetDisplayPowerState(void);
	void ReadLCDInformation(void);
	
	// Frame Interrupt / Status
	BOOL WaitForVerticalBlank(VB_STATUS Status);
	DWORD GetScanLine(void);

	// Overlay Control
	BOOL OverlayAllocResource(BOOL bLocalPath);
	BOOL OverlayReleaseResource(BOOL bLocalPath);
	BOOL OverlayInitialize(TCCDISPSurf* pOverlaySurface, RECT *pSrc, RECT *pDest,DWORD dwIndex);
	void OverlaySetPosition(UINT32 uiOffsetX, UINT32 uiOffsetY,DWORD dwindex);
	void OverlayEnable(DWORD dwIndex);
	void OverlayDisable(DWORD dwIndex);
	void OverlaySetPixelFormat(DWORD dwIndex);
	void OverlayBlendDisable(DWORD dwIndex);
	void OverlaySetColorKey(BOOL bSrcCKey, EDDGPEPixelFormat Format, DWORD ColorKey,DWORD dwIndex);
	void OverlaySetAlpha(BOOL bUsePixelBlend, DWORD Alpha,DWORD dwIndex);

	void InitalizeOverlayContext(DWORD dwIndex);
	TCCDISPSurf * GetCurrentOverlaySurf(DWORD dwIndex);
	TCCDISPSurf * GetPreviousOverlaySurf(DWORD dwIndex);


friend
	void
	buildDDHALInfo(
		LPDDHALINFO lpddhi,
		DWORD       modeidx
		);
};

class TCCDISPSurf : public DDGPESurf
{
private:
	SurfaceHeap*	m_pSurfHeap;

public:
	UINT32	m_uiOffsetCb;
	UINT32	m_uiOffsetCr;

	TCCDISPSurf(int, int, DWORD, VOID*, int, EGPEFormat, EDDGPEPixelFormat pixelFormat, SurfaceHeap*);

	virtual
	~TCCDISPSurf();

};

#endif __TCCDISP_H__
