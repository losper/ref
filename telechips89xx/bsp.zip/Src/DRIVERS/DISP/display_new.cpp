/****************************************************************************
*   FileName    : display.cpp
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/
#include "precomp.h"
#include "dispperf.h"
#include "tcc_gpio.h"
#include "../../BOOT/lcd.h" 
#include "blt.h"
#include <syspal.h>    
#include <gxinfo.h>

extern ULONG gBitMasks[3]; 
#define ESC_SUCCESS				0x00000001
#define ESC_FAILED				0xFFFFFFFF
#define ESC_NOT_SUPPORTED		0x00000000

typedef struct {
	volatile unsigned int	LIxC;				//   LCD Image x Control Register 
	volatile unsigned int	LIxP;				//   LCD Image x Position Register 
	volatile unsigned int	LIxS;				//   LCD Image x Size Register 
	volatile unsigned int	LIxBA0;				//   LCD Image x Base Address 0 Register. 
	volatile unsigned int	LIxCA;				//   LCD Image x Current Address Register. 
	volatile unsigned int	LIxBA1;				//   LCD Image x Base Address 1 Register 
	volatile unsigned int	LIxBA2;				//   LCD Image x Base Address 2 Register 
	volatile unsigned int	LIxO;				//   LCD Image x Offset Register 
	volatile unsigned int	LIxSR;				//   LCD Image x Scale ratio 
	volatile unsigned int	LIxA;				//   LCD Image x Alpha Configuration Register 
	volatile unsigned int	LIxKR;				//   LCD Image x Keying Register for RED or LUMA(Y) 
	volatile unsigned int	LIxKG;				//   LCD Image x Keying Register for BLUE or CHROMA(Cb) 
	volatile unsigned int	LIxKB;				//   LCD Image x Keying Register for GREEN or CHROMA(Cr) 
	volatile unsigned int	LIxEN;				//   LCD Image x Enhancement Register 
} LCDC_IMG, *PLCDC_IMG;

PLCDC		pLCDC[2];		// pLCDC[0]    - LCDC0,      pLCDC[1]    - LCDC1
PLCDC_IMG	pLCDCIMG[2];	// pLCDCIMG[0] - LCDC0.IMG0, pLCDCIMG[1] - LCDC1.IMG1

PLCDC		pLCD;
PLCDC_IMG	pIMG;

DDGPE * gGPE = (DDGPE *)NULL;
tSYSTEM_PARAM *gpBOOTARGS;
sHwGE *pGraphicEngine;



extern BOOL g_UsingLayer[MAX_OVERAY_COUNT];  
// initialZones should typically be 0x0003 (refer to "gpe.h")
INSTANTIATE_GPE_ZONES(0x0003, "DisplayDriver", "Unused1", "Unused2")
static TCHAR gszBaseInstance[256] = _T("Drivers\\Magellan\\CONFIG");


void DemoType1_UI_IMGs_Cfg_Sync(void)
{
	if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType == 1)
	{
		if (pLCD == pLCDC[0])
		{
			*pLCDCIMG[1] = *pLCDCIMG[0];
		}
		else //if (pLCD == pLCDC[1])
		{
			*pLCDCIMG[0] = *pLCDCIMG[1];
		}
	}
}


// This prototype avoids problems exporting from .lib
BOOL APIENTRY GPEEnableDriver(ULONG engineVersion, ULONG cj, DRVENABLEDATA * data, PENGCALLBACKS engineCallbacks);


BOOL
APIENTRY
DrvEnableDriver(
				ULONG           engineVersion,
				ULONG           cj,
				DRVENABLEDATA * data,
				PENGCALLBACKS   engineCallbacks
				)
{
	return GPEEnableDriver(engineVersion, cj, data, engineCallbacks);
}

GPE *
GetGPE()
{
	if (!gGPE)
	{
		gGPE = new TCCDISP();
	}

	return gGPE;
}

TCCDISP::TCCDISP()
:bFirstSetMode(TRUE)
{
	HKEY hkDisplay;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] ++TCCDISP::TCCDISP()\n\r")));

	m_VideoMemoryPhysicalBase = NULL;
	m_VideoMemoryVirtualBase = NULL;
	m_VideoMemorySize = 0;
	m_pVideoMemoryHeap = NULL;

	m_hVideoDrv = NULL;

	m_CursorVisible = FALSE;
	m_CursorDisabled = TRUE;
	m_CursorForcedOff = FALSE;
	memset (&m_CursorRect, 0x0, sizeof(m_CursorRect));

	InitializeCriticalSection(&m_csDevice);
	m_InDDraw = FALSE;

	for(int i=0; i< MAX_OVERAY_COUNT; i++)
		InitalizeOverlayContext(i);

	// Read LCD Information
	gpBOOTARGS=(tSYSTEM_PARAM *) tcc_allocbaseaddress(SYSTEM_PARAM_BASEADDRESS);
	// Initialize Screen Dimensions
	m_dwDeviceScreenWidth = gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nWidth;
	m_dwDeviceScreenHeight = gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nHeight;
	m_dwPixelUnit		= gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nMode;
	m_nScreenWidthSave = m_dwDeviceScreenWidth;
	m_nScreenHeightSave = m_dwDeviceScreenHeight;
//get memory information from registry

	DWORD dwStatus,dwType,dwSize;
	dwStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, gszBaseInstance, 0, 0, &hkDisplay);
	dwType = REG_DWORD;

	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) {
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hkDisplay, _T("DDRAW_BASE"), NULL, &dwType, 
			(LPBYTE) &dwDDRAWBaseAddress, &dwSize);
	}

	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) {
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hkDisplay, _T("DDRAW_LEN"), NULL, &dwType, 
			(LPBYTE) &dwDDRAWLength, &dwSize);
	}
	if(dwStatus == ERROR_SUCCESS && dwType == REG_DWORD) {
		dwSize = sizeof(DWORD);
		dwStatus = RegQueryValueEx(hkDisplay, _T("VIRTUAL_OFFSET"), NULL, &dwType, 
			(LPBYTE) &dwVirtualOffset, &dwSize);
	}
	RegCloseKey(hkDisplay);

	ReadLCDInformation();

	// Initialize Rotate Mode
	m_iRotate = 0; 
	SetRotateParams();

	// Initialize Power State
	m_VideoPowerState = VideoPowerOn;

	// Clear Video Memory (Leave frame buffer for splash image)
	//dwSplashFrameBufferSize = m_dwDeviceScreenWidth*m_dwDeviceScreenHeight*m_pMode->Bpp/8;
	//memset ((void *)(m_VideoMemoryVirtualBase+dwSplashFrameBufferSize), 0x0, m_VideoMemorySize-dwSplashFrameBufferSize);
	//memcpy((void*)m_VideoMemoryVirtualBase,(void*)(IMAGE1_START+0x60000000),dwSplashFrameBufferSize);

	pLCDC[0] = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE);
	pLCDC[1] = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE);

	if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType == 1)
	{
		pLCDCIMG[0] = (PLCDC_IMG)&pLCDC[0]->LI0C;
		pLCDCIMG[1] = (PLCDC_IMG)&pLCDC[1]->LI1C;

		pLCDCIMG[0]->LIxBA0 = dwDDRAWBaseAddress-dwVirtualOffset;
		pLCDCIMG[1]->LIxBA0 = dwDDRAWBaseAddress-dwVirtualOffset;

		pLCD = pLCDC[1];
		pIMG = (PLCDC_IMG)&pLCD->LI1C;
	}
	else
	{
		if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdcIdxForUI == 0)
		{
			pLCD = pLCDC[0];
			pIMG = (PLCDC_IMG)&pLCD->LI0C;
		}
		else
		{
			pLCD = pLCDC[1];
			pIMG = (PLCDC_IMG)&pLCD->LI1C;
		}

		pIMG->LIxBA0 = dwDDRAWBaseAddress-dwVirtualOffset;
		pLCD->LCTRL &=~Hw3|Hw2|Hw1;
		//pLCD->LCTRL |= Hw1; //Layer Order change 0 - 2- 1
	}
#ifdef _USING_HW_ACCELERATE_	
	pGraphicEngine=(sHwGE *)tcc_allocbaseaddress((DWORD)&HwOVERLAYMIXER_BASE);
	pGraphicEngine->FCH[2].SADDR0 = 0xFF00; //user flag Default set 0xFF00 
#endif
	//set overlay setting 
	for(int j=0; j < MAX_OVERAY_COUNT; j++)
		g_UsingLayer[j]=FALSE; 

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] --TCCDISP::TCCDISP()\n\r")));
}

VOID
TCCDISP::SetModePalette ( HPALETTE *palette)
{
		// Create Palette
		if (palette)
		{
			*palette = EngCreatePalette(PAL_BITFIELDS, 0, NULL, gBitMasks[0], gBitMasks[1], gBitMasks[2]);
		}
}

SCODE
TCCDISP::SetMode (int modeId, HPALETTE *palette)
{
	SCODE scRet = S_OK;
	DWORD dwSplashFrameBufferSize;
	

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] ++TCCDISP::SetMode(%d) \n\r"), modeId));

	if((modeId >= 0)&& (modeId <= 9))
	{
		m_pModeEx = &(m_ModeInfoEx[modeId]);
		m_pMode = &(m_ModeInfoEx[modeId].modeInfo);
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Set Mode Info[%dx%dx%d](%X,%X,%X)\n"), m_pMode->width,m_pMode->height,m_pModeEx->ePixelFormat,m_pModeEx->dwRBitMask,m_pModeEx->dwGBitMask,m_pModeEx->dwBBitMask));

		m_nScreenWidthSave = m_pMode->width;
		m_nScreenHeightSave =m_pMode->height;
		m_dwDeviceScreenWidth = m_nScreenWidthSave;
		m_dwDeviceScreenHeight = m_nScreenHeightSave;
		m_nScreenWidth = m_nScreenWidthSave;
		m_nScreenHeight = m_nScreenHeightSave;

		if (AllocResource() == FALSE)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] TCCDISP() : AllocResource() Fail\n\r")));
			return E_INVALIDARG;
		}
	
		dwSplashFrameBufferSize = m_dwDeviceScreenWidth*m_dwDeviceScreenHeight*m_pMode->Bpp/8;
		if(bFirstSetMode)
		{
			memset ((void *)(m_VideoMemoryVirtualBase+dwSplashFrameBufferSize), 0x0, m_VideoMemorySize-dwSplashFrameBufferSize);
			bFirstSetMode=FALSE;
		}
		else
			memset ((void *)(m_VideoMemoryVirtualBase), 0x0, m_VideoMemorySize);
		
		m_dwPhysicalModeID = m_pMode->modeId;

		// Create Palette
		SetModePalette(palette);

		if( m_pPrimarySurface)
		{
			delete m_pPrimarySurface;
			m_pPrimarySurface = NULL;
		}	

		//Allocate Primary Surface
		if (NULL == m_pPrimarySurface)
		{
			if (FAILED(AllocSurface((DDGPESurf **)&m_pPrimarySurface,
				m_nScreenWidthSave, m_nScreenHeightSave,
				m_pMode->format, m_pModeEx->ePixelFormat,
				GPE_REQUIRE_VIDEO_MEMORY)))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] SetMode() : m_pPrimarySurface AllocSurface() Fail\n\r")));
				scRet = E_INVALIDARG;
			}
			else
			{
				m_pVisibleSurface = (TCCDISPSurf*)m_pPrimarySurface;
			}
		}
#if 0
		//set pixelformat
		{
			if(m_pMode->Bpp == 16)
			{
				//RGB565
				BITCSET(pLCD->LI1C, Hw5-Hw0, 10);
			}
			else
			{
				//RGB888
				BITCSET(pLCD->LI1C, Hw5-Hw0, 12);
			}
			RETAILMSG(1,(TEXT("SET Pixel Format: LI1C:%08X \n"),pLCD->LI1C));

		}
#endif
		//set resolution
		{
			HKEY    hk;
			DWORD   dwStatus,dwHDMIWidth,dwHDMIHeight;
			DWORD dwSize,dwType;
			
			//check hdmi connection status & change resolution config
			{


				dwStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Drivers\\Display\\Magellan\\CONFIG", 0, 0, &hk);
				if( ERROR_SUCCESS == dwStatus )
				{
					dwSize = sizeof(DWORD);
					if (ERROR_SUCCESS == RegQueryValueEx(hk, TEXT("HDMISet"), NULL, &dwType, (LPBYTE)&dwStatus, &dwSize))
					{
						RETAILMSG(1,(TEXT("HDMI Status : %d \n"),dwStatus));
					}
					if(dwStatus)
					{
						dwSize = sizeof(DWORD);
						if (ERROR_SUCCESS == RegQueryValueEx(hk, TEXT("HDMIWidth"), NULL, &dwType, (LPBYTE)&dwHDMIWidth, &dwSize))
						{
							RETAILMSG(1,(TEXT("HDMI Width : %d \n"),dwHDMIWidth));
						}

						dwSize = sizeof(DWORD);
						if (ERROR_SUCCESS == RegQueryValueEx(hk, TEXT("HDMIHeight"), NULL, &dwType, (LPBYTE)&dwHDMIHeight, &dwSize))
						{
							RETAILMSG(1,(TEXT("HDMI Height : %d \n"),dwHDMIHeight));
						}
					}
				}
				else
				{
					RETAILMSG(1,(TEXT("HDMI Status Can't Read \n")));
					dwStatus=0;
				}

				if(hk != NULL) 
				{
					RegCloseKey(hk);
				}
			}
#if 0
			DWORD tempwidth=0,tempheight=0;
			if(dwStatus)
			{
				if(m_nScreenWidth >  dwHDMIWidth)
				{
					tempwidth=dwHDMIWidth;
				}
				else
					tempwidth=m_nScreenWidth;

				if(m_nScreenHeight > dwHDMIHeight)
				{
					tempheight=dwHDMIHeight;
				}
				else
					tempheight=m_nScreenHeight;
				
				{
					pLCD->LI1S = tempheight<<16|tempwidth;
					//pLCD->LI1O = m_nScreenWidth*2;
				}
			}
			else
			{

				if(m_nScreenWidth >  gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nWidth)
				{
					tempwidth=gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nWidth;
				}
				else
					tempwidth=m_nScreenWidth;

				if(m_nScreenHeight > gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nHeight)
				{
					tempheight=gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nHeight;
				}
				else
					tempheight=m_nScreenHeight;
				
				{
					pLCD->LI1S = tempheight<<16|tempwidth;
					//pLCD->LI1O = m_nScreenWidth*2;
				}
			}
#else
		SetModeHW(dwStatus,dwHDMIWidth,dwHDMIHeight);
		SaveLCDStatus( m_nScreenWidth,m_nScreenHeight);
#endif
		}

		m_pPrimarySurface->SetRotation(m_nScreenWidth, m_nScreenHeight, m_iRotate);

	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] SetMode() : modeId = %d, Driver Support Only Mode 0\n\r"), modeId));
		scRet = E_INVALIDARG;
	}


	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] --TCCDISP::SetMode()\n\r")));

	return scRet;
}
BOOL
TCCDISP::AllocResource(void)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] +AllocResource()\n\r")));

	// Frame Buffer
	m_VideoMemoryPhysicalBase = dwDDRAWBaseAddress-dwVirtualOffset;
	m_VideoMemorySize = dwDDRAWLength;

	m_VideoMemoryVirtualBase = (DWORD)tcc_allocbaseaddress(m_VideoMemoryPhysicalBase);

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] m_VideoMemoryPhysicalBase = 0x%08x\n\r"), m_VideoMemoryPhysicalBase));
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] m_VideoMemoryVirtualBase  = 0x%08x\n\r"), m_VideoMemoryVirtualBase));
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] m_VideoMemorySize = 0x%08x\n\r"), m_VideoMemorySize));


	if(m_pVideoMemoryHeap)
	{
		delete m_pVideoMemoryHeap;
		m_pVideoMemoryHeap = NULL;
	}
	// Allocate SurfaceHeap
	m_pVideoMemoryHeap = new SurfaceHeap(m_VideoMemorySize, m_VideoMemoryVirtualBase, NULL, NULL);
	if(!m_pVideoMemoryHeap)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] TCCDISP() : SurfaceHeap() allocate Fail\n\r")));
		return FALSE;
	}


	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] -AllocResource()\n\r")));

	return TRUE;
}


VOID
TCCDISP::SetModeHW (DWORD dwStatus, DWORD dwHDMIWidth, DWORD dwHDMIHeight)
{
	DWORD tempwidth=0,tempheight=0;
	if(dwStatus)
	{
		if(m_nScreenWidth >  (int)dwHDMIWidth)
		{
			tempwidth=dwHDMIWidth;
		}
		else
			tempwidth=m_nScreenWidth;

		if(m_nScreenHeight > (int)dwHDMIHeight)
		{
			tempheight=dwHDMIHeight;
		}
		else
			tempheight=m_nScreenHeight;

		{
			pLCD->LI1S = tempheight<<16|tempwidth;
			pLCD->LI1O = m_nScreenWidth*m_dwPixelUnit;
		}
	}
	else
	{

		if(m_nScreenWidth > (int)gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nWidth)
		{
			tempwidth=gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nWidth;
		}
		else
			tempwidth=m_nScreenWidth;

		if(m_nScreenHeight > (int)gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nHeight)
		{
			tempheight=gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nHeight;
		}
		else
			tempheight=m_nScreenHeight;

		{
			pLCD->LI1S = tempheight<<16|tempwidth;
			pLCD->LI1O = m_nScreenWidth*m_dwPixelUnit;
		}
	}

	DemoType1_UI_IMGs_Cfg_Sync();

	#ifdef _USING_HW_ACCELERATE_
	//reserved for H/W Accelerate Dump Memory
	if(!pHWTempHeap)
		pHWTempHeap = m_pVideoMemoryHeap->Alloc(800*480*4);
	#endif
}


void
TCCDISP::GetPhysicalVideoMemory(unsigned long *physicalMemoryBase, unsigned long *videoMemorySize)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] TCCDISP::GetPhysicalVideoMemory()\n\r")));

	*physicalMemoryBase = m_VideoMemoryPhysicalBase;
	*videoMemorySize = m_VideoMemorySize;
}

void
TCCDISP::GetVirtualVideoMemory(unsigned long *virtualMemoryBase, unsigned long *videoMemorySize)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] TCCDISP::GetVirtualVideoMemory()\n\r")));

	*virtualMemoryBase = m_VideoMemoryVirtualBase;
	*videoMemorySize = m_VideoMemorySize;
}

void
TCCDISP::GetAvailVideoMemory(unsigned long * AvailVideoMemorySize)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] TCCDISP::GetVirtualVideoMemory()\n\r")));

	*AvailVideoMemorySize = m_pVideoMemoryHeap->Available();
}

ULONG *
APIENTRY
DrvGetMasks(
			DHPDEV dhpdev
			)
{
	return gBitMasks;
}


void
TCCDISP::SetRotateParams()
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] TCCDISP::SetRotateParams() : Angle = %d\n\r"), m_iRotate));

	switch(m_iRotate)
	{
	case DMDO_90:
	case DMDO_270:
		m_nScreenHeight = m_nScreenWidthSave;
		m_nScreenWidth = m_nScreenHeightSave;
		break;

	case DMDO_0:
	case DMDO_180:
	default:
		m_nScreenWidth = m_nScreenWidthSave;
		m_nScreenHeight = m_nScreenHeightSave;
		break;
	}

	return;
}

LONG
TCCDISP::DynRotate(int angle)
{
	GPESurfRotate * pSurf = (GPESurfRotate *)m_pPrimarySurface;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++TCCDISP::DynRotate(%d)\n\r"), angle));

	// DirectDraw and rotation can't co-exist.
	if (m_InDDraw)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPDRV:ERR] DynRotate() : Can NOT Rotate in DirectDraw Mode\n\r")));
		return DISP_CHANGE_BADMODE;
	}

	CursorOff();

	m_iRotate = angle;

	switch(m_iRotate)
	{
	case DMDO_0:
	case DMDO_180:
		m_nScreenHeight = m_nScreenHeightSave;
		m_nScreenWidth  = m_nScreenWidthSave;
		break;

	case DMDO_90:
	case DMDO_270:
		m_nScreenHeight = m_nScreenWidthSave;
		m_nScreenWidth  = m_nScreenHeightSave;
		break;
	}

	m_pMode->width  = m_nScreenWidth;
	m_pMode->height = m_nScreenHeight;

	pSurf->SetRotation(m_nScreenWidth, m_nScreenHeight, angle);

	CursorOn();

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] --TCCDISP::DynRotate()\n\r")));

	return DISP_CHANGE_SUCCESSFUL;
}



void
TCCDISP::CursorOn (void)
{
	UCHAR *ptrScreen = (UCHAR*)m_pPrimarySurface->Buffer();
	UCHAR *ptrLine;
	UCHAR *cbsLine;
	int x, y;

	if (!m_CursorForcedOff && !m_CursorDisabled && !m_CursorVisible)
	{
		RECTL cursorRectSave = m_CursorRect;
		int   iRotate;

		RotateRectl(&m_CursorRect);
		for (y = m_CursorRect.top; y < m_CursorRect.bottom; y++)
		{
			if (y < 0)
			{
				continue;
			}
			if (y >= m_nScreenHeightSave)
			{
				break;
			}

			ptrLine = &ptrScreen[y * m_pPrimarySurface->Stride()];
			cbsLine = &m_CursorBackingStore[(y - m_CursorRect.top) * (m_CursorSize.x * (m_pMode->Bpp >> 3))];

			for (x = m_CursorRect.left; x < m_CursorRect.right; x++)
			{
				if (x < 0)
				{
					continue;
				}

				if (x >= m_nScreenWidthSave)
				{
					break;
				}

				// x' = x - m_CursorRect.left; y' = y - m_CursorRect.top;
				// Width = m_CursorSize.x;   Height = m_CursorSize.y;
				switch (m_iRotate)
				{
				case DMDO_0:
					iRotate = (y - m_CursorRect.top)*m_CursorSize.x + x - m_CursorRect.left;
					break;

				case DMDO_90:
					iRotate = (x - m_CursorRect.left)*m_CursorSize.x + m_CursorSize.y - 1 - (y - m_CursorRect.top);
					break;

				case DMDO_180:
					iRotate = (m_CursorSize.y - 1 - (y - m_CursorRect.top))*m_CursorSize.x + m_CursorSize.x - 1 - (x - m_CursorRect.left);
					break;

				case DMDO_270:
					iRotate = (m_CursorSize.x -1 - (x - m_CursorRect.left))*m_CursorSize.x + y - m_CursorRect.top;
					break;

				default:
					iRotate = (y - m_CursorRect.top)*m_CursorSize.x + x - m_CursorRect.left;
					break;
				}

				cbsLine[(x - m_CursorRect.left) * (m_pMode->Bpp >> 3)] = ptrLine[x * (m_pMode->Bpp >> 3)];
				ptrLine[x * (m_pMode->Bpp >> 3)] &= m_CursorAndShape[iRotate];
				ptrLine[x * (m_pMode->Bpp >> 3)] ^= m_CursorXorShape[iRotate];

				if (m_pMode->Bpp > 8)
				{
					cbsLine[(x - m_CursorRect.left) * (m_pMode->Bpp >> 3) + 1] = ptrLine[x * (m_pMode->Bpp >> 3) + 1];
					ptrLine[x * (m_pMode->Bpp >> 3) + 1] &= m_CursorAndShape[iRotate];
					ptrLine[x * (m_pMode->Bpp >> 3) + 1] ^= m_CursorXorShape[iRotate];

					if (m_pMode->Bpp > 16)
					{
						cbsLine[(x - m_CursorRect.left) * (m_pMode->Bpp >> 3) + 2] = ptrLine[x * (m_pMode->Bpp >> 3) + 2];
						ptrLine[x * (m_pMode->Bpp >> 3) + 2] &= m_CursorAndShape[iRotate];
						ptrLine[x * (m_pMode->Bpp >> 3) + 2] ^= m_CursorXorShape[iRotate];
					}
				}
			}
		}

		m_CursorRect = cursorRectSave;
		m_CursorVisible = TRUE;
	}
}

void
TCCDISP::CursorOff (void)
{
	UCHAR *ptrScreen = (UCHAR*)m_pPrimarySurface->Buffer();
	UCHAR *ptrLine;
	UCHAR *cbsLine;
	int x, y;

	if (!m_CursorForcedOff && !m_CursorDisabled && m_CursorVisible)
	{
		RECTL rSave = m_CursorRect;
		RotateRectl(&m_CursorRect);
		for (y = m_CursorRect.top; y < m_CursorRect.bottom; y++)
		{
			// clip to displayable screen area (top/bottom)
			if (y < 0)
			{
				continue;
			}

			if (y >= m_nScreenHeightSave)
			{
				break;
			}

			ptrLine = &ptrScreen[y * m_pPrimarySurface->Stride()];
			cbsLine = &m_CursorBackingStore[(y - m_CursorRect.top) * (m_CursorSize.x * (m_pMode->Bpp >> 3))];

			for (x = m_CursorRect.left; x < m_CursorRect.right; x++)
			{
				// clip to displayable screen area (left/right)
				if (x < 0)
				{
					continue;
				}

				if (x >= m_nScreenWidthSave)
				{
					break;
				}

				ptrLine[x * (m_pMode->Bpp >> 3)] = cbsLine[(x - m_CursorRect.left) * (m_pMode->Bpp >> 3)];

				if (m_pMode->Bpp > 8)
				{
					ptrLine[x * (m_pMode->Bpp >> 3) + 1] = cbsLine[(x - m_CursorRect.left) * (m_pMode->Bpp >> 3) + 1];

					if (m_pMode->Bpp > 16)
					{
						ptrLine[x * (m_pMode->Bpp >> 3) + 2] = cbsLine[(x - m_CursorRect.left) * (m_pMode->Bpp >> 3) + 2];
					}
				}
			}
		}

		m_CursorRect = rSave;
		m_CursorVisible = FALSE;
	}
}

SCODE
TCCDISP::SetPointerShape(GPESurf *pMask, GPESurf *pColorSurf, INT xHot, INT yHot, INT cX, INT cY)
{
	UCHAR	*andPtr;		// input pointer
	UCHAR	*xorPtr;		// input pointer
	UCHAR	*andLine;		// output pointer
	UCHAR	*xorLine;		// output pointer
	char	bAnd;
	char	bXor;
	int		row;
	int		col;
	int		i;
	int		bitMask;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("TCCDISP::SetPointerShape(0x%X, 0x%X, %d, %d, %d, %d)\r\n"),pMask, pColorSurf, xHot, yHot, cX, cY));

	// turn current cursor off
	CursorOff();

	// release memory associated with old cursor
	if (!pMask)							// do we have a new cursor shape
	{
		m_CursorDisabled = TRUE;		// no, so tag as disabled
	}
	else
	{
		m_CursorDisabled = FALSE;		// yes, so tag as not disabled

		// store size and hotspot for new cursor
		m_CursorSize.x = cX;
		m_CursorSize.y = cY;
		m_CursorHotspot.x = xHot;
		m_CursorHotspot.y = yHot;

		andPtr = (UCHAR*)pMask->Buffer();
		xorPtr = (UCHAR*)pMask->Buffer() + (cY * pMask->Stride());

		// store OR and AND mask for new cursor
		for (row = 0; row < cY; row++)
		{
			andLine = &m_CursorAndShape[cX * row];
			xorLine = &m_CursorXorShape[cX * row];

			for (col = 0; col < cX / 8; col++)
			{
				bAnd = andPtr[row * pMask->Stride() + col];
				bXor = xorPtr[row * pMask->Stride() + col];

				for (bitMask = 0x0080, i = 0; i < 8; bitMask >>= 1, i++)
				{
					andLine[(col * 8) + i] = bAnd & bitMask ? 0xFF : 0x00;
					xorLine[(col * 8) + i] = bXor & bitMask ? 0xFF : 0x00;
				}
			}
		}
	}

	return    S_OK;
}

SCODE
TCCDISP::MovePointer(INT xPosition, INT yPosition)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("TCCDISP::MovePointer(%d, %d)\r\n"), xPosition, yPosition));

	CursorOff();

	if (xPosition != -1 || yPosition != -1)
	{
		// compute new cursor rect
		m_CursorRect.left = xPosition - m_CursorHotspot.x;
		m_CursorRect.right = m_CursorRect.left + m_CursorSize.x;
		m_CursorRect.top = yPosition - m_CursorHotspot.y;
		m_CursorRect.bottom = m_CursorRect.top + m_CursorSize.y;

		CursorOn();
	}

	return    S_OK;
}
TCCDISP::~TCCDISP()
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++TCCDISP::~TCCDISP()\n\r")));

	ReleaseResource();
	//release HW Accelerate Temp Memory
	pHWTempHeap->Free();
	delete pHWTempHeap;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] --TCCDISP::~TCCDISP()\n\r")));
}

ULONG
TCCDISP::DrvControlOutput(DWORD tMode)
{
	if(tMode == 0)
	{
		//LCD Only
	}
	else if(tMode == 1)
	{
		//HDMI Only
	}
	else if(tMode == 3)
	{
		//LVDS Only
	}
	else if(tMode == 4)
	{
		//LCD+HDMI 
	}
	else if(tMode == 5)
	{
		//LCD+LVDS 
	}
	else
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++TCCDISP::DrvControlOutput(Mode:%d)\n\r"), tMode));

	return TRUE;

}

ULONG
TCCDISP::DrvEscape(SURFOBJ * pso, ULONG iEsc, ULONG cjIn, void *pvIn, ULONG cjOut, void *pvOut)
{
	ULONG Result = 0;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++TCCDISP::DrvEscape(0x%08x)\n\r"), iEsc));

	if (iEsc == QUERYESCSUPPORT)
	{
		if ( (*(DWORD*)pvIn == DRVESC_GETSCREENROTATION)
			|| (*(DWORD*)pvIn == DRVESC_SETSCREENROTATION)
			|| (*(DWORD*)pvIn == IOCTL_POWER_SET)
			|| (*(DWORD*)pvIn == IOCTL_POWER_GET)
			)
		{
			// The escape is supported.
			return 1;
		}
		else
		{
			// The escape isn't supported.
#if DO_DISPPERF
			return DispPerfQueryEsc(*(DWORD*)pvIn);;
#else
			return 0;
#endif
		}
	}
	else if (iEsc == DRVESC_GETSCREENROTATION)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] DrvEscape() : DRVESC_GETSCREENROTATION\n\r")));

		*(int *)pvOut = ((DMDO_0 | DMDO_90 | DMDO_180 | DMDO_270) << 8) | ((BYTE)m_iRotate);

		return DISP_CHANGE_SUCCESSFUL;
	}
	else if (iEsc == DRVESC_SETSCREENROTATION)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] DrvEscape() : DRVESC_SETSCREENROTATION\n\r")));

		if ((cjIn == DMDO_0)   ||
			(cjIn == DMDO_90)  ||
			(cjIn == DMDO_180) ||
			(cjIn == DMDO_270) )
		{
			return DynRotate(cjIn);
		}

		return DISP_CHANGE_BADMODE;
	}
	else if(iEsc == IOCTL_POWER_SET)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] DrvEscape() : IOCTL_POWER_SET[%x]\n\r"),iEsc));

		if(pvIn != NULL && cjIn == sizeof(CEDEVICE_POWER_STATE))
		{

			CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE) pvIn;
			if(VALID_DX(NewDx))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] DrvEscape() : IOCTL_POWER_SET(D%d)\n\r"), NewDx));
				if(NewDx == D4)
				{
					//power off
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ]Power Off\n\r"), NewDx));
				}
				else if(NewDx == D0)
				{
					//power on
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ]Power On\n\r"), NewDx));
				}
				Result = ESC_SUCCESS;
			}

		}

		return Result;
	}
	else if(iEsc == IOCTL_POWER_GET)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] DrvEscape() : IOCTL_POWER_GET\n\r")));

		if(pvOut != NULL && cjOut == sizeof(CEDEVICE_POWER_STATE))
		{

			Result = ESC_SUCCESS;
		}

		return Result;
	}
	else if(iEsc == DRVESC_OUTPUT_RGB)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] DrvEscape() : DRVESC_OUTPUT_RGB\n\r")));
		if (DrvControlOutput(OUTPUT_IF_RGB))
		{
			return ESC_SUCCESS;
		}
		else
		{
			return ESC_FAILED;
		}
	}
	/*
	else if(iEsc == DRV_LDCD_SET_BASEADDRESS)
	else if(iEsc == DRV_LDCD_GET_BASEADDRESS)
	else if(iEsc == DRV_LDCD_SET_POSITION)
	else if(iEsc == DRV_LDCD_GET_POSITION)
	else if(iEsc == DRV_LDCD_SET_COLORKEY)
	else if(iEsc == DRV_LDCD_GET_POSITION)
	*/


	return 0;
}

void TCCDISP::SetVisibleSurface(GPESurf *pSurf, BOOL bWaitForVBlank,DWORD dwIndex)
{
	TCCDISPSurf *pDDSurf = (TCCDISPSurf *)pSurf;

	DWORD dwFrameBuffer = pDDSurf->OffsetInVideoMemory() + m_VideoMemoryPhysicalBase;
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("SetVisibleSurface : %x , %d \n"),dwFrameBuffer,pDDSurf->IsOverlay()));
	if(pDDSurf->IsOverlay() == TRUE)
	{
		m_OverlayCtxt[dwIndex].pPrevSurface = m_OverlayCtxt[dwIndex].pSurface;		// Being Flipped Surface
		m_OverlayCtxt[dwIndex].pSurface = pDDSurf;
		if(dwIndex == 0)
			pLCD->LI2BA0 = dwFrameBuffer;
		if(dwIndex == 1)
			pLCD->LI0BA0 = dwFrameBuffer;
	}
	else
	{
		m_pVisibleSurface = pDDSurf;
//		if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nDemoType == 1)
//		{
//			pLCDCIMG[0]->LIxBA0 = dwFrameBuffer;
//			pLCDCIMG[1]->LIxBA0 = dwFrameBuffer;
//
//			return;
//		}
		//if(bWaitForVBlank) 
		//	while(!(pLCD->LSTATUS &Hw31));
		pIMG->LIxBA0 = dwFrameBuffer;

		DemoType1_UI_IMGs_Cfg_Sync();

		if(bWaitForVBlank)
		{
			pLCD->LSTATUS |= Hw3;
			while(!(pLCD->LSTATUS &Hw3));
		}
	}
}




void
TCCDISP::WaitForNotBusy(void)
{
	//RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("WaitForNotBusy\n\r")));
	return;
}

int
TCCDISP::IsBusy(void)
{
	//RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("IsBusy\n\r")));
	return    0;
}


int
TCCDISP::InDisplay(void)
{
	//RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("InDisplay\n\r")));

	return TRUE;
}

int
TCCDISP::InVBlank(void)
{
	//RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("InVBlank\n\r")));

	return TRUE;
}

SCODE
TCCDISP::SetPalette(const PALETTEENTRY *source, USHORT firstEntry, USHORT numEntries)
{
	DEBUGMSG (GPE_ZONE_INIT, (TEXT("TCCDISP::SetPalette\r\n")));

	if (firstEntry < 0 || firstEntry + numEntries > 256 || source == NULL)
	{
		return  E_INVALIDARG;
	}

	return S_OK;
}

int
TCCDISP::GetGameXInfo(ULONG iEsc, ULONG cjIn, PVOID pvIn, ULONG cjOut, PVOID pvOut)
{
	int     RetVal = 0;     // Default not supported
	GXDeviceInfo * pgxoi;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] ++TCCDISP::GetGameXInfo()\n\r")));

	// GAPI only support P8, RGB444, RGB555, RGB565, and RGB888
	if ((cjOut >= sizeof(GXDeviceInfo)) && (pvOut != NULL)
		&& (m_pMode->Bpp == 8 || m_pMode->Bpp == 16 || m_pMode->Bpp == 24 || m_pMode->Bpp == 32))
	{
		if (((GXDeviceInfo *) pvOut)->idVersion == kidVersion100)
		{
			pgxoi = (GXDeviceInfo *) pvOut;
			pgxoi->idVersion = kidVersion100;
			pgxoi->pvFrameBuffer = (void *)m_pPrimarySurface->Buffer();
			pgxoi->cbStride = m_pPrimarySurface->Stride();
			pgxoi->cxWidth = m_pPrimarySurface->Width();
			pgxoi->cyHeight = m_pPrimarySurface->Height();

			if (m_pMode->Bpp == 8)
			{
				pgxoi->cBPP = 8;
				pgxoi->ffFormat = kfPalette;
			}
			else if (m_pMode->Bpp == 16)
			{
				pgxoi->cBPP = 16;
				pgxoi->ffFormat= kfDirect | kfDirect565;
			}
			else if (m_pMode->Bpp == 24)
			{
				pgxoi->cBPP = 24;
				pgxoi->ffFormat = kfDirect | kfDirect888;
			}
			else
			{
				pgxoi->cBPP = 32;
				pgxoi->ffFormat = kfDirect | kfDirect888;
			}

			pgxoi->vkButtonUpPortrait = VK_UP;
			pgxoi->vkButtonUpLandscape = VK_LEFT;
			pgxoi->vkButtonDownPortrait = VK_DOWN;
			pgxoi->vkButtonDownLandscape = VK_RIGHT;
			pgxoi->vkButtonLeftPortrait = VK_LEFT;
			pgxoi->vkButtonLeftLandscape = VK_DOWN;
			pgxoi->vkButtonRightPortrait = VK_RIGHT;
			pgxoi->vkButtonRightLandscape = VK_UP;
			pgxoi->vkButtonAPortrait = 0xC3;            // far right button
			pgxoi->vkButtonALandscape = 0xC5;            // record button on side
			pgxoi->vkButtonBPortrait = 0xC4;            // second from right button
			pgxoi->vkButtonBLandscape = 0xC1;
			pgxoi->vkButtonCPortrait = 0xC5;            // far left button
			pgxoi->vkButtonCLandscape = 0xC2;            // far left button
			pgxoi->vkButtonStartPortrait = 134;            // action button
			pgxoi->vkButtonStartLandscape = 134;
			pgxoi->ptButtonUp.x = 120;
			pgxoi->ptButtonUp.y = 330;
			pgxoi->ptButtonDown.x = 120;
			pgxoi->ptButtonDown.y = 390;
			pgxoi->ptButtonLeft.x = 90;
			pgxoi->ptButtonLeft.y = 360;
			pgxoi->ptButtonRight.x = 150;
			pgxoi->ptButtonRight.y = 360;
			pgxoi->ptButtonA.x = 180;
			pgxoi->ptButtonA.y = 330;
			pgxoi->ptButtonB.x = 210;
			pgxoi->ptButtonB.y = 345;
			pgxoi->ptButtonC.x = -50;
			pgxoi->ptButtonC.y = 0;
			pgxoi->ptButtonStart.x = 120;
			pgxoi->ptButtonStart.y = 360;
			pgxoi->pvReserved1 = (void *) 0;
			pgxoi->pvReserved2 = (void *) 0;
			RetVal = ESC_SUCCESS;
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPDRV:ERR] GetGameXInfo() : Invalid Parameter\n\r")));
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = ESC_FAILED;
		}

	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPDRV:ERR] GetGameXInfo() : Invalid Parameter\n\r")));
		SetLastError (ERROR_INVALID_PARAMETER);
		RetVal = ESC_FAILED;
	}

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] --TCCDISP::GetGameXInfo()\n\r")));

	return(RetVal);
}



int
TCCDISP::GetRotateModeFromReg()
{
	HKEY hKey;
	int iRet = DMDO_0;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++TCCDISP::GetRotateModeFromReg()\n\r")));

	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("SYSTEM\\GDI\\ROTATION"), 0, 0, &hKey))
	{
		DWORD dwSize, dwAngle, dwType = REG_DWORD;

		dwSize = sizeof(DWORD);
		if (ERROR_SUCCESS == RegQueryValueEx(hKey, TEXT("ANGLE"), NULL, &dwType, (LPBYTE)&dwAngle, &dwSize))
		{
			switch (dwAngle)
			{
			case 0:
				iRet = DMDO_0;
				break;

			case 90:
				iRet = DMDO_90;
				break;

			case 180:
				iRet = DMDO_180;
				break;

			case 270:
				iRet = DMDO_270;
				break;

			default:
				iRet = DMDO_0;
				break;
			}
		}

		RegCloseKey(hKey);
	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPDRV:ERR] GetRotateModeFromReg() : RegOpenKeyEx() Fail\n\r")));
	}

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] --TCCDISP::GetRotateModeFromReg() = %d\n\r"), iRet));

	return iRet;
}



void
TCCDISP::ReleaseResource(void)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++TCCDISP::ReleaseResource()\n\r")));


	if (m_pVideoMemoryHeap != NULL)
	{
		delete m_pVideoMemoryHeap;
	}

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] --TCCDISP::ReleaseResource()\n\r")));
}

void
TCCDISP::SetDisplayPowerState(VIDEO_POWER_STATE PowerState)
{
	static BYTE * pVideoMemory = NULL;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++TCCDISP::SetDisplayPowerState(%d)\n\r"), PowerState));

	// If we're already in the appropriate state, just return
	if (m_VideoPowerState == PowerState)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] SetDisplayPowerState() : Same as current State [%d]\n\r"), m_VideoPowerState));
		return;
	}

	if (PowerState == VideoPowerOn)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] SetDisplayPowerState() : VideoPowerOn\n\r")));

		if (m_VideoPowerState == VideoPowerOn)
		{
			// Do Nothing
		}
		else		// from VideoPowerOff or VideoPowerSuspend
		{
			//DevPowerOn();

			DynRotate(m_iRotate);

			m_CursorDisabled = FALSE;

		}

		m_VideoPowerState = VideoPowerOn;

	}
	else if (PowerState == VideoPowerOff)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] SetDisplayPowerState() : VideoPowerOff\n\r")));

		if (m_VideoPowerState == VideoPowerOff)
		{
			// Do Nothing
		}
		else		// from VideoPowerOn or VideoPowerStandby
		{
			m_CursorDisabled = TRUE;
			CursorOff();

			// Turn Off Display Controller
			//DevPowerOff();
		}

		m_VideoPowerState = VideoPowerOff;
	}
}


VIDEO_POWER_STATE
TCCDISP::GetDisplayPowerState(void)
{
	return m_VideoPowerState;
}


BOOL
TCCDISP::WaitForVerticalBlank(VB_STATUS Status)
{
	BOOL bRet = FALSE;

	//RETAILMSG(1,(TEXT("+WaitForVerticalBlank %x\n"),pLCD->LSTATUS));
	bRet = TRUE; 
	while((pLCD->LSTATUS &Hw31));
	//RETAILMSG(1,(TEXT(".")));;
		
	//RETAILMSG(1,(TEXT("-WaitForVerticalBlank %x\n"),pLCD->LSTATUS));

	return bRet;
}


DWORD
TCCDISP::GetScanLine(void)
{
	DWORD dwRet = 0;

	//dwRet = DevGetScanLine();

	return dwRet;
}


BOOL
TCCDISP::OverlayAllocResource(BOOL bLocalPath)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++OverlayAllocResource(%d)\n\r"), bLocalPath));


	return TRUE;
}


BOOL
TCCDISP::OverlayReleaseResource(BOOL bLocalPath)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++OverlayReleaseResource(%d)\n\r"), bLocalPath));

	BOOL bRet = TRUE;
	//	DWORD dwBytes;

	return bRet;
}

enum PixelFormatType
{
	IMG_1BPP=0,
	IMG_2BPP, //1
	IMG_4BPP,
	IMG_8BPP,
	NOTUSING1,
	NOTUSING2,
	NOTUSING3,
	NOTUSING4,
	IMG_RGB332,
	IMG_RGB444,
	IMG_RGB565, //10
	IMG_RGB555,
	IMG_RGB888,
	IMG_RGB666,
	NOTUSING5,
	NOTUSING6,
	NOTUSING7,
	NOTUSING8,
	NOTUSING9,
	NOTUSING10,
	NOTUSING11,//20
	NOTUSING12,
	NOTUSING13,
	NOTUSING14,
	IMG_YVU420,
	IMG_YVU422_SP,
	IMG_YVU422_SQ
	
};

BOOL
TCCDISP::OverlayInitialize(TCCDISPSurf* pOverlaySurface, RECT *pSrc, RECT *pDest, DWORD dwIndex)
{
	BOOL bRet = TRUE;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] OverlayInitialize() (%d,%d) (%d,%d,%d,%d) (%d,%d,%d,%d)\n\r"),
		pOverlaySurface->Width(), pOverlaySurface->Height(),
		pSrc->left, pSrc->top, pSrc->right, pSrc->bottom,
		pDest->left, pDest->top, pDest->right, pDest->bottom
		));

	EnterCriticalSection(&m_csDevice);

	m_OverlayCtxt[dwIndex].pSurface = pOverlaySurface;

	// Driver support Overlay Source Clipping
	m_OverlayCtxt[dwIndex].uiSrcWidth = pSrc->right - pSrc->left;
	m_OverlayCtxt[dwIndex].uiSrcHeight = pSrc->bottom - pSrc->top;
	m_OverlayCtxt[dwIndex].uiSrcOffsetX = pSrc->left;
	m_OverlayCtxt[dwIndex].uiSrcOffsetY = pSrc->top;

	//  Driver support Overlay Destination Stretch
	m_OverlayCtxt[dwIndex].uiDstWidth = pDest->right - pDest->left;
	m_OverlayCtxt[dwIndex].uiDstHeight = pDest->bottom - pDest->top;
	m_OverlayCtxt[dwIndex].uiDstOffsetX = pDest->left;
	m_OverlayCtxt[dwIndex].uiDstOffsetY = pDest->top;
	
	if(dwIndex == 0)
	{
		//initialize LI2C register
		pLCD->LI2C = 
		//Hw31| //dma
		//Hw30| //alpha-blending
		//Hw29| //chroma-keying
		//Hw28|  //enable
		//Hw27|  //image source
		//Hw26|Hw25| //alphablending option
		//Hw24| //
		//Hw15|//padding
		Hw9|//Hw10|Hw9|
		//Hw8|
		//Hw7|
		//10|// 12: RGB888, 10:RGB565 Hw4|Hw3|Hw2|Hw1|Hw0|
		0;
	}else if(dwIndex == 1)
	{
		//initialize LI2C register
		pLCD->LI0C = 
		//Hw31| //dma
		//Hw30| //alpha-blending
		//Hw29| //chroma-keying
		//Hw28|  //enable
		//Hw27|  //image source
		//Hw26|Hw25| //alphablending option
		//Hw24| //
		//Hw15|//padding
		Hw9|//Hw10|Hw9|
		//Hw8|
		//Hw7|
		//10|// 12: RGB888, 10:RGB565 Hw4|Hw3|Hw2|Hw1|Hw0|
		0;
	}

	switch(m_OverlayCtxt[dwIndex].pSurface->PixelFormat())
	{
	case ddgpePixelFormat_5551:
	case ddgpePixelFormat_5550:
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Overay Initialize: pixelformat:555:%x\n\r"),m_OverlayCtxt[dwIndex].pSurface->PixelFormat()));
				
			// Use Local Path for RGB
			m_OverlayCtxt[dwIndex].bLocalPath = TRUE;
			m_OverlayCtxt[dwIndex].dwBPPMode = gpe16Bpp;
			m_OverlayCtxt[dwIndex].dwPostSrcType = IMG_RGB555;
		if(dwIndex == 0)
		{
			pLCD->LI2C &= ~0x1F;
			pLCD->LI2C |= IMG_RGB555;

			pLCD->LI2S = m_OverlayCtxt[dwIndex].uiSrcWidth|m_OverlayCtxt[dwIndex].uiSrcHeight<<16;
			pLCD->LI2O = m_OverlayCtxt[dwIndex].uiSrcWidth*2;
		}
		else if(dwIndex == 1)
		{
			pLCD->LI0C &= ~0x1F;
			pLCD->LI0C |= IMG_RGB555;

			pLCD->LI0S = m_OverlayCtxt[dwIndex].uiSrcWidth|m_OverlayCtxt[dwIndex].uiSrcHeight<<16;
			pLCD->LI0O = m_OverlayCtxt[dwIndex].uiSrcWidth*2;
		}

		}
		break;
	case ddgpePixelFormat_565:
		
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Overay Initialize: pixelformat:565:%x\n\r"),m_OverlayCtxt[dwIndex].pSurface->PixelFormat()));
				
			// Use Local Path for RGB
			m_OverlayCtxt[dwIndex].bLocalPath = TRUE;
			m_OverlayCtxt[dwIndex].dwBPPMode = gpe16Bpp;
			m_OverlayCtxt[dwIndex].dwPostSrcType = IMG_RGB565;
			if(dwIndex == 0)
			{		
				pLCD->LI2C &= ~0x1F;
				pLCD->LI2C |= IMG_RGB565;
				pLCD->LI2S = m_OverlayCtxt[dwIndex].uiSrcWidth|m_OverlayCtxt[dwIndex].uiSrcHeight<<16;
				pLCD->LI2O = m_OverlayCtxt[dwIndex].uiSrcWidth*2;
			}
			else if(dwIndex == 1)
			{
				pLCD->LI0C &= ~0x1F;
				pLCD->LI0C |= IMG_RGB565;
				pLCD->LI0S = m_OverlayCtxt[dwIndex].uiSrcWidth|m_OverlayCtxt[dwIndex].uiSrcHeight<<16;
				pLCD->LI0O = m_OverlayCtxt[dwIndex].uiSrcWidth*2;
			}
		}
		break;
	case ddgpePixelFormat_8880:	
	case ddgpePixelFormat_8888:
		
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Overay Initialize: pixelformat:888:%x\n\r"),m_OverlayCtxt[dwIndex].pSurface->PixelFormat()));
				
			// Use Local Path for RGB
			m_OverlayCtxt[dwIndex].bLocalPath = TRUE;
			m_OverlayCtxt[dwIndex].dwBPPMode = gpe24Bpp;
			m_OverlayCtxt[dwIndex].dwPostSrcType = IMG_RGB888;
			if(dwIndex == 0)
			{	
				pLCD->LI2C &= ~0x1F;
				pLCD->LI2C |= IMG_RGB888;
				pLCD->LI2S = m_OverlayCtxt[dwIndex].uiSrcWidth|m_OverlayCtxt[dwIndex].uiSrcHeight<<16;
				pLCD->LI2O = m_OverlayCtxt[dwIndex].uiSrcWidth*4;
			}else if(dwIndex == 1)
			{
				pLCD->LI0C &= ~0x1F;
				pLCD->LI0C |= IMG_RGB888;
				pLCD->LI0S = m_OverlayCtxt[dwIndex].uiSrcWidth|m_OverlayCtxt[dwIndex].uiSrcHeight<<16;
				pLCD->LI0O = m_OverlayCtxt[dwIndex].uiSrcWidth*4;
			
			}

		}
	case ddgpePixelFormat_YUYV:
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Overay Initialize: pixelformat:YUYV:%x\n\r"),m_OverlayCtxt[dwIndex].pSurface->PixelFormat()));
				
			// Use Local Path for YUV
			m_OverlayCtxt[dwIndex].bLocalPath = TRUE;
			m_OverlayCtxt[dwIndex].dwBPPMode = gpe16Bpp;
			m_OverlayCtxt[dwIndex].dwPostSrcType = IMG_YVU422_SQ;
			if(dwIndex == 1)
			{
				pLCD->LI0C &= ~0x1F;
				pLCD->LI0C |= IMG_YVU422_SQ;
				pLCD->LI0S = m_OverlayCtxt[dwIndex].uiSrcWidth|m_OverlayCtxt[dwIndex].uiSrcHeight<<16;
				pLCD->LI0O = m_OverlayCtxt[dwIndex].uiSrcWidth*2;
			
			}
			else
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Does Not support pixelformat:%x index error\n\r"),m_OverlayCtxt[dwIndex].pSurface->PixelFormat()));

		}
		break;
	default:
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Does Not support pixelformat:%x\n\r"),m_OverlayCtxt[dwIndex].pSurface->PixelFormat()));
		break;
		
	}

	//OverlaySetPixelFormat();

	LeaveCriticalSection(&m_csDevice);

	return bRet;
}


void
TCCDISP::OverlaySetPosition(UINT32 uiOffsetX, UINT32 uiOffsetY, DWORD dwIndex)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("OverlaySetPosition(%d,%d)\n\r"), uiOffsetX, uiOffsetY));
	
	if(dwIndex ==0)
		pLCD->LI2P = uiOffsetX|uiOffsetY<<16;
	else if(dwIndex ==1)
		pLCD->LI0P = uiOffsetX|uiOffsetY<<16;

}
void 
TCCDISP::OverlaySetPixelFormat(DWORD dwIndex)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] TCCDISP::OverlaySetPixelFormat() %d \n\r"),m_OverlayCtxt[dwIndex].dwBPPMode));
	if(m_OverlayCtxt[dwIndex].dwBPPMode == gpe16Bpp)
	{
		if(dwIndex == 0)
		{
			pLCD->LI2C &= ~0x1F;
			pLCD->LI2C |= 10;
		}
		else if(dwIndex ==1)
		{
			pLCD->LI0C &= ~0x1F;
			pLCD->LI0C |= 10;
		}
	}
	if(m_OverlayCtxt[dwIndex].dwBPPMode == gpe16Bpp)
	{
		if(dwIndex == 0)
		{
			pLCD->LI2C &= ~0x1F;
			pLCD->LI2C |= 10;
		}
		else if(dwIndex == 1)
		{
			pLCD->LI0C &= ~0x1F;
			pLCD->LI0C |= 10;
		}
	}
	else if(m_OverlayCtxt[dwIndex].dwBPPMode == gpe24Bpp)
	{
		if(dwIndex == 0)
		{
			pLCD->LI2C |= 12;
		}else if(dwIndex == 1)
		{
			pLCD->LI0C |= 12;
		}
	}
}

void
TCCDISP::OverlayEnable(DWORD dwIndex)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] TCCDISP::OverlayEnable()\n\r")));

	EnterCriticalSection(&m_csDevice);

	m_OverlayCtxt[dwIndex].bShow = TRUE;

//	DevOverlayEnable();
	/*
	pLCD->LI2C = 
		//Hw31| //dma
		//Hw30| //alpha-blending
		//Hw29| //chroma-keying
		Hw28|  //enable
		//Hw27|  //image source
		Hw26|Hw25| //alphablending option
		//Hw24| //
		//Hw15|//padding
		Hw9|//Hw10|Hw9|
		//Hw8|
		//Hw7|
		10|// 12: RGB888, 10:RGB565 Hw4|Hw3|Hw2|Hw1|Hw0|
		0;
		*/
	if(dwIndex == 0)
		pLCD->LI2C |= Hw28;
	else if(dwIndex ==1)
		pLCD->LI0C |= Hw28;


	LeaveCriticalSection(&m_csDevice);
}


void
TCCDISP::OverlayDisable(DWORD dwIndex)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] TCCDISP::OverlayDisable()\n\r")));

	m_OverlayCtxt[dwIndex].pSurface = NULL;
	m_OverlayCtxt[dwIndex].pPrevSurface = NULL;

	m_OverlayCtxt[dwIndex].bShow = FALSE;

	EnterCriticalSection(&m_csDevice);

	//DevOverlayDisable();
	/*pLCD->LI2C = 
		//Hw31| //dma
		//Hw30| //alpha-blending
		//Hw29| //chroma-keying
		//Hw28|  //enable
		//Hw27|  //image source
		Hw26|Hw25| //alphablending option
		//Hw24| //
		//Hw15|//padding
		Hw9|//Hw10|Hw9|
		//Hw8|
		//Hw7|
		10|// 12: RGB888, 10:RGB565 Hw4|Hw3|Hw2|Hw1|Hw0|
		0;
*/
	if(dwIndex == 0)
		pLCD->LI2C &= ~Hw28;
	else if(dwIndex ==1)
		pLCD->LI0C &= ~Hw28;

	
	LeaveCriticalSection(&m_csDevice);

	// Release H/W Resource for Overlay to Video Engine Driver
	OverlayReleaseResource(m_OverlayCtxt[dwIndex].bLocalPath);
}

void
TCCDISP::OverlaySetColorKey(BOOL bSrcCKey, EDDGPEPixelFormat Format, DWORD ColorKey,DWORD dwIndex)
{

	RETAILMSG(1,(TEXT("OverlaySetColorKey keyvalue:%x \n"),ColorKey));
	m_OverlayCtxt[dwIndex].bBlendOn = TRUE;
	m_OverlayCtxt[dwIndex].bColorKey = TRUE;
	m_OverlayCtxt[dwIndex].bSrcCKey = bSrcCKey;

	if (Format == ddgpePixelFormat_565)	// RGB565
	{
		m_OverlayCtxt[dwIndex].ColorKey =ColorKey;
		m_OverlayCtxt[dwIndex].CompareKey = 0x00070307;
		if(dwIndex ==0)
		{
			pLCD->LI2KR = ((ColorKey&0xF800)>>11)<<3|(0xFF)<<16;
			pLCD->LI2KG = ((ColorKey&0x07E0)>>5 )<<2|(0xFF)<<16;
			pLCD->LI2KB = ((ColorKey&0x001F)>>3 )<<3|(0xFF)<<16;
			pLCD->LI2C &= ~Hw29; //chroma-key Enable
			pLCD->LI2C |= Hw29; //chroma-key Enable
		}else if(dwIndex == 1)
		{
			pLCD->LI0KR = ((ColorKey&0xF800)>>11)<<3|(0xFF)<<16;
			pLCD->LI0KG = ((ColorKey&0x07E0)>>5 )<<2|(0xFF)<<16;
			pLCD->LI0KB = ((ColorKey&0x001F)>>3 )<<3|(0xFF)<<16;
			pLCD->LI0C &= ~Hw29; //chroma-key Enable
			pLCD->LI0C |= Hw29; //chroma-key Enable
		}

	}
	else if (Format == ddgpePixelFormat_5550 || Format == ddgpePixelFormat_5551)	// RGB555
	{
		m_OverlayCtxt[dwIndex].ColorKey =ColorKey;
		m_OverlayCtxt[dwIndex].CompareKey = 0x00070307;
		if(dwIndex ==0)
		{
			pLCD->LI2KR = ((ColorKey&0x7C00)>>10)<<3|(0xFF)<<16;
			pLCD->LI2KG = ((ColorKey&0x03e0)>>5 )<<3|(0xFF)<<16;
			pLCD->LI2KB = ((ColorKey&0x001F)>>3 )<<3|(0xFF)<<16;
			pLCD->LI2C &= ~Hw29; //chroma-key Enable
			pLCD->LI2C |= Hw29; //chroma-key Enable
		}else if(dwIndex == 1)
		{
			pLCD->LI0KR = ((ColorKey&0x7C00)>>10)<<3|(0xFF)<<16;
			pLCD->LI0KG = ((ColorKey&0x03e0)>>5 )<<3|(0xFF)<<16;
			pLCD->LI0KB = ((ColorKey&0x001F)>>3 )<<3|(0xFF)<<16;
			pLCD->LI0C &= ~Hw29; //chroma-key Enable
			pLCD->LI0C |= Hw29; //chroma-key Enable
		}
	}else	// if (Format == ddgpePixelFormat_8888)	// RGB888
	{
		m_OverlayCtxt[dwIndex].ColorKey =ColorKey;
		m_OverlayCtxt[dwIndex].CompareKey = 0x00070307;
		
		if(dwIndex ==0)
		{
			pLCD->LI2KR = ((ColorKey&0xFF0000))|(0xFF)<<16;
			pLCD->LI2KG = ((ColorKey&0xFF00) ) |(0xFF)<<16;
			pLCD->LI2KB = ((ColorKey&0xFF) )   |(0xFF)<<16;
			pLCD->LI2C &= ~Hw29; //chroma-key Enable
			pLCD->LI2C |= Hw29; //chroma-key Enable
		}else if(dwIndex == 1)
		{
			pLCD->LI0KR = ((ColorKey&0xFF0000))|(0xFF)<<16;
			pLCD->LI0KG = ((ColorKey&0xFF00) ) |(0xFF)<<16;
			pLCD->LI0KB = ((ColorKey&0xFF) )   |(0xFF)<<16;
			pLCD->LI0C &= ~Hw29; //chroma-key Enable
			pLCD->LI0C |= Hw29; //chroma-key Enable
			if (Format == ddgpePixelFormat_YUYV)
			{
				pLCD->LI0C &= ~Hw8; //Y2R Disable
				pLCD->LI0C |= Hw8;  //Y2R Enable
			}
			else
			{
				pLCD->LI0C &= ~Hw8; //Y2R Disable
			}
		}
	}
	

}

void
TCCDISP::OverlaySetAlpha(BOOL bUsePixelBlend, DWORD Alpha,DWORD dwIndex)
{

	RETAILMSG(1,(TEXT("OverlaySetAlpha Alpha:%x \n"),Alpha));
	m_OverlayCtxt[dwIndex].bBlendOn = TRUE;
	m_OverlayCtxt[dwIndex].bColorKey = FALSE;
	m_OverlayCtxt[dwIndex].bUsePixelBlend = bUsePixelBlend;
	m_OverlayCtxt[dwIndex].Alpha = Alpha;

	if(dwIndex ==0)
	{
		pLCD->LI2A = Alpha|(Alpha<<16);
		pLCD->LI2C &=~Hw30;
		pLCD->LI2C |=Hw30;
	}else if(dwIndex ==1)
	{
		pLCD->LI0A = Alpha|(Alpha<<16);
		pLCD->LI0C &=~Hw30;
		pLCD->LI0C |=Hw30;
	}
}

void
TCCDISP::OverlayBlendDisable(DWORD dwIndex)
{
	RETAILMSG(1,(TEXT("OverlayBlendDisable \n")));
	m_OverlayCtxt[dwIndex].bBlendOn = FALSE;
	if(dwIndex ==0)
		pLCD->LI2C &= ~Hw30;
	else if(dwIndex ==1)
		pLCD->LI0C &= ~Hw30;
}


void
TCCDISP::InitalizeOverlayContext(DWORD dwIndex)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] ++InitalizeOverlayContext()\n\r")));

	m_OverlayCtxt[dwIndex].pSurface = NULL;			// Current Overlay Surface
	m_OverlayCtxt[dwIndex].pPrevSurface = NULL;

	m_OverlayCtxt[dwIndex].bLocalPath = FALSE;
	m_OverlayCtxt[dwIndex].uiSrcWidth = 0;
	m_OverlayCtxt[dwIndex].uiSrcHeight = 0;
	m_OverlayCtxt[dwIndex].uiSrcOffsetX = 0;
	m_OverlayCtxt[dwIndex].uiSrcOffsetY = 0;
	m_OverlayCtxt[dwIndex].uiDstWidth = 0;
	m_OverlayCtxt[dwIndex].uiDstHeight = 0;
	m_OverlayCtxt[dwIndex].uiDstOffsetX = 0;
	m_OverlayCtxt[dwIndex].uiDstOffsetY = 0;
	m_OverlayCtxt[dwIndex].bEnabled = FALSE;
	m_OverlayCtxt[dwIndex].bShow = FALSE;

	m_OverlayCtxt[dwIndex].bBlendOn = FALSE;
	m_OverlayCtxt[dwIndex].bColorKey = 0x0;
	m_OverlayCtxt[dwIndex].bSrcCKey = FALSE;
	m_OverlayCtxt[dwIndex].CompareKey = 0x0;
	m_OverlayCtxt[dwIndex].ColorKey = 0x0;
	m_OverlayCtxt[dwIndex].bUsePixelBlend = FALSE;
	m_OverlayCtxt[dwIndex].Alpha = 0x0;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] --InitalizeOverlayContext()\n\r")));
}


TCCDISPSurf*
TCCDISP::GetCurrentOverlaySurf(DWORD dwIndex)
{
	return m_OverlayCtxt[dwIndex].pSurface;
}


TCCDISPSurf*
TCCDISP::GetPreviousOverlaySurf(DWORD dwIndex)
{
	return m_OverlayCtxt[dwIndex].pPrevSurface;
}


// this routine converts a string into a GUID and returns TRUE if the
// conversion was successful.
BOOL
ConvertStringToGuid (LPCTSTR pszGuid, GUID *pGuid)
{
	UINT Data4[8];
	int  Count;
	BOOL fOk = FALSE;
	TCHAR *pszGuidFormat = _T("{%08lX-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}");

	DEBUGCHK(pGuid != NULL && pszGuid != NULL);
	__try
	{
		if (_stscanf(pszGuid, pszGuidFormat, &pGuid->Data1,
			&pGuid->Data2, &pGuid->Data3, &Data4[0], &Data4[1], &Data4[2], &Data4[3],
			&Data4[4], &Data4[5], &Data4[6], &Data4[7]) == 11)
		{
			for(Count = 0; Count < (sizeof(Data4) / sizeof(Data4[0])); Count++)
			{
				pGuid->Data4[Count] = (UCHAR) Data4[Count];
			}
		}
		fOk = TRUE;
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
	}

	return fOk;
}


