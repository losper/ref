typedef volatile struct
{
	unsigned	SADDR0;			// Front-End Channel Source Address 0 (Y or Frame Base)
	unsigned	SADDR1;			// Front-End Channel Source Address 1 (U Base)
	unsigned	SADDR2;			// Front-End Channel Source Address 2 (V Base)
	unsigned	SFSIZE;			// Front-End Channel Source Frame Pixel Size
#define	HwGE_FCH_SFSIZE_X(X)				((X)*Hw0)
#define	HwGE_FCH_SFSIZE_X_MASK				HwGE_FCH_SFSIZE_X(4095)
#define	HwGE_FCH_SFSIZE_Y(X)				((X)*Hw16)
#define	HwGE_FCH_SFSIZE_Y_MASK				HwGE_FCH_SFSIZE_Y(4095)
	unsigned	SOFF;			// Front-End Channel Source Pixel Offset
#define	HwGE_FCH_SOFF_X(X)					((X)*Hw0)
#define	HwGE_FCH_SOFF_X_MASK				HwGE_FCH_SOFF_X(4095)
#define	HwGE_FCH_SOFF_Y(X)					((X)*Hw16)
#define	HwGE_FCH_SOFF_Y_MASK				HwGE_FCH_SOFF_Y(4095)
	unsigned	SISIZE;			// Front-End Channel Source Image Pixel Size
#define	HwGE_FCH_SISIZE_X(X)				((X)*Hw0)
#define	HwGE_FCH_SISIZE_X_MASK				HwGE_FCH_SISIZE_X(4095)
#define	HwGE_FCH_SISIZE_Y(X)				((X)*Hw16)
#define	HwGE_FCH_SISIZE_Y_MASK				HwGE_FCH_SISIZE_Y(4095)
	unsigned	WOFF;			// Front-End Channel Window Pixel Offset
#define	HwGE_FCH_WOFF_X(X)					((X)*Hw0)
#define	HwGE_FCH_WOFF_X_MASK				HwGE_FCH_WOFF_X(4095)
#define	HwGE_FCH_WOFF_Y(X)					((X)*Hw16)
#define	HwGE_FCH_WOFF_Y_MASK				HwGE_FCH_WOFF_Y(4095)
	unsigned	SCTRL;			// Front-End Channel Control
#define	HwGE_FCH_SCTRL_OPMODE(X)			((X)*Hw8)						// Operation Mode
#define	HwGE_FCH_SCTRL_OPMODE_COPY			HwGE_FCH_SCTRL_OPMODE(0)		// Data Copy
#define	HwGE_FCH_SCTRL_OPMODE_HMIRROR		HwGE_FCH_SCTRL_OPMODE(2)		// Horizontal Mirror
#define	HwGE_FCH_SCTRL_OPMODE_VMIRROR		HwGE_FCH_SCTRL_OPMODE(3)		// Vertical Mirror
#define	HwGE_FCH_SCTRL_OPMODE_VHMIRROR		HwGE_FCH_SCTRL_OPMODE(4)		// Vertical & Horizontal Mirror
#define	HwGE_FCH_SCTRL_OPMODE_ROT90			HwGE_FCH_SCTRL_OPMODE(5)		// 90 Degree Rotate
#define	HwGE_FCH_SCTRL_OPMODE_ROT180		HwGE_FCH_SCTRL_OPMODE(6)		// 180 Degree Rotate
#define	HwGE_FCH_SCTRL_OPMODE_ROT270		HwGE_FCH_SCTRL_OPMODE(7)		// 270 Degree Rotate
#define	HwGE_FCH_SCTRL_OPMODE_MASK			HwGE_FCH_SCTRL_OPMODE(7)
#define	HwGE_FCH_SCTRL_ZF_MSBFILL			HwZERO							// MSB Fill Mode Enable (used when non RGB888/AlphaRGB888 mode)
#define	HwGE_FCH_SCTRL_ZF_ZEROFILL			Hw5								// Zero Fill Mode Enable (used when non RGB888/AlphaRGB888 mode)
#define	HwGE_FCH_SCTRL_ZF_HOBFILL			Hw6								// HOB(High-Order Bits) Fill Mode Enable

#define	HwGE_FCH_SCTRL_SDFRM(X)				((X)*Hw0)						// Source Data Format
#define	HwGE_FCH_SCTRL_SDFRM_YUV444			HwGE_FCH_SCTRL_SDFRM(0)			// Separated YUV 4:4:4
#define	HwGE_FCH_SCTRL_SDFRM_YUV440			HwGE_FCH_SCTRL_SDFRM(1)			// Separated YUV 4:4:0
#define	HwGE_FCH_SCTRL_SDFRM_YUV422			HwGE_FCH_SCTRL_SDFRM(2)			// Separated YUV 4:2:2
#define	HwGE_FCH_SCTRL_SDFRM_YUV420			HwGE_FCH_SCTRL_SDFRM(3)			// Separated YUV 4:2:0
#define	HwGE_FCH_SCTRL_SDFRM_YUV411			HwGE_FCH_SCTRL_SDFRM(4)			// Separated YUV 4:1:1
#define	HwGE_FCH_SCTRL_SDFRM_YUV410			HwGE_FCH_SCTRL_SDFRM(5)			// Separated YUV 4:1:0
#define	HwGE_FCH_SCTRL_SDFRM_INTER422		HwGE_FCH_SCTRL_SDFRM(6)			// Interleaved YUV 4:2:2
#define	HwGE_FCH_SCTRL_SDFRM_INTER420		HwGE_FCH_SCTRL_SDFRM(7)			// Interleaved YUV 4:2:0
#define	HwGE_FCH_SCTRL_SDFRM_SEQ444			HwGE_FCH_SCTRL_SDFRM(8)			// Sequential YUV 4:4:4
#define	HwGE_FCH_SCTRL_SDFRM_SEQ422			HwGE_FCH_SCTRL_SDFRM(9)			// Sequential YUV 4:2:0

#define	HwGE_FCH_SCTRL_SDFRM_RGB332			HwGE_FCH_SCTRL_SDFRM(10)		// RGB332
#define	HwGE_FCH_SCTRL_SDFRM_RGB444			HwGE_FCH_SCTRL_SDFRM(12)		// RGB444
#define	HwGE_FCH_SCTRL_SDFRM_ARGB4444		HwGE_FCH_SCTRL_SDFRM(13)		// Alpha-RGB444
#define	HwGE_FCH_SCTRL_SDFRM_RGB454			HwGE_FCH_SCTRL_SDFRM(14)		// RGB454
#define	HwGE_FCH_SCTRL_SDFRM_ARGB3454		HwGE_FCH_SCTRL_SDFRM(15)		// Alpha-RGB3454
#define	HwGE_FCH_SCTRL_SDFRM_RGB555			HwGE_FCH_SCTRL_SDFRM(16)		// RGB555
#define	HwGE_FCH_SCTRL_SDFRM_ARGB1555		HwGE_FCH_SCTRL_SDFRM(17)		// Alpha-RGB1555
#define	HwGE_FCH_SCTRL_SDFRM_RGB565			HwGE_FCH_SCTRL_SDFRM(19)		// RGB565
#define	HwGE_FCH_SCTRL_SDFRM_RGB666			HwGE_FCH_SCTRL_SDFRM(20)		// RGB666

#define	HwGE_FCH_SCTRL_SDFRM_ARGB4666		HwGE_FCH_SCTRL_SDFRM(21)		// Alpha-RGB4666
#define	HwGE_FCH_SCTRL_SDFRM_ARGB6666		HwGE_FCH_SCTRL_SDFRM(22)		// Alpha-RGB5666
#define	HwGE_FCH_SCTRL_SDFRM_RGB888			HwGE_FCH_SCTRL_SDFRM(23)		// RGB888
#define	HwGE_FCH_SCTRL_SDFRM_ARGB4888		HwGE_FCH_SCTRL_SDFRM(24)		// Alpha-RGB4888
#define	HwGE_FCH_SCTRL_SDFRM_ARGB8888		HwGE_FCH_SCTRL_SDFRM(27)		// Alpha-RGB8888
#define	HwGE_FCH_SCTRL_SDFRM_MASK			HwGE_FCH_SCTRL_SDFRM(31)
} sHwGE_FCH;

typedef volatile struct
{
	unsigned	DADDR0;			// Back-End Channel Destination Address 0 (Y or Frame Base Address)
	unsigned	DADDR1;			// Back-End Channel Destination Address 1 (U Base Address)
	unsigned	DADDR2;			// Back-End Channel Destination Address 2 (V Base Address)
	unsigned	DFSIZE;			// Back-End Channel Destination Frame Pixel Size
#define	HwGE_BCH_DFSIZE_X(X)				((X)*Hw0)
#define	HwGE_BCH_DFSIZE_X_MASK				HwGE_BCH_DFSIZE_X(4095)
#define	HwGE_BCH_DFSIZE_Y(X)				((X)*Hw16)
#define	HwGE_BCH_DFSIZE_Y_MASK				HwGE_BCH_DFSIZE_Y(4095)
	unsigned	DOFF;			// Back-End Channel Destination Pixel Offset
#define	HwGE_BCH_DOFF_X(X)					((X)*Hw0)
#define	HwGE_BCH_DOFF_X_MASK				HwGE_BCH_DOFF_X(4095)
#define	HwGE_BCH_DOFF_Y(X)					((X)*Hw16)
#define	HwGE_BCH_DOFF_Y_MASK				HwGE_BCH_DOFF_Y(4095)
	unsigned	DCTRL;			// Back-End Channel Control
#define	HwGE_BCH_DCTRL_R2YEN_EN				Hw15							// RGB to YUV Converter Enable
#define	HwGE_BCH_DCTRL_R2YMODE(X)			((X)*Hw13)						// RGB to YUV Converter Type
#define	HwGE_BCH_DCTRL_R2YMODE_TYPE0		HwGE_BCH_DCTRL_R2YMODE(0)	// Y=0.299R+0.587G+0.114B, U=-0.172R-0.339G+0.511B+128, V=0.511R-0.428G-0.083B+128
#define	HwGE_BCH_DCTRL_R2YMODE_TYPE1		HwGE_BCH_DCTRL_R2YMODE(1)	// Y=0.257R+0.504G+0.098B+16, U=-0.148R-0.291G+0.439B+128, V=0.439R-0.368G-0.071B+128
#define	HwGE_BCH_DCTRL_R2YMODE_TYPE2		HwGE_BCH_DCTRL_R2YMODE(2)	// Y=0.213R+0.715G+0.072B, U=-0.117R-0.394G+0.511B+128, V=0.511R-0.464G-0.047B+128
#define	HwGE_BCH_DCTRL_R2YMODE_TYPE3		HwGE_BCH_DCTRL_R2YMODE(3)	// Y=0.183R+0.614G+0.062B+16, U=-0.101R-0.338G+0.439B+128, V=0.439R-0.399G-0.040B+128
#define	HwGE_BCH_DCTRL_R2YMODE_MASK			HwGE_BCH_DCTRL_R2YMODE(3)
#define	HwGE_BCH_DCTRL_OPMODE(X)			((X)*Hw8)						// Operation Mode
#define	HwGE_BCH_DCTRL_OPMODE_COPY			HwGE_BCH_DCTRL_OPMODE(0)		// Data Copy
#define	HwGE_BCH_DCTRL_OPMODE_HMIRROR		HwGE_BCH_DCTRL_OPMODE(2)		// Horizontal Mirror
#define	HwGE_BCH_DCTRL_OPMODE_VMIRROR		HwGE_BCH_DCTRL_OPMODE(3)		// Vertical Mirror
#define	HwGE_BCH_DCTRL_OPMODE_VHMIRROR		HwGE_BCH_DCTRL_OPMODE(4)		// Vertical & Horizontal Mirror
#define	HwGE_BCH_DCTRL_OPMODE_ROT90			HwGE_BCH_DCTRL_OPMODE(5)		// 90 Degree Rotate
#define	HwGE_BCH_DCTRL_OPMODE_ROT180		HwGE_BCH_DCTRL_OPMODE(6)		// 180 Degree Rotate
#define	HwGE_BCH_DCTRL_OPMODE_ROT270		HwGE_BCH_DCTRL_OPMODE(7)		// 270 Degree Rotate
#define	HwGE_BCH_DCTRL_OPMODE_MASK			HwGE_BCH_DCTRL_OPMODE(7)
#define	HwGE_BCH_DCTRL_DDFRM(X)				((X)*Hw0)						// Source Data Format
#define	HwGE_BCH_SCTRL_SDFRM_YUV444			HwGE_BCH_DCTRL_DDFRM(0)			// Separated YUV 4:4:4
#define	HwGE_BCH_SCTRL_SDFRM_YUV440			HwGE_BCH_DCTRL_DDFRM(1)			// Separated YUV 4:4:0
#define	HwGE_BCH_SCTRL_SDFRM_YUV422			HwGE_BCH_DCTRL_DDFRM(2)			// Separated YUV 4:2:2
#define	HwGE_BCH_SCTRL_SDFRM_YUV420			HwGE_BCH_DCTRL_DDFRM(3)			// Separated YUV 4:2:0
#define	HwGE_BCH_SCTRL_SDFRM_YUV411			HwGE_BCH_DCTRL_DDFRM(4)			// Separated YUV 4:1:1
#define	HwGE_BCH_SCTRL_SDFRM_YUV410			HwGE_BCH_DCTRL_DDFRM(5)			// Separated YUV 4:1:0
#define	HwGE_BCH_SCTRL_SDFRM_INTER422		HwGE_BCH_DCTRL_DDFRM(6)			// Interleaved YUV 4:2:2
#define	HwGE_BCH_SCTRL_SDFRM_INTER420		HwGE_BCH_DCTRL_DDFRM(7)			// Interleaved YUV 4:2:0
#define	HwGE_BCH_SCTRL_SDFRM_SEQ444			HwGE_BCH_DCTRL_DDFRM(8)			// Sequential YUV 4:4:4
#define	HwGE_BCH_SCTRL_SDFRM_SEQ422			HwGE_BCH_DCTRL_DDFRM(9)			// Sequential YUV 4:2:0

#define	HwGE_BCH_SCTRL_SDFRM_RGB332			HwGE_BCH_DCTRL_DDFRM(10)		// RGB332
#define	HwGE_BCH_SCTRL_SDFRM_RGB444			HwGE_BCH_DCTRL_DDFRM(12)		// RGB444
#define	HwGE_BCH_SCTRL_SDFRM_ARGB4444		HwGE_BCH_DCTRL_DDFRM(13)		// Alpha-RGB444
#define	HwGE_BCH_SCTRL_SDFRM_RGB454			HwGE_BCH_DCTRL_DDFRM(14)		// RGB454
#define	HwGE_BCH_SCTRL_SDFRM_ARGB3454		HwGE_BCH_DCTRL_DDFRM(15)		// Alpha-RGB3454
#define	HwGE_BCH_SCTRL_SDFRM_RGB555			HwGE_BCH_DCTRL_DDFRM(16)		// RGB555
#define	HwGE_BCH_SCTRL_SDFRM_ARGB1555		HwGE_BCH_DCTRL_DDFRM(17)		// Alpha-RGB1555
#define	HwGE_BCH_SCTRL_SDFRM_RGB565			HwGE_BCH_DCTRL_DDFRM(19)		// RGB565
#define	HwGE_BCH_SCTRL_SDFRM_RGB666			HwGE_BCH_DCTRL_DDFRM(20)		// RGB666

#define	HwGE_BCH_SCTRL_SDFRM_ARGB4666		HwGE_BCH_DCTRL_DDFRM(21)		// Alpha-RGB4666
#define	HwGE_BCH_SCTRL_SDFRM_ARGB6666		HwGE_BCH_DCTRL_DDFRM(22)		// Alpha-RGB5666
#define	HwGE_BCH_SCTRL_SDFRM_RGB888			HwGE_BCH_DCTRL_DDFRM(23)		// RGB888
#define	HwGE_BCH_SCTRL_SDFRM_ARGB4888		HwGE_BCH_DCTRL_DDFRM(24)		// Alpha-RG4B888
#define	HwGE_BCH_SCTRL_SDFRM_ARGB8888		HwGE_BCH_DCTRL_DDFRM(27)		// Alpha-RGB888
#define	HwGE_BCH_SCTRL_SDFRM_MASK			HwGE_BCH_DCTRL_DDFRM(31)
} sHwGE_BCH;

typedef volatile struct
{
	unsigned	CHROMA;			// Source Chroma-key Parameter
#define	HwGE_S_CHROMA_RY(X)					((X)*Hw16)						// R or Y Chroma-Key Value
#define	HwGE_S_CHROMA_RY_MASK				HwGE_S_CHROMA_RY(255)
#define	HwGE_S_CHROMA_GU(X)					((X)*Hw8)						// G or U Chroma-Key Value
#define	HwGE_S_CHROMA_GU_MASK				HwGE_S_CHROMA_GU(255)
#define	HwGE_S_CHROMA_BV(X)					((X)*Hw0)						// B or V Chroma-Key Value
#define	HwGE_S_CHROMA_BV_MASK				HwGE_S_CHROMA_BV(255)
	unsigned	PARAM;			// Source Arithmetic Parameter
#define	HwGE_S_PARAM_RY(X)					((X)*Hw16)						// R or Y Arithmetic Parameter
#define	HwGE_S_PARAM_RY_MASK				HwGE_S_PARAM_RY(255)
#define	HwGE_S_PARAM_GU(X)					((X)*Hw8)						// G or U Arithmetic Parameter
#define	HwGE_S_PARAM_GU_MASK				HwGE_S_PARAM_GU(255)
#define	HwGE_S_PARAM_BV(X)					((X)*Hw0)						// B or V Arithmetic Parameter
#define	HwGE_S_PARAM_BV_MASK				HwGE_S_PARAM_BV(255)
} sHwGE_SRC;

typedef volatile struct
{
	sHwGE_FCH	FCH[3];		// Front-End Channel Register Block (Valid only [0], [1], [2]))
	sHwGE_SRC	S[3];		// Source Parameter Register Block
	unsigned		SCTRL;		// Source Control Register
#define	HwGE_SCTRL_S2ARITH(X)				((X)*Hw25)						// Source 2 Arithmetic Operation
#define	HwGE_SCTRL_S2ARITH_BYPASS			HwGE_SCTRL_S2ARITH(0)			// Y = Source
#define	HwGE_SCTRL_S2ARITH_FILL				HwGE_SCTRL_S2ARITH(2)			// Y = Source Param
#define	HwGE_SCTRL_S2ARITH_INV				HwGE_SCTRL_S2ARITH(3)			// Y = 255 - Source
#define	HwGE_SCTRL_S2ARITH_ADD				HwGE_SCTRL_S2ARITH(4)			// Y = Source + Source Param
#define	HwGE_SCTRL_S2ARITH_SUBA				HwGE_SCTRL_S2ARITH(5)			// Y = Source - Source Param
#define	HwGE_SCTRL_S2ARITH_SUBB				HwGE_SCTRL_S2ARITH(6)			// Y = Source Param - Source
#define	HwGE_SCTRL_S2ARITH_MUL				HwGE_SCTRL_S2ARITH(7)			// Y = Source * Source Param (Mantisa = [7:6], Fraction = [5:0])
#define	HwGE_SCTRL_S2ARITH_MASK				HwGE_SCTRL_S2ARITH(7)
#define	HwGE_SCTRL_S1ARITH(X)				((X)*Hw22)						// Source 1 Arithmetic Operation
#define	HwGE_SCTRL_S1ARITH_BYPASS			HwGE_SCTRL_S1ARITH(0)			// Y = Source
#define	HwGE_SCTRL_S1ARITH_FILL				HwGE_SCTRL_S1ARITH(2)			// Y = Source Param
#define	HwGE_SCTRL_S1ARITH_INV				HwGE_SCTRL_S1ARITH(3)			// Y = 255 - Source
#define	HwGE_SCTRL_S1ARITH_ADD				HwGE_SCTRL_S1ARITH(4)			// Y = Source + Source Param
#define	HwGE_SCTRL_S1ARITH_SUBA				HwGE_SCTRL_S1ARITH(5)			// Y = Source - Source Param
#define	HwGE_SCTRL_S1ARITH_SUBB				HwGE_SCTRL_S1ARITH(6)			// Y = Source Param - Source
#define	HwGE_SCTRL_S1ARITH_MUL				HwGE_SCTRL_S1ARITH(7)			// Y = Source * Source Param (Mantisa = [7:6], Fraction = [5:0])
#define	HwGE_SCTRL_S1ARITH_MASK				HwGE_SCTRL_S1ARITH(7)
#define	HwGE_SCTRL_S0ARITH(X)				((X)*Hw19)						// Source 0 Arithmetic Operation
#define	HwGE_SCTRL_S0ARITH_BYPASS			HwGE_SCTRL_S0ARITH(0)			// Y = Source
#define	HwGE_SCTRL_S0ARITH_FILL				HwGE_SCTRL_S0ARITH(2)			// Y = Source Param
#define	HwGE_SCTRL_S0ARITH_INV				HwGE_SCTRL_S0ARITH(3)			// Y = 255 - Source
#define	HwGE_SCTRL_S0ARITH_ADD				HwGE_SCTRL_S0ARITH(4)			// Y = Source + Source Param
#define	HwGE_SCTRL_S0ARITH_SUBA				HwGE_SCTRL_S0ARITH(5)			// Y = Source - Source Param
#define	HwGE_SCTRL_S0ARITH_SUBB				HwGE_SCTRL_S0ARITH(6)			// Y = Source Param - Source
#define	HwGE_SCTRL_S0ARITH_MUL				HwGE_SCTRL_S0ARITH(7)			// Y = Source * Source Param (Mantisa = [7:6], Fraction = [5:0])
#define	HwGE_SCTRL_S0ARITH_MASK				HwGE_SCTRL_S0ARITH(7)

#define	HwGE_SCTRL_S2Y2REN_EN				Hw18							// Source 2 YUV to RGB Converter Enable
#define	HwGE_SCTRL_S1Y2REN_EN				Hw17							// Source 1 YUV to RGB Converter Enable
#define	HwGE_SCTRL_S0Y2REN_EN				Hw16							// Source 0 YUV to RGB Converter Enable

#define	HwGE_SCTRL_S2Y2RMODE(X)				((X)*Hw13)						// Source 2 YUV to RGB Converter Type
#define	HwGE_SCTRL_S2Y2RMODE_TYPE0			HwGE_SCTRL_S2Y2RMODE(0)		// R = Y+1.371(V-128), G = Y-0.336(U-128)-0.698(V-128), B = Y+1.732(U-128)
#define	HwGE_SCTRL_S2Y2RMODE_TYPE1			HwGE_SCTRL_S2Y2RMODE(1)		// R = 1.164(Y-16)+1.159(V-128), G = 1.164(Y-16)-0.391(U-128)-0.813(V-128), B = 1.164(Y-16)+2.018(U-128)
#define	HwGE_SCTRL_S2Y2RMODE_TYPE2			HwGE_SCTRL_S2Y2RMODE(2)		// R = Y+1.540(V-128), G = Y-0.183(U-128)-0.459(V-128), B = Y+1.816(U-128)
#define	HwGE_SCTRL_S2Y2RMODE_TYPE3			HwGE_SCTRL_S2Y2RMODE(3)		// R = 1.164(Y-16)+1.793(V-128), G = 1.164(Y-16)-0.213(U-128)-0.534(V-128), B = 1.164(Y-16)+2.115(U-128)
#define	HwGE_SCTRL_S2Y2RMODE_MASK			HwGE_SCTRL_S2Y2RMODE(3)
#define	HwGE_SCTRL_S1Y2RMODE(X)				((X)*Hw11)						// Source 1 YUV to RGB Converter Type
#define	HwGE_SCTRL_S1Y2RMODE_TYPE0			HwGE_SCTRL_S1Y2RMODE(0)		// R = Y+1.371(V-128), G = Y-0.336(U-128)-0.698(V-128), B = Y+1.732(U-128)
#define	HwGE_SCTRL_S1Y2RMODE_TYPE1			HwGE_SCTRL_S1Y2RMODE(1)		// R = 1.164(Y-16)+1.159(V-128), G = 1.164(Y-16)-0.391(U-128)-0.813(V-128), B = 1.164(Y-16)+2.018(U-128)
#define	HwGE_SCTRL_S1Y2RMODE_TYPE2			HwGE_SCTRL_S1Y2RMODE(2)		// R = Y+1.540(V-128), G = Y-0.183(U-128)-0.459(V-128), B = Y+1.816(U-128)
#define	HwGE_SCTRL_S1Y2RMODE_TYPE3			HwGE_SCTRL_S1Y2RMODE(3)		// R = 1.164(Y-16)+1.793(V-128), G = 1.164(Y-16)-0.213(U-128)-0.534(V-128), B = 1.164(Y-16)+2.115(U-128)
#define	HwGE_SCTRL_S1Y2RMODE_MASK			HwGE_SCTRL_S1Y2RMODE(3)
#define	HwGE_SCTRL_S0Y2RMODE(X)				((X)*Hw9)						// Source 0 YUV to RGB Converter Type
#define	HwGE_SCTRL_S0Y2RMODE_TYPE0			HwGE_SCTRL_S0Y2RMODE(0)		// R = Y+1.371(V-128), G = Y-0.336(U-128)-0.698(V-128), B = Y+1.732(U-128)
#define	HwGE_SCTRL_S0Y2RMODE_TYPE1			HwGE_SCTRL_S0Y2RMODE(1)		// R = 1.164(Y-16)+1.159(V-128), G = 1.164(Y-16)-0.391(U-128)-0.813(V-128), B = 1.164(Y-16)+2.018(U-128)
#define	HwGE_SCTRL_S0Y2RMODE_TYPE2			HwGE_SCTRL_S0Y2RMODE(2)		// R = Y+1.540(V-128), G = Y-0.183(U-128)-0.459(V-128), B = Y+1.816(U-128)
#define	HwGE_SCTRL_S0Y2RMODE_TYPE3			HwGE_SCTRL_S0Y2RMODE(3)		// R = 1.164(Y-16)+1.793(V-128), G = 1.164(Y-16)-0.213(U-128)-0.534(V-128), B = 1.164(Y-16)+2.115(U-128)
#define	HwGE_SCTRL_S0Y2RMODE_MASK			HwGE_SCTRL_S0Y2RMODE(3)

#define	HwGE_SCTRL_S2CHROMA_EN				Hw8								// Source 2 Chroma-Key Enable for Arithmetic
#define	HwGE_SCTRL_S1CHROMA_EN				Hw7								// Source 1 Chroma-Key Enable for Arithmetic
#define	HwGE_SCTRL_S0CHROMA_EN				Hw6								// Source 0 Chroma-Key Enable for Arithmetic

#define	HwGE_SCTRL_S2SEL(X)					((X)*Hw4)						// Source 2 Selection
#define	HwGE_SCTRL_S2SEL_DIS				HwGE_SCTRL_S2SEL(0)			// Source 2 Disabled
#define	HwGE_SCTRL_S2SEL_FCH0				HwGE_SCTRL_S2SEL(1)			// Source 2 = Front-end Channel 0
#define	HwGE_SCTRL_S2SEL_FCH1				HwGE_SCTRL_S2SEL(2)			// Source 2 = Front-end Channel 1
#define	HwGE_SCTRL_S2SEL_FCH2				HwGE_SCTRL_S2SEL(3)			// Source 2 = Front-end Channel 2 (Not supported)
#define	HwGE_SCTRL_S2SEL_MASK				HwGE_SCTRL_S2SEL(3)
#define	HwGE_SCTRL_S1SEL(X)					((X)*Hw2)						// Source 1 Selection
#define	HwGE_SCTRL_S1SEL_DIS				HwGE_SCTRL_S1SEL(0)			// Source 1 Disabled
#define	HwGE_SCTRL_S1SEL_FCH0				HwGE_SCTRL_S1SEL(1)			// Source 1 = Front-end Channel 0
#define	HwGE_SCTRL_S1SEL_FCH1				HwGE_SCTRL_S1SEL(2)			// Source 1 = Front-end Channel 1
#define	HwGE_SCTRL_S1SEL_FCH2				HwGE_SCTRL_S1SEL(3)			// Source 1 = Front-end Channel 2 (Not supported)
#define	HwGE_SCTRL_S1SEL_MASK				HwGE_SCTRL_S1SEL(3)
#define	HwGE_SCTRL_S0SEL(X)					((X)*Hw0)						// Source 0 Selection
#define	HwGE_SCTRL_S0SEL_DIS				HwGE_SCTRL_S0SEL(0)			// Source 0 Disabled (Not supported. Source 0 should be enabled)
#define	HwGE_SCTRL_S0SEL_FCH0				HwGE_SCTRL_S0SEL(1)			// Source 0 = Front-end Channel 0
#define	HwGE_SCTRL_S0SEL_FCH1				HwGE_SCTRL_S0SEL(2)			// Source 0 = Front-end Channel 1
#define	HwGE_SCTRL_S0SEL_FCH2				HwGE_SCTRL_S0SEL(3)			// Source 0 = Front-end Channel 2 (Not supported)
#define	HwGE_SCTRL_S0SEL_MASK				HwGE_SCTRL_S0SEL(3)

	unsigned		_RSV0;
	unsigned		OPPAT[2];	// Source Operator Register Block
#define	HwGE_OPPAT_ALPHA(X)					((X)*Hw24)						// Alpha Value (Valid only if OPCTRL.OPMODE == Alpha-Blend Type 0)
#define	HwGE_OPPAT_ALPHA_MASK				HwGE_OPPAT_ALPHA(15)
#define	HwGE_OPPAT_PAT_RY(X)				((X)*Hw16)						// R or Y pattern value for Raster Operation of Source Operator
#define	HwGE_OPPAT_PAT_RY_MASK				HwGE_OPPAT_PAT_RY(255)
#define	HwGE_OPPAT_PAT_GU(X)				((X)*Hw8)						// G or U pattern value for Raster Operation of Source Operator
#define	HwGE_OPPAT_PAT_GU_MASK				HwGE_OPPAT_PAT_GU(255)
#define	HwGE_OPPAT_PAT_BV(X)				((X)*Hw0)						// B or V pattern value for Raster Operation of Source Operator
#define	HwGE_OPPAT_PAT_BV_MASK				HwGE_OPPAT_PAT_BV(255)

	unsigned		OPCTRL;		// Source Operation Control Register
#define	HwGE_OPCTRL_ASEL1(X)				((X)*Hw23)
#define	HwGE_OPCTRL_ASEL1_MIN				HwGE_OPCTRL_ASEL1(0)
#define	HwGE_OPCTRL_ASEL1_MAX				HwGE_OPCTRL_ASEL1(2)
#define	HwGE_OPCTRL_ASEL1_MINMAX			HwGE_OPCTRL_ASEL1(3)
#define	HwGE_OPCTRL_ASEL1_MASK				HwGE_OPCTRL_ASEL1(3)

#define	HwGE_OPCTRL_CSEL1(X)				((X)*Hw21)						// Chroma-Key Source Selection for Operator 1
#define	HwGE_OPCTRL_CSEL1_DIS				HwGE_OPCTRL_CSEL1(0)			// Chroma-Key Disabled
#define	HwGE_OPCTRL_CSEL1_S0CHROM			HwGE_OPCTRL_CSEL1(1)			// Chroma-Key source is output of Operator 0, ChromaKey Value = S0_CHROMA
#define	HwGE_OPCTRL_CSEL1_S1CHROM			HwGE_OPCTRL_CSEL1(2)			// Chroma-Key source is output of Operator 0, ChromaKey Value = S1_CHROMA
#define	HwGE_OPCTRL_CSEL1_S2CHROM			HwGE_OPCTRL_CSEL1(3)			// Chroma-Key source is Source 2, ChromaKey Value = S2_CHROMA
#define	HwGE_OPCTRL_CSEL1_MASK				HwGE_OPCTRL_CSEL1(3)

#define	HwGE_OPCTRL_OP1MODE(X)				((X)*Hw16)						// Operation 1 Mode (A = Result of OP 0, B = Source2, S2_CHROMA used)
#define	HwGE_OPCTRL_OP1MODE_BLACK			HwGE_OPCTRL_OP1MODE(0)		// Blackness, Result = 0
#define	HwGE_OPCTRL_OP1MODE_MCOPY			HwGE_OPCTRL_OP1MODE(1)		// Merged Copy, Result = PAT & A
#define	HwGE_OPCTRL_OP1MODE_MPAINT			HwGE_OPCTRL_OP1MODE(2)		// Merged Paint, Result = ~A | B
#define	HwGE_OPCTRL_OP1MODE_PCOPY			HwGE_OPCTRL_OP1MODE(3)		// Pattern Copy, Result = PAT
#define	HwGE_OPCTRL_OP1MODE_PINV			HwGE_OPCTRL_OP1MODE(4)		// Pattern Inverter, Result = PAT ^ B
#define	HwGE_OPCTRL_OP1MODE_PPAINT			HwGE_OPCTRL_OP1MODE(5)		// Pattern Paint, Result = (PAT | ~A) | B
#define	HwGE_OPCTRL_OP1MODE_SCOPY			HwGE_OPCTRL_OP1MODE(6)		// Source Copy, Result = A
#define	HwGE_OPCTRL_OP1MODE_SINV			HwGE_OPCTRL_OP1MODE(7)		// Source Inverter, Result = A ^ B
#define	HwGE_OPCTRL_OP1MODE_SPAINT			HwGE_OPCTRL_OP1MODE(8)		// Source Paint, Result = A | B
#define	HwGE_OPCTRL_OP1MODE_SAND			HwGE_OPCTRL_OP1MODE(9)		// Source AND, Result = A & B
#define	HwGE_OPCTRL_OP1MODE_SERASE			HwGE_OPCTRL_OP1MODE(10)		// Source Erase, Result = A & ~B
#define	HwGE_OPCTRL_OP1MODE_NSCOPY			HwGE_OPCTRL_OP1MODE(11)		// Not Source Copy, Result = ~A
#define	HwGE_OPCTRL_OP1MODE_NSERASE			HwGE_OPCTRL_OP1MODE(12)		// Not Source Erase, Result = ~(A | B)
#define	HwGE_OPCTRL_OP1MODE_DCOPY			HwGE_OPCTRL_OP1MODE(13)		// Destination Copy, Result = B
#define	HwGE_OPCTRL_OP1MODE_NDCOPY			HwGE_OPCTRL_OP1MODE(14)		// Destination Inverter, Result = ~B
#define	HwGE_OPCTRL_OP1MODE_WHITE			HwGE_OPCTRL_OP1MODE(15)		// Whiteness, Result = 1
#define	HwGE_OPCTRL_OP1MODE_ATYPE0			HwGE_OPCTRL_OP1MODE(16)		// Alpha Blending Type 0, Result = Alpha-Blending with Alpha-Value (OP1PAT.ALPHA)
#define	HwGE_OPCTRL_OP1MODE_ATYPE1			HwGE_OPCTRL_OP1MODE(24)		// Alpha Blending Type 1, Result = Alpha-Blending with Alpha-Value of AlphaRGB
#define	HwGE_OPCTRL_OP1MODE_MASK			HwGE_OPCTRL_OP1MODE(31)

#define	HwGE_OPCTRL_ASEL0(X)				((X)*Hw7)
#define	HwGE_OPCTRL_ASEL0_MIN				HwGE_OPCTRL_ASEL0(0)
#define	HwGE_OPCTRL_ASEL0_MAX				HwGE_OPCTRL_ASEL0(2)
#define	HwGE_OPCTRL_ASEL0_MINMAX			HwGE_OPCTRL_ASEL0(3)
#define	HwGE_OPCTRL_ASEL0_MASK				HwGE_OPCTRL_ASEL0(3)

#define	HwGE_OPCTRL_CSEL0(X)				((X)*Hw5)						// Chroma-Key Source Selection for Operator 0
#define	HwGE_OPCTRL_CSEL0_DIS				HwGE_OPCTRL_CSEL0(0)			// Chroma-Key Operation Disabled
#define	HwGE_OPCTRL_CSEL0_S0CHROM			HwGE_OPCTRL_CSEL0(1)			//  Chroma-Key source is Source 0, ChromaKey Value = S0_CHROMA
#define	HwGE_OPCTRL_CSEL0_S1CHROM			HwGE_OPCTRL_CSEL0(2)			//  Chroma-Key source is Source 1, ChromaKey Value = S1_CHROMA
#define	HwGE_OPCTRL_CSEL0_MASK				HwGE_OPCTRL_CSEL0(3)
#define	HwGE_OPCTRL_OP0MODE(X)				((X)*Hw0)						// Operation 0 Mode (A = Source0, B = Source1, S1_CHROMA used)
#define	HwGE_OPCTRL_OP0MODE_BLACK			HwGE_OPCTRL_OP0MODE(0)		// Blackness, Result = 0
#define	HwGE_OPCTRL_OP0MODE_MCOPY			HwGE_OPCTRL_OP0MODE(1)		// Merged Copy, Result = PAT & A
#define	HwGE_OPCTRL_OP0MODE_MPAINT			HwGE_OPCTRL_OP0MODE(2)		// Merged Paint, Result = ~A | B
#define	HwGE_OPCTRL_OP0MODE_PCOPY			HwGE_OPCTRL_OP0MODE(3)		// Pattern Copy, Result = PAT
#define	HwGE_OPCTRL_OP0MODE_PINV			HwGE_OPCTRL_OP0MODE(4)		// Pattern Inverter, Result = PAT ^ B
#define	HwGE_OPCTRL_OP0MODE_PPAINT			HwGE_OPCTRL_OP0MODE(5)		// Pattern Paint, Result = (PAT | ~A) | B
#define	HwGE_OPCTRL_OP0MODE_SCOPY			HwGE_OPCTRL_OP0MODE(6)		// Source Copy, Result = A
#define	HwGE_OPCTRL_OP0MODE_SINV			HwGE_OPCTRL_OP0MODE(7)		// Source Inverter, Result = A ^ B
#define	HwGE_OPCTRL_OP0MODE_SPAINT			HwGE_OPCTRL_OP0MODE(8)		// Source Paint, Result = A | B
#define	HwGE_OPCTRL_OP0MODE_SAND			HwGE_OPCTRL_OP0MODE(9)		// Source AND, Result = A & B
#define	HwGE_OPCTRL_OP0MODE_SERASE			HwGE_OPCTRL_OP0MODE(10)		// Source Erase, Result = A & ~B
#define	HwGE_OPCTRL_OP0MODE_NSCOPY			HwGE_OPCTRL_OP0MODE(11)		// Not Source Copy, Result = ~A
#define	HwGE_OPCTRL_OP0MODE_NSERASE			HwGE_OPCTRL_OP0MODE(12)		// Not Source Erase, Result = ~(A | B)
#define	HwGE_OPCTRL_OP0MODE_DCOPY			HwGE_OPCTRL_OP0MODE(13)		// Destination Copy, Result = B
#define	HwGE_OPCTRL_OP0MODE_NDCOPY			HwGE_OPCTRL_OP0MODE(14)		// Destination Inverter, Result = ~B
#define	HwGE_OPCTRL_OP0MODE_WHITE			HwGE_OPCTRL_OP0MODE(15)		// Whiteness, Result = 1
#define	HwGE_OPCTRL_OP0MODE_ATYPE0			HwGE_OPCTRL_OP0MODE(16)		// Alpha Blending Type 0, Result = Alpha-Blending with Alpha-Value (OP0PAT.ALPHA)
#define	HwGE_OPCTRL_OP0MODE_ATYPE1			HwGE_OPCTRL_OP0MODE(24)		// Alpha Blending Type 1, Result = Alpha-Blending with Alpha-Value of AlphaRGB
#define	HwGE_OPCTRL_OP0MODE_MASK			HwGE_OPCTRL_OP0MODE(31)
	unsigned		_RSV1;
	sHwGE_BCH	BCH[1];		// Back-End Channel Register Block
	unsigned		_RSV2, _RSV3; //0xA8, 0xAF
	unsigned    BCH_DDMAT0;
	unsigned    BCH_DDMAT1;
	unsigned    BCH_DDMAT2;
	unsigned    BCH_DDMAT3; //0xBC
	unsigned		CTRL;		// 0xC0 Graphic Engine Control Register
#define	HwGE_CTRL_IEN						Hw16							// Graphic Engine Interrupt Enable
#define	HwGE_CTRL_FCH0_EN					Hw0								// Graphic Engine Front-End Channel 0 Enable
#define	HwGE_CTRL_FCH1_EN					Hw1								// Graphic Engine Front-End Channel 1 Enable
#define	HwGE_CTRL_FCH2_EN					Hw2								// Graphic Engine Front-End Channel 2 Enable (Not supported)
	unsigned		IREQ;		// Graphic Engine Interrupt Request Register
#define	HwGE_IREQ_FLAG						Hw16							// Graphic Engine Flag (Graphic Engine Operation Completed)
#define	HwGE_IREQ_IRQ						Hw0								// Graphic Engine Interrupt Occurred (Graphic Engine Operation Completed)
	unsigned	FCH0_LUT;
	unsigned	FCH1_LUT;
	unsigned	FCH2_LUT;
} sHwGE;