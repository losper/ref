/****************************************************************************
*   FileName    : halcaps.cpp
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#include "precomp.h"

//----------------------------------
// callbacks from the DIRECTDRAW object
//----------------------------------
DDHAL_DDCALLBACKS cbDDCallbacks =
{
	sizeof( DDHAL_DDCALLBACKS ),		// dwSize
	DDHAL_CB32_CREATESURFACE |
	DDHAL_CB32_WAITFORVERTICALBLANK |
	DDHAL_CB32_CANCREATESURFACE |
	//DDHAL_CB32_CREATEPALETTE |
	DDHAL_CB32_GETSCANLINE |
	0,
	HalCreateSurface,		// CreateSurface
	HalWaitForVerticalBlank,	// WaitForVerticalBlank
	HalCanCreateSurface,	// CanCreateSurface
	NULL,					// CreatePalette  		
	HalGetScanLine			// GetScanLine
};

//------------------------------------------
// callbacks from the DIRECTDRAWSURFACE object
//------------------------------------------
DDHAL_DDSURFACECALLBACKS cbDDSurfaceCallbacks =
{
	sizeof( DDHAL_DDSURFACECALLBACKS ),	// dwSize
	DDHAL_SURFCB32_DESTROYSURFACE |	// dwFlags
	DDHAL_SURFCB32_FLIP |
	DDHAL_SURFCB32_LOCK |
	DDHAL_SURFCB32_UNLOCK |
	DDHAL_SURFCB32_SETCOLORKEY |
	DDHAL_SURFCB32_GETBLTSTATUS |
	DDHAL_SURFCB32_GETFLIPSTATUS |
	DDHAL_SURFCB32_UPDATEOVERLAY |
	DDHAL_SURFCB32_SETOVERLAYPOSITION |
	//DDHAL_SURFCB32_SETPALETTE |
	0,
	HalDestroySurface,//DDGPEDestroySurface,		// DestroySurface
	HalFlip,						// Flip
	DDGPELock,					// Lock
	DDGPEUnlock,				// Unlock
	HalSetColorKey, 				// SetColorKey
	HalGetBltStatus,				// TODO: // GetBltStatus
	HalGetFlipStatus,			// GetFlipStatus
	HalUpdateOverlay,			// UpdateOverlay
	HalSetOverlayPosition,		// SetOverlayPosition
	NULL						// SetPalette 			 
};

//------------------------------------------------
// callbacks from the DIRECTDRAWMISCELLANEOUS object
//------------------------------------------------
DDHAL_DDMISCELLANEOUSCALLBACKS MiscellaneousCallbacks =
{
	sizeof(DDHAL_DDMISCELLANEOUSCALLBACKS),	// dwSize
	//DDHAL_MISCCB32_GETAVAILDRIVERMEMORY |	// dwFlags
	//DDHAL_MISCCB32_GETDEVICEIDENTIFIER |
	0,
	NULL,		// GetAvailDriverMemory
	NULL		// GetDeviceIdentifier
};

//-------------------------------------------------------
// callbacks from the DIRECTDRAWCOLORCONTROL pseudo object
//-------------------------------------------------------
DDHAL_DDCOLORCONTROLCALLBACKS ColorControlCallbacks =
{
	sizeof(DDHAL_DDCOLORCONTROLCALLBACKS),		// dwSize
	//DDHAL_COLORCB32_COLORCONTROL |			// dwFlags
	//DDHAL_COLORCB32_GAMMACONTROL |
	0,
	NULL,										// ColorControl
	NULL										// GammaControl
};

// This global pointer is to be recorded in the DirectDraw structure
// Initialized by HalInit()
DDGPE* g_pGPE = (DDGPE*)NULL;
DDGPESurf* g_pDDrawPrimarySurface = NULL;

DWORD lpdwFourCC[] = {
	FOURCC_I420,	// YUV420
	FOURCC_YV12,	// YVU420
	FOURCC_YUYV,	// 422 (YCbYCr)
	FOURCC_YUY2,	// 422 (YCbYCr)
	FOURCC_UYVY,	// 422 (CbYCrY)
	FOURCC_YVYU,	// 422 (YCrYCb)
	FOURCC_VYUY	// 422 (CrYCbY)
};

#define MAX_FOURCC		(sizeof(lpdwFourCC)/sizeof(DWORD))

// InitDDHALInfo must set up this information
unsigned char	*g_pVideoMemory		= NULL;		// virtual address of video memory from client's side
DWORD 	g_dwVideoMemorySize 	= 0;
DWORD   g_dwAvailVideoMemorySize = 0;
DWORD	g_currentusingoveray=0;

EXTERN_C void buildDDHALInfo(LPDDHALINFO lpddhi, DWORD modeidx)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL] ++buildDDHALInfo()\r\n")));

	TCCDISP *pTCCDISP = ((TCCDISP *)GetDDGPE());

	if(g_pVideoMemory == NULL)	
	{
		unsigned long VideoMemoryStart;
		unsigned long VideoMemorySize;
		unsigned long AvailVideoMemorySize;

		pTCCDISP->GetVirtualVideoMemory(&VideoMemoryStart, &VideoMemorySize);
		pTCCDISP->GetAvailVideoMemory(&AvailVideoMemorySize);
		g_pVideoMemory = (unsigned char *)VideoMemoryStart;
		g_dwVideoMemorySize = (DWORD)VideoMemorySize;
		g_dwAvailVideoMemorySize = (DWORD)AvailVideoMemorySize;

		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] buildDDHALInfo() :  VideoMemory = 0x%08x\r\n"), g_pVideoMemory));
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] buildDDHALInfo() :  VideoMemorySize = 0x%08x\r\n"), g_dwVideoMemorySize));
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] buildDDHALInfo() :  AvailVideoMemorySize = 0x%08x\r\n"), g_dwAvailVideoMemorySize));
	}
	else
	{
		unsigned long AvailVideoMemorySize;
		pTCCDISP->GetAvailVideoMemory(&AvailVideoMemorySize);
		g_dwAvailVideoMemorySize = (DWORD)AvailVideoMemorySize;
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] buildDDHALInfo() :  AvailVideoMemorySize = 0x%08x\r\n"), g_dwAvailVideoMemorySize));

	}


	memset(lpddhi, 0, sizeof(DDHALINFO));
	lpddhi->dwSize  = sizeof(DDHALINFO);
	lpddhi->dwFlags = 0;						
	lpddhi->lpDDCallbacks = &cbDDCallbacks;
	lpddhi->lpDDSurfaceCallbacks = &cbDDSurfaceCallbacks;
	lpddhi->lpDDPaletteCallbacks = NULL;		
	lpddhi->GetDriverInfo = HalGetDriverInfo;
	lpddhi->lpdwFourCC = lpdwFourCC;			
	lpddhi->ddCaps.dwSize = sizeof(DDCAPS);	
	lpddhi->ddCaps.dwVidMemTotal = g_dwVideoMemorySize;	
	lpddhi->ddCaps.dwVidMemFree  = g_dwAvailVideoMemorySize;	
	lpddhi->ddCaps.dwVidMemStride = 0;				


	lpddhi->ddCaps.ddsCaps.dwCaps =
		DDSCAPS_BACKBUFFER |		
		DDSCAPS_FLIP |				
		DDSCAPS_FRONTBUFFER |		
		DDSCAPS_OVERLAY |			
		DDSCAPS_PRIMARYSURFACE |	
		DDSCAPS_SYSTEMMEMORY |		
		DDSCAPS_VIDEOMEMORY |		
   		DDSCAPS_OWNDC |				
		0;

	lpddhi->ddCaps.dwNumFourCCCodes = MAX_FOURCC;	// number of four cc codes

	
	lpddhi->ddCaps.dwPalCaps =
		//DDPCAPS_PRIMARYSURFACE |		
		0;

    lpddhi->ddCaps.dwBltCaps =                    // blitting capabilities
    //    DDBLTCAPS_READSYSMEM  |
    //    DDBLTCAPS_WRITESYSMEM |
        // DDBLTCAPS_FOURCCTORGB |
        // DDBLTCAPS_COPYFOURCC  |
        // DDBLTCAPS_FILLFOURCC  |
        0;

    lpddhi->ddCaps.dwCKeyCaps=					// color key hardware blitting
        // DDCKEYCAPS_DESTBLT |
        // DDCKEYCAPS_DESTBLTCLRSPACE |
        // DDCKEYCAPS_DESTBLTCLRSPACEYUV |
        DDCKEYCAPS_SRCBLT |		            // Supports transparent blitting using the color key for the source with this surface for RGB colors.  
        // DDCKEYCAPS_SRCBLTCLRSPACE |
        // DDCKEYCAPS_SRCBLTCLRSPACEYUV |
        // DDCKEYCAPS_BOTHBLT |
        0;

    lpddhi->ddCaps.dwAlphaCaps=                   // alpha blitting
        DDALPHACAPS_ALPHAPIXELS |
        // DDALPHACAPS_ALPHASURFACE |
        // DDALPHACAPS_ALPHAPALETTE |
        DDALPHACAPS_ALPHACONSTANT |
        // DDALPHACAPS_ARGBSCALE |
        // DDALPHACAPS_SATURATE | 
        // DDALPHACAPS_PREMULT |  
        DDALPHACAPS_NONPREMULT |
        // DDALPHACAPS_ALPHAFILL |
        // DDALPHACAPS_ALPHANEG |
        0; 

	SETROPBIT(lpddhi->ddCaps.dwRops, SRCCOPY);                   // Set bits for ROPS supported
	SETROPBIT(lpddhi->ddCaps.dwRops, PATCOPY);
	SETROPBIT(lpddhi->ddCaps.dwRops, BLACKNESS);
	SETROPBIT(lpddhi->ddCaps.dwRops, WHITENESS);

	lpddhi->ddCaps.dwOverlayCaps =
		DDOVERLAYCAPS_FLIP |	 //support flip
		DDOVERLAYCAPS_FOURCC |	 //support FourCC
		DDOVERLAYCAPS_ZORDER |	 //support overy order
		DDOVERLAYCAPS_CKEYSRC |	 //support colorkey - chromakey
		//DDOVERLAYCAPS_CKEYDEST |	//???
		//DDOVERLAYCAPS_CKEYBOTH |
		DDOVERLAYCAPS_ALPHASRC |	
		//DDOVERLAYCAPS_ALPHADEST |	
		//DDOVERLAYCAPS_ALPHADESTNEG |
		//DDOVERLAYCAPS_ALPHASRCNEG |
		DDOVERLAYCAPS_ALPHACONSTANT |
		DDOVERLAYCAPS_OVERLAYSUPPORT |	
 		0;

	lpddhi->ddCaps.dwMaxVisibleOverlays = 2;		
	lpddhi->ddCaps.dwCurrVisibleOverlays = g_currentusingoveray;		

	lpddhi->ddCaps.dwAlignBoundarySrc = 8;		
	lpddhi->ddCaps.dwAlignSizeSrc = 8;			
	lpddhi->ddCaps.dwAlignBoundaryDest = 2;		
	lpddhi->ddCaps.dwAlignSizeDest = 8;			

	lpddhi->ddCaps.dwMinOverlayStretch = 240;	
	lpddhi->ddCaps.dwMaxOverlayStretch = 1920;	

	lpddhi->ddCaps.dwMiscCaps =
		DDMISCCAPS_READSCANLINE |				
		//DDMISCCAPS_READMONITORFREQ |		
		DDMISCCAPS_READVBLANKSTATUS |		
		//DDMISCCAPS_FLIPINTERVAL |			
		//DDMISCCAPS_FLIPODDEVEN |			
		DDMISCCAPS_FLIPVSYNCWITHVBI |		
		//DDMISCCAPS_COLORCONTROLOVERLAY |	
		//DDMISCCAPS_COLORCONTROLPRIMARY |	
		//DDMISCCAPS_GAMMACONTROLOVERLAY |
		//DDMISCCAPS_GAMMACONTROLPRIMARY |
 		0;

	
	lpddhi->ddCaps.dwMinVideoStretch = 1000;	
	lpddhi->ddCaps.dwMaxVideoStretch = 1000;	
	lpddhi->ddCaps.dwMaxVideoPorts  = 1;		
	lpddhi->ddCaps.dwCurrVideoPorts = 0;		
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL] --buildDDHALInfo()\r\n")));
}

