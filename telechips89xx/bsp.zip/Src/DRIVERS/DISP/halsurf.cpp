/****************************************************************************
*   FileName    : halsurf.cpp
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#include "precomp.h"

#define HAL_ZONE_ERROR 0
#define HAL_ZONE_INFO 0
#define HAL_ZONE_WARNING 0

extern PLCDC		pLCD;
extern DWORD	g_currentusingoveray;
BOOL g_UsingLayer[MAX_OVERAY_COUNT];  
DWORD g_OverSufraceCount[MAX_OVERAY_COUNT];
TCCDISPSurf *pOveraySurf[MAX_OVERAY_COUNT][5];

/*

enum EDDGPEPixelFormat
{
	ddgpePixelFormat_1bpp = 0,
	ddgpePixelFormat_2bpp,
	ddgpePixelFormat_4bpp,
	ddgpePixelFormat_8bpp,

	ddgpePixelFormat_565,
	ddgpePixelFormat_5551,
	ddgpePixelFormat_4444,
	ddgpePixelFormat_5550,
	ddgpePixelFormat_8880,
	ddgpePixelFormat_8888,
	
	ddgpePixelFormat_YUYV,
	ddgpePixelFormat_UYVY,
	ddgpePixelFormat_YUY2,
	ddgpePixelFormat_YV12,

	// some generic types
	// Use dwPixelFormatData in conjunction with this info
	ddgpePixelFormat_15bppGeneric,
	ddgpePixelFormat_16bppGeneric,
	ddgpePixelFormat_24bppGeneric,
	ddgpePixelFormat_32bppGeneric,

	ddgpePixelFormat_UnknownFormat,
	// you can assign custom formats starting with this value
	ddgpePixelFormat_CustomFormat = 0x1000
};
*/
DWORD
WINAPI
HalCreateSurface(LPDDHAL_CREATESURFACEDATA lpcsd)
{
	DEBUGENTER( HalCreateSurface );
	/*
	typedef struct _DDHAL_CREATESURFACEDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		LPDDSURFACEDESC lpDDSurfaceDesc;
		LPDDRAWI_DDRAWSURFACE_LCL lplpSList;
		DWORD dwSCnt;
		HRESULT ddRVal;
	} DDHAL_CREATESURFACEDATA;
	*/

	TCCDISP *pDDGPE = (TCCDISP *)GetDDGPE();
	DWORD dwCaps = lpcsd->lpDDSurfaceDesc->ddsCaps.dwCaps;
	DWORD dwFlags = lpcsd->lpDDSurfaceDesc->dwFlags;
	DWORD i=0;
	DWORD dwRet;
	//set overlay Number..
	for(; i < MAX_OVERAY_COUNT; i++)
	{
		if(!g_UsingLayer[i] )
			break;
	}
	if(i >= MAX_OVERAY_COUNT)
	{
		RETAILMSG(1,(TEXT("[DISPLAY    ]No anymore Layer for using Overlay \n")));
	}

	// Handle Overlay Surface
	if (dwCaps & DDSCAPS_OVERLAY)
	{
		DDPIXELFORMAT *pddpf = &lpcsd->lpDDSurfaceDesc->ddpfPixelFormat;

		if (pddpf->dwFlags & DDPF_RGB) {
	      if (
            (pddpf->dwRGBBitCount == 16 &&
             pddpf->dwRBitMask == 0xF800 &&
             pddpf->dwGBitMask == 0x07E0 &&
             pddpf->dwBBitMask == 0x001F)
		  )
		  {
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY    ] HalCreateSurface() : 565 format\n\r")));
			DWORD dwEmptyLayer=5;
			for(int m=0; m < MAX_OVERAY_COUNT; m++)
			{
				if(g_UsingLayer[m] == FALSE)
				{
					dwEmptyLayer=m;
					break;
				}
			}
			g_OverSufraceCount[dwEmptyLayer] = lpcsd->dwSCnt;
			dwRet= DDGPECreateSurface(lpcsd);
			for(unsigned int k=0; k < lpcsd->dwSCnt; k++)
				pOveraySurf[dwEmptyLayer][k] = (TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpcsd->lplpSList[k]);
			
			pDDGPE->SetVisibleSurface((TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpcsd->lplpSList[0]), TRUE, dwEmptyLayer);

			if(dwEmptyLayer ==1) //Layer 0 using for overlay
			{
				if(g_UsingLayer[0] == TRUE)
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 1<<1; //Layer Order change 0 - 2- 1
				}
				else
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 3<<1; //Layer Order change 2 - 0- 1
				}
			}
			g_UsingLayer[dwEmptyLayer]=TRUE;
			g_currentusingoveray++;
			return dwRet;
		  }
		  else if(
            (pddpf->dwRGBBitCount == 16 &&
             pddpf->dwRBitMask == 0x7C00  &&
             pddpf->dwGBitMask == 0x03E0 &&
             pddpf->dwBBitMask == 0x001F)
	      ) 
		  {
			  RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY    ] HalCreateSurface() : 555 format\n\r")));
			DWORD dwEmptyLayer=5;
			for(int m=0; m < MAX_OVERAY_COUNT; m++)
			{
				if(g_UsingLayer[m] == FALSE)
				{
					dwEmptyLayer=m;
					break;
				}
			}
			g_OverSufraceCount[dwEmptyLayer] = lpcsd->dwSCnt;
			dwRet= DDGPECreateSurface(lpcsd);
			for(unsigned int k=0; k < lpcsd->dwSCnt; k++)
				pOveraySurf[dwEmptyLayer][k] = (TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpcsd->lplpSList[k]);
			
			pDDGPE->SetVisibleSurface((TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpcsd->lplpSList[0]), TRUE, dwEmptyLayer);

			if(dwEmptyLayer ==1) //Layer 0 using for overlay
			{
				if(g_UsingLayer[0] == TRUE)
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 1<<1; //Layer Order change 0 - 2- 1
				}
				else
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 3<<1; //Layer Order change 2 - 0- 1
				}
			}
			g_UsingLayer[dwEmptyLayer]=TRUE;
			g_currentusingoveray++;
			return dwRet;
		  }
		  else if(
           (pddpf->dwRGBBitCount == 24 &&
             pddpf->dwRBitMask == 0xFF0000  &&
             pddpf->dwGBitMask == 0xFF000 &&
             pddpf->dwBBitMask == 0xFF)
          ) 
		  {
			  RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY    ] HalCreateSurface() : 888 format\n\r")));
			DWORD dwEmptyLayer=5;
			for(int m=0; m < MAX_OVERAY_COUNT; m++)
			{
				if(g_UsingLayer[m] == FALSE)
				{
					dwEmptyLayer=m;
					break;
				}
			}
			g_OverSufraceCount[dwEmptyLayer] = lpcsd->dwSCnt;
			dwRet= DDGPECreateSurface(lpcsd);
			for(unsigned int k=0; k < lpcsd->dwSCnt; k++)
				pOveraySurf[dwEmptyLayer][k] = (TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpcsd->lplpSList[k]);
			
			pDDGPE->SetVisibleSurface((TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpcsd->lplpSList[0]), TRUE, dwEmptyLayer);

			if(dwEmptyLayer ==1) //Layer 0 using for overlay
			{
				if(g_UsingLayer[0] == TRUE)
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 1<<1; //Layer Order change 0 - 2- 1
				}
				else
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 3<<1; //Layer Order change 2 - 0- 1
				}
			}
			g_UsingLayer[dwEmptyLayer]=TRUE;
			g_currentusingoveray++;
			return dwRet;
		  }
		}
		else if (pddpf->dwFlags & DDPF_FOURCC) {
			if( pddpf->dwFourCC == FOURCC_YUYV )
            {
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY    ] HalCreateSurface() : YUV(YUYV) format\n\r")));
				DWORD dwEmptyLayer=1;
				if(g_UsingLayer[dwEmptyLayer] == TRUE)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY    ] HalCreateSurface() FAIL : YUV(YUYV) format allwed only 1 Layer\n\r")));
					return DDHAL_DRIVER_HANDLED;
				}

				g_OverSufraceCount[dwEmptyLayer] = lpcsd->dwSCnt;
				dwRet= DDGPECreateSurface(lpcsd);
				for(unsigned int k=0; k < lpcsd->dwSCnt; k++)
					pOveraySurf[dwEmptyLayer][k] = (TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpcsd->lplpSList[k]);
				
				pDDGPE->SetVisibleSurface((TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpcsd->lplpSList[0]), TRUE, dwEmptyLayer);

				if(dwEmptyLayer ==1) //Layer 0 using for overlay
				{
					if(g_UsingLayer[0] == TRUE)
					{
						pLCD->LCTRL &=~(7<<1);
						pLCD->LCTRL |= 1<<1; //Layer Order change 0 - 2- 1
					}
					else
					{
						pLCD->LCTRL &=~(7<<1);
						pLCD->LCTRL |= 3<<1; //Layer Order change 2 - 0- 1
					}
				}
				g_UsingLayer[dwEmptyLayer]=TRUE;
				g_currentusingoveray++;
				return dwRet;
            }
            
		}
		
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalCreateSurface() : Unsupported format\n\r")));
		return DDHAL_DRIVER_HANDLED;
	}
	else
	{
		// Pass to Non-overlay surface to DDGPECreateSurface() function
		return DDGPECreateSurface(lpcsd);
	}
}

DWORD WINAPI HalCanCreateSurface(LPDDHAL_CANCREATESURFACEDATA lpccsd)
{
	DEBUGENTER( HalCanCreateSurface );
	/*
	typedef struct _DDHAL_CANCREATESURFACEDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		LPDDSURFACEDESC lpDDSurfaceDesc;
		DWORD bIsDifferentPixelFormat;
		HRESULT ddRVal;
	} DDHAL_CANCREATESURFACEDATA;

	*/

	DDPIXELFORMAT *pddpf = &lpccsd->lpDDSurfaceDesc->ddpfPixelFormat;
	DWORD dwCaps = lpccsd->lpDDSurfaceDesc->ddsCaps.dwCaps;
	DWORD dwWidth = lpccsd->lpDDSurfaceDesc->dwWidth;
	DWORD dwHeight = lpccsd->lpDDSurfaceDesc->dwHeight;

	TCCDISP *pDDGPE = (TCCDISP *)GetDDGPE();

	// We do Not allow Primary Surface in System Memory
	if ((dwCaps & DDSCAPS_PRIMARYSURFACE) && (dwCaps & DDSCAPS_SYSTEMMEMORY))
	{
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalCanCreateSurface() : Can Not create Primary Surface in System Memory\n\r")));
		goto CannotCreate;
	}

	if ((dwCaps & DDSCAPS_OVERLAY) && (dwCaps & DDSCAPS_SYSTEMMEMORY))
	{
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalCanCreateSurface() : Can Not create Overlay Surface in System Memory\n\r")));
		goto CannotCreate;
	}

	if (dwCaps & DDSCAPS_PRIMARYSURFACE)
	{
		if (lpccsd->bIsDifferentPixelFormat)
		{
			goto CannotCreate;
		}
		else
		{
			goto CanCreate;
		}
	}
	else if (dwCaps & DDSCAPS_OVERLAY)
	{
		if(g_currentusingoveray >= MAX_OVERAY_COUNT)
		{
			RETAILMSG(1,(TEXT("Not Enough Overay Layer Max Layer is %d \n "),MAX_OVERAY_COUNT));
			goto NotEnoughOverayLayer;
		}
		if (pddpf->dwFlags & DDPF_RGB) {
		      if (
                (pddpf->dwRGBBitCount == 16 &&
                 pddpf->dwRBitMask == 0xF800 &&
                 pddpf->dwGBitMask == 0x07E0 &&
                 pddpf->dwBBitMask == 0x001F)
				 )
				 {
				goto CanCreate;
			  }
			  else if(
                (pddpf->dwRGBBitCount == 16 &&
                 pddpf->dwRBitMask == 0x7C00  &&
                 pddpf->dwGBitMask == 0x03E0 &&
                 pddpf->dwBBitMask == 0x001F)

                   ) 
			  {
				goto CanCreate;
			  }
			  else if(
                (pddpf->dwRGBBitCount == 24 &&
                 pddpf->dwRBitMask == 0xFF0000  &&
                 pddpf->dwGBitMask == 0xFF000 &&
                 pddpf->dwBBitMask == 0xFF)

                   ) 
			  {
				goto CanCreate;
			  }
		}
		else if(pddpf->dwFlags &DDPF_FOURCC)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("-[DDHAL] DDPF_FOURCC OK\n\r")));
            if(
				//( pDDPF->dwFourCC == FOURCC_I420 )||
				( pddpf->dwFourCC == FOURCC_YUYV )||
				//( pddpf->dwFourCC == FOURCC_YVYU )||
				//( pDDPF->dwFourCC == FOURCC_VYUY )||
				0)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("-[DDHAL] FOURCC_YUYV OK\n\r")));
				goto CanCreate;
			}
			else
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("-[DDHAL] %x (%x,%x,%x)fail\n\r"),pddpf->dwFourCC,FOURCC_I420,FOURCC_YVYU,FOURCC_VYUY));
            
		}
		goto CannotCreate;
	}
	else		// Non Primary, Non Overlay Surface (Maybe Offscreen Surface)
	{
		return DDGPECanCreateSurface(lpccsd);
	}

CanCreate:

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("-[DDHAL] HalCanCreateSurface() OK\n\r")));
	lpccsd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;

CannotCreate:

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("-[DDHAL:ERR] HalCanCreateSurface() : Unsupported Surface\n\r")));
	lpccsd->ddRVal = DDERR_UNSUPPORTEDFORMAT;

	return DDHAL_DRIVER_HANDLED;

NotEnoughOverayLayer:

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("-[DDHAL:ERR] HalCanCreateSurface() : Not enough Surface\n\r")));
	lpccsd->ddRVal = DDERR_UNSUPPORTEDFORMAT;

	return DDHAL_DRIVER_HANDLED;
}

//////////////////////////// DDHAL_DDSURFACECALLBACKS ////////////////////////////

DWORD
WINAPI
HalFlip(LPDDHAL_FLIPDATA lpfd)
{
	DEBUGENTER( HalFlip );
	/*
	typedef struct _DDHAL_FLIPDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		LPDDRAWI_DDRAWSURFACE_LCL lpSurfCurr;
		LPDDRAWI_DDRAWSURFACE_LCL lpSurfTarg;
		DWORD dwFlags;
		HRESULT ddRVal;
	} DDHAL_FLIPDATA;
	*/
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DDHAL:DISP] +HalFlip [%d]\n\r"),lpfd->lpDD->dwGDISurfReserved1));

	TCCDISP *pDDGPE = (TCCDISP *)GetDDGPE();
	DWORD dwFlags = lpfd->dwFlags;

	if (dwFlags & (DDFLIP_INTERVAL1|DDFLIP_INTERVAL2|DDFLIP_INTERVAL4))
	{
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalFlip() : DDFLIP_INTERVAL is not supported\n\r")));
		lpfd->ddRVal = DDERR_UNSUPPORTED;
	}
	else
	{
		if (dwFlags & DDFLIP_WAITNOTBUSY)
		{
#if	0	
			while(((TCCDISP *)GetDDGPE())->IsBusy());
#endif
		}

		DDGPESurf* surfTarg = DDGPESurf::GetDDGPESurf(lpfd->lpSurfTarg);
		DWORD dwIndex = 0; 
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[%x] \n"),surfTarg));
		for(unsigned int i=0; i < 2; i++)
			for(unsigned int j=0; j < g_OverSufraceCount[i]; j++)
			{
				if(pOveraySurf[i][j] == surfTarg)
				{
					dwIndex=i;
					//RETAILMSG(1,(TEXT("Find Surface Overray is %d .. %x %x \n"),i,pOveraySurf[i][j],surfTarg));
					break;
				}
			}
		if (dwFlags & DDFLIP_WAITVSYNC)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("FLIP On %d %d \n"),dwIndex, surfTarg->IsOverlay()));
			pDDGPE->SetVisibleSurface(surfTarg, TRUE, dwIndex);
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("FLIP On %d %d \n"),dwIndex, surfTarg->IsOverlay()));
			pDDGPE->SetVisibleSurface(surfTarg, FALSE, dwIndex);
		}

		lpfd->ddRVal = DD_OK;
	}

	DEBUGLEAVE( HalFlip );

	return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalGetBltStatus( LPDDHAL_GETBLTSTATUSDATA lpgbsd )
{
	DEBUGENTER( HalGetBltStatus );
	/*
	typedef struct _DDHAL_GETBLTSTATUSDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		LPDDRAWI_DDRAWSURFACE_LCL lpDDSurface;
		DWORD dwFlags;
		HRESULT ddRVal;
	} DDHAL_GETBLTSTATUSDATA;
	*/

	// Implementation
	lpgbsd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalGetFlipStatus( LPDDHAL_GETFLIPSTATUSDATA lpgfsd)
{
	DEBUGENTER( HalGetFlipStatus );
	/*
	typedef struct _DDHAL_GETFLIPSTATUSDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		LPDDRAWI_DDRAWSURFACE_LCL lpDDSurface;
		DWORD dwFlags;
		HRESULT ddRVal;
	} DDHAL_GETFLIPSTATUSDATA;
	*/

	lpgfsd->ddRVal = DD_OK;

	// NOTE: DDGBS_CANFLIP always return DD_OK
	// Actually second flip request in same display frame is blocked to next frame

	return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalUpdateOverlay(LPDDHAL_UPDATEOVERLAYDATA lpuod)
{
	DEBUGENTER( HalUpdateOverlay );
	/*
	typedef struct _DDHAL_UPDATEOVERLAYDATA {
		  LPDDRAWI_DIRECTDRAW_GBL lpDD;
		  LPDDRAWI_DDRAWSURFACE_LCL lpDDDestSurface;
		  RECT rDest;
		  LPDDRAWI_DDRAWSURFACE_LCL lpDDSrcSurface;
		  RECT rSrc;
		  DWORD dwFlags;
		  DDOVERLAYFX overlayFX;
		  HRESULT ddRVal;
	} DDHAL_UPDATEOVERLAYDATA;
	*/
RETAILMSG(1,(TEXT("HalUpdateOverlay[%x][%x][%x][%x] \n"),lpuod->dwFlags,lpuod->lpDDSrcSurface->dwOverlayFlags
													,lpuod->lpDDDestSurface->dwOverlayFlags
													,lpuod->lpDDSrcSurface->dwReserved1));
	TCCDISP	*pDDGPE;
	TCCDISPSurf	*pSrcSurf;
	TCCDISPSurf	*pDestSurf;
	LPDDRAWI_DDRAWSURFACE_LCL lpSrcLCL;
	LPDDRAWI_DDRAWSURFACE_LCL lpDestLCL;

	BOOL bEnableOverlay = FALSE;
	DWORD dwIndex = 0;
	DDGPESurf* surfTarg = DDGPESurf::GetDDGPESurf(lpuod->lpDDSrcSurface);
	for(unsigned int i=0; i < 2; i++)
		for(unsigned int j=0; j < g_OverSufraceCount[i]; j++)
		{
			if(pOveraySurf[i][j] == surfTarg)
			{
				dwIndex=i;
				//RETAILMSG(1,(TEXT("Find Surface Overray is %d .. %x %x \n"),i,pOveraySurf[i][j],surfTarg));
				break;
			}
		}
	lpSrcLCL = lpuod->lpDDSrcSurface;
	lpDestLCL = lpuod->lpDDDestSurface;

	pDDGPE = (TCCDISP *)GetDDGPE();
	pSrcSurf = (TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpSrcLCL);
	pDestSurf = (TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpDestLCL);

	if (lpuod->dwFlags & DDOVER_HIDE)
	{
		// If overlay surface is valid, Turn off overlay
		if (pSrcSurf->OffsetInVideoMemory() != NULL)
		{
			if ( (pSrcSurf == pDDGPE->GetCurrentOverlaySurf(dwIndex))
				|| (pSrcSurf == pDDGPE->GetPreviousOverlaySurf(dwIndex)) )
			{
				pDDGPE->OverlayDisable(dwIndex);
			}

			lpuod->ddRVal = DD_OK;
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalUpdateOverlay() : pSrcSurf->OffsetInVideoMemory() = NULL\n\r")));
			lpuod->ddRVal = DDERR_INVALIDPARAMS;
		}

		return (DDHAL_DRIVER_HANDLED);
	}
	else if (lpuod->dwFlags & DDOVER_SHOW)
	{
		if (pSrcSurf->OffsetInVideoMemory() != NULL)
		{
			/*if ( (pSrcSurf != pDDGPE->GetCurrentOverlaySurf())
				&& (pSrcSurf != pDDGPE->GetPreviousOverlaySurf())
				&& (pDDGPE->GetCurrentOverlaySurf() != NULL))
			{
				// Some other overlay surface is already visible:
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalUpdateOverlay() : Overlay is already in use by another surface\n\r")));

				lpuod->ddRVal = DDERR_OUTOFCAPS;

				return (DDHAL_DRIVER_HANDLED);
			}
			else*/
			if(g_currentusingoveray <= MAX_OVERAY_COUNT)
			{
				
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Overay Initialize: pixelformat:%x\n\r"),pSrcSurf->PixelFormat()));
				// Initialize Overlay
				if (pDDGPE->OverlayInitialize(pSrcSurf, &lpuod->rSrc, &lpuod->rDest, dwIndex) == FALSE)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalUpdateOverlay() : OverlayInitialize() Failed\n\r")));

					lpuod->ddRVal = DDERR_OUTOFCAPS;

					return (DDHAL_DRIVER_HANDLED);
				}

				bEnableOverlay = TRUE;
			}
			else
			{

				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY    ] HalUpdateOverlay() : OverlayInitialize() Failed Overlay allowed count %d/%d\n\r"),g_currentusingoveray,MAX_OVERAY_COUNT));

				lpuod->ddRVal = DDERR_OUTOFCAPS;

				return (DDHAL_DRIVER_HANDLED);
			}

		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalUpdateOverlay() : pSrcSurf->OffsetInVideoMemory() = NULL\n\r")));

			lpuod->ddRVal = DDERR_INVALIDPARAMS;
			return (DDHAL_DRIVER_HANDLED);
		}
	}
	else
	{
		// If overlay surface is not visiable,  Nothing to do
		lpuod->ddRVal = DD_OK;

		return (DDHAL_DRIVER_HANDLED);
	}

	if ((lpuod->dwFlags & (DDOVER_KEYSRC|DDOVER_KEYSRCOVERRIDE|DDOVER_KEYDEST|DDOVER_KEYDESTOVERRIDE))
		&& (lpuod->dwFlags & (DDOVER_ALPHASRC|DDOVER_ALPHACONSTOVERRIDE)))
	{
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalUpdateOverlay() : Driver Not Support ColorKey & Alpha at the same time (dwFlags = 0x%08x)\n\r"), lpuod->dwFlags));
	}

	// chromakey setting
	if ((lpuod->dwFlags & DDOVER_KEYSRC)
		|| (lpuod->dwFlags & DDOVER_KEYSRCOVERRIDE))
	{
		DWORD dwColorKey;

		if (lpuod->dwFlags & DDOVER_KEYSRCOVERRIDE)
		{
			dwColorKey = lpuod->overlayFX.dckSrcColorkey.dwColorSpaceLowValue;
		}
		else
		{
			dwColorKey = lpSrcLCL->ddckCKSrcOverlay.dwColorSpaceLowValue;
		}

		pDDGPE->OverlaySetColorKey(TRUE, pSrcSurf->PixelFormat(), dwColorKey, dwIndex);
	}
	// Destination Color Key
	else if ((lpuod->dwFlags & DDOVER_KEYDEST)
		|| (lpuod->dwFlags & DDOVER_KEYDESTOVERRIDE))
	{
		DWORD dwColorKey;

		if (lpuod->dwFlags & DDOVER_KEYDESTOVERRIDE)
		{
			dwColorKey = lpuod->overlayFX.dckDestColorkey.dwColorSpaceLowValue;
		}
		else
		{
			dwColorKey = lpDestLCL->ddckCKDestOverlay.dwColorSpaceLowValue;
		}

		pDDGPE->OverlaySetColorKey(FALSE, pDestSurf->PixelFormat(), dwColorKey, dwIndex);
	}
	// Alpha Blending setting
	else if ((lpuod->dwFlags & DDOVER_ALPHASRC)
		|| (lpuod->dwFlags & DDOVER_ALPHACONSTOVERRIDE))
	{
		RETAILMSG(1,(TEXT("Alpha Blending setting : %x \n"),lpuod->overlayFX.dwAlphaConst));
		if (lpuod->dwFlags & DDOVER_ALPHACONSTOVERRIDE)	// Per Plane Alpha Blending
		{
			pDDGPE->OverlaySetAlpha(FALSE, lpuod->overlayFX.dwAlphaConst, dwIndex);
		}
		else
		{
			pDDGPE->OverlaySetAlpha(TRUE, lpuod->overlayFX.dwAlphaConst, dwIndex);
		}
	}
	// No Blending Effect
	else
	{
		pDDGPE->OverlayBlendDisable(dwIndex);
	}

	// Enable Overlay after set up blending
	if (bEnableOverlay) pDDGPE->OverlayEnable(dwIndex);

	lpuod->ddRVal = DD_OK;

	return (DDHAL_DRIVER_HANDLED);
}

DWORD WINAPI HalSetOverlayPosition(LPDDHAL_SETOVERLAYPOSITIONDATA lpsopd)
{
	DEBUGENTER( HalSetOverlayPosition );
	/*
	typedef struct _DDHAL_SETOVERLAYPOSITIONDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		LPDDRAWI_DDRAWSURFACE_LCL lpDDSrcSurface;
		LPDDRAWI_DDRAWSURFACE_LCL lpDDDestSurface;
		LONG lXPos;
		LONG lYPos;
		HRESULT ddRVal;
	} DDHAL_SETOVERLAYPOSITIONDATA;
	*/

	TCCDISP	*pDDGPE;
	TCCDISPSurf *pSrcSurf;

	pDDGPE = (TCCDISP *)GetDDGPE();
	pSrcSurf = (TCCDISPSurf *)DDGPESurf::GetDDGPESurf(lpsopd->lpDDSrcSurface);
	DWORD dwIndex = 5; 
	for(unsigned int i=0; i < 2; i++)
		for(unsigned int j=0; j < g_OverSufraceCount[i]; j++)
		{
			if(pOveraySurf[i][j] == pSrcSurf)
			{
				dwIndex=i;
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("Find Surface Overray is %d .. %x %x \n"),i,pOveraySurf[i][j],pSrcSurf));
				break;
			}
		}
	pDDGPE->OverlaySetPosition((unsigned int)lpsopd->lXPos, (unsigned int)lpsopd->lYPos,dwIndex);
	lpsopd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalSetColorKey(LPDDHAL_SETCOLORKEYDATA lpdsckd)
{
	DEBUGENTER(HalSetColorKey);
	/*
	typedef struct _DDHAL_SETCOLORKEYDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		LPDDRAWI_DDRAWSURFACE_LCL lpDDSurface;
		DWORD dwFlags;
		DDCOLORKEY ckNew;
		HRESULT ddRVal;
	} DDHAL_SETCOLORKEYDATA;
	*/

	DDGPESurf* pSurf = DDGPESurf::GetDDGPESurf(lpdsckd->lpDDSurface);
	if (pSurf != NULL)
	{
		if (lpdsckd->dwFlags == DDCKEY_COLORSPACE)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalSetColorKey() : Color Space CKEY is Not Supported\n\r")));
			lpdsckd->ddRVal = DDERR_NOCOLORKEYHW;
		}
		else if ((lpdsckd->dwFlags == DDCKEY_SRCBLT)
			|| (lpdsckd->dwFlags == DDCKEY_DESTBLT))
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalSetColorKey() : Color Space CKEY or CKEY BLT is Not Supported\n\r")));

			pSurf->SetColorKeyLow(lpdsckd->ckNew.dwColorSpaceLowValue);
			pSurf->SetColorKeyHigh(lpdsckd->ckNew.dwColorSpaceHighValue);
			lpdsckd->ddRVal = DD_OK;
		}
		else	 if ((lpdsckd->dwFlags == DDCKEY_SRCOVERLAY)
			|| (lpdsckd->dwFlags == DDCKEY_DESTOVERLAY))
		{
			pSurf->SetColorKeyLow(lpdsckd->ckNew.dwColorSpaceLowValue);
			pSurf->SetColorKeyHigh(lpdsckd->ckNew.dwColorSpaceHighValue);
			lpdsckd->ddRVal = DD_OK;
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalSetColorKey() : Invalid dwFlags = 0x%08x\n\r"), lpdsckd->dwFlags));
			lpdsckd->ddRVal = DDERR_INVALIDOBJECT;
		}
	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL:ERR] HalSetColorKey() : Surface Object is Null\n\r")));
		lpdsckd->ddRVal = DDERR_INVALIDOBJECT;
	}

	DEBUGLEAVE(HalSetColorKey);

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalDestroySurface( LPDDHAL_DESTROYSURFACEDATA pd )   
{   
    DEBUGENTER( HalDestroySurface );   
    /*  
    typedef struct _DDHAL_DESTROYSURFACEDATA  
    {  
        LPDDRAWI_DIRECTDRAW_GBL     lpDD;           // driver struct  
        LPDDRAWI_DDRAWSURFACE_LCL   lpDDSurface;    // surface struct  
        HRESULT                     ddRVal;         // return value  
        LPDDHALSURFCB_DESTROYSURFACE DestroySurface;// PRIVATE: ptr to callback  
        BOOL                        fDestroyGlobal;  
    } DDHAL_DESTROYSURFACEDATA;  
    */   
   
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("Destroy GPESurf *:0x%08x\r\n"), DDGPESurf::GetDDGPESurf(pd->lpDDSurface) ));    
	DDGPESurf* surfTarg = DDGPESurf::GetDDGPESurf(pd->lpDDSurface);	
	DWORD dwIndex=5;
	if(surfTarg->IsOverlay())
	{	DWORD dwIndex = 5; //lpsopd->lpDD->pOverlays.dwReserved1;
		for(unsigned int i=0; i < 2; i++)
			for(unsigned int j=0; j < g_OverSufraceCount[i]; j++)
			{
				if(pOveraySurf[i][j] == surfTarg)
				{
					dwIndex=i;
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("Find Surface Overray is %d .. %x %x \n"),i,pOveraySurf[i][j],surfTarg));
					break;
				}
			}
		if(g_UsingLayer[dwIndex] == TRUE)
		{
			g_UsingLayer[dwIndex]=FALSE;
			g_currentusingoveray--;
			if(dwIndex == 1) //if layer 0 
			{
				if(g_UsingLayer[0] == TRUE)
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 1<<1; //Layer Order change 0 - 2 - 1
				}
				else
				{	
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 5<<1; //Layer Order change 2 - 1 - 0
				}
			}
			else if(dwIndex == 0) //if layer 2 
			{
				if(g_UsingLayer[1] == TRUE)
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 3<<1; //Layer Order change 2 - 0 - 1
				}
				else
				{
					pLCD->LCTRL &=~(7<<1);
					pLCD->LCTRL |= 5<<1; //Layer Order change 2 - 1 - 0
				}
			}
		}
	}

	TCCDISP *pDDGPE = (TCCDISP *)GetDDGPE();

    // Make sure we're not destroying the GDI surface.    
    if( (DDGPESurf*)(pDDGPE->PrimarySurface()) != DDGPESurf::GetDDGPESurf(pd->lpDDSurface) )   
    {   
        RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("DeleteSurface\n")));    
        DDGPESurf::DeleteSurface(pd->lpDDSurface);   
        pd->lpDDSurface = NULL;   
    }   



    pd->ddRVal = DD_OK;   
    DEBUGLEAVE( HalDestroySurface );   
    return DDHAL_DRIVER_HANDLED; 
}