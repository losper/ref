/****************************************************************************
*   FileName    : blt.cpp
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/


#include "precomp.h"
#include <ceddk.h>
#include <dispperf.h>
#include "TCC_emul.h"
#include "blt.h"

extern "C"
{
	void fmemcpy800(volatile ULONG *pDst, volatile ULONG *pSrc);
}

extern sHwGE *pGraphicEngine;
extern DWORD g_dwBPPOption;

#define TEMP_DEBUG	(FALSE)
#define FULL_TEST_OK	(0)
#ifdef _USING_HW_ACCELERATE_
SCODE 
TCCDISP::TCCGraphicEngineBltNULL(GPEBltParms *pParms)
{
	return S_OK;
}
static SCODE GraphicEngine(DWORD DAddress, DWORD DFrameWidth, DWORD DFrameHeight, DWORD DX, DWORD DY, DWORD DWidth, DWORD DHeight, DWORD DFormat, DWORD SAddress, DWORD SFrameWidth, DWORD SFrameHeight, DWORD SX, DWORD SY, DWORD SWidth, DWORD SHeight, DWORD SFormat,DWORD dwSolidColor, DWORD rop4)
{
	if( rop4 == 0xCCCC )
	{
		pGraphicEngine->BCH[0].DADDR0=DAddress;
		pGraphicEngine->BCH[0].DFSIZE=HwGE_FCH_SFSIZE_X(DFrameWidth)|HwGE_FCH_SFSIZE_Y(DFrameHeight);
		pGraphicEngine->BCH[0].DOFF	 =HwGE_FCH_SOFF_X(DX)|HwGE_FCH_SOFF_Y(DY);
		pGraphicEngine->BCH[0].DCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|DFormat;
		
		pGraphicEngine->FCH[0].SADDR0=SAddress;
		pGraphicEngine->FCH[0].SFSIZE=HwGE_FCH_SFSIZE_X(SFrameWidth)|HwGE_FCH_SFSIZE_Y(SFrameHeight);
		pGraphicEngine->FCH[0].SOFF	 =HwGE_FCH_SOFF_X(SX)|HwGE_FCH_SOFF_Y(SY);
		pGraphicEngine->FCH[0].SISIZE=HwGE_FCH_SISIZE_X(SWidth)|HwGE_FCH_SISIZE_Y(SHeight);
		pGraphicEngine->FCH[0].WOFF  =HwGE_FCH_WOFF_X(0)|HwGE_FCH_WOFF_Y(0);
		pGraphicEngine->FCH[0].SCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|SFormat;

		if(dwSolidColor)
		{

			pGraphicEngine->S[0].CHROMA=0;
			pGraphicEngine->S[0].PARAM=0;
		}
		else
		{
			pGraphicEngine->S[0].CHROMA=0;
			pGraphicEngine->S[0].PARAM=0;
		}
		pGraphicEngine->S[1].CHROMA=0;
		pGraphicEngine->S[1].PARAM=0;

		//source control
		pGraphicEngine->SCTRL=HwGE_SCTRL_S0ARITH_BYPASS|HwGE_SCTRL_S0SEL_FCH0;
		//operation control
		pGraphicEngine->OPCTRL=HwGE_OPCTRL_OP1MODE_SCOPY|HwGE_OPCTRL_CSEL0_DIS|HwGE_OPCTRL_OP0MODE_NSCOPY;

	}
	else if(rop4 == 0xEEEE)
	{
		pGraphicEngine->BCH[0].DADDR0=DAddress;
		pGraphicEngine->BCH[0].DFSIZE=HwGE_FCH_SFSIZE_X(DFrameWidth)|HwGE_FCH_SFSIZE_Y(DFrameHeight);
		pGraphicEngine->BCH[0].DOFF	 =HwGE_FCH_SOFF_X(DX)|HwGE_FCH_SOFF_Y(DY);
		pGraphicEngine->BCH[0].DCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|DFormat;

		pGraphicEngine->FCH[0].SADDR0=SAddress;
		pGraphicEngine->FCH[0].SFSIZE=HwGE_FCH_SFSIZE_X(SFrameWidth)|HwGE_FCH_SFSIZE_Y(SFrameHeight);
		pGraphicEngine->FCH[0].SOFF	 =HwGE_FCH_SOFF_X(SX)|HwGE_FCH_SOFF_Y(SY);
		pGraphicEngine->FCH[0].SISIZE=HwGE_FCH_SISIZE_X(SWidth)|HwGE_FCH_SISIZE_Y(SHeight);
		pGraphicEngine->FCH[0].WOFF  =HwGE_FCH_WOFF_X(0)|HwGE_FCH_WOFF_Y(0);
		pGraphicEngine->FCH[0].SCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|SFormat;

		if(dwSolidColor)
		{

			pGraphicEngine->S[0].CHROMA=0;//HwGE_S_CHROMA_RY(0x1F<<3)|HwGE_S_CHROMA_GU(0x3F<<2)|HwGE_S_CHROMA_BV(0x1F<<3);
			pGraphicEngine->S[0].PARAM=0;
		}
		else
		{
			pGraphicEngine->S[0].CHROMA=0;
			pGraphicEngine->S[0].PARAM=0;
		}
		pGraphicEngine->S[1].CHROMA=0;
		pGraphicEngine->S[1].PARAM=0;

		//source control
		pGraphicEngine->SCTRL=HwGE_SCTRL_S0ARITH_BYPASS|HwGE_SCTRL_S0SEL_FCH0;
		//operation control
		pGraphicEngine->OPCTRL=HwGE_OPCTRL_OP1MODE_SCOPY|HwGE_OPCTRL_CSEL0_DIS|HwGE_OPCTRL_OP0MODE_SCOPY;

	}else if(rop4 == 0x8888)
	{
		pGraphicEngine->BCH[0].DADDR0=DAddress;
		pGraphicEngine->BCH[0].DFSIZE=HwGE_FCH_SFSIZE_X(DFrameWidth)|HwGE_FCH_SFSIZE_Y(DFrameHeight);
		pGraphicEngine->BCH[0].DOFF	 =HwGE_FCH_SOFF_X(DX)|HwGE_FCH_SOFF_Y(DY);
		pGraphicEngine->BCH[0].DCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|DFormat;

		pGraphicEngine->FCH[0].SADDR0=SAddress;
		pGraphicEngine->FCH[0].SFSIZE=HwGE_FCH_SFSIZE_X(SFrameWidth)|HwGE_FCH_SFSIZE_Y(SFrameHeight);
		pGraphicEngine->FCH[0].SOFF	 =HwGE_FCH_SOFF_X(SX)|HwGE_FCH_SOFF_Y(SY);
		pGraphicEngine->FCH[0].SISIZE=HwGE_FCH_SISIZE_X(SWidth)|HwGE_FCH_SISIZE_Y(SHeight);
		pGraphicEngine->FCH[0].WOFF  =HwGE_FCH_WOFF_X(0)|HwGE_FCH_WOFF_Y(0);
		pGraphicEngine->FCH[0].SCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|SFormat;

		if(dwSolidColor)
		{

			pGraphicEngine->S[0].CHROMA=0;//HwGE_S_CHROMA_RY(0x1F<<3)|HwGE_S_CHROMA_GU(0x3F<<2)|HwGE_S_CHROMA_BV(0x1F<<3);
			pGraphicEngine->S[0].PARAM=0;
		}
		else
		{
			pGraphicEngine->S[0].CHROMA=0;
			pGraphicEngine->S[0].PARAM=0;
		}
		pGraphicEngine->S[1].CHROMA=0;
		pGraphicEngine->S[1].PARAM=0;

		//source control
		pGraphicEngine->SCTRL=HwGE_SCTRL_S0ARITH_BYPASS|HwGE_SCTRL_S0SEL_FCH0;
		//operation control
		pGraphicEngine->OPCTRL=HwGE_OPCTRL_OP1MODE_SAND|HwGE_OPCTRL_CSEL0_DIS|HwGE_OPCTRL_OP0MODE_SAND;

	}else if(rop4 == 0x6666)
	{
		pGraphicEngine->BCH[0].DADDR0=DAddress;
		pGraphicEngine->BCH[0].DFSIZE=HwGE_FCH_SFSIZE_X(DFrameWidth)|HwGE_FCH_SFSIZE_Y(DFrameHeight);
		pGraphicEngine->BCH[0].DOFF	 =HwGE_FCH_SOFF_X(DX)|HwGE_FCH_SOFF_Y(DY);
		pGraphicEngine->BCH[0].DCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|DFormat;

		pGraphicEngine->FCH[0].SADDR0=SAddress;
		pGraphicEngine->FCH[0].SFSIZE=HwGE_FCH_SFSIZE_X(SFrameWidth)|HwGE_FCH_SFSIZE_Y(SFrameHeight);
		pGraphicEngine->FCH[0].SOFF	 =HwGE_FCH_SOFF_X(SX)|HwGE_FCH_SOFF_Y(SY);
		pGraphicEngine->FCH[0].SISIZE=HwGE_FCH_SISIZE_X(SWidth)|HwGE_FCH_SISIZE_Y(SHeight);
		pGraphicEngine->FCH[0].WOFF  =HwGE_FCH_WOFF_X(0)|HwGE_FCH_WOFF_Y(0);
		pGraphicEngine->FCH[0].SCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|SFormat;

		if(dwSolidColor)
		{

			pGraphicEngine->S[0].CHROMA=0;//HwGE_S_CHROMA_RY(0x1F<<3)|HwGE_S_CHROMA_GU(0x3F<<2)|HwGE_S_CHROMA_BV(0x1F<<3);
			pGraphicEngine->S[0].PARAM=0;
		}
		else
		{
			pGraphicEngine->S[0].CHROMA=0;
			pGraphicEngine->S[0].PARAM=0;
		}
		pGraphicEngine->S[1].CHROMA=0;
		pGraphicEngine->S[1].PARAM=0;

		//source control
		pGraphicEngine->SCTRL=HwGE_SCTRL_S0ARITH_INV|HwGE_SCTRL_S0SEL_FCH0;
		//operation control
		pGraphicEngine->OPCTRL=HwGE_OPCTRL_OP1MODE_SINV|HwGE_OPCTRL_CSEL0_DIS|HwGE_OPCTRL_OP0MODE_SINV;

	}else if(rop4 == 0x3333)
	{
	
		pGraphicEngine->BCH[0].DADDR0=DAddress;
		pGraphicEngine->BCH[0].DFSIZE=HwGE_FCH_SFSIZE_X(DFrameWidth)|HwGE_FCH_SFSIZE_Y(DFrameHeight);
		pGraphicEngine->BCH[0].DOFF	 =HwGE_FCH_SOFF_X(DX)|HwGE_FCH_SOFF_Y(DY);
		pGraphicEngine->BCH[0].DCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|DFormat;

		pGraphicEngine->FCH[0].SADDR0=SAddress;
		pGraphicEngine->FCH[0].SFSIZE=HwGE_FCH_SFSIZE_X(SFrameWidth)|HwGE_FCH_SFSIZE_Y(SFrameHeight);
		pGraphicEngine->FCH[0].SOFF	 =HwGE_FCH_SOFF_X(SX)|HwGE_FCH_SOFF_Y(SY);
		pGraphicEngine->FCH[0].SISIZE=HwGE_FCH_SISIZE_X(SWidth)|HwGE_FCH_SISIZE_Y(SHeight);
		pGraphicEngine->FCH[0].WOFF  =HwGE_FCH_WOFF_X(0)|HwGE_FCH_WOFF_Y(0);
		pGraphicEngine->FCH[0].SCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|SFormat;
		
		if(dwSolidColor)
		{
			pGraphicEngine->S[0].CHROMA=0;
			pGraphicEngine->S[0].PARAM=0;
		}
		else
		{
			pGraphicEngine->S[0].CHROMA=0;
			pGraphicEngine->S[0].PARAM=0;
		}
		pGraphicEngine->S[1].CHROMA=0;
		pGraphicEngine->S[1].PARAM=0;

		//source control
		pGraphicEngine->SCTRL=HwGE_SCTRL_S0ARITH_INV|HwGE_SCTRL_S0SEL_FCH0;
		//operation control
		pGraphicEngine->OPCTRL=HwGE_OPCTRL_OP1MODE_SCOPY|HwGE_OPCTRL_CSEL0_DIS|HwGE_OPCTRL_OP1MODE_SCOPY;

	}
	else if(rop4 == 0xF0F0)
	{

		pGraphicEngine->BCH[0].DADDR0=DAddress;
		pGraphicEngine->BCH[0].DFSIZE=HwGE_FCH_SFSIZE_X(DFrameWidth)|HwGE_FCH_SFSIZE_Y(DFrameHeight);
		pGraphicEngine->BCH[0].DOFF	 =HwGE_FCH_SOFF_X(DX)|HwGE_FCH_SOFF_Y(DY);
		pGraphicEngine->BCH[0].DCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|DFormat;

		pGraphicEngine->FCH[0].SADDR0=DAddress;
		pGraphicEngine->FCH[0].SFSIZE=HwGE_FCH_SFSIZE_X(DFrameWidth)|HwGE_FCH_SFSIZE_Y(DFrameHeight);
		pGraphicEngine->FCH[0].SOFF	 =HwGE_FCH_SOFF_X(DX)|HwGE_FCH_SOFF_Y(DY);
		pGraphicEngine->FCH[0].SISIZE=HwGE_FCH_SISIZE_X(DWidth)|HwGE_FCH_SISIZE_Y(DHeight);
		pGraphicEngine->FCH[0].WOFF  =HwGE_FCH_WOFF_X(0)|HwGE_FCH_WOFF_Y(0);
		pGraphicEngine->FCH[0].SCTRL =HwGE_FCH_SCTRL_OPMODE_COPY|HwGE_FCH_SCTRL_ZF_ZEROFILL|DFormat;


		pGraphicEngine->S[0].CHROMA=0;

		if(HwGE_FCH_SCTRL_SDFRM_RGB565 == DFormat)
			pGraphicEngine->S[0].PARAM = dwSolidColor;
		else if(HwGE_FCH_SCTRL_SDFRM_RGB888 == DFormat)
			pGraphicEngine->S[0].PARAM = (dwSolidColor&0xFFFFFF);


		pGraphicEngine->S[1].CHROMA=0;
		pGraphicEngine->S[1].PARAM=0;

		//source control
		pGraphicEngine->SCTRL=HwGE_SCTRL_S0ARITH_FILL|HwGE_SCTRL_S0SEL_FCH0;
		//operation control
		pGraphicEngine->OPCTRL=HwGE_OPCTRL_OP1MODE_SCOPY|HwGE_OPCTRL_CSEL0_DIS|HwGE_OPCTRL_OP1MODE_SCOPY;

	}
	else 
	{
		pGraphicEngine->FCH[2].SADDR0 = 0xFF00; //user flag set
		return S_FALSE;
	}

	pGraphicEngine->CTRL=1;
	while( pGraphicEngine->CTRL )
		::Sleep(0);
	pGraphicEngine->IREQ=0;

	pGraphicEngine->FCH[2].SADDR0 = 0xFF00; //user flag set
	return S_OK;
}

/*
enum EGPEFormat
{
gpe1Bpp,
gpe2Bpp,
gpe4Bpp,
gpe8Bpp,
gpe16Bpp,
gpe24Bpp,
gpe32Bpp,
gpe16YCrCb,
gpeDeviceCompatible,
gpeUndefined
};
*/
SCODE 
TCCDISP::TCCGraphicEngineBlt(GPEBltParms *pParms)
{
	SCODE sRet=S_FALSE ;
	DWORD DAddress;
	DWORD DFormat;
	

	if( m_pPrimarySurface==pParms->pDst )
		DAddress=m_VideoMemoryPhysicalBase;
	else
		DAddress=(m_VideoMemoryPhysicalBase + ((TCCDISPSurf *)(pParms->pDst))->OffsetInVideoMemory());
		
	switch( pParms->pDst->Format() )
	{
	case gpeDeviceCompatible:
	case gpe16Bpp:
		DFormat=HwGE_FCH_SCTRL_SDFRM_RGB565;
		break;
	case gpe24Bpp:
	case gpe32Bpp:
		DFormat=HwGE_FCH_SCTRL_SDFRM_RGB888;
		break;
	}

	if( pParms->pSrc )
	{
		DWORD SAddress;
		DWORD SFormat;

		switch( pParms->pSrc->Format() )
		{
		case gpe8Bpp:
			SFormat=HwGE_FCH_SCTRL_SDFRM_RGB332;
			break;
		case gpeDeviceCompatible:
		case gpe16Bpp: //4
			SFormat=HwGE_FCH_SCTRL_SDFRM_RGB565;
			break;
		case gpe24Bpp: //5
		case gpe32Bpp: //6
			SFormat=HwGE_FCH_SCTRL_SDFRM_RGB888;
			break;
		}

		if( m_pPrimarySurface==pParms->pSrc )
		{
			SAddress=m_VideoMemoryPhysicalBase;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ]m_pPrimarySurface==pParms->pSrc!!\n")));
		}
		else
		{
			if( pParms->pSrc->InVideoMemory() &&(( pParms->rop4 == 0xcccc)  ||( pParms->rop4 == 0x6666)||(pParms->rop4 == 0x3333)))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ]|%d %d %d %d, %d %d %d %d %d+[%x][%x][%x]\r\n"), pParms->prclDst->left, pParms->prclDst->top, pParms->prclDst->right, pParms->prclDst->bottom, pParms->prclSrc->left, pParms->prclSrc->top, pParms->prclSrc->right, pParms->prclSrc->bottom, pParms->pSrc->Format(),pParms->rop4,pParms->solidColor,pParms->pConvert));
				SAddress=(m_VideoMemoryPhysicalBase + ((TCCDISPSurf *)(pParms->pSrc))->OffsetInVideoMemory());
				

			}
			else if( pParms->rop4 == 0xCCCC )
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ]|%d %d %d %d, %d %d %d %d %d-\r\n"), pParms->prclDst->left, pParms->prclDst->top, pParms->prclDst->right, pParms->prclDst->bottom, pParms->prclSrc->left, pParms->prclSrc->top, pParms->prclSrc->right, pParms->prclSrc->bottom, pParms->pSrc->Format()));
				if(pParms->pSrc->Format()==6)
				{
					DWORD *pD = NULL;
					DWORD *pdwS = (DWORD *)pParms->pSrc->Buffer()+
								  pParms->pSrc->Stride()/sizeof(DWORD)*pParms->prclSrc->top;
					for(int y=pParms->prclSrc->top; y<pParms->prclSrc->bottom; ++y)
					{
						pD =(DWORD *)(pHWTempHeap->Address() +pParms->pSrc->Width()*4*y);
						memmove(pD,pdwS,(pParms->prclSrc->right - pParms->prclSrc->left)*sizeof(DWORD));
						pdwS+=pParms->pSrc->Stride()/sizeof(DWORD);
					}
					SAddress=(pHWTempHeap->Address()-0x60000000);
				}
				else if(pParms->pSrc->Format()==5)
				{
					DWORD *pD = NULL;
					BYTE  *pbS = (BYTE *)pParms->pSrc->Buffer()+
								pParms->pSrc->Stride()*pParms->prclSrc->top;
					for(int y=pParms->prclSrc->top; y<pParms->prclSrc->bottom; ++y)
					{
						pD =(DWORD *)(pHWTempHeap->Address() +pParms->pSrc->Width()*4*y);
						for(int x=pParms->prclSrc->left; x<pParms->prclSrc->right; ++x)
						{
							pD[x]=pbS[x*3]|pbS[x*3+1]<<8|pbS[x*3+2]<<16;
						}
						pbS+=pParms->pSrc->Stride();
					}
					SAddress=(pHWTempHeap->Address()-0x60000000);

				}else if(0) //pParms->pSrc->Format() == 3)
				{
					if(((pParms->prclDst->right-pParms->prclDst->left)==pParms->pSrc->Width()))
					{
						BYTE *pD = NULL;
						BYTE *pdwS = (BYTE *)pParms->pSrc->Buffer()+pParms->pSrc->Stride()*pParms->prclSrc->top;
						for(int y=pParms->prclSrc->top; y<pParms->prclSrc->bottom; ++y)
						{

							RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ]|%d %d %d %d, %d %d %d %d %d, %d,  \r\n"), 
								pParms->prclDst->left, pParms->prclDst->top, pParms->prclDst->right, pParms->prclDst->bottom, 
								pParms->prclSrc->left, pParms->prclSrc->top, pParms->prclSrc->right, pParms->prclSrc->bottom, 
								pParms->pSrc->Format(),pParms->pSrc->Width()));

							pD =(BYTE *)(pHWTempHeap->Address() +pParms->pSrc->Width()*1*y);
							memmove(pD,pdwS,(pParms->prclSrc->right - pParms->prclSrc->left)*sizeof(BYTE));
							pdwS+=pParms->pSrc->Stride()/sizeof(BYTE);

						}
						SAddress=(pHWTempHeap->Address()-0x60000000);
					}
					else
					{
						RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ]Not support src Format Type\n")));
						return sRet;
					}
				}
				else
				{

					RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ]Not support src Format Type\n")));
					return sRet;
				}
						
			}
		}

		sRet = ::GraphicEngine(
			DAddress, 
			pParms->pDst->Width(), 
			pParms->pDst->Height(), 
			pParms->prclDst->left, 
			pParms->prclDst->top, 
			pParms->prclDst->right-pParms->prclDst->left, 
			pParms->prclDst->bottom-pParms->prclDst->top, 
			DFormat, 
			SAddress, 
			pParms->pSrc->Width(), 
			pParms->pSrc->Height(), 
			pParms->prclSrc->left, 
			pParms->prclSrc->top, 
			pParms->prclSrc->right-pParms->prclSrc->left, 
			pParms->prclSrc->bottom-pParms->prclSrc->top, 
			SFormat,
			pParms->solidColor,
			pParms->rop4);
	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ]|%d %d %d %d, %d, %x #\r\n"), pParms->prclDst->left, pParms->prclDst->top, pParms->prclDst->right, pParms->prclDst->bottom,pParms->pDst->Width(),pParms->rop4));
		sRet =::GraphicEngine(
			DAddress, 
			pParms->pDst->Width(), 
			pParms->pDst->Height(), 
			pParms->prclDst->left, 
			pParms->prclDst->top, 
			pParms->prclDst->right-pParms->prclDst->left, 
			pParms->prclDst->bottom-pParms->prclDst->top, 
			DFormat, 0, 0, 0, 0, 0, 0, 0, 0,pParms->solidColor,pParms->rop4);
	}

	return sRet;
}
#endif
SCODE
TCCDISP::BltPrepare(GPEBltParms *pParms)
{
	RECTL rectl;
	int   iSwapTmp;
	BOOL  bRotate = FALSE;
	static bool bIsG2DReady = false;


	DEBUGMSG (GPE_ZONE_INIT, (TEXT("TCCDISP::BltPrepare\r\n")));


	// default to base EmulatedBlt routine
	pParms->pBlt = &GPE::EmulatedBlt;		// catch all

	// see if we need to deal with cursor


	// check for destination overlap with cursor and turn off cursor if overlaps
	if (pParms->pDst == m_pPrimarySurface)    // only care if dest is main display surface
	{
		if (m_CursorVisible && !m_CursorDisabled)
		{
			if (pParms->prclDst != NULL)        // make sure there is a valid prclDst
			{
				rectl = *pParms->prclDst;        // if so, use it

				// There is no guarantee of a well ordered rect in blitParamters
				// due to flipping and mirroring.
				if(rectl.top > rectl.bottom)
				{
					iSwapTmp     = rectl.top;
					rectl.top    = rectl.bottom;
					rectl.bottom = iSwapTmp;
				}

				if(rectl.left > rectl.right)
				{
					iSwapTmp    = rectl.left;
					rectl.left  = rectl.right;
					rectl.right = iSwapTmp;
				}
			}
			else
			{
				rectl = m_CursorRect;                    // if not, use the Cursor rect - this forces the cursor to be turned off in this case
			}

			if (m_CursorRect.top <= rectl.bottom && m_CursorRect.bottom >= rectl.top &&
				m_CursorRect.left <= rectl.right && m_CursorRect.right >= rectl.left)
			{
				CursorOff();
				m_CursorForcedOff = TRUE;
			}
		}

		if (m_iRotate )	// if screen (destination primary surface) is rotated.
		{
			bRotate = TRUE;
		}
	}

	// check for source overlap with cursor and turn off cursor if overlaps
	if (pParms->pSrc == m_pPrimarySurface)    // only care if source is main display surface
	{
		if (m_CursorVisible && !m_CursorDisabled)
		{
			if (pParms->prclSrc != NULL)        // make sure there is a valid prclSrc
			{
				rectl = *pParms->prclSrc;        // if so, use it
			}
			else
			{
				rectl = m_CursorRect;                    // if not, use the CUrsor rect - this forces the cursor to be turned off in this case
			}

			if (m_CursorRect.top < rectl.bottom && m_CursorRect.bottom > rectl.top &&
				m_CursorRect.left < rectl.right && m_CursorRect.right > rectl.left)
			{
				CursorOff();
				m_CursorForcedOff = TRUE;
			}
		}

		if (m_iRotate) //if screen(source primary surface) is rotated
		{
			bRotate = TRUE;
		}
	}

	if (bRotate)	// if source or destination surface is rotated.
	{
		if((S_OK != TCC_EmulRotate32(pParms))||(pParms->pSrc->IsRotate()))
			pParms->pBlt = &GPE::EmulatedBltRotate;

	}
#ifdef _USING_HW_ACCELERATE_
	else if(pParms->pDst->InVideoMemory() )
	{
		RETAILMSG(0, (TEXT("[%X]\r\n"),pParms->rop4));
		 switch (pParms->rop4)
		 {
		 case 0x3333:    // NOTSRCCPY
		 case 0xCCCC:    // SRCCOPY
		 //case 0x6666:    // SRCINVERT
		 //case 0x8888:    // SRCAND
		 //case 0xEEEE:    // SRCPAINT
			 if (pParms->pLookup ) //|| pParms->pConvert)
			 {
				 RETAILMSG(0,
					 (TEXT("-Color conversion not supported\r\n")));
				 break;
			 }
			 if (pParms->bltFlags & (BLT_STRETCH | BLT_ALPHABLEND))
			 {
				 RETAILMSG(0,
					 (TEXT("-Stretch and AlphaBlend BLT flags NOT supported\r\n")));
				 break;
			 }
			 if ( 
				 (pParms->pDst!=pParms->pSrc) && 
				 (0==pParms->bltFlags) && 
				 (pParms->pSrc->InVideoMemory() ||
				 //(6==pParms->pSrc->Format() ||
				 (5==pParms->pSrc->Format())
				 )&&
				 ((pGraphicEngine->FCH[2].SADDR0 >>8) == 0xFF) && //user flag for sharing with JPEG Decoder
				 (abs(pParms->prclDst->right - pParms->prclDst->left) >= 400)
				 )
			{
				 pGraphicEngine->FCH[2].SADDR0 = 0x7F00; //user flag set
				 pParms->pBlt = (SCODE (GPE::*)(struct GPEBltParms *))&TCCDISP::TCCGraphicEngineBlt;
			 }
			 break;

			case 0xF0F0AA:	 // FILL
				if(abs(pParms->prclDst->right - pParms->prclDst->left) >= 400)
					pParms->pBlt = (SCODE (GPE::*)(struct GPEBltParms *))&TCCDISP::TCCGraphicEngineBlt;

				 break;
		 }
		
	}
#endif
	else
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ]$%d %d %d %d %d[%x][%x], %d %d %d %d, %d[%x]+[%x][%x][%x]\r\n"), pParms->prclDst->left, pParms->prclDst->top, pParms->prclDst->right, pParms->prclDst->bottom, pParms->pDst->Format(),pParms->pDst->Buffer(),pParms->pSrc->Buffer(), pParms->prclSrc->left, pParms->prclSrc->top, pParms->prclSrc->right, pParms->prclSrc->bottom, pParms->pSrc->Format(),pParms->rop4,pParms->solidColor,pParms->pConvert));

	if(pParms->pBlt == &GPE::EmulatedBlt)
	{
		EmulatedBltSelect02(pParms);
		EmulatedBltSelect08(pParms);
		if(g_dwBPPOption)
			TCC_Emulated32(pParms);
		else
			TCC_Emulated16(pParms);
		//EmulatedBltSelect16(pParms);
		//TCC_Emulated16(pParms);
	}

	return S_OK;
}



// This function would be used to undo the setting of clip registers etc
SCODE
TCCDISP::BltComplete(GPEBltParms *pBltParms)
{
	DEBUGMSG (GPE_ZONE_BLT_HI, (TEXT("++TCCDISP::BltComplete\r\n")));


	// see if cursor was forced off because of overlap with source or destination and turn back on
	if (m_CursorForcedOff)
	{
		m_CursorForcedOff = FALSE;
		CursorOn();
	}


	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("--TCCDISP::BltComplete\r\n")));
	return S_OK;
}

