/****************************************************************************
*   FileName    : line.cpp
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#include "precomp.h"
#include <dispperf.h>

#define SIMPLE_LINEACCEL

SCODE TCCDISP::WrappedEmulatedLine(GPELineParms *pLineParms)
{
	SCODE retval;
	RECT  bounds;
	int   N_plus_1;                // Minor length of bounding rect + 1

	DEBUGMSG(GPE_ZONE_LINE, (TEXT("++TCCDISP::WrappedEmulatedLine[%d]\r\n"),pLineParms->iDir));
	// calculate the bounding-rect to determine overlap with cursor
	if (pLineParms->dN)            // The line has a diagonal component (we'll refresh the bounding rect)
	{
		N_plus_1 = 2 + ((pLineParms->cPels * pLineParms->dN) / pLineParms->dM);
	}
	else
	{
		N_plus_1 = 1;
	}

	switch(pLineParms->iDir)
	{
	case 0:
		bounds.left = pLineParms->xStart;
		bounds.top = pLineParms->yStart;
		bounds.right = pLineParms->xStart + pLineParms->cPels + 1;
		bounds.bottom = bounds.top + N_plus_1;
		break;

	case 1:
		bounds.left = pLineParms->xStart;
		bounds.top = pLineParms->yStart;
		bounds.bottom = pLineParms->yStart + pLineParms->cPels + 1;
		bounds.right = bounds.left + N_plus_1;
		break;

	case 2:
		bounds.right = pLineParms->xStart + 1;
		bounds.top = pLineParms->yStart;
		bounds.bottom = pLineParms->yStart + pLineParms->cPels + 1;
		bounds.left = bounds.right - N_plus_1;
		break;

	case 3:
		bounds.right = pLineParms->xStart + 1;
		bounds.top = pLineParms->yStart;
		bounds.left = pLineParms->xStart - pLineParms->cPels;
		bounds.bottom = bounds.top + N_plus_1;
		break;

	case 4:
		bounds.right = pLineParms->xStart + 1;
		bounds.bottom = pLineParms->yStart + 1;
		bounds.left = pLineParms->xStart - pLineParms->cPels;
		bounds.top = bounds.bottom - N_plus_1;
		break;

	case 5:
		bounds.right = pLineParms->xStart + 1;
		bounds.bottom = pLineParms->yStart + 1;
		bounds.top = pLineParms->yStart - pLineParms->cPels;
		bounds.left = bounds.right - N_plus_1;
		break;

	case 6:
		bounds.left = pLineParms->xStart;
		bounds.bottom = pLineParms->yStart + 1;
		bounds.top = pLineParms->yStart - pLineParms->cPels;
		bounds.right = bounds.left + N_plus_1;
		break;

	case 7:
		bounds.left = pLineParms->xStart;
		bounds.bottom = pLineParms->yStart + 1;
		bounds.right = pLineParms->xStart + pLineParms->cPels + 1;
		bounds.top = bounds.bottom - N_plus_1;
		break;

	default:
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPDRV:ERR] WrappedEmulatedLine() : Invalid Direction %d\n\r"), pLineParms->iDir));
		return E_INVALIDARG;
	}
	// check for line overlap with cursor and turn off cursor if overlaps
	if (m_CursorVisible && !m_CursorDisabled)
	{
		RotateRectl(&m_CursorRect);
		if (m_CursorRect.top < bounds.bottom && m_CursorRect.bottom > bounds.top &&
			m_CursorRect.left < bounds.right && m_CursorRect.right > bounds.left)
		{
			RotateRectlBack(&m_CursorRect);
			CursorOff();
			m_CursorForcedOff = TRUE;
		}
		else
			RotateRectlBack(&m_CursorRect);
	}


	// do emulated line
		retval = EmulatedLine (pLineParms);


	// se if cursor was forced off because of overlap with line bouneds and turn back on
		if (m_CursorForcedOff)
	{
		m_CursorForcedOff = FALSE;
		CursorOn();
	}

	DEBUGMSG(GPE_ZONE_LINE, (TEXT("--TCCDISP::WrappedEmulatedLine\r\n")));

	return retval;
}


SCODE
TCCDISP::Line(GPELineParms *pLineParms, EGPEPhase phase)
{
	DEBUGMSG (GPE_ZONE_INIT, (TEXT("++TCCDISP::Line\r\n")));

	if (phase == gpeSingle || phase == gpePrepare)
	{
#ifdef DO_DISPPERF
		DispPerfStart(ROP_LINE);
#endif
		if ((pLineParms->pDst != m_pPrimarySurface))
		{
			pLineParms->pLine = &GPE::EmulatedLine;
		}
		else
		{
				pLineParms->pLine = (SCODE (GPE::*)(struct GPELineParms *))&TCCDISP::WrappedEmulatedLine;
		}
	}
	else if (phase == gpeComplete)
	{
#ifdef DO_DISPPERF
		DispPerfEnd(0);
#endif

	}
	DEBUGMSG(GPE_ZONE_INIT, (TEXT("--TCCDISP::Line\r\n")));

	return S_OK;
}
