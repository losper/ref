/****************************************************************************
 *   FileName    : TCC_emul.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
SCODE	TCC_Emulated16 (GPEBltParms * );
SCODE	TCC_Emulated24 (GPEBltParms * );
SCODE	TCC_Emulated32 (GPEBltParms * );
SCODE   TCC_EmulRotate16 (GPEBltParms * );
SCODE   TCC_EmulRotate32 (GPEBltParms * );


