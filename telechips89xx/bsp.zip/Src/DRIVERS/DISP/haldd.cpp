/****************************************************************************
*   FileName    : haldd.cpp
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#include "precomp.h"

//---------------------
// DDHAL_DDCALLBACKS
//---------------------

DWORD
WINAPI
HalGetDriverInfo(LPDDHAL_GETDRIVERINFODATA lpgdid)
{
	/*
	typedef struct _DDHAL_GETDRIVERINFODATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		DWORD dwSize;
		DWORD dwFlags;
		GUID guidInfo;
		DWORD dwExpectedSize;
		LPVOID lpvData;
		DWORD dwActualSize;
		HRESULT ddRVal;
	} DDHAL_GETDRIVERINFODATA;
	*/


	lpgdid->ddRVal = DDERR_CURRENTLYNOTAVAIL;
	return DDHAL_DRIVER_HANDLED;

}

DWORD WINAPI HalWaitForVerticalBlank(LPDDHAL_WAITFORVERTICALBLANKDATA lpwfvbd)
{
	DEBUGENTER( HalWaitForVerticalBlank );
	/*
	typedef struct _DDHAL_WAITFORVERTICALBLANKDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		DWORD dwFlags;
		DWORD bIsInVB;
		HRESULT ddRVal;
	} DDHAL_WAITFORVERTICALBLANKDATA;
	*/

	TCCDISP *pDDGPE = (TCCDISP *)GetDDGPE();

	if (lpwfvbd->dwFlags & DDWAITVB_BLOCKBEGIN)			// Returns when the vertical blank interval begins.
	{
		lpwfvbd->bIsInVB = pDDGPE->WaitForVerticalBlank(VB_FRONTPORCH);
	}
	else if (lpwfvbd->dwFlags & DDWAITVB_BLOCKEND)		// Returns when the vertical blank interval ends and display begins.
	{
		lpwfvbd->bIsInVB = pDDGPE->WaitForVerticalBlank(VB_BACKPORCH);
	}
	else if (lpwfvbd->dwFlags & DDWAITVB_I_TESTVB)		// Sets the flag to query if a vertical blank is in progress.
	{
		lpwfvbd->bIsInVB = pDDGPE->InVBlank();
	}
	else
	{
		// DDWAITVB_BLOCKBEGINEVENT:	// This flag is not currently supported. (Sets up an event to trigger when the vertical blank begins.)
	}

	lpwfvbd->ddRVal = DD_OK;

	DEBUGLEAVE( HalWaitForVerticalBlank );

	return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalGetScanLine(LPDDHAL_GETSCANLINEDATA lpgsld)
{
	//DEBUGENTER( HalGetScanLine );
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL] ++HalGetScanLine()\n\r")));

	/*
	typedef struct _DDHAL_GETSCANLINEDATA
	{
		LPDDRAWI_DIRECTDRAW_GBL lpDD;
		DWORD dwScanLine;
		HRESULT ddRVal;
	} DDHAL_GETSCANLINEDATA;
	*/

	TCCDISP *pDDGPE = (TCCDISP *)GetDDGPE();

	lpgsld->dwScanLine = pDDGPE->GetScanLine();
	lpgsld->ddRVal = DD_OK;

	//DEBUGLEAVE( HalGetScanLine );
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DDHAL] --HalGetScanLine()\n\r")));

	return DDHAL_DRIVER_HANDLED;
}

