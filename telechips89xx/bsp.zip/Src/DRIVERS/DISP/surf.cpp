/****************************************************************************
*   FileName    : surf.cpp
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#include "precomp.h"

#define ALIGN(x, align)		(((x) + ((align) - 1)) & ~((align) - 1))
#define PIXEL_ALIGN_BPP16	2
#define PIXEL_ALIGN_YV12	16

static DWORD dwSurfaceCount = 0;

//  This method is called for all normal surface allocations from ddgpe and gpe
SCODE
TCCDISP::AllocSurface(
						GPESurf **ppSurf,
						int width,
						int height,
						EGPEFormat format,
						int surfaceFlags)
{
	
	unsigned int bpp;
	unsigned int stride;
	unsigned int align_width;
	
	bpp = EGPEFormatToBpp[format];
	align_width = width;

	// stride are all 32bit aligned for Video Memory
	stride = ((bpp * align_width + 31) >> 5) << 2;

	if ((surfaceFlags & GPE_REQUIRE_VIDEO_MEMORY)
		|| (surfaceFlags & GPE_BACK_BUFFER)
		|| (surfaceFlags & GPE_PREFER_VIDEO_MEMORY) && (format == m_pMode->format) && (width >= 200)&& (height>=120))
	{
		SCODE rv = AllocSurfaceVideo((DDGPESurf**)ppSurf, width, height, stride, format, ddgpePixelFormat_565);
		if (rv == S_OK)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] AllocSurface() : AllocSurfaceVideo() success[%d]x[%d]x[%d]\n\r"),width, height, stride));
			return S_OK;
		}
		else
		{
			if (surfaceFlags & (GPE_REQUIRE_VIDEO_MEMORY|GPE_BACK_BUFFER))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] AllocSurface() : AllocSurfaceVideo() failed\n\r")));
				return E_OUTOFMEMORY;
			}
		}
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] AllocSurface() : Can not allocate VIDEO_MEMORY Surface in Heap\n\r")));

	}
	// This method is only for surface in system memory
	if (surfaceFlags & GPE_REQUIRE_VIDEO_MEMORY)
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] AllocSurface() : Can not allocate GPE_REQUIRE_VIDEO_MEMORY Surface in system memory\n\r")));
		return E_OUTOFMEMORY;
	}

	// Allocate surface from system memory
	*ppSurf = new GPESurf(width, height, format);

	if (*ppSurf != NULL)
	{
		if (((*ppSurf)->Buffer()) == NULL)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] AllocSurface() : Surface Buffer is NULL\n\r")));
			delete *ppSurf;
			return E_OUTOFMEMORY;
		}
		else
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(_T("[DISPLAY     ] AllocSurface() : GPESurf() Allocated in System Memory [%d]x[%d]\n\r"),width, height));			
			return S_OK;
		}
	}

	RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] AllocSurface() : Surface allocate Failed\n\r")));
	return E_OUTOFMEMORY;
}


//  This method is used for DirectDraw enabled surfaces
SCODE
TCCDISP::AllocSurface(
						DDGPESurf **ppSurf,
						int width,
						int height,
						EGPEFormat format,
						EDDGPEPixelFormat pixelFormat,
						int surfaceFlags)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] TCCDISP::AllocSurface(%d, %d, %d, %d, 0x%08x)\n\r"), width, height, format, pixelFormat, surfaceFlags));

	unsigned int bpp;
	unsigned int stride;
	unsigned int align_width;

	if (pixelFormat == ddgpePixelFormat_I420 || pixelFormat == ddgpePixelFormat_YV12)
	{
		// in this case, stride can't be calculated. because of planar format (non-interleaved...)
		bpp = 12;
		align_width = ALIGN(width, 16);
	}
	else if (pixelFormat == ddgpePixelFormat_YVYU || pixelFormat == ddgpePixelFormat_VYUY)
	{
		bpp = 16;
		align_width = width;
	}
	else
	{
		bpp = EGPEFormatToBpp[format];
		align_width = width;
	}

	// stride are all 32bit aligned for Video Memory
	stride = ((bpp * align_width + 31) >> 5) << 2;

	if ((surfaceFlags & GPE_REQUIRE_VIDEO_MEMORY)
		|| (surfaceFlags & GPE_BACK_BUFFER)
		|| (surfaceFlags & GPE_PREFER_VIDEO_MEMORY) && (format == m_pMode->format))
	{
		SCODE rv = AllocSurfaceVideo(ppSurf, width, height, stride, format, pixelFormat);
		if (rv == S_OK)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] AllocSurface() : AllocSurfaceVideo() success[%d]x[%d]x[%d]\n\r"),width, height, stride));
			return S_OK;
		}
		else
		{
			if (surfaceFlags & (GPE_REQUIRE_VIDEO_MEMORY|GPE_BACK_BUFFER))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] AllocSurface() : AllocSurfaceVideo() failed\n\r")));
				return E_OUTOFMEMORY;
			}
		}
	}

	// stride and surface size for system memory surfaces
	stride = ((bpp * width + 31) >> 5) << 2;
	unsigned int surface_size = stride*height;

	// Allocate from system memory
	*ppSurf = new DDGPESurf(width, height, stride, format, pixelFormat);

	if (*ppSurf)	// check we allocated bits succesfully
	{
		if (!((*ppSurf)->Buffer()))
		{
			delete *ppSurf;
			return E_OUTOFMEMORY;
		}
		else
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[DISPLAY     ] AllocSurface() : System  AllocSurface() success [%d]x[%d]x[%d]\n\r"),width, height, stride));
	}

	return S_OK;
}


SCODE
TCCDISP::AllocSurfaceVideo(
						DDGPESurf **ppSurf,
						int width,
						int height,
						int stride,
						EGPEFormat format,
						EDDGPEPixelFormat pixelFormat)
{
	// align frame buffer size with 4-word unit
	DWORD dwSize = ALIGN(stride * height, 16);

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] dwSize:%d\n"),dwSize));
	// Try to allocate surface from video memory
	SurfaceHeap *pHeap = m_pVideoMemoryHeap->Alloc(dwSize);
	
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] pHeap->Address():%x\n"),pHeap->Address()));
	if (pHeap != NULL)
	{
		DWORD dwVideoMemoryOffset = pHeap->Address() - (DWORD)m_VideoMemoryVirtualBase;
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] AllocSurface() : Allocated PA = 0x%08x\n\r"), dwVideoMemoryOffset+m_VideoMemoryPhysicalBase));
		*ppSurf = new TCCDISPSurf(width, height, dwVideoMemoryOffset, (PVOID)pHeap->Address(), stride, format, pixelFormat, pHeap);
		if (*ppSurf  == NULL)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] AllocSurface() : Create TCCDISPSurf() Failed\n\r")));

			pHeap->Free();

			return E_OUTOFMEMORY;
		}

		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] AllocSurface() : TCCDISPSurf() Allocated in Video Memory\n\r")));

		return S_OK;
	}
	else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("[DISPLAY     ] AllocSurfaceVideo() : SurfaceHeap Alloc() Failed\n\r")));

		*ppSurf = (DDGPESurf *)NULL;

		return E_OUTOFMEMORY;
	}
}


//-----------------------------------------------------------------------------

TCCDISPSurf::TCCDISPSurf(int width, int height, DWORD offset, VOID *pBits, int stride,
			EGPEFormat format, EDDGPEPixelFormat pixelFormat, SurfaceHeap *pHeap)
			: DDGPESurf(width, height, pBits, stride, format, pixelFormat)
{
	dwSurfaceCount++;

	m_fInVideoMemory = TRUE;
	m_nOffsetInVideoMemory = offset;
	m_pSurfHeap = pHeap;

	if (pixelFormat == ddgpePixelFormat_I420)
	{
		m_uiOffsetCb = width*height;
		m_uiOffsetCr = m_uiOffsetCb+width*height/4;
	}
	else if (pixelFormat == ddgpePixelFormat_YV12)
	{
		m_uiOffsetCr = width*height;
		m_uiOffsetCb = m_uiOffsetCr+width*height/4;
	}
	else
	{
		m_uiOffsetCr = 0;
		m_uiOffsetCb = 0;
	}

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] TCCDISPSurf::TCCDISPSurf() : @ 0x%08x, %d\n\r"), m_nOffsetInVideoMemory, dwSurfaceCount));
}


TCCDISPSurf::~TCCDISPSurf()
{
	dwSurfaceCount--;

	m_pSurfHeap->Free();

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[DISPLAY     ] TCCDISPSurf::~TCCDISPSurf() : @ 0x%08x, %d\n\r"), m_nOffsetInVideoMemory, dwSurfaceCount));
}

