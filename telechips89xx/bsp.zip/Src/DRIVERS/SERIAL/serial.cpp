//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

Abstract:

    Serial PDD for SamSang TCC Development Board.

Notes: 
--*/
#include <windows.h>
#include <types.h>
#include <ceddk.h>

#include <ddkreg.h>
#include <serhw.h>
#include <Serdbg.h>


#include <bsp.h>
#include "pddserial.h"

static int g_loglevel = 0;

class CPddxxxSerial : public CPddUart {
public:
    CPddxxxSerial(DWORD deviceindex, LPTSTR lpActivePath, PVOID pMdd, PHWOBJ pHwObj)
        : CPddUart(lpActivePath, pMdd, pHwObj)
        {
			m_fIsDSRSet = FALSE;
			{
				TCHAR			sKeyName[64];
				ULONG           datasize = sizeof(ULONG);
				HKEY            hKey;
				ULONG           kreserved = 0, kvaluetype;
				
				//read Register Value
				wsprintf((unsigned short *)sKeyName,L"Drivers\\BuiltIn\\Serial%d",deviceindex+1);
				if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, sKeyName, 0, 0, &hKey))
					RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]FAIL UART Init")));
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]Load Key Base %s \n"),sKeyName));

				m_ComNumber = deviceindex+1;

				datasize = sizeof(DWORD);
				if ( ::RegQueryValueEx(hKey, 
					L"COM_ChNum", 
					NULL, 
					&kvaluetype,
					(LPBYTE)&(m_ComChannel), 
					&datasize
					) ) {
					m_ComChannel = 0;
					RETAILMSG (1,(TEXT("Failed to get m_ComChannel value, defaulting to %d\r\n"), m_ComChannel));
				}
				
				datasize = sizeof(DWORD);
				if ( ::RegQueryValueEx(hKey, 
					L"COM_PortNum", 
					NULL, 
					&kvaluetype,
					(LPBYTE)&(m_ComPort) , 
					&datasize) ) {
					m_ComPort = 0;
					RETAILMSG (1, (TEXT("Failed to get m_ComPort value, defaulting to %d\r\n"), m_ComPort));
				}

				datasize = sizeof(DWORD);
				if ( ::RegQueryValueEx(hKey, 
					L"USEDMATX", 
					NULL, 
					&kvaluetype,
					(LPBYTE)&(bUsingDMA) , 
					&datasize) ) {
					bUsingDMA = 0;
					RETAILMSG (1, (TEXT("Failed to get USEDMATX value, defaulting to %d\r\n"), bUsingDMA));
				}
				if ( ::RegQueryValueEx(hKey, 
					L"USEDMARX", 
					NULL, 
					&kvaluetype,
					(LPBYTE)&(RXIntrusing) , 
					&datasize) ) {
					RXIntrusing = 0;
					RETAILMSG (1, (TEXT("Failed to get USEDMARX value, defaulting to %d\r\n"), RXIntrusing));
				}
			
				RETAILMSG (TC_LOG_LEVEL(TC_DEBUG), (TEXT("[SERIAL      ]-----INFO-----\r\n")));
				RETAILMSG (TC_LOG_LEVEL(TC_LOG), (TEXT("[SERIAL      ]COM%d\r\n[SERIAL      ]channel%d port%d\r\n[SERIAL      ]TXDMA%d RXDMA%d\r\n"),m_ComNumber,m_ComChannel,m_ComPort,bUsingDMA,RXIntrusing ));
				RETAILMSG (TC_LOG_LEVEL(TC_DEBUG), (TEXT("[SERIAL      ]--------------\r\n")));
					
					
				


				RegCloseKey (hKey);			
				
				CPddUart::SetDefaultChannel(m_ComChannel);
			}
				    }
 
	~CPddxxxSerial() {
			
		}
 
	virtual BOOL Init() {
        ULONG               inIoSpace = 0;

		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[SERIAL      ]+ COM%d init\r\n"),m_ComNumber)); 
        
		  
		return CPddUart::Init(m_ComNumber);
    };

    virtual void    SetDefaultConfiguration() {
    	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[SERIAL      ]INFO: COM%d SetDefaultConfiguration\n"),m_ComNumber)); 

		CPddUart::SetDefaultConfiguration();
    }

    virtual BOOL    InitModem(BOOL bInit) {
        SetDTR(bInit);
        return CPddUart::InitModem(bInit);
    }
 
	virtual ULONG   GetModemStatus() {

        return (CPddUart::GetModemStatus() | MS_CTS_ON);
    }

    virtual void    SetDTR(BOOL bSet) {
    };
private:
   
    volatile ULONG *    m_pDTRPort;
    DWORD               m_dwDTRPortNum;
    volatile ULONG *    m_pDSRPort;
    DWORD               m_dwDSRPortNum;
    BOOL                m_fIsDSRSet;

};

CSerialPDD * CreateSerialObject(LPTSTR lpActivePath, PVOID pMdd,PHWOBJ pHwObj, DWORD DeviceArrayIndex)
{
    CSerialPDD * pSerialPDD = NULL;
    
   
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("Serial %d Init Start \n"),DeviceArrayIndex+1));
    pSerialPDD = new CPddxxxSerial(DeviceArrayIndex,lpActivePath, pMdd, pHwObj);
      
    
    if (pSerialPDD && !pSerialPDD->Init()) {
        delete pSerialPDD;
        pSerialPDD = NULL;
    }    
    return pSerialPDD;
}
void DeleteSerialObject(CSerialPDD * pSerialPDD)
{
    if (pSerialPDD)
        delete pSerialPDD;
}

