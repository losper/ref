//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

Abstract:

    Platform dependent Serial definitions for 16550  controller.

Notes: 
--*/
#ifndef __PDDTCCxxx_SER_H_
#define __PDDTCCxxx_SER_H_

#include <bsp.h>
#include <cserpdd.h>
#include <cmthread.h>
#include <serpriv.h>

//UART const
#define SERTCC_FIFO_DEPTH_TX	16
#define SERTCC_FIFO_DEPTH_RX	16
// UER State Error Bit.
#define UERSTATE_BREAK_DETECT	0x10
#define UERSTATE_FRAME_ERROR	0x08
#define UERSTATE_PARITY_ERROR	0x04
#define UERSTATE_OVERRUN_ERROR	0x02

/////////////////////////////////////////////////////////////////////////////////////////
// Required Registry Setting.
#define PC_REG_UART_INTBIT_VAL_NAME TEXT("InterruptBitsShift")
#define PC_REG_UART_INTBIT_VAL_LEN sizeof(DWORD)
#define PC_REG_UART_IST_TIMEOUTS_VAL_NAME TEXT("ISTTimeouts")
#define PC_REG_UART_IST_TIMEOUTS_VAL_LEN sizeof(DWORD)



////////////////////////////////////////////////////////////////////////////////////////
// WaterMarker Pairs.
typedef struct  __PAIRS {
    ULONG   Key;
    ULONG   AssociatedValue;
} PAIRS, *PPAIRS;


 class CRegUart {
public:
    CRegUart(PULONG pRegAddr);
    virtual ~CRegUart() { ; };
    virtual BOOL    Init() ;
    // We do not virtual Read & Write data because of Performance Concern.
    ULONG   Read_RBR() { return m_pReg->REG1.RBR; } ;
    void    Write_THR(ULONG uData) { m_pReg->REG1.THR = uData; };
    void    Write_DLL(ULONG uData) { m_pReg->REG1.DLL= uData; };
    ULONG   Read_DLL() { return  m_pReg->REG1.DLL; } ;
    void    Write_IER (ULONG uData) { m_pReg->REG2.IER = uData;};
    ULONG   Read_IER() { return  m_pReg->REG2.IER; };
    void    Write_DLM (ULONG uData) { m_pReg->REG2.DLM= uData; };
    ULONG   Read_DLM() { return  m_pReg->REG2.DLM; };
    ULONG   Read_IIR() { return  m_pReg->REG3.IIR;};
    void    Write_FCR(ULONG uData) { m_pReg->REG3.FCR = uData;};
	ULONG   Read_FCR() { return  m_pReg->REG3.FCR;};
    void    Write_LCR(ULONG uData) { m_pReg->LCR = uData;};
    ULONG   Read_LCR() { return  m_pReg->LCR;};
    void    Write_MCR(ULONG uData) {  m_pReg->MCR = uData;};
    ULONG   Read_MCR() { return m_pReg->MCR;};
    ULONG   Read_LSR() { return m_pReg->LSR;};
    ULONG   Read_MSR() { return  m_pReg->MSR;};
    void    Write_SCR(ULONG uData) {  m_pReg->SCR = uData;};
    ULONG   Read_SCR() { return m_pReg->SCR; };
	void    Write_AFT(ULONG uData) { m_pReg->AFT = uData ;};
    ULONG   Read_AFT() { return m_pReg->AFT; };
	void    Write_UCR(ULONG uData) { m_pReg->UCR = uData ;};
    ULONG   Read_UCR() { return m_pReg->UCR; };

    virtual BOOL    Write_BaudRate(ULONG uData);
    PULONG  GetRegisterVirtualAddr() { return (PULONG)m_pReg; };
    virtual void    Backup();
    virtual void    Restore();
#ifdef DEBUG
    virtual void    DumpRegister();
#endif

protected:
    volatile PUART const  m_pReg;
    BOOL    m_fIsBackedUp;
private:

    ULONG    m_DLLBackup;
    ULONG    m_IERBackup;
    ULONG    m_DLMBackup;
    ULONG    m_LCRBackup;
    ULONG    m_MCRBackup;
    ULONG    m_SCRBackup;
	ULONG	 m_FCRBackup;
	ULONG	 m_MSRBackup;
	ULONG	 m_AFTBackup;
	ULONG	 m_UCRBackup;
    ULONG    m_BaudRate;

 public:
	ULONG    m_nChannel;
	ULONG    m_nPort;
	int		 m_Opened;
};

class CPddUart: public CSerialPDD, public CMiniThread  {
public:
    CPddUart (LPTSTR lpActivePath, PVOID pMdd, PHWOBJ pHwObj);
    virtual ~CPddUart();
    virtual BOOL Init(DWORD);
    virtual void PostInit();
    virtual BOOL MapHardware();
    virtual BOOL CreateHardwareAccess();
	void	SetDefaultChannel(DWORD channel);
//  Power Manager Required Function.
    virtual void    SerialRegisterBackup() { m_pRegUart->Backup(); };
    virtual void    SerialRegisterRestore() { m_pRegUart->Restore(); };

// Implement CPddSerial Function.
// Interrupt
    virtual BOOL    InitialEnableInterrupt(BOOL bEnable ) ; // Enable All the interrupt may include Xmit Interrupt.
private:
    virtual DWORD ThreadRun();   // IST
//  Tx Function.
public:
    virtual BOOL    InitXmit(BOOL bInit);
    virtual void    XmitInterruptHandler(PUCHAR pTxBuffer, ULONG *pBuffLen);
    virtual void    XmitComChar(UCHAR ComChar);
    virtual BOOL    EnableXmitInterrupt(BOOL bEnable);
    virtual BOOL    CancelXmit();
    virtual DWORD   GetWriteableSize();
protected:
    BOOL    m_XmitFifoEnable;
    HANDLE  m_XmitFlushDone;
	BOOL	m_XmitInterruptStatus;

//
//  Rx Function.
public:
    virtual BOOL    InitReceive(BOOL bInit);
    virtual ULONG   ReceiveInterruptHandler(PUCHAR pRxBuffer,ULONG *pBufflen);
    virtual ULONG   CancelReceive();
    virtual DWORD   GetWaterMark();
    virtual BYTE    GetWaterMarkBit();
protected:
    BOOL    m_bReceivedCanceled;
    DWORD   m_dwWaterMark;
//
//  Modem
public:
    virtual BOOL    InitModem(BOOL bInit);
    virtual void    ModemInterruptHandler() { GetModemStatus();};
    virtual ULONG   GetModemStatus();
    virtual void    SetDTR(BOOL bSet) {;};
    virtual void    SetRTS(BOOL bSet);
//
// Line Function.
    virtual BOOL    InitLine(BOOL bInit) ;
    virtual void    LineInterruptHandler() { GetLineStatus();};
    virtual void    SetBreak(BOOL bSet) ;
    virtual BOOL    SetBaudRate(ULONG BaudRate,BOOL bIrModule) ;
	virtual int 	GetComChannel();
	virtual int 	GetComPort();
	virtual int     SetOpenStatus(int bOpen);
    virtual BOOL    SetByteSize(ULONG ByteSize);
    virtual BOOL    SetParity(ULONG Parity);
    virtual BOOL    SetStopBits(ULONG StopBits);
//
// Line Internal Function
    BYTE            GetLineStatus();
    virtual void    SetOutputMode(BOOL UseIR, BOOL Use9Pin) ;
//
//

protected:
   
    DWORD	m_dwBaudrate;
    DWORD	m_dwIntShift;
public:
    void    DisableInterrupt(DWORD dwInt) { 
        m_pRegUart->Write_IER(m_pRegUart->Read_IER() & (~(dwInt)));
    }
    void    EnableInterrupt(DWORD dwInt) { 
        m_pRegUart->Write_IER(m_pRegUart->Read_IER() | dwInt);
    }
    void    ClearInterrupt(DWORD dwInt) {
        m_pRegUart->Write_LCR(0x17 | (1<<7));
		

	if(RXIntrusing)
		m_pRegUart->Write_FCR(0x07);
	else
		m_pRegUart->Write_FCR(0x17);

        m_pRegUart->Write_LCR(0x17 & (~(1<<7)));
    }
	
    DWORD   GetInterruptStatus() { 
		return (m_pRegUart->Read_IIR());
	};
    DWORD   GetInterruptMask () { 
		return (m_pRegUart->Read_IER() & 0xf);
	};
    
protected:
    CRegistryEdit m_ActiveReg;
//  Interrupt Handler
    DWORD       m_dwSysIntr;
    HANDLE      m_hISTEvent;

    DWORD       m_dwSysIntrDMATx;
	HANDLE      m_DMATxEvent;
	DWORD       m_dwSysIntrDMARx;
	HANDLE      m_DMARxEvent;

//  Optional Parameter
	DWORD m_dwDevIndex;
    DWORD m_dwISTTimeout;
	
	
	
	BOOL  bUsingDMA; // flag DMA TX
	DWORD RXIntrusing; // flag DMA RX


	DWORD m_DmaTxNumber; // GDMA0, GDMA1 ....
	DWORD m_DmaTxChannel;// channel 0 or channel 1 or channel 2  
	DWORD m_DmaRxNumber;
	DWORD m_DmaRxChannel;

	DWORD preTemp; // for using dma repeat mode..
	DWORD m_dma_stAddr;

	DWORD m_ComNumber;
	DWORD m_ComChannel;
	DWORD m_ComPort;
	
	unsigned long* TXBUFFADDR;
	unsigned long* TXBUFFADDR_PHY;
	unsigned long* RXBUFFADDR;
	unsigned long* RXBUFFADDR_PHY;


		
	unsigned long* m_BaseAddress;
	CRegUart *		m_pRegUart;

	unsigned long* m_pRegVirtualAddr;//UART address
	unsigned long* pVirtualDmaAddrTX;//DMA TX address
	unsigned long* pVirtualDmaAddrRX;//DMA RX address
	
	

	//PTV Physical to Virtuasl Mapping 
	BOOL PTV_UART(DWORD nComChannel,unsigned long** vaddr);
	BOOL PTV_PORTMUX(unsigned long** vaddr);
	BOOL PTV_GPIO(unsigned long** vaddr);
	BOOL PTV_DMABUFFER(unsigned long** vaddr);
	BOOL PTV_DMA(int nDmaNum, unsigned long** vaddr);
	
	BOOL SET_DMA_BUFFER(DWORD DmaNum, DWORD DmaCh, BOOL isTX);
	BOOL SET_DMA(DWORD DmaNum, DWORD DmaCh, BOOL isTX);
	
	//installable ISR
	BOOL SetupUartISR(DWORD nComChannel);
	BOOL SetupDmaISR(unsigned long* pdma, DWORD nDmaCh, DWORD sysintr);

	//GIISR handle
	HANDLE m_hUartIsrHandler;	
	HANDLE m_hDMAIsrHandler;

	//Set MDD's rxbuffer address to System rxbuffer
	DWORD GetVirtualRxBuffAddr() {return (DWORD)RXBUFFADDR; };
	BOOL bLowPerfomance;
	//static variable used by UART channels
	unsigned long* pVirtualPortMuxAddr; // portmux
	unsigned long* pVirtualGpioAddr;//GPIO address
	unsigned long* pVirtualDmaBufAddr;//DMA buf address
		
};

#define MAX_BUF_SIZE	GDMA_BUFF_SIZE// defualt 512 -> 256


#endif
