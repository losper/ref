//
// Copyright (c) Telechips Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

  Module Name:  
  
	Abstract:
	
	  Serial PDD for Telechips TCCxxx UART Common Code.
	  
		Notes: 
--*/
#include <windows.h>
#include <types.h>
#include <ceddk.h>

#include <ddkreg.h>
#include <serhw.h>
#include <Serdbg.h>
#include <pddserial.h>

#include <bsp.h>
#include "../LIB/SOC/UART/tcc_serial.h"
#include "tcc_gpio.h"
#include "tcc_ckc.h"



#ifdef _DUMP_
FILE* fpwrite;
#endif

CRegUart::CRegUart(PULONG pRegAddr)
:   m_pReg((PUART)pRegAddr)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("CRegUart::CRegUart\r\n")));
    m_fIsBackedUp = FALSE;
	m_Opened = FALSE;
	
	
}
BOOL CRegUart::Init() 
{
    //RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("+CRegUart::Init m_pReg = 0x%x[%x]\r\n"), (int)m_pReg,HwUART_CHSEL)); 
	
    if (m_pReg) { // Set Value to default.
		Write_LCR(Read_LCR() & (~(1<<7)));
		Write_IER(0);
		Write_LCR(Read_LCR() | (1<<7));
		Write_DLL(0);
		Write_DLM(0);
		Write_FCR(0);
		Write_LCR(Read_LCR() & (~(1<<7)));
		Write_MCR(0);
        RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("-CRegUart::Init m_pReg = 0x%x\r\n"), (int)m_pReg));
		return TRUE;
    }
    else
	{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("FALSE CRegUart::Init m_pReg = 0x%x\r\n"), (int)m_pReg));
        return FALSE;
	}
}
void CRegUart::Backup()
{
    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[SERIAL      ]Channel%d::Backup\r\n"),m_nChannel));
	tcc_serial_iobusonoff(m_nChannel,m_nPort,1);	
	Write_IER(Read_IER() & (~(HwUART_IER_ELSI_EN)));
	
    m_fIsBackedUp = TRUE;
    //ByteSize, SetParity, SetStopBits, 
    m_LCRBackup = Read_LCR();
    m_IERBackup = Read_IER();
    Write_LCR(m_LCRBackup & (~(1<<7)));
	m_FCRBackup	= 0x17;
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("backup...[%x][%x]"), m_IERBackup, m_FCRBackup ));
    Write_LCR(m_LCRBackup | (1<<7));
	//baudrate
    m_DLLBackup = Read_DLL();
    m_DLMBackup = Read_DLM();
    m_MCRBackup = Read_MCR();  
	// others
	m_AFTBackup = Read_AFT();
	m_UCRBackup = Read_UCR();
	
	Write_LCR(m_LCRBackup);
	tcc_serial_iobusonoff(m_nChannel,m_nPort,1);	

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[%x][%x][%x][%x]\n"),m_LCRBackup,m_DLLBackup, m_DLMBackup, m_MCRBackup ));
}

void CRegUart::Restore()
{
    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[SERIAL      ]Channel%d::Restore\r\n"),m_nChannel));
	
    if (m_fIsBackedUp) {
	tcc_serial_iobusonoff(m_nChannel,m_nPort,1);	
	Write_IER(m_IERBackup );
	Write_LCR(m_LCRBackup & (~(1<<7)));
	//
	Write_FCR(m_FCRBackup );

	Write_LCR(m_LCRBackup | (1<<7));
       Write_DLL(m_DLLBackup);
       Write_DLM(m_DLMBackup);
	Write_LCR(m_LCRBackup);

	Write_MCR(m_MCRBackup);
	// others
	Write_AFT(m_AFTBackup);
	Write_UCR(m_UCRBackup);

	m_fIsBackedUp = FALSE;
	Backup();
	tcc_serial_iobusonoff(m_nChannel,m_nPort,1);
	Write_IER(Read_IER() | HwUART_IER_ELSI_EN);

	if(!m_Opened)
		tcc_serial_iobusonoff(m_nChannel,m_nPort,1);	
    }
}

CRegUart::Write_BaudRate(ULONG BaudRate)
{
   	DWORD nTemp = (tcc_ckc_getperi(PERI_UART0+m_nChannel) *100 *2/ BaudRate /16 + 1)/2 ;
	
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[SERIAL      ]PeriClock -> [%d]\r\n"),tcc_ckc_getperi(PERI_UART0+m_nChannel) *100 ));
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[SERIAL      ]SetBaudRate -> %d[%d]\r\n"), BaudRate,nTemp));
	
	if(nTemp > 0xFF)
	{
		Write_LCR(Read_LCR() | (1<<7));
		Write_DLL(nTemp & 0x00FF);

		Write_DLM(nTemp >> 8);
		Write_LCR(Read_LCR() & (~(1<<7)));
	}
	else if(nTemp > 0)
	{
		Write_LCR(Read_LCR() | (1<<7));
		Write_DLL(nTemp);
		Write_DLM(0);
		Write_LCR(Read_LCR() & (~(1<<7)));
	}
    else {
        // TODO: Support external UART clock.
        RETAILMSG(TRUE, (TEXT("ERROR: The TCC89X serial driver doesn't support an external UART clock.\r\n")));
        ASSERT(FALSE);
        return(FALSE);
    }
	return TRUE;
}
#ifdef DEBUG
void CRegUart::DumpRegister()
{
    Write_LCR(Read_LCR() | (1<<7));
    NKDbgPrintfW(TEXT("DumpRegister (DLL=%x, DLM=%x, LCR = %x, MCR =%x)\r\n"),
     Read_DLL(),Read_DLM(),Read_LCR(),Read_MCR());
    Write_LCR(Read_LCR() & (~(1<<7)));
}
#endif

CPddUart::CPddUart (LPTSTR lpActivePath, PVOID pMdd, PHWOBJ pHwObj )
:   CSerialPDD(lpActivePath,pMdd, pHwObj)
,   m_ActiveReg(HKEY_LOCAL_MACHINE,lpActivePath)
,   CMiniThread (0, TRUE)   
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("CPddUart::CPddUart\r\n")));
    
    m_pRegUart = NULL;
	
    m_dwIntShift = 0;
    m_dwSysIntr = MAXDWORD;
    m_hISTEvent = NULL;
    m_dwDevIndex = 0;
    m_XmitFlushDone =  CreateEvent(0, FALSE, FALSE, NULL);
    m_XmitFifoEnable = FALSE;
    m_dwWaterMark = 8 ;

	m_hUartIsrHandler = 0;	
	m_hDMAIsrHandler = 0;
	m_pRegVirtualAddr = 0;

	pVirtualPortMuxAddr = 0;
	pVirtualGpioAddr= 0;
	pVirtualDmaBufAddr= 0;

	RXBUFFADDR = 0;
	preTemp=0;


	m_DMARxEvent = 0;

}

CPddUart::~CPddUart()
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("CPddUart::~CPddUart\r\n")));
    
    InitModem(FALSE);
    if (m_hISTEvent) {
        m_bTerminated=TRUE;
        ThreadStart();
        SetEvent(m_hISTEvent);
		SetEvent(m_DMARxEvent);		
        ThreadTerminated(1000);
        InterruptDisable( m_dwSysIntr );         
        CloseHandle(m_hISTEvent);
    }


	if (m_XmitFlushDone)
        CloseHandle(m_XmitFlushDone);
    
	if (m_pRegUart)
        delete m_pRegUart;


	if(m_hUartIsrHandler)
		FreeIntChainHandler(m_hUartIsrHandler);

	if(m_hDMAIsrHandler)
		FreeIntChainHandler(m_hDMAIsrHandler);
}


BOOL CPddUart::Init(DWORD nComNumber)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::Init[%d]\r\n"),nComNumber));
	
	
	pVirtualDmaAddrTX = NULL;
	pVirtualDmaAddrRX = NULL;
	m_pRegVirtualAddr = NULL;




    if ( CSerialPDD::Init() && IsKeyOpened() && m_XmitFlushDone!=NULL) { 
        // IST Setup .

		 DDKISRINFO ddi;

		
		 if(!RXIntrusing){
			if(GetIsrInfo(&ddi)== ERROR_SUCCESS &&
			KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &ddi.dwIrq, sizeof(UINT32), &ddi.dwSysintr, sizeof(UINT32), NULL))
			{   
				RegSetValueEx(DEVLOAD_SYSINTR_VALNAME,REG_DWORD,(PBYTE)&ddi.dwSysintr, sizeof(UINT32));
			}
			else
				return FALSE;
		 }
		        
        
		m_ComNumber = nComNumber;		
		m_dwSysIntr = ddi.dwSysintr;
			
		
		PTV_PORTMUX(&pVirtualPortMuxAddr);
		PTV_GPIO(&pVirtualGpioAddr);
		PTV_UART(m_ComChannel,&m_pRegVirtualAddr);
		PTV_DMABUFFER(&pVirtualDmaBufAddr);

		tcc_serial_iobusonoff(m_ComChannel,m_ComPort, 1);		
		tcc_serial_portinit(m_ComChannel,m_ComPort,pVirtualGpioAddr,pVirtualPortMuxAddr);
		
		
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]portinit %d, %d, %d\r\n"),m_ComChannel,m_ComPort,m_ComNumber ));
		if(!RXIntrusing){
			if (m_dwSysIntr !=  MAXDWORD && m_dwSysIntr!=0 ) 
				m_hISTEvent= CreateEvent(0,FALSE,FALSE,NULL);
		}
		TXBUFFADDR		=0;
		TXBUFFADDR_PHY	=0;
		RXBUFFADDR		=0;
		RXBUFFADDR_PHY	=0;
		
	
		switch(m_ComPort)
		{
		//refer Resource.txt for UART & PORT & GDMA usage		
		case 5://com1
			if(bUsingDMA){
				m_DmaTxNumber = 1;
				m_DmaTxChannel = 2;		
				SET_DMA(m_DmaTxNumber, m_DmaTxChannel, true);//tx
			}

			if(RXIntrusing){
				m_DmaRxNumber = 0;
				m_DmaRxChannel = 0;
				SET_DMA(m_DmaRxNumber, m_DmaRxChannel, false);//rx
			}
			else{
				SetupUartISR(m_ComChannel);
				if (m_hISTEvent!=NULL)
					InterruptInitialize(m_dwSysIntr,m_hISTEvent,0,0);	
			}
			break;
		case 1://com2
			if(bUsingDMA){
				m_DmaTxNumber = 1;
				m_DmaTxChannel = 0;		
				SET_DMA(m_DmaTxNumber, m_DmaTxChannel, true);//tx
			}

			if(RXIntrusing){
				m_DmaRxNumber = 1;
				m_DmaRxChannel = 1;
				SET_DMA(m_DmaRxNumber, m_DmaRxChannel, false);//rx
			}
			else{
				SetupUartISR(m_ComChannel);
				if (m_hISTEvent!=NULL)
					InterruptInitialize(m_dwSysIntr,m_hISTEvent,0,0);	
			}
			break;
		case 4://com3
			if(bUsingDMA){
				m_DmaTxNumber = 0;
				m_DmaTxChannel = 1;		
				SET_DMA(m_DmaTxNumber, m_DmaTxChannel, true);//tx
			}

			if(RXIntrusing){
				m_DmaRxNumber = 0;
				m_DmaRxChannel = 2;
				SET_DMA(m_DmaRxNumber, m_DmaRxChannel, false);//rx
			}
			else{
				SetupUartISR(m_ComChannel);
				if (m_hISTEvent!=NULL)
					InterruptInitialize(m_dwSysIntr,m_hISTEvent,0,0);	
			}
			break;			
		default:
			SetupUartISR(m_ComChannel);
			if (m_hISTEvent!=NULL)
				InterruptInitialize(m_dwSysIntr,m_hISTEvent,0,0);	

			bUsingDMA=FALSE;
			RXIntrusing = FALSE;			
			break;
		}

        // Get Device Index.
        if (!GetRegValue(PC_REG_DEVINDEX_VAL_NAME, (PBYTE)&m_dwDevIndex, PC_REG_DEVINDEX_VAL_LEN)) {
            m_dwDevIndex = 0;
        }
        if (!GetRegValue(PC_REG_SERIALWATERMARK_VAL_NAME,(PBYTE)&m_dwWaterMark,sizeof(DWORD))) {
            m_dwWaterMark = 8;
        }
        if (!GetRegValue(PC_REG_UART_INTBIT_VAL_NAME,(PBYTE)&m_dwIntShift,sizeof(DWORD))) {
            RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]Registery does not have %s set. Drivers fail!!!\r\n"),PC_REG_UART_INTBIT_VAL_NAME));
            m_dwIntShift =0;
            return FALSE;
        }
        if (!GetRegValue(PC_REG_UART_IST_TIMEOUTS_VAL_NAME,(PBYTE)&m_dwISTTimeout, PC_REG_UART_IST_TIMEOUTS_VAL_LEN)) {
            m_dwISTTimeout = INFINITE;
        }
        if (!MapHardware() || !CreateHardwareAccess()) {
            return FALSE;
        }


		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[SERIAL      ]- COM%d init\r\n"),m_ComNumber));
		return TRUE;        
    }
    return FALSE;
}




BOOL CPddUart::MapHardware() 
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::MapHardware\r\n")));
	
    if (m_pRegVirtualAddr !=NULL)
        return TRUE;

	// Get IO Window From Registry
    DDKWINDOWINFO dwi;
    if ( GetWindowInfo( &dwi)!=ERROR_SUCCESS || 
		dwi.dwNumMemWindows < 1 || 
		dwi.memWindows[0].dwBase == 0 || 
		dwi.memWindows[0].dwLen <  0x2c)
        return FALSE;
    DWORD dwInterfaceType;
    if (m_ActiveReg.IsKeyOpened() && 
		m_ActiveReg.GetRegValue( DEVLOAD_INTERFACETYPE_VALNAME, (PBYTE)&dwInterfaceType,sizeof(DWORD))) {
        dwi.dwInterfaceType = dwInterfaceType;
    }
	
    return (m_pRegVirtualAddr!=NULL );
}
BOOL CPddUart::CreateHardwareAccess()
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::CreateHardwareAccess\r\n")));

		
    if (m_pRegUart)
        return TRUE;
    if (m_pRegVirtualAddr!=NULL) {
        m_pRegUart = new CRegUart((PULONG)m_pRegVirtualAddr);
        if (m_pRegUart && !m_pRegUart->Init()) { // FALSE.
            delete m_pRegUart ;
            m_pRegUart = NULL;
        }
		m_pRegUart->m_nChannel = m_ComChannel;
		m_pRegUart->m_nPort = m_ComPort;
		
    }
    return (m_pRegUart!=NULL);
}
void CPddUart::SetDefaultChannel(DWORD channel)
{
	//m_ComChannel = channel;
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("UART Init channel[%d]\n"),m_ComChannel));
}
#define MAX_RETRY 0x1000
void CPddUart::PostInit()
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::PostInit\r\n")));
	
    DWORD dwCount=0;
    m_HardwareLock.Lock();
	
    DisableInterrupt(HwUART_IER_EMSI_EN | HwUART_IER_ELSI_EN | HwUART_IER_ETXI_EN | HwUART_IER_ERXI_EN);
    // Mask all interrupt.
  	while ((GetInterruptStatus() & HwUART_IIR_IPF)==0 && dwCount <MAX_RETRY) { // Interrupt.
        InitReceive(TRUE);
        InitLine(TRUE);
        ClearInterrupt(HwUART_IER_EMSI_EN | HwUART_IER_ELSI_EN | HwUART_IER_ETXI_EN | HwUART_IER_ERXI_EN);
        dwCount++;
    }
    ASSERT((GetInterruptStatus() & HwUART_IIR_IPF)!=0);

    // IST Start to Run.
    m_HardwareLock.Unlock();
    CSerialPDD::PostInit();
    CeSetPriority(m_dwPriority256);
#ifdef DEBUG
    if ( ZONE_INIT )
        m_pRegUart->DumpRegister();
#endif
	
	

    //ThreadStart();  // Start IST.	
	}


DWORD CPddUart::ThreadRun()
{
	DWORD interrupts=0x00;
	DWORD nRet;
	PGDMACTRL pDMA = (PGDMACTRL)pVirtualDmaAddrRX;	
	tcc_serial_iobusonoff(m_ComChannel,m_ComPort,1);
	
	while (!IsTerminated()) 	{
	if(RXIntrusing)
	{

		nRet =WaitForSingleObject( m_DMARxEvent,INFINITE);
#ifdef LOW_SERIAL_PERFORMANCE
		tcc_dma_clrien(m_DmaRxChannel,pVirtualDmaAddrRX);
		tcc_serial_dmaclrinterrupt(m_DmaRxChannel,pVirtualDmaAddrRX);
#endif
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("receive data event occured from DMA channel\r\n")));
		if (nRet==WAIT_OBJECT_0) {			
			m_HardwareLock.Lock();			
			interrupts |= INTR_RX;			
			NotifyPDDInterrupt((INTERRUPT_TYPE)interrupts);							
			m_HardwareLock.Unlock();			
		}	
#ifdef LOW_SERIAL_PERFORMANCE
		tcc_dma_setien(m_DmaRxChannel,pVirtualDmaAddrRX);
#endif
	}
	else	
	{
			
		PUARTPORTMUX pPortMux = (PUARTPORTMUX)pVirtualPortMuxAddr;
	
		if (WaitForSingleObject( m_hISTEvent,m_dwISTTimeout)==WAIT_OBJECT_0) {		

				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("uart Interrupt occur (%d)\r\n"),m_dwSysIntr));
				m_HardwareLock.Lock();
				DWORD dwData = GetInterruptStatus();
				DWORD dwMask = GetInterruptMask();

				DWORD maskval;
				KernelLibIoControl(m_hUartIsrHandler, IOCTL_GIISR_PORTVALUE,  0, 0, &maskval, sizeof(DWORD), 0);
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("ISRs port value (%d)\r\n"),maskval));

				if(dwData & (1<<0))
				{	

					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT(" ChannelStatus %x\r\n"), pPortMux->CHST));
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT(" IIR %x\r\n"),dwData ));
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT(" IER %x\r\n"),dwMask ));
					InterruptDone(m_dwSysIntr);
					m_HardwareLock.Unlock();
					continue;//break;				
				}
				switch((dwData & 0x0e)>>1) {
				case 0x03:
					dwMask &= Hw2;//HwUART_IER_ELSI_EN;
					break;
				case 0x02:
				case 0x06:
					dwMask &= Hw0;//HwUART_IER_ERXI_EN;
					break;
				case 0x01:
					dwMask &= Hw1;//HwUART_IER_ETXI_EN;
					break;
				case 0x00:
					dwMask &= Hw3;//HwUART_IER_EMSI_EN;
					break;
				}
				if (dwMask) {
					DWORD interrupts=INTR_MODEM; // Always check Modem when we have change. It maywork at polling mode.
				if ((dwMask & Hw0)!=0)
					interrupts |= INTR_RX;					
				if (((dwMask & Hw1)!=0))
					{
						if(!m_XmitInterruptStatus)
						{
							dwMask &= ~Hw1;
							DisableInterrupt(Hw1);
							
						}
						
						interrupts |= INTR_TX;
					}
				if ((dwMask & Hw2)!=0) 
					interrupts |= INTR_LINE|INTR_RX;
					DisableInterrupt(dwMask);
					InterruptDone(m_dwSysIntr);
					EnableInterrupt(dwMask);
					NotifyPDDInterrupt((INTERRUPT_TYPE)interrupts);
				}
				else{	
					InterruptDone(m_dwSysIntr);
					m_HardwareLock.Unlock();
					continue;				
				}
				m_HardwareLock.Unlock(); 
			}
			else { // Polling Modem.
				NotifyPDDInterrupt(INTR_MODEM);
				#ifdef DEBUG
				if ( ZONE_THREAD )
					m_pRegUart->DumpRegister();
				#endif
			}
		}
    }
    return 1;
}

BOOL CPddUart::InitialEnableInterrupt(BOOL bEnable )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::InitialEnableInterrupt[%d]\r\n"),bEnable));
	
    m_HardwareLock.Lock();
	if (bEnable) {
		if(!RXIntrusing)
			EnableInterrupt(Hw2 |Hw0);
	}
    else
        DisableInterrupt(Hw2 | Hw0);
    m_HardwareLock.Unlock();
    return TRUE;
}

BOOL  CPddUart::InitXmit(BOOL bInit)
{
    RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]CPddUart::InitXmit[%d]\n"),bInit));
	
    if (bInit) { 
        m_HardwareLock.Lock();    
		
        m_pRegUart->Write_LCR( m_pRegUart->Read_LCR() | (1<<7));

		if(RXIntrusing)
			m_pRegUart->Write_FCR(0x07);
		else
			m_pRegUart->Write_FCR(0x17);

        m_pRegUart->Write_LCR( m_pRegUart->Read_LCR() & (~(1<<7)));
        
        DisableInterrupt(Hw1);
		
        m_HardwareLock.Unlock();
		
		
		
    }
    else { // Make Sure data has been trasmit out.
        // We have to make sure the xmit is complete because MDD will shut donw the device after this return
        DWORD dwTicks = 0;
        DWORD dwUTRState;
        while (dwTicks < 1000 && (((dwUTRState = m_pRegUart->Read_LSR())>>5) & 3)!=3  ) { // Transmitter empty is not true
            RETAILMSG(ZONE_THREAD|ZONE_WRITE,(TEXT("CPddUart::InitXmit! Wait for UTRSTAT=%x clear.\r\n"), dwUTRState));
            Sleep(5);
            dwTicks +=5;
        }
    }
    return TRUE;
}


void    CPddUart::XmitInterruptHandler(PUCHAR pTxBuffer, ULONG *pBuffLen)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+CPddUart::XmitInterruptHandler[%d]\r\n"),*pBuffLen));
    PREFAST_DEBUGCHK(pBuffLen!=NULL);
	DWORD currentTick=0;
	DWORD beforeTick=0;
	DWORD cutwindow =256;
	

    if (*pBuffLen == 0) { 
	 //m_pRegUart->Write_UCR((m_pRegUart->Read_UCR() &~Hw0));
        EnableXmitInterrupt(FALSE);
    }
    else {
		DWORD dwDataAvaiable = *pBuffLen;
		DWORD dwSentSize=0;
        DWORD dwByteWrite=0;

		
		PUART pt = (PUART)m_pRegVirtualAddr;

		if(bUsingDMA) 
		{
			//tcc_serial_dmaclrinterrupt(m_DmaTxChannel,pVirtualDmaAddrTX); //if already inter is occur, clear interrupt pending
			while(dwDataAvaiable > 0 )
			{
			
				
				if(dwDataAvaiable > cutwindow)
				{
					
					//UART DMA Mode Off
					m_pRegUart->Write_UCR((m_pRegUart->Read_UCR() &~Hw0));
								
					
					
						//memcpy to Physical Memory
						memcpy((BYTE *)TXBUFFADDR,pTxBuffer+dwByteWrite, cutwindow);
						//DMA Setting 
					
						tcc_dma_setconfig(m_DmaTxChannel,
							TXBUFFADDR_PHY,	0x1, /* src Param */
							m_BaseAddress, 	0x0, /* dst Param */
							HwCHCTRL_SYNC_EN		|
							HwCHCTRL_TYPE_SL		|
							HwCHCTRL_BSIZE_1		|
							HwCHCTRL_WSIZE_8		|
							HwCHCTRL_IEN_ON			|
							HwCHCTRL_FLAG			,	
							cutwindow			,
							m_ComChannel			, //channel	
							0,						 // Tx : 0, Rx : 1
							pVirtualDmaAddrTX
							);
						
					
					//UART DMA Mode On
					m_pRegUart->Write_UCR((m_pRegUart->Read_UCR() |Hw0));	
					dwDataAvaiable -=cutwindow;
					dwByteWrite += cutwindow;
					dwSentSize = cutwindow;
					
				}
				else 
				{
					
					//UART DMA Mode Off
					m_pRegUart->Write_UCR((m_pRegUart->Read_UCR() &~Hw0));
				
					
						//memcpy to Physical Memory
						memcpy((BYTE *)TXBUFFADDR,pTxBuffer+dwByteWrite, dwDataAvaiable);
				
						//DMA Setting 
						tcc_dma_setconfig(m_DmaTxChannel,
							TXBUFFADDR_PHY,	0x1, /* src Param */
							m_BaseAddress, 	0x0, /* dst Param */
							HwCHCTRL_SYNC_EN		|
							HwCHCTRL_TYPE_SL		|
							HwCHCTRL_BSIZE_1		|
							HwCHCTRL_WSIZE_8		|
							HwCHCTRL_IEN_ON			|
							HwCHCTRL_FLAG			,	
							dwDataAvaiable			,
							m_ComChannel			, //channel	
							0,						  // Rx : 1, Tx : 0
							pVirtualDmaAddrTX
							);

									
					//UART DMA Mode On
					m_pRegUart->Write_UCR((m_pRegUart->Read_UCR() |Hw0));	
/*
					PGDMACTRL pDMA = (PGDMACTRL)pVirtualDmaAddr;
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("DMA CHCONFIG[%04x]\r\n"),pDMA->CHCONFIG));
*/
					dwByteWrite += dwDataAvaiable;
					dwSentSize = dwDataAvaiable;
					dwDataAvaiable =0;
					

				}

			
				
				if((!(tcc_dma_ctrl(m_DmaTxChannel,pVirtualDmaAddrTX) & Hw3)) )
				{
					
					
					DWORD nTimeOut = 600 + (dwSentSize*1000)/(m_dwBaudrate/8);
					if(WaitForSingleObject( m_DMATxEvent,nTimeOut)==WAIT_OBJECT_0){
						tcc_serial_dmaclrinterrupt(m_DmaTxChannel,pVirtualDmaAddrTX);
						RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]UART DMA Intr occured\r\n")));
					}
					else{
						tcc_serial_dmaclrinterrupt(m_DmaTxChannel,pVirtualDmaAddrTX);
						RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]UART DMA Intr Timeout[%d]\r\n"),nTimeOut));
					}
					
					
				}
				else{	
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]UART DMA already occured\r\n")));
					tcc_serial_dmaclrinterrupt(m_DmaTxChannel,pVirtualDmaAddrTX); //if already inter is occur, clear interrupt pending
				}			
				
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+[%d][%d][%d]\r\n"),currentTick,dwSentSize,m_DmaTxChannel));
			}	
			
			


			*pBuffLen = dwByteWrite;


		}	
		else{
			m_HardwareLock.Lock(); 
			if(dwDataAvaiable > 8)
				dwDataAvaiable = 8;
			
			while(dwDataAvaiable)
			{
				if	(m_pRegUart->Read_LSR() & Hw5)
				{
					m_pRegUart->Write_THR(*pTxBuffer);
					
					pTxBuffer ++; 
					dwByteWrite++;
					dwDataAvaiable--;
				}
			}
			
			if(*pBuffLen > 8)
			{
				*pBuffLen = 8;
				EnableXmitInterrupt(TRUE);
			}
			else
			{
			
				*pBuffLen = dwByteWrite;					
			}
			m_HardwareLock.Unlock();
		}
		
    }
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-CPddUart::XmitInterruptHandler[%d]\r\n"),*pBuffLen));
}

void    CPddUart::XmitComChar(UCHAR ComChar)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::XmitComChar\r\n")));
	
    // This function has to poll until the Data can be sent out.
    BOOL bDone = FALSE;
    do {
        m_HardwareLock.Lock(); 
        if ( GetWriteableSize()!=0 ) {  // If not full 
            m_pRegUart->Write_THR(ComChar);
            bDone = TRUE;
        }
        else {
            EnableXmitInterrupt(TRUE);
        }
        m_HardwareLock.Unlock();
    }
    while (!bDone);
}
BOOL    CPddUart::EnableXmitInterrupt(BOOL fEnable)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::EnableXmitInterrupt[%d]\n"),fEnable));
	
    m_HardwareLock.Lock();
	m_pRegUart->Write_LCR(m_pRegUart->Read_LCR()&(~(1<<7)));
	
    if (fEnable)
	{
		m_XmitInterruptStatus=TRUE;
		if(!bUsingDMA)
			EnableInterrupt(Hw1);//HwUART_IER_ETXI_EN
	}
    else
	{
		m_XmitInterruptStatus=FALSE;
        DisableInterrupt(Hw1);//HwUART_IER_ETXI_EN
	}
	m_pRegUart->Write_LCR(m_pRegUart->Read_LCR()&(~(1<<7)));
	
    m_HardwareLock.Unlock();
    return TRUE;
	
}
BOOL  CPddUart::CancelXmit()
{
    return InitXmit(TRUE);     
}
static PAIRS s_HighWaterPairs[] = {
    {0, 4 },
    {1, 8 },
    {2, 12 },
    {3, 16 }
};

BYTE  CPddUart::GetWaterMarkBit()
{
    BYTE bReturnKey = (BYTE)s_HighWaterPairs[0].Key;
    for (DWORD dwIndex=dim(s_HighWaterPairs)-1;dwIndex!=0; dwIndex --) {
        if (m_dwWaterMark>=s_HighWaterPairs[dwIndex].AssociatedValue) {
            bReturnKey = (BYTE)s_HighWaterPairs[dwIndex].Key;
            break;
        }
    }
    return bReturnKey;
}
DWORD   CPddUart::GetWaterMark()
{
    BYTE bReturnValue = (BYTE)s_HighWaterPairs[0].AssociatedValue;
    for (DWORD dwIndex=dim(s_HighWaterPairs)-1;dwIndex!=0; dwIndex --) {
        if (m_dwWaterMark>=s_HighWaterPairs[dwIndex].AssociatedValue) {
            bReturnValue = (BYTE)s_HighWaterPairs[dwIndex].AssociatedValue;
            break;
        }
    }
    return bReturnValue;
}

// Receive
BOOL    CPddUart::InitReceive(BOOL bInit)
{
    RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]CPddUart::InitReceive[%d]\r\n"),bInit));
	
    m_HardwareLock.Lock();    
    if (bInit) {
#ifdef _DUMP_
		fpwrite = fopen("drv_recv","wb");
#endif
        BYTE uWarterMarkBit = GetWaterMarkBit();
        if (uWarterMarkBit> 3)
            uWarterMarkBit = 3;
        // Setup Receive FIFO.
        // Reset Receive Fifo.
		m_pRegUart->Write_LCR(m_pRegUart->Read_LCR() | (1<<7));

		if(RXIntrusing)
			m_pRegUart->Write_FCR(0x07);
		else
			m_pRegUart->Write_FCR(0x17);

        m_pRegUart->Write_LCR(m_pRegUart->Read_LCR() & (~(1<<7)));
		
		

		if(RXIntrusing)
		{
			tcc_dma_clrien(m_DmaRxChannel,pVirtualDmaAddrRX);

			m_dma_stAddr = tcc_dma_dmadeststartaddress(m_DmaRxChannel,pVirtualDmaAddrRX);
			
			preTemp = 0;
			
			m_pRegUart->Write_UCR((m_pRegUart->Read_UCR() &~Hw1));
			
			DWORD DMABuffer = 0xFFFFFF00 / (((MAX_BUF_SIZE) >> 4)<<8);
			DMABuffer = DMABuffer * (((MAX_BUF_SIZE) >> 4)<<8);
		
			tcc_dma_setconfig(m_DmaRxChannel,
				m_BaseAddress, 	0x0, /* src Param */
				RXBUFFADDR_PHY,	(0x1|DMABuffer), /* dst Param */
				HwCHCTRL_CONT_C			|
				HwCHCTRL_SYNC_EN		|
				HwCHCTRL_TYPE_SL		|
				HwCHCTRL_BSIZE_1		|
				HwCHCTRL_WSIZE_8		|
				HwCHCTRL_IEN_ON			|
				HwCHCTRL_FLAG			|
				HwCHCTRL_REP_EN			,	
				1			,
				m_ComChannel			, //channel	
				1,						  // Rx : 1, Tx : 0
				pVirtualDmaAddrRX
				);
		
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("Dma base address : %x \n"),RXBUFFADDR_PHY));
			
			m_pRegUart->Write_UCR((m_pRegUart->Read_UCR() |Hw1));			
		}
		else{
			EnableInterrupt(HwUART_IER_ERXI_EN);
		}
	}
    else {
		if(RXIntrusing)
			m_pRegUart->Write_UCR((m_pRegUart->Read_UCR() &~Hw1));
		else
			DisableInterrupt(HwUART_IER_ERXI_EN);
#ifdef _DUMP_
		fclose(fpwrite);
#endif
	    
    }
    m_HardwareLock.Unlock();
	
	
    return TRUE;
}


ULONG   CPddUart::ReceiveInterruptHandler(PUCHAR pRxBuffer,ULONG *pBufflen)
{

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("m_ComNumber %d\r\n"),m_ComNumber));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("m_RxDmaNumber %d , m_DmaRxChannel %d\r\n"),m_DmaRxNumber,m_DmaRxChannel));
		
	if(RXIntrusing)
	{
		DWORD temp=0, result=0;
		
		
		if(m_pRegUart->Read_LSR()&Hw0)
			Sleep(1);
		

		

		m_HardwareLock.Lock();
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("m_dma_stAddr %ld\r\n"),m_dma_stAddr));
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("tcc_dma_dmacurrentaddress %ld\r\n"),tcc_dma_dmacurrentaddress(m_DmaRxChannel,pVirtualDmaAddrRX)));
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("===========LSR %x=============\r\n"),m_pRegUart->Read_LSR()));
		temp = tcc_dma_dmacurrentaddress(m_DmaRxChannel,pVirtualDmaAddrRX) - m_dma_stAddr;
		m_HardwareLock.Unlock();
	
/*
		RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("===========================\r\n")));
		for(int i =0 ; i< 512 ; i++){
			RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("%02x "),*((char*)RXBUFFADDR+i)));
		}
		RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("\r\n===========================\r\n")));
*/
	
		if(preTemp >  temp){
			
			result = temp+ RX_BUFFER_SIZE - preTemp;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("recieved result %ld \n"),result));
			
			if(*pBufflen >= result){
				
			
				memcpy((char*)pRxBuffer, (char*)RXBUFFADDR+ preTemp, RX_BUFFER_SIZE - preTemp);
				memcpy((char*)pRxBuffer+RX_BUFFER_SIZE - preTemp, (char*)RXBUFFADDR, temp);					
				preTemp = temp;
				*pBufflen = result;
			}
			else{
				
				memcpy((char*)pRxBuffer, (char*)RXBUFFADDR+ preTemp, *pBufflen);
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("pre %ld, cur %ld, result %ld \n"),preTemp,temp,result));
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("pBufflen %d, result %d\r\n"),*pBufflen,result));
				preTemp += *pBufflen;
				
				result = *pBufflen;

				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("dma buffer full!! may dataloss occur..1\r\n")));
			}
			
				
#ifdef _DUMP_
			fwrite((char*)RXBUFFADDR+ preTemp,1,RX_BUFFER_SIZE - preTemp,fpwrite);
			fwrite((char*)RXBUFFADDR,1,temp,fpwrite);							
#endif
		}
		else{
			result = temp - preTemp;			
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("recieved result %ld \n"),result));
			if(*pBufflen >= result){
				memcpy((char*)pRxBuffer, (char*)RXBUFFADDR + preTemp , result);
				preTemp = temp;
				*pBufflen = result;
			}
			else{
				memcpy((char*)pRxBuffer, (char*)RXBUFFADDR + preTemp , *pBufflen);
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("pre %ld, cur %ld, result %ld \n"),preTemp,temp,result));
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("pBufflen %d, result %d\r\n"),*pBufflen,result));
				preTemp += *pBufflen;				
				result = *pBufflen;
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("dma buffer full!! may dataloss occur..2\r\n")));
			}
#ifdef _DUMP_
			fwrite((char*)RXBUFFADDR + preTemp,1,result,fpwrite);
#endif
		}




	
		if(preTemp == RX_BUFFER_SIZE){
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("full -> 0 \r\n")));
			preTemp = 0;
		}
	
		if(result > RX_BUFFER_SIZE )
			return  RX_BUFFER_SIZE;

		return result;
	}
	else
	{
		ULONG ulUFSTATE;
		DWORD dwNumRxInFifo;
		DWORD dwBytesStored;
		DWORD dwRoomLeft;
		PUCHAR tpRxBuffer = pRxBuffer;
		DWORD currentTick=0;
		DWORD beforeTick=0;
		DWORD dwDataReceive=0;
		
		
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+CPddUart::ReceiveInterruptHandler pRxBuffer=%x,*pBufflen=%x\r\n"),
			pRxBuffer,pBufflen!=NULL?*pBufflen:0));
		
		DWORD dwBytesDropped = 0;
		if (pRxBuffer && pBufflen ) {
			dwBytesStored = 0 ;
			dwRoomLeft = *pBufflen;
			m_bReceivedCanceled = FALSE;
			m_HardwareLock.Lock();
			
			while (dwRoomLeft && !m_bReceivedCanceled) {
				ulUFSTATE = m_pRegUart->Read_LSR();
	            
				
				
				if(ulUFSTATE & Hw0) 
					dwNumRxInFifo = 1; // Data ready
				else 
					dwNumRxInFifo = 0; // Data not ready
								
				if (ulUFSTATE & Hw1) {
					// Overflow. Use FIFO depth (16);
					dwNumRxInFifo = SERTCC_FIFO_DEPTH_RX;
					RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("FIFO Overflow\r\n")));
				}
				

				
				if (dwNumRxInFifo) {
					while (dwNumRxInFifo && dwRoomLeft) {
						UCHAR uLineStatus = GetLineStatus();
						UCHAR uData = (UCHAR)m_pRegUart->Read_RBR();    // Get data from Receiver Buffer Register
						
						

						if(uLineStatus & UERSTATE_PARITY_ERROR)
							RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]PARITY_ERROR\r\n")));
						
						if (DataReplaced(&uData,(uLineStatus & UERSTATE_PARITY_ERROR)!=0))
						{
							*pRxBuffer++ = uData;
							
							dwRoomLeft--;
							dwBytesStored++;    
						}
						dwNumRxInFifo --;
					}
				}
				else
					break;
				
			}
			if (m_bReceivedCanceled)
				dwBytesStored = 0;
			*pBufflen = dwBytesStored;
			m_HardwareLock.Unlock();
		}
		else {
			ASSERT(FALSE);
		}
	
    RETAILMSG(ZONE_THREAD|ZONE_READ,(TEXT("-CPddUart::ReceiveInterruptHandler pRxBuffer=%x,*pBufflen=%x,dwBytesDropped=%x\r\n"),
        pRxBuffer,pBufflen!=NULL?*pBufflen:0,dwBytesDropped));
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[%d]"),*pBufflen));
	return dwBytesDropped;
}

}
ULONG   CPddUart::CancelReceive()
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::CancelReceive\r\n")));
	
    m_bReceivedCanceled = TRUE;
    m_HardwareLock.Lock();   
    InitReceive(TRUE);
    m_HardwareLock.Unlock();
    return 0;
}
BOOL    CPddUart::InitModem(BOOL bInit)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::InitModem\r\n")));
	
#if 0
    m_HardwareLock.Lock();   
    m_pRegUart->Write_MCR((1<<1)); // Disable AFC and Set RTS as default.
    m_HardwareLock.Unlock();
    return TRUE;
#else
    return FALSE;
#endif
}

ULONG   CPddUart::GetModemStatus()
{
    //RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::GetModemStatus\r\n")));

    m_HardwareLock.Lock();
    ULONG ulReturn =0 ;
    ULONG Events = 0;
    UINT8 ubModemStatus = (UINT8) m_pRegUart->Read_MSR();
    m_HardwareLock.Unlock();
	
    // Event Notification.
    if (ubModemStatus & (1<<2))
        Events |= EV_CTS;
    if (Events!=0)
        EventCallback(Events);
	
    // Report Modem Status;
    if ( ubModemStatus & (1<<4) )
        ulReturn |= MS_CTS_ON;  
    return ulReturn;
}
void    CPddUart::SetRTS(BOOL bSet)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::SetRTS[%d]\n"),bSet));
    m_HardwareLock.Lock();
    ULONG ulData = m_pRegUart->Read_MCR()&(~(Hw6|Hw5|Hw4|Hw1));
	bSet=FALSE;
    if (bSet)
		m_pRegUart->Write_MCR(Hw5|Hw1);
	else
        m_pRegUart->Write_MCR(ulData);
	
    m_HardwareLock.Unlock();
}
BOOL CPddUart::InitLine(BOOL bInit)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+CPddUart::InitLine[%d]\n"),bInit));	

    m_HardwareLock.Lock();
    if  (bInit) {
		if(!RXIntrusing)
			EnableInterrupt( Hw2 );//HwUART_IER_ELSI_EN
    }
    else {
        DisableInterrupt(Hw2 );//HwUART_IER_ELSI_EN
    }
    m_HardwareLock.Unlock();
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-CPddUart::InitLine[%d]\n"),bInit));
    return TRUE;
}
BYTE CPddUart::GetLineStatus()
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::GetLineStatus\n")));
	
    m_HardwareLock.Lock();
    ULONG ulData = m_pRegUart->Read_LSR();
    m_HardwareLock.Unlock();  
    ULONG ulError = 0;
    if (ulData & Hw1 ) {//HwUART_LSR_OE_ON
        ulError |=  CE_OVERRUN;
    }
    if (ulData & Hw2 ) {//HwUART_LSR_PE_ON
        ulError |= CE_RXPARITY;
    }
    if (ulData & Hw3 ) {//HwUART_LSR_FE_ON
        ulError |=  CE_FRAME;
    }
    if (ulError)
        SetReceiveError(ulError);
    
    if (ulData & Hw4 ) {//HwUART_LSR_BI_ON
		EventCallback(EV_BREAK);
    }
    return (UINT8)(ulData & 0x8e);
	
}
DWORD   CPddUart::GetWriteableSize()
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::GetWriteableSize\r\n")));
	
    DWORD dwWriteSize = 0;
	
    DWORD dwUfState = m_pRegUart->Read_LSR() ;
    if ((dwUfState & (3<<5))!=0) { // It is not full.
		dwWriteSize = 1;
    }
    else{
		dwWriteSize = 0;
	}
	
    return dwWriteSize;
}
void    CPddUart::SetBreak(BOOL bSet)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]CPddUart::SetBreak[%d]\n"),bSet));
	
    m_HardwareLock.Lock();
    ULONG ulData = m_pRegUart->Read_LCR();
    if (bSet)
        ulData |= (1<<6);
    else
        ulData &= ~(1<<6);
	
    m_pRegUart->Write_LCR(ulData);
    m_HardwareLock.Unlock();      
}

BOOL    CPddUart::SetBaudRate(ULONG BaudRate,BOOL bIrModule)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]CPddUart::SetBaudRate[%d]\n"),BaudRate));
	
    m_HardwareLock.Lock();
    BOOL bReturn = m_pRegUart->Write_BaudRate(BaudRate);
	m_dwBaudrate = BaudRate;
    m_HardwareLock.Unlock();      
    return TRUE;
}


int CPddUart::GetComChannel()
{
	return m_ComChannel;
}

int CPddUart::GetComPort()
{
	return m_ComPort;
}

int  CPddUart::SetOpenStatus(int bOpen)
{
	if(bOpen){
		m_pRegUart->m_Opened = 1;
		ThreadStart(); // start IST
	}
	else{
		m_pRegUart->m_Opened = 0;
		m_bTerminated=TRUE;
        SetEvent(m_hISTEvent);
		ThreadTerminated(1000);

	}
	return 1;
}

BOOL    CPddUart::SetByteSize(ULONG ByteSize)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]CPddUart::SetByteSize[%d]\n"), ByteSize));
	
    m_HardwareLock.Lock();
    ULONG ulData = m_pRegUart->Read_LCR() & (~(Hw1|Hw0));
    
	switch ( ByteSize ) {
	case 5: 
		m_pRegUart->Write_LCR(ulData);
		break;
	case 6:
		m_pRegUart->Write_LCR( (ulData|Hw0) );
		break;
	case 7:
		m_pRegUart->Write_LCR( (ulData|Hw1) );
		break;
	case 8:
		m_pRegUart->Write_LCR( (ulData|Hw1|Hw0) );
		break;
	default:
		m_pRegUart->Write_LCR( (ulData|Hw1|Hw0) );
		break;
	}
    
    m_HardwareLock.Unlock();
    return TRUE;
}
BOOL    CPddUart::SetParity(ULONG Parity)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]CPddUart::SetParity[%d]\n"),Parity));
	
    m_HardwareLock.Lock();
    ULONG ulData = m_pRegUart->Read_LCR() & (~(Hw5|Hw4|Hw3));
    switch ( Parity ) {
    case ODDPARITY: //1
		m_pRegUart->Write_LCR( (ulData|Hw3) );
        break;
    case EVENPARITY: //2
		m_pRegUart->Write_LCR( (ulData|Hw4|Hw3) );
        break;
    case MARKPARITY: //3
        m_pRegUart->Write_LCR( (ulData|Hw5|Hw3) );
        break;
    case SPACEPARITY: //4
        m_pRegUart->Write_LCR( (ulData|Hw5|Hw4|Hw3) );
        break;
    case NOPARITY:  //0
		m_pRegUart->Write_LCR( (ulData) );
        break;
    default:
        m_pRegUart->Write_LCR( (ulData) );
        break;
    }
    m_HardwareLock.Unlock();
	
    return TRUE;
}
BOOL    CPddUart::SetStopBits(ULONG StopBits)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]CPddUart::SetStopBits[%d]\n")));
	
    m_HardwareLock.Lock();
    ULONG ulData = m_pRegUart->Read_LCR() & (~Hw2);
	
    switch ( StopBits ) {
    case ONESTOPBIT :  //0
		m_pRegUart->Write_LCR( (ulData|Hw2) );
		break;
    case TWOSTOPBITS : //2
        m_pRegUart->Write_LCR(ulData);
        break;
    default:
        m_pRegUart->Write_LCR( (ulData|Hw2) );
        break;
    }
    m_HardwareLock.Unlock();
	
    return TRUE;
}
void    CPddUart::SetOutputMode(BOOL UseIR, BOOL Use9Pin)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("CPddUart::SetOutputMode[%d]\n"),UseIR));
	m_HardwareLock.Lock();
    CSerialPDD::SetOutputMode(UseIR, Use9Pin);
#if 0
    ULONG ulData = m_pRegUart->Read_ULCON() & (~(0x1<<6));
    ulData |= (UseIR?(0x1<<6):0);
    m_pRegUart->Write_ULCON(ulData);
#endif
    m_HardwareLock.Unlock();
}



BOOL CPddUart::PTV_UART(DWORD nComChannel,unsigned long** vaddr)
{
	if(*vaddr)
		return TRUE;

	PHYSICAL_ADDRESS PhysAddr;
	PhysAddr.HighPart = 0;

	switch(nComChannel)	{
	case 0:
		PhysAddr.LowPart = (DWORD)&HwUARTCH0_BASE;
		m_BaseAddress = (DWORD*)&HwUARTCH0_BASE;
		break;
	case 1:
		PhysAddr.LowPart = (DWORD)&HwUARTCH1_BASE;
		m_BaseAddress = (DWORD*)&HwUARTCH1_BASE;
		break;
	case 2:			
		PhysAddr.LowPart = (DWORD)&HwUARTCH2_BASE;
		m_BaseAddress = (DWORD*)&HwUARTCH2_BASE;
		break;
	case 3:			
		PhysAddr.LowPart = (DWORD)&HwUARTCH3_BASE;
		m_BaseAddress = (DWORD*)&HwUARTCH3_BASE;
		break;
	case 4:			
		PhysAddr.LowPart = (DWORD)&HwUARTCH4_BASE;
		m_BaseAddress = (DWORD*)&HwUARTCH4_BASE;
		break;
	case 5:			
		PhysAddr.LowPart = (DWORD)&HwUARTCH5_BASE;
		m_BaseAddress = (DWORD*)&HwUARTCH5_BASE;
		break;
	default:
		PhysAddr.LowPart = 0;
		return FALSE;
		break;
	}
		
	*vaddr = (unsigned long*)tcc_allocbaseaddress(PhysAddr.LowPart);

	if(*vaddr)
		return TRUE;
	else
		return FALSE;
	return FALSE;
}

BOOL CPddUart::PTV_PORTMUX(unsigned long** vaddr)
{
	if(*vaddr)
		return TRUE;
	
	PHYSICAL_ADDRESS PhysAddr_PortMux;

	PhysAddr_PortMux.HighPart = 0;
	PhysAddr_PortMux.LowPart = (DWORD)&HwUARTPORTMUX_BASE;


	
	*vaddr  = (unsigned long*)tcc_allocbaseaddress(PhysAddr_PortMux.LowPart);
	
	if(*vaddr)
		return TRUE;
	else
		return FALSE;
	return FALSE;
}

BOOL CPddUart::PTV_GPIO(unsigned long** vaddr)
{
	if(*vaddr)
		return TRUE;
	
	PHYSICAL_ADDRESS PhysAddr_GPIO;
	PhysAddr_GPIO.HighPart = 0;
	PhysAddr_GPIO.LowPart = (DWORD)&HwGPIO_BASE;


	
	
	*vaddr = (unsigned long*)tcc_allocbaseaddress(PhysAddr_GPIO.LowPart);

	if(*vaddr)
		return TRUE;
	else
		return FALSE;
	return FALSE;
}

BOOL CPddUart::PTV_DMA(int nDmaNum, unsigned long** vaddr)
{
	if(*vaddr)
		return TRUE;
	
	PHYSICAL_ADDRESS PhysAddr_DMA;
	PhysAddr_DMA.HighPart = 0;

	switch(nDmaNum){
	case 0:
		PhysAddr_DMA.LowPart = (DWORD)&HwGDMA0_BASE;
		break;
	case 1:
		PhysAddr_DMA.LowPart = (DWORD)&HwGDMA1_BASE;
		break;
	case 2:
		PhysAddr_DMA.LowPart = (DWORD)&HwGDMA2_BASE;
		break;
	case 3:
		PhysAddr_DMA.LowPart = (DWORD)&HwGDMA3_BASE;
		break;
	}

	
	*vaddr = (unsigned long*)tcc_allocbaseaddress(PhysAddr_DMA.LowPart);
	
	
	if(*vaddr)
		return TRUE;
	else
		return FALSE;
	return FALSE;
}

BOOL CPddUart::PTV_DMABUFFER(unsigned long** vaddr)
{
	if(*vaddr)
		return TRUE;
	
	PHYSICAL_ADDRESS PhysAddr_DMABuf;
	PhysAddr_DMABuf.HighPart = 0;
	PhysAddr_DMABuf.LowPart = SYSTEM_PARAM_BASEADDRESS;
		
	
	*vaddr = (unsigned long*)tcc_allocbaseaddress(PhysAddr_DMABuf.LowPart);
	
	if(*vaddr)
		return TRUE;
	else
		return FALSE;
	return FALSE;
}


BOOL CPddUart::SetupUartISR(DWORD nComChannel)
{
	//load isr, irq
	DDKISRINFO ddi;
    if (GetIsrInfo(&ddi)!=ERROR_SUCCESS) 
		return FALSE;

	//Install ISR 
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("ddi.dwIrq [%d]\r\n"),ddi.dwIrq));		
    m_hUartIsrHandler = LoadIntChainHandler(ddi.szIsrDll,ddi.szIsrHandler,ddi.dwIrq);
	if(m_hUartIsrHandler == NULL){
		DWORD dwRet = GetLastError();	
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]Load UART IntChainHandler return fail %d\r\n"),dwRet));			
		return FALSE;
	}
	else{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]Load UART IntChainHandler  success\r\n")));					
	}


	// Set up ISR handler
	if(m_hUartIsrHandler){
		GIISR_INFO Info;
		memset(&Info, 0, sizeof(GIISR_INFO));
		Info.CheckPort = TRUE; //irq happen then chk port <-> false means don't chk port == no shared IRQ
		Info.PortIsIO = FALSE; // memory mapped - not real port (TRUE only used X86)
		Info.SysIntr = ddi.dwSysintr;
		Info.PortSize = sizeof(DWORD);// size of HwUART_CHST
		Info.UseMaskReg = FALSE;
		Info.MaskAddr = 0;
		
		switch(nComChannel)	{
		case 0:
			Info.Mask = Hw0;	
			break;
		case 1:
			Info.Mask = Hw1;	
			break;
		case 2:			
			Info.Mask = Hw2;	
			break;
		case 3:			
			Info.Mask = Hw3;	
			break;
		case 4:			
			Info.Mask = Hw4;	
			break;
		case 5:			
			Info.Mask = Hw5;	
			break;
		default:
			return FALSE;	
			break;
		}
		
		PUARTPORTMUX pPortMux = (PUARTPORTMUX)pVirtualPortMuxAddr;
		Info.PortAddr = (DWORD)&(pPortMux->CHST);
		
							
		if (!KernelLibIoControl(m_hUartIsrHandler, IOCTL_GIISR_INFO,  &Info, sizeof(GIISR_INFO), NULL, 0, 0)){
			DWORD dwRet = GetLastError();	
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]KernelLibIoControl return fail %d\r\n"),dwRet));			
			return FALSE;
		}
		else
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]KernelLibIoControl return success\r\n")));
	}

	return TRUE;	
}

BOOL CPddUart::SET_DMA(DWORD DmaNum, DWORD DmaCh, BOOL isTX)
{
	
	DWORD dmairq = IRQ_DMA;
	int retTxInter;
	int retRxInter;
	ptSYSTEM_PARAM ptPhySysparam;
	ptSYSTEM_PARAM ptVtSysparam;

	ptPhySysparam = (ptSYSTEM_PARAM)SYSTEM_PARAM_BASEADDRESS;
	ptVtSysparam = (ptSYSTEM_PARAM)pVirtualDmaBufAddr;

	if(isTX){
		//TX setting for UART DMA
		PTV_DMA(DmaNum,&pVirtualDmaAddrTX);
		SET_DMA_BUFFER(DmaNum,DmaCh,isTX);	

		KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dmairq, sizeof(UINT32), &retTxInter, sizeof(UINT32), NULL);
		m_dwSysIntrDMATx = retTxInter;
		SetupDmaISR(pVirtualDmaAddrTX, DmaCh,retTxInter );
		
		m_DMATxEvent= CreateEvent(0,FALSE,FALSE,NULL);
		InterruptInitialize(m_dwSysIntrDMATx,m_DMATxEvent,0,0);
		
	}
	else{
		//RX setting for UART DMA
		PTV_DMA(DmaNum,&pVirtualDmaAddrRX);
		SET_DMA_BUFFER(DmaNum,DmaCh,isTX);	

		KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dmairq, sizeof(UINT32), &retRxInter, sizeof(UINT32), NULL);
		m_dwSysIntrDMARx = retRxInter;
		SetupDmaISR(pVirtualDmaAddrRX, DmaCh,retRxInter );
		
		m_DMARxEvent= CreateEvent(0,FALSE,FALSE,NULL);
		InterruptInitialize(m_dwSysIntrDMARx,m_DMARxEvent,0,0);
		
	}
	return TRUE;	
}

BOOL CPddUart::SetupDmaISR(unsigned long* Pdma, DWORD nDmaCh, DWORD sysintr)
{

	GIISR_INFO dmainfo;
	//load isr, irq
	DDKISRINFO ddi;
	DWORD dmairq = IRQ_DMA;
	
    if (GetIsrInfo(&ddi)!=ERROR_SUCCESS) 
		return FALSE;

	m_hDMAIsrHandler = LoadIntChainHandler(ddi.szIsrDll,_T("DMAUARTISRHandler"),dmairq);
	if(m_hDMAIsrHandler == NULL){
		DWORD dwRet = GetLastError();	
		RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[SERIAL      ]Load DMA IntChainHandler return fail %d\r\n"),dwRet));			
		return FALSE;
	}
	else{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]Load DMA IntChainHandler  success\r\n")));					
	}

	memset(&dmainfo, 0, sizeof(GIISR_INFO));
	dmainfo.CheckPort = TRUE; //irq happen then chk port <-> false means don't chk port == no shared IRQ
	dmainfo.PortIsIO = FALSE; // memory mapped - not real port (TRUE only used X86)
	dmainfo.PortSize = sizeof(DWORD);// size of HwUART_CHST
	dmainfo.UseMaskReg = FALSE;
	dmainfo.MaskAddr = 0;
	dmainfo.Mask = Hw3;	//intr status bit in GDMA CHCTRL reg.
	dmainfo.SysIntr = sysintr;

	PGDMACTRL pdma = (PGDMACTRL)Pdma;
	switch(nDmaCh){
		case 0:
			dmainfo.PortAddr = (DWORD)&(pdma->CHCTRL0);
			break;
		case 1:
			dmainfo.PortAddr = (DWORD)&(pdma->CHCTRL1);
			break;
		case 2:
			dmainfo.PortAddr = (DWORD)&(pdma->CHCTRL2);
			break;
	}
	if (!KernelLibIoControl(m_hDMAIsrHandler, IOCTL_GIISR_INFO,  &dmainfo, sizeof(GIISR_INFO), NULL, 0, 0)){
		DWORD dwRet = GetLastError();	
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]IOCTL_GIISR_INFO return fail %d\r\n"),dwRet));			
		return FALSE;
	}
	else{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[SERIAL      ]IOCTL_GIISR_INFO return success\r\n")));
	}

	return TRUE;
}



BOOL CPddUart::SET_DMA_BUFFER(DWORD DmaNum, DWORD DmaCh, BOOL isTX)
{
	ptSYSTEM_PARAM ptPhySysparam;
	ptSYSTEM_PARAM ptVtSysparam;
	unsigned long* vTargetBuf;
	unsigned long* pTargetBuf;	
	
	ptPhySysparam = (ptSYSTEM_PARAM)SYSTEM_PARAM_BASEADDRESS;
	ptVtSysparam = (ptSYSTEM_PARAM)pVirtualDmaBufAddr;
	

	switch(DmaNum){
		case 0:
			switch(DmaCh){
			case 0:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA0.CH0_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA0.CH0_BUFFER;
				break;
			case 1:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA0.CH1_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA0.CH1_BUFFER;
				break;
			case 2:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA0.CH2_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA0.CH2_BUFFER;
				break;
			}
			break;
		case 1:
			switch(DmaCh){
			case 0:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA1.CH0_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA1.CH0_BUFFER;
				break;
			case 1:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA1.CH1_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA1.CH1_BUFFER;
				break;
			case 2:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA1.CH2_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA1.CH2_BUFFER;
				break;
			}
			break;
		case 2:
			switch(DmaCh){
			case 0:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA2.CH0_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA2.CH0_BUFFER;
				break;
			case 1:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA2.CH1_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA2.CH1_BUFFER;
				break;
			case 2:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA2.CH2_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA2.CH2_BUFFER;
				break;
			}
			break;
		case 3:
			switch(DmaCh){
			case 0:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA3.CH0_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA3.CH0_BUFFER;
				break;
			case 1:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA3.CH1_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA3.CH1_BUFFER;
				break;
			case 2:
				vTargetBuf		=(unsigned long*)ptVtSysparam->DMA3.CH2_BUFFER;	  
				pTargetBuf		=(unsigned long*)ptPhySysparam->DMA3.CH2_BUFFER;
				break;
			}
			break;
	}

	if(isTX){
		TXBUFFADDR = vTargetBuf;
		TXBUFFADDR_PHY = pTargetBuf; 
	}
	else{
		RXBUFFADDR = vTargetBuf;
		RXBUFFADDR_PHY = pTargetBuf; 
	}
	return TRUE;
}