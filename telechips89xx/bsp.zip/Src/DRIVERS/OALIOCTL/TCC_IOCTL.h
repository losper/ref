/****************************************************************************
 *   FileName    : TCC_IOCTL.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/


typedef struct _Intr{
	DWORD  nIRQ;
	HANDLE Event;
}tINTR;

typedef struct _UID_MEM {
	DWORD dwHwBaseAddress;
	DWORD dwAllocBaseAddress;
	DWORD dwSize;
}UID_MEM;

BOOL TCC_IOCTL_HalRequestSysintr(   DWORD dwIoControlCode,
								 PBYTE pInBuf,
								 DWORD nInBufSize,
								 PBYTE pOutBuf,
								 DWORD nOutBufSize,
								 PDWORD pBytesReturned);
BOOL TCC_IOCTL_HalReleaseSysIntr(   DWORD dwIoControlCode,
								 PBYTE pInBuf,
								 DWORD nInBufSize,
								 PBYTE pOutBuf,
								 DWORD nOutBufSize,
								 PDWORD pBytesReturned);
BOOL TCC_IOCTL_HalVirtualCopy(   DWORD dwIoControlCode,
							  PBYTE pInBuf,
							  DWORD nInBufSize,
							  PBYTE pOutBuf,
							  DWORD nOutBufSize,
							  PDWORD pBytesReturned);

