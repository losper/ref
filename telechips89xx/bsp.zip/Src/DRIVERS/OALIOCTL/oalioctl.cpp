//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
/* File:    oaliocontrol.cpp
 *
 * Purpose: OAL updatabale module which will be called from kernel for user
 * mode threads. OEMs can update the list of ioctls supported by user mode
 * threads by updating the IOControl function in this module.
 *
 * OEMs can do the following updates:
*
 * a) Change this dll name: In which case make sure to update oalioctl.h
 * file in public\common\oak\inc to update OALIOCTL_DLL symbol to relfect the 
 * new name for this dll.
*
 * b) Change the entry point name from IOControl to something else: In this case
 * make sure to update OALIOCTL_DLL_IOCONTROL symbol in public\common\
 * oak\inc\oalioctl.h file to reflect the new name of the entry point
*
 * c) Add/Delete from the list of ioctls in IOControl function below: This entry point
 * is called whenever a user mode thread calls into kernel via KernelIoControl or
 * via KernelLibIoControl (with KMOD_OAL). For kernel mode threads, all the 
 * handling for KernelIoControl and KernelLibIoControl happens inside kernel and
 * this module is not involved.
 *
 */

#include <windows.h>
#include <oalioctl.h>
#include "bsp.h"
#include "TCC_IOCTL.H"
#include "tcc_ckc.h"

#include "ioctl_pwrstr.h"

BOOL
pwr_ioctl(
	DWORD dwIoControlCode,
	PBYTE pInBuf,
	DWORD nInBufSize,
	PBYTE pOutBuf,
	DWORD nOutBufSize,
	PDWORD pBytesReturned
	);

PFN_Ioctl g_pfnExtOALIoctl;

//------------------------------------------------------------------------------
// Function: IOControl
//
// Arguments: Same signature as KernelIoControl
//    DWORD dwIoControlCode: io control code
//    PBYTE pInBuf: pointer to input buffer
//    DWORD nInBufSize: length of input buffer in bytes
//    PBYTE pOutBuf: pointer to out buffer
//    DWORD nOutBufSize: length of output buffer in bytes
//    PDWORD pBytesReturned: number of bytes returned in output buffer
//
// Return Values:
// If the function call is successful, TRUE is returned from this API call.
// If the function call is not successful, FALSE is returned from this API
// call and the last error is set to:
// a) ERROR_INVALID_PARAMETER: any of the input arguments are invalid
// b) ERROR_NOT_SUPPORTED: given ioctl is not supported
// c) any other ioctl set by OAL code
//
// Abstract:
// This is called by kernel whenever a user mode thread makes a call to
// KernelIoControl or KernelLibIoControl with io control code being an OAL
// io control code. OEMs can override what ioctls a user mode thread can call
// by enabling or disabling ioctl codes in this function.
//
//------------------------------------------------------------------------------

DWORD buf=0;

EXTERN_C
BOOL
IOControl(
    DWORD dwIoControlCode,
    PBYTE pInBuf,
    DWORD nInBufSize,
    PBYTE pOutBuf,
    DWORD nOutBufSize,
    PDWORD pBytesReturned
    )
{
    BOOL fRet = FALSE;

    //
    // By default the following ioctls are supported for user mode threads.
    // If a new ioctl is being added to this list, make sure the corresponding
    // data associated with that ioctl is marshalled properly to the OAL
    // ioctl implementation. In normal cases, one doesn't need any 
    // marshaling as first level user specified buffers are already validated 
    // by kernel that:
    // -- the buffers are within the user process space
    // Check out IsValidUsrPtr() function in vmlayout.h for details on kernel
    // validation of user specified buffers. Kernel doesn't validate that the
    // buffers are accessible; it only checks that the buffer start and end
    // addresses are within the user process space.
    //


    switch (dwIoControlCode) {     
        case IOCTL_HAL_GET_CACHE_INFO:
        case IOCTL_HAL_GET_DEVICE_INFO:
        case IOCTL_HAL_GET_DEVICEID:
        case IOCTL_HAL_GET_UUID:
        case IOCTL_PROCESSOR_INFORMATION:
            // request is to service the ioctl - forward the call to OAL code
            // OAL code will set the last error if there is a failure
            fRet = (*g_pfnExtOALIoctl)(dwIoControlCode, pInBuf, nInBufSize, pOutBuf, nOutBufSize, pBytesReturned);
        break;
		case IOCTL_HAL_REQUEST_SYSINTR:
			{
				fRet = TCC_IOCTL_HalRequestSysintr( dwIoControlCode, pInBuf, nInBufSize, pOutBuf, nOutBufSize, pBytesReturned);
			}
		break;
		case IOCTL_HAL_RELEASE_SYSINTR:
			{
				fRet = TCC_IOCTL_HalReleaseSysIntr( dwIoControlCode, pInBuf, nInBufSize, pOutBuf, nOutBufSize, pBytesReturned);
			}
			break;
		case IOCTL_HAL_VIRTUALCOPY:
			{
				fRet = TCC_IOCTL_HalVirtualCopy( dwIoControlCode, pInBuf, nInBufSize, pOutBuf, nOutBufSize, pBytesReturned);
			}
			break;
		case IOCTL_HAL_TCCCKC:
		case IOCTL_HAL_REBOOT:
			{
				fRet = KernelIoControl(dwIoControlCode, pInBuf, nInBufSize, pOutBuf, nOutBufSize, pBytesReturned);
			}
			break;
		case IOCTL_HAL_DONE:
			{
				buf=(DWORD)*pInBuf;
				InterruptDone(buf);
				fRet = TRUE;

			}
		case IOCTL_PWR_CONTROL:
			{
				fRet = pwr_ioctl(dwIoControlCode, pInBuf, nInBufSize, pOutBuf, nOutBufSize, pBytesReturned);
			}
			break;
        default:
            SetLastError(ERROR_NOT_SUPPORTED);
        	break;
    }

    return fRet;
}

BOOL
WINAPI
DllMain(HANDLE hDll, DWORD dwReason, LPVOID lpReserved)
{
    switch (dwReason)
    {
        case DLL_PROCESS_ATTACH:
            DisableThreadLibraryCalls((HINSTANCE)hDll);
            g_pfnExtOALIoctl = (PFN_Ioctl) lpReserved;
        break;
        case DLL_PROCESS_DETACH:
        default:
        break;
    }

    return TRUE;
}


BOOL
pwr_ioctl(
	DWORD dwIoControlCode,
	PBYTE pInBuf,
	DWORD nInBufSize,
	PBYTE pOutBuf,
	DWORD nOutBufSize,
	PDWORD pBytesReturned
	)
{
	HANDLE hDevice= INVALID_HANDLE_VALUE;

	stpwrioctl *pCmd  = (stpwrioctl*)pInBuf;
//	stpwrinfo  *pInfo = (stpwrinfo *)pOutBuf;

	BOOL bRet;

	if (pCmd == NULL)
	{
		return FALSE;
	}

	switch(pCmd->deviceid)
	{
		/*
		----------------------------------------------------------------------------------------------------------------------------------
		case DEVICE_XXXX:
			hDevice = CreateFile(TEXT("XXXX1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
			break;
		----------------------------------------------------------------------------------------------------------------------------------
		*/
		case DEVICE_LCD:
		{
			hDevice = CreateFile(TEXT("BKL1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		} break;
		case DEVICE_BACKLIGHT:
		{
			hDevice = CreateFile(TEXT("BKL1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		} break;
		case DEVICE_TVOUT:
		{
			hDevice = CreateFile(TEXT("TVO1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		} break;
		case DEVICE_HDMI:
		{
			hDevice = CreateFile(TEXT("HDM1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		} break;
            case DEVICE_OHCI:
		{
			hDevice = CreateFile(TEXT("HCD1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		} break;
            case DEVICE_KEYPAD:
		{
			hDevice = CreateFile(TEXT("KEY1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		} break;
            case DEVICE_ADC:
		{
			hDevice = CreateFile(TEXT("ADC1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		} break;
            case DEVICE_GPIOEXP:
		{
			hDevice = CreateFile(TEXT("GXP1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		} break;
		default :		
			return FALSE;	//break;
	}

	if (INVALID_HANDLE_VALUE == hDevice)
	{
		return FALSE;
	}

	bRet = DeviceIoControl(hDevice, dwIoControlCode, pCmd, sizeof(stpwrioctl), pOutBuf, nOutBufSize, pBytesReturned, NULL);

	CloseHandle(hDevice);

	return bRet;
}
