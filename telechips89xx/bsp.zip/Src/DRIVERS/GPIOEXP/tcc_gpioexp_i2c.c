/****************************************************************************
*   FileName    : tcc_gpioexp_i2c.c
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/

/*****************************************************************************
* Header Files Include
******************************************************************************/
#include "tcc_gpioexp.h"
#include "tcc_gpioexp_i2c.h"
#include "ioctl_code.h"

/*****************************************************************************
* Defines
******************************************************************************/

/*****************************************************************************
* Enum
******************************************************************************/

/*****************************************************************************
* Type Defines
******************************************************************************/

/*****************************************************************************
* Structures
******************************************************************************/

/*****************************************************************************
* External Variables
******************************************************************************/

/*****************************************************************************
* Global Variables
******************************************************************************/
HANDLE ghGXPI2C;



/*****************************************************************************
* Local Functions
******************************************************************************/


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int	tea_initializei2c(void)
{
    ghGXPI2C =  CreateFile(L"I2C1:",
                                        GENERIC_READ | GENERIC_WRITE,
                                        0,
                                        0,
                                        OPEN_EXISTING,
                                        FILE_ATTRIBUTE_NORMAL,
                                        0);
    if(!ghGXPI2C)
        RETAILMSG(1,(TEXT("ERROR: Can't open I2C Driver for GXP!!\n")));
    return 0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int	tea_terminatei2c(void)
{
    if(ghGXPI2C)
        CloseHandle(ghGXPI2C);
    return 0;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int tea_readi2c(unsigned int uiDestAddr, unsigned int uiPortMode, unsigned int uiCount, unsigned char* pBuffer)
{
    BOOL nRet=0;
    DWORD returned_bytes;
    I2C_Param sendParam;
    RetParam  recvParam;
    DWORD   cnt;
    BYTE*   pTemp = pBuffer;
    BYTE    cmd;

    if(uiCount>2)
        uiCount = 2;
    
    if(uiDestAddr == PCA9539HIGH && uiPortMode == PORTINPUT)
    {
        cmd = CMD_PORT1_INPUT;
    }
    else
    {
    if(uiDestAddr == PCA9538)
        cmd = CMD_PORT_OUTPUT;
    else
    	cmd = CMD_PORT0_OUTPUT;
    }
    
    for(cnt=0; cnt<uiCount;cnt++)
    {
    sendParam.DeviceAddr = (BYTE)uiDestAddr; //uiHbyte;
    sendParam.nWriteByte = 1;
    sendParam.pWriteBuffer =&cmd;//ucSzDataBuff;
        sendParam.nReadByte = 1;
        sendParam.pReadBuffer = pTemp;
    sendParam.nPort = 0;
        sendParam.nMode = 1;
    sendParam.nTimeout	 = 100;

    nRet = DeviceIoControl(ghGXPI2C,
					IOCTL_I2C_READ,
					&sendParam,
					sizeof(I2C_Param),
					&recvParam,
					sizeof(RetParam),
					&returned_bytes,
					NULL);
        cmd=cmd+1;
        pTemp++;
    }
    
    return nRet;
}
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int	tea_writei2c(unsigned int uiDestAddr, unsigned int uiCount, unsigned char* pBuffer)
{
	BOOL nRet=0;
	DWORD returned_bytes;
	I2C_Param sendParam;
        						
	sendParam.DeviceAddr = (BYTE)uiDestAddr; //uiHbyte;
	sendParam.nWriteByte = uiCount;
	sendParam.pWriteBuffer =(BYTE *)pBuffer;//ucSzDataBuff;
	sendParam.nPort = 0;
    	sendParam.nMode = 0;
	sendParam.nTimeout	 = 100;

	nRet = DeviceIoControl(ghGXPI2C,
		IOCTL_I2C_WRITE,
		&sendParam,
		sizeof(I2C_Param),
		0,
		0,
		&returned_bytes,
		0) ;
    
	return nRet;
}
/* end of file */

