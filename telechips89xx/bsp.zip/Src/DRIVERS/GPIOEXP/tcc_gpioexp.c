/****************************************************************************
 *   FileName    : tcc_gpioexp.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <windows.h>

#ifdef TCC89XX
#include "bsp.h"
#endif

#include "tcc_gpio.h"
#include "tcc_gpioexp.h"
#include "tcc_gpioexp_i2c.h"

#include "ioctl_code.h"
#include "ioctl_pwrstr.h"


/************************************************************************************************
* Global Defines
************************************************************************************************/
#define MSGFLAG FALSE // for Test
//#define INTRTEST

// you can use this option on EVB 1.0(hardware fixed) only
//#define USE_LOWPOWERSLEEP 


#if DEBUG
#ifdef DEBUG
#define ZONE_INIT 0x0001
DBGPARAM dpCurSettings = {
	_T("I2C"), {
		_T("Load"),
			_T("Dispatcher"),
			_T("Shutdown"),
			_T("Power"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""), 
			_T(""), 
			_T(""),
			_T(""), 
			_T("Init"), 
			_T("Warnings"), 
			_T("Errors") },
			0xC020 };
#endif
#endif



 /************************************************************************************************
* Global Handle
************************************************************************************************/
#ifdef INTRTEST
static HANDLE ghGxpIntr;
static HANDLE ghGxpIntrThread;
#endif


/************************************************************************************************
* Type Define
************************************************************************************************/





/************************************************************************************************
* Global Variable define
************************************************************************************************/
static unsigned short   GPORTDATA[3];
static unsigned char    gxpCfg[3];
static unsigned char    gxpData[3];
static stpwrinfo gxppwrinfo = {PWR_STATUS_ON};



#ifdef INTRTEST
UINT32    gPortVal;
UINT32 gGxpIRQ = IRQ_EI6;
UINT32 gGxpSysIntr;

PPIC pPIC = NULL;
PGPIO pGPIO = NULL;
#endif


 /************************************************************************************************
* FUNCTION		: DWORD   GXP_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
#ifdef INTRTEST
DWORD GXP_PortChangeDetectThread(PVOID  pArgs)
{
    DWORD ret;
    BYTE*   pPortVal;

    BITSET(pPIC->POL0, Hw9);  //set polarity = Active Low
    BITCLR(pPIC->MODE0, Hw9); //Set Interrupt Mode - edge triggered
    BITCLR(pGPIO->GPAEN, Hw15); // GPIOA15 Input Mode
    BITCSET(pGPIO->EINTSEL1, Hw22-Hw16, Hw20-Hw16); //set externall interrupt to GPIO A15
    BITCLR(pGPIO->GPAFN1, Hw32-Hw28); //set gpio function to GPIO A15

    ghGxpIntr = CreateEvent(NULL, FALSE, FALSE, NULL);
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[GXP         ] Port Change Detect Thread Run....\r\n")));

    // Request System Interrupt for GXP Port Status Change that is EINT6
    ret = KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &gGxpIRQ, sizeof(UINT32), &gGxpSysIntr, sizeof(UINT32), NULL);
    
    if (ret == NULL)
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[GXP         ] Failed to request sysintr value for GXP Port Change interrupt.\r\n")));
	
    ret = InterruptInitialize(gGxpSysIntr, ghGxpIntr, 0, 0);
    
    if (ret == NULL) 
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[GXP         ] Failed to initialize Interrupt.\r\n")));

    while (1)
    {
        ret = WaitForSingleObject(ghGxpIntr, INFINITE);
        if( ret == WAIT_OBJECT_0)
        {   
             // TO DO : read Port and store portval to GXPPORT
            tea_readi2c(PCA9539HIGH, PORTINPUT, 1, &gPortVal);
            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[GXP         ]Port Change Interrupt: %X\r\n"), (gPortVal&0xF)));
            
            InterruptDone(gGxpSysIntr);//clr Interrupt
        }
    }
}
#endif


/************************************************************************************************
* FUNCTION		: 
BOOL DllEntry(HINSTANCE   hinstDll,	   //@parm Instance pointer. 
			  DWORD       dwReason,    //@parm Reason routine is called. 
			  LPVOID      lpReserved   //@parm system parameter. 
			  )
* DESCRIPTION	:  
*
************************************************************************************************/
BOOL DllEntry(HINSTANCE   hinstDll,	   /*@parm Instance pointer. */
			  DWORD       dwReason,    /*@parm Reason routine is called. */
			  LPVOID      lpReserved   /*@parm system parameter. */
			  )
{
	if (dwReason == DLL_PROCESS_ATTACH) {
            DEBUGREGISTER(hinstDll);
            DEBUGMSG(ZONE_INIT, (TEXT("port process attach\r\n")));
            DisableThreadLibraryCalls((HMODULE) hinstDll);
	}
	
	if (dwReason == DLL_PROCESS_DETACH) {
		DEBUGMSG(ZONE_INIT, (TEXT("process detach detach\r\n")));
	}
	
	return (TRUE);
}


 /************************************************************************************************
* FUNCTION		: DWORD   GXP_Init(LPCTSTR pContext, DWORD dwBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   GXP_Init(LPCTSTR pContext, DWORD dwBusContext)
{
#ifdef INTRTEST
    DWORD IDThread;
#endif
    RETAILMSG(1,(TEXT("[GXP         ]+Init\n")));
    
    //Get I2C Handle
    tea_initializei2c();

    tea_readi2c(PCA9539HIGH, PORTOUTPUT, 2, (unsigned char*)&GPORTDATA[0]);
    tea_readi2c(PCA9539LOW, PORTOUTPUT, 2, (unsigned char*)&GPORTDATA[1]);
    tea_readi2c(PCA9538, PORTOUTPUT, 1, (unsigned char*)&GPORTDATA[2]);
    RETAILMSG(1,(TEXT("[GXP         ] InitState : %X %X %X\n"),GPORTDATA[0],GPORTDATA[1],GPORTDATA[2] ));

#ifdef INTRTEST
    pPIC = (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);
    pGPIO = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);

    ghGxpIntrThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GXP_PortChangeDetectThread, NULL, 0, &IDThread);

    if(ghGxpIntrThread == NULL)
        return FALSE; // CreateThread Fail
        
#endif

        
    RETAILMSG(1,(TEXT("[GXP         ]-Init\n")));	
    return TRUE;
}

 /************************************************************************************************
* FUNCTION		: DWORD   GXP_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   GXP_Deinit( DWORD hDeviceContext )
{
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]+Deinit\n")));
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]-Deinit\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: DWORD   GXP_Open(  DWORD hDeviceContext,  DWORD AccessCode,  DWORD ShareMode )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   GXP_Open(  DWORD hDeviceContext,  DWORD AccessCode,  DWORD ShareMode )
{
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]+Open\n")));
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]-Open\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: DWORD   GXP_Close(DWORD hOpenContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   GXP_Close(DWORD hOpenContext )
{
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]+Close\n")));
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]-Close\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: BOOL   GXP_IOControl( DWORD Handle, DWORD dwIoControlCode, 
*				                                     PBYTE pInBuf, DWORD nInBufSize, 
*				                                    PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL   GXP_IOControl( DWORD Handle, DWORD dwIoControlCode, 
				   PBYTE pInBuf, DWORD nInBufSize, 
				   PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
{
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]+IOControl\n")));    
    switch(dwIoControlCode)
    {
        case IOCTL_PWR_CONTROL:
        {
            stpwrioctl *pCmd  = (stpwrioctl*)pInBuf;

            if (pCmd == NULL)
                return FALSE;

            switch(pCmd->cmd)
            {
                case PWR_CMD_OFF:
                    gxppwrinfo.status = PWR_STATUS_OFF;
                    RETAILMSG(TRUE,(TEXT("[GXP         ]:TESTLOG:GXP Power OFF\n")));
                    break;

                case PWR_CMD_ON:
                    gxppwrinfo.status = PWR_STATUS_ON;
                    RETAILMSG(TRUE,(TEXT("[GXP         ]:TESTLOG:GXP Power ON\n")));
                    break;

                case PWR_CMD_GETSTATUS:
                    memcpy(pOutBuf, &gxppwrinfo, sizeof(stpwrinfo));
                    *pBytesReturned = sizeof(stpwrinfo);
                    break;
       
                default:
                    return FALSE;	//break;
            }
        }
        break;
    }
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]-IOControl\n")));	
    return TRUE;
}


void SetEVMPower(int bOn) //1 on 0 off
{
#ifdef USE_LOWPOWERSLEEP
	//HDMI
	HANDLE hGXP;
	hGXP =CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
    if( INVALID_HANDLE_VALUE!=hGXP )
    {
        DWORD dwByteReturned;

        GXPINFO GxpInfo;

		if(bOn)
			GxpInfo.uiState=ON;
		else
			GxpInfo.uiState=OFF;


        GxpInfo.uiDevice=PCA9539LOW;
     	GxpInfo.uiPort=LCD|CAM;
		if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
        {
            RETAILMSG(1,(TEXT("ERROR: PCA9539LOW Power OFF\r\n")));
        }
		
		GxpInfo.uiDevice=PCA9539HIGH;
        GxpInfo.uiPort=RTCRST_|BTWAKE;
		
        if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
        {
            RETAILMSG(1,(TEXT("ERROR: PCA9539HIGH Power OFF\r\n")));
        }
		
		GxpInfo.uiDevice=PCA9538;
        GxpInfo.uiPort=SATAHDMI;		

		
        if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
        {
            RETAILMSG(1,(TEXT("ERROR: PCA9538 Power OFF\r\n")));
        }
				
		
		CloseHandle(hGXP);
    }
    else
    {
        RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
    }
#endif

}
 /************************************************************************************************
* FUNCTION		: DWORD   GXP_PowerUp(DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   GXP_PowerUp(DWORD hDeviceContext )
{
    RETAILMSG(TRUE,(TEXT("[GXP         ]+PowerUp\n")));
    
    gxpCfg[0] = CMD_PORT0_CONFIG;
    gxpCfg[1] = PCA9539H_P0CFG;
    gxpCfg[2] = PCA9539H_P1CFG;

    gxpData[0] = CMD_PORT0_OUTPUT;
    gxpData[1] = ((GPORTDATA[0])&0x00FF);
    gxpData[2] = ((GPORTDATA[0])&0xFF00)>>8;

#ifdef USE_LOWPOWERSLEEP
	gxpData[2] |= RTCRST_|BTWAKE;
#endif

    tea_writei2c(PCA9539HIGH, 3, gxpCfg);
    tea_writei2c(PCA9539HIGH, 3, gxpData);


    gxpCfg[1] = PCA9539L_P0CFG;
    gxpCfg[2] = PCA9539L_P1CFG;
    gxpData[1] = ((GPORTDATA[1])&0x00FF);
    gxpData[2] = ((GPORTDATA[1])&0xFF00)>>8;

#ifdef USE_LOWPOWERSLEEP
	gxpData[1] |= LCD;
#endif
    
    tea_writei2c(PCA9539LOW, 3, gxpCfg);
    tea_writei2c(PCA9539LOW, 3, gxpData);
    
    gxpCfg[0] = CMD_PORT_CONFIG;
    gxpData[0] = CMD_PORT_OUTPUT;
    gxpData[1] = ((GPORTDATA[2])&0x00FF);
    gxpData[2] = ((GPORTDATA[2])&0xFF00)>>8;

#ifdef USE_LOWPOWERSLEEP
	gxpData[1] |= SATAHDMI;
#endif
	
    tea_writei2c(PCA9538, 2, gxpCfg);
    tea_writei2c(PCA9538, 2, gxpData);

   
#ifdef USE_LOWPOWERSLEEP
	SetEVMPower(1); //1 on 0 off
#endif

    RETAILMSG(TRUE,(TEXT("[GXP         ]-PowerUp\n")));	
    return TRUE;
}



 /************************************************************************************************
* FUNCTION		: DWORD   GXP_PowerDown(DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   GXP_PowerDown(DWORD hDeviceContext )
{
    unsigned char cfg[3];
#ifdef USE_LOWPOWERSLEEP	
	SetEVMPower(0); //1 on 0 off
#endif
    RETAILMSG(TRUE,(TEXT("[GXP         ]+PowerDown\n")));

    cfg[0] = CMD_PORT0_CONFIG;
    cfg[1] = 0xFF; 
    cfg[2] = 0xFF; 

#ifdef USE_LOWPOWERSLEEP
    cfg[2] = 0xFF&~(RTCRST_|BTWAKE); 
#endif

    tea_writei2c(PCA9539HIGH, 3, cfg);
	
    cfg[0] = CMD_PORT0_CONFIG;
    cfg[1] = 0xFF; 
    cfg[2] = 0xFF; 
#ifdef USE_LOWPOWERSLEEP
    cfg[1] = 0xFF&~(LCD); // for LCD power control
#endif
    tea_writei2c(PCA9539LOW, 3, cfg);

    cfg[0] = CMD_PORT_CONFIG;
    cfg[1] = 0xFF; 
    cfg[2] = 0xFF; 
#ifdef USE_LOWPOWERSLEEP
    cfg[1] = 0xFF&~(SATAHDMI); // for SATA|HDMI IO control
#endif

    tea_writei2c(PCA9538, 2, cfg);

    RETAILMSG(TRUE,(TEXT("[GXP         ]-PowerDown\n")));	
    return TRUE;
	
}


 /************************************************************************************************
* FUNCTION		: DWORD   GXP_Read(  DWORD hOpenContext,  LPVOID pBuffer,  DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   GXP_Read(  DWORD hOpenContext,  LPVOID pBuffer,  DWORD Count )
{
    PGXPINFO    pGxpInfo = (PGXPINFO)pBuffer;
    
    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]+Read\n")));

    tea_readi2c(pGxpInfo->uiDevice, pGxpInfo->uiPort, Count, &pGxpInfo->uiState);

    if( (pGxpInfo->uiDevice == PCA9538) || ((pGxpInfo->uiDevice == PCA9539HIGH) && (pGxpInfo->uiPort == PORTINPUT)))
        pGxpInfo->uiState &=0x000000FF;
    else
        pGxpInfo->uiState &=0x0000FFFF;

    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]-Read\n")));	

    return Count;
}


 /************************************************************************************************
* FUNCTION		: DWORD   GXP_Write(DWORD hOpenContext,  LPCVOID pBuffer,  DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   GXP_Write(DWORD hOpenContext,  LPCVOID pBuffer,  DWORD Count )
{

    int index;
    int writebyte;
    int ByteCnt, CmdReg, DataReg;	    
    PGXPINFO    pGxpInfo = (PGXPINFO)pBuffer;

    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]+Write\n")));

    switch(pGxpInfo->uiDevice)
    {
        case PCA9539HIGH:
            index = 0;
            writebyte = 3;
            gxpCfg[0] = CMD_PORT0_CONFIG;
            gxpCfg[1] = PCA9539H_P0CFG;
            gxpCfg[2] = PCA9539H_P1CFG;
            
            DataReg = CMD_PORT0_OUTPUT;
            break;

        case PCA9539LOW:
            index = 1;
            writebyte = 3;
            gxpCfg[0] = CMD_PORT0_CONFIG;
            gxpCfg[1] = PCA9539L_P0CFG;
            gxpCfg[2] = PCA9539L_P1CFG;
            
            DataReg = CMD_PORT0_OUTPUT;
            break;

        case PCA9538:
            index = 2;
            writebyte = 2;
            gxpCfg[0] = CMD_PORT_CONFIG;
            gxpCfg[1] = PCA9538_PCFG;
            DataReg = CMD_PORT_OUTPUT;
            break;
    }

    if (pGxpInfo->uiState == ON)
        GPORTDATA[index]|= pGxpInfo->uiPort;
    else
        GPORTDATA[index] &= ~(pGxpInfo->uiPort);

    gxpData[0] = DataReg;
    gxpData[1] = ((GPORTDATA[index])&0x00FF);
    gxpData[2] = ((GPORTDATA[index])&0xFF00)>>8;

    tea_writei2c(pGxpInfo->uiDevice, writebyte, gxpCfg);
    tea_writei2c(pGxpInfo->uiDevice, writebyte, gxpData);

    RETAILMSG(MSGFLAG,(TEXT("[GXP         ]-Write\n")));	
    return Count;
}


