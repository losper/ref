/****************************************************************************
 *   FileName    : TCC_I2C.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCC_I2C_H__
#define __TCC_I2C_H__


#define  IO_CKC_Fxin          120000      //Xin is 12MHz
#define  SCL_CLK			   40000
#define  SCL_CLK_100KHz       0.1

/**********************************************************************
Define I2C Address
**********************************************************************/
#define I2C_WR	0
#define I2C_RD	1


#define	HwI2CM_CTRL_EN_ON					Hw7										// Enabled
#define	HwI2CM_CTRL_EN_OFF					HwZERO									// Disabled
#define	HwI2CM_CTRL_IEN_ON					Hw6										// Enabled
#define	HwI2CM_CTRL_IEN_OFF					HwZERO									// Disabled
#define	HwI2CM_CTRL_MOD_16					Hw5										// 16bit Mode
#define	HwI2CM_CTRL_MOD_8					HwZERO									// 8bit Mode
#define	HwI2CM_CMD_STA_EN					Hw7 									// Start Condition Generation Enabled
#define	HwI2CM_CMD_STA_DIS					HwZERO 									// Start Condition Generation Disabled
#define	HwI2CM_CMD_STO_EN					Hw6 									// Stop Condition Generation Enabled
#define	HwI2CM_CMD_STO_DIS					HwZERO 									// Stop Condition Generation Disabled
#define	HwI2CM_CMD_RD_EN					Hw5 									// Read From Slave Enabled
#define	HwI2CM_CMD_RD_DIS					HwZERO 									// Read From Slave Disabled
#define	HwI2CM_CMD_WR_EN					Hw4 									// Wrtie to Slabe Enabled
#define	HwI2CM_CMD_WR_DIS					HwZERO 									// Wrtie to Slabe Disabled
#define	HwI2CM_CMD_ACK_EN					Hw3 									// Sent ACK Enabled
#define	HwI2CM_CMD_ACK_DIS					HwZERO 									// Sent ACK Disalbed
#define	HwI2CM_CMD_IACK_CLR					Hw0 									// Clear a pending interrupt
#define	HwI2CM_SR_RxACK						Hw7										// 1:Acknowledge received, 0:No Acknowledge received
#define	HwI2CM_SR_BUSY						Hw6										// 1:Start signal detected, 0:Stop signal detected
#define	HwI2CM_SR_AL						Hw5										// 1:The core lost arbitration, 0:The core don't lost arbitration
#define	HwI2CM_SR_TIP						Hw1										// 1:Transfer Complete, 0:Transferring Data
#define	HwI2CM_SR_IF						Hw0										// 1:Interrupt is pending
#define	HwI2CM_TR_CKSEL						Hw5										// Clock Source Select

typedef struct _I2C_Param{
	BYTE	DeviceAddr;
	BYTE	nPort;
	BYTE	nMode;
	BYTE	DUMMY;
	DWORD	nWriteByte;
	DWORD	nReadByte;
	BYTE	*pWriteBuffer;
	BYTE	*pReadBuffer;
	DWORD	nTimeout;
} I2C_Param;

typedef struct _RetParam{
	DWORD nReadByte;
	BYTE *pReadBuffer;
} RetParam;

DWORD	I2C_Init(LPCTSTR pContext, LPCVOID lpvBusContext);
BOOL	I2C_Deinit( DWORD hDeviceContext );
DWORD	I2C_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode );
BOOL	I2C_Close( DWORD hOpenContext );
BOOL	I2C_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut );

void	I2C_PowerUp( DWORD hDeviceContext );
void	I2C_PowerDown( DWORD hDeviceContext );
DWORD	I2C_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count );
DWORD	I2C_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count );
DWORD	I2C_Seek( DWORD hOpenContext, long Amount, WORD Type );

#endif //__TCC_I2C_H__