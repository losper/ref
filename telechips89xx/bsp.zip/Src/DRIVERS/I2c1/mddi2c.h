/****************************************************************************
*   FileName    : i2c.h
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/

class CPddI2C {
public:
	CPddI2C();
	~CPddI2C();

	BOOL I2C_Init(void);
	BOOL I2C_DeInit(void);
	BOOL I2C_Open(void);
	BOOL I2C_Close(void);
	BOOL I2C_Read(void);
	BOOL I2C_Write(void);
public:
	
	BOOL  bInit;
	DWORD dwOpenCount;

}