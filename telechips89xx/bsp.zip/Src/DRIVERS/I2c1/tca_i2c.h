/****************************************************************************
 *   FileName    : tca_i2c.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCA_I2C_H__
#define __TCA_I2C_H__

#ifdef __KERNEL__
#	if defined(_TCC79x_)
#		include <asm/arch/tcc79x.h>
#	elif defined(_TCC83x_)
#		include <asm/arch/tcc83x_virt.h>
#	endif
#else
#	if defined(_TCC79x_)
#		include "TCC79x_Virtual.h"
#	elif defined(_TCC83x_)
#		include "TCC83x_Virtual.h"
#	endif
#endif


extern void tca_i2c_reset(void);
extern void tca_i2c_setgpio(int ch);
extern void tca_i2c_setclock(int ch);


#endif	//__TCA_I2C_H__

