
/****************************************************************************
 *   FileName    : tca_i2c.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifdef __KERNEL__
#include "tca_i2c.h"
#include <linux/delay.h>
#define I2C_SLEEP(x) msleep(x)
#else
#include "tca_i2c.h"
#include <windows.h>
#define I2C_SLEEP(x) Sleep(x)
#endif


/*****************************************************************************
* Function Name : tca_i2c_reset()
* Description: I2C controller reset
******************************************************************************/
void tca_i2c_reset(void)
{ 
	BITSET(HwSWRESET, HwSWRESET_I2C_ON);
	BITCLR(HwSWRESET, HwSWRESET_I2C_ON);
}

/*****************************************************************************
* Function Name : tca_i2c_setgpio()
* Description: I2C port configuration
* input parameter:
*       int ch;   // I2C master channel
******************************************************************************/
void tca_i2c_setgpio(int ch)
{
	if (ch == 0) {
#ifdef _TCC79x_
        BITCSET(HwPORTCFG11, Hw8-Hw4, Hw4);		// SCL0, SDA0 select
#elif _TCC83x_
        BITCLR(HwNGSEL_E, Hw5|Hw6);				// SCL0, SDA0 select
        BITSET(HwGSEL_E, Hw1);
#endif
    } else if (ch == 1) {
#ifdef _TCC79x_
        BITCSET(HwPORTCFG8, Hw32-Hw28, Hw28);	// SDA1 select
        BITCSET(HwPORTCFG7, Hw4-Hw0, Hw0);		// SCL1 select
#elif _TCC83x_
        BITCLR(HwNGSEL_F, Hw14|Hw15);			// SCL1, SDA1 select
        BITSET(HwGSEL_F, Hw1);
#endif
    }

    BITSET(HwBCLKCTR, HwBCLKCTR_I2C_ON);		// Bus Enable
}

/*****************************************************************************
* Function Name : tca_i2c_setclock()
* Description: I2C clock configuration
* input parameter:
*       int ch;   // I2C master channel
******************************************************************************/
void tca_i2c_setclock(int ch)
{
	if (ch == 0) {
		//I2C Channel 0 setting 100kHz
		HwI2CMCH0_PRES = 7; // (4.1M /100K)/5 -1
		HwI2CMCH0_CTRL = HwI2CM_CMD_STA_EN | HwI2CM_CMD_STO_EN|HwI2CM_CTRL_MOD_8;
		BITSET( HwI2CMCH0_CMD, HwI2CMCH0_CMD_IACK_CLR);
		I2C_SLEEP(1);
		BITSET( HwI2CMCH0_CMD, HwI2CMCH0_CMD_IACK_CLR);
		
    } else if (ch == 1) {
    	//I2C Channel 1 setting 400kHz
#ifdef __KERNEL__
		HwI2CMCH1_PRES = 1; // (4.1M /400K)/5 -1
#else
		/* WinCE Required Frequency */
		HwI2CMCH1_PRES = 2; // (4.1M /400K)/5 -1
#endif
		HwI2CMCH1_CTRL = HwI2CM_CMD_STA_EN | HwI2CM_CMD_STO_EN|HwI2CM_CTRL_MOD_8;
		BITSET( HwI2CMCH1_CMD, HwI2CMCH1_CMD_IACK_CLR);
		I2C_SLEEP(1);
		BITSET( HwI2CMCH1_CMD, HwI2CMCH1_CMD_IACK_CLR);
    }
}

/* end of source */
