
/****************************************************************************
 *   FileName    : TCC_I2C.CPP
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <Windows.h>
#include "bsp.h"

#include "TCC89x_Physical.h"
#include "TCC89x_Structures.h"
#include "TCC_I2C.h"
#include "ioctl_code.h"
#include "tcc_ckc.h"
#include "tcc_gpio.h"

#ifdef DEBUG

DBGPARAM dpCurSettings = {
    _T("usbmsfn"),
    {
        _T("Error"), _T("Warning"), _T("Init"), _T("Function"),
        _T("Comments"), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""), 
        _T(""), _T(""), _T(""), _T("")
    },
    0x5
};

#endif // DEBUG
/************************************************************************************************
* Global Handle
************************************************************************************************/
HANDLE gCommandEventChannel0;
HANDLE gCommandEventChannel1;
HANDLE gInterruptEvent;
HANDLE gI2CINTThread;
HANDLE gMutexAll;     	// mutex handle




/************************************************************************************************
* Global Variable define
************************************************************************************************/
DWORD m_nIrq,m_nSysIrq;
BOOL  m_bisRunning;
const TCHAR *gMutexAllName = _T("TCC_I2C");
PI2C pI2C;
PSMUI2C pSMUI2C;
/************************************************************************************************
* Global Defines
************************************************************************************************/
#define LOGLEVEL DBG_ERROR|DBG_WARN|DBG_TRACE|DBG_LOG

/************************************************************************************************
* FUNCTION		: 
BOOL DllEntry(HINSTANCE   hinstDll,	   //@parm Instance pointer. 
			  DWORD       dwReason,    //@parm Reason routine is called. 
			  LPVOID      lpReserved   //@parm system parameter. 
			  )
* DESCRIPTION	:  
*
************************************************************************************************/
BOOL DllEntry(HINSTANCE   hinstDll,	   /*@parm Instance pointer. */
			  DWORD       dwReason,    /*@parm Reason routine is called. */
			  LPVOID      lpReserved   /*@parm system parameter. */
			  )
{
	if (dwReason == DLL_PROCESS_ATTACH) {
		DEBUGREGISTER(hinstDll);
		DEBUGMSG(ZONE_INIT, (TEXT("port process attach\r\n")));
		DisableThreadLibraryCalls((HMODULE) hinstDll);
	}
	
	if (dwReason == DLL_PROCESS_DETACH) {
		DEBUGMSG(ZONE_INIT, (TEXT("process detach detach\r\n")));
	}
	
	return (TRUE);
}
#if 0
/************************************************************************************************
* FUNCTION		: DWORD ReadChannel0(BYTE deviceAddr, BYTE writeBytes, BYTE* pWriteBuffer, BYTE readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL I2CIntrSetting(void)
{
	
	DDKISRINFO ddi;
	if (GetIsrInfo(&ddi)!=ERROR_SUCCESS) 
		return FALSE;

	//Install ISR 
	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[I2C         ]ddi.dwIrq [%d]\r\n"),ddi.dwIrq));		
	m_hUartIsrHandler = LoadIntChainHandler(ddi.szIsrDll,ddi.szIsrHandler,ddi.dwIrq);
	if(m_hUartIsrHandler == NULL){
		DWORD dwRet = GetLastError();	
		RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[I2C         ]LoadIntChainHandler return fail %d\r\n"),dwRet));			
		return FALSE;
	}
	else{
		RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[I2C         ]LoadIntChainHandler  success\r\n")));					
	}


	// Set up ISR handler
	if(m_hUartIsrHandler){
		GIISR_INFO Info;
		memset(&Info, 0, sizeof(GIISR_INFO));
		Info.CheckPort = TRUE; //irq happen then chk port <-> false means don't chk port == no shared IRQ
		Info.PortIsIO = FALSE; // memory mapped - not real port (TRUE only used X86)
		Info.SysIntr = ddi.dwSysintr;
		Info.PortSize = sizeof(DWORD);// size of HwUART_CHST
		Info.UseMaskReg = FALSE;
		Info.MaskAddr = 0;

		switch(nComNumber)	{
		case 1:
			Info.Mask = Hw5;	
			break;
		case 2:			
			Info.Mask = Hw1;	
			break;
		default:
			Info.Mask = Hw5;	
			break;
		}

		PUARTPORTMUX pPortMux = (PUARTPORTMUX)pVirtualPortMuxAddr;
		Info.PortAddr = (DWORD)&(pPortMux->CHST);


		if (!KernelLibIoControl(m_hUartIsrHandler, IOCTL_GIISR_INFO,  &Info, sizeof(GIISR_INFO), NULL, 0, 0)){
			DWORD dwRet = GetLastError();	
			RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[I2C         ]KernelLibIoControl return fail %d\r\n"),dwRet));			
			return FALSE;
		}
		else
			RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[I2C         ]KernelLibIoControl return success\r\n")));
	}

	return TRUE;	
}
#endif
/************************************************************************************************
* FUNCTION		: DWORD ReadChannel0(BYTE deviceAddr, BYTE writeBytes, BYTE* pWriteBuffer, BYTE readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD ReadChannel0(BYTE deviceAddr, DWORD writeBytes, BYTE* pWriteBuffer, DWORD readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
{
	
	DWORD nCount=0;
	
	if(writeBytes > 0)
	{
		pI2C->TXR0	= deviceAddr | I2C_WR;
		pI2C->CMD0	= HwI2CM_CMD_STA_EN | HwI2CM_CMD_WR_EN;
		
		while( !(pI2C->IRQSTR & Hw0) )	
		{
			nCount++;
			if(nCount > 100000)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT \n")));
				return FALSE;
			}
		}
		BITSET( pI2C->CMD0, Hw0); //Clear a pending interrupt
		
		for(unsigned int i=0; i< writeBytes; i++) {
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]WriteData[%d]=[%x]\n"), i, pWriteBuffer[i]));
			pI2C->TXR0 = pWriteBuffer[i];
			pI2C->CMD0 = HwI2CM_CMD_WR_EN;
			nCount=0;
			while( !(pI2C->IRQSTR & Hw0) )	
			{
				nCount++;
				if(nCount > 100000)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT \n")));
					return FALSE;
				}
			}
			BITSET( pI2C->CMD0, Hw0); //Clear a pending interrupt
		}
		
		if(!nMode || ((readBytes <= 0)&&(nMode != 2)&&(nMode != 4)))
		{	
			pI2C->CMD0 = HwI2CM_CMD_STO_EN;
			nCount=0;	
			while( !(pI2C->IRQSTR & Hw0) )	
			{
				nCount++;
				if(nCount > 100000)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT[STOP] \n")));
					return FALSE;
				}
			}
			BITSET( pI2C->CMD0, Hw0); //Clear a pending interrupts
		}
		
	}// writeBytes
	
	
	if(readBytes > 0)
	{
		pI2C->TXR0	= deviceAddr | I2C_RD;
		pI2C->CMD0	= HwI2CM_CMD_STA_EN | HwI2CM_CMD_WR_EN;
		nCount=0;
		while( !(pI2C->IRQSTR & Hw0) )	
		{
			nCount++;
			if(nCount > 100000)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT \n")));
				return FALSE;
			}
		}
		BITSET( pI2C->CMD0, Hw0); //Clear a pending interrupt
		for(unsigned int i=0; i< readBytes; i++) {
			if(nMode)
			{
				if(i==readBytes-1) 
					pI2C->CMD0 = HwI2CM_CMD_RD_EN |HwI2CM_CMD_ACK_EN;	
				else 			
					pI2C->CMD0 = HwI2CM_CMD_RD_EN ;
			}
			else
				pI2C->CMD0 = HwI2CM_CMD_RD_EN |HwI2CM_CMD_ACK_EN;
			nCount=0;
			while( !(pI2C->IRQSTR & Hw0) )	
			{
				nCount++;
				if(nCount > 100000)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT \n")));
					return FALSE;
				}
			}
			BITSET( pI2C->CMD0, Hw0); //Clear a pending interrupt
			pReadBuffer[i] =(BYTE)pI2C->RXR0;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]BUFFER[%d]:%x \n\r"),i,pReadBuffer[i]));
		}
		
        if(nMode != 4)
		pI2C->CMD0 = HwI2CM_CMD_STO_EN;
        
		nCount=0;
		while( !(pI2C->IRQSTR & Hw0) )	
		{
			nCount++;
			if(nCount > 100000)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT \n")));
				return FALSE;
			}
		}
		BITSET( pI2C->CMD0, Hw0); //Clear a pending interrupt
		
	}//readBytes	
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD ReadChannel1(BYTE deviceAddr, BYTE writeBytes, BYTE* pWriteBuffer, BYTE readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD ReadChannel1(BYTE deviceAddr, DWORD writeBytes, BYTE* pWriteBuffer, DWORD readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
{
	
	DWORD nCount=0;
	
	if(writeBytes > 0)
	{
		pI2C->TXR1	= deviceAddr | I2C_WR;
		pI2C->CMD1	= HwI2CM_CMD_STA_EN | HwI2CM_CMD_WR_EN;

		while( !(pI2C->IRQSTR & Hw1) )	
		{
			nCount++;
			if(nCount > 100000)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT[S|ADDR|W] \n")));
				return FALSE;
			}
		}
		BITSET( pI2C->CMD1, Hw0); //Clear a pending interrupt
		
		for(unsigned int i=0; i< writeBytes; i++) {
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]WriteData[%d]=[%x]\n"), i, pWriteBuffer[i]));
			pI2C->TXR1 = pWriteBuffer[i];
			pI2C->CMD1 = HwI2CM_CMD_WR_EN;
			nCount=0;

			while( !(pI2C->IRQSTR & Hw1) )	
			{
				nCount++;
				if(nCount > 100000)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT[DATA(%d)] \n"),i+1));
					return FALSE;
				}
			}
			BITSET( pI2C->CMD1, Hw0); //Clear a pending interrupt
		}

		if(!nMode || ((readBytes <= 0)&&(nMode != 2)&&(nMode != 4)))
		{	
			pI2C->CMD1 = HwI2CM_CMD_STO_EN;
			nCount=0;	
			while( !(pI2C->IRQSTR & Hw1) )	
			{
				nCount++;
				if(nCount > 100000)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT[STOP] \n")));
					return FALSE;
				}
			}
		}
		BITSET( pI2C->CMD1, Hw0); //Clear a pending interrupt
	}// writeBytes
	
	
	if(readBytes > 0)
	{
		pI2C->TXR1	= deviceAddr | I2C_RD;
		pI2C->CMD1	= HwI2CM_CMD_STA_EN | HwI2CM_CMD_WR_EN;
		nCount=0;
		while( !(pI2C->IRQSTR & Hw1) )	
		{
			nCount++;
			if(nCount > 100000)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT[S|ADDR|R]\n")));
				return FALSE;
			}
		}
		BITSET( pI2C->CMD1, Hw0); //Clear a pending interrupt
		for(unsigned int i=0; i< readBytes; i++) {
			if(nMode)
			{
				if(i==readBytes-1) 
					pI2C->CMD1 = HwI2CM_CMD_RD_EN |HwI2CM_CMD_ACK_EN;	
				else 			
					pI2C->CMD1 = HwI2CM_CMD_RD_EN ;
			}
			else
				pI2C->CMD1 = HwI2CM_CMD_RD_EN |HwI2CM_CMD_ACK_EN;

			nCount=0;
			while( !(pI2C->IRQSTR & Hw1) )	
			{
				nCount++;
				if(nCount > 100000)
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT[DATA(%d)] \n"),i+1));
					return FALSE;
				}
			}
			BITSET( pI2C->CMD1, Hw0); //Clear a pending interrupt
			pReadBuffer[i] =(BYTE)pI2C->RXR1;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]BUFFER[%d]:%x \n\r"),i,pReadBuffer[i]));
		}
		
        if(nMode != 4)
		pI2C->CMD1 = HwI2CM_CMD_STO_EN;
        
		nCount=0;
		while( !(pI2C->IRQSTR & Hw1) )	
		{
			nCount++;
			if(nCount > 100000)
			{
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]TIMEOUT[STOP] \n")));
				return FALSE;
			}
		}
		BITSET( pI2C->CMD1, Hw0); //Clear a pending interrupt
		
	}//readBytes	
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD ReadChannel2(BYTE deviceAddr, BYTE writeBytes, BYTE* pWriteBuffer, BYTE readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD ReadChannel2(BYTE deviceAddr, DWORD writeBytes, BYTE* pWriteBuffer, DWORD readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
{
	
	DWORD nCount=0;
	
	if(writeBytes > 0)
	{
		pSMUI2C->TXR0	= deviceAddr | I2C_WR;
		pSMUI2C->CMD0	= HwI2CM_CMD_STA_EN | HwI2CM_CMD_WR_EN;
		
        while(1) {
            nCount = pSMUI2C->SR0;
            if(!(nCount & Hw1)) break;
        }
        for (nCount = 0; nCount<15; nCount++);

        
		BITSET( pSMUI2C->CMD0, Hw0); //Clear a pending interrupt
		
		for(unsigned int i=0; i< writeBytes; i++) {
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]WriteData[%d]=[%x]\n"), i, pWriteBuffer[i]));
			pSMUI2C->TXR0 = pWriteBuffer[i];
			pSMUI2C->CMD0 = HwI2CM_CMD_WR_EN;
			nCount=0;

            while(1) {
                nCount = pSMUI2C->SR0;
                if(!(nCount & Hw1)) break;
            }
            for (nCount = 0; nCount<15; nCount++);

			BITSET( pSMUI2C->CMD0, Hw0); //Clear a pending interrupt
		}
		
		if(!nMode || readBytes <= 0)
		{	
			pSMUI2C->CMD0 = HwI2CM_CMD_STO_EN;
			nCount=0;	

            while(1) {
                nCount = pSMUI2C->SR0;
                if(!(nCount & Hw1)) break;
            }
            for (nCount = 0; nCount<15; nCount++);
        
			BITSET( pSMUI2C->CMD0, Hw0); //Clear a pending interrupts
		}
		
	}// writeBytes
	
	
	if(readBytes > 0)
	{
		pSMUI2C->TXR0	= deviceAddr | I2C_RD;
		pSMUI2C->CMD0	= HwI2CM_CMD_STA_EN | HwI2CM_CMD_WR_EN;
		nCount=0;

        while(1) {
            nCount = pSMUI2C->SR0;
            if(!(nCount & Hw1)) break;
        }
        for (nCount = 0; nCount<15; nCount++);

		BITSET( pSMUI2C->CMD0, Hw0); //Clear a pending interrupt
		for(unsigned int i=0; i< readBytes; i++) {
			pSMUI2C->CMD0 = HwI2CM_CMD_RD_EN |HwI2CM_CMD_ACK_EN;
			nCount=0;

            while(1) {
                nCount = pSMUI2C->SR0;
                if(!(nCount & Hw1)) break;
            }
            for (nCount = 0; nCount<15; nCount++);

			BITSET( pSMUI2C->CMD0, Hw0); //Clear a pending interrupt
			pReadBuffer[i] =(BYTE)pSMUI2C->RXR0;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]BUFFER[%d]:%x \n\r"),i,pReadBuffer[i]));
		}
		
		pSMUI2C->CMD0 = HwI2CM_CMD_STO_EN;
		nCount=0;

        while(1) {
            nCount = pSMUI2C->SR0;
            if(!(nCount & Hw1)) break;
        }
        for (nCount = 0; nCount<15; nCount++);

		BITSET( pSMUI2C->CMD0, Hw0); //Clear a pending interrupt
		
	}//readBytes	
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD ReadChannel3(BYTE deviceAddr, BYTE writeBytes, BYTE* pWriteBuffer, BYTE readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD ReadChannel3(BYTE deviceAddr, DWORD writeBytes, BYTE* pWriteBuffer, DWORD readBytes, BYTE* pReadBuffer, BYTE nMode, DWORD nTimeout)
{
	
	DWORD nCount=0;
	
	if(writeBytes > 0)
	{
		pSMUI2C->TXR1	= deviceAddr | I2C_WR;
		pSMUI2C->CMD1	= HwI2CM_CMD_STA_EN | HwI2CM_CMD_WR_EN;
		
        while(1) {
            nCount = pSMUI2C->SR1;
            if(!(nCount & Hw1)) break;
        }
        for (nCount = 0; nCount<15; nCount++);

        
		BITSET( pSMUI2C->CMD1, Hw0); //Clear a pending interrupt
		
		for(unsigned int i=0; i< writeBytes; i++) {
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]WriteData[%d]=[%x]\n"), i, pWriteBuffer[i]));
			pSMUI2C->TXR1 = pWriteBuffer[i];
			pSMUI2C->CMD1 = HwI2CM_CMD_WR_EN;
			nCount=0;

            while(1) {
                nCount = pSMUI2C->SR1;
                if(!(nCount & Hw1)) break;
            }
            for (nCount = 0; nCount<15; nCount++);

			BITSET( pSMUI2C->CMD1, Hw0); //Clear a pending interrupt
		}
		
		if(!nMode || readBytes <= 0)
		{	
			pSMUI2C->CMD1 = HwI2CM_CMD_STO_EN;
			nCount=0;	

            while(1) {
                nCount = pSMUI2C->SR1;
                if(!(nCount & Hw1)) break;
            }
            for (nCount = 0; nCount<15; nCount++);
        
			BITSET( pSMUI2C->CMD1, Hw0); //Clear a pending interrupts
		}
		
	}// writeBytes
	
	
	if(readBytes > 0)
	{
		pSMUI2C->TXR1	= deviceAddr | I2C_RD;
		pSMUI2C->CMD1	= HwI2CM_CMD_STA_EN | HwI2CM_CMD_WR_EN;
		nCount=0;

        while(1) {
            nCount = pSMUI2C->SR1;
            if(!(nCount & Hw1)) break;
        }
        for (nCount = 0; nCount<15; nCount++);

		BITSET( pSMUI2C->CMD1, Hw0); //Clear a pending interrupt
		for(unsigned int i=0; i< readBytes; i++) {
			pSMUI2C->CMD1 = HwI2CM_CMD_RD_EN |HwI2CM_CMD_ACK_EN;
			nCount=0;

            while(1) {
                nCount = pSMUI2C->SR1;
                if(!(nCount & Hw1)) break;
            }
            for (nCount = 0; nCount<15; nCount++);

			BITSET( pSMUI2C->CMD1, Hw0); //Clear a pending interrupt
			pReadBuffer[i] =(BYTE)pSMUI2C->RXR1;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]BUFFER[%d]:%x \n\r"),i,pReadBuffer[i]));
		}
		
		pSMUI2C->CMD1 = HwI2CM_CMD_STO_EN;
		nCount=0;

        while(1) {
            nCount = pSMUI2C->SR1;
            if(!(nCount & Hw1)) break;
        }
        for (nCount = 0; nCount<15; nCount++);

		BITSET( pSMUI2C->CMD1, Hw0); //Clear a pending interrupt
		
	}//readBytes	
	return TRUE;
}
/************************************************************************************************
* FUNCTION		: void I2C_Reset()
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_Reset()
{
	tcc_ckc_set_iobus_swreset(RB_I2CCONTROLLER);
}

/************************************************************************************************
* FUNCTION		: void I2C_GpioSetting(void
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_GpioSetting(void)
{
	PGPIO pGPIO;
	pGPIO = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);

	//SCL0-GPIOA0, SDA0-GPIOA1
	BITCSET(pGPIO->GPAFN0, (Hw5-Hw0), Hw0); //GPIOA[0] function set 1
	BITCSET(pGPIO->GPAFN0, (Hw8-Hw4), Hw4); //GPIOA[1] function set 1


	//SCL1-GPIOA8, SDA1-GPIOA9
	BITCSET(pGPIO->GPAFN1, (Hw5-Hw0), Hw0); //GPIOA[8] function set 1
	BITCSET(pGPIO->GPAFN1, (Hw8-Hw4), Hw4); //GPIOA[9] function set 1
	
}

/************************************************************************************************
* FUNCTION		: void I2C_Initialize()
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_Initialize()
{
	pI2C = (PI2C)tcc_allocbaseaddress((unsigned int)&HwI2CMASTER0_BASE);
	//I2C Channel 0 setting 100kHz
	//pI2C->PRES0 = 7; // (100K)
	//pI2C->PRES0 = 0x14; // (38K)
	pI2C->PRES0 = 0x18; // (32K)

	pI2C->CTRL0 = HwI2CM_CMD_STA_EN | HwI2CM_CMD_STO_EN|HwI2CM_CTRL_MOD_8;
	BITSET( pI2C->CMD0, HwI2CM_CMD_IACK_CLR);
	//Sleep(1);
	BITSET( pI2C->CMD0,HwI2CM_CMD_IACK_CLR);
	
	
	//I2C Channel 1 setting 400kHz
	/* Required Frequency  */
	pI2C->PRES1 = 2; // (400K)
	pI2C->CTRL1 = HwI2CM_CMD_STA_EN | HwI2CM_CMD_STO_EN|HwI2CM_CTRL_MOD_8;
	BITSET( pI2C->CMD1, HwI2CM_CMD_IACK_CLR);
	//Sleep(1);
	BITSET( pI2C->CMD1, HwI2CM_CMD_IACK_CLR);


    pSMUI2C = (PSMUI2C)tcc_allocbaseaddress((unsigned int)&HwSMU_I2CMASTER0_BASE);
    pSMUI2C->IRQSTR = 0x80000000;
    
    //SMU I2C Channel 0
	pSMUI2C->PRES0 = 4; // (100K)
	pSMUI2C->CTRL0 = HwI2CM_CMD_STA_EN | HwI2CM_CMD_STO_EN;
	BITSET( pSMUI2C->CMD0, HwI2CM_CMD_IACK_CLR);
	//Sleep(1);
	BITSET( pSMUI2C->CMD0,HwI2CM_CMD_IACK_CLR);

	pSMUI2C->PRES1 = 4; // (100K)
	pSMUI2C->CTRL1 = HwI2CM_CMD_STA_EN | HwI2CM_CMD_STO_EN;
	BITSET( pSMUI2C->CMD1, HwI2CM_CMD_IACK_CLR);
	//Sleep(1);
	BITSET( pSMUI2C->CMD1, HwI2CM_CMD_IACK_CLR);
	
}

/************************************************************************************************
* FUNCTION		: void tca_i2c_init(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
int tca_i2c_init(void)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[I2C         ]+TCC_I2C_Init\n")));
	m_nIrq		 = IRQ_I2C;
	m_bisRunning = TRUE;
	
	I2C_Reset();
	I2C_GpioSetting();
	I2C_Initialize();

	
	RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("[I2C         ]-TCC_I2C_Init\n")));
	
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{
	DWORD retval = 0;

	retval = tca_i2c_init();


	gMutexAll = CreateMutex(0, FALSE, gMutexAllName);
	if( !gMutexAll ) {
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]gMutexAll Create Event Fail \n\r"))); 
		retval=0;
	}

	return retval;
}

/************************************************************************************************
* FUNCTION		: BOOL I2C_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL I2C_Deinit( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_Deinit \n")));
	m_bisRunning = FALSE;
	/* remove SysIrq*/
	//nRet = KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &m_nSysIrq, sizeof(DWORD), NULL, NULL, NULL);
	InterruptDisable(m_nSysIrq);
	
	//SetEvent(gCommandEventChannel0);
	//PulseEvent(gCommandEventChannel1);
	//::WaitForSingleObject(gI2CINTThread, INFINITE);
	CloseHandle(gCommandEventChannel0);
	CloseHandle(gCommandEventChannel1);
	
	//PulseEvent(gInterruptEvent);
	CloseHandle(gInterruptEvent);
	CloseHandle(gMutexAll); 


	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_Deinit \n")));	

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_Open\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_Open\n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL I2C_Close( DWORD hOpenContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL I2C_Close( DWORD hOpenContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_Close\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_Close\n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL I2C_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL I2C_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
{
	I2C_Param *pI2C_Param;
	RetParam  *pRetParam;
	DWORD nRet;
	
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_IOControl[%d]\n"),GetTickCount()));
	nRet = WaitForSingleObject(gMutexAll, 1000);
	if (nRet == WAIT_OBJECT_0) 
    {
		switch (dwCode) {
		case IOCTL_I2C_INIT:
			break;
		case IOCTL_I2C_OPEN:
			break;
		case IOCTL_I2C_CLOSE:
			break;
		case IOCTL_I2C_READ:
			pI2C_Param = (I2C_Param *)pBufIn;
			
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ][I2C Drv] Read [%x][%d][%x][%d][%x][%d]\n"),
				pI2C_Param->DeviceAddr, 
				pI2C_Param->nWriteByte,
				pI2C_Param->pWriteBuffer, 
				pI2C_Param->nReadByte, 
				pI2C_Param->pReadBuffer,
				pI2C_Param->nPort));
			
			if(pI2C_Param->nPort == 0){
				nRet = ReadChannel0(pI2C_Param->DeviceAddr, pI2C_Param->nWriteByte, pI2C_Param->pWriteBuffer, pI2C_Param->nReadByte, (pI2C_Param->pReadBuffer),pI2C_Param->nMode, pI2C_Param->nTimeout);
				if((nRet > 0) && (pI2C_Param->nReadByte > 0))
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]Read [%x][%d][%x][%d][%x]\n"),
						pI2C_Param->DeviceAddr, 
						pI2C_Param->nWriteByte,
						pI2C_Param->pWriteBuffer, 
						pI2C_Param->nReadByte, 
						pI2C_Param->pReadBuffer));
					
					pRetParam = (RetParam *)pBufOut;
					pRetParam->pReadBuffer = pI2C_Param->pReadBuffer;
					pRetParam->nReadByte   = pI2C_Param->nReadByte;
					*pdwActualOut = pI2C_Param->nReadByte;
					dwLenOut = sizeof(RetParam);
				}
				else 
				{
					*pdwActualOut = 0;
					dwLenOut=0;
				}
			}
			else if(pI2C_Param->nPort == 1) {
				nRet = ReadChannel1(pI2C_Param->DeviceAddr, pI2C_Param->nWriteByte, pI2C_Param->pWriteBuffer, pI2C_Param->nReadByte, (pI2C_Param->pReadBuffer),pI2C_Param->nMode, pI2C_Param->nTimeout);
				if((nRet > 0) && (pI2C_Param->nReadByte > 0))
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]Read [%x][%d][%x][%d][%x]\n"),
						pI2C_Param->DeviceAddr, 
						pI2C_Param->nWriteByte,
						pI2C_Param->pWriteBuffer, 
						pI2C_Param->nReadByte, 
						pI2C_Param->pReadBuffer));
					
					pRetParam = (RetParam *)pBufOut;
					pRetParam->pReadBuffer = pI2C_Param->pReadBuffer;
					pRetParam->nReadByte  = pI2C_Param->nReadByte;
					*pdwActualOut = pI2C_Param->nReadByte;
					dwLenOut = sizeof(RetParam);
				}
				else 
				{
					*pdwActualOut = 0;
					dwLenOut=0;
				}
			}
			else if(pI2C_Param->nPort == 2){
				nRet = ReadChannel2(pI2C_Param->DeviceAddr, pI2C_Param->nWriteByte, pI2C_Param->pWriteBuffer, pI2C_Param->nReadByte, (pI2C_Param->pReadBuffer),pI2C_Param->nMode, pI2C_Param->nTimeout);
				if((nRet > 0) && (pI2C_Param->nReadByte > 0))
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]Read [%x][%d][%x][%d][%x]\n"),
						pI2C_Param->DeviceAddr, 
						pI2C_Param->nWriteByte,
						pI2C_Param->pWriteBuffer, 
						pI2C_Param->nReadByte, 
						pI2C_Param->pReadBuffer));
					
					pRetParam = (RetParam *)pBufOut;
					pRetParam->pReadBuffer = pI2C_Param->pReadBuffer;
					pRetParam->nReadByte   = pI2C_Param->nReadByte;
					*pdwActualOut = pI2C_Param->nReadByte;
					dwLenOut = sizeof(RetParam);
				}
				else 
				{
					*pdwActualOut = 0;
					dwLenOut=0;
				}
			}
			else if(pI2C_Param->nPort == 3) {
				nRet = ReadChannel3(pI2C_Param->DeviceAddr, pI2C_Param->nWriteByte, pI2C_Param->pWriteBuffer, pI2C_Param->nReadByte, (pI2C_Param->pReadBuffer),pI2C_Param->nMode, pI2C_Param->nTimeout);
				if((nRet > 0) && (pI2C_Param->nReadByte > 0))
				{
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]Read [%x][%d][%x][%d][%x]\n"),
						pI2C_Param->DeviceAddr, 
						pI2C_Param->nWriteByte,
						pI2C_Param->pWriteBuffer, 
						pI2C_Param->nReadByte, 
						pI2C_Param->pReadBuffer));
					
					pRetParam = (RetParam *)pBufOut;
					pRetParam->pReadBuffer = pI2C_Param->pReadBuffer;
					pRetParam->nReadByte  = pI2C_Param->nReadByte;
					*pdwActualOut = pI2C_Param->nReadByte;
					dwLenOut = sizeof(RetParam);
				}
				else 
				{
					*pdwActualOut = 0;
					dwLenOut=0;
				}
			}
			else
				RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]Not Support Port Number [%d]\n"),pI2C_Param->nPort));
			break;
			
		case IOCTL_I2C_WRITE:
			pI2C_Param = (I2C_Param *)pBufIn;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ][I2C Drv] Write [%x][%d][%x][%d]\n"),
				pI2C_Param->DeviceAddr, 
				pI2C_Param->nWriteByte,
				pI2C_Param->pWriteBuffer,
				pI2C_Param->nPort));
			if(pI2C_Param->nPort == 0)	{
				if(ReadChannel0(pI2C_Param->DeviceAddr, pI2C_Param->nWriteByte, pI2C_Param->pWriteBuffer, 0, NULL, pI2C_Param->nMode, pI2C_Param->nTimeout))	
					*pdwActualOut = pI2C_Param->nWriteByte;
				else 	*pdwActualOut = 0;
			}
			else if(pI2C_Param->nPort ==1){
				if(ReadChannel1(pI2C_Param->DeviceAddr, pI2C_Param->nWriteByte, pI2C_Param->pWriteBuffer, 0, NULL, pI2C_Param->nMode, pI2C_Param->nTimeout))
					*pdwActualOut = pI2C_Param->nWriteByte;
				else
					*pdwActualOut = 0;
			}			
			else if(pI2C_Param->nPort == 2)	{
				if(ReadChannel2(pI2C_Param->DeviceAddr, pI2C_Param->nWriteByte, pI2C_Param->pWriteBuffer, 0, NULL, pI2C_Param->nMode, pI2C_Param->nTimeout))	
					*pdwActualOut = pI2C_Param->nWriteByte;
				else 	*pdwActualOut = 0;
			}
			else if(pI2C_Param->nPort == 3){
				if(ReadChannel3(pI2C_Param->DeviceAddr, pI2C_Param->nWriteByte, pI2C_Param->pWriteBuffer, 0, NULL, pI2C_Param->nMode, pI2C_Param->nTimeout))
					*pdwActualOut = pI2C_Param->nWriteByte;
				else
					*pdwActualOut = 0;
			}			
			
			break;
		default:
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("[I2C         ]Unknown IOCTL[%x]\n"),dwCode));
			break;
		}
	}
	else{
		RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]I2C_IOControl WaitForSingleObject TimeOut\n")));
		ReleaseMutex(gMutexAll);
		return FALSE;
	}
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_IOControl[%d]\n"),GetTickCount()));
	ReleaseMutex(gMutexAll);
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: void I2C_PowerUp( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_PowerUp( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_PowerUp\n")));
	tca_i2c_init();
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_PowerUp\n")));
}

/************************************************************************************************
* FUNCTION		: void I2C_PowerDown( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_PowerDown( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_PowerDown\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_PowerDown\n")));	
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_Read\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_Read\n")));	
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_Write\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_Write\n")));	
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Seek( DWORD hOpenContext, long Amount, WORD Type )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Seek( DWORD hOpenContext, long Amount, WORD Type )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]+TCC_I2C_Seek\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("[I2C         ]-TCC_I2C_Seek\n")));	
	return 0;
}
