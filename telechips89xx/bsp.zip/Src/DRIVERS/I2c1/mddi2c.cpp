/****************************************************************************
*   FileName    : args.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/
#include <bsp.h>
#include <Devload.h>
#include "../../LIB/SOC/I2C/i2c.h"
#include "../../LIB/SOC/GPIO/tca_gpio.h"


/************************************************************************************************
* Global Handle
************************************************************************************************/
CPddI2C *pPDDI2C;


/************************************************************************************************
* Global Variable define
************************************************************************************************/


/************************************************************************************************
* Global Defines
************************************************************************************************/


/************************************************************************************************
* FUNCTION		: 
BOOL DllEntry(HINSTANCE   hinstDll,	   //@parm Instance pointer. 
			  DWORD       dwReason,    //@parm Reason routine is called. 
			  LPVOID      lpReserved   //@parm system parameter. 
			  )
* DESCRIPTION	:  
*
************************************************************************************************/
BOOL DllEntry(HINSTANCE   hinstDll,	   /*@parm Instance pointer. */
			  DWORD       dwReason,    /*@parm Reason routine is called. */
			  LPVOID      lpReserved   /*@parm system parameter. */
			  )
{
	if (dwReason == DLL_PROCESS_ATTACH) {
		DEBUGREGISTER(hinstDll);
		DEBUGMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("port process attach\r\n")));
		DisableThreadLibraryCalls((HMODULE) hinstDll);
	}
	
	if (dwReason == DLL_PROCESS_DETACH) {
		DEBUGMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("process detach detach\r\n")));
	}
	
	return (TRUE);
}
/************************************************************************************************
* FUNCTION		: BOOL CreateNewObject(DWORD DevIndex)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL CreateNewObject(DWORD DevBaseAddress, DWORD DevIndex, DWORD DevSpeed)
{
	// change physical to virtual
	DWORD Virtual_DevBaseAddress=tca_allocbaseaddress(DevBaseAddress, sizeof(GPIO));
	
	//
	switch(DevIndex)
	{
		case 0:
			if(!pPDDI2C)
			{
				pPDDI2C = new CPddI2C(Virtual_DevBaseAddress, DevIndex, DevSpeed);
				RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("CPDDI2C 0 Create \n")));
				return TRUE;
			}
			break;

		case 1:
			if(!pPDDI2C)
			{
				pPDDI2C = new CPddI2C(Virtual_DevBaseAddress, DevIndex, DevSpeed);
				RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("CPDDI2C 1 Create \n")));
				return TRUE;
			}
			break;

		default:
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("+TCC_I2C_Deinit \n")));
			break;
	}

	return FALSE;
}
/************************************************************************************************
* FUNCTION		: DWORD I2C_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{
	HKEY    hKey;
	DWORD	DevIndex, DevSpeed, DevBaseAddress;
	DWORD	kvaluetype, datasize;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+I2C_Init \n")));

	hKey = OpenDeviceKey((LPCTSTR)pContext);
    if ( !hKey ) {
        DEBUGMSG (TC_LOG_LEVEL(TC_ERROR),
                  (TEXT("Failed to open devkeypath, COM_Init failed\r\n")));
        return(NULL);
    }
	//get DevIndex Number
    datasize = sizeof(DWORD);

    if ( RegQueryValueEx(hKey, L"DeviceArrayIndex", NULL, &kvaluetype,
                         (LPBYTE)&DevIndex, &datasize) ) {
        DEBUGMSG (TC_LOG_LEVEL(TC_ERROR),
                  (TEXT("Failed to get DeviceArrayIndex value, COM_Init failed\r\n")));
        RegCloseKey (hKey);
       return(NULL);
    }
	//get DevSpeed Number
    datasize = sizeof(DWORD);

    if ( RegQueryValueEx(hKey, L"DeviceSpeed", NULL, &kvaluetype,
                         (LPBYTE)&DevSpeed, &datasize) ) {
        DEBUGMSG (TC_LOG_LEVEL(TC_ERROR),
                  (TEXT("Failed to get DeviceArrayIndex value, COM_Init failed\r\n")));
        RegCloseKey (hKey);
       return(NULL);
    }	
	//get DevSpeed Number
    datasize = sizeof(DWORD);

    if ( RegQueryValueEx(hKey, L"MemBase", NULL, &kvaluetype,
                         (LPBYTE)&DevBaseAddress, &datasize) ) {
        DEBUGMSG (TC_LOG_LEVEL(TC_ERROR),
                  (TEXT("Failed to get DeviceArrayIndex value, COM_Init failed\r\n")));
        RegCloseKey (hKey);
       return(NULL);
    }
	//CreateObject
	CreateNewObject(DevBaseAddress, DevIndex,DevSpeed);
	RegCloseKey(hKey);

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-I2C_Init \n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL I2C_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL I2C_Deinit( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_Deinit \n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-TCC_I2C_Deinit \n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_Open\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-TCC_I2C_Open\n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL I2C_Close( DWORD hOpenContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL I2C_Close( DWORD hOpenContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_Close\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-TCC_I2C_Close\n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL I2C_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL I2C_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
{
	
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_IOControl\n")));
	
	switch (dwCode) {
	case 1:
	default:
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("Unknown IOCTL[%x]\n"),dwCode));
		break;
	}

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: void I2C_PowerUp( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_PowerUp( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_PowerUp\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-TCC_I2C_PowerUp\n")));
}

/************************************************************************************************
* FUNCTION		: void I2C_PowerDown( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void I2C_PowerDown( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_PowerDown\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-TCC_I2C_PowerDown\n")));	
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_Read\n")));
	pPDDI2C->TCCI2C_Read((char *)pBuffer, Count);
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-TCC_I2C_Read\n")));	
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_Write\n")));
	pPDDI2C->TCCI2C_Write((char *)pBuffer, Count);
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-TCC_I2C_Write\n")));	
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD I2C_Seek( DWORD hOpenContext, long Amount, WORD Type )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD I2C_Seek( DWORD hOpenContext, long Amount, WORD Type )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("+TCC_I2C_Seek\n")));
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG),(TEXT("-TCC_I2C_Seek\n")));	
	return 0;
}
