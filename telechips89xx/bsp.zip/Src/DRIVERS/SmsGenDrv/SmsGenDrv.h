
#ifndef SMS_GEN_DRV_H
#define SMS_GEN_DRV_H

#include "BusDrvIf.h"

#define CTRL_FILE_BUFF_SIZE		(1024*2)
#define DATA_FILE_BUFF_SIZE		(697*188*2)	// ~(128*1024)*2

/* callback to be registered in SIANO_GEN_IOCTL_REGISTER_READ_IP_CB */
typedef void (*GEN_ReadIpCBFunc) (DWORD hContext, void* pBuffer, UINT32 BufSize);

typedef struct GEN_IOCTL_REGISTER_READ_IP_PARAMS_S
{
	GEN_ReadIpCBFunc	pReadIpCBFunc;
	DWORD				hContext;

} GEN_IOCTL_REGISTER_READ_IP_PARAMS_ST, *PGEN_IOCTL_REGISTER_READ_IP_PARAMS_ST;

/* IOCTLS */

/* Description : Associate handle returned from XXX_Open with specific steam type */
/* input format : UINT32 - requested file stream type */
/* output : none */
#define SIANO_GEN_IOCTL_SET_FILE_STREAM_TYPE	SIANO_MAKE_IOCTL(0)

/* Description : Cancel blocking read for the specific handle */
/* input format : None */
/* output : none */
#define SIANO_GEN_IOCTL_CANCEL_IO				SIANO_MAKE_IOCTL(1)

/* Description : register callback to be called to pass IP data to NDIS driver */
/* input  : pointer to PGEN_IOCTL_REGISTER_READ_IP_PARAMS_ST structure */
/* output : none */
#define SIANO_GEN_IOCTL_REGISTER_READ_IP_CB		SIANO_MAKE_IOCTL(2)

typedef enum {
	SIANO_CTRL_FILE_STREAM = 0,
	SIANO_MIN_DATA_FILE_STREAM = 1,
	SIANO_MAX_DATA_FILE_STREAM = 6,
	SIANO_NUM_OF_FILE_STREAMS
} SIANO_FILE_STREAM_TYPE_E;

/* Description : Change current application from one to another. */
/* input  : pointer to SIANO_APPLICATION_TYPE_E variable specifying the new application mode. */
/* output : none */
#define SIANO_IOCTL_CHANGE_APPLICATION		SIANO_MAKE_IOCTL(3)

/* Description : Return current application of the device. */
/* input  : none */
/* output : pointer to SIANO_APPLICATION_TYPE_E variable specifying the application mode. */
#define SIANO_GEN_IOCTL_GET_APP_TYPE		SIANO_MAKE_IOCTL(4)

/* Description : Set timeout for read operations in case data is not available. */
/* input  : pointer to UINT32 specifying the timeout in miliseconds.			*/
/*         windows define INFINITE (-1) means infinite timeout.					*/
/* output : none */
#define SIANO_GEN_IOCTL_SET_READ_TIMEOUT 		SIANO_MAKE_IOCTL(5)

typedef enum {
    SIANO_UNSUPPORTED = -1,
    SIANO_DVBH = 0,
    SIANO_DVBT = 1,
    SIANO_TDMB = 2,
    SIANO_ISDBT= 3,
    SIANO_CMMB = 4
} SIANO_APPLICATION_TYPE_E;

/************************************************************************/
/* Debug Zones definitions.                                             */
/************************************************************************/

/* Debug zones: */
#define ZONE_NONE_SET		0x0000
#define ZONE_ERROR			0//DEBUGZONE(0)
#define ZONE_ERROR_SET		0x0001
#define ZONE_WARNING		0//DEBUGZONE(1)
#define ZONE_WARNING_SET	0x0002
#define ZONE_INIT			0//DEBUGZONE(2)
#define ZONE_INIT_SET		0x0004
#define ZONE_INFO			0//DEBUGZONE(3)
#define ZONE_INFO_SET		0x0008
#define ZONE_ALL_SET		0xFFFF /* All of the zones */

#ifdef ENABLE_LOGS

#ifdef LOG_TO_FILE

	#define REGISTERZONES(hMod)
	#define DBGMSG(m, s) ((m & dpCurSettings.ulZoneMask) ? (LogStrToFile s),1:0)

#else
	#if defined(DEBUG)

		#define REGISTERZONES(hMod) DEBUGREGISTER(hMod)
		#define DBGMSG				DEBUGMSG

	#else

		#define REGISTERZONES(hMod) RETAILREGISTERZONES(hMod)
		#define DBGMSG				RETAILMSG

	#endif
#endif

#else

	#define REGISTERZONES(hMod)
	#define DBGMSG				RETAILMSG

#endif
/************************************************************************/

#endif
