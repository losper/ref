//test for RTC relative Interrupt
//RTC alarm & pmwakeup signal test 
#include "tcc_rtc.h"
#include "tcc_alarm.h"
#include <windows.h>
#include <notify.h>
#include <bsp.h>

BOOL g_bThread = FALSE;
static int RTC_SetAfterSeconds(SYSTEMTIME *pst, unsigned int seconds);
static void RTC_SetAlarmInt(void);
DWORD WINAPI RTCThreadProc( LPVOID dParam );
BOOL Init_Alarm(void);

DWORD g_dwIrq = 43;
DWORD g_dwRTCSysIntr;
HANDLE g_hRTCEvent;
HANDLE g_dwRTCThreadId;

BOOL Init_Alarm(void)
{
	CreateThread( NULL, 0,RTCThreadProc, NULL, 0, &g_dwRTCThreadId );	
	return TRUE;
}

static void RTC_SetAlarmInt(void)
{
	PRTC rtcvaddr;
	rtcvaddr = (PRTC)(((unsigned int)&HwRTC_BASE)&0xBFFFFFFF);
	tcc_alarm_setint(rtcvaddr);
	RETAILMSG(1 , (L"RTC_SetAlarmInt.\r\n"));
}



DWORD WINAPI RTCThreadProc( LPVOID dParam )
{
	PRTC rtcvaddr; 
	PPIC PICvaddr;
	rtcvaddr = (PRTC)(((unsigned int)&HwRTC_BASE)&0xBFFFFFFF);
	PICvaddr = (PPIC)(((unsigned int)&HwPIC_BASE)&0xBFFFFFFF);

	g_hRTCEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	g_bThread = TRUE;
	KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &g_dwIrq, sizeof(UINT32), &g_dwRTCSysIntr, sizeof(UINT32), NULL);
	InterruptInitialize(g_dwRTCSysIntr,g_hRTCEvent,0,0);
	
	RTC_SetAlarmInt();

	while (1) 
    {
		WaitForSingleObject(g_hRTCEvent, INFINITE);
        RETAILMSG(1, (TEXT("RTC Interrupt Success.\r\n")));
		RTC_SetAlarmInt();	
		InterruptDone(g_dwRTCSysIntr);
    }

	return 0;
}

