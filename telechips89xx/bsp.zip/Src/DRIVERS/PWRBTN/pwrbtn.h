/****************************************************************************
 *   FileName    : PWRBTN.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#ifndef __TCC_PWR_H__
#define __TCC_PWR_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _DISK 
{
    struct _DISK *		d_next;
    CARD_CLIENT_HANDLE	d_hPcmcia;   
    CARD_SOCKET_HANDLE	d_hSock;     
    CARD_WINDOW_HANDLE	d_hSRAM[3];
    volatile PUCHAR		d_pSRAM[3];
    DWORD				d_CardAddr[3];
    DWORD				d_LastWindow;
    CRITICAL_SECTION	d_DiskCardCrit;
    DWORD				d_DiskCardState;
    DWORD				d_CIS_Size;       
    DISK_INFO			d_DiskInfo;   
    DWORD				d_OpenCount;      
    LPWSTR				d_ActivePath;    
} DISK, * PDISK; 



// Scan-code mapping for keypad
typedef struct {
    int s_scancode;
    int e_scancode;
    BYTE vkcode;
}SCANCODE_MAPPING;


#ifdef __cplusplus
}
#endif

#endif // __TCC_PWR_H__

