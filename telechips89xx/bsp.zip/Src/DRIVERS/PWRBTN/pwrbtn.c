
/****************************************************************************
 *   FileName    : PWRBTN.C
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/

#include <windows.h>
#include <types.h>
#include <excpt.h>
#include <tchar.h>
#include <cardserv.h>
#include <cardapi.h>
#include <tuple.h>
#include <devload.h>
#include <diskio.h>
#include <nkintr.h>
#include <windev.h>
#include <winbase.h>
#include <Notify.h>

#include "tcc_rtc.h"
#include "tcc_alarm.h"
#include <bsp.h>
#include "tcc_gpio.h"
#include "tcc_ckc.h"
#include "tcc_gpioexp.h"

#include <TCC_MessageID.h>
#include <pm.h>
#include "pwrbtn.h"

/************************************************************************************************
*	DEFINES
************************************************************************************************/

//#define ENABLE_DRAM_VALID_CHK  // dram valid check logic enable
//#define	SUSPENDSLEEPTEST 1 //GWESPowerOff() call by this Driver
#define TC_CHATTER 1//button event check using GPIO



#define SHORTPRESSED 1
#define LONGPRESSED 2
enum 
{
	BUTTON_DOWN = 0,
	BUTTON_UP
};

/************************************************************************************************
* Global Variable
************************************************************************************************/
int g_NextButtonMode = BUTTON_DOWN;
static HANDLE gPwrButtonIntrEvent;
static HANDLE gPwrButtonIntrThread;
HANDLE gRTCIntrThread;
HANDLE gRTCIntrEvent;
HANDLE gRTCIntrEvent1;
UINT32 g_PwrButtonIrq = IRQ_EI7;
UINT32 g_PwrButtonSysIntr;
HANDLE m_hIsrHandler = NULL;
PPIC pvPIC = NULL;
PGPIO pvGPIO = NULL;//GPIO address




/************************************************************************************************
* FUNCTION		:  PWR_IntrThread
*
* DESCRIPTION	:  Detect Power button is pressed or not
*
************************************************************************************************/

const unsigned	CRC32_TABLE[256] = {
	0x00000000,	0x90910101,	0x91210201,	0x01B00300,
	0x92410401,	0x02D00500,	0x03600600,	0x93F10701,
	0x94810801,	0x04100900,	0x05A00A00,	0x95310B01,
	0x06C00C00,	0x96510D01,	0x97E10E01,	0x07700F00,
	0x99011001,	0x09901100,	0x08201200,	0x98B11301,
	0x0B401400,	0x9BD11501,	0x9A611601,	0x0AF01700,
	0x0D801800,	0x9D111901,	0x9CA11A01,	0x0C301B00,
	0x9FC11C01,	0x0F501D00,	0x0EE01E00,	0x9E711F01,
	0x82012001,	0x12902100,	0x13202200,	0x83B12301,
	0x10402400,	0x80D12501,	0x81612601,	0x11F02700,
	0x16802800,	0x86112901,	0x87A12A01,	0x17302B00,
	0x84C12C01,	0x14502D00,	0x15E02E00,	0x85712F01,
	0x1B003000,	0x8B913101,	0x8A213201,	0x1AB03300,
	0x89413401,	0x19D03500,	0x18603600,	0x88F13701,
	0x8F813801,	0x1F103900,	0x1EA03A00,	0x8E313B01,
	0x1DC03C00,	0x8D513D01,	0x8CE13E01,	0x1C703F00,
	0xB4014001,	0x24904100,	0x25204200,	0xB5B14301,
	0x26404400,	0xB6D14501,	0xB7614601,	0x27F04700,
	0x20804800,	0xB0114901,	0xB1A14A01,	0x21304B00,
	0xB2C14C01,	0x22504D00,	0x23E04E00,	0xB3714F01,
	0x2D005000,	0xBD915101,	0xBC215201,	0x2CB05300,
	0xBF415401,	0x2FD05500,	0x2E605600,	0xBEF15701,
	0xB9815801,	0x29105900,	0x28A05A00,	0xB8315B01,
	0x2BC05C00,	0xBB515D01,	0xBAE15E01,	0x2A705F00,
	0x36006000,	0xA6916101,	0xA7216201,	0x37B06300,
	0xA4416401,	0x34D06500,	0x35606600,	0xA5F16701,
	0xA2816801,	0x32106900,	0x33A06A00,	0xA3316B01,
	0x30C06C00,	0xA0516D01,	0xA1E16E01,	0x31706F00,
	0xAF017001,	0x3F907100,	0x3E207200,	0xAEB17301,
	0x3D407400,	0xADD17501,	0xAC617601,	0x3CF07700,
	0x3B807800,	0xAB117901,	0xAAA17A01,	0x3A307B00,
	0xA9C17C01,	0x39507D00,	0x38E07E00,	0xA8717F01,
	0xD8018001,	0x48908100,	0x49208200,	0xD9B18301,
	0x4A408400,	0xDAD18501,	0xDB618601,	0x4BF08700,
	0x4C808800,	0xDC118901,	0xDDA18A01,	0x4D308B00,
	0xDEC18C01,	0x4E508D00,	0x4FE08E00,	0xDF718F01,
	0x41009000,	0xD1919101,	0xD0219201,	0x40B09300,
	0xD3419401,	0x43D09500,	0x42609600,	0xD2F19701,
	0xD5819801,	0x45109900,	0x44A09A00,	0xD4319B01,
	0x47C09C00,	0xD7519D01,	0xD6E19E01,	0x46709F00,
	0x5A00A000,	0xCA91A101,	0xCB21A201,	0x5BB0A300,
	0xC841A401,	0x58D0A500,	0x5960A600,	0xC9F1A701,
	0xCE81A801,	0x5E10A900,	0x5FA0AA00,	0xCF31AB01,
	0x5CC0AC00,	0xCC51AD01,	0xCDE1AE01,	0x5D70AF00,
	0xC301B001,	0x5390B100,	0x5220B200,	0xC2B1B301,
	0x5140B400,	0xC1D1B501,	0xC061B601,	0x50F0B700,
	0x5780B800,	0xC711B901,	0xC6A1BA01,	0x5630BB00,
	0xC5C1BC01,	0x5550BD00,	0x54E0BE00,	0xC471BF01,
	0x6C00C000,	0xFC91C101,	0xFD21C201,	0x6DB0C300,
	0xFE41C401,	0x6ED0C500,	0x6F60C600,	0xFFF1C701,
	0xF881C801,	0x6810C900,	0x69A0CA00,	0xF931CB01,
	0x6AC0CC00,	0xFA51CD01,	0xFBE1CE01,	0x6B70CF00,
	0xF501D001,	0x6590D100,	0x6420D200,	0xF4B1D301,
	0x6740D400,	0xF7D1D501,	0xF661D601,	0x66F0D700,
	0x6180D800,	0xF111D901,	0xF0A1DA01,	0x6030DB00,
	0xF3C1DC01,	0x6350DD00,	0x62E0DE00,	0xF271DF01,
	0xEE01E001,	0x7E90E100,	0x7F20E200,	0xEFB1E301,
	0x7C40E400,	0xECD1E501,	0xED61E601,	0x7DF0E700,
	0x7A80E800,	0xEA11E901,	0xEBA1EA01,	0x7B30EB00,
	0xE8C1EC01,	0x7850ED00,	0x79E0EE00,	0xE971EF01,
	0x7700F000,	0xE791F101,	0xE621F201,	0x76B0F300,
	0xE541F401,	0x75D0F500,	0x7460F600,	0xE4F1F701,
	0xE381F801,	0x7310F900,	0x72A0FA00,	0xE231FB01,
	0x71C0FC00,	0xE151FD01,	0xE0E1FE01,	0x7070FF00
};

unsigned long makecrc (unsigned char *s, unsigned n)
{
    unsigned long c;
    static unsigned long crc = (unsigned long)0xffffffffL;

    if (s == 0)
	{
		c = 0xffffffffL;
    }
	else
	{
		c = crc;
        if (n)
        {
            do
		    {
                c = CRC32_TABLE[((int)c ^ (*s++)) & 0xff] ^ (c >> 8);
            } while (--n);
        }
    }
    crc = c;
    return c ^ 0xffffffffL;
}

int VerifyROMFile(unsigned int *pBuffer,unsigned int size )
{
	unsigned int crcout = 0;
	unsigned int cnt, i, code, tmp;
	unsigned int First_CrcRegion, Second_CrcRegion;

	First_CrcRegion = (128<<10)>>2;  //=32768  
	Second_CrcRegion = (size>>2);


	//First CRC Check 0~128kbyte	
	for(cnt=0; cnt<First_CrcRegion; cnt++)
	{
		if(cnt == 4 || cnt == 5)
			continue;
		
		code = pBuffer[cnt];
		for(i=0; i<4; i++)
		{
			tmp = code^crcout;
			crcout = (crcout>>8)^CRC32_TABLE[tmp&0xFF];
			code = code >> 8;
		}
	}
	if(crcout !=pBuffer[4]) return -1;


	//Second CRC Check 0~End
	crcout=0;
	
	for(cnt=0; cnt<Second_CrcRegion; cnt++)
	{
		code = pBuffer[cnt];	
		if(cnt == 4 || cnt == 5 )
		{
			continue;
		}
		else if(cnt==6){
			code = 0x00000000;
		}
		
		for(i=0; i<4; i++)
		{
			tmp = code^crcout;
			crcout = (crcout>>8)^CRC32_TABLE[tmp&0xFF];
			code = code >> 8;
		}
		
	}
	if(crcout !=pBuffer[6]) return -1;

	return 1;
}




void PWR_SuspendValidCheck()
{
	#ifdef ENABLE_DRAM_VALID_CHK
	unsigned int		nKernelLength;
	unsigned char		*ptr;
	unsigned int VPROGRAM_BASE_ADDRESS = 0;
	ptSYSTEM_PARAM pSysparam;
	pSysparam = (ptSYSTEM_PARAM)tcc_allocbaseaddress(SYSTEM_PARAM_BASEADDRESS);

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]Validate DRAM ...\n")));
	//make Physical Address to Virtual
	VPROGRAM_BASE_ADDRESS = KERNEL_BASEADDRESS;
	VPROGRAM_BASE_ADDRESS &= ~0x40000000;
	VPROGRAM_BASE_ADDRESS |= 0xA0000000;

	ptr = (unsigned char *)VPROGRAM_BASE_ADDRESS;
	memcpy(&nKernelLength,ptr+0x1C,4);
	if(nKernelLength >= 0xffffffff)
		return; //error

	if( VerifyROMFile ( (unsigned int*)VPROGRAM_BASE_ADDRESS,nKernelLength) != 1){
		pSysparam->POWER_KEY = PWRCTL_NORMAL;
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]+++ CRC error... +++ \nNormal boot...\n")));
		
		//normal rebooting....
		SetSystemPowerState (NULL, POWER_STATE_RESET, 0); 
	}
	pSysparam->POWER_KEY = PWRCTL_NORMAL;
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]Validate Complete...\n")));
	#endif
}



void PWR_IntrThread89x(void)
{
	int count;
	DWORD retval;
	BOOL bDownStatus=FALSE;
	BOOL bEnterSuspend=FALSE;
	ptSYSTEM_PARAM pSysparam;


	pvPIC = (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);
	pvGPIO = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);

	pSysparam = (ptSYSTEM_PARAM)tcc_allocbaseaddress(SYSTEM_PARAM_BASEADDRESS);
	
	pSysparam->POWER_KEY = PWRCTL_NORMAL;

	 RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("PWR_IntrThread.\r\n")));


#if defined(TC_CHATTER) 
	//set gpio3 input mode
	BITCLR(pvGPIO->GPAFN0, Hw16-Hw12);
	BITCLR(pvGPIO->GPAEN, Hw3);
#else

	//set gpio3 input mode
	BITCLR(pvGPIO->GPAFN0, Hw16-Hw12);
	BITCLR(pvGPIO->GPAEN, Hw3);

	//set externall interrupt3 to GPIO A3
	BITCSET(pvGPIO->EINTSEL1, Hw30-Hw24, Hw25|Hw24);
	
	//set polarity = Active Low
	BITSET(pvPIC->POL0, Hw10);

	//Set Interrupt Mode - edge triggered
	BITCLR(pvPIC->MODE0, Hw10);
	//Set Interrupt Mode - both edge
	BITSET(pvPIC->MODEA0, Hw10);

	//Sync diable (for edge trigger interrupt)
	BITSET(pvPIC->SYNC0, Hw10);

	//create Event associated Button Interrupt
    gPwrButtonIntrEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

	// Request a SYSINTR value from the OAL.
    if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &g_PwrButtonIrq, sizeof(UINT32), &g_PwrButtonSysIntr, sizeof(UINT32), NULL))
    {
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]ERROR: PwrButton: Failed to request sysintr value for power button interrupt.\r\n")));
        return;
    }
	
	//set Interrupt enable & Noti to Kernel
    if (!(InterruptInitialize(g_PwrButtonSysIntr, gPwrButtonIntrEvent, 0, 0))) 
    {
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]ERROR: PWRBTN: Interrupt initialize failed.\r\n")));
    }

#endif
		

 

	g_NextButtonMode = BUTTON_DOWN;
	count = 0;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]-PWR_Init\r\n")));

//	Init_Alarm();//to use this function, please remove "USING_RTC_NOTIFICATION_MODE" #define in rtc.c	



	while (1) //IST
    {

#if defined(TC_CHATTER) //only used for TC EVB SUSPEND test

		bDownStatus = FALSE;
		while(!(pvGPIO->GPADAT&Hw3)){
			count++;
			bDownStatus = TRUE;
			Sleep(10);
			if(count > 100){

				if(pSysparam->POWER_KEY == PWRCTL_NORMAL){
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]START SUSPEND\r\n")));
					pSysparam->POWER_KEY = PWRCTL_SUSPEND;
					
				#if 0
				count = 0;
				while(1)
				{					
					GwesPowerOffSystem();									
					PWR_SuspendValidCheck();
					Sleep(5000); // timeout
					count++;
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]wakeup %d\r\n"),count));									
				}
				#endif
					#ifdef	SUSPENDSLEEPTEST
					GwesPowerOffSystem();
					#else
					SendMessage(HWND_BROADCAST,WM_TCC_SUSPEND,(WPARAM)0,(LPARAM)0);
					#endif
					*(volatile unsigned long *)(SUS_DRAM_VALID1_VADDR) = 0x00;
					*(volatile unsigned long *)(SUS_DRAM_VALID2_VADDR) = 0x00;				
					PWR_SuspendValidCheck();
				}
				else{
					RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]END SUSPEND\r\n")));
					pSysparam->POWER_KEY = PWRCTL_NORMAL;
					Sleep(1000);
				}
				bDownStatus = FALSE;									
			}
		}
		
		if(bDownStatus){
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]START SLEEP\r\n")));
			pSysparam->POWER_KEY = PWRCTL_SLEEP;	
			#ifdef	SUSPENDSLEEPTEST
			GwesPowerOffSystem();
			#else
			PostMessage(HWND_BROADCAST,WM_TCC_SLEEP,(WPARAM)0,(LPARAM)0);
			#endif
			
			//pSysparam->POWER_KEY = PWRCTL_NORMAL;	

		
		}
		count = 0;
		Sleep(10);		

#else
		retval = WaitForSingleObject(gPwrButtonIntrEvent, 1000); // for Button Down Check
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("-")));
		if(retval == WAIT_OBJECT_0){// button down


			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]BUTTON DOWN\r\n")));
			InterruptDone(g_PwrButtonSysIntr);//clr Interrupt

					
			retval = WaitForSingleObject(gPwrButtonIntrEvent, 1000); // for Button Up Check
	
				
			if(retval == WAIT_OBJECT_0){
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]START SLEEP\r\n")));
				pSysparam->POWER_KEY = PWRCTL_SLEEP;	
				#ifdef	SUSPENDSLEEPTEST
				GwesPowerOffSystem();
				#else
				PostMessage(HWND_BROADCAST,WM_TCC_SLEEP,(WPARAM)0,(LPARAM)0);
				#endif
			}
			else{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]START SUSPEND\r\n")));
				pSysparam->POWER_KEY = PWRCTL_SUSPEND;					
				#ifdef	SUSPENDSLEEPTEST
				GwesPowerOffSystem();
				#else
				PostMessage(HWND_BROADCAST,WM_TCC_SUSPEND,(WPARAM)0,(LPARAM)0);
				#endif
				PWR_SuspendValidCheck();
			}
			
			*(volatile unsigned long *)(SUS_DRAM_VALID1_VADDR) = 0x00;
			*(volatile unsigned long *)(SUS_DRAM_VALID2_VADDR) = 0x00;
			pSysparam->POWER_KEY = PWRCTL_NORMAL;
			
			InterruptDone(g_PwrButtonSysIntr);//clr Interrupt
		}
#endif			
		
    }
}


DWORD PWR_IntrThread(PVOID pArg)
{
	PWR_IntrThread89x();
	return 0;
}


/************************************************************************************************
* FUNCTION		:  PWR_Init
*
* DESCRIPTION	:  Register Power button interrupt detecting thread..
*
************************************************************************************************/
DWORD PWR_Init(DWORD dwContext)
{
    PDISK   pDisk;
    DWORD   IDThread;

    pDisk = (PDISK)dwContext;


    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[PWRBTN      ]+PWR_Init.\r\n")));

    gPwrButtonIntrThread = CreateThread(0, 0, (LPTHREAD_START_ROUTINE) PWR_IntrThread, 0, 0, &IDThread);
	
    pDisk->d_DiskCardState = 1;

    return (DWORD)pDisk;
}



/************************************************************************************************
* FUNCTION		:  DllEntry
*
* DESCRIPTION	:
*
************************************************************************************************/
BOOL WINAPI DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
{
    switch ( dwReason ) 
    {
        case DLL_PROCESS_ATTACH:
            DisableThreadLibraryCalls((HMODULE) hInstDll);
        break;
    }
    return (TRUE);
}


/************************************************************************************************
* FUNCTION		:  PWR_Close
*
* DESCRIPTION	:
*
************************************************************************************************/
BOOL PWR_Close(DWORD Handle)
{
    return TRUE;
}


/************************************************************************************************
* FUNCTION		:  PWR_Deinit
*
* DESCRIPTION	:  Device deinit - devices are expected to close down.
*				   The device manager does not check the return code.
*
************************************************************************************************/
BOOL PWR_Deinit(
    DWORD dwContext     // future: pointer to the per disk structure
    )
{
    return TRUE;
}


/************************************************************************************************
* FUNCTION		:  PWR_Open
*
* DESCRIPTION	:  Returns handle value for the open instance.
*
************************************************************************************************/
DWORD PWR_Open(
    DWORD dwData,
    DWORD dwAccess,
    DWORD dwShareMode
    )
{
    return 0;
}


/************************************************************************************************
* FUNCTION		:  PWR_IOControl
*
* DESCRIPTION	:  I/O Control function - responds to info, read and write control codes.
*				   The read and write take a scatter/gather list in pInBuf
*
************************************************************************************************/
BOOL PWR_IOControl(
    DWORD Handle,
    DWORD dwIoControlCode,
    PBYTE pInBuf,
    DWORD nInBufSize,
    PBYTE pOutBuf,
    DWORD nOutBufSize,
    PDWORD pBytesReturned
    )
{
    return FALSE;
}

/************************************************************************************************
* FUNCTION		:  PWR_Read
*
* DESCRIPTION	:
*
************************************************************************************************/
DWORD PWR_Read(DWORD Handle, LPVOID pBuffer, DWORD dwNumBytes)
{
	return 0;
}


/************************************************************************************************
* FUNCTION		:  PWR_Write
*
* DESCRIPTION	:
*
************************************************************************************************/
DWORD PWR_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes)
{
	return 0;
}


/************************************************************************************************
* FUNCTION		:  PWR_Seek
*
* DESCRIPTION	:
*
************************************************************************************************/
DWORD PWR_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod)
{
	return 0;
}


/************************************************************************************************
* FUNCTION		:  PWR_PowerUp
*
* DESCRIPTION	:
*
************************************************************************************************/
void PWR_PowerUp(void)
{
	return;
}


/************************************************************************************************
* FUNCTION		:  PWR_PowerDown
*
* DESCRIPTION	:
*
************************************************************************************************/
void PWR_PowerDown(void)
{
	return;
}
