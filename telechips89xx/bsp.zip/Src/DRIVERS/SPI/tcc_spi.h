/****************************************************************************
 *   FileName    : tcc_spi.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCC_SPI_H__
#define __TCC_SPI_H__

#include <windows.h>
#include "tca_spi_hwset.h"

#define DEV TEXT("[         SPI]")

#define SPI_DMA_SIZE 2048

typedef struct _spi_param {
	BOOL CPL;			// SCK Polarity (= PCK)
	BOOL CPH;			// SCK Phase (= PWD,PRD)
	BOOL LSB;			// MSB/LSB (= SD)
	BOOL FP;			// Frame Pulse Polarity (= PCS,PCD)
	unsigned int Mhz;	// SPI clock (Mhz)
} spi_param_t;

class spi_core_c
{
public:
    spi_core_c();
    virtual ~spi_core_c();

public:
    BOOL wait_for_dma_done();

    BOOL init(int spi_num);
    BOOL open(DWORD access_code, DWORD share_mode);
	void close();
	void setup(spi_param_t *param, BOOL clk_flag);
	BOOL set_interrupt(int irq, int sys_irq, DWORD port_addr);
    DWORD transfer(char *p_buffer, DWORD cnt);
    DWORD align_transfer(char *rx_buf, char *tx_buf, DWORD count);

    void lock()   { EnterCriticalSection(&m_lock); }
    void unlock() { LeaveCriticalSection(&m_lock); }
    int inc_open_cnt() { m_open_cnt_0++; return m_open_cnt_0; }
    int dec_open_cnt() { if (m_open_cnt_0 > 0) m_open_cnt_0--; return m_open_cnt_0; }
    struct tea_dma_buf *get_rx_dma() { return &m_spi_handle->rx_dma; }
    struct tea_dma_buf *get_tx_dma() { return &m_spi_handle->tx_dma; }

    unsigned int get_bit_width();
    void set_bit_width(unsigned int bit_width);
    void set_spi_num(int spi_num);

public:
    tca_spi_handle_t *m_spi_handle;
    HANDLE m_intr_evt;
	int m_spi_loopback;
    BOOL m_is_init;

protected:
    int m_open_cnt_0;
    CRITICAL_SECTION m_lock;
    int m_spi_num;
	HANDLE m_hGpsbIsrHandler;
	int m_irq, m_sysirq;
};


#endif /*__TCC_SPI_H__*/
