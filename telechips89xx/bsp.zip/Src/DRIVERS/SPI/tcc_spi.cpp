/****************************************************************************
 *   FileName    : tcc_spi.cpp
 *   Description : Telechips GPSB (General Purpose Serial Bus) Driver
 *                 SPI Master Mode
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include <windows.h>
#include <giisr.h>
#include "bsp.h"
#include "tcc_ckc.h"
#include "tcc_gpio.h"
#include "tcc_spi.h"

#define CLOSE_HANDLE(H, N, F) do { if ((H) != (N)) { (F)(H); (H) = (N); } } while (0)

struct tcc_peri_id_table {
    unsigned int bus_id;
    unsigned int clk_id;
};

struct tcc_peri_id_table sa_peri_id_table[] = {
    { RB_GPSBCONTROLLER0, PERI_GPSB0 },
    { RB_GPSBCONTROLLER1, PERI_GPSB1 },
//	{ RB_GPSBCONTROLLER2, PERI_GPSB2 },
//	{ RB_GPSBCONTROLLER3, PERI_GPSB3 },
//	{ RB_GPSBCONTROLLER4, PERI_GPSB4 },
//	{ RB_GPSBCONTROLLER5, PERI_GPSB5 },
};

static void tea_free_dma_wince(struct tea_dma_buf *tdma)
{
    if (tdma) {
        CLOSE_HANDLE(tdma->v_addr, NULL, FreePhysMem);
    }
}

static int tea_alloc_dma_wince(struct tea_dma_buf *tdma, unsigned int size)
{
    int ret = -1;
    if (tdma) {
        DWORD tmp = 0;
        tea_free_dma_wince(tdma);
        tdma->v_addr = (unsigned char *)AllocPhysMem(size, PAGE_READWRITE, 0, 0, &tmp);
        if (tdma->v_addr) {
            tdma->buf_size = size;
            tdma->dma_addr = (unsigned int)tmp;
            RETAILMSG(TC_LOG_LEVEL(TC_LOG),(TEXT("%s (%s) DMA physical address [0x%X]\r\n"), DEV, _T(__FUNCTION__), tmp));
            ret = 0;
        }
    }
    return ret;
}

spi_core_c::spi_core_c()
{
    m_spi_num = -1;
    m_intr_evt = NULL;
    m_open_cnt_0 = 0;
    m_spi_handle = NULL;
	m_hGpsbIsrHandler = NULL;
    m_is_init = FALSE;
	m_spi_loopback = 0;
    InitializeCriticalSection(&m_lock);
}

spi_core_c::~spi_core_c()
{
    tca_spi_clean(m_spi_handle);
    CLOSE_HANDLE(m_spi_handle, NULL, free);

    DeleteCriticalSection(&m_lock);
	InterruptDisable(m_sysirq);
    CLOSE_HANDLE(m_intr_evt, NULL, CloseHandle);
}

void spi_core_c::set_spi_num(int spi_num)
{
    m_spi_num = spi_num;
}

BOOL spi_core_c::set_interrupt(int irq, int sys_irq, DWORD port_addr)
{
	//Install ISR 
	m_hGpsbIsrHandler = LoadIntChainHandler(L"tcc_giisr.dll", L"GPSBISRHandler", irq);
	if(m_hGpsbIsrHandler == NULL){
		DWORD dwRet = GetLastError();	
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s LoadIntChainHandler return fail %d\r\n"), DEV, dwRet));			
		return FALSE;
	}
	else{
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s LoadIntChainHandler success\r\n"), DEV));					
	}

	// Set up ISR handler
	if(m_hGpsbIsrHandler){
		GIISR_INFO Info;
		memset(&Info, 0, sizeof(GIISR_INFO));
		Info.CheckPort = TRUE; //irq happen then chk port <-> false means don't chk port == no shared IRQ
		Info.PortIsIO = FALSE; // memory mapped - not real port (TRUE only used X86)
		Info.SysIntr = sys_irq;
		Info.PortSize = sizeof(DWORD);// size of GPSB_CIRQST
		Info.UseMaskReg = FALSE;
		Info.MaskAddr = 0;

		switch(m_spi_num) {
		case 0:
			Info.Mask = Hw29;	// check DMAICR.ISD
			break;
		case 1:			
			Info.Mask = Hw29;	// check DMAICR.ISD
			break;
		default:
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s Unknown SPI\r\n"), DEV));
			return FALSE;
			break;
		}

		Info.PortAddr = port_addr;

		if (!KernelLibIoControl(m_hGpsbIsrHandler, IOCTL_GIISR_INFO,  &Info, sizeof(GIISR_INFO), NULL, 0, 0)){
			DWORD dwRet = GetLastError();	
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s KernelLibIoControl return fail %d\r\n"), DEV, dwRet));			
			return FALSE;
		}
		else
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR),(TEXT("%s KernelLibIoControl return success\r\n"), DEV));
	}

	return TRUE;
}

BOOL spi_core_c::init(int spi_num)
{
    int val = 0;
    BOOL ret = FALSE;
    volatile struct tca_spi_regs *p_spi_regs = (spi_num == 0)
		? (volatile struct tca_spi_regs *)tcc_allocbaseaddress((unsigned int)&(HwGPSBCH0_BASE))
		: (volatile struct tca_spi_regs *)tcc_allocbaseaddress((unsigned int)&(HwGPSBCH1_BASE));

    m_spi_num = spi_num;
    tca_spi_clean(m_spi_handle);
    CLOSE_HANDLE(m_spi_handle, NULL, free);

    m_spi_handle = (tca_spi_handle_t *)malloc(sizeof(tca_spi_handle_t));
	m_spi_handle->clk = 2;	// default clock 2Mhz
    if (m_spi_handle) {
		tcc_ckc_set_iobus_swreset(sa_peri_id_table[m_spi_num].bus_id);
		tcc_ckc_setiobus(sa_peri_id_table[m_spi_num].bus_id, ENABLE);
		tcc_ckc_setperi(sa_peri_id_table[m_spi_num].clk_id, ENABLE, m_spi_handle->clk*2*10000, PCDIRECTPLL2);

		m_irq = IRQ_GPSB;
		KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &m_irq, sizeof(UINT32), &m_sysirq, sizeof(UINT32), NULL);

		// IISR
		set_interrupt(m_irq, m_sysirq, (DWORD)&(p_spi_regs->DMAICR));

        val = tca_spi_init(m_spi_handle,
                            p_spi_regs,
                            m_sysirq,
                            tea_alloc_dma_wince,
                            tea_free_dma_wince,
                            SPI_DMA_SIZE,
                            m_spi_num,
                            0);
        if (val == 0) {
            m_spi_handle->clear_fifo_packet(m_spi_handle);
			
            m_intr_evt = CreateEvent(0, FALSE, FALSE, NULL);
            if ((InterruptInitialize(m_sysirq, m_intr_evt, 0, 0))) {
                ret = TRUE;
            } else {
                RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Cannot initialize interrupt \r\n"), DEV, _T(__FUNCTION__)));
            }
        }
    } else {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Cannot allocate memory for spi-handle \r\n"), DEV, _T(__FUNCTION__)));
    }

    if (!ret) {
        tca_spi_clean(m_spi_handle);
        CLOSE_HANDLE(m_spi_handle, NULL, free);
        CLOSE_HANDLE(m_intr_evt, NULL, CloseHandle);
    } else {
        m_is_init = TRUE;
    }

    return ret;
}

BOOL spi_core_c::open(DWORD access_code, DWORD share_mode)
{
    //if (!m_is_init) {
        if (!init(m_spi_num)) {
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s spi open fail !!!\r\n"), DEV, _T(__FUNCTION__)));
			return FALSE;
        }
    //}
	
    m_spi_handle->hw_init(m_spi_handle);
    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    return TRUE;
	
}

void spi_core_c::close()
{
	tca_spi_clean(m_spi_handle);
    CLOSE_HANDLE(m_spi_handle, NULL, free);

    InterruptDisable(m_sysirq);
    CLOSE_HANDLE(m_intr_evt, NULL, CloseHandle);
	CLOSE_HANDLE(m_hGpsbIsrHandler, NULL, FreeIntChainHandler);
	KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &m_sysirq, sizeof(UINT32), NULL, 0, NULL);
}

DWORD spi_core_c::align_transfer(char *rx_buf, char *tx_buf, DWORD count)
{
    DWORD ret = 0;
    DWORD w_byte = 0, oneshot_byte = 0, total_byte = 0;
    struct tea_dma_buf *p_rx_dma = NULL;
    unsigned int bit_width = 0;
    char *tx_pos_buf = tx_buf;

    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));

    p_rx_dma = get_rx_dma();
    if (count > 0) { 
        do {
            oneshot_byte = ((count - total_byte) > SPI_DMA_SIZE) ? SPI_DMA_SIZE : (count - total_byte);
            if (oneshot_byte & 0x03) {
                oneshot_byte %= 4;
                bit_width = get_bit_width();
                set_bit_width(8);
            }

            w_byte = transfer(tx_pos_buf, oneshot_byte);
            if (w_byte != oneshot_byte) {
                break;
            }

            if (rx_buf) { memcpy(rx_buf + total_byte, p_rx_dma->v_addr, w_byte); }
            if (tx_pos_buf) { tx_pos_buf += oneshot_byte; }

            if (bit_width) {
                set_bit_width(bit_width);
                bit_width = 0;
            }

            total_byte += oneshot_byte;
        } while (total_byte < count);
        ret = total_byte;
    }

    return ret;
}


DWORD spi_core_c::transfer(char *p_buffer, DWORD cnt)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s  cnt[%u]\r\n"), DEV, _T(__FUNCTION__), cnt));
    m_spi_handle->dma_stop(m_spi_handle);
    if (p_buffer) {
		if (m_spi_handle->flag) {
			m_spi_handle->regs->TXBASE = m_spi_handle->tx_dma.dma_addr;
        	memcpy(m_spi_handle->tx_dma.v_addr, p_buffer, cnt);
			m_spi_handle->flag = 0;
		} else {
			m_spi_handle->regs->TXBASE = m_spi_handle->tx_dma_1.dma_addr;
			memcpy(m_spi_handle->tx_dma_1.v_addr, p_buffer, cnt);
			m_spi_handle->flag = 1;
		}
    }

    m_spi_handle->clear_fifo_packet(m_spi_handle);
    m_spi_handle->set_packet_cnt(m_spi_handle, cnt);

    m_spi_handle->dma_start(m_spi_handle);
    if (!wait_for_dma_done()) {
        RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s dma wait error [%s:%d]!!!!!!!!!!!\n"), DEV, _T(__FUNCTION__), __LINE__));
        return 0;
    }
    return cnt;
}

BOOL spi_core_c::wait_for_dma_done()
{
    BOOL ret = FALSE;
    DWORD status;
    
    status = WaitForSingleObject(m_intr_evt, WAIT_TIME_FOR_DMA_DONE);
    if (status == WAIT_OBJECT_0) {
        m_spi_handle->dma_stop(m_spi_handle);
        //BITSET(HwINTMSK, Hw5);
        ret = TRUE;
    } else if (status == WAIT_TIMEOUT) {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s  recv timeout [%dms] !!! \r\n"), DEV, _T(__FUNCTION__), WAIT_TIME_FOR_DMA_DONE));
    } else {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s  WaitForSingleObject unknown error !!!\r\n"), DEV, _T(__FUNCTION__)));
    }
	InterruptDone(m_spi_handle->irq);
    return ret;
}

unsigned int spi_core_c::get_bit_width()
{
    unsigned int ret = 0;
    ret = m_spi_handle->regs->MODE;
    ret = ((ret >> 8) & 0x1F) + 1;
    return ret;
}

void spi_core_c::set_bit_width(unsigned int bit_width)
{
    m_spi_handle->set_bit_width(m_spi_handle, bit_width);
}

void spi_core_c::setup(spi_param_t *param, BOOL clk_flag)
{
	if (clk_flag) {
		// SPI Timing setting	
		tca_spi_setCPOL(m_spi_handle->regs, param->CPL);
	    tca_spi_setCPHA(m_spi_handle->regs, param->CPH);
	    tca_spi_setCS_HIGH(m_spi_handle->regs, param->FP);
	    tca_spi_setLSB_FIRST(m_spi_handle->regs, param->LSB);
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s mode 0x%08x\r\n"), DEV, m_spi_handle->regs->MODE));

		// SPI clock setting
		m_spi_handle->clk = param->Mhz;
		tcc_ckc_setiobus(sa_peri_id_table[m_spi_num].bus_id, ENABLE);
		//tcc_ckc_set_iobus_swreset(sa_peri_id_table[m_spi_num].bus_id);
		tcc_ckc_setperi(sa_peri_id_table[m_spi_num].clk_id, ENABLE, (m_spi_handle->clk * 2 * 10000), PCDIRECTPLL2);
		RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s clock %d Hz\r\n"), DEV, (tcc_ckc_getperi(sa_peri_id_table[m_spi_num].clk_id)/2*100)));
	} else {
		tcc_ckc_setperi(sa_peri_id_table[m_spi_num].clk_id, DISABLE, (m_spi_handle->clk * 2 * 10000), PCDIRECTPLL2);
		tcc_ckc_setiobus(sa_peri_id_table[m_spi_num].bus_id, DISABLE);
	}
}

