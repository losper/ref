/****************************************************************************
 *   FileName    : spi.cpp
 *   Description : Telechips GPSB (General Purpose Serial Bus) Driver
 *                 SPI Master Mode
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include <windows.h>
#include "bsp.h"
#include "tcc_spi.h"


DWORD get_registry(LPCTSTR p_path, LPCTSTR p_value_name, LPBYTE p_data, DWORD dw_data_size)
{
    DWORD data_size = 0, dw_type = 0, ret = 0;
    HKEY h_key;

    if (p_path) {
        if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, p_path, 0, 0, &h_key) == ERROR_SUCCESS) {
            RegQueryValueEx(h_key, p_value_name, NULL, &dw_type, p_data, &dw_data_size);
            RegCloseKey(h_key);
            ret = dw_data_size;
        }

    }
    return ret;
}

int get_device_index(LPCTSTR p_path)
{
    int ret = -1;
    TCHAR p_drv_path[1024];
    memset(p_drv_path, 0, sizeof(TCHAR) * 1024);

    if (get_registry(p_path, _T("Key"), (LPBYTE)p_drv_path, 1024) > 0) {
        get_registry(p_drv_path, _T("Index"), (LPBYTE)&ret, 4);
    }
    return ret;
}

BOOL DllEntry(HINSTANCE hinst_dll, DWORD reason, LPVOID reserved)
{
    switch (reason) {
    case DLL_PROCESS_ATTACH:
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s Process Attach\r\n"), DEV));
        break;
    case DLL_PROCESS_DETACH:
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s Process Detach\r\n"), DEV));
        break;
    }
    
    return TRUE;
}

DWORD SPI_Init(PVOID p_context)
{
    LPCTSTR p_spi_path = (LPCTSTR)p_context;
    spi_core_c *p_spi = NULL;
    int spi_num = 0;

    spi_num = get_device_index(p_spi_path);

    _try {
        p_spi = new spi_core_c();
    } _except (1) {
        if (p_spi) {
            delete p_spi;
            p_spi = NULL;
        }
    }

    if (p_spi) {
        p_spi->set_spi_num(spi_num);
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s(%d)\r\n"), DEV, _T(__FUNCTION__), spi_num));
        return (DWORD)p_spi;
    }

    RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Cannot init SPI driver(%d) !!!\r\n"), DEV, spi_num));
    return NULL;
}

DWORD SPI_Open(DWORD p_context, DWORD access_code, DWORD share_mode)
{
    DWORD ret = 0;
    int open_cnt = 0;
    spi_core_c *p_spi = (spi_core_c *)p_context;

    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    p_spi->lock();
    open_cnt = p_spi->inc_open_cnt();
    if (open_cnt == 1) {
        if (p_spi->open(access_code, share_mode)) {
            ret = (DWORD)p_context;
        }
    } else if (open_cnt > 1) {
        p_spi->dec_open_cnt();
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s Cannot open spi !!! Already spi open !!!\r\n"), DEV, _T(__FUNCTION__)));
    }
    p_spi->unlock();
    return ret;
}

BOOL SPI_Close(DWORD p_context)
{
    spi_core_c *p_spi = (spi_core_c *)p_context;

    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    p_spi->lock();
	p_spi->setup(NULL, FALSE);	// disalbe clock
    p_spi->dec_open_cnt();
	p_spi->close();
    p_spi->unlock();
    return TRUE;
}

DWORD SPI_Read(DWORD h_open_context, LPVOID p_buffer, DWORD count)
{
    DWORD ret = 0;
    spi_core_c *p_spi = (spi_core_c *)h_open_context;
    p_spi->lock();

	if (p_spi->m_spi_loopback)
    	ret = p_spi->align_transfer((char *)p_buffer, (char *)p_buffer, count);
	else
    	ret = p_spi->align_transfer((char *)p_buffer, NULL, count);

    p_spi->unlock();
    return ret;
}

DWORD SPI_Write(DWORD h_open_context, LPVOID p_buffer, DWORD count)
{
    DWORD ret = 0;
    spi_core_c *p_spi = (spi_core_c *)h_open_context;
    p_spi->lock();
    ret = p_spi->align_transfer(NULL, (char *)p_buffer, count);
    p_spi->unlock();
    return ret;
}

BOOL SPI_IOControl(DWORD h_open_context,
                   DWORD code,
                   PBYTE p_inbuf,
                   DWORD inbuf_size,
                   PBYTE p_outbuf,
                   DWORD outbuf_size,
                   LPDWORD p_retruned)
{
    spi_core_c *p_spi = (spi_core_c *)h_open_context;
	spi_param_t *p_spi_param;
	int value;
	BOOL ret = FALSE;

    p_spi->lock();

	switch (code) {
		case IOCTL_SPI_SETUP:
			p_spi_param = (spi_param_t *)p_inbuf;

			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s IOCTL_SPI_SETUP CPL(%d), CPH(%d), LSB(%d), FP(%d), Mhz(%d)\r\n"), DEV,
				p_spi_param->CPL, p_spi_param->CPH, p_spi_param->LSB, p_spi_param->FP, p_spi_param->Mhz));

			p_spi->setup(p_spi_param, TRUE);

			ret = TRUE;
			break;

		case IOCTL_SPI_LOOPBACK:
			value = *p_inbuf;

			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s IOCTL_SPI_WRITEREAD flag[%d]\n"), DEV, value));
			
			if (value == 1) {
				p_spi->m_spi_loopback = 1;
			} else if (value == 0) {
				p_spi->m_spi_loopback = 0;
			} else {
				RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s IOCTL_SPI_WRITEREAD unknown flag[%d]\n"), DEV, value));
				ret = FALSE;
			}

			ret = TRUE;
			break;
			
		default:
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Unknown IOCTL[%x]\n"), DEV, code));
			ret = FALSE;
			break;
	}
	
    p_spi->unlock();
    return ret;
}

DWORD SPI_Seek(DWORD h_open_context, long amount, DWORD type)
{
    spi_core_c *p_spi = (spi_core_c *)h_open_context;
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    p_spi->lock();
    p_spi->unlock();
    return 0;
}

void SPI_PowerDown(DWORD p_context)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
}

void SPI_PowerUp(DWORD p_context)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
}

void SPI_Deinit(DWORD p_context)
{
    spi_core_c *p_spi = (spi_core_c *)p_context;
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    if (p_spi) {
        delete p_spi;
    }
}

