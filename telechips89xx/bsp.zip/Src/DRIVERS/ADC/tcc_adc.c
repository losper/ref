/****************************************************************************
 *   FileName    : tcc_adc.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <windows.h>

#ifdef TCC89XX
#include "bsp.h"
#endif
#include "globals.h"
#include "tcc_ckc.h"
#include "tcc_gpio.h"
#include "tcc_adconv.h"
#include "ioctl_code.h"
#include "ioctl_pwrstr.h"


/************************************************************************************************
* Global Defines
************************************************************************************************/
#define TC_LOG_OPTION (0)
#define TC_LOG_LEVEL(a) ((TC_LOG_OPTION)&(a))


#if DEBUG
#ifdef DEBUG
#define ZONE_INIT 0x0001
DBGPARAM dpCurSettings = {
	_T("ADC"), {
		_T("Load"),
			_T("Dispatcher"),
			_T("Shutdown"),
			_T("Power"),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""),
			_T(""), 
			_T(""), 
			_T(""),
			_T(""), 
			_T("Init"), 
			_T("Warnings"), 
			_T("Errors") },
			0xC020 };
#endif
#endif

#define ADC_MUTEX  TEXT("ADC Mutex")
 /************************************************************************************************
* Global Handle
************************************************************************************************/
HANDLE  ghADCMutex;


/************************************************************************************************
* Type Define
************************************************************************************************/
typedef struct _XYPOS{
        int xpos;
        int ypos;
        int xp;
        int ym;
}TSXYPOS, *PTSXYPOS;

typedef struct _MXYPOS{
	TSXYPOS mtsxpos[16];
}MTSXYPOS, *PMTSXYPOS;


/************************************************************************************************
* Global Variable define
************************************************************************************************/
 PGPIO   pGPIO;
PTSADC  pTSADC;
static stpwrinfo adcpwrinfo = {PWR_STATUS_ON};


/************************************************************************************************
* FUNCTION		: 
BOOL DllEntry(HINSTANCE   hinstDll,	   //@parm Instance pointer. 
			  DWORD       dwReason,    //@parm Reason routine is called. 
			  LPVOID      lpReserved   //@parm system parameter. 
			  )
* DESCRIPTION	:  
*
************************************************************************************************/
BOOL DllEntry(HINSTANCE   hinstDll,	   /*@parm Instance pointer. */
			  DWORD       dwReason,    /*@parm Reason routine is called. */
			  LPVOID      lpReserved   /*@parm system parameter. */
			  )
{
	if (dwReason == DLL_PROCESS_ATTACH) {
            DEBUGREGISTER(hinstDll);
            DEBUGMSG(ZONE_INIT, (TEXT("port process attach\r\n")));
            DisableThreadLibraryCalls((HMODULE) hinstDll);
	}
	
	if (dwReason == DLL_PROCESS_DETACH) {
		DEBUGMSG(ZONE_INIT, (TEXT("process detach detach\r\n")));
	}
	
	return (TRUE);
}


 /************************************************************************************************
* FUNCTION		: DWORD   ADC_Init(LPCTSTR pContext, DWORD dwBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   ADC_Init(LPCTSTR pContext, DWORD dwBusContext)
{
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]+Init\n")));

    ghADCMutex = CreateMutex(NULL, FALSE, ADC_MUTEX);
    if (!ghADCMutex)
        RETAILMSG(TRUE,(TEXT("[ADC         ]:ERROR:Can't Create ADC Mutex\n")));

    pGPIO = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE, sizeof(GPIO));
    pTSADC = (PTSADC)tcc_allocbaseaddress((unsigned int)&HwTSADC_BASE, sizeof(TSADC));
    
    // 1. ADC Bus Clock Enable
    tcc_ckc_setiobus(RB_TSADCCONTROLLER,1);
	//tcc_ckc_setperi(PERI_ADC, ENABLE, 5000, PCDIRECTPLL2);

    // 2. GPIO Setting as ADCIN
    tcc_adc_portinitialize(pGPIO, NULL);

    // 2. ADC Setting
    tcc_adc_adcinitialize(pTSADC, NULL);

    
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]-Init\n")));	
    return TRUE;
}

 /************************************************************************************************
* FUNCTION		: DWORD   ADC_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   ADC_Deinit( DWORD hDeviceContext )
{
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]+Deinit\n")));
    // tcc_adc_deinit();
    CloseHandle(ghADCMutex);
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]-Deinit\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: DWORD   ADC_Open(  DWORD hDeviceContext,  DWORD AccessCode,  DWORD ShareMode )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   ADC_Open(  DWORD hDeviceContext,  DWORD AccessCode,  DWORD ShareMode )
{
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]+ADC_Open\n")));
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]-ADC_Open\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: DWORD   ADC_Close(DWORD hOpenContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   ADC_Close(DWORD hOpenContext )
{
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]+ADC_Close\n")));
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]-ADC_Close\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: BOOL   ADC_IOControl( DWORD Handle, DWORD dwIoControlCode, 
*				                                     PBYTE pInBuf, DWORD nInBufSize, 
*				                                    PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL   ADC_IOControl( DWORD Handle, DWORD dwIoControlCode, 
				   PBYTE pInBuf, DWORD nInBufSize, 
				   PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
{
    DWORD Ret;
    PTSXYPOS pxypos;
	PMTSXYPOS pxypos1;
    int*    padcdata;
	int i=0;

    
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]+ADC_IOControl\n")));
    Ret = WaitForSingleObject(ghADCMutex, 1000);

    if (Ret == WAIT_OBJECT_0) 
    {
        switch( dwIoControlCode)
        {
			case IOCTL_PWR_CONTROL:
			{
				stpwrioctl *pCmd  = (stpwrioctl*)pInBuf;
				
			    if (pCmd == NULL)
				    return FALSE;

			    switch(pCmd->cmd)
			    {
				    case PWR_CMD_OFF:
					    adcpwrinfo.status = PWR_STATUS_OFF;
					    //tcc_adc_powerdown(); 
					    RETAILMSG(TRUE,(TEXT("[ADC         ]:TESTLOG:ADC Power OFF\n")));
					    break;
    
				    case PWR_CMD_ON:
					    adcpwrinfo.status = PWR_STATUS_ON;
					    //tcc_adc_powerup();
					    RETAILMSG(TRUE,(TEXT("[ADC         ]:TESTLOG:ADC Power ON\n")));
					    break;
    
				    case PWR_CMD_GETSTATUS:
					    memcpy(pOutBuf, &adcpwrinfo, sizeof(stpwrinfo));
					    *pBytesReturned = sizeof(stpwrinfo);
					    break;
    
				    default:
					    return FALSE;	//break;
			    }
	        }
		        break;
            case    IOCTL_TSADC_CHANNEL0: // KEY
                padcdata = (int*)pOutBuf;
                *padcdata = tcc_adc_read(0);
                break;
                
            case    IOCTL_TSADC_CHANNEL1: // BATTERY
                padcdata = (int*)pOutBuf;
                *padcdata = tcc_adc_read(1);
                break;
                
            case    IOCTL_TSADC_CHANNEL2:
                padcdata = (int*)pOutBuf;
                *padcdata = tcc_adc_read(2);
                break;
                
            case    IOCTL_TSADC_TOUCHSCREEN:
                pxypos = (PTSXYPOS)pOutBuf;
                tcc_adc_tsautoread(&pxypos->xpos, &pxypos->ypos);
                break;
			
			case    IOCTL_TSADC_TOUCHSCREEN_GPIO:
				pxypos1 = (PMTSXYPOS *)pOutBuf;
				for(i=0; i<16;i++)
				{
					DWORD tmp=GetTickCount();
					tcc_adc_tsread(&pxypos1->mtsxpos[i].xpos, &pxypos1->mtsxpos[i].ypos, &pxypos1->mtsxpos[i].xp, &pxypos1->mtsxpos[i].ym);
					//RETAILMSG(1,(TEXT("get data(i):%d \n"),GetTickCount()-tmp));
				}
                break;
        }
    }
    else
    {
        RETAILMSG(TRUE,(TEXT("[ADC         ]:ERROR:ADC Mutex WaitForSingleObject TimeOut\n")));
        ReleaseMutex(ghADCMutex);
        return FALSE;
    }
	
    

    ReleaseMutex(ghADCMutex);
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]-ADC_IOControl\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: DWORD   ADC_PowerUp(DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   ADC_PowerUp(DWORD hDeviceContext )
{
    RETAILMSG(1,(TEXT("[ADC         ]+ADC_PowerUp\n")));
    // ADC PowerUp
    tcc_adc_powerup();
    RETAILMSG(1,(TEXT("[ADC         ]-ADC_PowerUp\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: DWORD   ADC_PowerDown(DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   ADC_PowerDown(DWORD hDeviceContext )
{
    RETAILMSG(1,(TEXT("[ADC         ]+ADC_PowerDown\n")));
    // ADC PowerDown
    tcc_adc_powerdown();
    RETAILMSG(1,(TEXT("[ADC         ]-ADC_PowerDown\n")));	
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: DWORD   ADC_Read(  DWORD hOpenContext,  LPVOID pBuffer,  DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   ADC_Read(  DWORD hOpenContext,  LPVOID pBuffer,  DWORD Count )
{
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]+ADC_Read\n")));
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]-ADC_Read\n")));	
    return Count;
}


 /************************************************************************************************
* FUNCTION		: DWORD   ADC_Write(DWORD hOpenContext,  LPCVOID pBuffer,  DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD   ADC_Write(DWORD hOpenContext,  LPCVOID pBuffer,  DWORD Count )
{
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]+ADC_Write\n")));
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),(TEXT("[ADC         ]-ADC_Write\n")));	
    return Count;
}


