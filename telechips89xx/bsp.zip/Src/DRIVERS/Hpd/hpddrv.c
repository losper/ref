
/****************************************************************************
 *   FileName    : hdmidrv.cpp
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <windows.h>

#include "bsp.h"

#include "TCC89x_Physical.h"
#include "TCC89x_Structures.h"
#include "ioctl_code.h"

#include "../hdmi/regs-hdmi.h"
#include "../hdmi/hdmi.h"
#include "hpddrv.h"

#include "tcc_gpio.h"
#include "tcc_gpioexp.h"


#define HPD_GPIO_POLLING

#define HPD_DEBUG 0

#define KERN_INFO

#define printk	printf

#if HPD_DEBUG
#define DPRINTK    printk
#else
#define DPRINTK
#endif

#define HPD_LO          0
#define HPD_HI          1


extern int  hpd_init(void);
extern void hpd_exit(void);
extern int  hpd_open(void);
extern int  hpd_release(void);

/************************************************************************************************
* Global Handle
************************************************************************************************/

static HANDLE gHpdIntrEvent;
static HANDLE gHpdIntrThread;


/************************************************************************************************
* Global Variable define
************************************************************************************************/

UINT32 g_HpdIrq = IRQ_HDMI;
UINT32 g_HpdSysIntr;

static UINT32 g_HpdState;
static int    g_last_hpd_state;

static tSYSTEM_PARAM *gpBOOTARGS;

static stpwrinfo gHpdPwrInfo = {PWR_STATUS_OFF};

/************************************************************************************************
* Global Defines
************************************************************************************************/
#if DEBUG
DBGPARAM dpCurSettings = {
    _T("usbmsfn"),
    {
        _T("Error"), _T("Warning"), _T("Init"), _T("Function"),
        _T("Comments"), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""), 
        _T(""), _T(""), _T(""), _T("")
    },
    0x5
};


#endif
#define LOGLEVEL DBG_ERROR|DBG_WARN|DBG_TRACE|DBG_LOG

/************************************************************************************************
* FUNCTION		: 
BOOL DllEntry(HINSTANCE   hinstDll,	   //@parm Instance pointer. 
			  DWORD       dwReason,    //@parm Reason routine is called. 
			  LPVOID      lpReserved   //@parm system parameter. 
			  )
* DESCRIPTION	:  
*
************************************************************************************************/
BOOL DllEntry(HINSTANCE   hinstDll,	   /*@parm Instance pointer. */
			  DWORD       dwReason,    /*@parm Reason routine is called. */
			  LPVOID      lpReserved   /*@parm system parameter. */
			  )
{
	if (dwReason == DLL_PROCESS_ATTACH) {
		DEBUGREGISTER(hinstDll);
		DEBUGMSG(ZONE_INIT, (TEXT("port process attach\r\n")));
		DisableThreadLibraryCalls((HMODULE) hinstDll);
	}
	
	if (dwReason == DLL_PROCESS_DETACH) {
		DEBUGMSG(ZONE_INIT, (TEXT("process detach detach\r\n")));
	}
	
	return (TRUE);
}


/************************************************************************************************
* FUNCTION		:  HPD_IntrThread
*
* DESCRIPTION	:  
*
************************************************************************************************/

void HPD_IntrThread89x(void)
{
    unsigned char flag;
    unsigned char reg;
	DWORD retval;

    /* adjust the duration of HPD detection */
	writeb(0xFF, HDMI_HPD_GEN);

	{
		unsigned int regl;
		
		// HW HPD On
		writeb(HPD_SW_DISABLE|HPD_ON,HDMI_HPD);
		regl = readl(GPIOA(GP_FN1));
		writel((regl & ~(0xF<<24)) | 1<<24, GPIOA(GP_FN1));		//GPIO_A14 -> HPD
		
		// setting PIC HDMI interrupt
		regl = readl(PIC_POL1);
		writel(regl & ~(1<<2), PIC_POL1);	// active-high
		#if (1)
		regl = readl(PIC_MODE1);
		writel(regl | (1<<2), PIC_MODE1);	// level-triggered
		#else
		regl = readl(PIC_MODE1);
		writel(regl & ~(1<<2), PIC_MODE1);	// edge-triggered
		#endif
		regl = readl(PIC_MODEA1);
		writel(regl & ~(1<<2), PIC_MODEA1);	// single-edge

	}

	//create Event associated Hpd Interrupt
    gHpdIntrEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("HPD_IntrThread.\r\n")));

    // Request a SYSINTR value from the OAL.
    if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &g_HpdIrq, sizeof(UINT32), &g_HpdSysIntr, sizeof(UINT32), NULL))
    {
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]ERROR: Failed to request sysintr value for hpd interrupt.\r\n")));
        return;
    }

	//set Interrupt enable & Noti to Kernel
    if (!(InterruptInitialize(g_HpdSysIntr, gHpdIntrEvent, 0, 0))) 
    {
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]ERROR: Interrupt initialize failed.\r\n")));
    }

    while (1) //IST
    {
		retval = WaitForSingleObject(gHpdIntrEvent, 5000); // for Short/Long Check

		if(retval == WAIT_OBJECT_0)
		{
		    /* read flag register */
		    flag = readb(HDMI_SS_INTC_FLAG);

		    DPRINTK("flag reg: 0x%02x\n", (int) flag);

		    /* is this our interrupt? */
		    if (!(flag & (1<<HDMI_IRQ_HPD_PLUG | 1<<HDMI_IRQ_HPD_UNPLUG))) {
		        return;
		    }

		    DPRINTK(KERN_INFO "%s\n", __FUNCTION__);
		    if (flag == (1<<HDMI_IRQ_HPD_PLUG | 1<<HDMI_IRQ_HPD_UNPLUG) ){
		        DPRINTK(KERN_INFO "HPD_HI && HPD_LO\n");
		        if ( g_last_hpd_state == HPD_HI && readb(HDMI_SS_HPD))
		        //if ( last_hpd_state == HPD_HI )
		            flag = 1<<HDMI_IRQ_HPD_UNPLUG;
		        else
		            flag = 1<<HDMI_IRQ_HPD_PLUG;
		    }

		    if (flag & (1<<HDMI_IRQ_HPD_PLUG)) {
		        DPRINTK(KERN_INFO "HPD_HI\n");
		        /* clear pending bit */
		        writeb(1<<HDMI_IRQ_HPD_PLUG, HDMI_SS_INTC_FLAG);
		        //atomic_set(&hpd_struct.state, HPD_HI);
				g_HpdState = HPD_HI;
		#if 1
		//??? add comments
		        // workaround: enable HDMI_IRQ_HPD_UNPLUG interrupt
		        reg = readb(HDMI_SS_INTC_CON);
		        reg |= 1<<HDMI_IRQ_HPD_UNPLUG;
		        g_last_hpd_state = HPD_HI;
		        writeb(reg, HDMI_SS_INTC_CON);
		#endif
		#if (1) && defined(TELECHIPS)
				writeb((1<<HDMI_IRQ_HPD_PLUG) | (1<<HDMI_IRQ_HPD_UNPLUG), HDMI_SS_INTC_FLAG);
		#endif
		        //wake_up_interruptible(&hpd_struct.waitq);
//		        InterruptDone(g_HpdSysIntr);//clr Interrupt
		    } else if (flag & (1<<HDMI_IRQ_HPD_UNPLUG)) {
		        DPRINTK(KERN_INFO "HPD_LO\n");
		        /* clear pending bit */
		        writeb(1<<HDMI_IRQ_HPD_UNPLUG, HDMI_SS_INTC_FLAG);
		        //atomic_set(&hpd_struct.state, HPD_LO);
				g_HpdState = HPD_LO;
		#if 1
		//??? add comments
		        // workaround: disable HDMI_IRQ_HPD_UNPLUG interrupt
		        reg = readb(HDMI_SS_INTC_CON);
		        reg &= ~(1<<HDMI_IRQ_HPD_UNPLUG);
		        g_last_hpd_state = HPD_LO;
		        writeb(reg, HDMI_SS_INTC_CON);
		#endif
		#if (1) && defined(TELECHIPS)
				writeb((1<<HDMI_IRQ_HPD_PLUG) | (1<<HDMI_IRQ_HPD_UNPLUG), HDMI_SS_INTC_FLAG);
		#endif
		        //wake_up_interruptible(&hpd_struct.waitq);
//		        InterruptDone(g_HpdSysIntr);//clr Interrupt
		    }
		
			InterruptDone(g_HpdSysIntr);//clr Interrupt
		}
		else{

		}
	}

    /* disable HPD interrupts */
    reg = readb(HDMI_SS_INTC_CON);
    reg &= ~(1<<HDMI_IRQ_HPD_PLUG);
    reg &= ~(1<<HDMI_IRQ_HPD_UNPLUG);
    writeb(reg, HDMI_SS_INTC_CON);
}


DWORD HPD_IntrThread(PVOID pArg)
{
#if !defined(HPD_GPIO_POLLING)
	HPD_IntrThread89x();
#endif

	return 0;
}

/************************************************************************************************
* FUNCTION		: DWORD HPD_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HPD_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{
    DWORD   IDThread;

	gpBOOTARGS=(tSYSTEM_PARAM *) tcc_allocbaseaddress(SYSTEM_PARAM_BASEADDRESS);

#if !defined(HPD_GPIO_POLLING)
    gHpdIntrThread = CreateThread(0, 0, (LPTHREAD_START_ROUTINE) HPD_IntrThread, 0, 0, &IDThread);
#endif

#if defined(HPD_GPIO_POLLING)
	{
		PGPIO pGPIO;
		pGPIO = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);

		BITCLR(pGPIO->GPAEN, Hw14);
	}
#endif
    HPD_PowerUp(NULL);

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT(__FUNCTION__)));

	return TRUE;
}


/************************************************************************************************
* FUNCTION		: BOOL HPD_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL HPD_Deinit( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT(__FUNCTION__)));

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD HPD_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HPD_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
{
    unsigned char reg;

#if !defined(HPD_GPIO_POLLING)

	writeb((1<<HDMI_IRQ_HPD_PLUG) | (1<<HDMI_IRQ_HPD_UNPLUG), HDMI_SS_INTC_FLAG);

    /* enable HPD interrupts */
    reg = readb(HDMI_SS_INTC_CON);
    writeb(reg | (1<<HDMI_IRQ_HPD_PLUG) | (1<<HDMI_IRQ_HPD_UNPLUG) |
      (1<<HDMI_IRQ_GLOBAL), HDMI_SS_INTC_CON);

#endif

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT(__FUNCTION__)));

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL HPD_Close( DWORD hOpenContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL HPD_Close( DWORD hOpenContext )
{
	int ret;
    unsigned char reg;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT(__FUNCTION__)));

#if !defined(HPD_GPIO_POLLING)

    /* disable HPD interrupts */
    reg = readb(HDMI_SS_INTC_CON);
    reg &= ~(1<<HDMI_IRQ_HPD_PLUG);
    reg &= ~(1<<HDMI_IRQ_HPD_UNPLUG);
    writeb(reg, HDMI_SS_INTC_CON);

#endif

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: void HPD_Enable( void )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void HPD_Enable( void )
{
//	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD        ]%s.\r\n"), TEXT(__FUNCTION__)));

#if defined(HPD_GPIO_POLLING)

	if (gHpdPwrInfo.status == PWR_STATUS_ON)
		return;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT("HPD_PowerUp")));

	if (gHpdPwrInfo.status == PWR_STATUS_OFF)
	{
		//LVDS
        HANDLE hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
        if( INVALID_HANDLE_VALUE!=hGXP )
        {
            DWORD dwByteReturned;
            GXPINFO GxpInfo;

			GxpInfo.uiDevice=PCA9539LOW;
			GxpInfo.uiPort=PWRGP4;
			GxpInfo.uiState=ON;

			if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
			{
				RETAILMSG(1,(TEXT("ERROR: PWRGP4 Power On\r\n")));
			}

            GxpInfo.uiDevice=PCA9538;
            GxpInfo.uiPort=SATAHDMI;	//HDMI_LVDS_ON
            GxpInfo.uiState=ON;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: HDMI_LVDS_ON Power On\r\n")));
            }

            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
        }

		gHpdPwrInfo.status = PWR_STATUS_ON;
    }
#endif

}

/************************************************************************************************
* FUNCTION		: void HPD_Disable( void )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void HPD_Disable( void )
{
//	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT(__FUNCTION__)));

	//TODO:
#if defined(HPD_GPIO_POLLING)

	if (gHpdPwrInfo.status == PWR_STATUS_OFF)
		return;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT("HPD_PowerDown")));

	if (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 0)
	{
		//LVDS
        HANDLE hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
        if( INVALID_HANDLE_VALUE!=hGXP )
        {
            DWORD dwByteReturned;
            GXPINFO GxpInfo;
            GxpInfo.uiDevice=PCA9538;
            GxpInfo.uiPort=SATAHDMI;	//HDMI_LVDS_ON
            GxpInfo.uiState=OFF;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: HDMI_LVDS_ON Power On\r\n")));
            }

            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
        }
    }
	gHpdPwrInfo.status = PWR_STATUS_OFF;
#endif
}

/************************************************************************************************
* FUNCTION		: BOOL HPD_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL HPD_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
{
	DWORD *pInValue = (DWORD *)pBufIn; 
    unsigned long *arg = (unsigned long *)pBufIn;
//	stReg *temp;
	int ret;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[HPD         ]%s[%d].\r\n"), TEXT(__FUNCTION__), dwCode));

	switch (dwCode)
    {
		case IOCTL_PWR_CONTROL:
		{
			stpwrioctl *pCmd  = (stpwrioctl*)pBufIn;
			stpwrinfo  *pInfo = (stpwrinfo *)pBufOut;

			if (pCmd == NULL)
			{
				return FALSE;
			}

			switch(pCmd->cmd)
			{
				case PWR_CMD_OFF:
					HPD_Disable();

					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gHpdPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;
				case PWR_CMD_ON:
					HPD_Enable();

					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gHpdPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;
				case PWR_CMD_GETSTATUS:
					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gHpdPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;

				default:
					return FALSE;	//break;
			}
		}
		break;
		
		case HPD_IOC_POWER_UP:
			HPD_Enable();
			break;
		case HPD_IOC_POWER_DOWN:
			HPD_Disable();
			break;

		default:
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]Unknown IOCTL.\r\n")));
			break;
     }

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: void HPD_PowerUp( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void HPD_PowerUp( DWORD hDeviceContext )
{
//	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD        ]%s.\r\n"), TEXT(__FUNCTION__)));

	HPD_Enable();
}

/************************************************************************************************
* FUNCTION		: void HPD_PowerDown( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void HPD_PowerDown( DWORD hDeviceContext )
{
//	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT(__FUNCTION__)));

	HPD_Disable();
}

/************************************************************************************************
* FUNCTION		: DWORD HPD_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HPD_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
{
	int read_bytes = sizeof(UINT32);

//	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HPD         ]%s.\r\n"), TEXT(__FUNCTION__)));
	
	if(Count < read_bytes)
		return FALSE;

	#if defined(HPD_GPIO_POLLING)
	{
		unsigned int tmp;
		PGPIO pGPIO;
		pGPIO = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);

		BITCLR(pGPIO->GPAEN, Hw14);

		tmp = (pGPIO->GPADAT & Hw14)>>14;
		
		g_HpdState = tmp;
	}
	
	#endif
	
	memcpy(pBuffer, &g_HpdState, sizeof(UINT32));
	
	return read_bytes;
}

/************************************************************************************************
* FUNCTION		: DWORD HPD_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HPD_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
{
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD HPD_Seek( DWORD hOpenContext, long Amount, WORD Type )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HPD_Seek( DWORD hOpenContext, long Amount, WORD Type )
{
	return 0;
}



