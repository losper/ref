/****************************************************************************
 *   FileName    : hpddrv.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCC_HPDDRV_H__
#define __TCC_HPDDRV_H__

DWORD	HPD_Init(LPCTSTR pContext, LPCVOID lpvBusContext);
BOOL	HPD_Deinit( DWORD hDeviceContext );
DWORD	HPD_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode );
BOOL	HPD_Close( DWORD hOpenContext );
BOOL	HPD_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut );

void	HPD_PowerUp( DWORD hDeviceContext );
void	HPD_PowerDown( DWORD hDeviceContext );
DWORD	HPD_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count );
DWORD	HPD_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count );
DWORD	HPD_Seek( DWORD hOpenContext, long Amount, WORD Type );

#endif //__TCC_HPDDRV_H__