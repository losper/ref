/*
 *
 */
#ifndef __TCC_USB_CORE_H__
#define __TCC_USB_CORE_H__


#define OTGID_ID_HOST		(~Hw9)
#define OTGID_ID_DEVICE		(Hw9)


extern void OTG_INTR_INIT(void);
extern void OTG_DVBUS_ON(void);
extern void OTGCORE_SetID(unsigned int ID);
extern void USB_LINK_Activate(void);
extern void USB_LINK_Reset(void);

#endif /*__TCC_USB_CORE_H__*/
