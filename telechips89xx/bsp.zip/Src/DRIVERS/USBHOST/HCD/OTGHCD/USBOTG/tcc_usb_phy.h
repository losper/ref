/*
 *
 */
#ifndef __TCC_USB_PHY_H__
#define __TCC_USB_PHY_H__

#include "tcc_usb_def.h"


extern void USBPHY_EnableClock(void);
extern void USBPHY_ModeChange(USB_MODE_T mode);

#endif /*__TCC_USB_PHY_H__*/