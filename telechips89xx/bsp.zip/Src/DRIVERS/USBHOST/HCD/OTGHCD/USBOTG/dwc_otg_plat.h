extern unsigned int dwc_read_reg32( unsigned int reg); 
extern void dwc_write_reg32( unsigned int reg, const unsigned int value) ;
extern void dwc_modify_reg32( unsigned int reg, unsigned int clear_mask, const unsigned int set_mask) ;

