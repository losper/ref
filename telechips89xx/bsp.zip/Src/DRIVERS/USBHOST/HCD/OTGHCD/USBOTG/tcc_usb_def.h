/*
 *
 */
#ifndef __TCC_USB_DEF_H__
#define __TCC_USB_DEF_H__

#include <bsp.h>

typedef enum {
	USB_MODE_NONE,
	USB_MODE_HOST,
	USB_MODE_DEVICE
} USB_MODE_T;


static PUSBPHYCFG pUSBPHYCFG = (PUSBPHYCFG)((unsigned int)0xB05F5028); //0xF05F5028
static PUSBOTGCFG pUSBOTGCFG = (PUSBOTGCFG)((unsigned int)0xB05F5000);// 0xF05F5000

#endif /*__TCC_USB_DEF_H__*/
