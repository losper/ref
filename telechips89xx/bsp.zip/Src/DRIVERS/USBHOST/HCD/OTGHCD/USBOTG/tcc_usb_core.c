/*
 *
 */
#include <bsp.h>
#include "tcc_ckc.h"
#include "dwc_otg_plat.h"
#include "tcc_usb_def.h"
#include "tcc_usb_phy.h"
#include "tcc_usb_core.h"
#include "tcc_gpioexp.h"


void OTG_INTR_INIT(void)
{
	BITCLR(HwPIC->POL1, HwINT1_UOTG);		// 0:active-high / 1:active-low
	BITSET(HwPIC->MODE1, HwINT1_UOTG);		// 1:Level / 0:edge trigger
	//BITCLR(HwPIC->MODEA1, HwINT1_UOTG);	// 0:single edge / 1:both edge
}

#if 1
void OTG_DVBUS_ON(void)
{
	/* GPIO_EXPAND DXB Power-on */
	HANDLE  hGXP;
	DWORD   dwret;
	DWORD   dwByteReturned;
	GXPINFO gxpInfo, gxpRead;


	hGXP = CreateFile(L"GXP1:",
	                    GENERIC_READ | GENERIC_WRITE,
						(PVOID)NULL,
						NULL,
						OPEN_ALWAYS,
						FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,
						NULL);

	if(!hGXP)
		RETAILMSG(TRUE,(TEXT("[OTG         ]:ERROR:Can't open GXP Driver!!\n")));

	gxpInfo.uiDevice = PCA9538;
	gxpInfo.uiPort = DVBUS|PWRGP1;
	gxpInfo.uiState = ON;

	dwret = WriteFile(  hGXP,  &gxpInfo,  sizeof(gxpInfo),   &dwByteReturned,  NULL);
	if( dwret == 0)
	{
		RETAILMSG(TRUE,(TEXT("[OTG         ]:ERROR:Can't Power up DVBUS!!\n")));
		CloseHandle(hGXP);
	}

	gxpRead.uiDevice = PCA9538;
	gxpRead.uiPort = PORTOUTPUT;
	dwret = ReadFile(hGXP, &gxpRead, 2, &dwByteReturned, NULL);
	RETAILMSG(TRUE,(TEXT("[OTG         ] GXP State : DVBUS:%s\r\n"), (((gxpRead.uiState & DVBUS))?L"ON":L"OFF")));
	//tcc_pca953x_setup(PCA9538_U4_SLAVE_ADDR, DVBUS, OUTPUT, HIGH, SET_DIRECTION|SET_VALUE);
	//DWC_DEBUGPL(DBG_CILV, "DVBUS power %s\n", (tcc_pca953x_setup(PCA9538_U4_SLAVE_ADDR, 0, OUTPUT, 0, GET_VALUE)&DVBUS)?"ON":"OFF");
}
#endif

void OTGCORE_SetID(unsigned int ID)
{
	if( ID )
		pUSBOTGCFG->OTGID |= OTGID_ID_DEVICE;
	else
		pUSBOTGCFG->OTGID &= OTGID_ID_HOST;
}

void USB_LINK_Activate(void)
{
	/* turn on the USB clock from IO BUS */
	//IO_CKC_EnableBUS_USB();
	tcc_ckc_setiobus(RB_USB20OTG, ENABLE);	
	/* turn on the USB PHY clock */
	USBPHY_EnableClock();
}

void USB_LINK_Reset(void)
{
//#define HwIOBUSCFG_BASE            *(volatile unsigned long *)0xF05F5000
	unsigned int		VA = (unsigned int)&HwIOBUSCFG_BASE;

	PIOBUSCFG	pIOBUSCFG = (PIOBUSCFG*)( VA - 0x40000000);

	BITCLR(pIOBUSCFG->HRSTEN0, HwIOBUSCFG_USB);
	{
		volatile unsigned int t=1000;
		while(t-->0);
	}
	BITSET(pIOBUSCFG->HRSTEN0, HwIOBUSCFG_USB);
}

/* end of file */
