/****************************************************************************
 *   FileName    : tca_keypad.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#if defined(_LINUX_)
#include <linux/input.h>
#include "tca_keypad.h"
#endif
 
/************************************************************************************************
* GLOBAL DEFINES
************************************************************************************************/

/************************************************************************************************
*   TYPE DEFINE
************************************************************************************************/
typedef struct {
	unsigned int	StartVal;
	unsigned int	EndVal;
	unsigned char	KeyCode;
}SCANCODE;


/************************************************************************************************
*   GLOBAL VARIABLE
************************************************************************************************/
const SCANCODE	stScanCodeMapping[] =
{
#if defined(_LINUX_)
	{1370, 1410, KEY_ESC},	// VK_LWIN
	{1730, 1780, KEY_1},	// VK_MENU
	{90  , 130 , KEY_2},	// VK_SPACE
	{350 , 390 , KEY_3},	// VK_UP
	{1120, 1170, KEY_4},	// VK_TAB
	{3730, 4100, KEY_5},	// VK_ESCAPE
	{920 , 970 , KEY_6},	// VK_RBUTTON
	{3280, 3340, KEY_7},	// VK_LEFT
	{2780, 2840, KEY_8},	// VK_RIGHT
	{600 , 660 , KEY_9},	// VK_DOWN
	{2280, 2350, KEY_0},	// VK_RETURN
#else
#if 0
	// 0x3E8, greater than 1000 -> IDLE
	{0x14A, 0x168, 0x5B},	//VK_LWIN },		// A1
	{0x1A4, 0x1C2, 0x12},	//VK_MENU },		// A2
	{0x0  , 0x28 , 0x20},	//VK_SPACE },		// A3
	{0x50 , 0x6E , 0x26},	//VK_UP },			// A4
	{0x10E, 0x12C, 0x09},	//VK_TAB },			// A5
	{0x3A2, 0x3B6, 0x1B},	//VK_ESCAPE },		// B0
	{0xE1 , 0xF5 , 0x02},	//VK_RBUTTON },		// B1
	{0x32F, 0x343, 0x25},	//VK_LEFT },		// B2
	{0x2B2, 0x2C6, 0x27},	//VK_RIGHT },		// B3
	{0x91 , 0xA5 , 0x28},	//VK_DOWN },		// B4
	{0x235, 0x249, 0x0D},	//VK_RETURN }		// B5
#else
	// Grater than 4050 -> IDLE
	// {ADC MinValue, MaxValue, Virtual Key Value}
	{1370, 1410, 0x5B},	// VK_LWIN
	{1730, 1780, 0x12},	// VK_MENU
	{90, 130, 0x20},		// VK_SPACE
	{350, 390, 0x26},		// VK_UP
	{1120, 1170, 0x09},	// VK_TAB
	{3730, 4100, 0x1B},	// VK_ESCAPE
	{920, 970, 0x02},		// VK_RBUTTON
	{3280,3340, 0x25},		// VK_LEFT
	{2780, 2840, 0x27},	// VK_RIGHT
	{600, 660, 0x28},		// VK_DOWN
	{2280, 2350, 0x0D},	// VK_RETURN
#endif
#endif
};


	
/************************************************************************************************
*   EXTERNAL FUNCTION PROTOTYPE
*************************************************************************************************/





 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
int tca_keypad_getkeycodebyscancode(unsigned int adcdata)
{
	int i;
	int key = -1;
	
	if(adcdata > 4050)
		key = -1;
	else
	{
		for (i = 0; i < sizeof(stScanCodeMapping)/sizeof(SCANCODE); i++)
		{
			if ((adcdata >= stScanCodeMapping[i].StartVal) && (adcdata <= stScanCodeMapping[i].EndVal))
				key = stScanCodeMapping[i].KeyCode;
		}
	}
	
	return key;
}

