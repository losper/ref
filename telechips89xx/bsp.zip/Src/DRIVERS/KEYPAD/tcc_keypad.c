/****************************************************************************
 *   FileName    : tcc_keypad.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <windows.h>
#include <devload.h>
#include <nkintr.h>
#include <pm.h>

#include "globals.h"
#include "ioctl_code.h"
#include "ioctl_pwrstr.h"

#ifdef DEBUG


DBGPARAM dpCurSettings = {
    _T("usbmsfn"),
    {
        _T("Error"), _T("Warning"), _T("Init"), _T("Function"),
        _T("Comments"), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""), 
        _T(""), _T(""), _T(""), _T("")
    },
    0x5
};

#endif // DEBUG
/************************************************************************************************
* GLOBAL DEFINES
************************************************************************************************/
#define TC_LOG_OPTION (TC_TRACE)
#define TC_LOG_LEVEL(a) ((TC_LOG_OPTION)&(a))

#define KEY_REPEAT_TIME 200
#define PRESSED     1
#define RELEASED   0
#define KEYPUSHEVENT 1
#define KEYUPEVENT 0


/************************************************************************************************
*   TYPE DEFINE
************************************************************************************************/
typedef struct{
	HANDLE	DevHandle;
	HANDLE	ThreadHandle;
	HANDLE	IntrEvent;
	DWORD	ThreadID;
	int		KillThread;
	int		State;
	int		SysIntr;
	int		Irq;
	CRITICAL_SECTION	CS;
}KEYPADINFO;

 /************************************************************************************************
* GLOBAL HANDLE
************************************************************************************************/
static HANDLE ghADC;


/************************************************************************************************
*   GLOBAL VARIABLE DEFINE
************************************************************************************************/
int PreviousKey = 0;
int CurrentState = RELEASED;
int PreviousState = RELEASED;
int KeyEvent;
unsigned int lasttick=0;

KEYPADINFO	stKeypadInfo;

static stpwrinfo keypwrinfo = {PWR_STATUS_ON};

/************************************************************************************************
*   EXTERNAL FUNCTION PROTOTYPE
*************************************************************************************************/
extern int tca_keypad_getkeycodebyscancode(unsigned int adcdata);


 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
void KEY_SendEvent(int CurrentKey)
{
	unsigned int timetick;

	if(CurrentKey > 0) // Key pushed down
	{
		CurrentState = PRESSED;

		timetick = GetTickCount();

		if( (PreviousKey == CurrentKey) && ( (timetick - lasttick)<KEY_REPEAT_TIME) )
			return ;// same key is pressed for a long time

		keybd_event(CurrentKey,0,0,0); // If the second param is not specified, the key is being pressed.

		lasttick = timetick;
		PreviousKey = CurrentKey;

		PreviousState = CurrentState;
		return;
	}
	else // Key Release
		CurrentState = RELEASED;


	if( PreviousState == PRESSED)
		keybd_event(PreviousKey, 0, KEYEVENTF_KEYUP,0);

	PreviousState = CurrentState;
	PreviousKey = CurrentKey;
}

 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
void KEY_DetectHandler(void* Param)
{
    unsigned int	ADCdata;
    int	VirtualKey;

    while(1)
    {
        Sleep(100);
        DeviceIoControl(ghADC, IOCTL_TSADC_CHANNEL0, NULL, 0, &ADCdata, sizeof(ADCdata), NULL, NULL);
        //RETAILMSG( 1, (_T("KEY=%d\n\r"), ADCdata));
        VirtualKey = tca_keypad_getkeycodebyscancode(ADCdata);
        KEY_SendEvent(VirtualKey);
    }
}

 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD	KEY_Init( LPCTSTR pContext, DWORD dwBusContext)
{
    UNREFERENCED_PARAMETER(pContext);
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]+Init: Context %s\n\r"), pContext));

    memset(&stKeypadInfo, 0x00, sizeof(KEYPADINFO) );

    ghADC = CreateFile(L"ADC1:", GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);

    if(!ghADC)
        RETAILMSG(TRUE,(TEXT("[KEY         ]:ERROR:Can't open ADC Driver!!\n")));

    stKeypadInfo.ThreadHandle= CreateThread(0, 0, (LPTHREAD_START_ROUTINE)KEY_DetectHandler, &stKeypadInfo, 0, &stKeypadInfo.ThreadID);

    if( stKeypadInfo.ThreadHandle == NULL )
    {
        RETAILMSG(TRUE, (_T("[KEY         ]:ERROR:Can't create Key Detect Thread!!\n\r")));    
        return 0;
    }
        
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]-Init: Context %s\n\r"), pContext));
    return 1;
}

 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL	KEY_Deinit( DWORD dwContext )
{
    KEYPADINFO *pKeyInfo = (KEYPADINFO*)dwContext;
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]+Deinit: Context %s\n\r"), dwContext));
    CloseHandle(stKeypadInfo.ThreadHandle);
    CloseHandle(ghADC);
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]-Deinit: Context %s\n\r"), dwContext));
    return TRUE;
}

 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL	KEY_IOControl( DWORD  dwContext, DWORD  Ioctl, PUCHAR pInBuf, DWORD  InBufLen, PUCHAR pOutBuf, DWORD  OutBufLen, PDWORD pdwBytesTransferred )
{
	DWORD	result;
	
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]+IOCTL\n\r")));
	switch(Ioctl)
	{
		case IOCTL_PWR_CONTROL:
		{
			stpwrioctl *pCmd  = (stpwrioctl*)pInBuf;
			//	stpwrinfo  *pInfo = (stpwrinfo *)pOutBuf;

			if (pCmd == NULL)
				return FALSE;

			switch(pCmd->cmd)
			{
				case PWR_CMD_OFF:
					keypwrinfo.status = PWR_STATUS_OFF;
					result = SuspendThread(stKeypadInfo.ThreadHandle);
					RETAILMSG(TRUE,(TEXT("[KEY         ]:TESTLOG:KEY Power OFF\n")));
					break;

				case PWR_CMD_ON:
					keypwrinfo.status = PWR_STATUS_ON;
					result = ResumeThread(stKeypadInfo.ThreadHandle);
					RETAILMSG(TRUE,(TEXT("[KEY         ]:TESTLOG:KEY Power ON\n")));
					break;

				case PWR_CMD_GETSTATUS:
					memcpy(pOutBuf, &keypwrinfo, sizeof(stpwrinfo));
					*pdwBytesTransferred = sizeof(stpwrinfo);
					break;

				default:
					return FALSE;	//break;
			}
		}
		break;
    }
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]-IOCTL\n\r")));
	return TRUE;
}


 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
VOID	KEY_PowerDown( DWORD dwContext )
{
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]+PowerDown\n\r")));
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]-PowerDown\n\r")));
    UNREFERENCED_PARAMETER(dwContext);
}


 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
VOID	KEY_PowerUp( DWORD dwContext )
{
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]+PowerUp\n\r")));
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]+PowerUp\n\r")));
    UNREFERENCED_PARAMETER(dwContext);
}


 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD	KEY_Open( DWORD Context, DWORD Access, DWORD ShareMode)
{
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]+Open\n\r")));
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]-Open\n\r")));
    //	DEBUGMSG(ZONE_FUNCTION,(_T("KEY_Open(%x, 0x%x, 0x%x)\r\n"),Context, Access, ShareMode));
    //	UNREFERENCED_PARAMETER(Context);	
    //	UNREFERENCED_PARAMETER(Access);
    //	UNREFERENCED_PARAMETER(ShareMode);
    return 1; // Success
}


 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL	KEY_Close( DWORD Context ) 
{
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]+Close\n\r")));
    RETAILMSG( TC_LOG_LEVEL(TC_TRACE), (_T("[KEY         ]-Close\n\r")));
        //DEBUGMSG(ZONE_FUNCTION,(_T("KEY_Close(%x)\r\n"), Context));
    return TRUE;
}


 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD	KEY_Read( DWORD  dwContext, LPVOID pBuf, DWORD  Len ) 
{
    UNREFERENCED_PARAMETER(dwContext);
    UNREFERENCED_PARAMETER(pBuf);
    UNREFERENCED_PARAMETER(Len);
    
    //DEBUGMSG(ZONE_ERROR | ZONE_FUNCTION,(_T("KEY_Read\r\n")));
    SetLastError(ERROR_INVALID_FUNCTION);
    return  0;
}


 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD	KEY_Write( DWORD  dwContext, LPVOID pBuf, DWORD  Len ) 
{
    UNREFERENCED_PARAMETER(dwContext);
    UNREFERENCED_PARAMETER(pBuf);
    UNREFERENCED_PARAMETER(Len);
    
    //DEBUGMSG(ZONE_ERROR | ZONE_FUNCTION,(_T("KEY_Read\r\n")));
    SetLastError(ERROR_INVALID_FUNCTION);
    return  0;
}


 /************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/
ULONG	KEY_Seek( PVOID Context, LONG Position, DWORD Type )
{
    UNREFERENCED_PARAMETER(Context);
    UNREFERENCED_PARAMETER(Position);
    UNREFERENCED_PARAMETER(Type);
    
    //return (DWORD)-1;
	return 0;
}

/************************************************************************************************
* FUNCTION		: 
BOOL DllEntry(HINSTANCE   hinstDll,	   //@parm Instance pointer. 
			  DWORD       dwReason,    //@parm Reason routine is called. 
			  LPVOID      lpReserved   //@parm system parameter. 
			  )
* DESCRIPTION	:  
*
************************************************************************************************/
BOOL 	DllEntry( HANDLE hDllHandle, DWORD  dwReason, LPVOID lpreserved ) 
{
    BOOL bRc = TRUE;
    
    UNREFERENCED_PARAMETER(hDllHandle);
    UNREFERENCED_PARAMETER(lpreserved);
    
    switch (dwReason) {
        case DLL_PROCESS_ATTACH: 
            {
                DEBUGREGISTER((HINSTANCE)hDllHandle);
                //DEBUGMSG(ZONE_INIT,(_T("*** DLL_PROCESS_ATTACH - Current Process: 0x%x, ID: 0x%x ***\r\n"),
                DisableThreadLibraryCalls(hDllHandle);
            } 
            break;

        case DLL_PROCESS_DETACH: 
            {
                //DEBUGMSG(ZONE_INIT,(_T("*** DLL_PROCESS_DETACH - Current Process: 0x%x, ID: 0x%x ***\r\n"),
                
            } 
            break;

        default:
            break;
    }
	
    return bRc;
}
