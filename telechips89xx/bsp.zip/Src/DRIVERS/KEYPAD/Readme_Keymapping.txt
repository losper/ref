
TCC7901 Evaluate Board KEYPAD Mapping


A0 A1 A2 A3 A4 A5
B0 B1 B2 B3 B4 B5

+---------------------------------------------+
|  RST  | Start |  ALT  | SPACE |  UP  | TAB  |
+---------------------------------------------+
|  ESC  |RButton|  LEFT | RIGHT | DOWN | ENTER|
+---------------------------------------------+


{1370, 1410, 0x5B}, //VK_LWIN
{1730, 1780, 0x12}, //VK_MENU
{90, 130, 0x20}, // VK_SPACE
{350, 390, 0x26}, //VK_UP
{1120, 1170, 0x09}, //VK_TAB
{3730, 4100, 0x1B}, //VK_ESCAPE
{920, 970, 0x02}, //VK_RBUTTON
{3280,3340, 0x25}, //VK_LEFT
{2780, 2840, 0x27}, //VK_RIGHT
{600, 660, 0x28}, // VK_DOWN
{2780, 2350, 0x0D}, // VK_RETURN
