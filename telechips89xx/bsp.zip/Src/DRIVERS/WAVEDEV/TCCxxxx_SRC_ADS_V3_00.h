

/*************************************************************
 
 			Telechips Inc., 2007
			 
 			All rights reserved
 
FILE:			TCCxxxx_SRC_ADS_V3.00.h

DESCRIPTION:	Sampling Rate Converter interface definitions.
 
************************************************************/
#ifndef _TCCxxx_SRC_ADS_H_
#define _TCCxxx_SRC_ADS_H_

//
//	funciton prototype define..
//
#ifdef __cplusplus
extern "C" {
#endif

int TC_SRC_init(void **ppSRC_handles, int fs_in, int fs_out, int nch, int nsize, unsigned char *pHeapMemory, int heapsize);
int TC_SRC_process(void *pSRC_handles, short *ldata, short *rdata, short *ldata_out, short *rdata_out, int nsamples);
int TC_SRC_finish(void *pSRC_handles, short *ldata, short *rdata, short *ldata_out, short *rdata_out, int nsamples);
int TC_SRC_get_remains(void *pSRC_handles, short *ldata, short *rdata, short *ldata_out, short *rdata_out, int nsamples);

#ifdef __cplusplus
}
#endif
#endif//_TCCxxx_SRC_ADS_H_