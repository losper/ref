
/****************************************************************************
 *   FileName    : TLV320AC.H
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include <windows.h>


//******************************* Register Map *******************************
// The audio codec is configured via a set of registers by issuing
// a Control Word.
//
// Control Word Size = 16 bits	where:	Bits[15-9]	- Control Address
//										Bits[8-0]	- Control Data
//

//------ Register Control Addresses -----					
#define LEFT_LINE_INPUT_VOLUME			0x0000
#define RIGHT_LINE_INPUT_VOLUME			0x0200
#define LEFT_CHANNEL_HP_VOLUME			0x0400
#define RIGHT_CHANNEL_HP_VOLUME			0x0600
#define ANALOG_AUDIO_CONTROL			0x0800
#define DIGITAL_AUDIO_CONTROL			0x0A00
#define POWER_DOWN_CONTROL				0x0C00
#define DIGITAL_AUDIO_FORMAT			0x0E00
#define SAMPLE_RATE_CONTROL				0x1000
#define DIGITAL_INTERFACE_ACT			0x1200
#define RESET_CONTROL					0x1E00

//*****************************************************************************

//----- Left line input volume control register -----
#define LRS_ENABLED						0x0100	 // Left/right simultaneous volume/mute update
#define LIM_MUTED						0x0080	 // Left line input muted
#define LIV_DEFAULT						0x0017   // Max volume

//----- Right line input volume control register -----
#define RLS_ENABLED						0x0100	 // Left/right simultaneous volume/mute update
#define RIM_MUTED						0x0080	 // Right line input muted
#define RIV_DEFAULT						0x0017   // Max volume

//----- Left channel headphone volume control register -----
#define LRS_ENABLED						0x0100	// Left/right simultaneous volume/mute update
#define LZC_ON							0x0080	// Left channel zero-cross detect
#define LHV_MAX							0x007F	// Max volume
#define LHV_DEFAULT						0x0070  // Default volume
#define LHV_MUTED						0x0000	// No volume (muted)

//----- Right channel headphone volume control register -----
#define RLS_ENABLED						0x0100	// Left/right simultaneous volume/mute update
#define RZC_ON							0x0080	// Right channel zero-cross detect
#define RHV_MAX							0x007F	// Max volume
#define RHV_DEFAULT						0x0079  // Default volume
#define RHV_MUTED						0x0000	// No volume (muted)

//----- Analog audio path control register -----
#define STA_6DB							0x0000	// Sidetone attenuation (-6DB)
#define STA_9DB							0x0040	// Sidetone attenuation (-9DB)
#define STA_12DB						0x0080	// Sidetone attenuation (-12DB)
#define STA_15DB						0x00C0	// Sidetone attenuation (-15DB)

#define STE_ENABLED						0x0020	// Sidetone enable
#define DAC_SELECTED					0x0010	// DAC select
#define BYPASS_ON						0x0008	
#define INSEL_MIC						0x0004	// Input select for ADC
#define MICM_MUTED						0x0002	// Microphone muted
#define MICB_20DB						0x0001	// Microphone boost

//----- Digital audio path control register -----
#define DACM_MUTE						0x0008	// DAC soft mute
#define DEEMP_32K						0x0002	// Deemphasis control (32K)
#define DEEMP_44K						0x0004	// Deemphasis control (44K)
#define DEEMP_48K						0x0006	// Deemphasis control (48K)
#define ADCHP_ON						0x0001	// ADC high-pass filter

//----- Power control down register -----
#define DEVICE_POWER_ON					0x0100	// Turn the device on
#define DEVICE_POWER_OFF				0x0080	// Turn the device off
#define CLK_OFF							0x0040	// Turn the clock off
#define OSC_OFF							0x0020	// Turn the oscillator off
#define OUT_OFF							0x0010	// Turn the outputs off
#define DAC_OFF							0x0008	// Turn the DAC off
#define ADC_OFF							0x0004	// Turn the ADC off
#define MIC_OFF							0x0002	// Turn the microphone off
#define LINE_OFF						0x0001	// Turn the line input off

//----- Digital audio interface register -----
#define MS_MASTER						0x0040	// Master mode
#define LRSWAP_ON						0x0020	// DAC left/right swap
#define LRP_ON							0x0010	// DAC left/right phase
#define IWL_16							0x0000	// Input bit length (16 bits)
#define IWL_20							0x0004	// Input bit length (20 bits)
#define IWL_24							0x0008	// Input bit length (24 bits)
#define IWL_32							0x000C	// Input bit length (32 bits)
#define FORMAT_MSBR						0x0000	// Data format (MSB first, right aligned)
#define FORMAT_MSBL						0x0001	// Data format (MSB first, left aligned)
#define FORMAT_I2S						0x0002	// Data format (I2S: MSB first, left-1 aligned)
#define FORMAT_DSP						0x0003	// DSP format (frame sync followed by 2 data words)

//----- Sample rate control register -----
#define CLKIN_FULL						0x0000	// Clock input rate (full speed)
#define CLKIN_HALF						0x0040	// Clock input rate (half speed)
#define CLKOUT_FULL						0x0000	// Clock output rate (full speed)	
#define CLKOUT_HALF						0x0080	// Clock output rate (half speed)

#define SR_44K							0x0020	// Sampling rate (44K) 
												// NOTE: The CPU's I2S module acts as the master and is configured
												//		 to generate a clock at 16.9344Mhz.  Looking into the datasheet
												//		 for this part, we find that at 16.9344Mhz the SR control bits
												//		 need to be set to {1000b} (with BOSR=FAST) in order for the ADC 
												//		 and DAC to run at 44.1Khz. 

#define BOSR_SLOW						0x0000	// Base oversampling rate (USB Mode = 250fs, Normal Mode = 256fs)
#define BOSR_FAST						0x0002	// Base oversampling rate (USB Mode = 272fs, Normal Mode = 384fs)
#define USB_CLK_ON						0x0001	// USB Mode

//----- Digital interface register -----
#define ACT_ON							0x0001	// Activate interface

//----- Reset register -----
#define RESET							0x0000	// Resets chip

