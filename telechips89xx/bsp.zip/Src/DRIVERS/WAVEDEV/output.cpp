//
// Copyright (c) Telechips Corporation.  All rights reserved.
//
//

#define SAMPLERATE_COMPENSATION
#ifdef SAMPLERATE_COMPENSATION
#define CONVERSION_FACTOR_BIT 16
#define CONVERSION_FACTOR_SIZE 65536 // 2^CONVERSION_FACTOR_BIT
#endif
#if defined(_SPDIF_COMMON_)
#include <bsp.h>
#include "tcc_wave.h"
#endif//defined(_SPDIF_COMMON_)
#include "wavemain.h"
#if defined(TC_SRC)
#include "TCCxxxx_SRC_ADS_V3_00.h"
#endif

extern DWORD SAMPLERATE;
#if defined(_MULTIL_DAO_INCLUDE_)
static DWORD 	m_DMABufClrStatus = 0;
static PBYTE	m_DMABufStatus[2*MAXDADONUM] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};
#endif

#if defined(TC_SRC)
DWORD OutputStreamContext::QueueBuffer(LPWAVEHDR lpWaveHdr)
{
	if (!(lpWaveHdr->dwFlags & WHDR_PREPARED))
	{
		return WAVERR_UNPREPARED;
	}

	lpWaveHdr->dwFlags |= WHDR_INQUEUE;
	lpWaveHdr->dwFlags &= ~WHDR_DONE;
	lpWaveHdr->lpNext=NULL;
	lpWaveHdr->dwBytesRecorded=0;

	if (!m_lpWaveHdrHead)
	{
		m_lpWaveHdrHead = lpWaveHdr;
	}
	else
	{
		m_lpWaveHdrTail->lpNext=lpWaveHdr;
	}

	m_lpWaveHdrTail=lpWaveHdr;

	// Note: Even if head & tail are valid, current may be NULL if we're in the middle of
	// a loop and ran out of data. So, we need to check specifically against current to
	// decide if we need to initialize it.
	if (!m_lpWaveHdrCurrent)
	{
		m_lpWaveHdrCurrent = lpWaveHdr;
		m_lpCurrData	= (PBYTE)lpWaveHdr->lpData;
		m_lpCurrDataEnd = (PBYTE)lpWaveHdr->lpData + lpWaveHdr->dwBufferLength;
		if (lpWaveHdr->dwFlags & WHDR_BEGINLOOP)	// if this is the start of a loop block
		{
			m_dwLoopCount = lpWaveHdr->dwLoops; 	// save # of loops
		}
		#if defined(TC_SRC)
		if(m_SRC_Frame != 0)
		{
			m_SRCOutputCur = 0;
			m_SRCOutputLen = 0;
			m_lpCurrDataSRC = m_lpCurrData;
			m_SRCInputLen = lpWaveHdr->dwBufferLength;
		}
		#endif		
	}

	if (m_bRunning)
	{
		m_pDeviceContext->StreamReadyToRender(this);
	} 
	else 
	{
		//RETAILMSG(1,(L"[WAVEDEV	  ]?"));
	}

	return MMSYSERR_NOERROR;
}

PBYTE OutputStreamContext::GetNextBuffer()
{
	LPWAVEHDR lpOldHdr;
	LPWAVEHDR lpNewHdr;
	LPSTR pNewBuf=NULL;

	// Get a pointer to the current buffer which is now done being processed
	lpOldHdr=m_lpWaveHdrCurrent;

	if (!lpOldHdr)
	{
		return NULL;
	}

	// Are we in a loop
	// Note: a loopcount of 1 means we're not really in a loop
	if (m_dwLoopCount>1)
	{
		// We're in a loop!
		if (lpOldHdr->dwFlags & WHDR_ENDLOOP)
		{
		   // In loop, last buffer
			// If dwLoopCount was set to INFINITE, loop forever
			// (Note: this is not explicitly in the wave driver API spec)
			if (m_dwLoopCount!=INFINITE)
			{
		   m_dwLoopCount--; 				   // decrement loop count
			}
		   lpNewHdr=m_lpWaveHdrHead;		   // go back to start of loop
		}
		else
		{
		   // In loop, intermediate buffer
		   lpNewHdr=lpOldHdr->lpNext;		   // just go to next buffer in loop block
		}

		lpOldHdr=NULL;
	}
	else
	{
		// Not in a loop; return old buffer and get new buffer
		lpNewHdr=lpOldHdr->lpNext;

		m_lpWaveHdrHead = lpNewHdr; 		  // reset list head
		if (!lpNewHdr)
		{
			m_lpWaveHdrTail=NULL;			  // no new buffer, reset tail to NULL
		}
		else if (lpNewHdr->dwFlags & WHDR_BEGINLOOP)	// if new buffer is start of a loop block
		{
			m_dwLoopCount=lpNewHdr->dwLoops;  // save # of loops
		}
	}

	m_lpWaveHdrCurrent=lpNewHdr;			  // save current buffer pointer

	if (lpNewHdr)
	{
		m_lpCurrData	= (PBYTE)lpNewHdr->lpData;	// reinitialize data pointer
		m_lpCurrDataEnd = m_lpCurrData + lpNewHdr->dwBufferLength;

		#if defined(TC_SRC)
		if(m_SRC_Frame != 0)
		{
			m_SRCOutputCur = 0;
			m_SRCOutputLen = 0;
			m_lpCurrDataSRC = m_lpCurrData;
			m_SRCInputLen = lpNewHdr->dwBufferLength;
		}
		#endif		
	}
	else
	{
		m_lpCurrData  = NULL;
		m_lpCurrDataEnd = NULL;
	}

	// Return the old buffer
	// This may cause the stream to be destroyed, so make sure that any calls to this function
	// are within an AddRef/Release block
	if (lpOldHdr)
	{
		ReturnBuffer(lpOldHdr);
	}

	return m_lpCurrData;
}
#endif
HRESULT OutputStreamContext::Open(DeviceContext *pDeviceContext, LPWAVEOPENDESC lpWOD, DWORD dwFlags)
{
    HRESULT Result;

    Result = WaveStreamContext::Open(pDeviceContext, lpWOD, dwFlags);
#if defined(TC_SRC)
	if(m_WaveFormat.nSamplesPerSec < 44100)
	{
		extern DWORD AUDIO_DMA_PAGE_SIZE;	
		
		if(m_WaveFormat.wBitsPerSample == 16)
		{
			if(m_WaveFormat.nSamplesPerSec >= 32000)
				m_SRC_Frame = AUDIO_DMA_PAGE_SIZE>>2;
			else if(m_WaveFormat.nSamplesPerSec >= 11025)
				m_SRC_Frame = AUDIO_DMA_PAGE_SIZE>>3;
			else
				m_SRC_Frame = AUDIO_DMA_PAGE_SIZE>>4;
		}
		else
		{
			if(m_WaveFormat.nSamplesPerSec >= 32000)
				m_SRC_Frame = AUDIO_DMA_PAGE_SIZE>>3;
			else if(m_WaveFormat.nSamplesPerSec >= 11025)
				m_SRC_Frame = AUDIO_DMA_PAGE_SIZE>>4;
			else
				m_SRC_Frame = AUDIO_DMA_PAGE_SIZE>>5;
		}
		
		int iRet = TC_SRC_init(&(m_SRC_handles), m_WaveFormat.nSamplesPerSec, SAMPLERATE, 
			m_WaveFormat.nChannels, m_SRC_Frame, m_SRCHeapMemory, SRC_HEAP_SIZE);

		if(iRet < 0)
		{
			RETAILMSG(1,(TEXT("[WAVEDEV	  ]TC_SRC_Init Error iRet = %d\r\n"),iRet));
			m_SRC_Frame = 0;			
		}
	}
	else
		m_SRC_Frame = 0;
#endif

    if (Result==MMSYSERR_NOERROR)
    {
        // Note: Output streams should be initialized in the run state.
        Run();
    }

    return Result;
}

DWORD OutputStreamContext::Close()
{
	HRESULT Result;

	Result = WaveStreamContext::Close();

#if defined(TC_SRC)
	if(m_SRC_Frame != 0)
	{
		TC_SRC_finish(
			this->m_SRC_handles,
			(short*)this->m_SRCInputL, (short*)this->m_SRCInputR,
			(short*)this->m_SRCOutputL, (short*)this->m_SRCOutputR,
			this->m_SRCInputLen);

		//printf("TC_SRC_finish\r\n");
			
	}
#endif	
	return Result;
};

DWORD OutputStreamContext::Reset()
{
    HRESULT Result;

    Result = WaveStreamContext::Reset();

    if (Result==MMSYSERR_NOERROR)
    {
        // Note: Output streams should be reset to the run state.
        Run();
    }

    return Result;
};

// Init m_DeltaT with (SampleRate/HWSampleRate) calculated in 24.8 fixed point form
// Note that we need to hold the result in a 64-bit value until we're done shifting,
// since the result of the multiply will overflow 32 bits for sample rates greater than
// or equal to the hardware's sample rate.
DWORD OutputStreamContext::SetRate(DWORD dwMultiplier)
{
    m_dwMultiplier = dwMultiplier;
#if defined(_MULTIL_DAO_INCLUDE_)
	UINT64 Delta = (m_WaveFormat.Format.nSamplesPerSec * m_dwMultiplier) >> 16;
#else
    UINT64 Delta = (m_WaveFormat.nSamplesPerSec * m_dwMultiplier) >> 16;
#endif
#ifndef SAMPLERATE_COMPENSATION
	DWORD INVSAMPLERATE = ((UINT32)(((1i64<<32)/SAMPLERATE)+1));
    Delta = (Delta * INVSAMPLERATE) >> 24;  // Convert to 24.8 format
#else
	DWORD INVSAMPLERATE = ((UINT32)(((1i64<<32)/SAMPLERATE)+1));
    Delta = (Delta * INVSAMPLERATE) >> (32-CONVERSION_FACTOR_BIT);  // Convert to 16.16 format
	//printf("Delta=%I64d\n",Delta);
#endif
    m_DeltaT = (DWORD)Delta;

    return MMSYSERR_NOERROR;
}

// Originally, this code used to be in each renderer, and each one would call GetNextBuffer as needed.
// Pulling this code out of each low level renderer allows the inner loop to be in a leaf routine (ie no
// subroutine calls out of that routine), which helps the compiler optimize the inner loop.
PBYTE WaveStreamContext::Render(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
    if (!m_bRunning || !m_lpCurrData)
    {
        return pBuffer;
    }

    while (pBuffer < pBufferEnd)
    {
        while (m_lpCurrData>=m_lpCurrDataEnd)
        {
            if (!GetNextBuffer())
            {
                return pBuffer;
            }
        }

        pBuffer = Render2(pBuffer,pBufferEnd,pBufferLast);
    }

    return pBuffer;
}

PBYTE OutputStreamContextM8::Render2(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
    LONG CurrT = m_CurrT;
    LONG DeltaT = m_DeltaT;
    LONG CurrSamp0;
    LONG PrevSamp0;
    PBYTE pCurrData = m_lpCurrData;
    PBYTE pCurrDataEnd = m_lpCurrDataEnd;
    LONG fxpGain = m_fxpGain;
	LONG OutSamp0;

	CurrSamp0 = m_CurrSamp[m_CurChBufNum[0]];
	PrevSamp0 = m_PrevSamp[m_CurChBufNum[0]];

    while (pBuffer < pBufferEnd)
    {
#if defined(TC_SRC)
		if(m_SRC_Frame == 0)
		{
#endif			
			#ifndef SAMPLERATE_COMPENSATION
	        while (CurrT >= 0x100)
			#else
		 	while (CurrT >= CONVERSION_FACTOR_SIZE)
			#endif
	        {
	            if (pCurrData>=pCurrDataEnd)
	            {
	                goto Exit;
	            }
				#ifndef SAMPLERATE_COMPENSATION
	            CurrT -= 0x100;
				#else
	            CurrT -= CONVERSION_FACTOR_SIZE;
				#endif
	            PrevSamp0 = CurrSamp0;

	            PPCM_SAMPLE pSampleSrc = (PPCM_SAMPLE)pCurrData;
	            CurrSamp0 = (LONG)pSampleSrc->m8.sample;
	            CurrSamp0 = (CurrSamp0 - 128) << 8;
	            pCurrData+=1;
	        }

			#ifndef SAMPLERATE_COMPENSATION		
	        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> 8);
			#else
	        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> CONVERSION_FACTOR_BIT);
			#endif
#if defined(TC_SRC)
		}
		else
		{
			if(	m_SRCOutputCur >= m_SRCOutputLen)
			{
				if(m_SRCInputLen == 0)
				{
					pCurrData = pCurrDataEnd;
					goto Exit;
				}
				int iInc = 0, iCurSRCFrameLen;
				PPCM_SAMPLE pSampleSrc;
				int SRCInputLen;
				m_SRCOutputCur = 0;

				if(m_SRCInputLen > m_SRC_Frame)
					SRCInputLen = m_SRC_Frame;
				else
					SRCInputLen = m_SRCInputLen;

				iCurSRCFrameLen = SRCInputLen;

				while(iInc < iCurSRCFrameLen)
				{
					pSampleSrc = (PPCM_SAMPLE)m_lpCurrDataSRC;
					m_SRCInputL[iInc] = ((unsigned short)pSampleSrc->m8.sample - 128) << 8;
					m_lpCurrDataSRC++;
					iInc++;
				}

				m_SRCOutputLen = TC_SRC_process(
					m_SRC_handles,
					(short*)m_SRCInputL, NULL,
					(short*)m_SRCOutputL, NULL,
					SRCInputLen);

				if(m_SRCOutputLen <= 0)
				{
					if(m_SRCOutputLen < 0)
						RETAILMSG(1,(TEXT("[WAVEDEV	  ]M8 Render2 SRC Error!!\r\n")));
					
					pCurrData = pCurrDataEnd;
					m_SRC_Frame = 0;
					goto Exit;
				}

				m_SRCInputLen -= SRCInputLen; 						
			}

			OutSamp0 = m_SRCOutputL[m_SRCOutputCur] << 16 >>16;
			m_SRCOutputCur++;
		}
#endif
        OutSamp0 = (OutSamp0 * fxpGain) >> VOLSHIFT;
        CurrT += DeltaT;

#if (OUTCHANNELS==2)
        LONG OutSamp1;
        OutSamp1=OutSamp0;
#if defined(_MULTIL_DAO_INCLUDE_)
		if((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[m_CurChBufNum[0]]) 
		{
			OutSamp0 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]];
#if USE_MIX_SATURATE
			// Handle saturation
			if (OutSamp0>AUDIO_SAMPLE_MAX)
				OutSamp0=AUDIO_SAMPLE_MAX;
			else if (OutSamp0<AUDIO_SAMPLE_MIN)
				OutSamp0=AUDIO_SAMPLE_MIN;
#endif
		}
		if((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[m_CurChBufNum[1]]) 
		{
			OutSamp1 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]];
#if USE_MIX_SATURATE
			// Handle saturation
			if (OutSamp1>AUDIO_SAMPLE_MAX)
				OutSamp1=AUDIO_SAMPLE_MAX;
			else if (OutSamp1<AUDIO_SAMPLE_MIN)
				OutSamp1=AUDIO_SAMPLE_MIN;
#endif
		}
		((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]] = (HWSAMPLE)OutSamp0;
		((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]] = (HWSAMPLE)OutSamp1;		
		pBuffer += 8*sizeof(HWSAMPLE);
#else			
		if (pBuffer < pBufferLast)
		{
			OutSamp0 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]];
			OutSamp1 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]];
#if USE_MIX_SATURATE
			// Handle saturation
			if (OutSamp0>AUDIO_SAMPLE_MAX)
			{
				OutSamp0=AUDIO_SAMPLE_MAX;
			}
			else if (OutSamp0<AUDIO_SAMPLE_MIN)
			{
				OutSamp0=AUDIO_SAMPLE_MIN;
			}
			if (OutSamp1>AUDIO_SAMPLE_MAX)
			{
				OutSamp1=AUDIO_SAMPLE_MAX;
			}
			else if (OutSamp1<AUDIO_SAMPLE_MIN)
			{
				OutSamp1=AUDIO_SAMPLE_MIN;
			}
#endif
		}
		((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]] = (HWSAMPLE)OutSamp0;
		((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]] = (HWSAMPLE)OutSamp1;
		pBuffer += 2*sizeof(HWSAMPLE);
#endif	
#else
        if (pBuffer < pBufferLast)
        {
            OutSamp0 += ((HWSAMPLE *)pBuffer)[0];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
            {
                OutSamp0=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
            {
                OutSamp0=AUDIO_SAMPLE_MIN;
            }
#endif
        }
        ((HWSAMPLE *)pBuffer)[0] = (HWSAMPLE)OutSamp0;
        pBuffer += sizeof(HWSAMPLE);
#endif
    }

    Exit:

    m_dwByteCount += (pCurrData - m_lpCurrData);
    m_lpCurrData = pCurrData;
    m_CurrT = CurrT;
    m_PrevSamp[m_CurChBufNum[0]] = PrevSamp0;
    m_CurrSamp[m_CurChBufNum[0]] = CurrSamp0;

#if defined(_MULTIL_DAO_INCLUDE_)
	if(pBuffer > m_DMABufStatus[m_CurChBufNum[0]])
		m_DMABufStatus[m_CurChBufNum[0]] = pBuffer+sizeof(HWSAMPLE)*m_CurChBufNum[0];
	if(pBuffer > m_DMABufStatus[m_CurChBufNum[1]])
		m_DMABufStatus[m_CurChBufNum[1]] = pBuffer+sizeof(HWSAMPLE)*m_CurChBufNum[1];
#endif
    return pBuffer;
}

PBYTE OutputStreamContextM16::Render2(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
    LONG CurrT = m_CurrT;
    LONG DeltaT = m_DeltaT;
    LONG CurrSamp0;
    LONG PrevSamp0;
    PBYTE pCurrData = m_lpCurrData;
    PBYTE pCurrDataEnd = m_lpCurrDataEnd;
    LONG fxpGain = m_fxpGain;
    LONG OutSamp0;

	CurrSamp0 = m_CurrSamp[m_CurChBufNum[0]];
	PrevSamp0 = m_PrevSamp[m_CurChBufNum[0]];

    while (pBuffer < pBufferEnd)
    {
#if defined(TC_SRC)
		if(m_SRC_Frame == 0)
		{
#endif	
			#ifndef SAMPLERATE_COMPENSATION
	        while (CurrT >= 0x100)
			#else
			 while (CurrT >= CONVERSION_FACTOR_SIZE)
			#endif
	        {
	            if (pCurrData>=pCurrDataEnd)
	            {				
	                goto Exit;
	            }

				#ifndef SAMPLERATE_COMPENSATION
	            CurrT -= 0x100;
				#else
	            CurrT -= CONVERSION_FACTOR_SIZE;
				#endif
	            PrevSamp0 = CurrSamp0;

	            PPCM_SAMPLE pSampleSrc = (PPCM_SAMPLE)pCurrData;
	            CurrSamp0 = (LONG)pSampleSrc->m16.sample;
	            pCurrData+=2;
	        }

			#ifndef SAMPLERATE_COMPENSATION		
	        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> 8);
			#else
	        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> CONVERSION_FACTOR_BIT);
			#endif
#if defined(TC_SRC)
		}
		else
		{
			if(	m_SRCOutputCur >= m_SRCOutputLen)
			{
				if(m_SRCInputLen == 0)
				{
					pCurrData = pCurrDataEnd;
					goto Exit;
				}
				int iInc = 0, iCurSRCFrameLen;
				PPCM_SAMPLE pSampleSrc;
				int SRCInputLen;
				m_SRCOutputCur = 0;

				if(m_SRCInputLen > m_SRC_Frame*2)
					SRCInputLen = m_SRC_Frame*2;
				else
					SRCInputLen = m_SRCInputLen;

				iCurSRCFrameLen = SRCInputLen>>1;

				while(iInc < iCurSRCFrameLen)
				{
					pSampleSrc = (PPCM_SAMPLE)m_lpCurrDataSRC;
					m_SRCInputL[iInc] = (unsigned short)pSampleSrc->m16.sample;
					m_lpCurrDataSRC+=2;
					iInc++;
				}

				m_SRCOutputLen = TC_SRC_process(
					m_SRC_handles,
					(short*)m_SRCInputL, NULL,
					(short*)m_SRCOutputL, NULL,
					SRCInputLen>>1);		

				if(m_SRCOutputLen <= 0)
				{
					if(m_SRCOutputLen < 0)
						RETAILMSG(1,(TEXT("[WAVEDEV	  ]M16 Render2 SRC Error!!\r\n")));
					
					pCurrData = pCurrDataEnd;
					m_SRC_Frame = 0;
					goto Exit;
				}

				m_SRCInputLen -= SRCInputLen;				
			}
			
			OutSamp0 = m_SRCOutputL[m_SRCOutputCur] << 16 >>16;
			m_SRCOutputCur++;
		}
#endif
		
        OutSamp0 = (OutSamp0 * fxpGain) >> VOLSHIFT;
        CurrT += DeltaT;
        // DEBUGMSG(1, (TEXT("[WAVEDEV     ]PrevSamp0=0x%x, CurrSamp0=0x%x, CurrT=0x%x, OutSamp0=0x%x\r\n"), PrevSamp0,CurrSamp0,CurrT,OutSamp0));

#if (OUTCHANNELS==2)
        LONG OutSamp1;
        OutSamp1=OutSamp0;
#if defined(_MULTIL_DAO_INCLUDE_)
		if((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[m_CurChBufNum[0]])	
        {
            OutSamp0 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
                OutSamp0=AUDIO_SAMPLE_MAX;
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
                OutSamp0=AUDIO_SAMPLE_MIN;
#endif
        }
		if((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[m_CurChBufNum[1]])	
        {
            OutSamp1 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp1>AUDIO_SAMPLE_MAX)
                OutSamp1=AUDIO_SAMPLE_MAX;
            else if (OutSamp1<AUDIO_SAMPLE_MIN)
                OutSamp1=AUDIO_SAMPLE_MIN;
#endif
        }		
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]] = (HWSAMPLE)OutSamp0;
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]] = (HWSAMPLE)OutSamp1;
		pBuffer += 8*sizeof(HWSAMPLE);
#else			
        if (pBuffer < pBufferLast)
        {
            OutSamp0 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]];
            OutSamp1 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
            {
                OutSamp0=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
            {
                OutSamp0=AUDIO_SAMPLE_MIN;
            }
            if (OutSamp1>AUDIO_SAMPLE_MAX)
            {
                OutSamp1=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp1<AUDIO_SAMPLE_MIN)
            {
                OutSamp1=AUDIO_SAMPLE_MIN;
            }
#endif
        }
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]] = (HWSAMPLE)OutSamp0;
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]] = (HWSAMPLE)OutSamp1;
		pBuffer += 2*sizeof(HWSAMPLE);
#endif			
#else
        if (pBuffer < pBufferLast)
        {
            OutSamp0 += ((HWSAMPLE *)pBuffer)[0];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
            {
                OutSamp0=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
            {
                OutSamp0=AUDIO_SAMPLE_MIN;
            }
#endif
        }
        ((HWSAMPLE *)pBuffer)[0] = (HWSAMPLE)OutSamp0;
        pBuffer += sizeof(HWSAMPLE);
#endif
    }

    Exit:
    m_dwByteCount += (pCurrData - m_lpCurrData);
    m_lpCurrData = pCurrData;
    m_CurrT = CurrT;
    m_PrevSamp[m_CurChBufNum[0]] = PrevSamp0;
    m_CurrSamp[m_CurChBufNum[0]] = CurrSamp0;
	
#if defined(_MULTIL_DAO_INCLUDE_)
	if(pBuffer > m_DMABufStatus[m_CurChBufNum[0]])
		m_DMABufStatus[m_CurChBufNum[0]] = pBuffer+sizeof(HWSAMPLE)*m_CurChBufNum[0];
	if(pBuffer > m_DMABufStatus[m_CurChBufNum[1]])
		m_DMABufStatus[m_CurChBufNum[1]] = pBuffer+sizeof(HWSAMPLE)*m_CurChBufNum[1];
#endif
    return pBuffer;
}

#if (OUTCHANNELS==2)
PBYTE OutputStreamContextS8::Render2(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
    LONG CurrT = m_CurrT;
    LONG DeltaT = m_DeltaT;
    LONG CurrSamp0;
    LONG CurrSamp1;
    LONG PrevSamp0;
    LONG PrevSamp1;
    PBYTE pCurrData = m_lpCurrData;
    PBYTE pCurrDataEnd = m_lpCurrDataEnd;
    LONG fxpGain = m_fxpGain;
    LONG OutSamp0;
    LONG OutSamp1;

	CurrSamp0 = m_CurrSamp[m_CurChBufNum[0]];
	CurrSamp1 = m_CurrSamp[m_CurChBufNum[1]];
	PrevSamp0 = m_PrevSamp[m_CurChBufNum[0]];
	PrevSamp1 = m_PrevSamp[m_CurChBufNum[1]];

    while (pBuffer < pBufferEnd)
    {
#if defined(TC_SRC)
		if(m_SRC_Frame == 0)
		{
#endif	
			#ifndef SAMPLERATE_COMPENSATION
	        while (CurrT >= 0x100)
			#else
			while (CurrT >= CONVERSION_FACTOR_SIZE)
			#endif
	        {
	            if (pCurrData>=pCurrDataEnd)
	            {
	                goto Exit;
	            }

				#ifndef SAMPLERATE_COMPENSATION
	            CurrT -= 0x100;
				#else
	            CurrT -= CONVERSION_FACTOR_SIZE;
				#endif

	            PrevSamp0 = CurrSamp0;
	            PrevSamp1 = CurrSamp1;

	            PPCM_SAMPLE pSampleSrc = (PPCM_SAMPLE)pCurrData;
	            CurrSamp0 =  (LONG)pSampleSrc->s8.sample_left;
	            CurrSamp0 = (CurrSamp0 - 128) << 8;
	            CurrSamp1 = (LONG)pSampleSrc->s8.sample_right;
	            CurrSamp1 = (CurrSamp1 - 128) << 8;
	            pCurrData+=2;
	        }

			#ifndef SAMPLERATE_COMPENSATION		
	        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> 8);
			#else
	        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> CONVERSION_FACTOR_BIT);
			#endif

			#ifndef SAMPLERATE_COMPENSATION		
	        OutSamp1 = PrevSamp1 + (((CurrSamp1 - PrevSamp1) * CurrT) >> 8);
			#else
	        OutSamp1 = PrevSamp1 + (((CurrSamp1 - PrevSamp1) * CurrT) >> CONVERSION_FACTOR_BIT);
			#endif		
#if defined(TC_SRC)
		}
		else
		{
			if(	m_SRCOutputCur >= m_SRCOutputLen)
			{
				if(m_SRCInputLen == 0)
				{
					pCurrData = pCurrDataEnd;
					goto Exit;
				}
				int iInc = 0, iCurSRCFrameLen;
				PPCM_SAMPLE pSampleSrc;
				int SRCInputLen;
				m_SRCOutputCur = 0;

				if(m_SRCInputLen > m_SRC_Frame*2)
					SRCInputLen = m_SRC_Frame*2;
				else
					SRCInputLen = m_SRCInputLen;

				iCurSRCFrameLen = SRCInputLen>>1;

				while(iInc < iCurSRCFrameLen)
				{
					pSampleSrc = (PPCM_SAMPLE)m_lpCurrDataSRC;
					m_SRCInputL[iInc] = ((unsigned short)pSampleSrc->s8.sample_left  - 128) << 8;;
					m_SRCInputR[iInc] = ((unsigned short)pSampleSrc->s8.sample_right - 128) << 8;;
					m_lpCurrDataSRC+=2;
					iInc++;
				}

				m_SRCOutputLen = TC_SRC_process(
					m_SRC_handles,
					(short*)m_SRCInputL, (short*)m_SRCInputR,
					(short*)m_SRCOutputL, (short*)m_SRCOutputR,
					SRCInputLen>>1);		

				if(m_SRCOutputLen <= 0)
				{
					if(m_SRCOutputLen < 0)
						RETAILMSG(1,(TEXT("[WAVEDEV	  ]S8 Render2 SRC Error!!\r\n")));
					
					pCurrData = pCurrDataEnd;
					m_SRC_Frame = 0;
					goto Exit;
				}
				
				m_SRCInputLen -= SRCInputLen;			
					
			}

			OutSamp0 = m_SRCOutputL[m_SRCOutputCur] << 16 >> 16;
			OutSamp1 = m_SRCOutputR[m_SRCOutputCur] << 16 >> 16;
			m_SRCOutputCur++;
		}
#endif
        OutSamp0 = (OutSamp0 * fxpGain) >> VOLSHIFT;
        OutSamp1 = (OutSamp1 * fxpGain) >> VOLSHIFT;
        CurrT += DeltaT;
        // DEBUGMSG(1, (TEXT("[WAVEDEV     ]PrevSamp0=0x%x, CurrSamp0=0x%x, CurrT=0x%x, OutSamp0=0x%x\r\n"), PrevSamp0,CurrSamp0,CurrT,OutSamp0));

#if defined(_MULTIL_DAO_INCLUDE_)
		if((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[m_CurChBufNum[0]]) 	
        {
            OutSamp0 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
                OutSamp0=AUDIO_SAMPLE_MAX;
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
                OutSamp0=AUDIO_SAMPLE_MIN;
#endif
        }
		if((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[m_CurChBufNum[1]]) 	
        {
            OutSamp1 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp1>AUDIO_SAMPLE_MAX)
                OutSamp1=AUDIO_SAMPLE_MAX;
            else if (OutSamp1<AUDIO_SAMPLE_MIN)
                OutSamp1=AUDIO_SAMPLE_MIN;
#endif
        }		
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]] = (HWSAMPLE)OutSamp0;
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]] = (HWSAMPLE)OutSamp1;

		pBuffer += 8*sizeof(HWSAMPLE);
#else			
		if (pBuffer < pBufferLast)
        {
            OutSamp0 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]];
            OutSamp1 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
            {
                OutSamp0=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
            {
                OutSamp0=AUDIO_SAMPLE_MIN;
            }
            if (OutSamp1>AUDIO_SAMPLE_MAX)
            {
                OutSamp1=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp1<AUDIO_SAMPLE_MIN)
            {
                OutSamp1=AUDIO_SAMPLE_MIN;
            }
#endif
        }
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]] = (HWSAMPLE)OutSamp0;
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]] = (HWSAMPLE)OutSamp1;

		pBuffer += 2*sizeof(HWSAMPLE);
#endif	
    }

    Exit:
    m_dwByteCount += (pCurrData - m_lpCurrData);
    m_lpCurrData = pCurrData;
    m_CurrT = CurrT;
    m_PrevSamp[m_CurChBufNum[0]] = PrevSamp0;
    m_PrevSamp[m_CurChBufNum[1]] = PrevSamp1;
    m_CurrSamp[m_CurChBufNum[0]] = CurrSamp0;
    m_CurrSamp[m_CurChBufNum[1]] = CurrSamp1;

#if defined(_MULTIL_DAO_INCLUDE_)
	if(pBuffer > m_DMABufStatus[m_CurChBufNum[0]])
		m_DMABufStatus[m_CurChBufNum[0]] = pBuffer+sizeof(HWSAMPLE)*m_CurChBufNum[0];
	if(pBuffer > m_DMABufStatus[m_CurChBufNum[1]])
		m_DMABufStatus[m_CurChBufNum[1]] = pBuffer+sizeof(HWSAMPLE)*m_CurChBufNum[1];
#endif
    return pBuffer;
}

PBYTE OutputStreamContextS16::Render2(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
    LONG CurrT = m_CurrT;
    LONG DeltaT = m_DeltaT;
    LONG CurrSamp0;
    LONG CurrSamp1;
    LONG PrevSamp0;
    LONG PrevSamp1;
    PBYTE pCurrData = m_lpCurrData;
    PBYTE pCurrDataEnd = m_lpCurrDataEnd;
    LONG fxpGain = m_fxpGain;
    LONG OutSamp0;
    LONG OutSamp1;

	CurrSamp0 = m_CurrSamp[m_CurChBufNum[0]];
	CurrSamp1 = m_CurrSamp[m_CurChBufNum[1]];
	PrevSamp0 = m_PrevSamp[m_CurChBufNum[0]];
	PrevSamp1 = m_PrevSamp[m_CurChBufNum[1]];

    while (pBuffer < pBufferEnd)
    {
#if defined(TC_SRC)
		if(m_SRC_Frame == 0)
		{
#endif	
			#ifndef SAMPLERATE_COMPENSATION
	        while (CurrT >= 0x100)
			#else
			while (CurrT >= CONVERSION_FACTOR_SIZE)
			#endif
	        {
	            if (pCurrData>=pCurrDataEnd)
	            {				
	                goto Exit;
	            }

				#ifndef SAMPLERATE_COMPENSATION
	            CurrT -= 0x100;
				#else
	            CurrT -= CONVERSION_FACTOR_SIZE;
				#endif

	            PrevSamp0 = CurrSamp0;
	            PrevSamp1 = CurrSamp1;

	            PPCM_SAMPLE pSampleSrc = (PPCM_SAMPLE)pCurrData;
	            CurrSamp0 = (LONG)pSampleSrc->s16.sample_left;
	            CurrSamp1 = (LONG)pSampleSrc->s16.sample_right;
	            pCurrData+=4;
	        }

			#ifndef SAMPLERATE_COMPENSATION		
	        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> 8);
			#else
	        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> CONVERSION_FACTOR_BIT);
			#endif

			#ifndef SAMPLERATE_COMPENSATION		
	        OutSamp1 = PrevSamp1 + (((CurrSamp1 - PrevSamp1) * CurrT) >> 8);
			#else
	        OutSamp1 = PrevSamp1 + (((CurrSamp1 - PrevSamp1) * CurrT) >> CONVERSION_FACTOR_BIT);
			#endif
#if defined(TC_SRC)
		}
		else
		{
			if( m_SRCOutputCur >= m_SRCOutputLen)
			{
				if(m_SRCInputLen == 0)
				{
					pCurrData = pCurrDataEnd;
					goto Exit;
				}
				
				int iInc = 0, iCurSRCFrameLen;
				PPCM_SAMPLE pSampleSrc;
				int SRCInputLen;
				m_SRCOutputCur = 0;

				if(m_SRCInputLen > m_SRC_Frame*4)
					SRCInputLen = m_SRC_Frame*4;
				else
					SRCInputLen = m_SRCInputLen;

				iCurSRCFrameLen = SRCInputLen>>2;

				while(iInc < iCurSRCFrameLen)
				{
					pSampleSrc = (PPCM_SAMPLE)m_lpCurrDataSRC;
					m_SRCInputL[iInc] = (unsigned short)pSampleSrc->s16.sample_left;
					m_SRCInputR[iInc] = (unsigned short)pSampleSrc->s16.sample_right;
					m_lpCurrDataSRC+=4;
					iInc++;
				}
					
				m_SRCOutputLen = TC_SRC_process(
					m_SRC_handles,
					(short*)m_SRCInputL, (short*)m_SRCInputR,
					(short*)m_SRCOutputL, (short*)m_SRCOutputR,
					SRCInputLen>>2);
		
				if(m_SRCOutputLen <= 0)
				{
					if(m_SRCOutputLen < 0)
						RETAILMSG(1,(TEXT("[WAVEDEV	  ]S16 Render2 SRC Error!!\r\n")));
					
					pCurrData = pCurrDataEnd;
					m_SRC_Frame = 0;
					goto Exit;
				}

				m_SRCInputLen -= SRCInputLen;
			}

			OutSamp0 = m_SRCOutputL[m_SRCOutputCur] << 16 >>16;
			OutSamp1 = m_SRCOutputR[m_SRCOutputCur] << 16 >>16;
			m_SRCOutputCur++;
		}
#endif
        OutSamp0 = (OutSamp0 * fxpGain) >> VOLSHIFT;
        OutSamp1 = (OutSamp1 * fxpGain) >> VOLSHIFT;
        CurrT += DeltaT;
        
        // DEBUGMSG(1, (TEXT("PrevSamp0=0x%x, CurrSamp0=0x%x, CurrT=0x%x, OutSamp0=0x%x\r\n"), PrevSamp0,CurrSamp0,CurrT,OutSamp0));

#if defined(_MULTIL_DAO_INCLUDE_)
		if((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[m_CurChBufNum[0]]) 	
        {
            OutSamp0 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
                OutSamp0=AUDIO_SAMPLE_MAX;
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
                OutSamp0=AUDIO_SAMPLE_MIN;
#endif
        }
		if((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[m_CurChBufNum[1]])	
		{
			OutSamp1 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]];
#if USE_MIX_SATURATE
			// Handle saturation
			if (OutSamp1>AUDIO_SAMPLE_MAX)
				OutSamp1=AUDIO_SAMPLE_MAX;
			else if (OutSamp1<AUDIO_SAMPLE_MIN)
				OutSamp1=AUDIO_SAMPLE_MIN;
#endif
		}
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]] = (HWSAMPLE)OutSamp0;
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]] = (HWSAMPLE)OutSamp1;

		pBuffer += 8*sizeof(HWSAMPLE);
#else			
		if (pBuffer < pBufferLast)
        {
            OutSamp0 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]];
            OutSamp1 += ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]];
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
            {
                OutSamp0=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
            {
                OutSamp0=AUDIO_SAMPLE_MIN;
            }
            if (OutSamp1>AUDIO_SAMPLE_MAX)
            {
                OutSamp1=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp1<AUDIO_SAMPLE_MIN)
            {
                OutSamp1=AUDIO_SAMPLE_MIN;
            }
#endif
        }
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[0]] = (HWSAMPLE)OutSamp0;
        ((HWSAMPLE *)pBuffer)[m_CurChBufNum[1]] = (HWSAMPLE)OutSamp1;

		pBuffer += 2*sizeof(HWSAMPLE);
#endif	
    }

    Exit:
    m_dwByteCount += (pCurrData - m_lpCurrData);
    m_lpCurrData = pCurrData;
    m_CurrT = CurrT;
    m_PrevSamp[m_CurChBufNum[0]] = PrevSamp0;
    m_PrevSamp[m_CurChBufNum[1]] = PrevSamp1;
    m_CurrSamp[m_CurChBufNum[0]] = CurrSamp0;
    m_CurrSamp[m_CurChBufNum[1]] = CurrSamp1;
	
#if defined(_MULTIL_DAO_INCLUDE_)
	if(pBuffer > m_DMABufStatus[m_CurChBufNum[0]])
		m_DMABufStatus[m_CurChBufNum[0]] = pBuffer+sizeof(HWSAMPLE)*m_CurChBufNum[0];
	if(pBuffer > m_DMABufStatus[m_CurChBufNum[1]])
		m_DMABufStatus[m_CurChBufNum[1]] = pBuffer+sizeof(HWSAMPLE)*m_CurChBufNum[1];
#endif
    return pBuffer;
}

#else

PBYTE OutputStreamContextS8::Render2(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
    LONG CurrT = m_CurrT;
    LONG DeltaT = m_DeltaT;
    LONG CurrSamp0 = m_CurrSamp[0];
    LONG PrevSamp0 = m_PrevSamp[0];
    PBYTE pCurrData = m_lpCurrData;
    PBYTE pCurrDataEnd = m_lpCurrDataEnd;
    LONG fxpGain = m_fxpGain;
    LONG OutSamp0;

    while (pBuffer < pBufferEnd)
    {
#ifndef SAMPLERATE_COMPENSATION
        while (CurrT >= 0x100)
#else
	 while (CurrT >= CONVERSION_FACTOR_SIZE)
#endif
        {
            if (pCurrData>=pCurrDataEnd)
            {
                goto Exit;
            }

#ifndef SAMPLERATE_COMPENSATION
            CurrT -= 0x100;
#else
            CurrT -= CONVERSION_FACTOR_SIZE;
#endif

            PrevSamp0 = CurrSamp0;

            PPCM_SAMPLE pSampleSrc = (PPCM_SAMPLE)pCurrData;
            CurrSamp0 =  (LONG)pSampleSrc->s8.sample_left;
            CurrSamp0 += (LONG)pSampleSrc->s8.sample_right;
            CurrSamp0 = (CurrSamp0 - 256) << 7;
            pCurrData+=2;
        }

#ifndef SAMPLERATE_COMPENSATION		
        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> 8);
#else
        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> CONVERSION_FACTOR_BIT);
#endif
        OutSamp0 = (OutSamp0 * fxpGain) >> VOLSHIFT;
        CurrT += DeltaT;
        // DEBUGMSG(1, (TEXT("[WAVEDEV     ]PrevSamp0=0x%x, CurrSamp0=0x%x, CurrT=0x%x, OutSamp0=0x%x\r\n"), PrevSamp0,CurrSamp0,CurrT,OutSamp0));

        if (pBuffer < pBufferLast)
        {
            OutSamp0 += *(HWSAMPLE *)pBuffer;
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
            {
                OutSamp0=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
            {
                OutSamp0=AUDIO_SAMPLE_MIN;
            }
#endif
        }
        *(HWSAMPLE *)pBuffer = (HWSAMPLE)OutSamp0;

        pBuffer += sizeof(HWSAMPLE);
    }

    Exit:
    m_dwByteCount += (pCurrData - m_lpCurrData);
    m_lpCurrData = pCurrData;
    m_CurrT = CurrT;
    m_PrevSamp[0] = PrevSamp0;
    m_CurrSamp[0] = CurrSamp0;
    return pBuffer;
}

PBYTE OutputStreamContextS16::Render2(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
    LONG CurrT = m_CurrT;
    LONG DeltaT = m_DeltaT;
    LONG CurrSamp0 = m_CurrSamp[0];
    LONG PrevSamp0 = m_PrevSamp[0];
    PBYTE pCurrData = m_lpCurrData;
    PBYTE pCurrDataEnd = m_lpCurrDataEnd;
    LONG fxpGain = m_fxpGain;
    LONG OutSamp0;

    while (pBuffer < pBufferEnd)
    {
#ifndef SAMPLERATE_COMPENSATION
        while (CurrT >= 0x100)
#else
	 	while (CurrT >= CONVERSION_FACTOR_SIZE)
#endif
        {
            if (pCurrData>=pCurrDataEnd)
            {
                goto Exit;
            }

#ifndef SAMPLERATE_COMPENSATION
            CurrT -= 0x100;
#else
            CurrT -= CONVERSION_FACTOR_SIZE;
#endif

            PrevSamp0 = CurrSamp0;

            PPCM_SAMPLE pSampleSrc = (PPCM_SAMPLE)pCurrData;
            CurrSamp0 =  (LONG)pSampleSrc->s16.sample_left;
            CurrSamp0 += (LONG)pSampleSrc->s16.sample_right;
            CurrSamp0 = CurrSamp0>>1;
            pCurrData+=4;
        }

#ifndef SAMPLERATE_COMPENSATION		
        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> 8);
#else
        OutSamp0 = PrevSamp0 + (((CurrSamp0 - PrevSamp0) * CurrT) >> CONVERSION_FACTOR_BIT);
#endif
        OutSamp0 = (OutSamp0 * fxpGain) >> VOLSHIFT;
        CurrT += DeltaT;
        // DEBUGMSG(1, (TEXT("[WAVEDEV     ]PrevSamp0=0x%x, CurrSamp0=0x%x, CurrT=0x%x, OutSamp0=0x%x\r\n"), PrevSamp0,CurrSamp0,CurrT,OutSamp0));

        if (pBuffer < pBufferLast)
        {
            OutSamp0 += *(HWSAMPLE *)pBuffer;
#if USE_MIX_SATURATE
            // Handle saturation
            if (OutSamp0>AUDIO_SAMPLE_MAX)
            {
                OutSamp0=AUDIO_SAMPLE_MAX;
            }
            else if (OutSamp0<AUDIO_SAMPLE_MIN)
            {
                OutSamp0=AUDIO_SAMPLE_MIN;
            }
#endif
        }
        *(HWSAMPLE *)pBuffer = (HWSAMPLE)OutSamp0;

        pBuffer += sizeof(HWSAMPLE);

    }

    Exit:
    m_dwByteCount += (pCurrData - m_lpCurrData);
    m_lpCurrData = pCurrData;
    m_CurrT = CurrT;
    m_PrevSamp[0] = PrevSamp0;
    m_CurrSamp[0] = CurrSamp0;
    return pBuffer;
}
#endif

#if defined(_MULTIL_DAO_INCLUDE_)
PBYTE OutputStreamContextNonPCM::Render2(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
	LONG CurrT = m_CurrT;
	LONG DeltaT = m_DeltaT;
	LONG CurrSamp0[MAXDADONUM];
	LONG CurrSamp1[MAXDADONUM];
	LONG PrevSamp0[MAXDADONUM];
	LONG PrevSamp1[MAXDADONUM];
	PBYTE pCurrData8 = m_lpCurrData;
	PBYTE pCurrDataEnd8 = m_lpCurrDataEnd;
	HWSAMPLE *pCurrData16 = (HWSAMPLE *)m_lpCurrData;
	HWSAMPLE *pCurrDataEnd16 = (HWSAMPLE *)m_lpCurrDataEnd;
	LONG fxpGain = m_fxpGain;
	LONG OutSamp0[MAXDADONUM];
	LONG OutSamp1[MAXDADONUM];
	int DataOffset = m_WaveFormat.Format.nChannels;
	
	if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_LEFT)
		DataOffset--;
	if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_RIGHT)
		DataOffset--;
	if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_CENTER)
		DataOffset--;
	if(m_WaveFormat.dwChannelMask & SPEAKER_LOW_FREQUENCY)
		DataOffset--;
	if(m_WaveFormat.dwChannelMask & SPEAKER_BACK_LEFT)
		DataOffset--;
	if(m_WaveFormat.dwChannelMask & SPEAKER_BACK_RIGHT)
		DataOffset--;
	if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_LEFT_OF_CENTER)
		DataOffset--;
	if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_RIGHT_OF_CENTER)
		DataOffset--;
	
	CurrSamp0[0] = m_CurrSamp[0];
	CurrSamp1[0] = m_CurrSamp[1];
	CurrSamp0[1] = m_CurrSamp[2];
	CurrSamp1[1] = m_CurrSamp[3];
	CurrSamp0[2] = m_CurrSamp[4];
	CurrSamp1[2] = m_CurrSamp[5];
	CurrSamp0[3] = m_CurrSamp[6];
	CurrSamp1[3] = m_CurrSamp[7];

	PrevSamp0[0] = m_PrevSamp[0];
	PrevSamp1[0] = m_PrevSamp[1];
	PrevSamp0[1] = m_PrevSamp[2];
	PrevSamp1[1] = m_PrevSamp[3];
	PrevSamp0[2] = m_PrevSamp[4];
	PrevSamp1[2] = m_PrevSamp[5];
	PrevSamp0[3] = m_PrevSamp[6];
	PrevSamp1[3] = m_PrevSamp[7];

	if(m_WaveFormat.Format.wBitsPerSample==16)
	{
		while (pBuffer < pBufferEnd)
		{
#ifndef SAMPLERATE_COMPENSATION
			while (CurrT >= 0x100)
#else
		 	while (CurrT >= CONVERSION_FACTOR_SIZE)
#endif
			{
				if (pCurrData16>=pCurrDataEnd16)
				{
					goto Exit;
				}

#ifndef SAMPLERATE_COMPENSATION
				CurrT -= 0x100;
#else
				CurrT -= CONVERSION_FACTOR_SIZE;
#endif
				PrevSamp0[0] = CurrSamp0[0];
				PrevSamp1[0] = CurrSamp1[0];
				PrevSamp0[1] = CurrSamp0[1];
				PrevSamp1[1] = CurrSamp1[1];
				PrevSamp0[2] = CurrSamp0[2];
				PrevSamp1[2] = CurrSamp1[2];
				PrevSamp0[3] = CurrSamp0[3];
				PrevSamp1[3] = CurrSamp1[3];

				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_LEFT)
				{
					CurrSamp0[0] = *pCurrData16;
					pCurrData16++;
				}
				else CurrSamp0[0] = 0;

				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_RIGHT)
				{
					CurrSamp1[0] = *pCurrData16;
					pCurrData16++;
				}
				else CurrSamp1[0] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_CENTER)
				{
					CurrSamp0[1] = *pCurrData16;
					pCurrData16++;
				}
				else CurrSamp0[1] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_LOW_FREQUENCY)
				{
					CurrSamp1[1] = *pCurrData16;
					pCurrData16++;
				}
				else CurrSamp1[1] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_BACK_LEFT)
				{
					CurrSamp0[2] = *pCurrData16;
					pCurrData16++;
				}else CurrSamp0[2] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_BACK_RIGHT)
				{
					CurrSamp1[2] = *pCurrData16;
					pCurrData16++;
				}else CurrSamp1[2] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_LEFT_OF_CENTER)
				{
					CurrSamp0[3] = *pCurrData16;
					pCurrData16++;
				}else CurrSamp0[3] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_RIGHT_OF_CENTER)
				{
					CurrSamp1[3] = *pCurrData16;
					pCurrData16++;
				}else CurrSamp1[3] = 0;

				pCurrData16 += DataOffset;
			}

#ifndef SAMPLERATE_COMPENSATION 	
			OutSamp0[0] = PrevSamp0[0] + (((CurrSamp0[0] - PrevSamp0[0]) * CurrT) >> 8);
			OutSamp1[0] = PrevSamp1[0] + (((CurrSamp1[0] - PrevSamp1[0]) * CurrT) >> 8);
			OutSamp0[1] = PrevSamp0[1] + (((CurrSamp0[1] - PrevSamp0[1]) * CurrT) >> 8);
			OutSamp1[1] = PrevSamp1[1] + (((CurrSamp1[1] - PrevSamp1[1]) * CurrT) >> 8);
			OutSamp0[2] = PrevSamp0[2] + (((CurrSamp0[2] - PrevSamp0[2]) * CurrT) >> 8);
			OutSamp1[2] = PrevSamp1[2] + (((CurrSamp1[2] - PrevSamp1[2]) * CurrT) >> 8);
			OutSamp0[3] = PrevSamp0[3] + (((CurrSamp0[3] - PrevSamp0[3]) * CurrT) >> 8);
			OutSamp1[3] = PrevSamp1[3] + (((CurrSamp1[3] - PrevSamp1[3]) * CurrT) >> 8);
#else
			OutSamp0[0] = PrevSamp0[0] + (((CurrSamp0[0] - PrevSamp0[0]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp1[0] = PrevSamp1[0] + (((CurrSamp1[0] - PrevSamp1[0]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp0[1] = PrevSamp0[1] + (((CurrSamp0[1] - PrevSamp0[1]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp1[1] = PrevSamp1[1] + (((CurrSamp1[1] - PrevSamp1[1]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp0[2] = PrevSamp0[2] + (((CurrSamp0[2] - PrevSamp0[2]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp1[2] = PrevSamp1[2] + (((CurrSamp1[2] - PrevSamp1[2]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp0[3] = PrevSamp0[3] + (((CurrSamp0[3] - PrevSamp0[3]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp1[3] = PrevSamp1[3] + (((CurrSamp1[3] - PrevSamp1[3]) * CurrT) >> CONVERSION_FACTOR_BIT);
#endif
			OutSamp0[0] = (OutSamp0[0] * fxpGain) >> VOLSHIFT;
			OutSamp1[0] = (OutSamp1[0] * fxpGain) >> VOLSHIFT;
			OutSamp0[1] = (OutSamp0[1] * fxpGain) >> VOLSHIFT;
			OutSamp1[1] = (OutSamp1[1] * fxpGain) >> VOLSHIFT;
			OutSamp0[2] = (OutSamp0[2] * fxpGain) >> VOLSHIFT;
			OutSamp1[2] = (OutSamp1[2] * fxpGain) >> VOLSHIFT;
			OutSamp0[3] = (OutSamp0[3] * fxpGain) >> VOLSHIFT;
			OutSamp1[3] = (OutSamp1[3] * fxpGain) >> VOLSHIFT;
			
			CurrT += DeltaT;
			// DEBUGMSG(1, (TEXT("[WAVEDEV     ]PrevSamp0=0x%x, CurrSamp0=0x%x, CurrT=0x%x, OutSamp0=0x%x\r\n"), PrevSamp0,CurrSamp0,CurrT,OutSamp0));

			if ((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[0])
			{
				OutSamp0[0] += ((HWSAMPLE *)pBuffer)[0];
#if USE_MIX_SATURATE
				// Handle saturation
				if (OutSamp0[0]>AUDIO_SAMPLE_MAX)
					OutSamp0[0]=AUDIO_SAMPLE_MAX;
				else if (OutSamp0[0]<AUDIO_SAMPLE_MIN)
					OutSamp0[0]=AUDIO_SAMPLE_MIN;
#endif
			}
			if ((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[1])
			{				
				OutSamp1[0] += ((HWSAMPLE *)pBuffer)[1];
#if USE_MIX_SATURATE
				if (OutSamp1[0]>AUDIO_SAMPLE_MAX)
					OutSamp1[0]=AUDIO_SAMPLE_MAX;
				else if(OutSamp1[0]<AUDIO_SAMPLE_MIN)
					OutSamp1[0]=AUDIO_SAMPLE_MIN;
#endif
			}
			if ((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[2])
			{				
				OutSamp0[1] += ((HWSAMPLE *)pBuffer)[2];
#if USE_MIX_SATURATE				
				if (OutSamp0[1]>AUDIO_SAMPLE_MAX)
					OutSamp0[1]=AUDIO_SAMPLE_MAX;
				else if (OutSamp0[1]<AUDIO_SAMPLE_MIN)
					OutSamp0[1]=AUDIO_SAMPLE_MIN;
#endif
			}
			if ((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[3])
			{				
				OutSamp1[1] += ((HWSAMPLE *)pBuffer)[3];
#if USE_MIX_SATURATE				
				if (OutSamp1[1]>AUDIO_SAMPLE_MAX)
					OutSamp1[1]=AUDIO_SAMPLE_MAX;
				else if(OutSamp1[1]<AUDIO_SAMPLE_MIN)
					OutSamp1[1]=AUDIO_SAMPLE_MIN;
#endif
			}
			if ((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[4])
			{				
				OutSamp0[2] += ((HWSAMPLE *)pBuffer)[4];
#if USE_MIX_SATURATE
				if (OutSamp0[2]>AUDIO_SAMPLE_MAX)
					OutSamp0[2]=AUDIO_SAMPLE_MAX;
				else if (OutSamp0[2]<AUDIO_SAMPLE_MIN)
					OutSamp0[2]=AUDIO_SAMPLE_MIN;
#endif
			}
			if ((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[5])
			{				
				OutSamp1[2] += ((HWSAMPLE *)pBuffer)[5];
#if USE_MIX_SATURATE
				if (OutSamp1[2]>AUDIO_SAMPLE_MAX)
					OutSamp1[2]=AUDIO_SAMPLE_MAX;
				else if(OutSamp1[2]<AUDIO_SAMPLE_MIN)
					OutSamp1[2]=AUDIO_SAMPLE_MIN;
#endif	
			}
			if ((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[6])
			{				
				OutSamp0[3] += ((HWSAMPLE *)pBuffer)[6];
#if USE_MIX_SATURATE				
				if (OutSamp0[3]>AUDIO_SAMPLE_MAX)
					OutSamp0[3]=AUDIO_SAMPLE_MAX;
				else if (OutSamp0[3]<AUDIO_SAMPLE_MIN)
					OutSamp0[3]=AUDIO_SAMPLE_MIN;
#endif
			}
			if ((pBuffer + 8*sizeof(HWSAMPLE)) <= m_DMABufStatus[7])
			{			
				
				OutSamp1[3] += ((HWSAMPLE *)pBuffer)[7];
				#if USE_MIX_SATURATE				
				if (OutSamp1[3]>AUDIO_SAMPLE_MAX)
					OutSamp1[3]=AUDIO_SAMPLE_MAX;
				else if(OutSamp1[3]<AUDIO_SAMPLE_MIN)
					OutSamp1[3]=AUDIO_SAMPLE_MIN;
				#endif
			}
			
			((HWSAMPLE *)pBuffer)[0] = (HWSAMPLE)OutSamp0[0];
			((HWSAMPLE *)pBuffer)[1] = (HWSAMPLE)OutSamp1[0];
			((HWSAMPLE *)pBuffer)[2] = (HWSAMPLE)OutSamp0[1];
			((HWSAMPLE *)pBuffer)[3] = (HWSAMPLE)OutSamp1[1];
			((HWSAMPLE *)pBuffer)[4] = (HWSAMPLE)OutSamp0[2];
			((HWSAMPLE *)pBuffer)[5] = (HWSAMPLE)OutSamp1[2];
			((HWSAMPLE *)pBuffer)[6] = (HWSAMPLE)OutSamp0[3];
			((HWSAMPLE *)pBuffer)[7] = (HWSAMPLE)OutSamp1[3];			
			pBuffer += 8*sizeof(HWSAMPLE);
		}
	}
	else//m_WaveFormat.wBitsPerSample==8
	{
		while (pBuffer < pBufferEnd)
		{
#ifndef SAMPLERATE_COMPENSATION
			while (CurrT >= 0x100)
#else
		 	while (CurrT >= CONVERSION_FACTOR_SIZE)
#endif
			{
				if (pCurrData8>=pCurrDataEnd8)
				{
					goto Exit;
				}

#ifndef SAMPLERATE_COMPENSATION
				CurrT -= 0x100;
#else
				CurrT -= CONVERSION_FACTOR_SIZE;
#endif
				PrevSamp0[0] = CurrSamp0[0];
				PrevSamp1[0] = CurrSamp1[0];
				PrevSamp0[1] = CurrSamp0[1];
				PrevSamp1[1] = CurrSamp1[1];
				PrevSamp0[2] = CurrSamp0[2];
				PrevSamp1[2] = CurrSamp1[2];
				PrevSamp0[3] = CurrSamp0[3];
				PrevSamp1[3] = CurrSamp1[3];

				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_LEFT)
				{
					CurrSamp0[0] = (*pCurrData8 - 128) << 8;
					pCurrData8++;
				}
				else CurrSamp0[0] = 0;

				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_RIGHT)
				{
					CurrSamp1[0] = (*pCurrData8 - 128) << 8;
					pCurrData8++;
				}
				else CurrSamp1[0] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_CENTER)
				{
					CurrSamp0[1] = (*pCurrData8 - 128) << 8;
					pCurrData8++;
				}
				else CurrSamp0[1] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_LOW_FREQUENCY)
				{
					CurrSamp1[1] = (*pCurrData8 - 128) << 8;
					pCurrData8++;
				}
				else CurrSamp1[1] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_BACK_LEFT)
				{
					CurrSamp0[2] = (*pCurrData8 - 128) << 8;
					pCurrData8++;
				}else CurrSamp0[2] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_BACK_RIGHT)
				{
					CurrSamp1[2] = (*pCurrData8 - 128) << 8;
					pCurrData8++;
				}else CurrSamp1[2] = 0;
				
				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_LEFT_OF_CENTER)
				{
					CurrSamp0[3] = (*pCurrData8 - 128) << 8;
					pCurrData8++;
				}else CurrSamp0[3] = 0;
				if(m_WaveFormat.dwChannelMask & SPEAKER_FRONT_RIGHT_OF_CENTER)
				{
					CurrSamp1[3] = (*pCurrData8 - 128) << 8;
					pCurrData8++;
				}else CurrSamp1[3] = 0;
			}

#ifndef SAMPLERATE_COMPENSATION 	
			OutSamp0[0] = PrevSamp0[0] + (((CurrSamp0[0] - PrevSamp0[0]) * CurrT) >> 8);
			OutSamp1[0] = PrevSamp1[0] + (((CurrSamp1[0] - PrevSamp1[0]) * CurrT) >> 8);
			OutSamp0[1] = PrevSamp0[1] + (((CurrSamp0[1] - PrevSamp0[1]) * CurrT) >> 8);
			OutSamp1[1] = PrevSamp1[1] + (((CurrSamp1[1] - PrevSamp1[1]) * CurrT) >> 8);
			OutSamp0[2] = PrevSamp0[2] + (((CurrSamp0[2] - PrevSamp0[2]) * CurrT) >> 8);
			OutSamp1[2] = PrevSamp1[2] + (((CurrSamp1[2] - PrevSamp1[2]) * CurrT) >> 8);
			OutSamp0[3] = PrevSamp0[3] + (((CurrSamp0[3] - PrevSamp0[3]) * CurrT) >> 8);
			OutSamp1[3] = PrevSamp1[3] + (((CurrSamp1[3] - PrevSamp1[3]) * CurrT) >> 8);
#else
			OutSamp0[0] = PrevSamp0[0] + (((CurrSamp0[0] - PrevSamp0[0]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp1[0] = PrevSamp1[0] + (((CurrSamp1[0] - PrevSamp1[0]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp0[1] = PrevSamp0[1] + (((CurrSamp0[1] - PrevSamp0[1]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp1[1] = PrevSamp1[1] + (((CurrSamp1[1] - PrevSamp1[1]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp0[2] = PrevSamp0[2] + (((CurrSamp0[2] - PrevSamp0[2]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp1[2] = PrevSamp1[2] + (((CurrSamp1[2] - PrevSamp1[2]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp0[3] = PrevSamp0[3] + (((CurrSamp0[3] - PrevSamp0[3]) * CurrT) >> CONVERSION_FACTOR_BIT);
			OutSamp1[3] = PrevSamp1[3] + (((CurrSamp1[3] - PrevSamp1[3]) * CurrT) >> CONVERSION_FACTOR_BIT);
#endif
			OutSamp0[0] = (OutSamp0[0] * fxpGain) >> VOLSHIFT;
			OutSamp1[0] = (OutSamp1[0] * fxpGain) >> VOLSHIFT;
			OutSamp0[1] = (OutSamp0[1] * fxpGain) >> VOLSHIFT;
			OutSamp1[1] = (OutSamp1[1] * fxpGain) >> VOLSHIFT;
			OutSamp0[2] = (OutSamp0[2] * fxpGain) >> VOLSHIFT;
			OutSamp1[2] = (OutSamp1[2] * fxpGain) >> VOLSHIFT;
			OutSamp0[3] = (OutSamp0[3] * fxpGain) >> VOLSHIFT;
			OutSamp1[3] = (OutSamp1[3] * fxpGain) >> VOLSHIFT;

			if (pBuffer < m_DMABufStatus[0])
			{
				OutSamp0[0] += ((HWSAMPLE *)pBuffer)[0];
#if USE_MIX_SATURATE
				// Handle saturation
				if (OutSamp0[0]>AUDIO_SAMPLE_MAX)
					OutSamp0[0]=AUDIO_SAMPLE_MAX;
				else if (OutSamp0[0]<AUDIO_SAMPLE_MIN)
					OutSamp0[0]=AUDIO_SAMPLE_MIN;
#endif
			}
			if (pBuffer < m_DMABufStatus[1])
			{				
				OutSamp1[0] += ((HWSAMPLE *)pBuffer)[1];
#if USE_MIX_SATURATE
				if (OutSamp1[0]>AUDIO_SAMPLE_MAX)
					OutSamp1[0]=AUDIO_SAMPLE_MAX;
				else if(OutSamp1[0]<AUDIO_SAMPLE_MIN)
					OutSamp1[0]=AUDIO_SAMPLE_MIN;
#endif
			}
			if (pBuffer < m_DMABufStatus[2])
			{				
				OutSamp0[1] += ((HWSAMPLE *)pBuffer)[2];
#if USE_MIX_SATURATE				
				if (OutSamp0[1]>AUDIO_SAMPLE_MAX)
					OutSamp0[1]=AUDIO_SAMPLE_MAX;
				else if (OutSamp0[1]<AUDIO_SAMPLE_MIN)
					OutSamp0[1]=AUDIO_SAMPLE_MIN;
#endif
			}
			if (pBuffer < m_DMABufStatus[3])
			{				
				OutSamp1[1] += ((HWSAMPLE *)pBuffer)[3];
#if USE_MIX_SATURATE				
				if (OutSamp1[1]>AUDIO_SAMPLE_MAX)
					OutSamp1[1]=AUDIO_SAMPLE_MAX;
				else if(OutSamp1[1]<AUDIO_SAMPLE_MIN)
					OutSamp1[1]=AUDIO_SAMPLE_MIN;
#endif
			}
			if (pBuffer < m_DMABufStatus[4])
			{				
				OutSamp0[2] += ((HWSAMPLE *)pBuffer)[4];
#if USE_MIX_SATURATE
				if (OutSamp0[2]>AUDIO_SAMPLE_MAX)
					OutSamp0[2]=AUDIO_SAMPLE_MAX;
				else if (OutSamp0[2]<AUDIO_SAMPLE_MIN)
					OutSamp0[2]=AUDIO_SAMPLE_MIN;
#endif
			}
			if (pBuffer < m_DMABufStatus[5])
			{				
				OutSamp1[2] += ((HWSAMPLE *)pBuffer)[5];
#if USE_MIX_SATURATE
				if (OutSamp1[2]>AUDIO_SAMPLE_MAX)
					OutSamp1[2]=AUDIO_SAMPLE_MAX;
				else if(OutSamp1[2]<AUDIO_SAMPLE_MIN)
					OutSamp1[2]=AUDIO_SAMPLE_MIN;
#endif	
			}
			if (pBuffer < m_DMABufStatus[6])
			{				
				OutSamp0[3] += ((HWSAMPLE *)pBuffer)[6];
#if USE_MIX_SATURATE				
				if (OutSamp0[3]>AUDIO_SAMPLE_MAX)
					OutSamp0[3]=AUDIO_SAMPLE_MAX;
				else if (OutSamp0[3]<AUDIO_SAMPLE_MIN)
					OutSamp0[3]=AUDIO_SAMPLE_MIN;
#endif
			}
			if (pBuffer < m_DMABufStatus[7])
			{			
				
				OutSamp1[3] += ((HWSAMPLE *)pBuffer)[7];
	#if USE_MIX_SATURATE				
				if (OutSamp1[3]>AUDIO_SAMPLE_MAX)
					OutSamp1[3]=AUDIO_SAMPLE_MAX;
				else if(OutSamp1[3]<AUDIO_SAMPLE_MIN)
					OutSamp1[3]=AUDIO_SAMPLE_MIN;
	#endif
			}

			((HWSAMPLE *)pBuffer)[0] = (HWSAMPLE)OutSamp0[0];
			((HWSAMPLE *)pBuffer)[1] = (HWSAMPLE)OutSamp1[0];
			((HWSAMPLE *)pBuffer)[2] = (HWSAMPLE)OutSamp0[1];
			((HWSAMPLE *)pBuffer)[3] = (HWSAMPLE)OutSamp1[1];
			((HWSAMPLE *)pBuffer)[4] = (HWSAMPLE)OutSamp0[2];
			((HWSAMPLE *)pBuffer)[5] = (HWSAMPLE)OutSamp1[2];
			((HWSAMPLE *)pBuffer)[6] = (HWSAMPLE)OutSamp0[3];
			((HWSAMPLE *)pBuffer)[7] = (HWSAMPLE)OutSamp1[3];	
			pBuffer += 8*sizeof(HWSAMPLE);
		}
	}
	
	Exit:
	if(m_WaveFormat.Format.wBitsPerSample==16)
	{
		m_dwByteCount += ((PBYTE)pCurrData16 - m_lpCurrData);
		m_lpCurrData = (PBYTE)pCurrData16;
	}
	else
	{
		m_dwByteCount += (pCurrData8 - m_lpCurrData);
		m_lpCurrData = pCurrData8;
	}

	m_CurrT = CurrT;

	m_CurrSamp[0] 	= CurrSamp0[0];
 	m_CurrSamp[1] 	= CurrSamp1[0];
	m_CurrSamp[2]	= CurrSamp0[1];
	m_CurrSamp[3]	= CurrSamp1[1];
	m_CurrSamp[4]	= CurrSamp0[2];
	m_CurrSamp[5]	= CurrSamp1[2];
	m_CurrSamp[6]	= CurrSamp0[3];
	m_CurrSamp[7]	= CurrSamp1[3];

	m_PrevSamp[0] 	= PrevSamp0[0];
	m_PrevSamp[1] 	= PrevSamp1[0];
	m_PrevSamp[2] 	= PrevSamp0[1];
	m_PrevSamp[3] 	= PrevSamp1[1];
	m_PrevSamp[4] 	= PrevSamp0[2];
	m_PrevSamp[5] 	= PrevSamp1[2];
	m_PrevSamp[6] 	= PrevSamp0[3];
	m_PrevSamp[7] 	= PrevSamp1[3];

#if defined(_MULTIL_DAO_INCLUDE_)
	if(pBuffer > m_DMABufStatus[0])
		m_DMABufStatus[0] = pBuffer;
	if(pBuffer > m_DMABufStatus[1])
		m_DMABufStatus[1] = pBuffer+sizeof(HWSAMPLE);
	if(pBuffer > m_DMABufStatus[2])
		m_DMABufStatus[2] = pBuffer+sizeof(HWSAMPLE)*2;
	if(pBuffer > m_DMABufStatus[3])
		m_DMABufStatus[3] = pBuffer+sizeof(HWSAMPLE)*3;
	if(pBuffer > m_DMABufStatus[4])	
		m_DMABufStatus[4] = pBuffer+sizeof(HWSAMPLE)*4;
	if(pBuffer > m_DMABufStatus[5])	
		m_DMABufStatus[5] = pBuffer+sizeof(HWSAMPLE)*5;
	if(pBuffer > m_DMABufStatus[6])	
		m_DMABufStatus[6] = pBuffer+sizeof(HWSAMPLE)*6;
	if(pBuffer > m_DMABufStatus[7])	
		m_DMABufStatus[7] = pBuffer+sizeof(HWSAMPLE)*7;
#endif
	return pBuffer;
}
#endif

#if defined(_MULTIL_DAO_INCLUDE_)	
void ArrangeBuffer(PBYTE pStart, PBYTE pEnd, ULONG NumBuf)
{
	int iChCnt = 0;
	DWORD BufClrStauts;
	//Check DMA buffer status
	while(iChCnt < 2*MAXDADONUM)
	{
		BufClrStauts = 0x01<<(iChCnt + 2*MAXDADONUM*NumBuf);
		if((m_DMABufStatus[iChCnt] == NULL || m_DMABufStatus[iChCnt] == pStart))
		{
			if(m_DMABufClrStatus & BufClrStauts) 
				m_DMABufStatus[iChCnt] = pEnd;
			else 
				m_DMABufClrStatus |= BufClrStauts;
		}
		else 
			m_DMABufClrStatus &= ~BufClrStauts;

		++iChCnt;
	}
	while(pStart < pEnd)
	{
		if(pStart >= m_DMABufStatus[0])
			((HWSAMPLE *)pStart)[0] = 0;
		
		if(pStart >= m_DMABufStatus[1])
			((HWSAMPLE *)pStart)[1] = 0;
		
		if(pStart >= m_DMABufStatus[2])
			((HWSAMPLE *)pStart)[2] = 0;
		
		if(pStart >= m_DMABufStatus[3])
			((HWSAMPLE *)pStart)[3] = 0;
		
		if(pStart >= m_DMABufStatus[4])
			((HWSAMPLE *)pStart)[4] = 0;
		
		if(pStart >= m_DMABufStatus[5])
			((HWSAMPLE *)pStart)[5] = 0;
		
		if(pStart >= m_DMABufStatus[6])
			((HWSAMPLE *)pStart)[6] = 0;
		
		if(pStart >= m_DMABufStatus[7])
			((HWSAMPLE *)pStart)[7] = 0;				

		pStart += 2*MAXDADONUM*sizeof(HWSAMPLE);
	}

	//Set that all m_DMABufStatus is NULL. 
	memset(m_DMABufStatus, 0, 2*MAXDADONUM*sizeof(PBYTE));
}
#endif

#if defined(_SPDIF_COMMON_)
PBYTE OutputStreamContextEncodedSPDIF::Render2(PBYTE pBuffer, PBYTE pBufferEnd, PBYTE pBufferLast)
{
	DWORD dwSrcBytes = m_lpCurrDataEnd - m_lpCurrData;
	DWORD dwDstBytes = pBufferEnd - pBuffer;
	DWORD dwBytesToCopy = min(dwSrcBytes,dwDstBytes);

	memcpy(pBuffer,m_lpCurrData,dwBytesToCopy);

	m_dwByteCount += dwBytesToCopy;
	m_lpCurrData += dwBytesToCopy;

	pBufferLast = pBuffer+dwBytesToCopy;

	return pBufferLast;
}

BOOL OutputStreamContextEncodedSPDIF::IsExclusive()
{
	return TRUE;
}

// We don't support setting the rate on SPDIF encoded outputs, do we?
DWORD OutputStreamContextEncodedSPDIF::SetRate(DWORD dwMultiplier)
{
#if defined(_SPDIF_COMMON_)
	extern ADMA *pstrADMA_VirtualRegAddr;
	extern ADMASPDIFTX *pstrADMASPDIFTX_VirtualRegAddr;

#if defined(_MULTIL_DAO_INCLUDE_)
	if(m_WaveFormat.Format.wFormatTag == WAVE_FORMAT_DOLBY_AC3_SPDIF)
	{
		tcc_spdif_setclock(pstrADMASPDIFTX_VirtualRegAddr, m_WaveFormat.Format.nSamplesPerSec);
		//printf("\r\n/////Set Rate SPDIF Clock = %d\r\n", m_WaveFormat.Format.nSamplesPerSec);
	}
#else
	if(m_WaveFormat.wFormatTag == WAVE_FORMAT_DOLBY_AC3_SPDIF)
	{
		tcc_spdif_setclock(pstrADMASPDIFTX_VirtualRegAddr, m_WaveFormat.nSamplesPerSec);
		//printf("\r\n/////Set Rate SPDIF Clock = %d\r\n", m_WaveFormat.nSamplesPerSec);
	}
#endif
#endif
	return (dwMultiplier == 0x10000) ? MMSYSERR_NOERROR : MMSYSERR_NOTSUPPORTED ;
}
#endif
