/*!
 ***********************************************************************
 \par Copyright
 \verbatim
  ________  _____           _____   _____           ____  ____   ____		
     /     /       /       /       /       /     /   /    /   \ /			
    /     /___    /       /___    /       /____ /   /    /____/ \___			
   /     /       /       /       /       /     /   /    /           \		
  /     /_____  /_____  /_____  /_____  /     / _ /_  _/_      _____/ 		
   																				
  Copyright (c) 2009 Telechips Inc.
  Korad Bldg, 1000-12 Daechi-dong, Kangnam-Ku, Seoul, Korea					
 \endverbatim
 ***********************************************************************
 */
/*!
 ***********************************************************************
 *
 * \file
 *		TCCxxxx_AEC.h
 * \date
 *		2009/07/20
 * \author
 *		Kris Park(Park@telechips.com) 
 * \brief
 *		xx library config header
 * \version
 *		0.0.1 : 2009/07/20
 *
 ***********************************************************************
 */
#ifndef TCC_AEC_H
#define TCC_AEC_H

#ifdef __cplusplus
extern "C" {
#endif
typedef unsigned __int64  U64;
typedef __int64 S64;

//! Callback Func
typedef struct aec_callback_func_t
{
	//! Callback Func
	void* (*m_pfMalloc			) ( unsigned int );						//!< malloc
	void* (*m_pfNonCacheMalloc	) ( unsigned int );						//!< non-cacheable malloc 
	void  (*m_pfFree			) ( void* );							//!< free
	void  (*m_pfNonCacheFree	) ( void* );							//!< non-cacheable free
	void* (*m_pfMemcpy			) ( void*, const void*, unsigned int );	//!< memcpy
	void* (*m_pfMemset			) ( void*, int, unsigned int );			//!< memset
	void* (*m_pfRealloc			) ( void*, unsigned int );				//!< realloc
	void* (*m_pfMemmove			) ( void*, const void*, unsigned int );	//!< memmove
	void* (*m_pfCalloc			) ( unsigned int , unsigned int );		//!< calloc

	void* (*m_pfPhysicalAlloc	) ( unsigned int );						//!< alloc function of physical memory
	void  (*m_pfPhysicalFree	) ( void*, unsigned int );				//!< free function of physical memory
	void* (*m_pfVirtualAlloc	) ( int*, unsigned int, unsigned int );	//!< alloc function of virtual memory
	void  (*m_pfVirtualFree		) ( int*, unsigned int, unsigned int );	//!< free function of virtual memory
	int m_Reserved1[16-13];

	void*		 (*m_pfFopen ) ( const char *, const char * );						//!< fopen
	unsigned int (*m_pfFread ) ( void*, unsigned int, unsigned int, void* );		//!< fread
	int			 (*m_pfFseek ) ( void*, long, int );								//!< fseek
	long		 (*m_pfFtell ) ( void* );											//!< ftell
	unsigned int (*m_pfFwrite) ( const void*, unsigned int, unsigned int, void* );	//!< fwrite
	int			 (*m_pfFclose) ( void* );											//!< fclose
	int			 (*m_pfUnlink) ( const char* );										//!< _unlink
	unsigned int (*m_pfFeof  ) ( void* );											//!< feof
	unsigned int (*m_pfFflush) ( void* );											//!< fflush

	int			 (*m_pfFseek64) ( void*, S64, int );							//!< fseek
	S64			 (*m_pfFtell64) ( void* );											//!< ftell
	int m_Reserved2[16-11];
} aec_callback_func_t;

#define AEC_PARAM_AEC_OFF			(0x00000001)
#define AEC_PARAM_NR_OFF			(0x00000002)
#define AEC_PARAM_USE_BASEDIVIDE	(0x00000004) //!< This setting will use an inherent divide function

//! AEC control parameters
typedef struct
{
	int				m_iNoiseSuppressdB;			//!< -15
	int				m_iEchoSuppressdB;			//!< -40
	int				m_iEchoSuppressActivedB;	//!< -15
	int				m_iConvergenceCoeff;		//!< Q28(1) is default
	int				m_iDCfilterSelect;			//!< 300Hz is default, other selective options are 0, 100, 200
	int				m_iInputGainScale;			//!< Q30 scaling 
	unsigned int 	m_uiControlOptions;			//!< 
	int 			m_iReserved[16-6];
} aec_params_t;

//! AEC Handle
typedef struct aec_handle_t
{
	void 				*m_pvAecHandle;			//!< Handle of acoustic echo canceller
	void 				*m_pvNoiseSuppHandle;	//!< Handle of noise suppressor
	aec_callback_func_t	 m_tCallbackFunc;		//!< callback function structure
} aec_handle_t;

/*!
 ***********************************************************************
 * \brief
 *		TC_AEC_Init			: initializes aec
 * \param
 *		[in]psMemallocInfo	: aec structure handle
 * \param
 *		[in]sAecParams		: aec paramter structure
 * \param
 *		[in]sAecCallbackFunc: callback function structure
 * \return
 *		If successful, TC_AEC_Init returns 0. Otherwise, it returns a nagative value.
 ***********************************************************************
 */
int TC_AEC_Init(aec_handle_t **ppsAecHandle, aec_params_t sAecParams, aec_callback_func_t sAecCallbackFunc);

/*!
 ***********************************************************************
 * \brief
 *		TC_AEC_Process		: apply aec to pNes using pFes, then output to output_frame
 * \param
 *		[in]psAecHandle		: aec structure handle
 * \param
 *		[in]psNesPcm		: near-end side pcm buffer(microphone input)
  * \param
 *		[in]psFesPcm		: far-end side pcm buffer(speaker output)
 * \param
 *		[in]psOutputPcm		: aec applied pcm output(echo free speech)
 ***********************************************************************
 */
void TC_AEC_Process(aec_handle_t *psAecHandle, short *psNesPcm, short *psFesPcm, short *psOutputPcm);

/*!
 ***********************************************************************
 * \brief
 *		TC_AEC_Finish		: close aec structure handle
 * \param
 *		[in]psAecHandle		: aec structure handle
 ***********************************************************************
 */
void TC_AEC_Finish(aec_handle_t *psAecHandle);

#ifdef __cplusplus
}
#endif 
#endif // #ifndef TCC_AEC_H
