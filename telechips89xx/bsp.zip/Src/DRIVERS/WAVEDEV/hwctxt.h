//
// Copyright (c) Telechips Corporation.  All rights reserved.
//
//

//
#pragma once

#include "MemQueue.h"

#define OUTPUTDMANO 0
#define INPUTDMANO  1
#define SPDIFDMANO	2

#define INDMA		1
#define OUTDMA		0
#define SPDIFOUTDMA	2

#define OUTCHANNELS (2)
#define BITSPERSAMPLE (16)
//#define SAMPLERATE  (44100)
//#define SAMPLERATE  (8000)

// Inverse sample rate, in .32 fixed format, with 1 added at bottom to ensure round up.
//#define INVSAMPLERATE ((UINT32)(((1i64<<32)/SAMPLERATE)+1))

typedef INT16 HWSAMPLE;
typedef HWSAMPLE *PHWSAMPLE;

// Set USE_MIX_SATURATE to 1 if you want the mixing code to guard against saturation
// This costs a couple of instructions in the inner loop
#define USE_MIX_SATURATE (1)
// The code will use the follwing values as saturation points
#define AUDIO_SAMPLE_MAX    (32767)
#define AUDIO_SAMPLE_MIN    (-32768)

#define MAXDADONUM	(4)
#define MAXDADINUM	(4)

//----- Used to track DMA controllers status -----
#define DMA_CLEAR			0x00000000
#define DMA_DONEA			0x00000008
#define DMA_STRTA			0x00000010
#define DMA_DONEB			0x00000020
#define DMA_STRTB			0x00000040
#define DMA_BIU				0x00000080					// Determines which buffer is in use: (A=0, B=1)

//----- Used for scheduling DMA transfers -----
#define  OUT_BUFFER_A		0							
#define  OUT_BUFFER_B		1
#define	 IN_BUFFER_A		0
#define  IN_BUFFER_B		1

enum{
	TRANSFER_TYPE_PCM = 0,
	TRANSFER_TYPE_SPDIF
};

class HardwareContext
{
public:
    static BOOL CreateHWContext(DWORD Index);
    HardwareContext();
    ~HardwareContext();

    void Lock()   {EnterCriticalSection(&m_Lock);}
    void Unlock() {LeaveCriticalSection(&m_Lock);}

    DWORD GetNumInputDevices()  {return 1;}
    DWORD GetNumOutputDevices() {return 1;}
    DWORD GetNumMixerDevices()  {return 1;}

    DeviceContext *GetInputDeviceContext(UINT DeviceId)
    {
        return &m_InputDeviceContext;
    }

    DeviceContext *GetOutputDeviceContext(UINT DeviceId)
    {
        return &m_OutputDeviceContext;
    }

    BOOL Init(DWORD Index);										
    BOOL Deinit();

    void PowerUp();
    void PowerDown();

    BOOL StartInputDMA();
    BOOL StartOutputDMA();
	BOOL StartOutputDMAByTransferType(DWORD TransferType);

    void StopInputDMA();
    void StopOutputDMA();
	void StopOutputDMAByTransferType(DWORD TransferType);
    void InterruptThread();
	BOOL g_AECSetMode(BOOL bMode);
	BOOL SetInputType(DWORD dwInputType);

    DWORD       GetOutputGain (void);
    MMRESULT    SetOutputGain (DWORD dwVolume);
    DWORD       GetInputGain (void);
    MMRESULT    SetInputGain (DWORD dwVolume);

    BOOL        GetOutputMute (void);
    MMRESULT    SetOutputMute (BOOL fMute);
    BOOL        GetInputMute (void);
    MMRESULT    SetInputMute (BOOL fMute);
#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY) 	
	unsigned int m_TxSpdifSrcAddrForI2SSync;
#endif

protected:
    DWORD m_dwOutputGain;
    DWORD m_dwInputGain;
    BOOL  m_fInputMute;
    BOOL  m_fOutputMute;


    DWORD m_MicrophoneRouting;
    DWORD m_SpeakerRouting;
    DWORD m_InternalRouting;
    DWORD m_MasterOutputGain;

    BOOL InitInterruptThread();

    BOOL InitInputDMA();
    BOOL InitOutputDMA(DWORD TransferType);
    BOOL Codec_channel(DWORD status);
    BOOL InitCodec();
    
    BOOL MapRegisters();
    BOOL UnmapRegisters();
    BOOL MapDMABuffers();
    BOOL UnmapDMABuffers();

    ULONG TransferInputBuffer(ULONG NumBuf);
    ULONG TransferOutputBuffer(ULONG NumBuf, DWORD TransferType);
    ULONG TransferInputBuffers(DWORD dwDCSR);
    ULONG TransferOutputBuffers(DWORD dwDCSR, DWORD TransferType);


    DWORD GetInterruptThreadPriority();

    VOID ProcessInput(VOID);

    DWORD m_DriverIndex;
    CRITICAL_SECTION m_Lock;

    BOOL m_Initialized;
    BOOL m_InPowerHandler;
    DWORD m_dwSysintrOutput;
    DWORD m_dwSysintrInput;

    InputDeviceContext m_InputDeviceContext;
    OutputDeviceContext m_OutputDeviceContext;

    PBYTE		m_Input_pbDMA_PAGES[2];
    PBYTE		m_Output_pbDMA_PAGES[2];
	PBYTE		m_Output_pbDMA_PAGES_ForSPDIF[2];

	PBYTE pVirtDMABufferAddr;
    int m_InputDMARunning;
    int m_OutputDMARunning;
    ULONG m_OutBytes[2][2];//m_OutBytes[TransferType][OUTPUT_BFFFER_A or B]
    ULONG m_InBytes[2];

    WORD  m_nOutputVolume;					// Current HW Playback Volume 
    WORD  m_nInputVolume;					// Current HW Input (Microphone) Volume 
    HANDLE m_hAudioInterrupt;				// Handle to Audio Interrupt event.
    HANDLE m_hAudioInterruptThread;			// Handle to thread which waits on an audio interrupt event.
	//----------------------- Platform specific members ----------------------------------

	DWORD  m_OutputDMAStatus;					// Output DMA channel's status
	DWORD  m_InputDMAStatus;					// Input DMA channel's status
	DWORD  m_SPDIFOutputDMAStatus;				// SPDIF Output DMA channel's status

	BOOL AudioMute(DWORD channel, BOOL bMute);	
	//------------------------------------------------------------------------------------

	//-------------------------POWER MANAGEMENT-----------------------------------------
	DWORD               m_RegHwDAMR;




};

void CallInterruptThread(HardwareContext *pHWContext);
//------------------------------------------ Externs ----------------------------------------------
extern HardwareContext *g_pHWContext;


