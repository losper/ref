//
// Copyright (c) Telechips Corporation.  All rights reserved.
//
//
#include <bsp.h>

#include <windows.h>
#include <ceddk.h>

#include "wavemain.h"
#include "hwctxt.h"
#include "args.h"
#include "tcc_gpio.h"
#include "tcc_wave.h"
//#include "../../LIB/SOC/GPIO/tca_gpio.h"

#if defined(_LINE_IN_RECORD_)
unsigned int gInputType = LINE_IN_INPUT;
#else
unsigned int gInputType = MIC_INPUT;
#endif

ADMA *pstrADMA_VirtualRegAddr = NULL;
ADMADAI *pstrADMADAI_VirtualRegAddr = NULL;
GPIO *pstrGPIO_VirtualRegAddr = NULL;
ADMASPDIFTX *pstrADMASPDIFTX_VirtualRegAddr = NULL;

#define DMA_CH_MIC 2
#define DMA_CH_OUT 1
extern unsigned int tcc_i2c_open(void *hI2C);

//==============================================================================================
// Please check to below for using TCC250
// 1. R129 and R131 should mount on the TCC8300_WINCE_DEMO_V1.1 Baord
// 2. JS3 USB_PWR connect to 2-3 when using the TCC250
//==============================================================================================

HardwareContext *g_pHWContext = NULL;
static TCHAR gszBaseInstance[256] = _T("Drivers\\BuiltIn\\Wavedev");
PHYSICAL_ADDRESS g_PhysDMABufferAddr;
extern BOOL gbFMRMODE;

//#define 
DWORD	SAMPLERATE=44100;
DWORD	AUDIO_DMA_PAGE_SIZE		=(1024)	;				// Size in bytes
DWORD	AUDIO_DMA_IN_PAGE_SIZE	=(1024)	;				// Size in bytes
DWORD	AUDIO_DMA_PAGE_SIZE_SPIDF = (1024);			// Size in bytes

#if defined(_USING_AEC_)
	#include "TCCxxxx_AEC.h"
	aec_handle_t		*pAECHandle;	
	aec_params_t 		 s_aec_params = {0,};
	aec_callback_func_t  s_aec_callback_func = {0, };

	// AEC include
	cCircularQueue *pInQueue;
	cCircularQueue *pOutQueue;
	cCircularQueue *pResultQueue;
	BOOL	g_AECMode=FALSE;

	unsigned int curOutputADMAOffset = 0;
	unsigned int curInputADMAOffset = 0;	
#endif

#if defined(_AUD_DUMP_)
HANDLE hFile_in;
HANDLE hFile_out;
HANDLE hFile_result;
#endif

DWORD _gCurrentDAC = 0;
DWORD _gCurrentGain = 0;
//----------------------------------------------------------------------------------------

#ifdef DEBUG
DBGPARAM dpCurSettings = {
    TEXT("WaveDriver"), {
         TEXT("Test")           //  0   ZONE_TEST
        ,TEXT("Params")         //  1   ZONE_PARAMS     
        ,TEXT("Verbose")        //  2   ZONE_VERBOSE    
        ,TEXT("Interrupt")      //  3   ZONE_INTERRUPT  
        ,TEXT("WODM")           //  4   ZONE_WODM       
        ,TEXT("WIDM")           //  5   ZONE_WIDM       
        ,TEXT("PDD")            //  6   ZONE_PDD        
        ,TEXT("MDD")            //  7   ZONE_MDD        
        ,TEXT("Regs")           //  8   ZONE_REGS       
        ,TEXT("Misc")           //  9   ZONE_MISC       
        ,TEXT("Init")           // 10   ZONE_INIT       
        ,TEXT("IOcontrol")      // 11   ZONE_IOCTL      
        ,TEXT("Alloc")          // 12   ZONE_ALLOC      
        ,TEXT("Function")       // 13   ZONE_FUNCTION   
        ,TEXT("Warning")        // 14   ZONE_WARN       
        ,TEXT("Error")          // 15   ZONE_ERROR      
    },
        (1 << 15)   // Errors
    |   (1 << 14)   // Warnings
}; 
#endif

BOOL HardwareContext::g_AECSetMode(BOOL bMode)
{
	#if defined(_USING_AEC_)
	g_AECMode=bMode;
	if(bMode)
	{
		RETAILMSG(1, (TEXT("[WAVEDEV     ]Set Mode change BT HFP Mode ON \n")));
		SAMPLERATE=8000; //change sampling rate

		AUDIO_DMA_PAGE_SIZE		=(256)	;				// Size in bytes
		AUDIO_DMA_IN_PAGE_SIZE	=(256)	;				// Size in bytes
		MapDMABuffers();
		tcc_i2s_init(pstrADMADAI_VirtualRegAddr, pstrADMA_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr,
			OUTPUTDMANO, INPUTDMANO,AUDIO_DMA_PAGE_SIZE, AUDIO_DMA_IN_PAGE_SIZE,AUDIO_DMA_PAGE_SIZE_SPIDF,SAMPLERATE);
	}
	else
	{
		RETAILMSG(1, (TEXT("[WAVEDEV     ]Set Mode change BT HFP Mode OFF \n")));
		SAMPLERATE=44100; //change sampling rate
		AUDIO_DMA_PAGE_SIZE		=(1024)	;				// Size in bytes
		AUDIO_DMA_IN_PAGE_SIZE	=(1024)	;				// Size in bytes
	    MapDMABuffers();
		tcc_i2s_init(pstrADMADAI_VirtualRegAddr, pstrADMA_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr,
			OUTPUTDMANO,INPUTDMANO,AUDIO_DMA_PAGE_SIZE, AUDIO_DMA_IN_PAGE_SIZE,AUDIO_DMA_PAGE_SIZE_SPIDF,SAMPLERATE);
		tcc_i2s_start(pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0);
		tcc_i2s_start(pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 1);
#if defined(_SPDIF_COMMON_)
		tcc_i2s_start(pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 2);
#endif
	}

	g_pHWContext->StartOutputDMA();
#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)	
	g_pHWContext->StopOutputDMA();
#else
	g_pHWContext->StopOutputDMAByTransferType(TRANSFER_TYPE_PCM);
#endif
	g_pHWContext->StartInputDMA();
	g_pHWContext->StopInputDMA();
	#endif
		return TRUE;
}
/************************************************************************************************
* FUNCTION		: void Delay(int count)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL HardwareContext::CreateHWContext(DWORD Index)
{
    if (g_pHWContext)
    {
        return(TRUE);
    }

    g_pHWContext = new HardwareContext;

	if (!g_pHWContext)
    {
        return(FALSE);
    }

    return(g_pHWContext->Init(Index));
}

HardwareContext::HardwareContext()
: m_InputDeviceContext(), m_OutputDeviceContext() 
{
    InitializeCriticalSection(&m_Lock);
    m_Initialized=FALSE;
	m_OutputDMARunning=0;
	
	//Get the virtual base address that maps the base physical address
	if(pstrADMA_VirtualRegAddr == NULL)
		pstrADMA_VirtualRegAddr = (ADMA*)tcc_allocbaseaddress((unsigned int)&HwADMA_BASE);
	if(pstrADMADAI_VirtualRegAddr == NULL)
		pstrADMADAI_VirtualRegAddr = (ADMADAI*)tcc_allocbaseaddress((unsigned int)&HwADMA_DAIBASE);
	if(pstrGPIO_VirtualRegAddr == NULL)
		pstrGPIO_VirtualRegAddr = (GPIO*)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	if(pstrADMASPDIFTX_VirtualRegAddr == NULL)
		pstrADMASPDIFTX_VirtualRegAddr = (ADMASPDIFTX*)tcc_allocbaseaddress((unsigned int)&HwADMA_SPDIFTXBASE);
}

HardwareContext::~HardwareContext()
{
    DeleteCriticalSection(&m_Lock);
}

BOOL HardwareContext::Init(DWORD Index)
{
    UINT32 Irq;

    RETAILMSG(FALSE, (TEXT("[WAVEDEV     ]Wavedev:::Hardware Init\r\n")));
    
    m_dwInputGain  = 0xFFFF;
    m_dwOutputGain = 0xFFFF;
    m_fInputMute   = FALSE;
    m_fOutputMute  = FALSE;


    if (m_Initialized)
    {
        return(FALSE);
    }

    // Call the OAL to translate the audio IRQ into a SYSINTR value.
    //
	Irq = tcc_irq_getnumber();

    if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &Irq, sizeof(UINT32), &m_dwSysintrOutput, sizeof(UINT32), NULL))
    {
        RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]ERROR: HardwareContext::Init: Failed to obtain sysintr value for output interrupt.\r\n")));
        return FALSE;
    }

    //----- 1. Initialize the state/status variables -----
    m_DriverIndex       = Index;
    m_InPowerHandler    = FALSE;
    m_InputDMARunning   = 0;
    m_OutputDMARunning  = 0;
    m_InputDMAStatus    = DMA_CLEAR;                
    m_OutputDMAStatus   = DMA_CLEAR;                
#if defined(_SPDIF_COMMON_)
	m_SPDIFOutputDMAStatus = DMA_CLEAR;      
#endif
    //----- 2. Map the necessary descriptory channel and control registers into the driver's virtual address space -----
    if(!MapRegisters())
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("[WAVEDEV     ]HardwareContext::Init() - Failed to map config registers.\r\n")));
        goto Exit;
    }

    //----- 3. Map the DMA buffers into driver's virtual address space -----
    if(!MapDMABuffers())
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("[WAVEDEV     ]HardwareContext::Init() - Failed to map DMA buffers.\r\n")));
        goto Exit;
    }

    //----- 4. Configure the Codec -----
    InitCodec();
    
    //----- 5. Initialize the interrupt thread -----
    if (!InitInterruptThread())
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("[WAVEDEV     ]HardwareContext::Init() - Failed to initialize interrupt thread.\r\n")));
        goto Exit;
    }
	
	// AEC include
#if defined(_USING_AEC_)
	pInQueue = new cCircularQueue();
    pInQueue->Create( new BYTE[8192], 8192);
	
	pOutQueue = new cCircularQueue();
    pOutQueue->Create( new BYTE[8192], 8192);

	pResultQueue = new cCircularQueue();
    pResultQueue->Create( new BYTE[8192], 8192);

	// callback function setting
	s_aec_callback_func.m_pfMalloc 	= malloc;
	s_aec_callback_func.m_pfFree 	= free;
	s_aec_callback_func.m_pfMemset  = memset;
	s_aec_callback_func.m_pfMemcpy  = memcpy;

	s_aec_params.m_iNoiseSuppressdB 	 = -30; // -15;
	s_aec_params.m_iEchoSuppressdB		 = -50; // -40;
	s_aec_params.m_iEchoSuppressActivedB = -25; // -15;
	s_aec_params.m_iConvergenceCoeff	 = (int)(0.99*32768); // default = (int)(0.99*32768)
	s_aec_params.m_iDCfilterSelect		 = 0; // 0==aec filter, 1==50Hz cut off, 2==100Hz cut off, 3==200Hz cut off
	s_aec_params.m_iInputGainScale		 = (int)(0.6f*1024); // q10 default ( (int)(0.5f*1024) )
	s_aec_params.m_iOutputGainScale 	 = (int)(0.0f*1024); // q10 default ( (int)(0.0f*1024) )
	s_aec_params.m_iTxGainScale 		 = (int)(1.67f*1024); // q10 default ( (int)(2.0f*1024) )
	s_aec_params.m_iRxGainScale 		 = (int)(0.0f*1024); // q10 default ( (int)(0.0f*1024) )	
	s_aec_params.m_uiControlOptions 	 = 0;	// first of all, s_aec_params.m_uiControlOptions must be initialized to 0
//	s_aec_params.m_uiControlOptions 	 |= AEC_PARAM_AEC_OFF;	// turn off aec
//	s_aec_params.m_uiControlOptions 	 |= AEC_PARAM_NR_OFF;	// turn off nr
//	s_aec_params.m_uiControlOptions 	 |= AEC_PARAM_USE_BASEDIVIDE; // use inherent divide function
	s_aec_params.m_uiControlOptions 	 |= AUTO_INGAIN_CONTROL_ON; // use inherent divide function
//	s_aec_params.m_uiControlOptions 	 |= AUTO_OUTGAIN_CONTROL_ON; // use inherent divide function

	if(TC_AEC_Init(&pAECHandle, s_aec_params, s_aec_callback_func)!=0)
	{
		RETAILMSG(1,(TEXT("[WAVEDEV     ]TC_AEC_Init Error\n")));
	}
#endif


    m_Initialized=TRUE;

Exit:
    return(m_Initialized);
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       MapRegisters()

Description:    Maps the config registers used by both the SPI and
                I2S controllers.

Notes:          The SPI and I2S controllers both use the GPIO config
                registers, so these MUST be initialized FIRST.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::MapRegisters()
{
    PowerUp();
    return(TRUE);
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       Deinit()

Description:    Deinitializest the hardware: disables DMA channel(s), 
                clears any pending interrupts, powers down the audio
                codec chip, etc.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::Deinit()
{
    //----- 1. Disable the input/output channels -----
    tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0, INPUTDMANO,INDMA); //input
    tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,OUTDMA);
#if defined(_SPDIF_COMMON_)
	tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,SPDIFOUTDMA);
#endif
    //----- 2. Disable/clear DMA input/output interrupts -----


    //----- 3. Turn the audio hardware off -----
    AudioMute(DMA_CH_OUT | DMA_CH_MIC, TRUE);

    //----- 4. Unmap the control registers and DMA buffers -----
    UnmapRegisters();
    UnmapDMABuffers();

#if defined(_USING_AEC_)
	delete pInQueue;
	delete pOutQueue;
	delete pResultQueue;
#endif

    return TRUE;
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       UnmapRegisters()

Description:    Unmaps the config registers used by both the SPI and
                I2S controllers.

Notes:          The SPI and I2S controllers both use the GPIO config
                registers, so these MUST be deinitialized LAST.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::UnmapRegisters()
{
    return TRUE;
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       MapDMABuffers()

Description:    Maps the DMA buffers used for audio input/output
                on the I2S bus.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::MapDMABuffers()
{
#if defined(AUDIO_DMA_IN_SRAM)	
	//PBYTE pSRAMPhysicalAddress = (PBYTE)0x10000000;
	PBYTE pSRAMPhysicalAddress = (PBYTE)0x10002800;
#else
	tSYSTEM_PARAM *pSystemParamPhysicalAddress = (tSYSTEM_PARAM*)SYSTEM_PARAM_BASEADDRESS;
	tSYSTEM_PARAM *pSystemParamVirtualAddress = NULL;
#endif	
    static PBYTE pVirtDMABufferAddr = NULL;
    DMA_ADAPTER_OBJECT Adapter;

//	if(pVirtDMABufferAddr != NULL)
//	{
//		tcc_freebaseaddress((unsigned int)pVirtDMABufferAddr, sizeof(tSYSTEM_PARAM));
//	}

#if defined(AUDIO_DMA_IN_SRAM)
	pVirtDMABufferAddr = (PBYTE)tcc_allocbaseaddress((unsigned int)pSRAMPhysicalAddress);
	g_PhysDMABufferAddr.LowPart = (DWORD)pSRAMPhysicalAddress;
#else
	pSystemParamVirtualAddress = (tSYSTEM_PARAM*)tcc_allocbaseaddress((unsigned int)pSystemParamPhysicalAddress);
	pVirtDMABufferAddr = pSystemParamVirtualAddress->ADMA_BUFFER;
	g_PhysDMABufferAddr.LowPart = (DWORD)pSystemParamPhysicalAddress->ADMA_BUFFER;
#endif

	memset(&Adapter, 0, sizeof(DMA_ADAPTER_OBJECT));
    Adapter.InterfaceType = Internal;
    Adapter.ObjectSize = sizeof(DMA_ADAPTER_OBJECT);
    
    RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]HardwareContext::MapDMABuffers() @ %x\r\n"), g_PhysDMABufferAddr));
    
    if (pVirtDMABufferAddr == NULL)
    {
        RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]HardwareContext::MapDMABuffers() - Failed to allocate DMA buffer.\r\n")));
        return(FALSE);
    }
    //RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]HardwareContext::MapDMABuffers() @ %x\r\n"), g_PhysDMABufferAddr));
    // Setup the DMA page pointers.
    // NOTE: Currently, input and output each have two DMA pages: these pages are used in a round-robin
    // fashion so that the OS can read/write one buffer while the audio codec chip read/writes the other buffer.
    //
    m_Output_pbDMA_PAGES[0] = pVirtDMABufferAddr;

	m_Output_pbDMA_PAGES[1] = m_Output_pbDMA_PAGES[0] + AUDIO_DMA_PAGE_SIZE;
	
	m_Input_pbDMA_PAGES[0]  = m_Output_pbDMA_PAGES[1] + AUDIO_DMA_PAGE_SIZE;

	m_Input_pbDMA_PAGES[1] = m_Input_pbDMA_PAGES[0] + AUDIO_DMA_IN_PAGE_SIZE;

#if defined(_SPDIF_COMMON_)
	m_Output_pbDMA_PAGES_ForSPDIF[0] = m_Input_pbDMA_PAGES[1] + AUDIO_DMA_IN_PAGE_SIZE;
	m_Output_pbDMA_PAGES_ForSPDIF[1] = m_Output_pbDMA_PAGES_ForSPDIF[0] + AUDIO_DMA_PAGE_SIZE_SPIDF;
#endif
	
    return(TRUE);
    
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       UnmapDMABuffers()

Description:    Unmaps the DMA buffers used for audio input/output
                on the I2S bus.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::UnmapDMABuffers()
{
    return TRUE;
}

BOOL HardwareContext::Codec_channel(DWORD status)
{

	switch(status){
		
	case 0x03: // in & out
	case 0x07: // in & out & spdif output
		if(_gCurrentDAC != status)
		{
			#if defined(_USING_AEC_)
			if(g_AECMode)
				tcc_setinputoutputmode(ghI2C, MIC_INPUT);	
			else
			#endif
			if(gbFMRMODE)
				tcc_setinputoutputmode(ghI2C, FMR_INPUT);	
			else
				tcc_setinputoutputmode(ghI2C, gInputType);	

			_gCurrentDAC = status;
		}
		break;
		
	case 0x01: // in
	case 0x05: // in & spdif output
		if(_gCurrentDAC != status)
		{
			
			#if defined(_USING_AEC_)
			if(g_AECMode)
				tcc_setinputmode(ghI2C, MIC_INPUT);	
			else
			#endif
			if(gbFMRMODE)
				tcc_setinputmode(ghI2C, FMR_INPUT);
			else
				tcc_setinputmode(ghI2C, gInputType);

			_gCurrentDAC = status;
		}
		break;
		
	case 0x02: // out
	case 0x06: // out & spdif output
		if(_gCurrentDAC != status)
		{
			#if defined(_USING_AEC_)
			if(g_AECMode)
				tcc_setoutputmode(ghI2C, MIC_INPUT);	
			else
			#endif
			if(gbFMRMODE)
				tcc_setoutputmode(ghI2C, FMR_INPUT);		
			else
				tcc_setoutputmode(ghI2C, gInputType);

			_gCurrentDAC = status;
		}
		break;
		
	case 0x00:
	case 0x04: // spdif output
		if((_gCurrentDAC != status)&&((_gCurrentDAC == 0x03)||(_gCurrentDAC == 0x01)))
		{
			tcc_setnormalmode(ghI2C);
			_gCurrentDAC = status;
		}		
		break;
    }


    return(TRUE);
}

MMRESULT HardwareContext::SetOutputGain (DWORD dwGain)
{
	RETAILMSG(1,(TEXT("[WAVEDEV     ]SetOutputGain(%d)\n"),dwGain & 0xffff));
	m_dwOutputGain = dwGain & 0xffff; // save off so we can return this from GetGain - but only MONO

	_gCurrentGain = dwGain;
	
	tcc_setoutputgain(ghI2C, m_dwOutputGain);
		
    return MMSYSERR_NOERROR;
}

MMRESULT HardwareContext::SetOutputMute (BOOL fMute)
{
    m_fOutputMute = fMute;
	RETAILMSG(1,(TEXT("[WAVEDEV     ]SetOutputMute(%d)\n"),fMute));

    if(fMute){
		tcc_setoutputmute(ghI2C, 1);//mute on
	}
    else{
		tcc_setoutputmute(ghI2C, 0);//mute off
	}

    return MMSYSERR_NOERROR;
}

BOOL HardwareContext::GetOutputMute (void)
{
    return m_fOutputMute;
}

DWORD HardwareContext::GetOutputGain (void)
{
    return m_dwOutputGain;
}

BOOL HardwareContext::GetInputMute (void)
{
    return m_fInputMute;
}

MMRESULT HardwareContext::SetInputMute (BOOL fMute)
{
    m_fInputMute = fMute;
    if ( fMute )
    {
		tcc_setinputmute(ghI2C, 1);
    }
    else
    {
       // UCHAR ucGain = (UCHAR) (m_dwInputGain / 2048);  // codec supports 32 steps volume;
		tcc_setinputmute(ghI2C, 0);
    }
    return MMSYSERR_NOERROR;
}

DWORD HardwareContext::GetInputGain (void)
{
    return m_dwInputGain;
}

MMRESULT HardwareContext::SetInputGain (DWORD dwGain)
{
    m_dwInputGain = dwGain & 0xffff; // save off so we can return this from GetGain - but only MONO
	
    UCHAR ucGain = (UCHAR) (m_dwInputGain / 2048);  // codec supports 32 steps volume;
	
    RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]HardwareContext::SetInputGain(%d)\r\n"), m_dwInputGain));
	
	tcc_setinputgain(ghI2C, m_dwInputGain);
	
    return MMSYSERR_NOERROR;
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       InitCodec()

Description:    Initializes the audio codec chip.

Notes:          The audio codec chip is intialized for output mode
                but powered down.  To conserve battery life, the chip
                is only powered up when the user starts playing a 
                file.

                Specifically, the powerup/powerdown logic is done 
                in the AudioMute() function.  If either of the 
                audio channels are unmuted, then the chip is powered
                up; otherwise the chip is powered own.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::InitCodec()
{
    RETAILMSG(FALSE, (TEXT("[WAVEDEV     ]+Wavedev:::Codec Init\r\n")));
    DEBUGMSG(ZONE_FUNCTION, (TEXT("[WAVEDEV     ]+++InitCodec\n")));

	tcc_i2c_open(ghI2C);
	
	tcc_tcc_initport(pstrGPIO_VirtualRegAddr); //port init for output mute control

    tcc_initcodec(ghI2C);

    tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,OUTDMA);//output dma disable
#if defined(_SPDIF_COMMON_)
	tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,SPDIFOUTDMA);//spdif output dma disable    
#endif
	tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,INPUTDMANO,INDMA); //input dma disable
	RETAILMSG(FALSE, (TEXT("[WAVEDEV     ]-Wavedev:::Codec Init\r\n")));
    return(TRUE);
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       InitOutputDMA()

Description:    Initializes the DMA channel for output.

Notes:          DMA Channel 2 is used for transmitting output sound
                data from system memory to the I2S controller.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::InitOutputDMA(DWORD TransferType)
{
	unsigned int OutputDMAVirtualAddress = g_PhysDMABufferAddr.LowPart;
	
    RETAILMSG(0,(TEXT("[WAVEDEV     ]+InitOutputDMA\n")));
    // Initialize the DMA channel for output mode and use the first output DMA buffer -----
    if (!g_PhysDMABufferAddr.LowPart)
    {
        DEBUGMSG(TRUE, (TEXT("[WAVEDEV     ]ERROR:HardwareContext::InitOutputDMA: Invalid DMA buffer physical address.\r\n")));
        return(FALSE);
    }
	
	// Set the start address of DMA source buffer
	if(TransferType == TRANSFER_TYPE_PCM)
	{
	    tcc_dma_setsrcaddr(pstrADMA_VirtualRegAddr, 0, OUTPUTDMANO, OutputDMAVirtualAddress);
	}
#if defined(_SPDIF_COMMON_)
	else//TRANSFER_TYPE_SPDIF
	{
		tcc_dma_setsrcaddr(pstrADMA_VirtualRegAddr, 4, OUTPUTDMANO, OutputDMAVirtualAddress + 2*AUDIO_DMA_PAGE_SIZE + 2*AUDIO_DMA_IN_PAGE_SIZE);		
	}
#endif
    // Reset the playback pointers -----
    RETAILMSG(0,(TEXT("[WAVEDEV     ]-InitOutputDMA\n")));

    return TRUE;
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       StartOutputDMA()

Description:    Starts outputting the sound data to the audio codec
                chip via DMA.

Notes:          Currently, both playback and record share the same
                DMA channel.  Consequently, we can only start this
                operation if the input channel isn't using DMA.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/

BOOL HardwareContext::StartOutputDMA()
{
	unsigned int OutputDMAVirtualAddress = g_PhysDMABufferAddr.LowPart;
	ULONG OutputTransferred;
	RETAILMSG(0,(TEXT("[WAVEDEV     ]++StartOutputDMA[%d]\n"),m_OutputDMARunning));

    if(!(m_OutputDMARunning & 0x02))
    {
        RETAILMSG(0,(TEXT("[WAVEDEV     ]++StartOutputDMA I2S[%d]\n"),m_OutputDMARunning));
        //----- 1. Initialize our buffer counters -----
        m_OutputDMARunning |= 0x2; //0x2 means TRUE
        m_OutBytes[TRANSFER_TYPE_PCM][OUT_BUFFER_A]=m_OutBytes[TRANSFER_TYPE_PCM][OUT_BUFFER_B]=0;
		
        //----- 2. Prime the output buffer with sound data -----
		//Audio DMA Noise error is modified.(Because Audio dma current address is not rest)
		if (pstrADMA_VirtualRegAddr->TxDaCsar > (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE)) 
		{
			m_OutputDMAStatus = DMA_DONEA | DMA_BIU;
#if defined(_USING_AEC_)
			curOutputADMAOffset = pstrADMA_VirtualRegAddr->TxDaCsar - (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE);
			if(curOutputADMAOffset >= AUDIO_DMA_PAGE_SIZE)
				curOutputADMAOffset = 0;
#endif			
		}
		else
		{
			m_OutputDMAStatus = (DMA_DONEA | DMA_DONEB) & ~DMA_BIU;
#if defined(_USING_AEC_)
			curOutputADMAOffset = pstrADMA_VirtualRegAddr->TxDaCsar - g_PhysDMABufferAddr.LowPart;
			if(curOutputADMAOffset >= AUDIO_DMA_PAGE_SIZE)
				curOutputADMAOffset = 0;
#endif			
		}

		m_OutputDeviceContext.ResetStreamSampleForSRC(TRANSFER_TYPE_PCM);
		memset(m_Output_pbDMA_PAGES[0], 0, AUDIO_DMA_PAGE_SIZE*2);

        OutputTransferred = TransferOutputBuffers(m_OutputDMAStatus, TRANSFER_TYPE_PCM);
		        
        //----- 3. If we did transfer any data to the DMA buffers, go ahead and enable DMA -----
        if(OutputTransferred)
        {
			RETAILMSG(0,(TEXT("[WAVEDEV     ]==OutputTransferred TRUE\n")));
            //----- 4. Configure the DMA channel for playback -----
            if(!InitOutputDMA(TRANSFER_TYPE_PCM))
            {
                RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]HardwareContext::StartOutputDMA() - Unable to initialize output DMA channel!\r\n")));
                goto START_ERROR;
            }
            //----- 5. Make sure the audio isn't muted -----
            AudioMute(DMA_CH_OUT, FALSE);                   
			
            //----- 6. Start the DMA controller -----
			tcc_dma_setsrcaddr(pstrADMA_VirtualRegAddr, 0, OUTPUTDMANO, OutputDMAVirtualAddress);
            Codec_channel(m_InputDMARunning + m_OutputDMARunning); // Turn ON output channel
            // charlie, start A buffer
            tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 1,OUTPUTDMANO,OUTDMA);
        }
        else    // We didn't transfer any data, so DMA wasn't enabled
        {
            m_OutputDMARunning &= ~0x02;// 0 means FALSE 
        }
    }
	
#if defined(_SPDIF_COMMON_)
	if(!(m_OutputDMARunning & 0x04))
	{
        RETAILMSG(0,(TEXT("[WAVEDEV     ]++StartOutputDMA SPDIF[%d]\n"),m_OutputDMARunning));
        //----- 1. Initialize our buffer counters -----
        m_OutputDMARunning |= 0x04; //0x4 means TRUE
		m_OutBytes[TRANSFER_TYPE_SPDIF][OUT_BUFFER_A]=m_OutBytes[TRANSFER_TYPE_SPDIF][OUT_BUFFER_B]=0;
		
        //----- 2. Prime the output buffer with sound data -----
		if (pstrADMA_VirtualRegAddr->TxSpCsar > (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE*2 +
					AUDIO_DMA_IN_PAGE_SIZE*2 + AUDIO_DMA_PAGE_SIZE_SPIDF)) 
			m_SPDIFOutputDMAStatus = DMA_DONEA | DMA_BIU;
		else
			m_SPDIFOutputDMAStatus = (DMA_DONEA | DMA_DONEB) & ~DMA_BIU;

#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)			
		ULONG SPDIFOutputTransferred = 1;
#else
		m_OutputDeviceContext.ResetStreamSampleForSRC(TRANSFER_TYPE_SPDIF);
		memset(m_Output_pbDMA_PAGES_ForSPDIF[0], 0, AUDIO_DMA_PAGE_SIZE_SPIDF*2);

		ULONG SPDIFOutputTransferred = TransferOutputBuffers(m_SPDIFOutputDMAStatus, TRANSFER_TYPE_SPDIF);
#endif
        //----- 3. If we did transfer any data to the DMA buffers, go ahead and enable DMA -----
    	RETAILMSG(0,(TEXT("[WAVEDEV     ]==OutputTransferred TRUE\n")));
		if(SPDIFOutputTransferred)
		{
			//----- 4. Configure the DMA channel for playback -----
            if(!InitOutputDMA(TRANSFER_TYPE_SPDIF))
            {
                RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]HardwareContext::StartOutputDMA() - Unable to initialize output DMA channel! SPDIF\r\n")));
                goto START_ERROR;
            }
            //----- 5. Make sure the audio isn't muted -----
            AudioMute(DMA_CH_OUT, FALSE);                   
			
            //----- 6. Start the DMA controller -----
			tcc_dma_setsrcaddr(pstrADMA_VirtualRegAddr, 4, OUTPUTDMANO, OutputDMAVirtualAddress + 2*AUDIO_DMA_PAGE_SIZE + 2*AUDIO_DMA_IN_PAGE_SIZE);
			tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 1,OUTPUTDMANO,SPDIFOUTDMA);
		}            
        else    // We didn't transfer any data, so DMA wasn't enabled
        {
            m_OutputDMARunning &= ~0x04;// 0 means FALSE 
        }
    }
#endif	
    RETAILMSG(0,(TEXT("[WAVEDEV     ]--StartOutputDMA\n")));
    return TRUE;
	
START_ERROR:
    return FALSE;
}

BOOL HardwareContext::StartOutputDMAByTransferType(DWORD TransferType)
{
	unsigned int OutputDMAVirtualAddress = g_PhysDMABufferAddr.LowPart;
	
	RETAILMSG(0,(TEXT("[WAVEDEV     ]++StartOutputDMAByTransferType[%d]\n"),m_OutputDMARunning));

    if( !(m_OutputDMARunning & 0x02) && (TransferType == TRANSFER_TYPE_PCM) )
    {
        RETAILMSG(0,(TEXT("[WAVEDEV     ]++StartOutputDMAByTransferType I2S[%d]\n"),m_OutputDMARunning));
        //----- 1. Initialize our buffer counters -----
        m_OutputDMARunning |= 0x2; //0x2 means TRUE
        m_OutBytes[TRANSFER_TYPE_PCM][OUT_BUFFER_A]=m_OutBytes[TRANSFER_TYPE_PCM][OUT_BUFFER_B]=0;
		
        //----- 2. Prime the output buffer with sound data -----
		//Audio DMA Noise error is modified.(Because Audio dma current address is not rest)
		if (pstrADMA_VirtualRegAddr->TxDaCsar > (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE)) 
		{
			m_OutputDMAStatus = DMA_DONEA | DMA_BIU;
#if defined(_USING_AEC_)
			curOutputADMAOffset = pstrADMA_VirtualRegAddr->TxDaCsar - (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE);
			if(curOutputADMAOffset >= AUDIO_DMA_PAGE_SIZE)
				curOutputADMAOffset = 0;
#endif			
		}
		else
		{
			m_OutputDMAStatus = (DMA_DONEA | DMA_DONEB) & ~DMA_BIU;
#if defined(_USING_AEC_)
			curOutputADMAOffset = pstrADMA_VirtualRegAddr->TxDaCsar - g_PhysDMABufferAddr.LowPart;
			if(curOutputADMAOffset >= AUDIO_DMA_PAGE_SIZE)
				curOutputADMAOffset = 0;
#endif			
		}
		
		m_OutputDeviceContext.ResetStreamSampleForSRC(TRANSFER_TYPE_PCM);
		memset(m_Output_pbDMA_PAGES[0], 0, AUDIO_DMA_PAGE_SIZE*2);

        ULONG OutputTransferred = TransferOutputBuffers(m_OutputDMAStatus, TRANSFER_TYPE_PCM);
        //----- 3. If we did transfer any data to the DMA buffers, go ahead and enable DMA -----
        if(OutputTransferred)
        {
			RETAILMSG(0,(TEXT("[WAVEDEV     ]==OutputTransferred TRUE\n")));
            //----- 4. Configure the DMA channel for playback -----
            if(!InitOutputDMA(TRANSFER_TYPE_PCM))
            {
                RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]HardwareContext::StartOutputDMAByTransferType() - Unable to initialize output DMA channel!\r\n")));
                goto START_ERROR;
            }
            //----- 5. Make sure the audio isn't muted -----
            AudioMute(DMA_CH_OUT, FALSE);                   
			
            //----- 6. Start the DMA controller -----
			tcc_dma_setsrcaddr(pstrADMA_VirtualRegAddr, 0, OUTPUTDMANO, OutputDMAVirtualAddress);
            Codec_channel(m_InputDMARunning + m_OutputDMARunning); // Turn ON output channel
            // charlie, start A buffer
            tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 1,OUTPUTDMANO,OUTDMA);
        }
        else    // We didn't transfer any data, so DMA wasn't enabled
        {
            m_OutputDMARunning &= ~0x02;// 0 means FALSE 
        }
    }
	
#if defined(_SPDIF_COMMON_)
	if( !(m_OutputDMARunning & 0x04) && (TransferType == TRANSFER_TYPE_SPDIF) )
	{
        RETAILMSG(0,(TEXT("[WAVEDEV     ]++StartOutputDMAByTransferType SPDIF[%d]\n"),m_OutputDMARunning));
        //----- 1. Initialize our buffer counters -----
        m_OutputDMARunning |= 0x04; //0x4 means TRUE
		m_OutBytes[TRANSFER_TYPE_SPDIF][OUT_BUFFER_A]=m_OutBytes[TRANSFER_TYPE_SPDIF][OUT_BUFFER_B]=0;
		
        //----- 2. Prime the output buffer with sound data -----
		if (pstrADMA_VirtualRegAddr->TxSpCsar > (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE*2 +
					AUDIO_DMA_IN_PAGE_SIZE*2 + AUDIO_DMA_PAGE_SIZE_SPIDF)) 
			m_SPDIFOutputDMAStatus = DMA_DONEA | DMA_BIU;
		else
			m_SPDIFOutputDMAStatus = (DMA_DONEA | DMA_DONEB) & ~DMA_BIU;

#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)						
		ULONG SPDIFOutputTransferred = 1;
#else
		m_OutputDeviceContext.ResetStreamSampleForSRC(TRANSFER_TYPE_SPDIF);
		memset(m_Output_pbDMA_PAGES_ForSPDIF[0], 0, AUDIO_DMA_PAGE_SIZE_SPIDF*2);

		ULONG SPDIFOutputTransferred = TransferOutputBuffers(m_SPDIFOutputDMAStatus, TRANSFER_TYPE_SPDIF);
#endif		
        //----- 3. If we did transfer any data to the DMA buffers, go ahead and enable DMA -----
    	RETAILMSG(0,(TEXT("[WAVEDEV     ]==OutputTransferred TRUE\n")));		
		if(SPDIFOutputTransferred)
		{
			//----- 4. Configure the DMA channel for playback -----
            if(!InitOutputDMA(TRANSFER_TYPE_SPDIF))
            {
                RETAILMSG(TRUE, (TEXT("[WAVEDEV     ]HardwareContext::StartOutputDMAByTransferType() - Unable to initialize output DMA channel! SPDIF\r\n")));
                goto START_ERROR;
            }
            //----- 5. Make sure the audio isn't muted -----
            AudioMute(DMA_CH_OUT, FALSE);                   
			
            //----- 6. Start the DMA controller -----
			tcc_dma_setsrcaddr(pstrADMA_VirtualRegAddr, 4, OUTPUTDMANO, OutputDMAVirtualAddress + 2*AUDIO_DMA_PAGE_SIZE + 2*AUDIO_DMA_IN_PAGE_SIZE);
			tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 1,OUTPUTDMANO,SPDIFOUTDMA);
		}            
        else    // We didn't transfer any data, so DMA wasn't enabled
        {
            m_OutputDMARunning &= ~0x04;// 0 means FALSE 
        }
    }
#endif	
    RETAILMSG(0,(TEXT("[WAVEDEV     ]--StartOutputDMAByTransferType\n")));
    return TRUE;
	
START_ERROR:
    return FALSE;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       StopOutputDMA()

Description:    Stops any DMA activity on the output channel.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
void HardwareContext::StopOutputDMA()
{
    RETAILMSG(0,(TEXT("[WAVEDEV     ]StopOutputDMA.\r\n")));
	unsigned int mute_status;
    //----- 1. If the output DMA is running, stop it -----
    if (m_OutputDMARunning & 0x2)
    {
        m_OutputDMAStatus = DMA_CLEAR;

		mute_status = tcc_getoutputmutestatus();
		tcc_setoutputmute(ghI2C, 1);//mute on
        tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,OUTDMA);
		tcc_setoutputmute(ghI2C, mute_status);
        AudioMute(DMA_CH_OUT, TRUE);        

		m_OutputDMARunning &= ~0x2;
    }
//When you use 2Channel DAI & SPDIF Same Data Output, SPDIF DMA does not stop.	
#if defined(_SPDIF_COMMON_) 
	#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY) || defined(SPDIF_2CH_ONLY)
	memset(m_Output_pbDMA_PAGES_ForSPDIF[0], 0, AUDIO_DMA_PAGE_SIZE_SPIDF*2);
	#else
	if (m_OutputDMARunning & 0x4)
    {
        m_SPDIFOutputDMAStatus = DMA_CLEAR;              
        tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,SPDIFOUTDMA);

		m_OutputDMARunning &= ~0x4;
    }
	#endif
#endif	
    Codec_channel( m_InputDMARunning + m_OutputDMARunning );
}

void HardwareContext::StopOutputDMAByTransferType(DWORD TransferType)
{
	unsigned int mute_status;
    RETAILMSG(0,(TEXT("[WAVEDEV     ]StopOutputDMAByTransferType Type=%d.\r\n"), TransferType));
    //----- 1. If the output DMA is running, stop it -----
    if (TransferType == TRANSFER_TYPE_PCM)
    {
        m_OutputDMAStatus = DMA_CLEAR;   
		mute_status = tcc_getoutputmutestatus();
		tcc_setoutputmute(ghI2C, 1);//mute on
        tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,OUTDMA);
		tcc_setoutputmute(ghI2C, mute_status);
        AudioMute(DMA_CH_OUT, TRUE);        

		m_OutputDMARunning &= ~0x2;

		Codec_channel( m_InputDMARunning + m_OutputDMARunning );
    }

#if defined(_SPDIF_COMMON_)
	if (TransferType == TRANSFER_TYPE_SPDIF)
    {
        m_SPDIFOutputDMAStatus = DMA_CLEAR;              
        tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,SPDIFOUTDMA);

		m_OutputDMARunning &= ~0x4;
    }    
#endif
}	

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       InitInputDMA()

Description:    Initializes the DMA channel for input.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::InitInputDMA()
{
	DEBUGMSG(ZONE_FUNCTION,(TEXT("[WAVEDEV     ]+InitInputDMA\n")));

	unsigned int InputDMAVirtualAddress = (g_PhysDMABufferAddr.LowPart + 2*AUDIO_DMA_PAGE_SIZE);
	
	if (!g_PhysDMABufferAddr.LowPart)
	{
		DEBUGMSG(TRUE, (TEXT("[WAVEDEV     ]ERROR:HardwareContext::InitInputDMA: Invalid DMA buffer physical address.\r\n")));
		return(FALSE);
	}
	//call source address setting for input dma
   	tcc_dma_setdestaddr(pstrADMA_VirtualRegAddr, 0, INPUTDMANO, InputDMAVirtualAddress);

	DEBUGMSG(ZONE_FUNCTION,(TEXT("[WAVEDEV     ]-InitInputDMA\n")));
	return(TRUE);
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       StartInputDMA()

Description:    Starts inputting the recorded sound data from the 
                audio codec chip via DMA.
Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::StartInputDMA()
{
	RETAILMSG(0,(TEXT("[WAVEDEV     ]+++StartInputDMA\n")));

	unsigned int InputDMAVirtualAddress = (g_PhysDMABufferAddr.LowPart + 2*AUDIO_DMA_PAGE_SIZE);
	
    if(0==m_InputDMARunning)
    {
        //----- 1. Initialize our buffer counters -----
        m_InputDMARunning=1;
        m_InBytes[IN_BUFFER_A]=m_InBytes[IN_BUFFER_B] = 0;
        //----- 2. Prime the output buffer with sound data -----
        m_InputDMAStatus = DMA_DONEA;
        //----- 3. Configure the DMA channel for record -----
        if(!InitInputDMA())
        {
            DEBUGMSG(ZONE_ERROR, (TEXT("[WAVEDEV     ]HardwareContext::StartInputDMA() - Unable to initialize input DMA channel!\r\n")));
            goto START_ERROR;
        }
        //----- 4. Make sure the audio isn't muted -----
        AudioMute(DMA_CH_MIC, FALSE);
        //----- 5. Start the input DMA -----
       	tcc_dma_setdestaddr(pstrADMA_VirtualRegAddr, 0, INPUTDMANO, InputDMAVirtualAddress);
		
        Codec_channel( m_InputDMARunning + m_OutputDMARunning );        // Turn On Input channel
        //

		if (pstrADMA_VirtualRegAddr->RxDaCdar > (g_PhysDMABufferAddr.LowPart + 2*AUDIO_DMA_PAGE_SIZE + AUDIO_DMA_IN_PAGE_SIZE )) 
		{
			m_InputDMAStatus = DMA_DONEB|DMA_BIU;
#if defined(_USING_AEC_)
			curInputADMAOffset = pstrADMA_VirtualRegAddr->RxDaCdar - (g_PhysDMABufferAddr.LowPart + 2*AUDIO_DMA_PAGE_SIZE + AUDIO_DMA_IN_PAGE_SIZE);
			if(curInputADMAOffset >= AUDIO_DMA_IN_PAGE_SIZE)
				curInputADMAOffset = 0;
#endif
		}
#if defined(_USING_AEC_)
		else
		{
			curInputADMAOffset = pstrADMA_VirtualRegAddr->RxDaCdar - (g_PhysDMABufferAddr.LowPart + 2*AUDIO_DMA_PAGE_SIZE);
			if(curInputADMAOffset >= AUDIO_DMA_IN_PAGE_SIZE)
				curInputADMAOffset = 0;
		}
#endif
		tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 1,INPUTDMANO,INDMA);

        // change the buffer pointer
    }
	
    DEBUGMSG(ZONE_FUNCTION,(TEXT("[WAVEDEV     ]---StartInputDMA\n")));
    return(TRUE);
	
START_ERROR:
    return(FALSE);
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       StopInputDMA()

Description:    Stops any DMA activity on the input channel.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
void HardwareContext::StopInputDMA()
{
    //----- 1. If the output DMA is running, stop it -----
    if (m_InputDMARunning)
    {
        m_InputDMAStatus = DMA_CLEAR;               
        tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,INPUTDMANO,INDMA);
        AudioMute(DMA_CH_MIC, TRUE);        
    }
	RETAILMSG(0, (TEXT("[WAVEDEV     ]StopInputDMA!!\n")));
	//tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,INPUTDMANO,INDMA);
    //m_InputDMARunning = FALSE;
    m_InputDMARunning = 0; // Zero means FALSE 

    Codec_channel(m_InputDMARunning + m_OutputDMARunning );
}


DWORD HardwareContext::GetInterruptThreadPriority()
{
    HKEY hDevKey;
    DWORD dwValType;
    DWORD dwValLen;
    DWORD dwPrio = 60; // Default priority is 249

    hDevKey = OpenDeviceKey((LPWSTR)m_DriverIndex);
    if (hDevKey)
    {
        dwValLen = sizeof(DWORD);
        RegQueryValueEx(
            hDevKey,
            TEXT("Priority256"),
            NULL,
            &dwValType,
            (PUCHAR)&dwPrio,
            &dwValLen);
        RegCloseKey(hDevKey);
    }
    RETAILMSG(FALSE, (TEXT("[WAVEDEV     ]I2S thread:%d\r\n"), dwPrio));
    return dwPrio;
}



/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       InitInterruptThread()

Description:    Initializes the IST for handling DMA interrupts.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::InitInterruptThread()
{
    m_hAudioInterrupt = CreateEvent(NULL, FALSE, FALSE, NULL);
    if (!m_hAudioInterrupt)
    {
        ERRMSG("Unable to create interrupt event");
        return(FALSE);
    }

    if (! InterruptInitialize(m_dwSysintrOutput, m_hAudioInterrupt, NULL, 0)) {
        ERRMSG("Unable to initialize output interrupt[%d]");
        return FALSE;
    }
    m_hAudioInterruptThread  = CreateThread((LPSECURITY_ATTRIBUTES)NULL,
                                            0,
                                            (LPTHREAD_START_ROUTINE)CallInterruptThread,
                                            this,
                                            0,
                                            NULL);
    if (!m_hAudioInterruptThread)
    {
        ERRMSG("Unable to create interrupt thread");
        return FALSE;
    }

    // Bump up the priority since the interrupt must be serviced immediately.
    CeSetThreadPriority(m_hAudioInterruptThread, GetInterruptThreadPriority());

    return(TRUE);
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       PowerUp()

Description:    Powers up the audio codec chip.

Notes:          Currently, this function is unimplemented because
                the audio codec chip is ONLY powered up when the 
                user wishes to play or record.  The AudioMute() function
                handles the powerup sequence.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
void HardwareContext::PowerUp()
{
    static int WavTemp = 0;
    RETAILMSG(1,(TEXT("[WAVEDEV     ]+Wavedev::PowerUp\r\n")));
	
	tcc_gpioexp_setcodepwrctl(1);

#if defined(AUDIO_DMA_IN_SRAM)
	if((AUDIO_DMA_PAGE_SIZE > 1024) ||  (AUDIO_DMA_IN_PAGE_SIZE > 1024) || (AUDIO_DMA_PAGE_SIZE_SPIDF > 1024))
	{
		//If you use SRAM Area for Audio dma buffer, you cannot use more than 1KB.
		//As you want to use more than 1KB for audio dma buffer, don'use "AUDIO_DMA_IN_SRAM".
		RETAILMSG(1,(TEXT("[WAVEDEV     ]-----------------------------------------------------\r\n")));
		RETAILMSG(1,(TEXT("[WAVEDEV     ]                                                     |\r\n")));
		RETAILMSG(1,(TEXT("[WAVEDEV     ]!!!!!ERROR!!!!Audio DMA buffer size is so big!!!!!!! |\r\n")));
		RETAILMSG(1,(TEXT("[WAVEDEV     ]                                                     |\r\n")));
		RETAILMSG(1,(TEXT("[WAVEDEV     ]-----------------------------------------------------\r\n")));
	}
#endif		

    if ( WavTemp == 0 )
    {
		tcc_i2s_init(pstrADMADAI_VirtualRegAddr, pstrADMA_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr,
			OUTPUTDMANO,INPUTDMANO,AUDIO_DMA_PAGE_SIZE, AUDIO_DMA_IN_PAGE_SIZE,AUDIO_DMA_PAGE_SIZE_SPIDF,SAMPLERATE);
        WavTemp = 1;
    }
    else if ( m_OutputDMARunning & 0x2 || m_OutputDMARunning & 0x4)
    {
		//clear output dma interrupt
		tcc_i2s_init(pstrADMADAI_VirtualRegAddr, pstrADMA_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr,
				OUTPUTDMANO,INPUTDMANO,AUDIO_DMA_PAGE_SIZE, AUDIO_DMA_IN_PAGE_SIZE,AUDIO_DMA_PAGE_SIZE_SPIDF,SAMPLERATE);

		if(m_OutputDMARunning & 0x2)
		{
			m_OutputDMAStatus = DMA_DONEB|DMA_BIU;
	        if(!InitOutputDMA(TRANSFER_TYPE_PCM))
	    		RETAILMSG(1, (TEXT("[WAVEDEV     ]HardwareContext::StartOutputDMA() - Unable to initialize output DMA channel!\r\n")));
	    	AudioMute(DMA_CH_OUT, FALSE);
			//tcc_dma_setsrcaddr(OUTPUTDMANO,g_PhysDMABufferAddr.LowPart);
			tcc_initcodec(ghI2C);
	    	Codec_channel( m_InputDMARunning + m_OutputDMARunning );
			SetOutputGain(_gCurrentGain);
			tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 1,OUTPUTDMANO,OUTDMA);
			tcc_i2s_setregister(pstrADMADAI_VirtualRegAddr, m_RegHwDAMR);

			if (pstrADMA_VirtualRegAddr->TxDaCsar > (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE)) {
				m_OutputDMAStatus = DMA_DONEA | DMA_BIU;
			} else {
				m_OutputDMAStatus = (DMA_DONEA | DMA_DONEB) & ~DMA_BIU;
			}
			TransferOutputBuffers(m_OutputDMAStatus, TRANSFER_TYPE_PCM);
		}
		
#if defined(_SPDIF_COMMON_)
		if(m_OutputDMARunning & 0x4)
		{
			m_SPDIFOutputDMAStatus = DMA_DONEB|DMA_BIU;
	        if(!InitOutputDMA(TRANSFER_TYPE_SPDIF))
	    		RETAILMSG(1, (TEXT("[WAVEDEV     ]HardwareContext::StartOutputDMA() - Unable to initialize output DMA channel!\r\n")));
	    	AudioMute(DMA_CH_OUT, FALSE);
	    	SetOutputGain(_gCurrentGain);
			tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 1,OUTPUTDMANO,SPDIFOUTDMA);
			tcc_i2s_setregister(pstrADMADAI_VirtualRegAddr, m_RegHwDAMR);

			if (pstrADMA_VirtualRegAddr->TxSpCsar > (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE*2 +
					AUDIO_DMA_IN_PAGE_SIZE*2 + AUDIO_DMA_PAGE_SIZE_SPIDF)) 
			{
				m_SPDIFOutputDMAStatus = DMA_DONEA | DMA_BIU;
			} else {
				m_SPDIFOutputDMAStatus = (DMA_DONEA | DMA_DONEB) & ~DMA_BIU;
			}
#if !defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)		
			TransferOutputBuffers(m_SPDIFOutputDMAStatus, TRANSFER_TYPE_SPDIF);
#endif
		}
#endif
    }
    else
    {
		//For suspend mode - enable audio bus and clock
		tcc_i2s_init(pstrADMADAI_VirtualRegAddr, pstrADMA_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr,
			OUTPUTDMANO,INPUTDMANO,AUDIO_DMA_PAGE_SIZE, AUDIO_DMA_IN_PAGE_SIZE,AUDIO_DMA_PAGE_SIZE_SPIDF,SAMPLERATE);
		
		tcc_initcodec(ghI2C);
    	Codec_channel( m_InputDMARunning + m_OutputDMARunning );
		SetOutputGain(_gCurrentGain);
	}
	RETAILMSG(1,(TEXT("[WAVEDEV     ]-Wavedev::PowerUp\r\n")));
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       PowerDown()

Description:    Powers down the audio codec chip.

Notes:          Even if the input/output channels are muted, this
                function powers down the audio codec chip in order
                to conserve battery power.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
void HardwareContext::PowerDown()
{
    RETAILMSG(1,(TEXT("[WAVEDEV     ]Wavedev::PowerDown\r\n")));
	
	if( m_OutputDMARunning & 0x2 || m_OutputDMARunning & 0x4)
	{
    	Codec_channel(0);
		m_RegHwDAMR = tcc_i2s_getregister(pstrADMADAI_VirtualRegAddr);
    	tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,OUTDMA);
#if defined(_SPDIF_COMMON_)
    	tcc_dma_control(pstrADMA_VirtualRegAddr, pstrADMADAI_VirtualRegAddr, pstrADMASPDIFTX_VirtualRegAddr, 0,OUTPUTDMANO,SPDIFOUTDMA);		
#endif
	}
		_gCurrentDAC = 0;

	tcc_setsleepmode(ghI2C);
	tcc_gpioexp_setcodepwrctl(0);
}


//############################################ Helper Functions #############################################

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       TransferOutputBuffer()

Description:    Retrieves the next "mixed" audio buffer of data to
                DMA into the output channel.

Returns:        Number of bytes needing to be transferred.
-------------------------------------------------------------------*/
#if defined(_MULTIL_DAO_INCLUDE_)		
extern void ArrangeBuffer(PBYTE pStart, PBYTE pEnd, ULONG NumBuf);
#endif		

ULONG HardwareContext::TransferOutputBuffer(ULONG NumBuf, DWORD TransferType)
{
	//RETAILMSG(1,(TEXT("[WAVEDEV     ]TransferOutputBuffer : NumBuf = %d\n"), NumBuf));
	
    ULONG BytesTransferred = 0;
    ULONG bLen1=0;
    
    PBYTE pBufferStart = NULL;
    PBYTE pBufferEnd = NULL;
    PBYTE pBufferLast;
	PBYTE pBufferStartForSPDIF = NULL;
#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)
	unsigned int iDiffSpCurSrcFromDMAStart = 0;
	static unsigned int PreStatusFlag = 0;
#endif				
	

	__try
    {
		if(TransferType == TRANSFER_TYPE_PCM)
		{
	        pBufferStart = m_Output_pbDMA_PAGES[NumBuf];
	        pBufferEnd = pBufferStart + AUDIO_DMA_PAGE_SIZE;
			//RETAILMSG(1,(TEXT("[WAVEDEV     ]TransferOutputBuffer : pBufferStart = %x, pBufferEnd = %x\n"), pBufferStart, pBufferEnd));

#if defined(_USING_AEC_)
			if(curOutputADMAOffset != 0)
			{
				pOutQueue->Write((BYTE *)(pBufferStart + curOutputADMAOffset), 256 - curOutputADMAOffset);
				curOutputADMAOffset = 0;
			}
			else
			{
				pOutQueue->Write((BYTE *)(pBufferStart), AUDIO_DMA_PAGE_SIZE);
			}
#endif	
	        pBufferLast = m_OutputDeviceContext.TransferBuffer(pBufferStart, pBufferEnd, NULL, TransferType);

			BytesTransferred = m_OutBytes[TransferType][NumBuf] = pBufferLast-pBufferStart;
			
	        // Enable if you need to clear the rest of the DMA buffer
	        StreamContext::ClearBuffer(pBufferLast,pBufferEnd);
#if defined(_MULTIL_DAO_INCLUDE_)		
			ArrangeBuffer(pBufferStart, pBufferLast, NumBuf);
#endif			
#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)
			iDiffSpCurSrcFromDMAStart = m_TxSpdifSrcAddrForI2SSync - (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE*2 +
					AUDIO_DMA_IN_PAGE_SIZE*2);
			
			if(iDiffSpCurSrcFromDMAStart > 1 && iDiffSpCurSrcFromDMAStart <= AUDIO_DMA_PAGE_SIZE_SPIDF/2)
			{
				if(PreStatusFlag == 4 && iDiffSpCurSrcFromDMAStart > AUDIO_DMA_PAGE_SIZE_SPIDF/2 - 0x10)
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[1] + AUDIO_DMA_PAGE_SIZE_SPIDF/2;
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF/2);
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0];
					memcpy(pBufferStartForSPDIF, pBufferStart + AUDIO_DMA_PAGE_SIZE_SPIDF/2, AUDIO_DMA_PAGE_SIZE_SPIDF/2);
					//printf("2. 0x%x Conpensation\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 2;
				}
				else if(PreStatusFlag == 2 && iDiffSpCurSrcFromDMAStart <= AUDIO_DMA_PAGE_SIZE_SPIDF/2 + 0x10)
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0] + AUDIO_DMA_PAGE_SIZE_SPIDF/2;
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("4. 0x%x Conpensation 2\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 4;
				}
				else//default
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[1];
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("1. 0x%x\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 1; 
				}
			}
			else if(iDiffSpCurSrcFromDMAStart <= AUDIO_DMA_PAGE_SIZE_SPIDF && iDiffSpCurSrcFromDMAStart != 0)
			{
				if(PreStatusFlag ==1 && iDiffSpCurSrcFromDMAStart > AUDIO_DMA_PAGE_SIZE_SPIDF - 0x10)
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0];
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("3. 0x%x Conpensation\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 3;
				}
				else if(PreStatusFlag == 3 && iDiffSpCurSrcFromDMAStart <= AUDIO_DMA_PAGE_SIZE_SPIDF + 0x10)
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[1];
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("1. 0x%x Conpensation 2\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 1; 
				}
				else//default
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[1] + AUDIO_DMA_PAGE_SIZE_SPIDF/2;
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF/2);
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0];
					memcpy(pBufferStartForSPDIF, pBufferStart + AUDIO_DMA_PAGE_SIZE_SPIDF/2, AUDIO_DMA_PAGE_SIZE_SPIDF/2);
					//printf("2. 0x%x\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 2;
				}
			}
			else if(iDiffSpCurSrcFromDMAStart <= AUDIO_DMA_PAGE_SIZE_SPIDF/2*3 && iDiffSpCurSrcFromDMAStart != 0)
			{
				if(PreStatusFlag == 2 && iDiffSpCurSrcFromDMAStart > AUDIO_DMA_PAGE_SIZE_SPIDF/2*3 - 0x10)
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0] + AUDIO_DMA_PAGE_SIZE_SPIDF/2;
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("4. 0x%x Conpensation\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 4;
				}
				else if(PreStatusFlag == 4 && iDiffSpCurSrcFromDMAStart <= AUDIO_DMA_PAGE_SIZE_SPIDF/2*3 + 0x10)
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[1] + AUDIO_DMA_PAGE_SIZE_SPIDF/2;
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF/2);
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0];
					memcpy(pBufferStartForSPDIF, pBufferStart + AUDIO_DMA_PAGE_SIZE_SPIDF/2, AUDIO_DMA_PAGE_SIZE_SPIDF/2);
					//printf("2. 0x%x Conpensation 2\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 2;
				}
				else//default
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0];
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("3. 0x%x\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 3;
				}
			}
			else if(iDiffSpCurSrcFromDMAStart <= AUDIO_DMA_PAGE_SIZE_SPIDF*2 || iDiffSpCurSrcFromDMAStart == 0)
			{
				if(PreStatusFlag == 3 && iDiffSpCurSrcFromDMAStart > AUDIO_DMA_PAGE_SIZE_SPIDF*2 - 0x10)
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[1];
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("1. 0x%x Conpensation\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 1; 
				}
				else if(PreStatusFlag == 1 && iDiffSpCurSrcFromDMAStart <= AUDIO_DMA_PAGE_SIZE_SPIDF*2 + 0x10)
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0];
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("3. 0x%x Conpensation 2\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 3;
				}
				else//default
				{
					pBufferStartForSPDIF = m_Output_pbDMA_PAGES_ForSPDIF[0] + AUDIO_DMA_PAGE_SIZE_SPIDF/2;
					memcpy(pBufferStartForSPDIF, pBufferStart, AUDIO_DMA_PAGE_SIZE_SPIDF);
					//printf("4. 0x%x\r\n", m_TxSpdifSrcAddrForI2SSync);
					PreStatusFlag = 4;
				}
			}
			else
				PreStatusFlag = 0;
			
			//printf("////////// 0x%x, 0x%x, %d\r\n", pBufferStart, pBufferStartForSPDIF, pBufferEnd - pBufferStart);
#endif		
	        if(NumBuf == OUT_BUFFER_A)          // Output Buffer A
	        {
	            m_OutputDMAStatus &= ~DMA_DONEA;
	            m_OutputDMAStatus |= DMA_STRTA;
	        }
	        else                                // Output Buffer B
	        {
	            m_OutputDMAStatus &= ~DMA_DONEB;
	            m_OutputDMAStatus |= DMA_STRTB;
	        }
		}
#if defined(_SPDIF_COMMON_)
		else//TRANSFER_TYPE_SPDIF
		{
			pBufferStart = m_Output_pbDMA_PAGES_ForSPDIF[NumBuf];
	        pBufferEnd = pBufferStart + AUDIO_DMA_PAGE_SIZE;
	        pBufferLast = m_OutputDeviceContext.TransferBuffer(pBufferStart, pBufferEnd, NULL, TransferType);

			BytesTransferred = m_OutBytes[TransferType][NumBuf] = pBufferLast-pBufferStart;
	        // Enable if you need to clear the rest of the DMA buffer
	        StreamContext::ClearBuffer(pBufferLast,pBufferEnd);

	        if(NumBuf == OUT_BUFFER_A)          // Output Buffer A
	        {
	            m_SPDIFOutputDMAStatus &= ~DMA_DONEA;
	            m_SPDIFOutputDMAStatus |= DMA_STRTA;
	        }
	        else                                // Output Buffer B
	        {
	            m_SPDIFOutputDMAStatus &= ~DMA_DONEB;
	            m_SPDIFOutputDMAStatus |= DMA_STRTB;
	        }
		}
#endif
    }
    __except(EXCEPTION_EXECUTE_HANDLER) 
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("[WAVEDEV     ]WAVDEV2.DLL:TransferOutputBuffer() - EXCEPTION: %d"), GetExceptionCode()));
    }

    return BytesTransferred;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       TransferOutputBuffers()

Description:    Determines which output buffer (A or B) needs to 
                be filled with sound data.  The correct buffer is
                then populated with data and ready to DMA to the 
                output channel.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
ULONG HardwareContext::TransferOutputBuffers(DWORD dwDCSR, DWORD TransferType)
{
    ULONG BytesTransferred = 0;
    ULONG BytesTotal;
    DWORD Bits = dwDCSR & (DMA_DONEA|DMA_DONEB|DMA_BIU);

    //
    switch (Bits)
    {
    case 0:
    case DMA_BIU:
        // No done bits set- must not be my interrupt
		RETAILMSG(1,(TEXT("[WAVEDEV     ]TransferOutputBuffers : DMA_BIU return \n")));
        //break;
        return 0;
    case DMA_DONEA|DMA_DONEB|DMA_BIU:
        // Load B, then A
        BytesTransferred = TransferOutputBuffer(OUT_BUFFER_B, TransferType);
        // fall through
    case DMA_DONEA: // This should never happen!
    case DMA_DONEA|DMA_BIU:
        BytesTransferred += TransferOutputBuffer(OUT_BUFFER_A, TransferType); // charlie, A => B
        break;
    case DMA_DONEA|DMA_DONEB:   // Both A & B are empty
        // Load A, then B
        BytesTransferred = TransferOutputBuffer(OUT_BUFFER_A, TransferType);
        BytesTransferred += TransferOutputBuffer(OUT_BUFFER_B, TransferType);
        break;      // charlie
        // fall through
    case DMA_DONEB|DMA_BIU: // This should never happen!
    case DMA_DONEB:
        // Load B
        BytesTransferred += TransferOutputBuffer(OUT_BUFFER_B, TransferType);     // charlie, B => A
        break;
    }
    //RETAILMSG(1,(TEXT("[WAVEDEV     ]BITS:%x,BytesTransferred:%d\r\n"),Bits,BytesTransferred));
       
    // If it was our interrupt, but we weren't able to transfer any bytes
    // (e.g. no full buffers ready to be emptied)
    // and all the output DMA buffers are now empty, then stop the output DMA
    BytesTotal = m_OutBytes[TransferType][OUT_BUFFER_A]+m_OutBytes[TransferType][OUT_BUFFER_B];

	RETAILMSG(FALSE,(TEXT("[WAVEDEV     ]BITS:%x,BytesTransferred:%d[%d]\n"),Bits,BytesTransferred,BytesTotal));
    if (BytesTotal==0)
    {
#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)
		StopOutputDMA();
#else
        StopOutputDMAByTransferType(TransferType);
#endif
    }
    return BytesTransferred;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       TransferInputBuffer()

Description:    Retrieves the chunk of recorded sound data and inputs
                it into an audio buffer for potential "mixing".

Returns:        Number of bytes needing to be transferred.
-------------------------------------------------------------------*/
static DWORD isInPutSecond=0;
char tempOutput[8192];
char tempInput[8192];
char tempResult[8192];
DWORD nCount=0;
int nAddCount=0;
BOOL isInPutFirst=TRUE;


ULONG HardwareContext::TransferInputBuffer(ULONG NumBuf)
{
    ULONG BytesTransferred = 0;
    PBYTE pBufferStart = NULL;
    PBYTE pBufferEnd = NULL;
    PBYTE pBufferLast;
	
    __try
    {
		pBufferStart = m_Input_pbDMA_PAGES[NumBuf];
		pBufferEnd = pBufferStart + AUDIO_DMA_IN_PAGE_SIZE;
#if defined(_USING_AEC_)
		RETAILMSG(0,(TEXT("[WAVEDEV     ]AEC Mode %d\n"),g_AECMode));
		if(g_AECMode)
		{

		if(isInPutSecond > 40)
		{
			if(isInPutFirst)
			{
				pOutQueue->Reset();
				pInQueue->Reset();
				pResultQueue->Reset();
				isInPutFirst=FALSE;
				isInPutSecond=0;
				RETAILMSG(1,(TEXT("[WAVEDEV     ]Start AEC Mode!![%d]\n"),isInPutSecond));
			}
			else
			{
				if(curInputADMAOffset != 0)
				{
					pInQueue->Write((BYTE *)(pBufferStart + curInputADMAOffset), 256 - curInputADMAOffset);
					curInputADMAOffset = 0;
				}
				else
				{
					pInQueue->Write((BYTE *)(pBufferStart), 256);
				}

				//processing aec
				DWORD nRet=0;

				if((pInQueue->ActualDataLength() >= 320)&& (pOutQueue->ActualDataLength() >= 320))
				{
					DWORD nRet  = pInQueue->Read( (BYTE *)tempInput, 320);
					DWORD nRet1 = pOutQueue->Read((BYTE *)tempOutput, 320);
				
					TC_AEC_Process(pAECHandle, (short *)(tempInput), (short *)(tempOutput), (short *)tempResult);
					pResultQueue->Write((BYTE *)(tempResult), 320);
					
					#if defined(_AUD_DUMP_)
						DWORD cByte;
						WriteFile(hFile_in, (BYTE *)(tempInput), nRet, &cByte, NULL);
						WriteFile(hFile_result, (BYTE *)(tempResult), nRet, &cByte, NULL);
						WriteFile(hFile_out, (BYTE *)(tempOutput), nRet1, &cByte, NULL);
					#endif

				}
				
				if(pResultQueue->ActualDataLength() >= 256)
				{
					pResultQueue->Read((BYTE *)(pBufferStart), 256);
				}
				else
				{
				//	memset(pBufferStart, 0x00, 256);
					RETAILMSG(0,(TEXT("[WAVEDEV     ]_(%d)(%d)(%d)\n"),pResultQueue->ActualDataLength(),pInQueue->ActualDataLength(),pOutQueue->ActualDataLength()));
				}
			}//end else
		}
		else {

			int nRemain =	pOutQueue->ActualDataLength() - 256*2 ;

			if(nRemain > 0)
			{
				DWORD nread = pOutQueue->Read( (BYTE *)tempInput, nRemain ); 
				RETAILMSG(0,(TEXT("[WAVEDEV     ]read %d(%d) Byte.. %d [%d]\n"),nread,nRemain,pOutQueue->ActualDataLength(),AUDIO_DMA_PAGE_SIZE));
			}
			else 
				RETAILMSG(0,(TEXT("[WAVEDEV     ]read 0 Byte.. %d[%d]\n"),pOutQueue->ActualDataLength(),AUDIO_DMA_PAGE_SIZE));
			
			RETAILMSG(0,(TEXT("[WAVEDEV     ]isInPutSecond [%d]\n"),isInPutSecond));
			isInPutSecond++;
			memset(pBufferStart, 0x00, 256);

			}

		}
#endif
        pBufferLast = m_InputDeviceContext.TransferBuffer(pBufferStart, pBufferEnd,NULL, TRANSFER_TYPE_PCM);
		BytesTransferred = m_InBytes[NumBuf] = pBufferLast-pBufferStart;
		
        if(NumBuf == IN_BUFFER_A)           // Input Buffer A
        {
            m_InputDMAStatus &= ~DMA_DONEA;
            m_InputDMAStatus |= DMA_STRTA;
        }
        else                                // Input Buffer B
        {
            m_InputDMAStatus &= ~DMA_DONEB;
            m_InputDMAStatus |= DMA_STRTB;
        }
    }
    __except(EXCEPTION_EXECUTE_HANDLER) 
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("[WAVEDEV     ]WAVDEV2.DLL:TransferInputBuffer() - EXCEPTION: %d"), GetExceptionCode()));
    }

    return BytesTransferred;
}


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       TransferInputBuffers()

Description:    Determines which input buffer (A or B) needs to 
                be filled with recorded sound data.  The correct 
                buffer is then populated with recorded sound data
                from the input channel.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
ULONG HardwareContext::TransferInputBuffers(DWORD dwDCSR)
{
    ULONG BytesTransferred=0;
    DWORD Bits = dwDCSR & (DMA_DONEA|DMA_DONEB|DMA_BIU);
	
    switch (Bits)
    {
    case 0:
    case DMA_BIU:
        // No done bits set- must not be my interrupt
        return 0;
    case DMA_DONEA: // This should never happen!
    case DMA_DONEA|DMA_BIU:
        // Load A
        BytesTransferred += TransferInputBuffer(IN_BUFFER_A);
        break;
    case DMA_DONEB|DMA_BIU: // This should never happen!
    case DMA_DONEB:
        // Load B
        BytesTransferred += TransferInputBuffer(IN_BUFFER_B);
        break;
    }
	
    // If it was our interrupt, but we weren't able to transfer any bytes
    // (e.g. no empty buffers ready to be filled)
    // Then stop the input DMA
    if (BytesTransferred==0)
    {
        StopInputDMA();
    }
    return BytesTransferred;
}

void HardwareContext::InterruptThread()
{
    ULONG OutputTransferred; //,InputTransferred; 
    ULONG InputTransferred;
    unsigned int k=0;
	DWORD status;

    // Fast way to access embedded pointers in wave headers in other processes.
    SetProcPermissions((DWORD)-1);

    while(TRUE)
    {
        status = WaitForSingleObject(m_hAudioInterrupt, INFINITE);

		if (status == WAIT_OBJECT_0) {
	        RETAILMSG(FALSE, (TEXT("[WAVEDEV     ]Wavedev:::DMA Interrupt\r\n")));
	        //----- 1. Grab the lock -----
	        Lock();
	        __try
	        {				
				if(tcc_dma_getstatus(pstrADMA_VirtualRegAddr, OUTPUTDMANO)) //output
				{
#if defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)
					m_TxSpdifSrcAddrForI2SSync = pstrADMA_VirtualRegAddr->TxSpCsar;
#endif
					tcc_dma_clrstatus(pstrADMA_VirtualRegAddr, OUTPUTDMANO);
					InterruptDone(m_dwSysintrOutput);

                    RETAILMSG(FALSE, (TEXT("[WAVEDEV     ]Wavedev:::DMA OUTPUT Interrupt  m_OutputDMAStatus & DMA_BIU[0x%X]\r\n"), (m_OutputDMAStatus & DMA_BIU)));

					//Error exception for VBUS setting delay
					if (pstrADMA_VirtualRegAddr->TxDaCsar >= (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE)) 
					{
						if(m_OutputDMAStatus & DMA_BIU)
						{
							RETAILMSG(FALSE, (TEXT("[WAVEDEV     ] DAI Buffer B error!!\r\n")));
							m_OutputDMAStatus &= ~DMA_STRTB;						// Buffer A just completed...
							m_OutputDMAStatus |= DMA_DONEB;
							m_OutputDMAStatus &= ~DMA_BIU;	
						}
					}
					else
					{
						if(!(m_OutputDMAStatus & DMA_BIU))
						{
							RETAILMSG(FALSE, (TEXT("[WAVEDEV     ] DAI Buffer A error!!\r\n")));
							m_OutputDMAStatus &= ~DMA_STRTA;						// Buffer B just completed...
							m_OutputDMAStatus |= DMA_DONEA;
							m_OutputDMAStatus |= DMA_BIU;
						}
					}
					
					if(m_OutputDMAStatus & DMA_BIU)
					{
						m_OutputDMAStatus &= ~DMA_STRTB;						// Buffer A just completed...
						m_OutputDMAStatus |= DMA_DONEB;
						m_OutputDMAStatus &= ~DMA_BIU;							// Buffer B is in use
					}
					else
					{
						m_OutputDMAStatus &= ~DMA_STRTA;						// Buffer B just completed...
						m_OutputDMAStatus |= DMA_DONEA;
						m_OutputDMAStatus |= DMA_BIU;							// Buffer A is in use
					}
					OutputTransferred = TransferOutputBuffers(m_OutputDMAStatus, TRANSFER_TYPE_PCM);
				}
#if defined(_SPDIF_COMMON_)
				else if(tcc_dma_getstatus(pstrADMA_VirtualRegAddr, SPDIFDMANO)) //output
				{
					tcc_dma_clrstatus(pstrADMA_VirtualRegAddr, SPDIFDMANO);
					InterruptDone(m_dwSysintrOutput);

#if !defined(I2S_SPDIF_SAME_DATA_2CH_ONLY)
					RETAILMSG(FALSE, (TEXT("[WAVEDEV     ]Wavedev:::SPDIF DMA OUTPUT Interrupt  m_SPDIFOutputDMAStatus & DMA_BIU[0x%X]\r\n"), (m_SPDIFOutputDMAStatus & DMA_BIU)));

					//Error exception for VBUS setting delay
					if (pstrADMA_VirtualRegAddr->TxSpCsar >= (g_PhysDMABufferAddr.LowPart + AUDIO_DMA_PAGE_SIZE*2 +
								AUDIO_DMA_IN_PAGE_SIZE*2 + AUDIO_DMA_PAGE_SIZE_SPIDF)) 					
					{
						if(m_SPDIFOutputDMAStatus & DMA_BIU)
						{
							RETAILMSG(FALSE, (TEXT("[WAVEDEV	 ] SPDIF Buffer B error!!\r\n")));
							m_SPDIFOutputDMAStatus &= ~DMA_STRTB;						// Buffer A just completed...
							m_SPDIFOutputDMAStatus |= DMA_DONEB;
							m_SPDIFOutputDMAStatus &= ~DMA_BIU;							// Buffer B is in use
						}
					}
					else
					{
						if(!(m_SPDIFOutputDMAStatus & DMA_BIU))
						{
							RETAILMSG(FALSE, (TEXT("[WAVEDEV	 ] SPDIF Buffer A error!!\r\n")));
							m_SPDIFOutputDMAStatus &= ~DMA_STRTA;						// Buffer B just completed...
							m_SPDIFOutputDMAStatus |= DMA_DONEA;
							m_SPDIFOutputDMAStatus |= DMA_BIU;							// Buffer A is in use
						}
					}

					if(m_SPDIFOutputDMAStatus & DMA_BIU)
					{
						m_SPDIFOutputDMAStatus &= ~DMA_STRTB;						// Buffer A just completed...
						m_SPDIFOutputDMAStatus |= DMA_DONEB;
						m_SPDIFOutputDMAStatus &= ~DMA_BIU;							// Buffer B is in use
					}
					else
					{
						m_SPDIFOutputDMAStatus &= ~DMA_STRTA;						// Buffer B just completed...
						m_SPDIFOutputDMAStatus |= DMA_DONEA;
						m_SPDIFOutputDMAStatus |= DMA_BIU;							// Buffer A is in use
					}

					OutputTransferred = TransferOutputBuffers(m_SPDIFOutputDMAStatus, TRANSFER_TYPE_SPDIF);
#endif					
				}
#endif
				else if(tcc_dma_getstatus(pstrADMA_VirtualRegAddr, INPUTDMANO)) //input
				{
					 RETAILMSG(FALSE, (TEXT("[WAVEDEV     ]Wavedev:::DMA INPUT Interrupt\r\n")));
					tcc_dma_clrstatus(pstrADMA_VirtualRegAddr, INPUTDMANO);
					InterruptDone(m_dwSysintrOutput);
					
					if(m_InputDMAStatus & DMA_BIU)
					{
						m_InputDMAStatus &= ~DMA_STRTB;                        // Buffer B just completed...
						m_InputDMAStatus |= DMA_DONEB;
						m_InputDMAStatus &= ~DMA_BIU;                          // Buffer A is in use
					}
					else
					{
						m_InputDMAStatus &= ~DMA_STRTA;                        // Buffer A just completed...
						m_InputDMAStatus |= DMA_DONEA;
						m_InputDMAStatus |= DMA_BIU;                           // Buffer B is in use
					}
					InputTransferred = TransferInputBuffers(m_InputDMAStatus);		    
				}
				else 
				{
					RETAILMSG(1,(TEXT("[WAVEDEV     ]WaveDrv::Interrupt ERROR\n")));
					RETAILMSG(FALSE,(TEXT("[WAVEDEV     ]WaveDrv::Interrupt ERROR\n")));
					InterruptDone(m_dwSysintrOutput);
				}
		
	        }
	        __except(EXCEPTION_EXECUTE_HANDLER) 
	        {
	            DEBUGMSG(ZONE_ERROR, (TEXT("[WAVEDEV     ]WAVDEV2.DLL:InterruptThread() - EXCEPTION: %d"), GetExceptionCode()));
	        }
		} else if(status == WAIT_TIMEOUT) {
			RETAILMSG(1, (TEXT("[WAVEDEV     ]- %s  WaitForSingleObject timeout !!!\r\n"), _T(__FUNCTION__)));
		} else {
			RETAILMSG(1, (TEXT("[WAVEDEV     ]- %s  WaitForSingleObject unknown error !!!\r\n"), _T(__FUNCTION__)));
		}

        //----- 10. Give up the lock ----- 
        Unlock();
    }  
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:       AudioMute()

Description:    Mutes/unmutes the specified audio channel.

Notes:          If both audio channels are MUTED, then the chip 
                is powered down to conserve battery life.  
                Alternatively, if either audio channel is unMUTED, 
                the chip is powered up.

Returns:        Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::AudioMute(DWORD channel, BOOL bMute)
{
    static DWORD dwActiveChannel = 0;
    return(TRUE);
}

void CallInterruptThread(HardwareContext *pHWContext)
{
    pHWContext->InterruptThread();
}

VOID HardwareContext::ProcessInput(VOID)
{
	ULONG InputTransferred;
	//RETAILMSG(0, (TEXT("[WAVEDEV     ]ProcessInput\r\n")));
	//----- Determine which buffer just completed the DMA transfer -----
	if(m_InputDMAStatus & DMA_BIU)
	{
		m_InputDMAStatus &= ~DMA_STRTB;                        // Buffer B just completed...
		m_InputDMAStatus |= DMA_DONEB;
		m_InputDMAStatus &= ~DMA_BIU;                          // Buffer A is in use
	}
	else
	{
		m_InputDMAStatus &= ~DMA_STRTA;                        // Buffer A just completed...
		m_InputDMAStatus |= DMA_DONEA;
		m_InputDMAStatus |= DMA_BIU;                           // Buffer B is in use
	}

	tcc_dma_clrstatus(pstrADMA_VirtualRegAddr, INPUTDMANO); 
	InputTransferred = TransferInputBuffers(m_InputDMAStatus);
}

BOOL HardwareContext::SetInputType(DWORD dwInputType)
{
	gInputType = dwInputType;
	_gCurrentDAC = 0;
	Codec_channel(m_InputDMARunning + m_OutputDMARunning);
	return TRUE;
}


