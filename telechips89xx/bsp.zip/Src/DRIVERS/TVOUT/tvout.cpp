
/****************************************************************************
 *   FileName    : tcc_tvout.cpp
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <Windows.h>
#include "bsp.h"

#include "TCC89x_Physical.h"
#include "TCC89x_Structures.h"
#include "ioctl_code.h"

#include "../../lib/soc/tvout/tcc_tvout.h"
#include "tvout.h"
#include "ioctl_pwrstr.h"

/************************************************************************************************
* Global Handle
************************************************************************************************/
#if DEBUG
DBGPARAM dpCurSettings = {
    _T("usbmsfn"),
    {
        _T("Error"), _T("Warning"), _T("Init"), _T("Function"),
        _T("Comments"), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""), 
        _T(""), _T(""), _T(""), _T("")
    },
    0x5
};


#endif

	DWORD gType;
	int   gTvoStatus;	// 1: enabled tv-out, 0: disabled tv-out

/************************************************************************************************
* Global Variable define
************************************************************************************************/
static stpwrinfo gTvoPwrInfo = {PWR_STATUS_OFF};

/************************************************************************************************
* Global Defines
************************************************************************************************/
#define LOGLEVEL DBG_ERROR|DBG_WARN|DBG_TRACE|DBG_LOG

/************************************************************************************************
* FUNCTION		: 
BOOL DllEntry(HINSTANCE   hinstDll,	   //@parm Instance pointer. 
			  DWORD       dwReason,    //@parm Reason routine is called. 
			  LPVOID      lpReserved   //@parm system parameter. 
			  )
* DESCRIPTION	:  
*
************************************************************************************************/
BOOL DllEntry(HINSTANCE   hinstDll,	   /*@parm Instance pointer. */
			  DWORD       dwReason,    /*@parm Reason routine is called. */
			  LPVOID      lpReserved   /*@parm system parameter. */
			  )
{
	if (dwReason == DLL_PROCESS_ATTACH) {
		DEBUGREGISTER(hinstDll);
		DEBUGMSG(ZONE_INIT, (TEXT("port process attach\r\n")));
		DisableThreadLibraryCalls((HMODULE) hinstDll);
	}
	
	if (dwReason == DLL_PROCESS_DETACH) {
		DEBUGMSG(ZONE_INIT, (TEXT("process detach detach\r\n")));
	}
	
	return (TRUE);
}




/************************************************************************************************
* FUNCTION		: DWORD TVO_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD TVO_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]TVO_Init.\r\n")));

	gTvoStatus = 0;

	return TRUE;
}


/************************************************************************************************
* FUNCTION		: BOOL TVO_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL TVO_Deinit( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]TVO_Deinit.\r\n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD TVO_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD TVO_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[TVOUT       ]TVO_Open.\r\n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL TVO_Close( DWORD hOpenContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL TVO_Close( DWORD hOpenContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[TVOUT       ]TVO_Close.\r\n")));
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL TVO_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL TVO_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[TVOUT       ]TVO_IOControl[%d].\r\n"), dwCode));
	DWORD *pInValue = (DWORD *)pBufIn; 
//	stReg *temp;
	switch (dwCode)
    {
		case IOCTL_PWR_CONTROL:
		{
			stpwrioctl *pCmd  = (stpwrioctl*)pBufIn;
			stpwrinfo  *pInfo = (stpwrinfo *)pBufOut;

			if (pCmd == NULL)
			{
				return FALSE;
			}

			switch(pCmd->cmd)
			{
				case PWR_CMD_OFF:
					tca_tvo_enable(FALSE);

					gTvoPwrInfo.status = PWR_STATUS_OFF;

					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gTvoPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;
				case PWR_CMD_ON:
					tca_tvo_enable(TRUE);

					gTvoPwrInfo.status = PWR_STATUS_ON;

					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gTvoPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;
				case PWR_CMD_GETSTATUS:
					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gTvoPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;

				default:
					return FALSE;	//break;
			}
		}
		break;
		
		case IOCTL_TVOUT_CONNECT_LCDC:
			gType =(DWORD)*pInValue; 
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]IOCTL_TVOUT_CONNECT_LCDC[LCDC%d].\r\n"), *pInValue));
			tca_tvo_connectlcdc((unsigned int)*pInValue);
            break;

		case IOCTL_TVOUT_TYPE:
			gType =(DWORD)*pInValue; 
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]IOCTL_TVOUT_TYPE[0x%04d].\r\n"), gType));
            break;

        case IOCTL_TVOUT_OPEN:
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]IOCTL_TVOUT_OPEN.\r\n")));
			tca_tvo_setlcd2tv(gType);
			tca_tvo_setmode(gType); // need to input type
			tca_tvo_enable(TRUE);

			gTvoPwrInfo.status = PWR_STATUS_ON;
			gTvoStatus = 1;

			{
				HANDLE hDevice= INVALID_HANDLE_VALUE;
				stpwrioctl	pwrioctl;	// for input
				pwrioctl.deviceid = DEVICE_BACKLIGHT;
				pwrioctl.cmd = PWR_CMD_OFF;

				hDevice = CreateFile(TEXT("BKL1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
				DeviceIoControl(hDevice, IOCTL_PWR_CONTROL, &pwrioctl, sizeof(stpwrioctl), NULL, NULL, NULL, NULL);				
				CloseHandle(hDevice);
			}
			
            break;

        case IOCTL_TVOUT_CLOSE:
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]IOCTL_TVOUT_CLOSE.\r\n")));

			tca_tvo_enable(FALSE);
			tca_tvo_settv2lcd();

			gTvoPwrInfo.status = PWR_STATUS_OFF;
			gTvoStatus = 0;
			
			{
				HANDLE hDevice= INVALID_HANDLE_VALUE;
				stpwrioctl	pwrioctl;	// for input
				pwrioctl.deviceid = DEVICE_BACKLIGHT;
				pwrioctl.cmd = PWR_CMD_ON;

				hDevice = CreateFile(TEXT("BKL1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
				DeviceIoControl(hDevice, IOCTL_PWR_CONTROL, &pwrioctl, sizeof(stpwrioctl), NULL, NULL, NULL, NULL);				
				CloseHandle(hDevice);
			}

            break;

		default:
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]Unknown IOCTL.\r\n")));
			break;
     }

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: void TVO_PowerUp( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void TVO_PowerUp( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]TVO_PowerUp.\r\n")));

	if(gTvoStatus)
	{
		tca_tvo_setlcd2tv(gType);
		tca_tvo_setmode(gType); // need to input type
		tca_tvo_enable(TRUE);

		gTvoPwrInfo.status = PWR_STATUS_ON;
	}
}

/************************************************************************************************
* FUNCTION		: void TVO_PowerDown( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void TVO_PowerDown( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[TVOUT       ]TVO_PowerDown.\r\n")));

	if(gTvoStatus)
	{
		tca_tvo_enable(FALSE);
		
		gTvoPwrInfo.status = PWR_STATUS_OFF;
	}

}

/************************************************************************************************
* FUNCTION		: DWORD TVO_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD TVO_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
{
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD TVO_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD TVO_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
{
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD TVO_Seek( DWORD hOpenContext, long Amount, WORD Type )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD TVO_Seek( DWORD hOpenContext, long Amount, WORD Type )
{
	return 0;
}




