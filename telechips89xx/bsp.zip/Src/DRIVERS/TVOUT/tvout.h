/****************************************************************************
 *   FileName    : TCC_TVOUT.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCC_TVOUT_H__
#define __TCC_TVOUT_H__

typedef struct _stReg{
	DWORD dwRegAdd;
	DWORD dwValue;
}stReg;

DWORD	TVO_Init(LPCTSTR pContext, LPCVOID lpvBusContext);
BOOL	TVO_Deinit( DWORD hDeviceContext );
DWORD	TVO_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode );
BOOL	TVO_Close( DWORD hOpenContext );
BOOL	TVO_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut );

void	TVO_PowerUp( DWORD hDeviceContext );
void	TVO_PowerDown( DWORD hDeviceContext );
DWORD	TVO_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count );
DWORD	TVO_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count );
DWORD	TVO_Seek( DWORD hOpenContext, long Amount, WORD Type );

#endif //__TCC_TVOUT_H__