
/****************************************************************************
 *   FileName    : Backlight.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <windows.h>
#include <types.h>
#include <notify.h>
#include <memory.h>
#include <linklist.h>
#include <nkintr.h>
#include <serdbg.h>
#include <hwcomapi.h>
#include <pegdser.h>
#include <devload.h>
#include <pm.h>

#include "bsp.h"
#include "tcc_gpio.h"
#include "ioctl_code.h"
#include "backlight.h"
#include "tcc_backlight.h"

#include "tcc_gpioexp.h"
#include "ioctl_pwrstr.h"

#define _DISP_PWDN_BUS_CTRL_

//#define _USING__GPIO_EXTEND__LCD_BL_EN_		//for HDMI_CECI

/************************************************************************************************
* Global Variable
************************************************************************************************/
static HANDLE gBKLThread;
static tSYSTEM_PARAM *gpBOOTARGS;

static stpwrinfo gLCDPwrInfo = {PWR_STATUS_ON};
static stpwrinfo gBKLPwrInfo = {PWR_STATUS_ON};


#if defined(_DISP_PWDN_BUS_CTRL_)
static unsigned int gBakDDICFG_PWDN=0;
static unsigned int gBakPWROFF_DISP=0;
volatile LCDC gBakLCDC[2];
volatile DDICACHE gBakDDICACHE;
volatile unsigned int nCount=0;

int pwr_ioctl_lcd(int onoff);

void disp_power_up(void)
{
	PGPIO	pGPIO 	= (GPIO *)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	PDDICONFIG	pDDICfg = (DDICONFIG *)tcc_allocbaseaddress((unsigned int)&HwDDI_CONFIG_BASE);
	PLCDC		pLCDC[2]	= {(LCDC *)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE),
							   (LCDC *)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE)};

	PDDICACHE	pDDICache = (DDICONFIG *)tcc_allocbaseaddress((unsigned int)&HwDDI_CACHE_BASE);

	PPMU lPMU = (PMU *)tcc_allocbaseaddress((unsigned int)&HwPMU_BASE);

	memcpy(pLCDC[0],&gBakLCDC[0],sizeof(LCDC));
	memcpy(pLCDC[1],&gBakLCDC[1],sizeof(LCDC));

	memcpy(pDDICache, &gBakDDICACHE, sizeof(DDICACHE));

	pwr_ioctl_lcd(1);
}

void disp_power_down(void)
{
	PGPIO		pGPIO 	= (GPIO *)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	PDDICONFIG	pDDICfg 	= (DDICONFIG *)tcc_allocbaseaddress((unsigned int)&HwDDI_CONFIG_BASE);
	PPMU lPMU = (PMU *)tcc_allocbaseaddress((unsigned int)&HwPMU_BASE);

	PLCDC		pLCDC[2]	= {(LCDC *)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE),
							   (LCDC *)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE)};
	
	PDDICACHE	pDDICache = (DDICONFIG *)tcc_allocbaseaddress((unsigned int)&HwDDI_CACHE_BASE);

	if ((pLCDC[0]->LCTRL & Hw0) && !(pDDICfg->PWDN & Hw2))
	{
		BITCLR(pLCDC[0]->LCTRL, Hw0);
		while (pLCDC[0]->LSTATUS & Hw30) { Sleep(1); };	// BUSY
	}

	if ((pLCDC[1]->LCTRL & Hw0) && !(pDDICfg->PWDN & Hw3))
	{
		BITCLR(pLCDC[1]->LCTRL, Hw0);
		while (pLCDC[1]->LSTATUS & Hw30) { Sleep(1); };	// BUSY
	}

	memcpy(&gBakLCDC[0],pLCDC[0],sizeof(LCDC));
	memcpy(&gBakLCDC[1],pLCDC[1],sizeof(LCDC));

	memcpy(&gBakDDICACHE, pDDICache, sizeof(DDICACHE));

	pwr_ioctl_lcd(0);
}
#endif	// _DISP_PWDN_TEST_


int pwr_ioctl_lcd(int onoff)
{
	/*
	 *	LCD_ON off (gpio expand)
	 *	LCDC on/off
	 *	LCDC power down
	 *	LCD data line
	 *
	 *	(for lcdc1-rgbif)
	 */
	 
	static int flag=1;

	HANDLE hGXP;

	PGPIO		pGPIO;
	PLCDC 		pLCDC[2];
	PDDICONFIG	pDDICfg;

	pGPIO    = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	pLCDC[0] = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE);
	pLCDC[1] = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE);
	pDDICfg  = (PDDICONFIG)tcc_allocbaseaddress((unsigned int)&HwDDI_CONFIG_BASE);


	#if (0)
	RETAILMSG(1,(TEXT("[before]\r\n")));
	RETAILMSG(1,(TEXT("LCDC0 - EN[%d]:PWDN[%d]\r\n"), pLCDC[0]->LCTRL & Hw0, (pDDICfg->PWDN & Hw2)>>2));
	RETAILMSG(1,(TEXT("LCDC1 - EN[%d]:PWDN[%d]\r\n"), pLCDC[1]->LCTRL & Hw0, (pDDICfg->PWDN & Hw3)>>3));
	#endif
	
	if (onoff)
	{	// On

		if (flag)
			return 0;

		//@ LCD_ON (gpio expand)	- on
        hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
        if( INVALID_HANDLE_VALUE!=hGXP )
        {
            DWORD dwByteReturned;

            GXPINFO GxpInfo;
            GxpInfo.uiDevice=PCA9539LOW;
            GxpInfo.uiPort=LCD;
            GxpInfo.uiState=ON;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: LCD Power On\r\n")));
            }

            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
        }
		Sleep(10);	//!!

		//@ RGB Interface
		// rgb interface
		BITSET(pGPIO->GPCFN0, 0x55555555);	//LCDC1 RGB Interface
		BITSET(pGPIO->GPCFN1, 0x55555555);
		BITSET(pGPIO->GPCFN2, 0x55555555);
		BITCSET(pGPIO->GPCFN3, (Hw16-Hw0), 0x5555);

		//@ LCDC
		// lcdc pwdn disable
		BITCLR(pDDICfg->PWDN, Hw3);	// lcdc1
		
		//@ LCD_DISP
		// high
		BITSET(pGPIO->GPCDAT, Hw28);

		// lcdc enable
		BITSET(pLCDC[1]->LCTRL, Hw0);

		flag = 1;
	}
	else
	{	// Off
		if (!flag)
			return 0;

		//@ LCD_DISP
		// low
		BITCLR(pGPIO->GPCDAT, Hw28);

		//@LCDC0
		if (!(pDDICfg->PWDN & Hw2))
		{
			// if lcdc0 enable ..
			if (pLCDC[0]->LCTRL & Hw0)
			{
			// lcdc0 disable
				BITCLR(pLCDC[0]->LCTRL, Hw0);
				while (pLCDC[0]->LSTATUS & Hw30) { Sleep(1); };	// BUSY
			}

			// lcdc0 pwdn enable
			BITSET(pDDICfg->PWDN, Hw2);	// lcdc0
		}
		
		//@ LCDC1
		if (!(pDDICfg->PWDN & Hw3))
		{
			// if lcdc0 enable ..
			if (pLCDC[1]->LCTRL & Hw0)
			{
			// lcdc0 disable
				BITCLR(pLCDC[1]->LCTRL, Hw0);
				while (pLCDC[1]->LSTATUS & Hw30) { Sleep(1); };	// BUSY
			}

			// lcdc0 pwdn enable
			BITSET(pDDICfg->PWDN, Hw3);	// lcdc0
		}

		//@ RGB Interface
		// gpio output low
	    BITCLR(pGPIO->GPCDAT, Hw28-Hw0);	// low
		BITSET(pGPIO->GPCEN , Hw28-Hw0);	// ouput
		BITCLR(pGPIO->GPCFN0, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN1, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN2, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN3, (Hw16-Hw0));

		//@ LCD_ON (gpio expand)  - off
        hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
        if( INVALID_HANDLE_VALUE!=hGXP )
        {
            DWORD dwByteReturned;

            GXPINFO GxpInfo;
            GxpInfo.uiDevice=PCA9539LOW;
            GxpInfo.uiPort=LCD;
            GxpInfo.uiState=OFF;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: LCD Power Off\r\n")));
            }

            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
        }
		Sleep(10);
		
		flag = 0;
    }

	#if (0)
	RETAILMSG(1,(TEXT("[after]\r\n")));
	RETAILMSG(1,(TEXT("LCDC0 - EN[%d]:PWDN[%d]\r\n"), pLCDC[0]->LCTRL & Hw0, (pDDICfg->PWDN & Hw2)>>2));
	RETAILMSG(1,(TEXT("LCDC1 - EN[%d]:PWDN[%d]\r\n"), pLCDC[1]->LCTRL & Hw0, (pDDICfg->PWDN & Hw3)>>3));
	#endif

	return 0;
}
/************************************************************************************************
* FUNCTION		: DWORD BKL_Init(DWORD dwContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD BKL_Init(DWORD dwContext)
{
	PTIMER vTimerAddr = (PTIMER)tcc_allocbaseaddress((unsigned int)&HwTMR_BASE);
	PGPIO vGpioAddr = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);

	RETAILMSG(1, (TEXT("[BACKLIGHT   ]+ BKL_Init()\n")));

#ifdef _USING__GPIO_EXTEND__LCD_BL_EN_
	{
		// LCD_BL_EN
		HANDLE hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
		if( INVALID_HANDLE_VALUE!=hGXP )
		{
			DWORD dwByteReturned;
			GXPINFO GxpInfo;

			GxpInfo.uiDevice=PCA9539HIGH;
			GxpInfo.uiPort=LCDBLEN;
			GxpInfo.uiState=ON;

			if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
			{
				RETAILMSG(1,(TEXT("ERROR: LCD_BL_EN Power On\r\n")));
			}

			CloseHandle(hGXP);
		}
		else
		{
			RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
		}

		// GPIO_A7 --> GPIO IN mode
		//BITCSET(vGpioAddr->GPAPD0, Hw15|Hw14, Hw14);	// Pull-Up  //PD7[15], PU7[14]
		BITCSET(vGpioAddr->GPAFN0, Hw32-Hw28, 0<<28);
		BITCLR(vGpioAddr->GPAEN,  Hw7);

		return 1;
	}
#endif

#if 1
	gpBOOTARGS=(tSYSTEM_PARAM *) tcc_allocbaseaddress(SYSTEM_PARAM_BASEADDRESS);

	if ((gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 1) || (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 2))
	{
		//LVDS
		return 1;
	}
#endif

	tcc_bkl_init((unsigned int)vTimerAddr, (unsigned int)vGpioAddr);
    RETAILMSG(1, (TEXT("[BACKLIGHT   ]- BKL_Init()\n")));

    return 1;
}

/************************************************************************************************
* FUNCTION		: BOOL WINAPI DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL WINAPI DllEntry(HANDLE hInstDll, DWORD dwReason, LPVOID lpvReserved)
{
    switch ( dwReason ) 
    {
        case DLL_PROCESS_ATTACH:
            RETAILMSG(0, (TEXT("[BACKLIGHT   ]BKL : DLL_PROCESS_ATTACH\r\n")));
            DisableThreadLibraryCalls((HMODULE) hInstDll);
        break;
    }
    return (TRUE);
}

/************************************************************************************************
* FUNCTION		: BOOL BKL_Close(DWORD Handle)
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL BKL_Close(DWORD Handle)
{
    return TRUE;
}



/************************************************************************************************
* FUNCTION		: BOOL BKL_Deinit( DWORD dwContext )
*
* DESCRIPTION	: Device deinit - devices are expected to close down.
*				  The device manager does not check the return code.
*
************************************************************************************************/
BOOL BKL_Deinit( DWORD dwContext )
{
    return TRUE;
}



/************************************************************************************************
* FUNCTION		: DWORD BKL_Open(    DWORD dwData,    DWORD dwAccess,    DWORD dwShareMode    )
*
* DESCRIPTION	: Returns handle value for the open instance.
*
************************************************************************************************/
DWORD BKL_Open(    DWORD dwData,    DWORD dwAccess,    DWORD dwShareMode    )
{
    // MUST return a non-zero value
    return 1;
}

/************************************************************************************************
* FUNCTION		: BOOL BKL_IOControl(
									DWORD Handle,
									DWORD dwIoControlCode,
									PBYTE pInBuf,
									DWORD nInBufSize,
									PBYTE pOutBuf,
									DWORD nOutBufSize,
									PDWORD pBytesReturned
									)
*
* DESCRIPTION	:  I/O Control function - responds to info, read and write control codes.
*					The read and write take a scatter/gather list in pInBuf
*
************************************************************************************************/
BOOL BKL_IOControl(
    DWORD Handle,
    DWORD dwIoControlCode,
    PBYTE pInBuf,
    DWORD nInBufSize,
    PBYTE pOutBuf,
    DWORD nOutBufSize,
    PDWORD pBytesReturned
    )
{
    int inValue, outValue;
	PTIMER vTimerAddr = (PTIMER)tcc_allocbaseaddress((unsigned int)&HwTMR_BASE);
	PGPIO vGpioAddr = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);

#if 1
	if ((gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 1) || (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 2))
	{
		//LVDS
		return TRUE;
	}
#endif

    RETAILMSG(0, (TEXT("[BACKLIGHT   ]IOControl:%x, value:%x\r\n"), dwIoControlCode, tcc_bkl_gettmrref((unsigned int)vTimerAddr)));
    switch (dwIoControlCode)
    {
		case IOCTL_PWR_CONTROL:
		{
			stpwrioctl *pCmd  = (stpwrioctl*)pInBuf;
			stpwrinfo  *pInfo = (stpwrinfo *)pOutBuf;

			stpwrinfo *pPwrInfo;

			if (pCmd == NULL)
			{
				return FALSE;
			}

			switch(pCmd->deviceid) {
			case DEVICE_LCD:
				pPwrInfo = &gLCDPwrInfo;
				break;
			case DEVICE_BACKLIGHT:
				pPwrInfo = &gBKLPwrInfo;
				break;
			default:
				return FALSE;
			}

			switch(pCmd->cmd)
			{
				case PWR_CMD_OFF:
					if (pCmd->deviceid == DEVICE_LCD)
					{
						tcc_bkl_powerdown((unsigned int)vTimerAddr,(unsigned int)vGpioAddr);
						pwr_ioctl_lcd(0);
					}
					else
					{
						tcc_bkl_powerdown((unsigned int)vTimerAddr,(unsigned int)vGpioAddr);
					}

					pPwrInfo->status = PWR_STATUS_OFF;

					if ( pOutBuf && (nOutBufSize >= sizeof(stpwrinfo)))
						memcpy(pInfo, pPwrInfo, sizeof(stpwrinfo));

					if (pBytesReturned)
						*pBytesReturned = sizeof(stpwrinfo);

					break;
				case PWR_CMD_ON:
					if (pCmd->deviceid == DEVICE_LCD)
					{
						pwr_ioctl_lcd(1);
						tcc_bkl_powerup((unsigned int)vTimerAddr,(unsigned int)vGpioAddr);
					}
					else
					{
						tcc_bkl_powerup((unsigned int)vTimerAddr,(unsigned int)vGpioAddr);
					}

					pPwrInfo->status = PWR_STATUS_ON;

					if ( pOutBuf && (nOutBufSize >= sizeof(stpwrinfo)))
						memcpy(pInfo, pPwrInfo, sizeof(stpwrinfo));

					if (pBytesReturned)
						*pBytesReturned = sizeof(stpwrinfo);
					
					break;
				case PWR_CMD_GETSTATUS:

					if ( pOutBuf && (nOutBufSize >= sizeof(stpwrinfo)))
						memcpy(pInfo, pPwrInfo, sizeof(stpwrinfo));

					if (pBytesReturned)
						*pBytesReturned = sizeof(stpwrinfo);
					
					break;

				default:
					return FALSE;	//break;
			}
		}
		break;
        case IOCTL_BLK_SETPOWER:
            if (pInBuf == 0) break;
            
			inValue =*pInBuf;
			if(inValue <= 0)
				inValue=1;

			tcc_bkl_setpowerval(inValue,(unsigned int)vTimerAddr);

			RETAILMSG(1,(TEXT("[BACKLIGHT   ]IOCTL_BLK_SETPOWER : [%d]\n"),inValue));
        break;
        case IOCTL_BLK_GETPOWER:
			if (pOutBuf == 0) break;

			outValue = tcc_bkl_getpowerval((unsigned int)vTimerAddr);
			memcpy(pOutBuf, &outValue, sizeof(int));
			*pBytesReturned = 4;
			RETAILMSG(1,(TEXT("[BACKLIGHT   ]IOCTL_BLK_GETPOWER : [%d]\n"),outValue));
        break;
    }
    return TRUE;
}


/************************************************************************************************
* FUNCTION		: DWORD BKL_Read(DWORD Handle, LPVOID pBuffer, DWORD dwNumBytes)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD BKL_Read(DWORD Handle, LPVOID pBuffer, DWORD dwNumBytes)
{
    RETAILMSG(1, (TEXT("[BACKLIGHT   ]BKL_Read\r\n")));
	return 0;
}
/************************************************************************************************
* FUNCTION		: DWORD BKL_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD BKL_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes)
{
    RETAILMSG(1, (TEXT("[BACKLIGHT   ]BKL_Write\r\n")));
	return 0;
}
/************************************************************************************************
* FUNCTION		: DWORD BKL_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD BKL_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod)
{
	return 0;
}

/************************************************************************************************
* FUNCTION		: void BKL_PowerUp(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void BKL_PowerUp(void)
{
	PTIMER vTimerAddr = (PTIMER)tcc_allocbaseaddress((unsigned int)&HwTMR_BASE);
	PGPIO vGpioAddr = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);	
    RETAILMSG(1, (TEXT("[BACKLIGHT   ]+BKL_PowerUp\r\n")));

#if 1
	if ((gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 1) || (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 2))
	{
		//LVDS
		return;
	}
#endif

#if defined(_DISP_PWDN_BUS_CTRL_)
	disp_power_up();

//    //On
//	nCount = 10000;
//	for ( ; nCount > 0 ; nCount --);		// delay
#endif	// _DISP_PWDN_TEST_

	tcc_bkl_powerup((unsigned int)vTimerAddr,(unsigned int)vGpioAddr);

	gBKLPwrInfo.status = PWR_STATUS_ON;

	return;
}

/************************************************************************************************
* FUNCTION		: void BKL_PowerDown(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void BKL_PowerDown(void)
{
	PTIMER vTimerAddr = (PTIMER)tcc_allocbaseaddress((unsigned int)&HwTMR_BASE);
	PGPIO vGpioAddr = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	RETAILMSG(1, (TEXT("[BACKLIGHT   ]+BKL_PowerDown\r\n")));
#if 1
	if ((gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 1) || (gpBOOTARGS->SYSTEM_ARGS.mLcdInfo.nLcdCfgIdx == 2))
	{
		//LVDS
		return;
	}
#endif
	
	//OFF
	tcc_bkl_powerdown((unsigned int)vTimerAddr,(unsigned int)vGpioAddr);

#if defined(_DISP_PWDN_BUS_CTRL_)
	disp_power_down();
#endif //_DISP_PWDN_TEST_

	gBKLPwrInfo.status = PWR_STATUS_OFF;

	return;
}
