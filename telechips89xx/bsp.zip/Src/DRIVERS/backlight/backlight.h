/****************************************************************************
 *   FileName    : Backlight.h
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#ifndef __TCC_BKL_H__
#define __TCC_BKL_H__

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif // __TCC_BKL_H__

