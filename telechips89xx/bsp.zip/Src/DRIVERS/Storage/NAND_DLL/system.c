/****************************************************************************
 *   FileName    : system.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include "IO_TCCXXX.h"
#include "TC_DRV.h"
#include "nand_drv.h"
#include "Disk.h"
//#include "tccresource.h"
#include "fwupdateboot.h"
#include "tcc_disk.h"
#include "tca_ckc.h"
#include "ioctl_code.h"
#include "args.h"
#include <bsp.h>


//#include "TCC79x_Args.h"

#undef ZONE_INIT
#define ZONE_INIT 1

#undef ZONE_FUNCTION
#define ZONE_FUNCTION 1

#undef ZONE_IO
#define ZONE_IO 1

#ifdef DEBUG
//
// These defines must match the ZONE_* defines
//
#define DBG_ERROR      1
#define DBG_WARNING    2
#define DBG_FUNCTION   4
#define DBG_INIT       8
#define DBG_PCMCIA     16
#define DBG_IO         32

DBGPARAM dpCurSettings = {
    TEXT("RAM Disk"), {
    TEXT("Errors"),TEXT("Warnings"),TEXT("Functions"),TEXT("Initialization"),
    TEXT("PCMCIA"),TEXT("Disk I/O"),TEXT("Misc"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined") },
    0x1
};

volatile unsigned char	sectorbuf[512];
static int						jhflag = 0;

#endif  // DEBUG

/***************************************
* STRUCTURES
*
***************************************/
typedef struct _NAND_INTERRUPT_
{
	DWORD		iIrq;
	DWORD		iSysIntr;
	HANDLE		hRequestCompleteEvent;
}NANDINTR, *PNANDINTR;

#define NAND_HIDDEN_MARGIN	2
#define NAND_SECTOR_SIZE	512

//
// Global Variables
//
static NANDINTR 	gNFCIntr;
static NANDINTR		gNANDRBIntr;
CRITICAL_SECTION v_DiskCrit;
PDISK v_DiskList;                // initialized to 0 in bss
ptSYSTEM_PARAM pSystem_Param; 

#ifdef TCC79X
extern int gDRV_GDMA_Handle_NAND;
extern sDRV_GDMA	gDRV_GDMA_NAND;
#endif
//------------------------------------------------------------------------------
//
// NAND.DLL entry
//
//------------------------------------------------------------------------------
BOOL WINAPI
DllMain(HINSTANCE DllInstance, DWORD Reason, LPVOID Reserved)
{
    switch(Reason) {
        case DLL_PROCESS_ATTACH:
            DEBUGMSG(ZONE_INIT, (TEXT("[NAND        ] DLL_PROCESS_ATTACH\r\n")));
            DEBUGREGISTER(DllInstance);
            DisableThreadLibraryCalls((HMODULE) DllInstance);
            break;
    
        case DLL_PROCESS_DETACH:
            DEBUGMSG(ZONE_INIT, (TEXT("[NAND        ] DLL_PROCESS_DETACH\r\n")));
            DeleteCriticalSection(&v_DiskCrit);
            break;
    }
    return TRUE;
}   // DllMain



/* NAND_DRV_C INCLUDE */
extern unsigned char	*gNAND_PageBuffer;
extern unsigned char	____gNAND_PageBuffer[TNFTL_MAX_SUPPORT_NAND_IO_PAGE_SIZE + TNFTL_MAX_SUPPORT_NAND_IO_SPARE_SIZE];
extern void SetPORTS(void);

int get_geometrics(int dwSectorCount,int *pdwSectorsPerHead, int *pwHeadsPerCylinder, int *pwCylinder)
{
    int     r = 0;
    int    dwHeads, dwSectors, dwCylinders, dwTemp;
 
    dwCylinders = 1023;
    dwHeads = 63;
 
 
    dwTemp = dwCylinders * dwHeads;
    dwSectors = dwSectorCount / dwTemp;
    if (dwSectorCount % dwTemp) 
    {
 
        dwSectors += 1 ;
        dwTemp = dwCylinders * dwSectors;
        dwHeads = dwSectorCount / dwTemp;
 
        if (dwSectorCount % dwTemp)
        {
            dwHeads += 1;
            dwTemp = dwHeads * dwSectors;
            dwCylinders = dwSectorCount / dwTemp;
        }
    }
 
    if ( dwCylinders == 0 || dwHeads == 0 || dwSectors == 0)
    {
        r = -1;
    }
 
 
    *pwCylinder = dwCylinders;
    *pwHeadsPerCylinder = dwHeads;
    *pdwSectorsPerHead = dwSectors;
    
    return r;
}

//------------------------------------------------------------------------------
//
// CreateDiskObject - create a DISK structure, init some fields and link it.
//
//------------------------------------------------------------------------------
PDISK
CreateDiskObject(VOID)
{
    PDISK pDisk;
    
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+CreateDiskObject\r\n")));
    
    pDisk = LocalAlloc(LPTR, sizeof(DISK));
    if (pDisk != NULL) {
        pDisk->d_ActivePath = NULL;
        InitializeCriticalSection(&(pDisk->d_DiskCardCrit));        
        EnterCriticalSection(&v_DiskCrit);
        pDisk->d_next = v_DiskList;
        v_DiskList = pDisk;
        LeaveCriticalSection(&v_DiskCrit);
    }
    
    DEBUGMSG(ZONE_FUNCTION, (TEXT("-CreateDiskObject\r\n")));
    return pDisk;
}   // CreateDiskObject



//------------------------------------------------------------------------------
//
// IsValidDisk - verify that pDisk points to something in our list
//
// Return TRUE if pDisk is valid, FALSE if not.
//
//------------------------------------------------------------------------------
BOOL
IsValidDisk(
    PDISK pDisk
    )
{
    PDISK pd;
    BOOL ret = FALSE;

    EnterCriticalSection(&v_DiskCrit);
    pd = v_DiskList;
    while (pd) {
        if (pd == pDisk) {
            ret = TRUE;
            break;
        }
        pd = pd->d_next;
    }
    LeaveCriticalSection(&v_DiskCrit);
    return ret;
}   // IsValidDisk

//------------------------------------------------------------------------------
//
// Returns context data for this Init instance
//
// Arguments:
//      dwContext - registry path for this device's active key
//
//------------------------------------------------------------------------------
DWORD
DSK_Init( DWORD dwContext)
{
    PDISK pDisk;
    LPWSTR ActivePath = (LPWSTR) dwContext;
	int debug = 1;
	int i=0;

	int cylinder, head, sector;
	//unsigned	uBCLKCTR	= HwBCLKCTR;
	
    RETAILMSG(1, (TEXT("[NAND        ]+ DRIVER INIT!\r\n")));

    if (v_DiskList == NULL) {
        InitializeCriticalSection(&v_DiskCrit);
    }

    pDisk = CreateDiskObject();
    if (pDisk == NULL) {
        //RETAILMSG(1,(TEXT("[NAND        ] LocalAlloc(PDISK) failed %d\r\n"), GetLastError()));
        return 0;
    }

    if (ActivePath) {
        //RETAILMSG(1, (TEXT("NANDDISK : ActiveKey = %s\r\n"), ActivePath));
		pDisk->d_ActivePath = LocalAlloc(LPTR, (wcslen(ActivePath) * sizeof(WCHAR)) + sizeof(WCHAR));
        if ( pDisk->d_ActivePath ) {
            wcscpy(pDisk->d_ActivePath, ActivePath);
        }
		else {
			RETAILMSG(1, (TEXT("[NAND        ] Active Path Alloc Fail\r\n")));
			return 0;
		}
        
		//RETAILMSG(1, (TEXT("NANDDISK : ActiveKey (copy) = %s (@ 0x%08X)\r\n"), pDisk->d_ActivePath, pDisk->d_ActivePath));
    }
    
	//gNAND_PageBuffer = (unsigned char *)(((unsigned int)____gNAND_PageBuffer + 8) & 0xFFFFFFF8);// nemo

	gNAND_PageBuffer = (unsigned char *)(((unsigned int)gNAND_PageBuffer + 8) & 0xFFFFFFF8);
	DEBUGMSG(ZONE_INIT, (TEXT("[NAND        ] ActiveKey = %s\r\n"), ActivePath));


	//WINCE to use DMA access
	#ifdef TCC79X
	gDRV_GDMA_Handle_NAND	= DRV_GDMA(DRV_GDMA_FUNC_OPEN, 2, IO_DMA_CH2, &gDRV_GDMA_NAND);
	DRV_GDMA(DRV_GDMA_FUNC_PARSECFG, 1, gDRV_GDMA_Handle_NAND);
	#endif
	

	#ifdef __USE_NAND_ISR__
	memset(&gNFCIntr,0,sizeof(NANDINTR));
	gNFCIntr.hRequestCompleteEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	gNFCIntr.iIrq = IRQ_NFC;

	RETAILMSG(1, (TEXT("[NAND        ]+ ISR INIT!\r\n")));

	if(!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &gNFCIntr.iIrq, sizeof(DWORD), &gNFCIntr.iSysIntr, sizeof(DWORD), NULL) )
	{
		printf("%s fail at line %d\r\n", __FUNCTION__, __LINE__);
		return 0;
	}

	if(!InterruptInitialize(gNFCIntr.iSysIntr, gNFCIntr.hRequestCompleteEvent, 0, 0) )
	{
		printf("%s fail at line %d\r\n", __FUNCTION__, __LINE__);
		return 0;
	}

	NAND_IO_SetNFC_IRQ_Handle( gNFCIntr.iIrq, gNFCIntr.iSysIntr, 
								gNFCIntr.hRequestCompleteEvent );
	#if 0		/* 010.01.07 */
	memset(&gNANDRBIntr,0,sizeof(NANDINTR));
	gNANDRBIntr.hRequestCompleteEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	gNANDRBIntr.iIrq = IRQ_EI11;

	if(!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &gNANDRBIntr.iIrq, sizeof(DWORD), &gNANDRBIntr.iSysIntr, sizeof(DWORD), NULL) )
	{
		printf("%s fail at line %d\r\n", __FUNCTION__, __LINE__);
		return 0;
	}

	if(!InterruptInitialize(gNANDRBIntr.iSysIntr, gNANDRBIntr.hRequestCompleteEvent, 0, 0) )
	{
		printf("%s fail at line %d\r\n", __FUNCTION__, __LINE__);
		return 0;
	}

	NAND_IO_SetNFC_IRQ_Handle( gNANDRBIntr.iIrq, gNANDRBIntr.iSysIntr, 
								gNANDRBIntr.hRequestCompleteEvent );
	#endif /* 0 */
	RETAILMSG(1, (TEXT("[NAND        ]- ISR INIT!\r\n")));

	#endif /* NAND_ISR */

if(debug)
{	
	if( NAND_Ioctl(DEV_INITIALIZE, NULL) != SUCCESS )
		RETAILMSG(1, (TEXT("[NAND        ] INITIALIZE FAIL\r\n")));
	else
		RETAILMSG(1, (TEXT("[NAND        ] INITIALIZE SUCCESS\r\n")));
}
	pDisk->d_DiskInfo.di_total_sectors = gNAND_DrvInfo[0].TotalDiskSector - NAND_HIDDEN_MARGIN;  // 0 if card has no CIS
    get_geometrics(pDisk->d_DiskInfo.di_total_sectors, &sector, &head, &cylinder);

    pDisk->d_DiskInfo.di_bytes_per_sect = 512;
    pDisk->d_DiskInfo.di_cylinders = cylinder;
    pDisk->d_DiskInfo.di_heads = head;
    pDisk->d_DiskInfo.di_sectors = sector;
    pDisk->d_DiskInfo.di_flags = 0;


	pSystem_Param = (ptSYSTEM_PARAM)tcc_allocbaseaddress(SYSTEM_PARAM_BASEADDRESS);
	NAND_GetSerialNumber((U8 *)&pSystem_Param->SYSTEM_ARGS.mSystemParam.NANDUUID,32);
	//NAND_GetSerialNumber(&pSystem_Param->SYSTEM_ARGS.NANDUUID,32);
	//RETAILMSG(1,(TEXT("Nand Serial Id["),pSystem_Param->SYSTEM_ARGS.NANDUUID));
	RETAILMSG(1,(TEXT("[NAND        ] Serial Id["),pSystem_Param->SYSTEM_ARGS.mSystemParam.NANDUUID));
	for(i=0; i<32; i++)
	RETAILMSG(1,(TEXT("%c"),pSystem_Param->SYSTEM_ARGS.mSystemParam.NANDUUID[i]));
	RETAILMSG(1,(TEXT("]\n")));
    //RETAILMSG(1, (TEXT("[NAND        ] DSK_Init returning 0x%x\r\n"), pDisk));
	RETAILMSG(1, (TEXT("[NAND        ]-DRIVER INIT!\r\n")));
    return (DWORD) pDisk;
}


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
BOOL
DSK_Close(
    DWORD Handle
    )
{
    PDISK pDisk = (PDISK)Handle;
    BOOL bClose = FALSE;

    RETAILMSG(1, (TEXT("[NAND        ] DSK_Close entered\r\n")));

    if (!IsValidDisk(pDisk)) {
        return FALSE;
    }

    RETAILMSG(1, (TEXT("[NAND        ] DSK_Close done\r\n")));
    return TRUE;
}   // DSK_Close


//------------------------------------------------------------------------------
//
// Device deinit - devices are expected to close down.
// The device manager does not check the return code.
//
//------------------------------------------------------------------------------
BOOL
DSK_Deinit(
    DWORD dwContext     // future: pointer to the per disk structure
    )
{
    //RETAILMSG(1, (TEXT("[NAND        ] DSK_Deinit entered\r\n")));
    RETAILMSG(1, (TEXT("[NAND        ]+ DRIVER CLOSE!\r\n")));
    DSK_Close(dwContext);
    CloseDisk((PDISK)dwContext);
    //RETAILMSG(1, (TEXT("[NAND        ] DSK_Deinit done\r\n")));
	RETAILMSG(1, (TEXT("[NAND        ]- DRIVER CLOSE!\r\n")));
    return TRUE;
}   // DSK_Deinit

 
//------------------------------------------------------------------------------
//
// Returns handle value for the open instance.
//
//------------------------------------------------------------------------------
DWORD
DSK_Open(
    DWORD dwData,
    DWORD dwAccess,
    DWORD dwShareMode
    )
{
    PDISK pDisk = (PDISK)dwData;
	RETAILMSG(0, (TEXT("[NAND        ]+ DRIVER OPEN!\r\n")));
    if (IsValidDisk(pDisk) == FALSE) {
        DEBUGMSG(ZONE_IO, (TEXT("[NAND        ] DSK_Open - Passed invalid disk handle\r\n")));
        return 0;
    }

    //RETAILMSG(1, (TEXT("[NAND        ] DSK_Open returning %d\r\n"),dwData));
	RETAILMSG(0, (TEXT("[NAND        ]- DRIVER OPEN!\r\n")));
    return dwData;
}   // DSK_Open


//------------------------------------------------------------------------------
//
// I/O Control function - responds to info, read and write control codes.
// The read and write take a scatter/gather list in pInBuf
//
//------------------------------------------------------------------------------
BOOL
DSK_IOControl(
    DWORD Handle,
    DWORD dwIoControlCode,
    PBYTE pInBuf,
    DWORD nInBufSize,
    PBYTE pOutBuf,
    DWORD nOutBufSize,
    PDWORD pBytesReturned
    )
{
    PSG_REQ pSG;
    PDISK pDisk = (PDISK) Handle;

	//This is for CE image update..
	HIDDENINFO* ptr;
	MULTIHIDDENINFO* pMultiPtr;  
	BootCRCCode*		pBootCRC;
	
	// This is for FW update..
	FirmwareInfo *pFWInfo;
	//unsigned char *pUserBuffer;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("+DSK_IOControl (%d) \r\n"), dwIoControlCode));

    if (IsValidDisk(pDisk) == FALSE) {
        SetLastError(ERROR_INVALID_HANDLE);
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (invalid disk) \r\n")));
        return FALSE;
    }

    if (OEM_CERTIFY_TRUST != PSLGetCallerTrust()) {
		DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (NO TRUST) \r\n")));
        SetLastError(ERROR_ACCESS_DENIED);
        return FALSE;
    }

    //
    // Check parameters
    //
	EnterCriticalSection(&(pDisk->d_DiskCardCrit));
    switch (dwIoControlCode) {

    case DISK_IOCTL_READ:
    case IOCTL_DISK_READ:        
    case DISK_IOCTL_WRITE:
    case IOCTL_DISK_WRITE:        
    case DISK_IOCTL_INITIALIZED:
        if (pInBuf == NULL) {
            SetLastError(ERROR_INVALID_PARAMETER);
            return FALSE;
        }
        break;

    case DISK_IOCTL_GETNAME:
    case IOCTL_DISK_GETNAME:        
        if (pOutBuf == NULL) {
            SetLastError(ERROR_INVALID_PARAMETER);
            return FALSE;
        }
        break;

    case IOCTL_DISK_GETINFO:
        if (pOutBuf == NULL || nOutBufSize != sizeof(DISK_INFO)) 
        {
            SetLastError(ERROR_INVALID_PARAMETER);
            return FALSE;
        }
        break;

    case DISK_IOCTL_GETINFO:
    case DISK_IOCTL_SETINFO:
    case IOCTL_DISK_SETINFO:
        if(pInBuf == NULL || nInBufSize != sizeof(DISK_INFO)) 
        {
            SetLastError(ERROR_INVALID_PARAMETER);
            return FALSE;
        }
        break;


    case IOCTL_DISK_DEVICE_INFO:
        if(!pInBuf || nInBufSize != sizeof(STORAGEDEVICEINFO)) {
            SetLastError(ERROR_INVALID_PARAMETER);   
            return FALSE;
        }
        break;
        
    case IOCTL_DISK_GET_SECTOR_ADDR:
        if(pInBuf == NULL || pOutBuf == NULL || nInBufSize != nOutBufSize) {
            SetLastError(ERROR_INVALID_PARAMETER);   
            return FALSE;
        }
        break;        

    case DISK_IOCTL_FORMAT_MEDIA:
    case IOCTL_DISK_FORMAT_MEDIA:
        SetLastError(ERROR_SUCCESS);
        return TRUE;
    
	case DISK_HD_WRITE:
		ptr=(HIDDENINFO*)pInBuf;
		//pUserBuffer = (unsigned char*)MapCallerPtr(ptr->DataBuffer, ptr->SectorNum*NAND_SECTOR_SIZE);
		if( NAND_HDWritePage(ptr->HiddenAddress, ptr->SectorNum, ptr->DataBuffer) < 0 ) {
				//RETAILMSG(1,"Nand_HDWritePage Error\n");
				goto DSK_Exit_FALSE;
			}
		goto DSK_Exit_TRUE;

	case DISK_HD_READ:
		ptr=(HIDDENINFO*)pOutBuf;
		//pUserBuffer = (unsigned char*)MapCallerPtr(ptr->DataBuffer, ptr->SectorNum*NAND_SECTOR_SIZE);
		if(NAND_HDReadPage(ptr->HiddenAddress, ptr->SectorNum, ptr->DataBuffer) <0) {
			//RETAILMSG(1,"NAND_HDReadPage Error\n");
			goto DSK_Exit_FALSE;
		}
		*pBytesReturned = ptr->SectorNum*NAND_SECTOR_SIZE;
		goto DSK_Exit_TRUE;

	case DISK_MULTI_HD_WRITE:
		pMultiPtr=(MULTIHIDDENINFO*)pInBuf;
		//pUserBuffer = (unsigned char*)MapCallerPtr(pMultiPtr->DataBuffer, pMultiPtr->SectorNum*NAND_SECTOR_SIZE);
		if(NAND_HDWriteSector( pMultiPtr->DriveNum, pMultiPtr->HiddenAddress, pMultiPtr->SectorNum, pMultiPtr->DataBuffer) <0) {
			//RETAILMSG(0,"Nand_MultiHDWrite Error\n");
			goto DSK_Exit_FALSE;
		}
		goto DSK_Exit_TRUE;

	case DISK_MULTI_HD_READ:
		pMultiPtr=(MULTIHIDDENINFO*)pOutBuf;
		//pUserBuffer = (unsigned char*)MapCallerPtr(pMultiPtr->DataBuffer, pMultiPtr->SectorNum*NAND_SECTOR_SIZE);
		if(NAND_HDReadSector( pMultiPtr->DriveNum, pMultiPtr->HiddenAddress, pMultiPtr->SectorNum, pMultiPtr->DataBuffer) <0) {
			//RETAILMSG(0,"NAND_MultiHDRead Error\n");
			goto DSK_Exit_FALSE;
		}
		*pBytesReturned = pMultiPtr->SectorNum*NAND_SECTOR_SIZE;
		goto DSK_Exit_TRUE;

	case DISK_FW_UPDATE:
		pFWInfo = (FirmwareInfo*)pInBuf;
		RETAILMSG(1, (TEXT("NAND FWUPDATE ROUTINE\r\n")));
#ifdef FWUG_INCLUDE		/* 08.12.22 */
		if ( FWUG_MainFunc(pFWInfo->hFile, pFWInfo->Filesize) == 0 )
			goto DSK_Exit_TRUE;
		else
#endif /* nemo */
			goto DSK_Exit_FALSE;

	 case DISK_GET_SERIALNUM:
	        *pBytesReturned = NAND_GetSerialNumber( pOutBuf, 32 );
		 
			goto DSK_Exit_TRUE;

	 case DISK_GET_MAX_SECTOR_PER_BLOCK:
		{
			DWORD dwTemp=0;
			NAND_Ioctl(DEV_GET_MAX_SECTOR_PER_BLOCK, &dwTemp);
			memcpy(pOutBuf, &dwTemp, sizeof(DWORD));
			*pBytesReturned = sizeof(DWORD);
			RETAILMSG(1,(TEXT("nand Block Size is %d \n"),dwTemp));
		}
	       goto DSK_Exit_TRUE;

	 case DISK_GET_BOOTCRCCODE:
	 	pBootCRC = (BootCRCCode*)(pInBuf);
	 	//(unsigned char*)MapCallerPtr(pMultiPtr->DataBuffer, pMultiPtr->SectorNum*NAND_SECTOR_SIZE);
	 	if(NAND_Ioctl(DEV_CHECK_CRC_NANDBOOT_IMAGE_ROM, pBootCRC) == SUCCESS)
	 		goto DSK_Exit_TRUE;
	 	else
	 		goto DSK_Exit_FALSE;
	 	
	 case DISK_SET_ALIGN_CACHE:
	 	NAND_Ioctl( DEV_SET_ALIGEN_CACHE, pInBuf );			// pInBuf =  unsigned short, ENABLE: 1, DISABLE: 0
		goto DSK_Exit_TRUE;

    default:
        SetLastError(ERROR_INVALID_PARAMETER);
        goto DSK_Exit_FALSE;
    }


    //
    // Execute dwIoControlCode
    //
    switch (dwIoControlCode) {
    case DISK_IOCTL_READ:
    case IOCTL_DISK_READ:
    case DISK_IOCTL_WRITE:
    case IOCTL_DISK_WRITE:
        pSG = (PSG_REQ)pInBuf;
        if (!(pSG && nInBufSize >= (sizeof(SG_REQ) + sizeof(SG_BUF) * (pSG->sr_num_sg - 1)))) {
            SetLastError(ERROR_INVALID_PARAMETER);
				goto DSK_Exit_FALSE;
        }

		//DEBUGMSG(ZONE_FUNCTION, (TEXT("+DoDiskIO (%d) \r\n"), dwIoControlCode));
        DoDiskIO(pDisk, dwIoControlCode, pSG);

        if (pSG->sr_status) {
            SetLastError(pSG->sr_status);
				goto DSK_Exit_TRUE;
        }

    case DISK_IOCTL_GETINFO:
    case IOCTL_DISK_GETINFO:
        	SetLastError(GetDiskInfo(pDisk, (PDISK_INFO)(dwIoControlCode == IOCTL_DISK_GETINFO ? pOutBuf : pInBuf)));
			goto DSK_Exit_TRUE;

    case DISK_IOCTL_SETINFO:
    case IOCTL_DISK_SETINFO:
        SetLastError(SetDiskInfo(pDisk, (PDISK_INFO)pInBuf));
			goto DSK_Exit_TRUE;

    case DISK_IOCTL_INITIALIZED:
			goto DSK_Exit_TRUE;

    case DISK_IOCTL_GETNAME:
    case IOCTL_DISK_GETNAME:        
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (name) \r\n")));
			LeaveCriticalSection(&(pDisk->d_DiskCardCrit));
        return GetFolderName(pDisk, (LPWSTR)pOutBuf, nOutBufSize, pBytesReturned);

    case IOCTL_DISK_DEVICE_INFO: // new ioctl for disk info
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (device info) \r\n")));
			LeaveCriticalSection(&(pDisk->d_DiskCardCrit));
        return GetDeviceInfo(pDisk, (PSTORAGEDEVICEINFO)pInBuf);

    case IOCTL_DISK_GET_SECTOR_ADDR:
    {
        LPDWORD pLogicalSectors = (LPDWORD)pInBuf;
        LPDWORD pAddresses = (LPDWORD)pOutBuf;        
        DWORD dwNumSectors = nInBufSize / sizeof(DWORD);
        DWORD i;
     
		DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (GET SECTOR ADDR+) \r\n")));

        for (i = 0; i < dwNumSectors; i++) {
            pAddresses[i] = GetSectorAddr(pDisk, pLogicalSectors[i]);
        }

		DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (GET SECTOR ADDR-) \r\n")));
        goto DSK_Exit_TRUE;
    }

    default:
        DEBUGMSG(ZONE_FUNCTION, (TEXT("-DSK_IOControl (default) \r\n")));
        SetLastError(ERROR_INVALID_PARAMETER);
        goto DSK_Exit_FALSE;
    }

DSK_Exit_TRUE:
	LeaveCriticalSection(&(pDisk->d_DiskCardCrit));
	return TRUE;

DSK_Exit_FALSE:
	LeaveCriticalSection(&(pDisk->d_DiskCardCrit));
	return FALSE;
}   // DSK_IOControl




//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
unsigned long DSK_Read(unsigned long Handle, LPVOID pBuffer, unsigned long dwNumBytes){return 0;}
DWORD DSK_Write(DWORD Handle, LPCVOID pBuffer, DWORD dwNumBytes){return 0;}
DWORD DSK_Seek(DWORD Handle, long lDistance, DWORD dwMoveMethod){return 0;}
void DSK_PowerUp(void){}
void DSK_PowerDown(void){}


