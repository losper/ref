/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
	\file 
	\brief TCC8900 specific code
 
	\defgroup CGX_DRIVER_PLATFORM TCC8900 specific code
	\{
*/
#include <windows.h>                 // For all that Windows stuff

#include "CgxDriverApi.h"					/**< CellGuide Driver API */
#include "CgCpuTCC8900.h"					/**< CPU specifics */
#include "CgCpu.h"							/**< CPU abstraction */
#include "platform.h"						/**< Platform specifics */
#include "CgReturnCodes.h"					/**< CellGuide return codes */
#include "CgxDriverOs.h"
#include "CgxDriverCore.h"
#include "tcc8900_gpio.h"
#include "tcc8900_intr.h"
#include "tcc8900_gpsb.h"
//#include "CgOsSemaphore.h"

/** Virtual base address for GPIO controller */
U32 gCpuGpioBaseVA;

/** Virtual base address for Interrupt controller */
//U32 gCpuIntBaseVA  = CG_DRIVER_INT_BASE_VA;

/** Virtual base address for clock/reset controller */
//U32 gCpuResetBaseVA  = CG_DRIVER_RESET_BASE_VA;

/** Native byte order for this CPU */
const TCgByteOrder CGX_DRIVER_NATIVE_BYTE_ORDER = ECG_BYTE_ORDER_1234;	// TCC8900 is little endian

//const TCHAR * CGX_DRIVE_DMA_INT_SHARED_LIBRARY_NAME	= _T("tcc_giisr.dll");
//const TCHAR * CGX_DRIVER_DMA_INT_SHARED_HANDLER_NAME = _T("ISRHandler");
//const GIISR_INFO	*	pCGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO = &CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO;

/** Virtual address for NON-EXISTENT 5500 IP **/
const U32 CGX5500_BASE_ADDR_VA = 0;

/** Semaphore for synchronizing TBD **/
HANDLE gGpsSem;

/**
    Return the interrupt code for the GPS device interrupt.
    In case where the interrupt low level handling is done by BSP, this function should return '0',
	meaning the interrupt integration is done by other OS means (a named event on Microsoft windows CE)
	\note see #CGX_DRIVER_GPS_INT_CODE
*/
U32 CgxDriverGpsInterruptCode(void)
{
	return 0;
}


/**
	0 means no IRQ code

    \return IRQ # of GPS IP
*/
U32 CgxDriverGpsIrqCode(void)
{
	return IRQ1_GPS2 + 32;	// B group of IRQ is offset by 32... not really nice coding...
}



/**
    the GPS interrupt setup is done by the BSP
*/
TCgReturnCode CgxDriverGpsInterruptPrepare(void)
{
	// the interrupt preparation is handled by BSP
	return ECgOk;
}






extern S32 CgxDriverSnapLengthExtraBytes;




/**
    Reset the core and timers and initialize GPIO (direction and special function)
*/
TCgReturnCode CgxDriverInit(void *pDriver)
{
	return ECgOk;
}






/**
    'close' the GPS interrupt by clearing the pending bit and re-enabling it	
*/
TCgReturnCode  CGxDriverGpsInterruptDone(U32 aIntCode)
{
	DBG_FUNC_NAME("CGxDriverGpsInterruptDone")

 	TCgReturnCode rc = ECgOk;

	DBGMSG1("Clearing intr %d", aIntCode)
	rc = CgCpuIntrDone(aIntCode);

	// TODO - see if we need to clear a register
	
	return rc;
}



/**
    'close' the DMA_DONE interrupt by clearing the pending bit and re-enabling it	
*/
TCgReturnCode  CGxDriverDataReadyInterruptDone(U32 aIntCode)
{	
	//CgCpuDRMaskOn();
	return CgCpuIntrDone(aIntCode);
}

TCgReturnCode CgCpuGpioIntCode(unsigned long aPin, unsigned long *aCode);

TCgReturnCode CgxDriverResetPrepare(void)
{
	return CgCpuGpioMode(CGX5000_RESET, ECG_CPU_GPIO_OUTPUT);
}

TCgReturnCode CgxDriverDataReadyPrepare(void)
{
	// Reinstate CGX5000_SPI_CS as an SPI function
	gpiod->GPFN1 &= ~0xf0000000;			//(15 == CGX5000_SPI_CS)
	gpiod->GPFN1 |=  0x20000000;

	return CgCpuGpioMode(CGX5000_DR, ECG_CPU_GPIO_FALLING_INT);
}


TCgReturnCode CgxDriverInterruptPrepare(void)
{
	TCgReturnCode rc = ECgOk;

	return rc;
}

TCgReturnCode CgxDriverSpiPrepare(void)
{
	TCgReturnCode rc = ECgOk;
	// set up the selected SPI channel to work with CGX5900 
	rc = CgCpuGpioMode(CGX5000_SPI_CS, ECG_CPU_GPIO_OUTPUT); 
	if (OK(rc)) rc = CgCpuSpiSetup(SPI_CHANNEL, SPI_PRESCALE, ECG_CPU_SPI_INIT);
	if (OK(rc)) rc = CgCpuDmaStop(CG_DRIVER_DMA_CHANNEL_READ);
	if (OK(rc)) rc = CgCpuDmaStop(CG_DRIVER_DMA_CHANNEL_WRITE);

	return rc;
}

U32 CgxDriverDataReadyIrqCode(void)
{
	//return IRQ1_GPSB + 32;
	unsigned long code;
	CgCpuGpioIntCode(CGX5000_DR, &code);
	return code;
}

unsigned long CgxDriverDataReadyInterruptCode(void)
{
	return 0;
}

unsigned long CgxDriverGeneralInterruptCode(void)
{
	return 0;
}

TCgReturnCode CgxDriverWriteData(unsigned char *aSourceVirtualAddress, unsigned long aSourcePhysicalAddress, unsigned long aLengthBytes)
{
	DBG_FUNC_NAME("CgxDriverWriteData")
	TCgReturnCode rc = ECgOk;
	int ret = 0;

	U32 * pData = (U32*)aSourceVirtualAddress;

	#if WRITE_MODE==CG_CPU_SPI_MODE_DMA
	if(aLengthBytes <= 8)
	{
		// TODO : Writing a register is still done in Polling. Need to change to DMA, if possible
		U32 i;
		CgCpuSpiSetup(SPI_CHANNEL, SPI_PRESCALE, ECG_CPU_SPI_OUTPUT_POLLING);

		for(i = 0; i < aLengthBytes; i++) {
			CgCpuSpiTxFinishWait(SPI_CHANNEL);
			CgCpuSpiWriteByte(SPI_CHANNEL, aSourceVirtualAddress[i]);
		}
	}
	else
	{	// Do nothing - we don't write anything that isn't a register to the SPI

	rc = ECgBadArgument;
	}

	#elif WRITE_MODE==CG_CPU_SPI_MODE_MANUAL
		U32 i;
		CgCpuSpiSetup(SPI_CHANNEL, SPI_PRESCALE, ECG_CPU_SPI_OUTPUT_POLLING);

		for(i = 0; i < aLengthBytes; i++) {
			CgCpuSpiTxFinishWait(SPI_CHANNEL);
			CgCpuSpiWriteByte(SPI_CHANNEL, aSourceVirtualAddress[i]);
		}
	#endif

	//DBGMSG3("VA : 0x%08x, PA : 0x%08x, length : %d, ", aSourceVirtualAddress, aSourcePhysicalAddress, aLengthBytes )
	//DBGMSG2("HDR = 0x%x, DATA = 0x%x", *pData, *(pData+1))

	return rc;
}

TCgReturnCode CgxDriverGpioCode(int aControlLine, int *aGpioCode)
{
	*aGpioCode = 0;
	return ECgNotSupported;
}

TCgReturnCode CgxDriverReadWait(void)
{
	TCgReturnCode rc = ECgOk;
	return rc;
}

TCgReturnCode CgxDriverReadData(unsigned char *aTargetVirtualAddress, unsigned long aTargetPhysicalAddress, unsigned long aLengthBytes)
{
	TCgReturnCode rc = ECgOk;

	#if READ_MODE==CG_CPU_SPI_MODE_DMA
	if(aLengthBytes <= 4)
	{	
		// TODO : Reading a register is still done in Polling. Need to change to DMA, if possible
		unsigned long i;
		CgCpuSpiSetup(SPI_CHANNEL, SPI_PRESCALE, ECG_CPU_SPI_INPUT_POLLING);
		for(i = 0; i < aLengthBytes; i++) {
			CgCpuSpiWriteByte(SPI_CHANNEL, 0); //dummy transmit
			CgCpuSpiRxFinishWait(SPI_CHANNEL);
			CgCpuSpiReadByte(SPI_CHANNEL, (volatile unsigned char *)(aTargetVirtualAddress + i));
		}
	}
	else
	{	
		// Buffer data (not register data) is written in DMA mode
		if (OK(rc)) rc = CgCpuDmaStop(CG_DRIVER_DMA_CHANNEL_READ);
		if (OK(rc)) rc = CgCpuDmaStop(CG_DRIVER_DMA_CHANNEL_WRITE);

		if (OK(rc)) rc = CgCpuSpiSetup(SPI_CHANNEL, SPI_PRESCALE, ECG_CPU_SPI_INPUT_DMA);
		if (OK(rc)) rc = CgCpuDmaSetupFromDevice(aTargetPhysicalAddress, aLengthBytes, SPI_PRESCALE, CG_DRIVER_DMA_CHANNEL_READ, CG_DRIVER_DMA_CHANNEL_WRITE, SPI_CHANNEL);
		if (OK(rc)) rc = CgCpuDmaStart(CG_DRIVER_DMA_CHANNEL_READ);
		if (OK(rc)) rc = CgCpuDmaStart(CG_DRIVER_DMA_CHANNEL_WRITE);
		if (OK(rc)) rc = CgCpuDmaWaitFinish(CG_DRIVER_DMA_CHANNEL_READ);
	}
	#elif READ_MODE==CG_CPU_SPI_MODE_MANUAL
		unsigned long i;
		CgCpuSpiSetup(SPI_CHANNEL, SPI_PRESCALE, ECG_CPU_SPI_INPUT_POLLING);
		for(i = 0; i < aLengthBytes; i++) {
			CgCpuSpiWriteByte(SPI_CHANNEL, 0); //dummy transmit
			CgCpuSpiRxFinishWait(SPI_CHANNEL);
			CgCpuSpiReadByte(SPI_CHANNEL, (volatile unsigned char *)(aTargetVirtualAddress + i));
		}
	#endif

	return rc;

}

TCgReturnCode CgxDriverClearData(unsigned char *aTargetVirtualAddress, unsigned long aTargetPhysicalAddress, unsigned long aLengthBytes)
{
	return CgxDriverReadData(aTargetVirtualAddress, aTargetPhysicalAddress, aLengthBytes);
}

TCgReturnCode CgxDriverIsDataReady(void)
{
	TCgReturnCode rc = ECgOk;
	unsigned int val = 0;
	CgCpuGpioMode(CGX5000_DR, ECG_CPU_GPIO_INPUT);
	CgCpuGpioGet(CGX5000_DR, &val);

	return (val == 0) ? ECgOk : ECgGeneralFailure;
}

TCgReturnCode CgxDriverReadDataTail(unsigned char *aTargetVirtualAddress, unsigned long aTargetPhysicalAddress, unsigned long aLengthBytes)
{
	TCgReturnCode rc = ECgOk;

	return rc;
}

//extern TCgReturnCode CgxDriverTransferEndWaitevent(	void *pDriver, U32 aTimeoutMS);

TCgReturnCode CgxDriverIdle(void *pDriver)
{
	TCgReturnCode rc = ECgOk;

	RETAILMSG(0,(TEXT("\n\r[CgxDriverIdle] !!!!")));

	//CgxDriverTransferEndWaitevent(pDriver,5000);

	//RETAILMSG(0,(TEXT("\n\r[CgxDriverIdle] DR end!!!")));

	// 1. set pins to input mode
	CgCpuGpioMode(CGX5000_DR, ECG_CPU_GPIO_INPUT);
	CgCpuGpioMode(CGX5000_RESET, ECG_CPU_GPIO_INPUT);
	CgCpuGpioMode(CGX5000_SPI_CS, ECG_CPU_GPIO_INPUT);
	#ifdef CGX5000_POWER_EN 
		CgCpuGpioMode(CGX5000_POWER_EN, ECG_CPU_GPIO_INPUT);
	#endif
	#ifdef CGX5000_TCXO_EN
		CgCpuGpioMode(CGX5000_TCXO_EN, ECG_CPU_GPIO_INPUT);
	#endif
	#ifdef CGX5000_INT 	
		CgCpuGpioMode(CGX5000_INT, ECG_CPU_GPIO_INPUT);
	#endif

	// 2. turn off the gpsb block & clock
	CgCpuSpiSetup(SPI_CHANNEL, SPI_PRESCALE, ECG_CPU_SPI_SLEEP);

	return rc;
}

TCgReturnCode CgxDriverWakeup(void)
{
	TCgReturnCode rc = ECgOk;

#ifdef CGX5000_POWER_EN 
#ifdef CGX5000_POWER_EN_RESET
	if (OK(rc)) rc = CgCpuGpioReset(CGX5000_POWER_EN);	
#else
	if (OK(rc)) rc = CgCpuGpioSet(CGX5000_POWER_EN);	
#endif
#endif

#ifdef CGX5000_TCXO_EN
	if (OK(rc)) rc = CgCpuGpioReset(CGX5000_TCXO_EN);
#endif

	if (OK(rc)) rc = CgxDriverInterruptPrepare();
	if (OK(rc)) rc = CgxDriverSpiPrepare();
	if (OK(rc)) rc = CgxDriverResetPrepare();
	if (OK(rc)) rc = CgxDriverHardwareReset(0);

	return rc;
}

/**
the DMA done interrupt setup is done by the BSP
*/
TCgReturnCode CgxDriverDataReadyInterruptPrepare()
{
	// Init shared interrupt info
	memset(&CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO, 0, sizeof(GIISR_INFO));
	CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO.CheckPort	= TRUE;			// irq happen then chk port <-> false means don't chk port == no shared IRQ
	CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO.PortIsIO	= FALSE;			// memory mapped - not real port (TRUE only used X86)
	CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO.PortSize	= sizeof(DWORD);	// size of HwUART_CHST
	CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO.UseMaskReg = FALSE;
	CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO.MaskAddr	= 0;

	CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO.PortAddr	= (DWORD)&(gpsbcfg->CIRQST);
	CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO.Mask		= (0x1<<5);			//GPSB DMA IRQ status register for channel 2

	return ECgOk;
}
/** 
	\} 
*/ 
