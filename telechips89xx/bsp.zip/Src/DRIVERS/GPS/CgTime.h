/* ???*/
/* Build: 3477 */
/**
 * \file CgTime.h
 * \brief Time related functions

 * API functions dealing with time
*/
#ifndef CG_TIME_H
#define CG_TIME_H

#ifdef	__cplusplus
extern "C" {
#endif /*__cplusplus*/

#include "CgTypes.h"
#include "CgReturnCodes.h"
//#include "CgMath.h"

#define MIN2SEC(n)		(n * 60)
#define MIN2MSEC(n)		(n * 60000)
#define MIN2USEC(n)		(n * 60000000)
#define MIN2NSEC(n)		(n * 60000000000)
	
#define SEC2MSEC(n)		(n * 1000)
#define SEC2USEC(n)		(n * 1000000)
#define SEC2NSEC(n)		(n * 1000000000)

#define USEC2SEC(n)		(n / 1000000)
#define USEC2MSEC(n)	(n / 1000)
#define USEC2NSEC(n)	(n * 1000)

#define NSEC2SEC(n)		(n / 1000000000)
#define NSEC2MSEC(n)	(n / 1000000)
#define NSEC2USEC(n)	(n / 1000)

#define TC_TICK_BASE    (5)
#define USEC2TICK(n)	((n / 1000) / TC_TICK_BASE)
/**
 GPS time structure
*/

#define NON_ALIGNED_SIZE_OF_AGPS_TIME (10)

typedef struct SCgAgpsTime
{
	U16   weekNo; 		/*< week number (from beginning of current week cycle) */
	//TODO noam alignment
	U32   second;      	/*<  seconds (from beginning of current week no) */
	U32   secondFrac;  	/*<  seconds fraction (from beginning of current second) units: 1ns */
} TCgAgpsTime;

/**
 System time structure
*/
typedef struct SCgTime
{
        U16 year;		/*< year */
        U16 month;		/*< month (0-11) */
        U16 day;		/*< day (0-31) */
        U16 hour;		/*< hour (0-23) */
        U16 minute;		/*< minute (0-59) */
        U16 second;		/*< second (0-59) */
        U32 microsec;	/*< microseconds */
} TCgTime;

typedef struct SCgUtcGpsDiffTime
{
	U16		weekNo;		// last update
	S8		diffSec;	// value of the delta time (Second)
} TCgUtcGpsTimeDiff;


#define CGTIME_SHOW_TIME		0x00000001
#define CGTIME_SHOW_DATE		0x00000002
#define CGTIME_SHOW_HI_RES_TIME	0x00000004


/**
 \ingroup High_Resolution_counter
 High Resolution Counter time marker
*/
typedef SINT64		TCgTimeHighResCounter;

/**
 \ingroup High_Resolution_counter
 High Resolution Counter frequency
*/
typedef	SINT64		TCgTimeHighResFrequency;

/**
 \ingroup time_marker
 Time marker
*/
typedef U32 TCgTimeMarker;
#define CGTIME_MARKER_MAX_VALUE		0xFFFFFFFF
#define MAX_FRAC_SEC 1000000000

/***READ FUNCTIONS***/
unsigned int AgpsTimeReadFromFileEx(
    void *fd,
    TCgAgpsTime *aTime,
    const void *pData);

unsigned int AgpsTimeReadFromFile(
    void *fd,
    TCgAgpsTime *aTime);

/**
 * Sets TCgAgpsTime structure from buffer that contains the time in AGPS format.
 * @param[in] buf the buffer that contains the data
 * @param[out] aTime the structure to set
 * @return Returns one of TCgReturnCode return codes
 */
unsigned int AgpsTimeReadFromBuf(
    const char* buf,
    TCgAgpsTime *aTime);

/***WRITE FUNCTIONS***/
unsigned int AgpsTimeWriteToFileEx(
    void *fd,
    const TCgAgpsTime *aTime,
    const void *pData);

unsigned int AgpsTimeWriteToFile(
    void *fd,
    const TCgAgpsTime *aTime);

/**
 * Serializes TCgAgpsTime to buffer
 * @param[in,out] buf pointer to allocated buffer in which the data is serialized
 * @param[in] aTime the time to serialize
 * @return Returns one of TCgReturnCode return codes
 */
unsigned int AgpsTimeWriteToBuf(
    char* buf,
    const TCgAgpsTime* aTime);

/**
\defgroup time_textformatting Time text formatting
Functions to format time into human readable text
*/

/**
 \ingroup time_textformatting
 Simple formatting of GPS time

 @param[in] pTime Pointer to GPS time structure
 @param[out] pText Pointer to preallocated character buffer to hold formatted data
 @return ECgOk on success
*/
TCgReturnCode CgTimeFormatGpsTime(
    const TCgAgpsTime * pTime,
    char *pText,
    unsigned int aBufSize);

/**
 \ingroup time_textformatting
 Advanced formatting of GPS time

 @param[in] pTime Pointer to GPS time structure
 @param[in] aFlags Formatting flags
 @param[in] aMaxLen Maximum length of formatted string
 @param[out] pBuf Pointer to preallocated character buffer to hold formatted data
 @return ECgOk on success
*/
TCgReturnCode CgTimeFormat(
    const TCgAgpsTime *pTime,
    U32 aFlags,
    char *pBuf,
    U32 aMaxLen);

/**
 \ingroup time_textformatting
 Advanced formatting of GPS time period

 @param[in] aDiff The time period, in seconds
 @param[in] aMaxLen Maximum length of formatted string
 @param[out] pBuf Pointer to preallocated character buffer to hold formatted data
 @return ECgOk on success
*/
TCgReturnCode CgTimeFormatPeriod(
    DOUBLE aDiff,
    char *pBuf,
    U32 aMaxLen);

/**
\defgroup time_manipulation Time manipulation
Functions to manipulate time
*/

/**
 \ingroup time_manipulation
 Increment GPS time

 @param[out] pTime Pointer to GPS time structure
 @param[in] pDeltaTime delta to add, in GPS time format
 @return ECgOk on success
*/
TCgReturnCode CgTimeIncrement(
    TCgAgpsTime *pTime,
    const TCgAgpsTime *pDeltaTime);

/**
 \ingroup time_manipulation
 Set GPS time from weeknumber and seconds

 @param[out] pTime Pointer to GPS time structure
 @param[in] aWeekNum Week number
 @param[in] aSecond seconds of week
 @param[in] aNanoSec nano seconds of week
 @return ECgOk on success
*/
TCgReturnCode CgTimeSet(
    TCgAgpsTime *pTime,
    U32 aWeekNum,
    U32 aSecond,
    U32 aNanoSec);

/**
 \ingroup time_manipulation
 Clear the GPS time structure to zero (epoc)

 @param[out] pGpsTime Pointer to GPS time structure
 @return ECgOk on success
*/
TCgReturnCode CgTimeZERO(
    TCgAgpsTime *pGpsTime);





/**
\defgroup time_conversion Time conversion
*/

/**
 \ingroup time_conversion
 Convert sysetm time to GPS time

 @param[in] aTime Pointer to ystem time
 @param[out] pGpsTime Pointer to GPS time structure
 @return ECgOk on success
*/
TCgReturnCode CgTimeSystemToGps(
    const TCgTime *aTime,
    TCgAgpsTime *pGpsTime);

/**
 \ingroup time_conversion
 Convert GPS time to system time

 @param[in] pGpsTime Pointer to GPS time structure
 @param[out] aTime Pointer to ystem time
 @return ECgOk on success
*/
TCgReturnCode CgTimeGpsToSystem(
    const TCgAgpsTime *pGpsTime,
    TCgTime *aTime);

/**
 \ingroup time_conversion
 Convert time, in seconds, to GPS valid time

 @param[in] aSeconds Time in seconds
 @param[out] aTime Pointer to GPS time structure
 @return ECgOk on success
*/
TCgReturnCode CgTimeSecondsToGPS(
    U32 aSeconds,
    TCgAgpsTime *aTime);




/**
 Calculate the difference between 2 times

 @param[in] pGpsTime1 Pointer to 1st GPS time structure
 @param[in] pGpsTime2 Pointer to 2nd GPS time structure
 @param[in] pDiff Pointer to result
 @return ECgOk on success
*/
TCgReturnCode CgTimeDiff(
    const TCgAgpsTime *pGpsTime1,
    const TCgAgpsTime *pGpsTime2,
    FLOAT *pDiff);

/**
 Calculate the difference between 2 times

 @param[in] pGpsTime1 Pointer to 1st GPS time structure
 @param[in] pGpsTime2 Pointer to 2nd GPS time structure
 @param[in] pDiff Pointer to result
 @return ECgOk on success
*/
TCgReturnCode CgTimeDiffMS(
    const TCgAgpsTime *pGpsTime1,
    const TCgAgpsTime *pGpsTime2,
    S32 *pDiff);

/**
 Calculate the difference between 2 times (1st - 2nd)

 @param[in] pGpsTime1 Pointer to 1st GPS time structure 
 @param[in] pGpsTime2 Pointer to 2nd GPS time structure
 @param[in] pDiff Pointer to result
 @return ECgOk on success
*/
TCgReturnCode CgTimeDiffSec(
    const TCgAgpsTime *pGpsTime1,
    const TCgAgpsTime *pGpsTime2,
    S32 *pDiff);

/**
 Calculate the difference between 2 times

 @param[in] pGpsTime1 Pointer to 1st GPS time structure
 @param[in] pGpsTime2 Pointer to 2nd GPS time structure
 @param[in] pDiff Pointer to result
 @return ECgOk on success
*/
TCgReturnCode CgTimeDiffDay(
    const TCgAgpsTime *pGpsTime1,
    const TCgAgpsTime *pGpsTime2,
    S32 *pDiff);


/**
 Verify GPS structure is Zero

 @param[in] pGpsTime Pointer to GPS time structure
 @param[out] isZERO Pointer to boolean result
 @return ECgOk on success
*/
TCgReturnCode CgTimeIsZERO(
    const TCgAgpsTime *pGpsTime,
    BOOL *isZERO );

/**
\defgroup High_Resolution_counter High Resolution Counter
*/
/**
 \ingroup High_Resolution_counter
 Retrieve board high performance counter, i.e., cpu/board crystal ticks
 
 @param[out] 	pCounter 	New counter
   
	 
 @return CG return codes
	   
		 
 @retval ECgOk on success
*/
TCgReturnCode CgTimeGetHighResCounter(
							  TCgTimeHighResCounter* pCounter);


/**
 \ingroup High_Resolution_counter
 get the High Resolution counter frequency, in Hz

 @param[out] 	pFrequency 		High Resolution counter frequency [Hz]

 @return CG return codes

 @retval ECgOk on success
*/
TCgReturnCode CgTimeHighResFrequencyGet(
    TCgTimeHighResFrequency* pFrequency );

/**
 \ingroup High_Resolution_counter
 Set the High Resolution counter frequency, in Hz, according to tcxo counter

 @param[out] 	pFrequency 		High Resolution counter frequency [Hz]

 @return CG return codes

 @retval ECgOk on success
*/
TCgReturnCode CgTimeHighResFrequencySet(TCgTimeHighResFrequency freq);


/**
\defgroup time_marker Time Marker
*/


/**
 \ingroup time_marker
 Retreive system time marker, i.e., tick counter

 @param[out] 	pClockMarker 	New time marker


 @return CG return codes


 @retval ECgOk on success
*/
TCgReturnCode CgTimeGetMarker(
    TCgTimeMarker* pClockMarker);

/**
 \ingroup time_marker
 get the time marker age, in miliseconds

 @param[in] 	pClockMarker 	Time marker
 @param[out] 	aTimeMs 		The age of the marker, in miliseconds

 @return CG return codes

 @retval ECgOk on success
*/
TCgReturnCode CgTimeGetMarkerAge(
    const TCgTimeMarker* pClockMarker,
    U32 *aTimeMs);






/**
 Pause running thread for specific time, in microseconds

 @param[in] aTimeUs Time in microseconds to sleep
 @return ECgOk on success
*/
TCgReturnCode CgTimeSleep(
    U32 aTimeUs);

#define CgTimeSleepMs(period)  CgTimeSleep(1000*period)


/**
 Set current system time, from GPS format

 @param[in] aGpsTime Pointer to GPS time structure
 @return ECgOk on success
*/
TCgReturnCode CgTimeSystemSet(
    const TCgAgpsTime *aGpsTime, BOOL aUpdatePrevBias);

/**
 Update system time to match GPS time (set local system time)

 @return ECgOk on success
*/
TCgReturnCode CgTimeSystemUpdate(void);

/**
 Get current system time, in GPS format

 @param[out] aGpsTime Pointer to GPS time structure
 @return ECgOk on success
*/
TCgReturnCode CgTimeSystemGet(
    TCgAgpsTime *aGpsTime);

/**
 Adjust system clock by microseconds

 @param[in] aTimeUs The time delta in microseconds

 @return ECgOk on success
*/
TCgReturnCode CgTimeAdjust(
    S32 aTimeUs);


/**
 Increment GPs time

 @param[in] aTimeUs The time delta in microseconds

 @return ECgOk on success
*/
TCgReturnCode CgTimeAdd(
    TCgAgpsTime *pTime,
    DOUBLE aDeltaTime);


/**
 Increment GPs time

 @param[in] aTimeUs The time delta in microseconds

 @return ECgOk on success
*/
TCgReturnCode CgTimeAddMs(
    TCgAgpsTime *pTime,
    S32 aDeltaTimeMs);


/**
 Increment GPs time

 @param[in] aTimeUs The time delta in seconds

 @return ECgOk on success
*/

TCgReturnCode CgTimeAddSec(
    TCgAgpsTime *pTime,
    S32 aDeltaTimeSec);

/**
 Increment GPs time

 @param[in] aTimeUs The time delta in seconds

 @return ECgOk on success
*/

TCgReturnCode CgTimeAddDay(
    TCgAgpsTime *pTime,
    S32 aDeltaTimeDay);
/**
 Convert GPs time to seconds

 @param[in] pTime the time in gps format

  @param[out] aTimeInSeconds The time in seconds

 @return ECgOk on success
*/


TCgReturnCode CgTimeGpsTimeToSeconds(
    TCgAgpsTime *pTime,
    U32 *aTimeInSeconds);

/**
 Get the Clock bias value

 @param[in] [out] FLOAT  clock bias

 @return ECgOk on success
*/

TCgReturnCode CgTimeClockBiasGet(DOUBLE *aBias);
/**
 Set the Clock bias value

 @param[in] [out] FLOAT  clock bias

 @return ECgOk on success
*/

TCgReturnCode CgTimeClockBiasSet(DOUBLE *aBias);
/**
 Set the Clock previous bias value

 @return ECgOk on success
*/

TCgReturnCode CgTimeClockRestorePreviousBias(void);
/**
 Set the Clock bias value

 @param[in] [out] FLOAT  clock bias

 @return ECgOk on success
*/

TCgReturnCode CgTimeGpsParse(TCgAgpsTime *pTime, const char* aTimeStr);

TCgReturnCode CgTimeSystemParse(TCgAgpsTime *pTime, const char* aTimeStr);

/**
 * Converts GPS time to millisecond
 * param[in]	aGpsTime	apTime	Pointer to the GPS time
 * param[out]	pDiff		Pointer to result
 * @return In case of failure returns ECgBadArgument
 */
TCgReturnCode CgTimeOffsetGetMS(const TCgAgpsTime *pGpsTime, U32 *pDiff);

/**
 * Converts GPS time to microsecond
 * param[in]	aGpsTime	Pointer to the GPS time
 * param[out]	pDiff		Pointer to result
 * @return In case of failure returns ECgBadArgument
 */
TCgReturnCode CgTimeOffsetGetUS(const TCgAgpsTime *pGpsTime, U32 *pDiff);

/**
 * Converts millisecond to GPS time 
 * param[in]	pDiff		Pointer to time in millisecond
 * param[out]	aGpsTime	Pointer to the GPS time
 * @return In case of failure returns ECgBadArgument
 */
TCgReturnCode CgTimeOffsetSetMS(U32 pDiff, TCgAgpsTime *pGpsTime);

/**
 * Converts microsecond to GPS time 
 * param[in]	pDiff		Pointer to time in microsecond
 * param[out]	aGpsTime	Pointer to the GPS time
 * @return In case of failure returns ECgBadArgument
 */
TCgReturnCode CgTimeOffsetSetUS(U32 pDiff, TCgAgpsTime *pGpsTime);

/**
 * Decrement GPS time
 * param[in]	pTime		Pointer to GPS time to decrement from
 * param[in]	pDeltaTime	Pointer to GPS time to decrement
 * @return In case of failure returns ECgBadArgument
 */
TCgReturnCode CgTimeDecrement(TCgAgpsTime *pTime, const TCgAgpsTime *pDeltaTime);

/**
Get current system time

\param[out] aTime Pointer to time structure
\return ECgOk on success
*/
TCgReturnCode CgTimeSystemLocalGet(TCgTime *aTime);

/**
Set current system time

\param[in] aTime Pointer to time structure
\return ECgOk on success
*/
TCgReturnCode CgTimeSystemLocalSet(const TCgTime aTime);

/**
Check system time validation

\param[in] aTime Pointer to time structure
\return ECgOk on success
*/
TCgReturnCode CgTimeSystemCheckYearValidation(const TCgTime aTime);
TCgReturnCode CgTimeRtcBiasGet(DOUBLE *aBias);
TCgReturnCode CgTimeRtcBiasSet(DOUBLE aBias);
TCgReturnCode CgTimeRtcBiasUpdate(DOUBLE Bias);
TCgReturnCode CgTimePreviousRtcBiasSet(void);

TCgReturnCode CgTimeClockPreviousBiasSet(DOUBLE *aBias);

TCgReturnCode CgTimeUtcGpsGet(TCgUtcGpsTimeDiff *aUtcGpsTime);
TCgReturnCode CgTimeUtcGpsSet(TCgUtcGpsTimeDiff aUtcGpsTime);

/**
 Get current device time, in GPS format 

 @param[out] aGpsTime Pointer to GPS time structure
 @return ECgOk on success
*/
TCgReturnCode CgTimeDeviceGet(TCgAgpsTime *aGpsTime);

TCgReturnCode CgTimeDiffDouble( const TCgAgpsTime *pGpsTime1, const TCgAgpsTime *pGpsTime2, DOUBLE *pDiff);

#ifdef	__cplusplus
}
#endif /*__cplusplus*/

#define GPSTIME_STRUCTURE_TO_DOUBLE(seconds,secondsFrac)   ((DOUBLE)seconds+(DOUBLE)secondsFrac*(1E-9))
#define GPSTIME_DOUBLE_TO_STRUCTURE_SECONDS(gpstimeDouble)  ((U32)CgMathFloor(gpstimeDouble))
#define GPSTIME_DOUBLE_TO_STRUCTURE_SECONDS_FRAC(gpstimeDouble)  ((U32)(CgMathMod((gpstimeDouble),1.0)/(1E-9)))
#define MAX_GPS_TIME  604800 //7*24*60*60

#endif
