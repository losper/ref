/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */

/**
	\file 
	\brief CPU API
	\defgroup CG_CPU_API CPU Abstraction API
	\{

	CellGuide's API to access low-level CPU resources 

	The API is used by CellGuide drivers and applications that require access to low-level CPU resources
	like DMA, SPI.

	CPU depended code is divided to the following API groups:
	\li \ref cg_cpu_clk
	\li \ref cg_cpu_dma
	\li \ref cg_cpu_gpio
	\li \ref cg_cpu_spi
	\li \ref cg_cpu_interrupt
	\li \ref cg_cpu_rtc
	\li \ref cg_cpu_general
*/

#ifndef CG_CPU_H
#define CG_CPU_H

#ifdef	__cplusplus
	extern "C" {
#endif /*__cplusplus*/

#include "CgTypes.h"						/**< CellGuide global types */
#include "CgReturnCodes.h"					/**< CellGuide return codes */
#include "CgCpuOs.h"						/**< CellGuide CPU related, OS specific functions */


/** Bit field definition 
  This structure is used to define a sub-register bit field, with arbitrary size.
  */
typedef struct {
	U32 start;								/**< start bit (0 based)  0 == LSB*/
	U32 length;								/**< length of bit field (1-32)*/
	U32 defaultValue;						/**< default value */
} TCgBitField;


#define CG_CPU_DEVICE_SPI			(1)

#define CG_CPU_SPI_MODE_DMA			(0)		/**< Use DMA to handle SPI communication */
#define CG_CPU_SPI_MODE_MANUAL		(1)		/**< Use polling to handle SPI communication */


/** Virtual GPIO groups definitions
	These values are used to define CellGuide 'virtual' GPIO codes, later converted to specific 
	CPU GPIO register and pin.
 */


#define CG_CPU_GPIO_GROUP_SIZE		(32)		/**< Maximum number of GPIOs in a group */

#define CG_CPU_GPIO_GROUP_INDEX_A  (1) /**< GPIO group A index */
#define CG_CPU_GPIO_GROUP_INDEX_B  (CG_CPU_GPIO_GROUP_INDEX_A+1) /**< GPIO group B index */
#define CG_CPU_GPIO_GROUP_INDEX_C  (CG_CPU_GPIO_GROUP_INDEX_B+1) /**< GPIO group C index */
#define CG_CPU_GPIO_GROUP_INDEX_D  (CG_CPU_GPIO_GROUP_INDEX_C+1) /**< GPIO group A index */
#define CG_CPU_GPIO_GROUP_INDEX_E  (CG_CPU_GPIO_GROUP_INDEX_D+1) /**< GPIO group A index */
#define CG_CPU_GPIO_GROUP_INDEX_F  (CG_CPU_GPIO_GROUP_INDEX_E+1) /**< GPIO group A index */
#define CG_CPU_GPIO_GROUP_INDEX_G  (CG_CPU_GPIO_GROUP_INDEX_F+1) /**< GPIO group G index */
#define CG_CPU_GPIO_GROUP_INDEX_H  (CG_CPU_GPIO_GROUP_INDEX_G+1) /**< GPIO group H index */
#define CG_CPU_GPIO_GROUP_INDEX_I  (CG_CPU_GPIO_GROUP_INDEX_H+1) /**< GPIO group I index */
#define CG_CPU_GPIO_GROUP_INDEX_J  (CG_CPU_GPIO_GROUP_INDEX_I+1) /**< GPIO group J index */
#define CG_CPU_GPIO_GROUP_INDEX_K  (CG_CPU_GPIO_GROUP_INDEX_J+1) /**< GPIO group K index */
#define CG_CPU_GPIO_GROUP_INDEX_L  (CG_CPU_GPIO_GROUP_INDEX_K+1) /**< GPIO group L index */
#define CG_CPU_GPIO_GROUP_INDEX_M  (CG_CPU_GPIO_GROUP_INDEX_L+1) /**< GPIO group M index */
#define CG_CPU_GPIO_GROUP_INDEX_N  (CG_CPU_GPIO_GROUP_INDEX_M+1) /**< GPIO group N index */
#define CG_CPU_GPIO_GROUP_INDEX_O  (CG_CPU_GPIO_GROUP_INDEX_N+1) /**< GPIO group O index */
#define CG_CPU_GPIO_GROUP_INDEX_P  (CG_CPU_GPIO_GROUP_INDEX_O+1) /**< GPIO group P index */
#define CG_CPU_GPIO_GROUP_INDEX_Q  (CG_CPU_GPIO_GROUP_INDEX_P+1) /**< GPIO group Q index */
#define CG_CPU_GPIO_GROUP_INDEX_R  (CG_CPU_GPIO_GROUP_INDEX_Q+1) /**< GPIO group R index */
#define CG_CPU_GPIO_GROUP_INDEX_S  (CG_CPU_GPIO_GROUP_INDEX_R+1) /**< GPIO group S index */
#define CG_CPU_GPIO_GROUP_INDEX_T  (CG_CPU_GPIO_GROUP_INDEX_S+1) /**< GPIO group T index */
#define CG_CPU_GPIO_GROUP_INDEX_U  (CG_CPU_GPIO_GROUP_INDEX_T+1) /**< GPIO group U index */
#define CG_CPU_GPIO_GROUP_INDEX_V  (CG_CPU_GPIO_GROUP_INDEX_U+1) /**< GPIO group V index */
#define CG_CPU_GPIO_GROUP_INDEX_W  (CG_CPU_GPIO_GROUP_INDEX_V+1) /**< GPIO group W index */
#define CG_CPU_GPIO_GROUP_INDEX_X  (CG_CPU_GPIO_GROUP_INDEX_W+1) /**< GPIO group X index */
#define CG_CPU_GPIO_GROUP_INDEX_Y  (CG_CPU_GPIO_GROUP_INDEX_X+1) /**< GPIO group Y index */
#define CG_CPU_GPIO_GROUP_INDEX_Z  (CG_CPU_GPIO_GROUP_INDEX_Y+1) /**< GPIO group Z index */
#define CG_CPU_GPIO_GROUP_INDEX___  (CG_CPU_GPIO_GROUP_INDEX_Z+1)


#define CG_CPU_GPIO_GROUP_A	 (CG_CPU_GPIO_GROUP_INDEX_A * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group A */
#define CG_CPU_GPIO_GROUP_B	 (CG_CPU_GPIO_GROUP_INDEX_B * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group B */
#define CG_CPU_GPIO_GROUP_C	 (CG_CPU_GPIO_GROUP_INDEX_C * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group C */
#define CG_CPU_GPIO_GROUP_D	 (CG_CPU_GPIO_GROUP_INDEX_D * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group D */
#define CG_CPU_GPIO_GROUP_E	 (CG_CPU_GPIO_GROUP_INDEX_E * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group E */
#define CG_CPU_GPIO_GROUP_F	 (CG_CPU_GPIO_GROUP_INDEX_F * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group F */
#define CG_CPU_GPIO_GROUP_G	 (CG_CPU_GPIO_GROUP_INDEX_G * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group G */
#define CG_CPU_GPIO_GROUP_H	 (CG_CPU_GPIO_GROUP_INDEX_H * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group H */
#define CG_CPU_GPIO_GROUP_I	 (CG_CPU_GPIO_GROUP_INDEX_I * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group I */
#define CG_CPU_GPIO_GROUP_J	 (CG_CPU_GPIO_GROUP_INDEX_J * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group J */
#define CG_CPU_GPIO_GROUP_K	 (CG_CPU_GPIO_GROUP_INDEX_K * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group K */
#define CG_CPU_GPIO_GROUP_L	 (CG_CPU_GPIO_GROUP_INDEX_L * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group L */
#define CG_CPU_GPIO_GROUP_M	 (CG_CPU_GPIO_GROUP_INDEX_M * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group M */
#define CG_CPU_GPIO_GROUP_N	 (CG_CPU_GPIO_GROUP_INDEX_N * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group N */
#define CG_CPU_GPIO_GROUP_O	 (CG_CPU_GPIO_GROUP_INDEX_O * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group O */
#define CG_CPU_GPIO_GROUP_P	 (CG_CPU_GPIO_GROUP_INDEX_P * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group P */
#define CG_CPU_GPIO_GROUP_Q	 (CG_CPU_GPIO_GROUP_INDEX_Q * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group Q */
#define CG_CPU_GPIO_GROUP_R	 (CG_CPU_GPIO_GROUP_INDEX_R * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group R */
#define CG_CPU_GPIO_GROUP_S	 (CG_CPU_GPIO_GROUP_INDEX_S * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group S */
#define CG_CPU_GPIO_GROUP_T	 (CG_CPU_GPIO_GROUP_INDEX_T * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group T */
#define CG_CPU_GPIO_GROUP_U	 (CG_CPU_GPIO_GROUP_INDEX_U * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group U */
#define CG_CPU_GPIO_GROUP_V	 (CG_CPU_GPIO_GROUP_INDEX_V * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group V */
#define CG_CPU_GPIO_GROUP_W	 (CG_CPU_GPIO_GROUP_INDEX_W * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group W */
#define CG_CPU_GPIO_GROUP_X	 (CG_CPU_GPIO_GROUP_INDEX_X * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group X */
#define CG_CPU_GPIO_GROUP_Y	 (CG_CPU_GPIO_GROUP_INDEX_Y * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group Y */
#define CG_CPU_GPIO_GROUP_Z	 (CG_CPU_GPIO_GROUP_INDEX_Z * CG_CPU_GPIO_GROUP_SIZE)	/**< 1st GPIO code in group Z */

 
extern const int gCgCpuDmaChNumFirst;		/**< 1st usable DMA channel index */
extern const int gCgCpuDmaChNumLast;		/**< Last usable DMA channel index */
/** Total number of usable DMA channels */
#define CG_CPU_DMA_CHANNEL_COUNT	(gCgCpuDmaChNumLast-gCgCpuDmaChNumFirst+1)


extern U32 gCpuGpioBaseVA;	/**<Virtual base address for GPIO controller */
extern U32 gCpuIntBaseVA;	/**<Virtual base address for Interrupt controller */
extern U32 gCpuDmaBaseVA;	/**<Virtual base address for DMA controller */
extern U32 gCpuResetBaseVA;	/**<Virtual base address for Reset controller */


#define REG32(r) *((volatile U32*)(r))

#define REG_SET1(aReg, aPin, aVal)  {\
	unsigned long regval = ((aVal) << ((aPin)));	\
	unsigned long mask = ~((unsigned long)1 << ((aPin)));	\
 	if(aVal == 0) aReg &= (mask); \
	else aReg |= regval; \
	}


#define REG_SET2(aReg, aPin, aVal)  {\
	unsigned long regval = ((aVal) << ((aPin)*2));	\
	unsigned long mask = ~((unsigned long)3 << ((aPin)*2));	\
 	aReg &= (mask); \
	aReg |= regval; \
	}

#define REG_SET4(aReg, aPin, aVal)  {\
	unsigned long regval = ((aVal) << ((aPin)*4));	\
	unsigned long mask = ~((unsigned long)0xF << ((aPin)*4));	\
 	aReg &= (mask); \
	aReg |= regval; \
	}

#define REG_SET8(aReg, aPin, aVal)  {\
	unsigned long regval = ((aVal) << ((aPin)*8));	\
	unsigned long mask = ~((unsigned long)0xFF << ((aPin)*8));	\
	aReg &= (mask); \
	aReg |= regval; \
}


/*********************************************************** CLOCK *************************/
/** \defgroup cg_cpu_clk Clock control
	Define the API to access the CPU clock configuration. This API is used to enable/disable generated clocks
	to required hardware units like SPI controller, UART controller etc.
*/

/** CPU unit identifier for clock generation purposes */
typedef enum {
	ECG_CPU_CLK_SPI		/**< SPI unit */
} TCgCpuClockUnit;


/**
    \ingroup cg_cpu_clk
    Create 'clock' access 

	in windows CE, usually use VirtualAlloc/VirtualCopy to generate an access to the DMA registers.
	if a consist storage is needed, it should be global.

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuClockCreate(void);


/**
    \ingroup cg_cpu_clk
    Destroy 'clock' access

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuClockDestroy(void);


/**
    \ingroup cg_cpu_clk
    Enable the clock to specific CPU unit

	\param[in]	aUnit		Unit code to enable

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuClockEnable(TCgCpuClockUnit aUnit);

/**
    \ingroup cg_cpu_clk
    Disable the clock to specific CPU unit

	\param[in]	aUnit		Unit code to disable

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuClockDisble(TCgCpuClockUnit aUnit);


/*********************************************************** DMA ***************************/

#define CG_DMA_SUBBLOCK_FLAG (0x80000000)

/** 
	\section DMA_CH_CODE DMA channel code
	code = DMA Controller code + channel number
	
	example: CG_CPU_DMA_CONTROLLER_0 + 4 ==> DMA controller 1, channel 4
*/
#define CG_CPU_DMA_CONTROLLER_0			(0x00000000)
#define CG_CPU_DMA_CONTROLLER_1			(0x00010000)
#define CG_CPU_DMA_CONTROLLER_2			(0x00020000)
#define CG_CPU_DMA_CONTROLLER_3			(0x00030000)
#define CG_CPU_DMA_CONTROLLER_4			(0x00040000)

#define CG_DMA_CONTROLLER(ch)			((ch & 0xFFFF0000) >> 16)
#define CG_DMA_CHANNEL(ch)				(ch & 0x0000FFFF)

/** DMA multi block mode
	Defines the method of executing consequtive DMA transfers.
	There are 3 different possible methods : 
	LLI - means that the DMA needs to be configured only once, and no extra tx commands should be issued
	PENDING - means that after receiving the first GPS data interrupt, the DMA should issue the next task, so it is prepared for it.
	NONE - means that the DMA should prepared for the next task, only after receiving the DMA interrupt for tx-done.
*/

#define CG_DRIVER_DMA_MULTI_BLOCK_MODE_NONE		0
#define CG_DRIVER_DMA_MULTI_BLOCK_MODE_PENDING	1
#define CG_DRIVER_DMA_MULTI_BLOCK_MODE_LLI		2

typedef struct {
    U32 address;
	U32 length;
} TCgCpuDmaTask;


/** \defgroup cg_cpu_dma DMA control
	Define the API to access Direct Memory Access unit for specific CPU.
*/

/**
    \ingroup cg_cpu_dma
    Create DMA access 

	\note in windows CE, usually use VirtualAlloc/VirtualCopy to generate an access to the DMA registers.
	if a consist storage is needed, it should be global.

	\param[in]  dmaChannel : The DMA channel to create
	\param[in] ipDataSourceAddress : The address of the IP, from which the DMA should read data

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDmaCreate(U32 dmaChannel, U32 ipDataSourceAddress);


/**
    \ingroup cg_cpu_dma
    Destroy DMA access 

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDmaDestroy(U32 aDmaChannel, U32 aIpDataSourceAddress);


/**
    \ingroup cg_cpu_dma
	Check if DMA channel number is valid for the specific system

    \param[in]	aDmaChannel			channel number
	
	\return System wide return code
	\retval ECgOk On success
	\retval ECgBadArgument for invalid channel
*/
TCgReturnCode CgCpuDmaIsValid(int aDmaChannel);


/**
    \ingroup cg_cpu_dma
    Check if DMA channel is ready for next operation.

    \param[in]	aDmaChannel			channel number

	\return System wide return code
	\retval ECgOk On success
	\retval ECgBadArgument for invalid channel
	\retval ECgBusy if not ready
*/
TCgReturnCode CgCpuDmaIsReady(int aDmaChannel);



/**
    \ingroup cg_cpu_dma
    Get DMA channel current count

    \param[in]	aDmaChannel			channel number
    \param[out]	apCount				bytes count

	\return System wide return code
	\retval ECgOk On success
	\retval ECgBadArgument for invalid channel
	\retval ECgBusy if not ready
*/
TCgReturnCode CgCpuDmaCurCount(int aDmaChannel, U32 *apCount);

/**
    \ingroup cg_cpu_dma
    Get DMA channel requested count

    \param[in]	aDmaChannel			channel number
    \param[out]	apCount				bytes count

	\return System wide return code
	\retval ECgOk On success
	\retval ECgBadArgument for invalid channel
	\retval ECgBusy if not ready
*/
TCgReturnCode CgCpuDmaRequestedCount(int aDmaChannel, U32 *apCount);

/**
    \ingroup cg_cpu_dma
    Wait for DMA channel to finish it's current transfer

    \param[in]	aDmaChannel			channel number

	\return System wide return code
	\retval ECgOk On success
	\retval ECgBadArgument for invalid channel
	\retval ECgBusy if not ready
*/TCgReturnCode CgCpuDmaWaitFinish(int aDmaChannel);


/**
    \ingroup cg_cpu_dma
    Stop DMA channel

    \param[in]	aDmaChannel			channel number

	\return System wide return code
	\retval ECgOk On success
	\retval ECgBadArgument for invalid channel
*/
TCgReturnCode CgCpuDmaStop(int aDmaChannel);


/**
    \ingroup cg_cpu_dma
    Start the specified DMA channel.
	the channel initialization (setting source, destination, etc) is done in another function.

    \param[in]	aDmaChannelCode		DMA channel code.
									\ref DMA_CH_CODE									

	\return System wide return code
	\retval ECgOk On success
	\retval ECgBadArgument for invalid channel
*/
TCgReturnCode CgCpuDmaStart(int aDmaChannelCode);


/**
    \ingroup cg_cpu_dma
    Configure DMA to write data to SPI 

    \param pSource			Source memory address to write from
    \param aLength			Number of bytes to write
    \param aWriteDmaChannel DMA channel to use
    \param aDeviceChannel		SPI channel to use

	\note the function checks that the DMA channel selected is the right one for the SPI channel.

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDmaSetupToDevice(U32 pSource, U32 aLength, int aWriteDmaChannel, int aDeviceChannel);




/**
    \ingroup cg_cpu_dma
    Configure DMA to read data from SPI 

    \param pTarget			Source memory address to write to
    \param aLength			Number of bytes to transfer
    \param aBlockLength		Number of bytes in a block
    \param aReadDmaChannel	DMA channel to use for read
    \param aWriteDmaChannel DMA channel to use for write
    \param aDeviceChannel		SPI channel to use

	\note if SPI has 'auto output' generator, there is no need to use the 'write' channel.
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDmaSetupFromDevice(U32 pTarget, U32 aLength, U32 aBlockLength, int aReadDmaChannel, int aWriteDmaChannel, int aDeviceChannel);



/**
    \ingroup cg_cpu_dma
    Configure DMA to read data from CGX5500 

    \param apDmaTask		DMA tasks list
    \param aDmaTaskCount	Total number of DMA tasks
    \param aDmaChannelCode	DMA channel to use for read (\ref DMA_CH_CODE)
    \param aDeviceCode		Device code 

	\note if SPI has 'auto output' generator, there is no need to use the 'write' channel.
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDmaSetupFromDeviceFirstTask(TCgCpuDmaTask *apDmaTask, U32 aDmaTaskCount, U32 aDmaChannelCode, U32 aDeviceCode);


/**
    \ingroup cg_cpu_dma
    Configure DMA to read data from SPI 

    \param apDmaTask		DMA tasks list
    \param aDmaTaskCount	Total number of DMA tasks
    \param aActiveTaskIndex	Active DMA task number
    \param aDmaChannel		DMA channel to use for read
    \param aDeviceCode		Device code 

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDmaSetupFromDeviceNextTask(TCgCpuDmaTask *apDmaTask, U32 aDmaTaskCount, U32 aActiveTaskIndex, U32 aDmaChannel, U32 aDeviceCode);

/**
    \ingroup cg_cpu_dma
    Configure DMA to read data from CGX5500 

    \param apDmaTask		DMA tasks list
    \param aDmaTaskCount	Total number of DMA tasks
    \param aDmaChannelCode	DMA channel to use for read (\ref DMA_CH_CODE)
    \param aDeviceAddress	Device address 

	\note if SPI has 'auto output' generator, there is no need to use the 'write' channel.
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDmaSetupFromCgx5500(TCgCpuDmaTask *apDmaTask, U32 aDmaTaskCount, U32 aDmaChannelCode, U32 aDeviceAddress);




/**
    \ingroup cg_cpu_dma
    Configure DMA to read data from SPI 

    \param apDmaTask		DMA tasks list
    \param aDmaTaskCount	Total number of DMA tasks
    \param aActiveTaskIndex	Active DMA task number
    \param aDmaChannel		DMA channel to use for read
    \param aDeviceAddress	Device address 

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDmaSetupFromCgx5500NextTask(TCgCpuDmaTask *apDmaTask, U32 aDmaTaskCount, U32 aActiveTaskIndex, U32 aDmaChannel, U32 aDeviceAddress);

/*********************************************************** GPIO **************************/
/** \defgroup cg_cpu_gpio GPIO control
	Configure, set and read GPIO


	CellGuide GPIO code is abstract number, combination of group constant and pin number.
	the number is translated to specific CPU values by specific implementation.
*/


/** GPIO pin configuration modes */
typedef enum {
	ECG_CPU_GPIO_INPUT,				/**< GPIO to act as input */
	ECG_CPU_GPIO_OUTPUT,			/**< GPIO to act as output */
	ECG_CPU_GPIO_SPECIAL,			/**< GPIO to act as special function */
	ECG_CPU_GPIO_FALLING_INT,		/**< GPIO to act as falling edge interrupt*/
	ECG_CPU_GPIO_SPECIAL2,			/**< GPIO to act as special function */
	ECG_CPU_GPIO_MODE___
} TCgCpuGpioMode;


/**
    \ingroup cg_cpu_gpio
    Create access to GPIO
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuGpioCreate(void);


/**
    \ingroup cg_cpu_gpio
    Destroy access to GPIO
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuGpioDestroy(void);


/**
    \ingroup cg_cpu_gpio
    Set a specific GPIO to '1'

    \param[in]	aPinCode			GPIO pin code

	\note Pin code is Cell-guide internal code for each GPIO, which is a combination of the 
	GPIO group offset and the number inside the group.
	
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuGpioSet(U32 aPinCode);


/**
    \ingroup cg_cpu_gpio
    Set a specific GPIO to '0'

	\note Pin code is Cell-guide internal code for each GPIo, which is a combination of the 
	GPIO group offset and the number inside the group.

	\param[in]	aPinCode			GPIO pin code
	
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuGpioReset(U32 aPinCode);


/**
    \ingroup cg_cpu_gpio
    Get a specific GPIO value

    \note Pin code is Cell-guide internal code for each GPIo, which is a combination of the 
	GPIO group offset and the number inside the group.

    \param[in]	aPinCode			GPIO pin code
    \param[out] aPinValue			current value
	
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuGpioGet(U32 aPinCode, int *aPinValue);


/**
    \ingroup cg_cpu_gpio
    Set a specific GPIO mode

    \note Pin code is Cell-guide internal code for each GPIo, which is a combination of the 
	GPIO group offset and the number inside the group.

    \param[in]	aPinCode			GPIO pin code
    \param[in]	aPinMode			Requested mode

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuGpioMode(U32 aPinCode, TCgCpuGpioMode aPinMode);

/**
    \ingroup cg_cpu_gpio
    Set a specific GPIO direction

    \note Pin code is Cell-guide internal code for each GPIo, which is a combination of the 
	GPIO group offset and the number inside the group.

    \param[in]	aPinCode			GPIO pin code
    \param[in]	aPinMode			Requested mode

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuGpioDirection(U32 aPinCode, TCgCpuGpioMode aPinMode);

/*********************************************************** SPI ***************************/
/** \defgroup cg_cpu_spi SPI control
	SPI programing
*/




/**
    \ingroup cg_cpu_spi
    Delay for specific time

    \param aCount 
    \param aDeviceChannel 

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuDelay(U32 aCount);


typedef enum {
	ECG_CPU_SPI_INPUT_DMA,
	ECG_CPU_SPI_INPUT_POLLING,
	ECG_CPU_SPI_OUTPUT_DMA,
	ECG_CPU_SPI_OUTPUT_POLLING,
	ECG_CPU_SPI_INIT,
	ECG_CPU_SPI_SLAVE_INPUT_DMA,
	ECG_CPU_SPI_SLEEP,				// TODO : where did this come from? sun uses it in her code...
	ECG_CPU_SPI_MODE___
} TCgCpuSpiMode;



/**
    \ingroup cg_cpu_spi
    Create access to SPI
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiCreate(void); 


/**
    \ingroup cg_cpu_spi
    Destroy access to SPI
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiDestroy(void); 


/**
    \ingroup cg_cpu_spi
    Enable SPI controller for specific channel

	\param[in]	aDeviceChannel		SPI Channel number
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiEnable(int aDeviceChannel); 

/**
    \ingroup cg_cpu_spi
    Disable SPI controller for specific channel

	\param[in]	aDeviceChannel		SPI Channel number
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiDisable(int aDeviceChannel); 

/**
    \ingroup cg_cpu_spi
    Check if SPI channel number is valid for the specific system

    \param[in]	aDeviceChannel		SPI Channel number
	
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiIsValid(int aDeviceChannel);

/**
    \ingroup cg_cpu_spi
    Setup SPI channel
   
	\param[in]	aDeviceChannel		SPI channel number
	\param[in]	aPrescale			SPI clock divider
	\param[in]	aMode				SPI mode
	\param[in]	aLengthBytes		Number of bytes

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiConfig(U32 aDeviceChannel, U32 aPrescale, TCgCpuSpiMode aMode, U32 aLengthBytes);

/**
    \ingroup cg_cpu_spi
    Setup SPI channel
   
	\param[in]	aDeviceChannel		SPI channel number
	\param[in]	aLengthBytes		Number of bytes

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiSlaveConfig(U32 aDeviceChannel, U32 aLengthBytes);

/**
    \ingroup cg_cpu_spi
    Setup SPI channel GPIO
   
	\param[in]	aDeviceChannel			SPI channel number
	\param[in]	aPrescale			SPI clock divider
	\param[in]	aMode				SPI mode

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiSetup(U32 aDeviceChannel, U32 aPrescale, TCgCpuSpiMode aMode);


/**
    \ingroup cg_cpu_spi
    Loop until SPI write is finished.

	\param[in]	aDeviceChannel			SPI channel number
  
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiTxFinishWait(U32 aDeviceChannel);


/**
    \ingroup cg_cpu_spi
    Clear SPI receive FIFO

	\param[in]	aDeviceChannel			SPI channel number
  
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiClearFifo(U32 aDeviceChannel);

/**
    \ingroup cg_cpu_spi
    Loop until SPI read is finished.

	\param[in]	aDeviceChannel			SPI channel number
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiRxFinishWait(U32 aDeviceChannel);

/**
    \ingroup cg_cpu_spi
    Read one byte from SPI channel

	\param[in]	aDeviceChannel			SPI channel number
	\param[out]	aByte				Data read from SPI
   
    \return Value read from SPI
*/
TCgReturnCode CgCpuSpiReadByte(U32 aDeviceChannel, volatile unsigned char *aByte);

/**
    \ingroup cg_cpu_spi
    Read one byte from SPI channel (read 2nd FIFO byte)

	\param[in]	aDeviceChannel			SPI channel number
	\param[out]	aByte				Data read from SPI
   
    \return Value read from SPI
*/
TCgReturnCode CgCpuSpiReadByte2(U32 aDeviceChannel, volatile unsigned char *aByte);


/**
    \ingroup cg_cpu_spi
    Write one byte to SPI channel

	\param[in]	aDeviceChannel			SPI channel number
	\param[in]	aValue				Value to write
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiWriteByte(U32 aDeviceChannel, unsigned char aValue);


/**
    \ingroup cg_cpu_spi
    Return the GPIO code for selected SPI channel MOSI

    \param[in]	aDeviceChannel			channel number
    \param[out] aGpioCode			gpio code

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiMosi(U32 aDeviceChannel, U32 *aGpioCode);


/**
    \ingroup cg_cpu_spi
    Return the GPIO number for selected SPI channel MISO

    \param[in]	aDeviceChannel			channel number
    \param[out] aGpio				gpio code

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiMiso(U32 aDeviceChannel, U32 *aGpio);


/**
    \ingroup cg_cpu_spi
    Return the GPIO number for selected SPI channel CLK

    \param[in]	aDeviceChannel			channel number
    \param[out] aGpio				gpio code

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiClk(U32 aDeviceChannel, U32 *aGpio);


/**
    \ingroup cg_cpu_spi
    Return the GPIO number for selected SPI channel CS (Chip Select)

    \param[in]	aDeviceChannel			channel number
    \param[out] aGpio				gpio code

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuSpiCs(U32 aDeviceChannel, U32 *aGpio);

/*********************************************************** INTR **************************/
/** \defgroup cg_cpu_interrupt Interrupt control
	access to interrupt controller
*/

/**
    \ingroup cg_cpu_interrupt
    Create access to INTC
   
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuIntrCreate(void);

/**
    \ingroup cg_cpu_interrupt
    Destroy access to INTC 

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuIntrDestroy(void);


/**
    \ingroup cg_cpu_interrupt
	Register IRQ interrupt as OS interrupt
    \param[in]			aIRQ				requested IRQ interrupt code
	\param[in]			apOSIntCode			requested software interrupt code
    \param[out]			apOSIntCode			registered OS interrupt code 
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuIntrRequestOsInterrupt(U32 aIRQ, U32 *apOSIntCode);
/**
    \ingroup cg_cpu_interrupt
    Initialize interrupt

    \param[in]		aRequestCode	requested interrupt code (os specific)
    \param[in]		apEvent			event to tie with interrupt

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuIntrAttachEvent(U32 aRequestCode, void *apEvent);

/**
    \ingroup cg_cpu_interrupt
    Disable registered interrupt

    \param[in]	aInterruptCode	interrupt code (os specific)

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuIntrDisable(U32 aInterruptCode);


/**
    \ingroup cg_cpu_interrupt
    Signals to the kernel that interrupt processing has been completed

    \param[in]	aInterruptCode	interrupt code (os specific)

	\return System wide return code
	\retval ECgOk On success
*/

TCgReturnCode CgCpuIntrDone(U32 aInterruptCode);


/** Interrupt Service Thread information structure */
typedef struct {
    void *handle;					/**< Handle to thread object */
    U32 intCode;					/**< Interrupt code */
    void *event;					/**< Handle to Interrupt event */
    S32 priority;					/**< Thread priority */
} TCgCpuIST;


/**
    \ingroup cg_cpu_interrupt
	If apSharedISRInfo == NULL	===>		Create and start interrupt service thread 
	Else						===>		Initialize an event, and connect it to the EXISTING ISR

    \param[in]	apIstInfo				Thread info structure
    \param[in]	aFunc					Main function for the thread
    \param[in]	aPriority				Requested thread priority
    \param[in]	aIntCode				Required interrupt code
    \param[in]	aIrqCode				Required IRQ code (may be 0)
    \param[in]	aParam					IST data structure pointer
	\param[in]	aEventName				Event name to use for interrupt/IST communication
										only need to supply name if the event is created by BSP.
										for systems where the event is internally tied to specific GPI interrupt,
										NULL can be set here
	\param[in] opt apSharedISRInfo		if the interrupt is shared, this will contain the info on 
										the shared interrupt
	\param[in] opt apSharedISRLibrary	if the interrupt is shared, this will indicate what library 
										holds the shared interrupt handler
	\param[in] opt apSharedISR			if the interrupt is shared, this will indicate the name of the 
										interrupt service routine
	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuISTStart(TCgCpuIST *apIstInfo, void *aFunc, S32 aPriority, U32 aIntCode, U32 aIrqCode, 
							void *aParam, const char *aEventName, void * apSharedISRInfo, 
							const void * apSharedISRLibrary, const void * apSharedISR);


/**
    \ingroup cg_cpu_interrupt
    Stop interrupt service thread 

    \param[in]	apIstInfo	Thread info structure

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuISTStop(TCgCpuIST *apIstInfo);



/*********************************************************** RTC ***************************/
/** \defgroup cg_cpu_rtc RTC control
	access to RTC
*/

/**
    \ingroup cg_cpu_rtc
    Create access to RTC 

	in windows CE, usually use VirtualAlloc/VirtualCopy to generate an access to the DMA registers.
	if a consist storage is needed, it should be global.

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuRtcCreate(void);



/**
    \ingroup cg_cpu_rtc
    Destroy access to RTC 

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuRtcDestroy(void);


typedef struct  {
	U32 year;
	U32 month;
	U32 day;
	U32 hour;
	U32 minute;
	U32 second;
	U32 dayInWeek;
	U32 tick;
} TCgCpuRtcTime;

TCgReturnCode CgCpuRtcRead(TCgCpuRtcTime *apTime);

/*********************************************************** General *************************/
/** \defgroup cg_cpu_general General*/

/**
    \ingroup cg_cpu_general
    Get last error code for this unit

	\return system error code
*/
U32 CgCpuLastErrorCode(void);



/**
    \ingroup cg_cpu_general
    Clear CPU cache

    \param[in]	pSource			Source memory address 
    \param[in]	aDmaChannel		DMA channel	


	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuClearCache(U32 pSource, int aDmaChannel);



/**
    \ingroup cg_cpu_general
    Set bits in bit-field register

    \param[in]	aReg			pointer to register
    \param[in]	aBitFieldDef	bit field definition
    \param[in]	aValue			value to set

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgSetRegisterBits(volatile U32 *aReg, TCgBitField aBitFieldDef, U32 aValue);



/**
    \ingroup cg_cpu_general
    Get bits from bit-field register

    \param[in]	aReg			register
    \param[in]	aBitFieldDef	bit field definition
    \param[in]	apValue			pointer to returned value

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgGetRegisterBits(volatile U32 aReg, TCgBitField aBitFieldDef, U32 *apValue);

/**
    \ingroup cg_cpu_general
    Virtual memory allocation 

	\return System wide return code
	\retval ECgOk On success
*/
TCgReturnCode CgCpuAllocateVa();

/**
    Reset a CPU sub-unit
    \param[in]	aUnitIndex		unit id (see specific CPU documentation)
*/
TCgReturnCode CgCpuReset(U32 aUnitIndex);


/** 
	Get CPU revision code
	\param[out]	apRevisionCode	CPU revision code
*/
TCgReturnCode CgCpuRevision(char *apRevisionCode);


// Swap function
TCgReturnCode CgSwapBytesInBlock(void * aSource,void * aDest, long aSizeInBytes, TCgByteOrder aFrom, TCgByteOrder aTo);

#ifdef	__cplusplus
}
#endif /*__cplusplus*/

#endif
/**
 \}
*/
