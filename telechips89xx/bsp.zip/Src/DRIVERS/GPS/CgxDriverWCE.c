/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
  \file 
  \brief Microsoft Windows CE specific driver code

  Specific code required for the CellGuide GPS driver integration with Microsoft Windows CE.
  \defgroup CGX_DRIVER_WCE Windows CE Implementation
  \{
*/

#include "CgTypes.h"						/**< CellGuide Types */
#include "CgReturnCodes.h"					/**< CellGuide Return codes */
#include "CgxDriverCore.h"					/**< CellGuide Driver core API */
#include "CgxDriverOs.h"					/**< CellGuide Driver OS specific API */
#include "CgxDriverPlatform.h"				/**< CellGuide Driver Platform specific API */
#include "CgCpu.h"							/**< CellGuide CPU low level functions API */
#include <windows.h>                 		/**< Windows CE Specific */
#include "CgxDriverWCE.h"               		/**< Windows CE Specific */
#include <pkfuncs.h>						/**< Windows CE Specific */


#define RCV_SEM_NAME L"HwRcvSem"

/** Default value for Data ready IST priority, if not specifically defined in platform.h */
#ifndef CG_DRIVER_DATA_READY_IST_PRIORITY
	#define CG_DRIVER_DATA_READY_IST_PRIORITY	(5)
#endif

/** Default value for GPS IST priority, if not specifically defined in platform.h */
#ifndef CG_DRIVER_GPS_IST_PRIORITY
	#define CG_DRIVER_GPS_IST_PRIORITY			(6)
#endif


/**
    initialize interrupt support
       
	\return System wide return code
	\retval ECgOk Success
*/
static TCgReturnCode CgxDriverInitInterrupt(U32 *intr, HANDLE event)
{
	TCgReturnCode rc = ECgOk;
	BOOL bRet = FALSE;
	#ifndef DONT_USE_KERNEL_IO_CONTROL_FOR_INT
		if(!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, intr, 
			sizeof(unsigned int), intr, sizeof(unsigned int), NULL))
		{
			RETAILMSG(1, (TEXT("ERROR: PwrButton: Failed to request apThreadInfo->.intCode value for power button interrupt.\r\n")));
			return(0);
		}
	#endif
	
	bRet = InterruptInitialize(*intr, event, NULL, 0);
	if(bRet == FALSE)
	{
		U32 dwError = GetLastError();
	}
	return bRet ? ECgOk: ECgGeneralFailure;
}




static TCgReturnCode CgxDriverStartThread(void *pDriver, TCgCpuIST *apThreadInfo, LPTHREAD_START_ROUTINE StartFunc)
{
	TCgReturnCode rc = ECgOk;
	DWORD suspendCount = 0;
	DWORD errCode = 0;
	BOOL bRet = FALSE;
	
    apThreadInfo->event = CreateEvent(NULL, FALSE, FALSE, NULL);
	bRet = (apThreadInfo->event != NULL);
    if (bRet)  {
	    apThreadInfo->handle = CreateThread(NULL, 0, StartFunc, pDriver, CREATE_SUSPENDED, NULL);
	    bRet = (apThreadInfo->handle != NULL);
	    }
    if (bRet)  {
        bRet = CeSetThreadPriority(apThreadInfo->handle, apThreadInfo->priority);
	    }
    if (bRet)  {
        CgxDriverInitInterrupt(&apThreadInfo->intCode, apThreadInfo->event);
	    }
	if (bRet)  {
        suspendCount = ResumeThread(apThreadInfo->handle); // TODO NG handle error : The thread's previous suspend count indicates success. 0xFFFFFFFF indicates failure. To get extended error information, call GetLastError.
		if (suspendCount == 0xFFFFFFFF) {
			errCode = GetLastError();
			bRet = FALSE;
			}
	    }

	return rc;
}



static TCgReturnCode CgxDriverTerminateThread(TCgCpuIST *apThreadInfo)
{
	TCgReturnCode rc = ECgOk;
	BOOL bRet = TRUE;
	DWORD dwError = 0;

	InterruptDisable(apThreadInfo->intCode);
	if(apThreadInfo->handle) {
		bRet = SetEvent(apThreadInfo->event);// TODO NG handle error
		//dwError = WaitForSingleObject(apThreadInfo->handle, INFINITE);
		bRet = CloseHandle(apThreadInfo->handle);		// TODO NG handle error
		}
        
	CloseHandle(apThreadInfo->event);

	return rc;
}



TCgxDriverPhysicalMemory * GetDriverChunk(void * pDriver)
{
	TCgxDriverPhysicalMemory * pChunk = &(((DRVCONTEXT *)pDriver)->chunk);
	return pChunk;
}



static DWORD  WINAPI GeneralInterruptServiceThread( LPVOID plvParam)
{
	DWORD dwStatus = 0;
	DWORD bMode = SetKMode(TRUE); 
	DWORD dwPerm = SetProcPermissions(0xFFFFFFFF);
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)plvParam;

	// loop until told to stop
	while(!pDriverInfo->state.flags.terminate) {
		// wait for the interrupt event...
		dwStatus = WaitForSingleObject(pDriverInfo->gpsIST.event, INFINITE);

		// Make sure we have the object
        switch (dwStatus)  {
            case WAIT_FAILED:
                dwStatus = GetLastError();
                break;
            case WAIT_OBJECT_0:
	            HandleGeneralInterrupt(pDriverInfo, &pDriverInfo->state);
				InterruptDone(pDriverInfo->gpsIST.intCode);
                break;
            case WAIT_ABANDONED:
                break;
            case WAIT_TIMEOUT:
                break;
            default:
                break;
			}
		}
	
	return 0;
}



















TCgReturnCode CgxDriverAllocateChunkMemory(void *pDriver, TCgxDriverPhysicalMemory *apPhysicalMemory, U32 aSizeBytes)
{
	TCgReturnCode rc = ECgOk;
		 
	apPhysicalMemory->length = aSizeBytes;
	apPhysicalMemory->driverContextVirtBufferAddr = AllocPhysMem(aSizeBytes + 32, PAGE_READWRITE, 0, 0, &apPhysicalMemory->physAddr);
	if(apPhysicalMemory->driverContextVirtBufferAddr == NULL) {
		DWORD err = GetLastError();
		rc = ECgErrMemory;
		}
	apPhysicalMemory->driverContextVirtBufferAddr = (unsigned char *)((((DWORD)apPhysicalMemory->driverContextVirtBufferAddr + 32 - 1) / 32) * 32);
	apPhysicalMemory->physAddr = ((apPhysicalMemory->physAddr + 32 - 1) / 32) * 32;
	return rc;
}

//extern HANDLE activecontrolEvt = NULL; //TODO

TCgReturnCode CgxDriverTransferEndWait(void *pDriver, U32 aTimeoutMS, U8 **apBuffer, U32 *aCount)
{
	TCgReturnCode rc = ECgOk;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)pDriver;
	DWORD ret = 0;
	if (pDriverInfo->state.request.abortReceive && 
		(pDriverInfo->state.transfer.chunks.received > pDriverInfo->state.transfer.cancel.onChunk)) 
		{
			return ECgCanceled;
		}

	ret = WaitForSingleObject(pDriverInfo->transferEndSemaphore, aTimeoutMS);

	switch (ret) {
		case WAIT_OBJECT_0:	
//TODO
//			if(activecontrolEvt != NULL){
// 				SetEvent(activecontrolEvt);
//			}
			*apBuffer = pDriverInfo->state.transfer.originalBuffer + pDriverInfo->state.transfer.bufferOffset[pDriverInfo->state.transfer.blocks.received - 1];
			*aCount = (pDriverInfo->state.transfer.blocks.bytes == 0) 
				? pDriverInfo->state.transfer.bytes.received 
				: pDriverInfo->state.transfer.blocks.bytes;
			
			break;
		case WAIT_TIMEOUT: rc = ECgTimeout; printf("\n\r[CgxDriverTransferEndWait] wait timeout %x!!!",aTimeoutMS);
			CgCpuDRCheck();
			break;
		default: 
			{
				int err = 0;
				err = GetLastError();
				RETAILMSG(1,(TEXT("\r\n[CgxDriverTransferEndWait] wait_Failed %X"),err));

			
			rc = ECgGeneralFailure; 
			}
			break;
		}

	if (pDriverInfo->state.request.abortReceive && 
		(pDriverInfo->state.transfer.chunks.received > pDriverInfo->state.transfer.cancel.onChunk))
		{
			rc = ECgCanceled;
		}

	return rc;
}




TCgReturnCode CgxDriverGeneralInterruptHandlerStart(void *pDriver)
{
	TCgReturnCode rc = ECgOk;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)pDriver;
	pDriverInfo->gpsIST.intCode = CgxDriverGeneralInterruptCode();
	CgxDriverStartThread(pDriver, &pDriverInfo->gpsIST, GeneralInterruptServiceThread);
	return rc;
}




void *CgxDriverGetInternalBuff(void *pSource, U32 aLength)
{
	#ifdef INLINE_DRIVER
		return pSource;
	#else
		return MapPtrToProcess(pSource, GetCallerProcess());
	#endif
}

void CgxDriverUnMapPointer(void *pSource)
{
	UnMapPtr(pSource);
}





TCgReturnCode CgxDriverSleep(U32 aTimeMS)
{
	Sleep(aTimeMS);
	return ECgOk;
}



unsigned long CgxCopyFromUser(
	void *to,
	const void *fromuser,
	unsigned long n )
{
	void *from = MapPtrToProcess((void *)fromuser, GetCallerProcess());
	if (from == NULL)
		return n;
	memcpy(to, from, n);
	return 0; // TODO should return number of un-copied bytes.
}



TCgReturnCode CgxDriverAllocInternalBuff(void *pDriver, unsigned long aLength, void **apBuffer, U32 aAppProcessId)
{
	DBG_FUNC_NAME("CgxDriverAllocInternalBuff")
	TCgReturnCode rc = ECgOk;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)pDriver;


	pDriverInfo->state.buffer.length = 0;

	// Create buffer between the driver and the DMA
	//////////////////////////////////////////////////////////////////////////

	pDriverInfo->state.buffer.driverContextVirtBufferAddr = 
		AllocPhysMem(aLength, PAGE_READWRITE, 0, 0, &pDriverInfo->state.buffer.physAddr);

	DBGMSG1("driverContextVirtBufferAddr = 0x%x", pDriverInfo->state.buffer.driverContextVirtBufferAddr )
		DBGMSG1("Physical address = 0x%x", pDriverInfo->state.buffer.physAddr  )

	rc = pDriverInfo->state.buffer.driverContextVirtBufferAddr != NULL ? ECgOk : ECgErrMemory;
	if (OK(rc)) 
	{
	#if ( (_WIN32_WCE == 0x600) )	// Windows CE6 

		// Map physical buffer to the Application process virtual memory
		////////////////////////////////////////////////////////////////

		pDriverInfo->state.buffer.appContextVirtAddr = 
		(U8*)VirtualAllocCopyEx( GetCurrentProcess(), (HANDLE)aAppProcessId, (void*)(pDriverInfo->state.buffer.driverContextVirtBufferAddr), 
		aLength, PAGE_READWRITE );
		DBGMSG1("app virt address = 0x%x", pDriverInfo->state.buffer.appContextVirtAddr )
		rc = pDriverInfo->state.buffer.appContextVirtAddr != NULL ? ECgOk : ECgErrMemory;
		if ( OK(rc) )
			*apBuffer = (void *)pDriverInfo->state.buffer.appContextVirtAddr;

	#else							// Windows CE5 and below

		*apBuffer = (void *)pDriverInfo->state.buffer.physAddr;
		DBGMSG3("Allocated V:0x%08X, P:0x%08X, size:%d",pDriverInfo->state.buffer.driverContextVirtBufferAddr, 
				pDriverInfo->state.buffer.physAddr, aLength)
	#endif
	}
	
	if (OK(rc))	
	{
		memset(pDriverInfo->state.buffer.driverContextVirtBufferAddr, 0x43, aLength);
		pDriverInfo->state.buffer.length = aLength;
	}

	return rc;
}
TCgReturnCode CgxDriverFreeInternalBuff(void *pDriver, U32 aAppProcessId)
{
	DBG_FUNC_NAME("CgxDriverFreeInternalBuff")
		TCgReturnCode rc = ECgOk;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)pDriver;
	DBGMSG2("V:0x%08X P:", pDriverInfo->state.buffer.appContextVirtAddr, pDriverInfo->state.buffer.physAddr)
	#if ( (_WIN32_WCE == 0x600) )	// Windows CE6
		// Free virtual allocated memory, in the application process address space
		VirtualFreeEx( (HANDLE)aAppProcessId, pDriverInfo->state.buffer.appContextVirtAddr, pDriverInfo->state.buffer.length, MEM_RELEASE );

		// Free the actual physical memory allocated
		FreePhysMem(pDriverInfo->state.buffer.driverContextVirtBufferAddr);

	#else
	{
		BOOL ret = FreePhysMem(pDriverInfo->state.buffer.appContextVirtAddr);
		if (!ret) {
			DBGMSG1("Failed internal free (%d)", ret)
				rc = ECgErrMemory;
		}
	}
	#endif

	return rc;
}


//======================================================================
// CGX_Init - Driver initialization function
//
DWORD CGX_Init (DWORD dwContext)
{
	DBG_FUNC_NAME("CGX_Init")
    PDRVCONTEXT pDrv = NULL;
	DWORD bMode = SetKMode(TRUE); 
	DWORD dwPerm = SetProcPermissions(0xFFFFFFFF);

    // Allocate a drive instance structure.
    pDrv = (PDRVCONTEXT)LocalAlloc (LPTR, sizeof (DRVCONTEXT));
    if (!pDrv) {
        return 0;  // Fail init
		}
    // Init structure
    memset ((PBYTE) pDrv, 0, sizeof (DRVCONTEXT));
    pDrv->dwSize = sizeof (DRVCONTEXT);

    CgxDriverConstruct(pDrv, &pDrv->state, &pDrv->chunk);

	return (DWORD)pDrv;
}



//======================================================================
// CGX_IOControl - Called when DeviceIOControl called
//
DWORD CGX_IOControl (DWORD dwOpen, DWORD dwCode, PBYTE pIn, DWORD dwIn,
                     PBYTE pOut, DWORD dwOut, DWORD *pdwBytesWritten)
{
	TCgReturnCode rc = ECgOk;
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwOpen;

	/*lint -e826*/ 
	// TODO check size of structure
	rc = CgxDriverExecute(pDrv, &pDrv->state, &pDrv->chunk, dwCode, (TCgDriverControl*)pIn, (TCgDriverStatus *)pOut);
	
	if(pdwBytesWritten)
	  *pdwBytesWritten = sizeof(TCgDriverStatus);

    return (OK(rc)) ? TRUE : FALSE;
}








//======================================================================
// CGX_Deinit - Driver de-initialization function
//
BOOL CGX_Deinit (DWORD dwContext)
{
    PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

    if (pDrv && (pDrv->dwSize == sizeof (DRVCONTEXT))) {
        // Free the driver state buffer.
		BOOL ret =TRUE;
		TCgReturnCode rc;

		// TODO NG handle return code
		if ( pDrv->gpsIST.intCode )
		{
			ret = KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &pDrv->gpsIST.intCode, sizeof(DWORD), NULL, 0, NULL);
			if ( !ret ) printf("Failure releasing gpsIST interrupt [%d]", pDrv->gpsIST.intCode);
		}
		// TODO NG handle return code
		if ( pDrv->dataReadyIST.intCode )
		{
			ret = KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &pDrv->dataReadyIST.intCode, sizeof(DWORD), NULL, 0, NULL);
			if ( !ret ) printf("Failure releasing dataReadyIST interrupt [%d]", pDrv->dataReadyIST.intCode);
		}
		pDrv->state.flags.terminate = TRUE;
		// TODO KF handle return code
		if ( pDrv->gpsIST.handle != NULL )
		{
			rc = CgxDriverTerminateThread(&pDrv->gpsIST);
			if (FAIL(rc))	printf("Failure CgxDriverTerminateThread(&pDrv->gpsIST)");
		}
		// TODO KF handle return code
		if ( pDrv->dataReadyIST.handle != NULL )
		{
			rc = CgxDriverTerminateThread(&pDrv->dataReadyIST);
			if (FAIL(rc))	printf("Failure CgxDriverTerminateThread(&pDrv->dataReadyIST)");
		}
		if(pDrv->chunk.driverContextVirtBufferAddr) {
			BOOL boo = FreePhysMem((LPVOID)pDrv->chunk.driverContextVirtBufferAddr);
			}
		ret = CgxDriverStop(pDrv);
        LocalFree ((PBYTE)pDrv);
		}
    return TRUE;
}

//======================================================================
// CGX_PowerDown - Called when system suspends
//
// NOTE: No kernel calls including debug messages can be made from this call.
//
void CGX_PowerDown (DWORD dwContext)
{
    PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;
	pDrv->state.counters.powerDown++;

	CgxDriverPowerDown(&pDrv->chunk);
	CgxDriverIdle(pDrv);

    return;
}


//======================================================================
// CGX_PowerUp - Called when resumes
//
// NOTE: No kernel calls including debug messages can be made from this call.
//
void CGX_PowerUp (DWORD dwContext)
{
    PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;
	pDrv->state.counters.powerUp++;

	CgxDriverWakeup();

    return;
}




/* 	\}*/