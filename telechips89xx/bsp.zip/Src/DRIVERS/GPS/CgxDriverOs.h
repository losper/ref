/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
  \file
  \brief CellGuide CGX5900 driver OS depended prototypes

*/

#ifndef CGX_DRIVR_OS_H
#define CGX_DRIVR_OS_H

#include "CgReturnCodes.h"					/**< CellGuide Return codes definitions */




/**
	Sleep

    \param[in]  aTimeMS			Sleep for the specified time (in mili seconds)	
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverSleep(
	U32 aTimeMS);



	
/**
	Get internal buffer
	\note : TEMP/Noam !!! on linux, get internal allocated buffer. on wce, map external buffer

    \param[in]  pSource			Map pointer passed from application to the driver space
    \param[in]  aLength			Length allocated (bytes)
	
	\return Mapped pointer
	\retval NULL	on error

*/
void *CgxDriverGetInternalBuff(void *pSource, U32 aLength);

/**
	Allocate a kernel buffer

    \param[in]  pDriver			Pointer to driver structure
    \param[in]  length			Length to allocate (bytes)
	
	\return TBD...

*/
TCgReturnCode CgxDriverAllocInternalBuff(void *pDriver, unsigned long length, void **apBuffer, U32 aAppProcessId);




/**
	Free a kernel buffer

	\return TBD...

*/
TCgReturnCode CgxDriverFreeInternalBuff(void *pDriver, U32 aAppProcessId);




/**
	Copy Memory from User Space

    \param[in]  to				Target address (Kernel Space)
    \param[in]  fromuser		Source address (User Space)
    \param[in]  n      			Length to copy
	
	
	\return Number of bytes NOT copied (0=success)

*/
unsigned long CgxCopyFromUser(
	void *to,
	const void *fromuser,
	unsigned long n );




/**
	Allocate physical memory

    \param[in]  pDriver				Global driver structure pointer 	
    \param[in]  apPhysicalMemory	Physical memory structure pointer to be filled with the allocated memory information
    \param[in]  aSizeBytes			Size for allocation (in bytes)
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverAllocateChunkMemory(
	void *pDriver, 
	TCgxDriverPhysicalMemory *apPhysicalMemory, 
	U32 aSizeBytes);




/**
	Create transfer end signaling object.
	the object will be used for blocking the application until transfer is finished.

    \param[in]  pDriver			Global driver structure pointer 
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverTransferEndCreate(
	void *pDriver);


/**
	Destroy transfer end signaling object.

    \param[in]  pDriver			Global driver structure pointer 
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverTransferEndDestroy(
	void *pDriver);


/**
	Signal transfer end object

    \param[in]  pDriver			Global driver structure pointer 
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverTransferEndSignal(
	void *pDriver);

/**
	Clear signal from transfer end object

    \param[in]  pDriver			Global driver structure pointer 
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverTransferEndClear(
	void *pDriver);


/**
	Wait for transfer end object

    \param[in]  pDriver			Global driver structure pointer 
    \param[in]  aTimeoutMS		timeout for the wait, in mili seconds. 
								if the object is not singled after this time, the function will 
								return with ECgTimeout error code.
    \param[in]  apBuffer		handle to store the received buffer pointer (application memory space)
    \param[in]  aCount			pointer to hold size (in bytes) of transfer
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverTransferEndWait(
	void *pDriver, 
	U32 aTimeoutMS, 
	U8 **apBuffer, 
	U32 *aCount);




/**
	Start data ready interrupt handle

    \param[in]  pDriver			Global driver structure pointer 
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverDataReadyInterruptHandlerStart(
	void *pDriver);



/**
	Start general interrupt handler

    \param[in]  pDriver			Global driver structure pointer 
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverGeneralInterruptHandlerStart(
	void *pDriver);


/**
	Init driver

    \param[in]  pDriver			Global driver structure pointer 	

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverInit(
	void *pDriver);

TCgxDriverPhysicalMemory * GetDriverChunk(void * pDriver);

//2009.07.13 sunny
TCgReturnCode CgxDriverIdle(void *pDriver);
TCgReturnCode CgxDriverWakeup(void);

#endif
