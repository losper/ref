/************************************************************************************************
*	TCC8900 WinCE Board Support Package
*	-----------------------------------
*
*	FUNCTION	: TCC8900 GPS Driver
*	MODEL		: TCC8900 WinCE
*	CPU	NAME	: TCC8900
*
*	DEVISION	: DEPT. 2GROUP SOC 2 TEAM
*				: TELECHIPS, INC.
************************************************************************************************/
//
// Copyright (c) Telechips Corporation.  All rights reserved.
//
//
//
//------------------------------------------------------------------------------
//
//  Header: TCC8900_dma.h
//
//  Defines the interrupt controller register layout and associated interrupt
//  sources and bit masks.
//
#ifndef __TCC8900_DMA_H
#define __TCC8900_DMA_H

#if __cplusplus
extern "C" {
#endif

#define HwDMA0CON							*(volatile unsigned long *)0xF0540000   // general DMA0 controller Controller 
#define HwDMA1CON							*(volatile unsigned long *)0xF0540100	  // general DMA1 controller Controller
#define HwDMA2CON							*(volatile unsigned long *)0xF0540200	  // general DMA2 controller Controller 
#define HwDMA3CON							*(volatile unsigned long *)0xF0540300  // general DMA3 controller Controller

typedef	struct {
   volatile U32      ST_HCOUNT	  : 16;   // Start hop count : DMA transfers data by amount of an hop transfers
   volatile U32      C_HCOUNT	  : 16 ;  // current hop count 
} DMAHCOUNT;
typedef union{
	volatile U32 word;
	DMAHCOUNT bit;
} UDMAHCOUNT;

typedef	struct {
   volatile U32      EN	  : 1;   // channel enable
   volatile U32      REP	  : 1 ;  // repeat mode contrl 
   volatile U32      IEN	  : 1;   // interrupt enable
   volatile U32      FLG	  : 1 ;  // dma done flag
   volatile U32      WSIZE	  : 2;   // word size 0: 8bit 1:16bit 2,3:32bit
   volatile U32      BSIZE	  : 2 ;  // burst size
   volatile U32      TYPE	  : 2;   // 0: single transfer with edge-triggered detection 11:signel transfer with level-sensitive detection
                             // 01: HW transfer 10:SW transfer
   volatile U32      BST	  : 1 ;  // burst transfer
   volatile U32      LOCK  : 1;   // issue locked transfer
   volatile U32      HRD	  : 1 ;  // hardware request direction
   volatile U32      SYN	  : 1;   // hardware request synchronization
   volatile U32      DTM	  : 1 ;  // differential transfer mode
   volatile U32      CONT  : 1 ;  // issue continuous transfer
   volatile U32      reserv  : 16 ;  
} DMACHCTRL;
typedef union{
	volatile U32 word;
	DMACHCTRL bit;
} UDMACHCTRL;

typedef	struct {
   volatile U32      RPTCNT	  : 24;   // repeat count
   volatile U32      reserv	  : 6 ;  // 
   volatile U32      EOT	  : 1;   // 
   volatile U32      DRI	  : 1 ;  // disable repeat interrupt
} DMARPTCTRL;
typedef union{
	volatile U32 word;
	DMARPTCTRL bit;
} UDMARPTCTRL;

typedef	struct {
	volatile U32	ST_SADR;		// start address of source block
	volatile U32	SPARAM;			// parameter of source block
	volatile U32	reserv0;		
	volatile U32	C_SADR;			// current address of source block

	volatile U32	ST_DADR;		// start address of destination block
	volatile U32	DPARAM;			// parameter of destination block
	volatile U32	reserv1;		
	volatile U32	C_DADR;			// current address of destination block

	UDMAHCOUNT	HCOUNT;			// initial and current hop count
	UDMACHCTRL	CHCTRL;			// channel control register
	UDMARPTCTRL	RPTCTRL;		// repeat control register	
	U32	EXTREQ;			// external dma request register
} DMACH_REG, *PDMACH_REG;

typedef	struct {
   volatile U32      FIX			: 1;  // fixed priority operation 0:round-robin mode 1:fixed priority mode
   volatile U32      reserv0     : 3;  // Enables/Disables Tx FIFO overrun error interrupt
   volatile U32      PRI		    : 3;  // channel priority 000: ch0>ch1>ch2 001: ch0>ch2>ch1 010:ch1>ch0>ch2 011:ch1>ch2>ch0 100:ch2>ch1>ch0 101:ch2>ch0>ch1
   volatile U32		reserv1		: 1;
   volatile U32		SWP0		: 1;	// channel0 swap enable bit	
   volatile U32		SWP1		: 1;	// channel1 swap enable bit	
   volatile U32		SWP2		: 1;	// channel2 swap enable bit	
   volatile U32		reserv2		: 5;
   volatile U32		MIS0		: 1;	// read only - ch0 masked interrupt status 
   volatile U32		MIS1		: 1;	// read only - ch1 masked interrupt status 
   volatile U32		MIS2		: 1;	// read only - ch2 masked interrupt status 
   volatile U32		reserv3		: 1;
   volatile U32		IS0			: 1;	// read only - ch0 alternate interrupt status 
   volatile U32		IS1			: 1;	// read only - ch1 alternate interrupt status 
   volatile U32		IS2			: 1;	// read only - ch2 alternate interrupt status 
   volatile U32		reserv4		: 9;
} DMACHCONFIG_REG, *PDMACHCONFIG_REG;

typedef union{
	volatile U32 word;
	DMACHCONFIG_REG bit;
} UDMACHCONFIG_REG;

typedef	struct {
	DMACH_REG	ch0;		// channel0
	DMACH_REG	ch1;		// channel1
	DMACH_REG	ch2;		// channel2
	UDMACHCONFIG_REG	chconfig;		// channel configuration register
} TCC8900_DMA_REG, *PTCC8900_DMA_REG;

typedef PTCC8900_DMA_REG pTccdma;

#if CGX_IP == 5500
	#define HwGDMA_EXTREQB_GPS		(1<<15)
#else
	#define HwGDMA_EXTREQA_SPI0_TX	(1<<6)
	#define HwGDMA_EXTREQA_SPI0_RX	(1<<9)
#endif

#endif
