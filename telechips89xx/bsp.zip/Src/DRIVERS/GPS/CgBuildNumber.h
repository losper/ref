/* this file is automatically updated on build - DO NOT CHANGE! */

#define CG_BUILD_NUMBER     "3477"
#define CG_BUILD_DATE       "30/07/2009"
#define CG_BUILD_TIME       "17:22:35"
#define CG_BUILD_VERSION	"1.8.3"
#define CG_BUILD_ORIGINATOR	"Tomer"
