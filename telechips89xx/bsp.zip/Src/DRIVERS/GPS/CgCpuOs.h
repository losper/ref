/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
	\file 
	\brief Os depended services requires by CgCpu
 
	\defgroup CG_CPU_OS_API CPU OS Depended Abstraction API
	\{
*/

#ifndef CG_CPU_OS_H
#define CG_CPU_OS_H

#ifdef __cplusplus
    extern "C" 
    {
#endif


#include "CgReturnCodes.h"					/**< CellGuide Return codes */



/** \defgroup cg_cpu_os OS Depended Services

*/


/**
    \ingroup cg_cpu_os
	Map physical address space to virtual one

    \param[out]		pObject		Pointer to virtual address for physical memory region
    \param[in]		aBaseAddr	Base address (physical)
    \param[in]		aSize		Number of bytes 
	
	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgCpuVirtualAllocate(volatile void **pObject, unsigned long aBaseAddr, unsigned long aSize);


/**
    \ingroup cg_cpu_os
	Un-map physical address space to virtual one

    \param			pObject		Pointer to virtual address for physical memory region
	
	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgCpuVirtualFree(volatile void **pObject);


/**
    \ingroup cg_cpu_os
	Enter Kernel mode

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgCpuKernelModeEnter(void);

/**
    \ingroup cg_cpu_os
	Exit Kernel mode

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgCpuKernelModeExit(void);

/**
    \ingroup cg_cpu_os
	Cahce sync

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgCpuCacheSync(void);

/**
	Read host memory location

    \param[in]  aBaseAddr		Base address (e.g. GPS base address)
    \param[in]  aOffset			Offset
    \param[out] apValue			Read value

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxCpuReadMemory(U32 aBaseAddr, U32 aOffset, U32 *apValue);

/**
	Write host memory location

    \param[in]  aBaseAddr		Base address (e.g. GPS base address)
    \param[in]  aOffset			Offset
    \param[out] aValue			Read value

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxCpuWriteMemory(U32 aBaseAddr, U32 aOffset, U32 aValue);

TCgReturnCode CgxCpuSleep(U32 milliSeconds);


/**
	Debug facility - to show error messages
*/

#if defined(CGTEST) || defined(DEBUG)
	TCgReturnCode CgxCpuMsg(const char *aFuncName, const char *aFileName, U32 aLineNum, char *aFormat, ...);
	#define DBG_FUNC_NAME(name) const char *__funcname__ = name;
	#define DBGMSG(format) CgxCpuMsg(__funcname__, __FILE__, __LINE__, format);
	#define DBGMSG1(format,a) CgxCpuMsg(__funcname__, __FILE__, __LINE__, format, a);
	#define DBGMSG2(format,a,b) CgxCpuMsg(__funcname__, __FILE__, __LINE__, format, a,b);
	#define DBGMSG3(format,a,b,c) CgxCpuMsg(__funcname__, __FILE__, __LINE__, format, a,b,c);
	#define DBGMSG4(format,a,b,c,d) CgxCpuMsg(__funcname__, __FILE__, __LINE__, format, a,b,c,d);
	#define DBGMSG5(format,a,b,c,d,e) CgxCpuMsg(__funcname__, __FILE__, __LINE__, format, a,b,c,d,e);
	#define DBGMSG6(format,a,b,c,d,e,f) CgxCpuMsg(__funcname__, __FILE__, __LINE__, format, a,b,c,d,e,f);
	#define DBGMSG7(format,a,b,c,d,e,f,g) CgxCpuMsg(__funcname__, __FILE__, __LINE__, format, a,b,c,d,e,f,g);
#else
	#define DBG_FUNC_NAME(name) 
	#define DBGMSG(format) {}
	#define DBGMSG1(format,a) {}
	#define DBGMSG2(format,a,b) {}
	#define DBGMSG3(format,a,b,c) {}
	#define DBGMSG4(format,a,b,c,d) {}
	#define DBGMSG5(format,a,b,c,d,e) {}
	#define DBGMSG6(format,a,b,c,d,e,f) {}
	#define DBGMSG7(format,a,b,c,d,e,f,g) {}
#endif


#ifdef __cplusplus
    }
#endif

#endif 
/**
 \}
*/
