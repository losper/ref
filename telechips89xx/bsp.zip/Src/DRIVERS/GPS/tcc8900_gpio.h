/************************************************************************************************
*	TCC8900 WinCE Board Support Package
*	-----------------------------------
*
*	FUNCTION	: TCC8900 GPS Driver
*	MODEL		: TCC8900 WinCE
*	CPU	NAME	: TCC8900
*
*	DEVISION	: DEPT. 2GROUP SOC 2 TEAM
*				: TELECHIPS, INC.
************************************************************************************************/
//
// Copyright (c) Telechips Corporation.  All rights reserved.
//
//
//
//------------------------------------------------------------------------------
//
//  Header: TCC8900_gpio.h
//
//  Defines the interrupt controller register layout and associated interrupt
//  sources and bit masks.
//
#ifndef __TCC8900_GPIO_H
#define __TCC8900_GPIO_H

#if __cplusplus
extern "C" {
#endif

#define	HwGPIO_BASE  				*(volatile unsigned long *)0xF0102000  	// 
#define	HwGPIOA_BASE  				*(volatile unsigned long *)0xF0102000  	// 
#define	HwGPIOB_BASE  				*(volatile unsigned long *)0xF0102040  	// 
#define	HwGPIOC_BASE  				*(volatile unsigned long *)0xF0102080  	// 
#define	HwGPIOD_BASE  				*(volatile unsigned long *)0xF01020C0  	// 
#define	HwGPIOE_BASE  				*(volatile unsigned long *)0xF0102100  	// 
#define	HwGPIOF_BASE  				*(volatile unsigned long *)0xF0102140  	// 
#define	HwEINTSEL_BASE  			*(volatile unsigned long *)0xF0102180  	// 

typedef struct {
	volatile unsigned int	GPDAT;					// 0x000  R/W	GPA Data Register 
	volatile unsigned int	GPEN;					// 0x004  R/W	GPA Output Enable Register 
	volatile unsigned int	GPSET;					// 0x008  W  	OR function on GPA Output Data 
	volatile unsigned int	GPCLR;					// 0x00C  W  	BIC function on GPA Output Data 
	volatile unsigned int	GPXOR;					// 0x010  W  	XOR function on GPA Output Data 
	volatile unsigned int	GPCD0;					// 0x014  W  	Driver strength Control 0 on GPA Output Data 
	volatile unsigned int	GPCD1;					// 0x018  W  	Driver strength Control 1 on GPA Output Data 
	volatile unsigned int	GPPD0;					// 0x01C  W  	Pull-Up/Down function on GPA Output Data 
	volatile unsigned int	GPPD1;					// 0x020  W  	Pull-Up/Down function on GPA Output Data 
	volatile unsigned int	GPFN0;					// 0x024  W  	Port Configuration on GPA Output Data 
	volatile unsigned int	GPFN1;					// 0x028  W  	Port Configuration on GPA Output Data 
	volatile unsigned int	GPFN2;					// 0x02C  W  	Port Configuration on GPA Output Data 
	volatile unsigned int	GPFN3;					// 0x030  W  	Port Configuration on GPA Output Data 
} TCC8900_GPION, *PTCC8900_GPION;


/*******************************************************************************
*	 29. IOBUS Configuration Register Define   (Base Addr = 0xF05F5000)
********************************************************************************/
#define HwIOBUSCFG_BASE                             *(volatile unsigned long*)0xF05F5000

typedef struct {
    volatile unsigned int  USBOTG;                  // 0x00 Refer to USB OTG Configuration Register (OTGCR) in 15.2 register Description for USB 2.0 OTG Controller USB OTG Configuration register (OTGCR)USB OTG Configuration Register (OTGCR)USB OTG Configuration register (OTGCR)USB OTG Configuration Register (OTGCR)USB OTG Configuration Register (OTGCR).
    volatile unsigned int  USB11H;                  // 0x04 Refer to USB 1.1 Host Configuration Register (USB11H) in 14.2 register Description for USB 1.1 Host Controller & Transceiver
    volatile unsigned int  IOBAPB;                  // 0x08 IOBUS APB wait counter register
    volatile unsigned int  STORAGE;                 // 0x0C Storage Device Configuration Register
    volatile unsigned int  HCLKEN0;                 // 0x10 IOBUS AHB clock enable Register 0
    volatile unsigned int  HCLKEN1;                 // 0x14 IOBUS AHB clock enable Register 1
    volatile unsigned int  HCLKMEN;                 // 0x18 DMA AHB clock mask enable Register
    volatile unsigned int  NOTDEFINE0;              // 0x1C Reserved
    volatile unsigned int  HRSTEN0;                 // 0x20 IOBUS AHB Hreset Control register 0
    volatile unsigned int  HRSTEN1;                 // 0x24 IOBUS AHB Hreset Control register 1
    volatile unsigned int  USBOTG0;                 // 0x28 Refer to USB PHY Configuration Register0 (UPCR0) in 15.2 register Description for USB 2.0 OTG Controller
    volatile unsigned int  USBOTG1;                 // 0x2C Refer to USB PHY Configuration Register1 (UPCR1) in 15.2 register Description for USB 2.0 OTG Controller
    volatile unsigned int  USBOTG2;                 // 0x30 Refer to USB PHY Configuration Register2 (UPCR2) in 15.2 register Description for USB 2.0 OTG Controller
    volatile unsigned int  USBOTG3;                 // 0x34 Refer to USB PHY Configuration Register3 (UPCR3) in 15.2 register Description for USB 2.0 OTG Controller
    volatile unsigned int  IO_A2X;                  // 0x38 IOBUS AHB2AXI Control Register    
}TCC8900_IOBUSCFG, *PTCC8900_IOBUSCFG;

#if CGX_IP != 5500
typedef struct __GPIO{
	volatile unsigned int	GPADAT;					//   0x000  R/W  0x00000000  GPA Data Register 
	volatile unsigned int	GPAEN;					//   0x004  R/W  0x00000000  GPA Output Enable Register 
	volatile unsigned int	GPASET;					//   0x008  W  -  OR function on GPA Output Data 
	volatile unsigned int	GPACLR;					//   0x00C  W  -  BIC function on GPA Output Data 
	volatile unsigned int	GPAXOR;					//   0x010  W  -  XOR function on GPA Output Data 
	volatile unsigned int	GPACD0;					//   0x014  W  0x55555555  Driver strength Control 0 on GPA Output Data 
	volatile unsigned int	GPACD1;					//   0x018  W  0x00000000  Driver strength Control 1 on GPA Output Data 
	volatile unsigned int	GPAPD0;					//   0x01C  W  0x55555555  Pull-Up/Down function on GPA Output Data 
	volatile unsigned int	GPAPD1;					//   0x020  W  0x00000000  Pull-Up/Down function on GPA Output Data 
	volatile unsigned int	GPAFN0;					//   0x024  W  0x00000000  Port Configuration on GPA Output Data 
	volatile unsigned int	GPAFN1;					//   0x028  W  0x00000000  Port Configuration on GPA Output Data 
	volatile unsigned int	GPAFN2;					//   0x02C  W  0x00000000  Port Configuration on GPA Output Data 
	volatile unsigned int	GPAFN3;					//   0x030  W  0x00000000  Port Configuration on GPA Output Data 
	volatile unsigned int	NOTDEFINE0[3];			//	 0x034-0x03C     Reserved 
	volatile unsigned int	GPBDAT;					//   0x040  R/W  0x00000000  GPB Data Register 
	volatile unsigned int	GPBEN;					//   0x044  R/W  0x00000000  GPB Output Enable Register 
	volatile unsigned int	GPBSET;					//   0x048  W  -  OR function on GPB Output Data 
	volatile unsigned int	GPBCLR;					//   0x04C  W  -  BIC function on GPB Output Data 
	volatile unsigned int	GPBXOR;					//   0x050  W  -  XOR function on GPB Output Data 
	volatile unsigned int	GPBCD0;					//   0x054  W  0x55555555  Driver strength Control 0 on GPB Output Data 
	volatile unsigned int	GPBCD1;					//   0x058  W  0x00000000  Driver strength Control 1 on GPB Output Data 
	volatile unsigned int	GPBPD0;					//   0x05C  W  0x55555555  Pull-Up/Down function on GPB Output Data 
	volatile unsigned int	GPBPD1;					//   0x060  W  0x00000000  Pull-Up/Down function on GPB Output Data 
	volatile unsigned int	GPBFN0;					//   0x064  W  0x00000000  Port Configuration on GPB Output Data 
	volatile unsigned int	GPBFN1;					//   0x068  W  0x00000000  Port Configuration on GPB Output Data 
	volatile unsigned int	GPBFN2;					//   0x06C  W  0x00000000  Port Configuration on GPB Output Data 
	volatile unsigned int	GPBFN3;					//   0x070  W  0x00000000  Port Configuration on GPB Output Data 
	volatile unsigned int	NOTDEFINE1[3];			// 	 0x074-0x07C     Reserved 
	volatile unsigned int	GPCDAT;					//   0x080  R/W  0x00000000  GPC Data Register 
	volatile unsigned int	GPCEN;					//   0x084  R/W  0x00000000  GPC Output Enable Register 
	volatile unsigned int	GPCSET;					//   0x088  W  -  OR function on GPC Output Data 
	volatile unsigned int	GPCCLR;					//   0x08C  W  -  BIC function on GPC Output Data 
	volatile unsigned int	GPCXOR;					//   0x090  W  -  XOR function on GPC Output Data 
	volatile unsigned int	GPCCD0;					//   0x094  W  0x55555555  Driver strength Control 0 on GPC Output Data 
	volatile unsigned int	GPCCD1;					//   0x098  W  0x00000000  Driver strength Control 1 on GPC Output Data 
	volatile unsigned int	GPCPD0;					//   0x09C  W  0x55555555  Pull-Up/Down function on GPC Output Data 
	volatile unsigned int	GPCPD1;					//   0x0A0  W  0x00000000  Pull-Up/Down function on GPC Output Data 
	volatile unsigned int	GPCFN0;					//   0x0A4  W  0x00000000  Port Configuration on GPC Output Data 
	volatile unsigned int	GPCFN1;					//   0x0A8  W  0x00000000  Port Configuration on GPC Output Data 
	volatile unsigned int	GPCFN2;					//   0x0AC  W  0x00000000  Port Configuration on GPC Output Data 
	volatile unsigned int	GPCFN3;					//   0x0B0  W  0x00000000  Port Configuration on GPC Output Data 
	volatile unsigned int	NOTDEFINE2[3];			// 	 0x0B4-0x0BC Reserved 
	volatile unsigned int	GPDDAT;					//   0x0C0  R/W  0x00000000  GPD Data Register 
	volatile unsigned int	GPDEN;					//   0x0C4  R/W  0x00000000  GPD Output Enable Register 
	volatile unsigned int	GPDSET;					//   0x0C8  W  -  OR function on GPD Output Data 
	volatile unsigned int	GPDCLR;					//   0x0CC  W  -  BIC function on GPD Output Data 
	volatile unsigned int	GPDXOR;					//   0x0D0  W  -  XOR function on GPD Output Data 
	volatile unsigned int	GPDCD0;					//   0x0D4  W  0x55555555  Driver strength Control 0 on GPD Output Data 
	volatile unsigned int	GPDCD1;					//   0x0D8  W  0x00000000  Driver strength Control 1 on GPD Output Data 
	volatile unsigned int	GPDPD0;					//   0x0DC  W  0x55555555  Pull-Up/Down function on GPD Output Data 
	volatile unsigned int	GPDPD1;					//   0x0E0  W  0x00000000  Pull-Up/Down function on GPD Output Data 
	volatile unsigned int	GPDFN0;					//   0x0E4  W  0x00000000  Port Configuration on GPD Output Data 
	volatile unsigned int	GPDFN1;					//   0x0E8  W  0x00000000  Port Configuration on GPD Output Data 
	volatile unsigned int	GPDFN2;					//   0x0EC  W  0x00000000  Port Configuration on GPD Output Data 
	volatile unsigned int	GPDFN3;					//   0x0F0  W  0x00000000  Port Configuration on GPD Output Data 
	volatile unsigned int	NOTDEFINE3[3];			// 	 0x0F4-0x0FC     Reserved 
	volatile unsigned int	GPEDAT;					//   0x100  R/W  0x00000000  GPE Data Register 
	volatile unsigned int	GPEEN;					//   0x104  R/W  0x00000000  GPE Output Enable Register 
	volatile unsigned int	GPESET;					//   0x108  W  -  OR function on GPE Output Data 
	volatile unsigned int	GPECLR;					//   0x10C  W  -  BIC function on GPE Output Data 
	volatile unsigned int	GPEXOR;					//   0x110  W  -  XOR function on GPE Output Data 
	volatile unsigned int	GPECD0;					//   0x114  W  0x55555555  Driver strength Control 0 on GPE Output Data 
	volatile unsigned int	GPECD1;					//   0x118  W  0x00000000  Driver strength Control 1 on GPE Output Data 
	volatile unsigned int	GPEPD0;					//   0x11C  W  0x55555555  Pull-Up/Down function on GPE Output Data 
	volatile unsigned int	GPEPD1;					//   0x120  W  0x00000000  Pull-Up/Down function on GPE Output Data 
	volatile unsigned int	GPEFN0;					//   0x124  W  0x00000000  Port Configuration on GPE Output Data 
	volatile unsigned int	GPEFN1;					//   0x128  W  0x00000000  Port Configuration on GPE Output Data 
	volatile unsigned int	GPEFN2;					//   0x12C  W  0x00000000  Port Configuration on GPE Output Data 
	volatile unsigned int	GPEFN3;					//   0x130  W  0x00000000  Port Configuration on GPE Output Data 
	volatile unsigned int	NOTDEFINE4[3];			// 	 0x134-0x13C     Reserved 
	volatile unsigned int	GPFDAT;					//   0x140  R/W  0x00000000  GPF Data Register 
	volatile unsigned int	GPFEN;					//   0x144  R/W  0x00000000  GPF Output Enable Register 
	volatile unsigned int	GPFSET;					//   0x148  W  -  OR function on GPF Output Data 
	volatile unsigned int	GPFCLR;					//   0x14C  W  -  BIC function on GPF Output Data 
	volatile unsigned int	GPFXOR;					//   0x150  W  -  XOR function on GPF Output Data 
	volatile unsigned int	GPFCD0;					//   0x154  W  0x55555555  Driver strength Control 0 on GPF Output Data 
	volatile unsigned int	GPFCD1;					//   0x158  W  0x00000000  Driver strength Control 1 on GPF Output Data 
	volatile unsigned int	GPFPD0;					//   0x15C  W  0x55555555  Pull-Up/Down function on GPF Output Data 
	volatile unsigned int	GPFPD1;					//   0x160  W  0x00000000  Pull-Up/Down function on GPF Output Data 
	volatile unsigned int	GPFFN0;					//   0x164  W  0x00000000  Port Configuration on GPF Output Data 
	volatile unsigned int	GPFFN1;					//   0x168  W  0x00000000  Port Configuration on GP Output Data 
	volatile unsigned int	GPFFN2;					//   0x16C  W  0x00000000  Port Configuration on GPF Output Data 
	volatile unsigned int	GPFFN3;					//   0x170  W  0x00000000  Port Configuration on GPF Output Data 
	volatile unsigned int	NOTDEFINE5[4];			// 	 0x174-0x17C     Reserved 
	volatile unsigned int	EINTSEL0;				//   0x184  R/W  0x00000000  External Interrupt Select Register 01
	volatile unsigned int	EINTSEL1;				//   0x188  R/W  0x00000000  External Interrupt Select Register 1 
	volatile unsigned int	EINTSEL2;				//   0x18C  R/W  0x00000000  External Interrupt Select Register 2 
	volatile unsigned int	MON;					//   0x190  R/W  0x00000000  System Monitor Enable Register   
	volatile unsigned int	ECID0;					//   0x194  R/W  0x00000000  CID output Register 
	volatile unsigned int	ECID1;					//   0x198  R  -  CID serial input Register 
	volatile unsigned int	ECID2;					//   0x19C  R  -  CID parallel input 0 Register 
	volatile unsigned int	ECID3;					//   0x1A0  R  -  CID parallel input 1 Register     
}S0GPIO, *SPGPIO;
#endif
 #endif // _GPIO_H
