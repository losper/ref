/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
  \file
  \brief Driver platform depended API

*/

#ifndef _CGX_DRIVER_PLATFORM_H__
#define _CGX_DRIVER_PLATFORM_H__

#include "CgReturnCodes.h"					/**< CellGuide Return codes definitions */
#include "CgxDriverApi.h"					/**< CellGuide Driver API */

extern const TCgByteOrder CGX_DRIVER_NATIVE_BYTE_ORDER;

/**
    Write buffer to SPI.
    
    \param[in]  aSourceVirtualAddress		Address of the buffer to write (virtual memory)
    \param[in]  aSourcePhysicalAddress		Address of the buffer to write (physical memory)
	\param[in]  aLengthBytes				Length (in bytes) of the buffer to send

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverWriteData(unsigned char *aSourceVirtualAddress, U32 aSourcePhysicalAddress, U32 aLengthBytes);


/**
    Read buffer from SPI
    
    \param[in]  aTargetVirtualAddress		Address of the buffer to read (virtual memory)
    \param[in]  aTargetPhysicalAddress		Address of the buffer to read (physical memory)
	\param[in]  aLengthBytes				Length (in bytes) of the buffer to send

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverReadData(unsigned char *aTargetVirtualAddress, U32 aTargetPhysicalAddress, U32 aLengthBytes);


/**
code for data ready interrupt


\return interrupt code
*/
U32 CgxDriverDataReadyInterruptCode(void);

/**
code for data ready IRQ #
0 means no IRQ code 

\return IRQ # of DMA
*/
U32 CgxDriverDataReadyIrqCode(void);


/**
    code for general interrupt
    

    \return interrupt code
*/
U32 CgxDriverGeneralInterruptCode(void);





/**
	test data ready interrupt state    

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverIsDataReady(void);

/**
configure Data Ready interrupt pin & directions
this function is called once, on driver startup

\return System wide return code
\retval ECgOk Success
*/
TCgReturnCode CgxDriverDataReadyInterruptPrepare(void);


/**
    Read tail of snap data (only relevant when using FIFO)
    
    \param[in]  aTargetVirtualAddress		Address of the buffer to read (virtual memory)
    \param[in]  aTargetPhysicalAddress		Address of the buffer to read (physical memory)
	\param[in]  aLengthBytes				Length (in bytes) of the buffer to send

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverReadDataTail(unsigned char *aTargetVirtualAddress, U32 aTargetPhysicalAddress, U32 aLengthBytes);


/**
	wait until the SPI read is finished
    wait until DMA transfer is done

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverReadWait(void);


/**
	Clear data from buffer

    \param[in]  aTargetVirtualAddress		Address of the buffer to read (virtual memory)
    \param[in]  aTargetPhysicalAddress		Address of the buffer to read (physical memory)
	\param[in]  aLengthBytes				Length (in bytes) of the buffer to send

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverClearData(unsigned char *aTargetVirtualAddress, unsigned long aTargetPhysicalAddress, unsigned long aLengthBytes);

/**
	configure Data Ready interrupt pin & directions
    this function is called once, on driver startup

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverDataReadyPrepare(void);

/**
'close' the DMA_DONE interrupt by clearing the pending bit and re-enabling it	
*/

/**
'close' the GPS interrupt by clearing the pending bit and re-enabling it	
*/
TCgReturnCode  CGxDriverGpsInterruptDone(U32 aIntCode);

TCgReturnCode  CGxDriverDataReadyInterruptDone(U32 aIntCode);

/**
	set direction of 'cgx5900_data_ready' GPIO to be input and enable falling edge interrupt trigger
    this function is called once, on driver startup

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverInterruptPrepare(void);



/**
	set up the selected SPI channel
    this function is called once, on driver startup

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverSpiPrepare(void);


/**
	set up the Reset GPIO pin to output
    this function is called once, on driver startup

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverResetPrepare(void);



/**
    Return GPIO code for specific control line(for debug only)
    
    \param[in]		aPinNumber	GPIO code (cellguide format)
	\param[out]		aGpioCode	Pointer to returned value

	\return System wide return code
	\retval ECgOk Success
*/
TCgReturnCode CgxDriverGpioCode(int aPinNumber, int *aGpioCode);



/**
    Stop active transfer
    
	\return System wide return code
	\retval ECgOk Success
*/
void CgxDriverDataTransferStop(void);

#endif /* _CGX_DRIVER_PLATFORM_H__ */
