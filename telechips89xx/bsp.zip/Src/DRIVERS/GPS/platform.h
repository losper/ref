/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
	\file 
	\brief TCC8900 specific defines

	\defgroup CGX_DRIVER_PLATFORM_WCE TCC8000/WCE specific defines
	\{
	The following values are specific to the TCC8900 / WCe implementation.
	for other platforms, please select appropriate values.

 */
#ifndef PLATFORM_H
#define PLATFORM_H

#include "CgCpuTCC8900.h"
#include <windows.h>
#include <Giisr.h>							/**< Windows CE shared interrupt support */

#define CGX_PLATFORM_NAME "TCC8900"

/** \name Interrupt codes
	BSP definitions for required interrupt codes 
	\{
 */


/** DMA interrupt event name
	This interrupt is handled by BSP code, which generated windows event on interrupt.
	the event name must be the same as the one defined in the BSP code
 */
#define CGX_DRIVE_DMA_INT_EVENT_NAME NULL

//#define DRIVE_DMA_INT_SHARED_LIBRARY_NAME
//#define DRIVER_DMA_INT_SHARED_HANDLER_NAME
//#define DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO

const TCHAR * CGX_DRIVE_DMA_INT_SHARED_LIBRARY_NAME;
const TCHAR * CGX_DRIVER_DMA_INT_SHARED_HANDLER_NAME;
GIISR_INFO CGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO;
const GIISR_INFO	*	pCGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO;

/** DMA multi block mode
	Defines the method of executing consequtive DMA transfers.
	There are 3 different possible methods : 
	LLI - means that the DMA needs to be configured only once, and no extra tx commands should be issued
	PENDING - means that after receiving the first GPS data interrupt, the DMA should issue the next task, so it is prepared for it.
	NONE - means that the DMA should prepared for the next task, only after receiving the DMA interrupt for tx-done.
*/

#define CG_DRIVER_DMA_MULTI_BLOCK_MODE CG_DRIVER_DMA_MULTI_BLOCK_MODE_NONE

/** GPS interrupt event name
	This interrupt is handled by BSP code, which generated windows event on interrupt.
	the event name must be the same as the one defined in the BSP code
 */
#define CGX_DRIVE_GPS_INT_EVENT_NAME NULL

#define CG_DRIVER_DMA_CHANNEL_READ		(0) /* This value is hard coded! do not change!*/
#define CG_DRIVER_DMA_CHANNEL_WRITE		(1) /* This value is hard coded! do not change!*/

// Choose the SPI mode - Manual or DMA
//////////////////////////////////////////////////////////////////////////

	#define WRITE_MODE	(CG_CPU_SPI_MODE_DMA)
	#define READ_MODE	(CG_CPU_SPI_MODE_DMA)

	//#define WRITE_MODE	(CG_CPU_SPI_MODE_MANUAL)
	//#define READ_MODE	(CG_CPU_SPI_MODE_MANUAL)

//////////////////////////////////////////////////////////////////////////
// Choose the SPI mode - Manual or DMA	 (END)

/** 
	\} 
 */ // Interrupt codes

/** \name Memory mapping
	Memory addresses for various units
	\{
 */

/** The virtual base address for CGX5500 registers */
//#define CG_CPU_CGX5000_BASE_PA		(0xF053A000)	

/** The virtual base address for accessing GPIO controller */
//#define CG_DRIVER_GPIO_BASE_VA		(0xB2005000)

/** The virtual base address for accessing the interrupt controller */
//#define CG_DRIVER_INT_BASE_VA		(0x98003000)

/** The virtual base address for accessing the DMA controller */
//#define CG_DRIVER_DMA_BASE_VA		(0xB0004000)

/** The virtual base address for accessing the clock/reset controller */
//#define CG_DRIVER_RESET_BASE_VA		(0xB2006000)

#define RTC_BASE_PA	(0x98012000)	/**< RTC Controller base address */
#define RTC_LAST_PA	(0x98012100)

#define CGX5000_RESET		(CG_CPU_GPIO_GROUP_D + 17)
#define CGX5000_SPI_CS		(CG_CPU_GPIO_GROUP_D + 15)	
#define CGX5000_DR			(CG_CPU_GPIO_GROUP_D + 18)	

#define SPI_MOSI			(CG_CPU_GPIO_GROUP_D + 20)	
#define SPI_CLK				(CG_CPU_GPIO_GROUP_D + 16)	
#define SPI_MISO			(CG_CPU_GPIO_GROUP_D + 19)	

//#define CGX5000_INT			(CG_CPU_GPIO_GROUP_D + 9)

#define SPI_CHANNEL		(0)

#define SPI_PRESCALE	(0)

/** 
	\} // Memory addresses
*/ 
/** 
	\} 
*/ 

#endif /* PLATFORM_H */
