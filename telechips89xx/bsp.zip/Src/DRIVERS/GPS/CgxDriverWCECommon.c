/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */

/**
  \file 
  \brief Microsoft Windows CE specific driver code

  Specific code required for the CellGuide GPS driver integration with Microsoft Windows CE.
  \defgroup CGX_DRIVER_WCE Windows CE Implementation
  \{
*/

#include <windows.h>                /**< Windows CE main include file */
#include <pkfuncs.h>				/**< Windows CE include file */
#include "CgTypes.h"				/**< CellGuide types */
#include "CgReturnCodes.h"			/**< CellGuide return codes */
#include "CgCpu.h"					/**< CellGuide CPU API */
#include "CgxDriverCore.h"			/**< CellGuide Driver OS in-depended logic */
#include "CgxDriverOs.h"			/**< CellGuide Driver OS specific  */
#include "CgxDriverPlatform.h"		/**< CellGuide Driver platform specific */
#include "platform.h"				/**< CellGuide Driver platform info  */
#include "CgxDriverWCE.h"           /**< Windows device driver definitions */



/** 
	Internal semaphore name, used to block application on synchronous requests.
	/note WCE is Unicode. 
*/
#ifdef _WIN32_WCE
	#define RCV_SEM_NAME L"CgxDriverSem"
#else
	#define RCV_SEM_NAME "CgxDriverSem"
#endif


/** Default value for Data ready IST priority, if not specifically defined in platform.h */
#ifndef CG_DRIVER_DATA_READY_IST_PRIORITY
	#define CG_DRIVER_DATA_READY_IST_PRIORITY	(5)
#endif

/** Default value for GPS IST priority, if not specifically defined in platform.h */
#ifndef CG_DRIVER_GPS_IST_PRIORITY
	#define CG_DRIVER_GPS_IST_PRIORITY			(6)
#endif





#ifndef CG_CPU_CGX5000_BASE_VA
#define CG_CPU_CGX5000_BASE_VA (0)
#endif



/**
	Main function for Data ready interrupt service thread (IST)

    \param[in]  plvParam			Pointer to the driver global data structure
	
	\return 0 = success

*/
static DWORD WINAPI DataReadyISTMain(LPVOID plvParam)
{
	DWORD dwStatus = 0;
	
	#ifndef CGX_IP
		#if ( (_WIN32_WCE < 0x600) )	// Windows CE5 and below 
			// Only for 5900, and WCE5 and below
			DWORD bMode = SetKMode(TRUE); 
			DWORD dwPerm = SetProcPermissions(0xFFFFFFFF);
		#endif
	#endif


	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)plvParam;
    if (pDriverInfo->dataReadyIST.event == NULL)  {
        return 0;
		}
	
	// loop until told to stop
	while(!pDriverInfo->state.flags.terminate) {
		dwStatus = WaitForSingleObject(pDriverInfo->dataReadyIST.event, INFINITE);
		// Make sure we have the object
        switch(dwStatus)  {
            case WAIT_FAILED:
                dwStatus = GetLastError();
				RETAILMSG(1,(TEXT("\r\n[DataReadyISTMain] wait_Failed %X"),dwStatus));
                break;
            case WAIT_OBJECT_0:
				CgxDriverDataReadyInterruptHandler(plvParam, &pDriverInfo->state);
				CGxDriverDataReadyInterruptDone(pDriverInfo->dataReadyIST.intCode);
                break;
            case WAIT_ABANDONED:
 				RETAILMSG(1,(TEXT("\r\n[DataReadyISTMain] WAIT_ABANDONED")));
           case WAIT_TIMEOUT:
  				RETAILMSG(1,(TEXT("\r\n[DataReadyISTMain] WAIT_TIMEOUT %X"),dwStatus));
          default:
                break;
			}
		}
	return 0;
}




/**
	Main function for Device interrupt service thread (IST)

    \param[in]  plvParam			Pointer to the driver global data structure
	
	\return System wide return code

*/
static DWORD  WINAPI GpsISTMain( LPVOID plvParam)
{
	DBG_FUNC_NAME("GpsISTMain")
	DWORD dwStatus = 0;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)plvParam;

	DBGMSG("Start")

	// loop until told to stop
	while(!pDriverInfo->state.flags.terminate) {

		// wait for the interrupt event...
		dwStatus = WaitForSingleObject(pDriverInfo->gpsIST.event, INFINITE);
//		DBGMSG1("Status = %d", dwStatus)

		// Make sure we have the object
        switch (dwStatus)  {
            case WAIT_FAILED:
                dwStatus = GetLastError();
                break;
            case WAIT_OBJECT_0:
	            CgxDriverGpsInterruptHandler(pDriverInfo, &pDriverInfo->state);
				CGxDriverGpsInterruptDone(pDriverInfo->gpsIST.intCode);
                break;
            case WAIT_ABANDONED:
            case WAIT_TIMEOUT:
            default:
                break;
			}
		}
	return 0;
}









/**
	Create transfer end synchronization object (semaphore)

    \param[in]  pDriver			Pointer to the driver global data structure
	
	\return System wide return code
	\retval ECgOK				On success
	\retval ECgGeneralFailure	On any error

*/
TCgReturnCode CgxDriverTransferEndCreate(void *pDriver)
{
	DBG_FUNC_NAME("CgxDriverTransferEndCreate")
	TCgReturnCode rc = ECgOk;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)pDriver;
	
	pDriverInfo->transferEndSemaphore = CreateSemaphore(
		NULL, //LPSECURITY_ATTRIBUTES lpSemaphoreAttributes, 
		0, //LONG lInitialCount, 
		1, // TODO ??? LONG lMaximumCount, 
		RCV_SEM_NAME); //LPCTSTR lpName 
		
	if (pDriverInfo->transferEndSemaphore == NULL) {
		//error
		DWORD err = GetLastError();
		rc = ECgGeneralFailure;
		DBGMSG1("Failed to create Transfer End object (%d)", err)
		}

	return rc;
}



/**
	Destroy transfer end synchronization object (semaphore)

    \param[in]  pDriver			Pointer to the driver global data structure
	
	\return System wide return code
	\retval ECgOK				On success
	\retval ECgGeneralFailure	On any error

*/
TCgReturnCode CgxDriverTransferEndDestroy(void *pDriver)
{
	DBG_FUNC_NAME("CgxDriverTransferEndDestroy")
	TCgReturnCode rc = ECgOk;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)pDriver;

	if( (pDriverInfo->transferEndSemaphore) && CloseHandle(pDriverInfo->transferEndSemaphore) == 0) {
		DWORD err = GetLastError();
		rc = ECgGeneralFailure;
		DBGMSG1("Failed to create Transfer End object (%d)", err)
		}
	pDriverInfo->transferEndSemaphore = NULL;
	return rc;
}


/**
	Signal transfer end synchronization object (semaphore)

    \param[in]  pDriver			Pointer to the driver global data structure
	
	\return System wide return code
	\retval ECgOK				On success
	\retval ECgGeneralFailure	On any error

*/
TCgReturnCode CgxDriverTransferEndSignal(void *pDriver)
{
	DBG_FUNC_NAME("CgxDriverTransferEndSignal")
	TCgReturnCode rc = ECgOk;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)pDriver;
	BOOL b = ReleaseSemaphore(pDriverInfo->transferEndSemaphore, 1, NULL);
	if (b == 0) {
		//error
		DWORD err = GetLastError();
		rc = ECgGeneralFailure;
		DBGMSG1("Failed to signal Transfer End object (%d)", err)
		}

	return rc;
}


HINSTANCE hInst = NULL;                     /**< DLL instance handle */
long g_DllCnt = 0;                   /**< Global DLL reference count */


/**
	DllMain - DLL initialization entry point
    \param[in]  hinstDLL			See windows documentation
    \param[in]  dwReason			See windows documentation
    \param[in]  lpvReserved			See windows documentation
*/
BOOL WINAPI DllMain (HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved) 
{
    hInst = hinstDLL;
    switch (dwReason) {
        case DLL_PROCESS_ATTACH:
			break;
        case DLL_PROCESS_DETACH:
            break;
        default:
            break;
    }
    return TRUE;
}








/**
	CGX_Close - Called when driver closed
    \param[in]  dwOpen			See windows documentation
*/
BOOL CGX_Close (DWORD dwOpen)
{
    PDRVCONTEXT pDrv = (PDRVCONTEXT) dwOpen;

    if (!pDrv) 
        return 0;
		
    if (pDrv->dwSize != sizeof (DRVCONTEXT)) 
        return 0;
		
    if (pDrv->nNumOpens)
        pDrv->nNumOpens--;
    
    return TRUE;
}


/**
	CGX_Read - Called when driver read
    \param[in]  dwOpen			See windows documentation
    \param[in]  pBuffer			See windows documentation
    \param[in]  dwCount			See windows documentation
*/
DWORD CGX_Read (DWORD dwOpen, LPVOID pBuffer, DWORD dwCount)
{
    return 0;
}


/**
	CGX_Write - Called when driver written
    \param[in]  dwOpen			See windows documentation
    \param[in]  pBuffer			See windows documentation
    \param[in]  dwCount			See windows documentation
*/
DWORD CGX_Write (DWORD dwOpen, LPVOID pBuffer, DWORD dwCount)
{
    return 0;
}


/**
	CGX_Seek - Called when SetFilePtr called
    \param[in]  dwOpen			See windows documentation
    \param[in]  lDelta			See windows documentation
    \param[in]  wType			See windows documentation
*/
DWORD CGX_Seek (DWORD dwOpen, long lDelta, WORD wType)
{
    return 0;
}


/**
	CGX_Open - Called when driver opened
    \param[in]  dwContext			See windows documentation
    \param[in]  dwAccess			See windows documentation
    \param[in]  dwShare			See windows documentation
*/
DWORD CGX_Open (DWORD dwContext, DWORD dwAccess, DWORD dwShare)
{
	DBG_FUNC_NAME("CGX_Open")
    PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DBGMSG1("start. pDrv = 0x%08x", pDrv)

    // Verify that the context handle is valid.
    if (!pDrv) 
        return 0; 
		
    if (pDrv->dwSize != sizeof (DRVCONTEXT)) 
	{
		DBGMSG2("pDrv->dwSize = %d != %d", pDrv->dwSize, sizeof (DRVCONTEXT))
        return 0;
	}
		
    // Count the number of opens.
    InterlockedIncrement (&pDrv->nNumOpens);

	DBGMSG("end")

    return (DWORD)pDrv;
}

#ifndef DRIVE_DMA_INT_SHARED_LIBRARY_NAME
	#define CGX_DRIVE_DMA_INT_SHARED_LIBRARY_NAME			NULL
#endif

#ifndef DRIVER_DMA_INT_SHARED_HANDLER_NAME
	#define CGX_DRIVER_DMA_INT_SHARED_HANDLER_NAME			NULL
#endif

#ifndef DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO
	#define pCGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO	NULL
#endif

#ifndef CGX_DRIVE_DMA_INT_EVENT_NAME
	#define CGX_DRIVE_DMA_INT_EVENT_NAME					NULL
#endif

TCgReturnCode CgxDriverDataReadyInterruptHandlerStart(void *pDriver)
{
	TCgReturnCode rc = ECgOk;
	DRVCONTEXT *pDriverInfo = (DRVCONTEXT *)pDriver;
	CgCpuISTStart(	&pDriverInfo->dataReadyIST, DataReadyISTMain, CG_DRIVER_DATA_READY_IST_PRIORITY, 
		CgxDriverDataReadyInterruptCode(),	CgxDriverDataReadyIrqCode(), pDriverInfo, 
		CGX_DRIVE_DMA_INT_EVENT_NAME, (void*)pCGX_DRIVER_DMA_SHARED_INTERRUPT_HANDLER_INFO, (void*)(CGX_DRIVE_DMA_INT_SHARED_LIBRARY_NAME), 
		(void*)(CGX_DRIVER_DMA_INT_SHARED_HANDLER_NAME) );
	return rc;
}

/** Microsoft driver code */
#ifdef DEBUG
DBGPARAM dpCurSettings = {
    TEXT("CgxDriver"), {
    TEXT("Errors"),TEXT("Warnings"),TEXT("Functions"),
    TEXT("Init"),TEXT("Driver Calls"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"), TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined") },
    0x0003
};
#endif //DEBUG

/* 	\}*/
