/************************************************************************************************
*	TCC8900 WinCE Board Support Package
*	-----------------------------------
*
*	FUNCTION	: TCC8900 GPS Driver
*	MODEL		: TCC8900 WinCE
*	CPU	NAME	: TCC8900
*
*	DEVISION	: DEPT. 2GROUP SOC 2 TEAM
*				: TELECHIPS, INC.
************************************************************************************************/
#ifndef  _TCC8900_SPI_H_
#define  _TCC8900_SPI_H_


#define HwGPSBCH0_BASE              *(volatile unsigned long *)0xF0536000
#define HwGPSBCH1_BASE              *(volatile unsigned long *)0xF0536100
#define HwGPSBCH2_BASE              *(volatile unsigned long *)0xF0536200
#define HwGPSBCH3_BASE              *(volatile unsigned long *)0xF0536300
#define HwGPSBCH4_BASE              *(volatile unsigned long *)0xF0536400
#define HwGPSBCH5_BASE              *(volatile unsigned long *)0xF0536500
#define HwGPSBPORTCFG_BASE          *(volatile unsigned long *)0xF0536800
#define HwGPSBPIDTABLE_BASE         *(volatile unsigned long *)0xF0536F00

/*#define HwGPSBCH0_BASE              *(volatile unsigned long *)0xF0570000
#define HwGPSBCH1_BASE              *(volatile unsigned long *)0xF0570100
#define HwGPSBCH2_BASE              *(volatile unsigned long *)0xF0570200
#define HwGPSBCH3_BASE              *(volatile unsigned long *)0xF0570300
#define HwGPSBCH4_BASE              *(volatile unsigned long *)0xF0570400
#define HwGPSBCH5_BASE              *(volatile unsigned long *)0xF0570500
#define HwGPSBPORTCFG_BASE          *(volatile unsigned long *)0xF0570800
#define HwGPSBPIDTABLE_BASE         *(volatile unsigned long *)0xF0570F00
*/

#define	HwGPSB_PIDT(X)				*(volatile unsigned long *)(HwGPSBPIDTABLE_BASE+(X)*4)	// R/W, PID Table Register
#define	HwGPSB_PIDT_CH2				Hw31											// Channel 2 enable
#define	HwGPSB_PIDT_CH1				Hw30											// Channel 1 enable
#define	HwGPSB_PIDT_CH0				Hw29											// Channel 0 enable

/*******************************************************************************
*	 17. General Purpose Serial Bus (GPSB) Register Define   (Base Addr = 0xF0057000)
********************************************************************************/

typedef  struct {
   volatile unsigned int      RTH      : 1;  // receive buffer valid flag
   volatile unsigned int      WTH      : 1;  // transmit buffer valid flag
   volatile unsigned int      RNE      : 1;  // receive buffer empty flag
   volatile unsigned int      WE       : 1;  // transmit buffer empty flag
   volatile unsigned int      RF       : 1;  // receive buffer full flag
   volatile unsigned int      ROR      : 1;  // receive buffer overrun flag
   volatile unsigned int      WUR      : 1;  // transmit buffer underrun flag
   volatile unsigned int      RUR      : 1;  // receive buffer underrun flag
   volatile unsigned int      WOR      : 1;  // transmit buffer overrun flag
   volatile unsigned int               : 7;
   volatile unsigned int      RBVCNT   : 8;  // receive buffer valid count ( lower 4 bits are valid )
   volatile unsigned int      WBVCNT   : 8;  // transmit buffer valid count ( lower 4 bits are valid )
}  GPSB_STAT;

typedef  union {
   volatile unsigned int         word;
   GPSB_STAT   bit;
}  GPSB_STAT_U;

typedef  struct {
   volatile unsigned int      	RTH     : 1;  	// receive buffer valid flag
   volatile unsigned int      	WTH     : 1;  	// transmit buffer valid flag
   volatile unsigned int      	RNE     : 1;  	// receive buffer empty flag
   volatile unsigned int      	WE      : 1;  	// transmit buffer empty flag
   volatile unsigned int      	RF      : 1;  	// receive buffer full flag
   volatile unsigned int      	ROR     : 1;  	// receive buffer overrun flag
   volatile unsigned int      	WUR     : 1;  	// transmit buffer underrun flag
   volatile unsigned int      	RUR     : 1;  	// receive buffer underrun flag
   volatile unsigned int      	WOR     : 1;  	// transmit buffer overrun flag
   volatile unsigned int				: 6;
   volatile unsigned int		RC		: 1;  	// clear interrupt at read enable
   volatile unsigned int		CFGRTH  : 4;  	// 3 bits are valid
   volatile unsigned int		CFGWTH	: 4;  	// 3 bits are valid
   volatile unsigned int		SBR		: 1;	// Rx byte swap in word
   volatile unsigned int		SHR		: 1;	// Rx half-word swap in word
   volatile unsigned int		SBT		: 1;	// Tx byte swap in half-word
   volatile unsigned int		SHT		: 1;	// Tx half-word swap in word
   volatile unsigned int				: 2;
   volatile unsigned int		DR      : 1;	// DMA request enable for receive FIFO
   volatile unsigned int		DW      : 1;	// DMA request enable for transmit FIFO
}  GPSB_INTEN;

typedef  union {
   volatile unsigned int         word;
   GPSB_INTEN  bit;
} GPSB_INTEN_U;

typedef  struct {
   volatile unsigned int      MD       : 2;  // mode, 0 : SPI mode, 1 : TI mode, 2 : MW, 3 : reserved
   volatile unsigned int      SLV      : 1;  // slave mode enable ( 1 for slave )
   volatile unsigned int      EN       : 1;  // enable ( 1 for enable )
   volatile unsigned int      CTF      : 1;  // continuous transfer enable
   volatile unsigned int	:1 ;			 // volatile unsigned int     SDO      : 1;  // SDO output enable
   volatile unsigned int      LB       : 1;  // Loop back enable
   volatile unsigned int      SD       : 1;  // Shift right enable
   volatile unsigned int      BWS      : 5;  // shift counter load value
   volatile unsigned int               : 1;
   volatile unsigned int      CWF      : 1;  // transmit fifo clear
   volatile unsigned int      CRF      : 1;  // receive fifo clear
   volatile unsigned int      PCK      : 1;  // clock polarity
   volatile unsigned int      PRD      : 1;  // receive data at falling edge
   volatile unsigned int      PWD      : 1;  // send at rising edge
   volatile unsigned int      PCD      : 1;  // command polarity
   volatile unsigned int      PCS      : 1;  // chip select polarity --> not-used
   volatile unsigned int      TSU      : 1;  // setup time
   volatile unsigned int      THL      : 1;  // hold time
   volatile unsigned int      TRE      : 1;  // recovery time
   volatile unsigned int      DIVLDV   : 8;  // divider load value
}  GPSB_MODE;

typedef  union {
   volatile unsigned int         word;
   GPSB_MODE   bit;
}  GPSB_MODE_U;

typedef  struct {
   volatile unsigned int      PSW      : 5;  // position for write command
   volatile unsigned int               : 2;
   volatile unsigned int      PLW      : 1;  // polarity control for write command
   volatile unsigned int      RDSTART  : 8;  // data read start position            : 5 bits are valid
   volatile unsigned int      CMDSTART : 8;  // command start position           : 5 bits are valid
   volatile unsigned int      CMDEND   : 5;  // command end position
   volatile unsigned int               : 1;
   volatile unsigned int      LCR      : 1;  // disable last sck output (read)
   volatile unsigned int      LCW      : 1;  // disable last sck output (write)
}  GPSB_CTRL;

typedef  union {
   volatile unsigned int         word;
   GPSB_CTRL   bit;
} GPSB_CTRL_U;

typedef  struct {
   volatile unsigned int      SIZE     :16;  // 13 bits are valid
   volatile unsigned int      COUNT    :16;  // 13 bits are valid
} GPSB_PACKET;

typedef  union {
   volatile unsigned int            word;
   GPSB_PACKET bit;
}  GPSB_PACKET_U;

typedef  struct {
   volatile unsigned int      EN       : 1;  // dma enable
   volatile unsigned int	:1;	
   volatile unsigned int      PCLR	:1;	// clear Tx/Rx packet counter
   volatile unsigned int	:1;
   volatile unsigned int      MD       : 2;  // mode selection register
                           // 0 : normal mode, 1 : mpeg2-ts mode, 2,3 : reserved
   volatile unsigned int	:8;
   volatile unsigned int	RXAM	:2;	// Rx addressing mode '0':Multiple Packet (base) '1':fixed address '2':,'3':Single Packet
   volatile unsigned int	TXAM	:2;	// Tx addressing mode '0':Multiple Packet (base) '1':fixed address '2':,'3':Single Packet
   volatile unsigned int      MS       : 1;  // sync byte matching enable for mpeg2-ts mode
   volatile unsigned int      MP       : 1;  // pid table matching enable for mpeg2-ts mode
   volatile unsigned int               : 8;
   volatile unsigned int      END      : 1;  // endian selection bit
                           // 0 for little-endian
                           // 1 for big-endian
   volatile unsigned int      CT       : 1;  // continuous mode enable ( master only )
                           // '1' for enable
   volatile unsigned int      DRE      : 1;  // receive dma request enable : 1 for enable
   volatile unsigned int      DTE      : 1;  // transmit dma request enable : 1 for enable
} GPSB_DMACTR;

typedef  union {
   volatile unsigned int         word;
   GPSB_DMACTR bit;
}  GPSB_DMACTR_U;

typedef  struct {
   volatile unsigned int      TXPCNT   : 16;  // 13 bits are valid
   volatile unsigned int      RXPCNT   : 16;  // 13 bits are valid
}  GPSB_DMASTR;

typedef  union {
   volatile unsigned int            word;
   GPSB_DMASTR    bit;
}  GPSB_DMASTR_U;

typedef struct {
   volatile unsigned int      IRQPCNT   : 16;  // 13 bits are valid
   volatile unsigned int      IEP   : 1;  //	IRQ enable for 'Packet ineterrupt'
   volatile unsigned int	IED	  : 1; //	IRQ enalbe fore 'Done Interrupt'
   volatile unsigned int	:2;
   volatile unsigned int	IRQS  :1; // IRQ select register '0' for receive '1' for transmit
   volatile unsigned int	:7;
   volatile unsigned int 	ISP:1;	// IRQ status for 'Packet interrupt'
   volatile unsigned int	ISD:1;	// IRQ status for 'Done interrupt'
   volatile unsigned int	:2;   
} GPSB_DMAICR;

typedef union {
   volatile unsigned int            word;
   GPSB_DMAICR    bit;
} GPSB_DMAICR_U;

typedef union {
	volatile unsigned int word;
} GPSB_DUMMY;

typedef struct {
    volatile unsigned int   PORT;               // 0x000 R/W 0x0000 Data port
    GPSB_STAT_U				STAT;               // 0x004 R/W 0x0000 Status register
    GPSB_INTEN_U			INTEN;              // 0x008 R/W 0x0000 Interrupt enable
    GPSB_MODE_U				MODE;               // 0x00C R/W 0x0004 Mode register
    GPSB_CTRL_U				CTRL;               // 0x010 R/W 0x0000 Control register
    volatile unsigned int   EVTCTRL;            // 0x014 R/W 0x0000 Counter & Ext. Event Control
    volatile unsigned int   CCV;                // 0x018 R 0x0000 Counter Current Value
    volatile unsigned int   NOTDEFINE0;
    volatile unsigned int   TXBASE;             // 0x020 R/W 0x0000 TX base address register
    volatile unsigned int   RXBASE;             // 0x024 R/W 0x0000 RX base address register
    GPSB_PACKET_U   		PACKET;             // 0x028 R/W 0x0000 Packet register
    GPSB_DMACTR_U   		DMACTR;             // 0x02C R/W 0x0000 DMA control register
    GPSB_DMASTR_U   		DMASTR;             // 0x030 R/W 0x0000 DMA status register
    GPSB_DMAICR_U   		DMAICR;             // 0x034 R/W 0x0000 DMA interrupt control register
}TCC89X_SPI_REG, *PTCC89X_SPI_REG;


typedef struct {
    volatile unsigned int   PCFG0;              // 0x800 R/W 0x03020100 Port Configuration Register 0
    volatile unsigned int   PCFG1;              // 0x804 R/W 0x00000504 Port Configuration Port Config Register 1
    volatile unsigned int   CIRQST;             // 0x808 R 0x0000 Channel IRQ Status Register   
}GPSBportcfg, *pGPSBportcfg;




typedef PTCC89X_SPI_REG pTccspi;

#endif
