/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
	\file 
	\brief CellGuide platform specific 

	\defgroup CG_CPU_TCC8900 Telechips TCC8900 CPU Specific
	\{
*/
#include <windows.h>                 // For all that Windows stuff
#include <winioctl.h>
#include <pkfuncs.h>

//Kernel Ioctl
#include <ioctl_code.h>
#include <ioctl_gpiostr.h>

#include "CgReturnCodes.h"					/**< CellGuide return codes */
#include "CgCpu.h"							/**< CellGuide CPU abstraction aPI*/
#include "CgCpuOs.h"						/**< CellGuide CPU, OS depended abstraction aPI*/
#include "CgCpuTCC8900.h"					/**< Telechips TCC8900 CPU specific definitions */

//#include "CgOsSemaphore.h"
#include "platform.h"

#include "tcc8900_dma.h"
#include "tcc8900_intr.h"

//#define CGX_IP NONE	// can be NONE or 5500

static pTccintr				pIntr = NULL;
static PTCC8900_IOBUSCFG	iobuscfg = NULL;
static pTccdma				gDMACs = NULL;	// The base virtual address of DMA controllers
static volatile void		* gGPSVA = NULL;	// Virtual address of CG_CPU_CGX5500_BASE_PHYS (entire GPS block)
static volatile U32			* gGPSCLK = NULL;
static volatile U32			* gGPSRST = NULL;
static U32					* gGpsVa = NULL;

#ifndef CGX_IP
	#include <Giisr.h>							/**< Windows CE shared interrupt support */

//	static pTccspi				sSPICBaseVA = NULL;	// Used for allocation and deallocation
	static pTccspi				sSPIC = NULL;	// gpsb2 - port12
	SPGPIO pGpio = NULL;
	static PSCKC ckc = NULL;

	typedef struct {
		U32 addr;
		U8 *ptr;
		U32 length;
	} TCPhysicalMemory;

	typedef struct {
		int			sysintr;
		int			irq;
		HANDLE		intrevent;
	} GPS_DMA_INFO;

	static TCPhysicalMemory		tempTx = {0},tempRx = {0}; 
	static GPS_DMA_INFO			dma_info = {0};

	TCgReturnCode CgCpuGpioIntCode(unsigned long aPin, unsigned long *aCode);
	TCgReturnCode CgCpuGpioIntSource(unsigned long aPin, unsigned long *aSource);
	void SetGPSBClock(int iFreq);

#endif


/*********************************************************** DMA *************************/
static TCgReturnCode EnableDMA(U32 aDmaChannel)
{
    TCgReturnCode rc = ECgOk;

	//enable DMA iobus
	iobuscfg->HCLKEN0 |= (0x1<<3);	//dma clock enable
	iobuscfg->HRSTEN0 &= ~(0x1<<3); //dma reset
	iobuscfg->HRSTEN0 |= (0x1<<3);

    return rc;
}

// Source Address Mask Register. 
//Each bit field controls the dedicated bit of source address field. That is, if SMASK[23] is set  to 1, the 28th bit of source
//address is masked, and if SMASK[22] is set to 1, the 27th bit of source address is masked, and so on. If a bit is masked, a
//corresponding bit of address bus is not changed during DMA transfer. This function can be used to generate circular buffer
//address. 
#define DMA_MASK(x) (((x & 0xffffff) << 8) & 0xffffff00)


//The addresses of DMA transfer have 32bit wide, but the upper 4bit of them are not affected during DMA transfer. If 
//the source or destination address reaches its maximum address space like 0x7FFFFFFF or 0x2FFFFFFF, the next 
//transfer is starting from 0x70000000 or 0x20000000 not from 0x80000000 or 0x30000000. 
#define DMA_INC(x) (x) 

TCgReturnCode GetDmaController(U32 aDmaChannel, TCC8900_DMA_REG ** appController)
{
	TCgReturnCode rc = ECgOk;

	switch (CG_DMA_CONTROLLER(aDmaChannel))
	{
	case 0:
		*appController = gDMACs;
		break;
	case 1:
		*appController = (TCC8900_DMA_REG*)((U32)gDMACs + (U32)(&HwDMA1CON)-(U32)(&HwDMA0CON));
		break;
	case 2:
		*appController = (TCC8900_DMA_REG*)((U32)gDMACs + (U32)(&HwDMA2CON)-(U32)(&HwDMA0CON));
		break;
	case 3:
		*appController = (TCC8900_DMA_REG*)((U32)gDMACs + (U32)(&HwDMA3CON)-(U32)(&HwDMA0CON));
		break;
	default :
		*appController = NULL;
		rc = ECgNotSupported;
	}

	return rc;
}

TCgReturnCode GetDmaChannel(U32 aDmaChannel, DMACH_REG ** appChannel)
{
	TCgReturnCode rc = ECgOk;
	pTccdma pDma = NULL;

	rc = GetDmaController(aDmaChannel, &pDma);

	if ( OK(rc) )
	{
		switch(CG_DMA_CHANNEL(aDmaChannel)) 
		{
		case 0:
			*appChannel = (DMACH_REG*)&(pDma->ch0);
			break;
		case 1:
			*appChannel = (DMACH_REG*)&(pDma->ch1);
			break;
		case 2:
			*appChannel = (DMACH_REG*)&(pDma->ch2);
			break;
		default: 
			*appChannel = NULL;
			rc = ECgNotSupported;
			break;
		}
	}

	return rc;
}



TCgReturnCode CgCpuDmaIsValid(int aDmaChannel)
{
	DBG_FUNC_NAME("CgCpuDmaIsValid")
	DBGMSG("Start")

	if (CG_DMA_CHANNEL(aDmaChannel) > 32)   {
		DBGMSG1("Invalid DMA channel! %d", CG_DMA_CHANNEL(aDmaChannel));
		return ECgBadArgument;
		}
	return ECgOk;
}


TCgReturnCode CgCpuDmaIsReady(int aDmaChannel)
{
	TCgReturnCode rc = ECgOk;

	return rc;
}


TCgReturnCode CgCpuDmaCurCount(int aDmaChannel, U32 *apCount)
{
	TCgReturnCode rc = ECgOk;
	
    DMACH_REG *pCh = NULL;
	
	rc = GetDmaChannel(aDmaChannel, &pCh);
	
	if( OK(rc) )
	{
		//*apCount = pCh->HCOUNT.bit.C_HCOUNT * 16;
		// TODO : remove this patch vvvvvvvvvvvvvvvvvvvv and unremark the former remarked line ^^^^^^^^^^^^^^^^^^
		*apCount = pCh->HCOUNT.bit.ST_HCOUNT * 16;
	}

	return rc;
}


TCgReturnCode CgCpuDmaRequestedCount(int aDmaChannel, U32 *apCount)
{
	TCgReturnCode rc = ECgOk;

    DMACH_REG *pCh = NULL;

	rc = GetDmaChannel(aDmaChannel, &pCh);

	if ( OK(rc) )
		*apCount = pCh->HCOUNT.bit.ST_HCOUNT * 16;
	
	return rc;
}



TCgReturnCode CgCpuDmaSetupFromCgx5500(TCgCpuDmaTask *apDmaTask, U32 aDmaTaskCount, U32 aDmaChannel, U32 aDeviceAddress)
{
	TCgReturnCode rc = ECgOk;
    DMACH_REG *pCh = NULL;
    volatile U32 * pEXTREQB = NULL;
    volatile pTccintr pIntr = NULL;
    U32 intMask = 0;

	if (aDmaTaskCount == 0)
		rc = ECgBadArgument;
        
	if ( OK(rc) )
		rc = GetDmaChannel(aDmaChannel, &pCh);

	if (OK(rc))	{
		U32 length = apDmaTask[0].length &~ CG_DMA_SUBBLOCK_FLAG;	
		
        // address setup
        pCh->ST_DADR = apDmaTask[0].address;
		
        // transfer length setup
        pCh->HCOUNT.bit.ST_HCOUNT = (apDmaTask->length/16) & 0xFFFF;	// 1 burst at one hop / 1 burst is 4bytes*4cycles
        // TODO max block size = 16 * 0xFFFF = 1MB
        // transfer start
        pCh->CHCTRL.bit.IEN = 0;	
        pCh->CHCTRL.bit.EN = 0;	
        pCh->CHCTRL.bit.FLG = 1;	
        pCh->CHCTRL.bit.EN = 1;	
        pCh->CHCTRL.bit.IEN = 1;	
	}

	return rc;
}


U32 CgCpuDmaAddr(U32 aDmaChannel)
{
	DMACH_REG *pCh = NULL;

	GetDmaChannel(aDmaChannel, &pCh);

	return (U32)&(pCh->CHCTRL);
}

TCgReturnCode CgCpuDmaSetupFromCgx5500NextTask(TCgCpuDmaTask *apDmaTask, U32 aDmaTaskCount, U32 aActiveTaskIndex, U32 aDmaChannel, U32 aDeviceAddress)
{
	DBG_FUNC_NAME("CgCpuDmaSetupFromCgx5500NextTask")
	TCgReturnCode rc = ECgOk;
	
	DMACH_REG *pCh = NULL;

	DBGMSG("Start")

	rc = GetDmaChannel(aDmaChannel, &pCh);

	if ( OK(rc) )
	{
		// address setup
		pCh->ST_DADR = apDmaTask[aActiveTaskIndex].address;
		
		// transfer length setup
		pCh->HCOUNT.bit.ST_HCOUNT = (apDmaTask[aActiveTaskIndex].length/16) & 0xFFFF;	// 1 burst at one hop / 1 burst is 4bytes*4cycles
		// TODO max block size = 16 * 0xFFFF = 1MB
		// transfer start
		pCh->CHCTRL.bit.IEN = 0;	
		pCh->CHCTRL.bit.EN = 0;	
		pCh->CHCTRL.bit.FLG = 1;	
		pCh->CHCTRL.bit.EN = 1;	
		pCh->CHCTRL.bit.IEN = 1;	
	}

	return rc;
}



TCgReturnCode CgCpuDmaTaskDone(U32 aDmaChannel)
{
	TCgReturnCode rc = ECgOk;
	
	DMACH_REG *pCh = NULL;

	//DBGMSG("Done")

	rc = GetDmaChannel(aDmaChannel, &pCh);

	if ( OK(rc) )
	{
		// transfer start
		pCh->CHCTRL.bit.EN = 0;	
		pCh->CHCTRL.bit.FLG = 1;	
	}

	return rc;


}


/*********************************************************** GPIO *************************/

static TCgReturnCode GpioSet(unsigned long aPin, unsigned long aValue)
{
	DBG_FUNC_NAME("GpioSet")
	TCgReturnCode rc = ECgOk;

	unsigned long group = aPin / CG_CPU_GPIO_GROUP_SIZE;
	unsigned long pin = aPin % CG_CPU_GPIO_GROUP_SIZE;

	DBGMSG3("pin: GP%c%d = 0x%08x", 'A' + group - 1 , pin, aValue);

    rc = CgCpuGpioMode(aPin, ECG_CPU_GPIO_OUTPUT);

	if (OK(rc)) switch(group) 
	{
		case CG_CPU_GPIO_GROUP_INDEX_D: 
			REG_SET1(gpiod->GPDAT, pin, aValue); 
			break;
		default: rc = ECgBadArgument; break;
	}

	return rc;
}



TCgReturnCode CgCpuGpioSet(unsigned long aPin)
{
	return GpioSet(aPin, 1);
}




TCgReturnCode CgCpuGpioReset(unsigned long aPin)
{
	return GpioSet(aPin, 0);
}



TCgReturnCode CgCpuGpioGet(unsigned long aPin, int *aValue)
{
	DBG_FUNC_NAME("CgCpuGpioGet")
	TCgReturnCode rc = ECgOk;

	unsigned long group = aPin / CG_CPU_GPIO_GROUP_SIZE;
	unsigned long pin = aPin % CG_CPU_GPIO_GROUP_SIZE;
	
	DBGMSG2("pin: GP%c%d", 'A' + group - 1 , pin);

	rc = CgCpuGpioMode(aPin, ECG_CPU_GPIO_INPUT);
    	switch(group) 
	{
		case CG_CPU_GPIO_GROUP_INDEX_D: 
			*aValue = (0 != (gpiod->GPDAT & (1 << pin))); 
			RETAILMSG(0,(TEXT("\n\r CgCpuGpioGet D%d %d"),pin,*aValue));
			break;
		default: rc = ECgBadArgument; break;
	}
	
	return rc;
}


TCgReturnCode CgCpuGpioMode(unsigned long aPin, TCgCpuGpioMode aMode)
{
	DBG_FUNC_NAME("CgCpuGpioMode")
	TCgReturnCode rc = ECgOk;
	unsigned long group = aPin / CG_CPU_GPIO_GROUP_SIZE;
	unsigned long pin = aPin % CG_CPU_GPIO_GROUP_SIZE;

	DBGMSG2("pin: GP%c%d", 'A' + group - 1 , pin);

	if (aMode >= ECG_CPU_GPIO_MODE___)
		return ECgBadArgument; 

	#if CGX_IP == 5500
		if (aMode == ECG_CPU_GPIO_INPUT) 
		{
			switch(group) 
			{
			case CG_CPU_GPIO_GROUP_INDEX_D: 
				if( pin < 8 )
				{
					REG_SET4(gpiod->GPFN0,pin,0);
				}
				else if(pin>=8 && pin <16)
				{
					REG_SET4(gpiod->GPFN1,pin-8,0);
				}
				else if(pin>=16 && pin <24)
				{
					REG_SET4(gpiod->GPFN2,pin-16,0);
				}
				else if(pin>=24 && pin <32)
				{
					REG_SET4(gpiod->GPFN3,pin-24,0);
				}

				REG_SET1(gpiod->GPEN, pin,0);

				break;

			default: 	
				rc = ECgBadArgument;
				break;
			}
		}
		else if (aMode == ECG_CPU_GPIO_OUTPUT) {
			switch(group) {
				case CG_CPU_GPIO_GROUP_INDEX_D: 
					if( pin < 8 )
					{
						REG_SET4(gpiod->GPFN0,pin,0);
					}
					else if(pin>=8 && pin <16)
					{
						REG_SET4(gpiod->GPFN1,pin-8,0);
					}
					else if(pin>=16 && pin <24)
					{
						REG_SET4(gpiod->GPFN2,pin-16,0);
					}
					else if(pin>=24 && pin <32)
					{
						REG_SET4(gpiod->GPFN3,pin-24,0);
					}
					
					REG_SET1(gpiod->GPEN, pin,1);
					break;
				

				default: 	
					rc = ECgBadArgument;
					break;
			}
		}
	#elif CGX_IP != 5500

		if (aMode == ECG_CPU_GPIO_INPUT) 
		{
			switch(aPin) 
			{
			case CGX5000_DR: 
				gpiod->GPFN2 &= ~0x00000f00; // (18)
				REG_SET1(gpiod->GPEN,pin,0);

				pIntr->IEN0 &= ~HwINT0_EI6;	
				pIntr->SEL0 &= ~HwINT0_EI6;
				break;

			default:
				break;
			}
		}
		else if (aMode == ECG_CPU_GPIO_OUTPUT) 
		{
			switch(aPin) 
			{
			case CGX5000_RESET: 
				gpiod->GPFN2 &= ~0x000000f0; //reset
				REG_SET1(gpiod->GPEN, pin,1);
				break;
			case CGX5000_SPI_CS:
				gpiod->GPFN1 &= ~0xf0000000; //cs
				REG_SET1(gpiod->GPEN, pin,1);
				break;
			case SPI_MOSI:
				REG_SET4(gpiod->GPFN2,pin - 16,0);
				REG_SET1(gpiod->GPEN, pin,1);
				break;
			case SPI_CLK:
				REG_SET4(gpiod->GPFN2,pin - 16,0);
				REG_SET1(gpiod->GPEN, pin,1);
				break;
			case SPI_MISO:
				REG_SET4(gpiod->GPFN2,pin - 16,0);
				REG_SET1(gpiod->GPEN, pin,1);
				break;
			case CGX5000_DR: 
				REG_SET4(gpiod->GPFN2,pin - 16,0);
				REG_SET1(gpiod->GPEN, pin,1);
				break;
			default :
				break;
			}
		}
		else if (aMode == ECG_CPU_GPIO_FALLING_INT) 
		{
			switch(aPin) 
			{
			case CGX5000_DR: 
				gpiod->GPFN2 &= ~0x00000f00; // (18)

				REG_SET1(gpiod->GPEN, pin,0);

				//connect ext intr 4 with gpio18 2009/07/13 sunny to block the unexpected dr after cancel
				if((pGpio->EINTSEL1&0x1b0000)!= 0x1b0000)
				{
				  pGpio->EINTSEL1 &= ~(0xff0000); //EI6 gpiod18(27) 
				  pGpio->EINTSEL1 |= 0x1b0000;
				}

				pIntr->POL0 |= HwINT0_EI6;		// Low Active
				pIntr->MODE0 &= ~HwINT0_EI6;		// edge

				pIntr->CLR0 |= HwINT0_EI6;	/* Clear EXT interrupt */
				pIntr->SEL0 |= HwINT0_EI6;
				pIntr->INTMSK0 |= HwINT0_EI6;
				pIntr->IEN0 |= HwINT0_EI6;	

				break;

			default:
				break;	
			}
		}

	#endif
	else
	{
		rc = ECgBadArgument;
	}

	
	return rc;

}

void CgCpuDRMaskOn()
{
	pIntr->INTMSK0 |= HwINT0_EI6;
}

void CgCpuDRCheck()
{
	printf("\n\r INTMSK0 %x IRQ0 %x",pIntr->INTMSK0,pIntr->IRQ0);
}


TCgReturnCode CgCpuReset(U32 aUnitIndex)
{
	DBG_FUNC_NAME("CgCpuReset")

	TCgReturnCode rc = ECgOk;
	// TODO NG : change to use physical address + mapping
	// TODO NG : reset RTC
	// TODO NG : reset BS

	DBGMSG("Start")
		
	switch (aUnitIndex)  {
		case CG_CPU_RESET_BIT_CGX5500_CORE:

			// make sure the entire GPS is not reset...
			iobuscfg->HCLKEN0 |= (0x1<<CG_CPU_RESET_BIT_GPS);
			iobuscfg->HRSTEN0 |= (0x1<<CG_CPU_RESET_BIT_GPS);

			*(U32 *)gGPSRST |= (0x1<<CG_CPU_RESET_BIT_CGX5500_CORE);
			*(U32 *)gGPSRST &= ~(0x1<<CG_CPU_RESET_BIT_CGX5500_CORE);
			
			*(U32 *)gGPSCLK |= (0x1<<CG_CPU_RESET_BIT_CGX5500_RTC_EN)|(0x1<<CG_CPU_RESET_BIT_CGX5500_GSM_EN)|(0x1<<CG_CPU_RESET_BIT_CGX5500_BS_EN)|(0x1<<CG_CPU_RESET_BIT_CGX5500_TCXO_POL);
			
			break;

		case CG_CPU_RESET_BIT_CGX5500_TCXO:
			// make sure the entire GPS is not reset...
			//iobuscfg->HRSTEN0 &= ~(0x1<<CG_CPU_RESET_BIT_GPS);
			//iobuscfg->HRSTEN0 |= (0x1<<CG_CPU_RESET_BIT_GPS);
			//iobuscfg->HCLKEN0 |= (0x1<<CG_CPU_RESET_BIT_GPS);

			*(U32 *)gGPSRST |= (0x1<<CG_CPU_RESET_BIT_CGX5500_TCXO);
			*(U32 *)gGPSRST &= ~(0x1<<CG_CPU_RESET_BIT_CGX5500_TCXO);

			break;
		}
	

	DBGMSG("End")
	return rc;
}

extern U32 CGX5500_BASE_ADDR_VA;


TCgReturnCode VirtualAllocateGpioSun(void **pObject, unsigned long aBaseAddr, unsigned long aSize)
{
	TCgReturnCode rc = ECgOk;

	int retVal = -1;
	stgpioioctl stGPIO = {0};
	stgpioinfo	stGPIOInfo = {0};
	unsigned long	returnedbyte = 0;

	stGPIO.ioctlcode = IOCTL_GPIO_PATOVA;
	stGPIO.iphysicalbaseaddress = aBaseAddr;
	//	stGPIO.isize = isize;

	retVal = KernelIoControl(IOCTL_HAL_TCCGPIO, &stGPIO, sizeof(stgpioioctl), &stGPIOInfo, sizeof(stgpioinfo), &returnedbyte);
	*pObject = (void*)stGPIOInfo.returnaddress;

	return (retVal ? rc : ECgGeneralFailure);
}

TCgReturnCode CgCpuAllocateVa()
{
	DBG_FUNC_NAME("CgCpuAllocateVa")

    TCgReturnCode rc = ECgOk;
//	CgCpuVirtualAllocate((void**)&gGpsVa,(U32)&(CG_CPU_CGX5000_BASE_PA),sizeof(U32));
	RETAILMSG(0,(TEXT("\n\r[CgCpuAllocateVa]%x"),gGpsVa));

	//initialize the virtual address 
	if ( OK(rc) )	rc = VirtualAllocateGpioSun((void**)&gpiod,		(U32)&(HwGPIOD_BASE),	sizeof(TCC8900_GPION));
	if ( OK(rc) )	rc = VirtualAllocateGpioSun((void**)&gDMACs,	(U32)&(HwDMA0CON),		sizeof(TCC8900_DMA_REG));	// Allocate enough memory for all DMACs
	#if CGX_IP == 5500
		if ( OK(rc) )	rc = CgCpuVirtualAllocate((void**)&pIntr,	(U32)&(HwPIC_BASE),		sizeof(TCC8900_INTR_REG));
		if ( OK(rc) )	rc = CgCpuVirtualAllocate((void**)&iobuscfg,(U32)&(HwIOBUSCFG_BASE),sizeof(TCC8900_IOBUSCFG));
		if ( OK(rc) )	rc = CgCpuVirtualAllocate((void**)&CGX5500_BASE_ADDR_VA, CG_CPU_CGX5500_BASE_PHYS, 0x1000);	// Entire GPS block consists of slightly less than 4KB (0x1000) 
		if ( OK(rc) )	gGPSCLK = (U32*)(CGX5500_BASE_ADDR_VA + (U32)(&CG_CPU_TCC8900_GPSCLK) - CG_CPU_CGX5500_BASE_PHYS);	// We can't allocate to the GPSCLK address directly, because its not a multiple of 4KB (I guess)
		if ( OK(rc) )	gGPSRST = (U32*)(CGX5500_BASE_ADDR_VA + (U32)(&CG_CPU_TCC8900_GPSRST) - CG_CPU_CGX5500_BASE_PHYS);	// We can't allocate to the GPSRST address directly, because its not a multiple of 4KB (I guess)
	#else
		if ( OK(rc) )	rc = VirtualAllocateGpioSun((void**)&pIntr,	(U32)&(HwPIC_BASE),		sizeof(TCC8900_INTR_REG));
		if ( OK(rc) )	rc = VirtualAllocateGpioSun((void**)&iobuscfg,(U32)&(HwIOBUSCFG_BASE),sizeof(TCC8900_IOBUSCFG));
		if ( OK(rc) )	rc = VirtualAllocateGpioSun((void**)&pGpio,		(U32)&(HwGPIO_BASE),	sizeof(GPIO));	// HwEINTSEL_2 is the last register
	#endif

	DBGMSG1("rc = %d", rc)
	return rc;
}

#if CGX_IP == 5500

TCgReturnCode CgCpuGPSPrepare()
{
    	TCgReturnCode rc = ECgOk;
	//////////////////////////////////////////////////////////////////////////
	// CgCpuGpsPrepare
	//////////////////////////////////////////////////////////////////////////

	// real input | tcxo clock input (D24,D21)
	gpiod->GPFN3 &= ~0x0000000f;
	gpiod->GPFN3 |= 0x00000004;
	gpiod->GPFN2 &= ~0x00f00000;
	gpiod->GPFN2 |= 0x00400000;

	gpiod->GPCD1 &= ~0x00030c00;
	gpiod->GPPD1 &= ~0x00030c00;
	
	//GpiopD15,D16,D17  rf_reset,rf_idle#,rf_shdn#
	gpiod->GPFN1 &= ~0xf0000000;
	gpiod->GPFN2 &= ~0x000000ff;
	
	gpiod->GPCD0 &= ~0xc0000000;
	gpiod->GPPD0 &= ~0xc0000000;
	gpiod->GPCD1 &= ~0x0000000f;
	gpiod->GPPD1 &= ~0x0000000f;

	gpiod->GPDAT |= (0x1<<15)|(0x1<<16)|(0x1<<17);
	gpiod->GPEN |=  (0x1<<15)|(0x1<<16)|(0x1<<17);
	gpiod->GPDAT &= ~(0x1<<15);
	CgxCpuSleep(1);
	gpiod->GPDAT |= (0x1<<15);
	
	//prepare gpio port for virtual spi interface GPIOD18,19,20 ( clk,cs,data ) 
	gpiod->GPFN2 &= ~0x000fff00;

	gpiod->GPCD1 &= ~0x000003f0;
	gpiod->GPPD1 &= ~0x000003f0;
	
	// cs:active low, clk:rising edge 
	// cs : 1 & clk: 0 & data : 0
	gpiod->GPDAT &= ~((0x1<<18)&(0x1<<19)&(0x1<<20));
	gpiod->GPEN |=((0x1<<18)&(0x1<<19)&(0x1<<20));


	return rc;
	
}



TCgReturnCode CgCpuDmaCreate(U32 aDmaChannel, U32 aIpDataSourceAddress)
{
	DBG_FUNC_NAME("CgCpuDmaCreate")
    TCgReturnCode rc = ECgOk;
    DMACH_REG *pCh = NULL;
	TCC8900_DMA_REG * pDMAC = NULL;

	RETAILMSG(0,(TEXT("\n\r[CgCpuDmaCreate]")));
	if (OK(rc)) rc = EnableDMA(aDmaChannel);
	if (OK(rc))	rc = GetDmaChannel(aDmaChannel, &pCh);
	if (OK(rc))	rc = GetDmaController(aDmaChannel, &pDMAC);

	DBGMSG1("pCh = 0x%x", pCh)

	if ( OK(rc) )
	{
        // channel configuration setup
        pCh->ST_SADR = aIpDataSourceAddress; // Start Source Address Register = CGX5500 'window' address [PHYSICAL!]
		
        // 4 byte jump at one cycle
        // CGX5500 has a window of 4 dword (16bytes), and we use burst, so, NEVER advance src address
        pCh->SPARAM = DMA_MASK(0xffffff) | DMA_INC(4); 
		
        // 4 byte jump at one cycle
        pCh->DPARAM = DMA_MASK(0) | DMA_INC(4); 	
		
		// data source
		pCh->EXTREQ = HwGDMA_EXTREQB_GPS;

		pDMAC->chconfig.bit.FIX = 0; // ROUND-ROBIN
		pDMAC->chconfig.bit.PRI = 0; // ch0>ch1>ch2
		pDMAC->chconfig.bit.SWP0 = 1; // do not swap data to be written to destination address
		pDMAC->chconfig.bit.SWP1 = 0;
		pDMAC->chconfig.bit.SWP2 = 0;
			
		// channel control setup
		pCh->CHCTRL.word = 0;
		pCh->CHCTRL.bit.WSIZE = 2;  // 4 byte transfer at each cycle
		pCh->CHCTRL.bit.BSIZE = 2;  // at 1 burst transfer 0:1 1:2 2:4 3:8
		pCh->CHCTRL.bit.TYPE = 0;	// 0: single transfer with edge 3: signel transfer with level 1: HW 2: SW
		pCh->CHCTRL.bit.BST = 0;    // burst mode 0=off,1=on 
		pCh->CHCTRL.bit.LOCK = 0;   // meaningful in case of non-burst type transfer
		pCh->CHCTRL.bit.HRD = 1;    // hardware request direction 0: when dma-read operation 1:when dam_write operation
		pCh->CHCTRL.bit.SYN = 0;    // do not synchronize hardware request   (for UT, I2S, CAN)
		pCh->CHCTRL.bit.DTM = 0;    // Differential Transfer Mode [0 =Disable,  1 =Enable]
		pCh->CHCTRL.bit.FLG = 1;    // clear 'done' flag
		pCh->CHCTRL.bit.IEN = 0;    // interrupt enable // TODO NG
		pCh->CHCTRL.bit.REP = 0;    // repeat mode : 0=after done, DMA is disabled, 1= continue to work after done
		
		// 0  DMA transfer begins from ST_SADR / ST_DADR address 
		// 1  DMA transfer begins from C_SADR / C_DADR address. 
		// It must be used after the former transfer has been executed, so that C_SADR and 
		// C_DADR contain a meaningful value. 
		pCh->CHCTRL.bit.CONT = 0;
		pCh->CHCTRL.bit.EN = 0;     // 0= disabled, 1=Enabled
		//pIntr->CLR0 |= 0x1<<IRQ0_DMA;	/* Clear GDMA interrupt */
		pIntr->SEL0 |= 0x1<<IRQ0_DMA;			/* Set GDMA interrupt as IRQ */
		pIntr->MODE0 &= ~(0x1<<IRQ0_DMA);
		pIntr->POL0 &= ~(0x1<<IRQ0_DMA);
	}

	return rc;
}

TCgReturnCode CgCpuDmaDestroy(U32 aDmaChannel, U32 aIpDataSourceAddress)
{
	return CgCpuDmaStop(aDmaChannel);
}


TCgReturnCode CgCpuDmaStop(int aDmaChannel)
{
	TCgReturnCode rc = ECgOk;

	DMACH_REG *pCh;

	rc = GetDmaChannel(aDmaChannel,&pCh);

	if ( OK(rc) )
		pCh->CHCTRL.bit.EN = 0;

	return rc;
}

TCgReturnCode CgCpuDmaStart(int aDmaChannel)
{
	TCgReturnCode rc = ECgOk;

	// TODO - complete

	return rc;
}

#else


TCgReturnCode CgCpuDmaStart(int aDmaChannel)
{
	TCgReturnCode rc = ECgOk;

	sSPIC->DMACTR.bit.EN = 1;

	return rc;
}

BOOL set_interrupt(int irq, int sys_irq)
{
	HANDLE m_hGpsbIsrHandler = NULL;

	//Install ISR 
	m_hGpsbIsrHandler = LoadIntChainHandler(L"tcc_giisr.dll", L"GPSBISRHandler", irq);
	if(m_hGpsbIsrHandler == NULL){
		DWORD dwRet = GetLastError();	
		RETAILMSG(1,(TEXT("LoadIntChainHandler return fail ")));			
		return FALSE;
	}
	else{
		RETAILMSG(0,(TEXT("LoadIntChainHandler success\r\n")));					
	}

	// Set up ISR handler
	if(m_hGpsbIsrHandler){
		GIISR_INFO Info = {0};
//		memset(&Info, 0, sizeof(GIISR_INFO));
		Info.CheckPort = TRUE; //irq happen then chk port <-> false means don't chk port == no shared IRQ
		Info.PortIsIO = FALSE; // memory mapped - not real port (TRUE only used X86)
		Info.SysIntr = sys_irq;
		Info.PortSize = sizeof(DWORD);// size of GPSB_CIRQST
		Info.UseMaskReg = FALSE;
		Info.MaskAddr = 0;

		Info.Mask = 1 << 29;//GPSB DMA IRQ status register for channel 2
		Info.PortAddr = (DWORD)&(sSPIC->DMAICR.word);

		if (!KernelLibIoControl(m_hGpsbIsrHandler, IOCTL_GIISR_INFO,  &Info, sizeof(GIISR_INFO), NULL, 0, 0)){
			DWORD dwRet = GetLastError();	
			RETAILMSG(1,(TEXT("KernelLibIoControl return fail %d\r\n")));			
			return FALSE;
		}
		else
			RETAILMSG(0,(TEXT("KernelLibIoControl return success\r\n")));
	}

	return TRUE;
}

TCgReturnCode CgCpuDmaCreate(U32 aDmaChannel, U32 aIpDataSourceAddress)
{
	TCgReturnCode rc = ECgOk;

	dma_info.irq = IRQ1_GPSB + 32;	// second table starts from 32

	if( !KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &dma_info.irq, 
		sizeof(DWORD), &dma_info.sysintr, sizeof(DWORD), NULL) ) {
			rc = ECgGeneralFailure;
	}

	// IISR
	if ( OK(rc) )	set_interrupt(dma_info.irq, dma_info.sysintr);
	if ( OK(rc) )	dma_info.intrevent = CreateEvent(0, FALSE, FALSE, NULL);
	if ( !dma_info.intrevent )
		rc = ECgGeneralFailure;

	if (OK(rc) ) if ( !(InterruptInitialize(dma_info.sysintr, dma_info.intrevent, 0, 0)) ) {
		rc = ECgGeneralFailure;
	}
	
	// transfer temp buffer allocate for DMA
	tempTx.length = 4096;
	if ( OK(rc) )	tempTx.ptr = AllocPhysMem(tempTx.length+32 ,PAGE_READWRITE, 0, 0, &tempTx.addr);
	if(tempTx.ptr == NULL) {
		DWORD err = GetLastError();
		rc = ECgErrMemory;
	}

	tempTx.ptr = (unsigned char *)((((DWORD)tempTx.ptr + 32 - 1) / 32) * 32);
	tempTx.addr = ((tempTx.addr + 32 - 1) / 32) * 32;
	if( OK(rc) )	memset(tempTx.ptr,0,tempTx.length);

	// receive temp buffger allocate for DMA
	tempRx.length = 4096;
	if ( OK(rc) )	tempRx.ptr = AllocPhysMem(tempRx.length+32 ,PAGE_READWRITE, 0, 0, &tempRx.addr);
	if(tempRx.ptr == NULL) {
		DWORD err = GetLastError();
		rc = ECgErrMemory;
		return rc;
	}
	tempRx.ptr = (unsigned char *)((((DWORD)tempRx.ptr + 32 - 1) / 32) * 32);
	tempRx.addr = ((tempRx.addr + 32 - 1) / 32) * 32;
	if ( OK(rc) )	memset(tempRx.ptr,0,tempRx.length);

	return rc;
}
TCgReturnCode CgCpuDmaDestroy(U32 aDmaChannel, U32 aIpDataSourceAddress)
{
	TCgReturnCode rc = ECgOk;

	FreePhysMem((void *)tempTx.ptr);
	FreePhysMem((void *)tempRx.ptr);

	KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &dma_info.sysintr, sizeof(DWORD), NULL, 0, NULL);

	InterruptDisable(dma_info.sysintr);

	SetEvent(dma_info.intrevent);

	CloseHandle(dma_info.intrevent);

	return rc;
}

#endif

TCgReturnCode CgCpuRtcCreate(void)
{
	TCgReturnCode rc = ECgOk;
	return rc;
}


TCgReturnCode CgCpuRtcDestroy(void)
{
	TCgReturnCode rc = ECgOk;
	return rc;
}

TCgReturnCode CgCpuRtcRead(TCgCpuRtcTime *apTime)
{	
	return ECgOk;
}


int sprintf(char *str, const char *format, ...); 
TCgReturnCode CgCpuRevision(char *apRevisionCode)
{
	DBG_FUNC_NAME("CgCpuRevision")
	U32 cpurevision = 0;
	U32 code = 0;

	CgCpuVirtualAllocate((void**)&cpurevision, 0xF053A044, sizeof(U32));
		
	code = REG32(cpurevision);
	
	sprintf(apRevisionCode, "TCC8900-R%d", code & 0x000000FF);
	return ECgOk;
}

#if CGX_IP == NONE

TCgReturnCode CgCpuSpiCreate(void)
{
	TCgReturnCode rc = ECgOk;

	rc = VirtualAllocateGpioSun((void**)&sSPIC, (U32)(&HwGPSBCH2_BASE), sizeof(TCC89X_SPI_REG));

//	rc = VirtualAllocateGpioSun(&sSPICBaseVA, HwGPSBCH0_BASE, 
//								HwGPSBCH2_BASE - HwGPSBCH0_BASE + sizeof(TCC89X_SPI_REG));

//	rc = CgCpuVirtualAllocate(	&sSPICBaseVA, HwGPSBCH0_BASE, 4);

	//rc = CgCpuVirtualAllocate(	(void**)&sSPICBaseVA, (U32)(&HwGPSBCH0_BASE), 
	//							(U32)(&HwGPSBCH2_BASE) - (U32)(&HwGPSBCH0_BASE) + sizeof(TCC89X_SPI_REG));
	//sSPIC = (pTccspi)((U32)sSPICBaseVA + (U32)(&HwGPSBCH2_BASE - &HwGPSBCH0_BASE));
	if (OK(rc)) rc = VirtualAllocateGpioSun((void**)&gpsbcfg, (U32)(&HwGPSBPORTCFG_BASE), sizeof(GPSBportcfg));
	//if (OK(rc)) rc = CgCpuVirtualAllocate((void**)&gpsbcfg, (U32)(&HwGPSBPORTCFG_BASE), 0x100);
	//if (OK(rc)) rc = CgCpuVirtualAllocate((void**)&gpsbcfg, (U32)(&HwGPSBPORTCFG_BASE), sizeof(GPSBportcfg));

	return rc;
}

TCgReturnCode CgCpuSpiDestroy(void)
{
	TCgReturnCode rc = ECgOk;
// 	rc = CgCpuVirtualFree((void**)&sSPIC);
// 	if (OK(rc)) rc = CgCpuVirtualFree((void**)&gpsbcfg);
	return rc;
}

TCgReturnCode CgCpuIntrCreate(void)
{
	return ECgOk;
}

TCgReturnCode CgCpuIntrDestroy(void)
{
	return ECgOk;
}

TCgReturnCode CgCpuClockCreate(void)
{
	TCgReturnCode rc = ECgOk;
	rc = VirtualAllocateGpioSun((void**)&ckc, (U32)(&CLK_BASE), sizeof(CKC));

	return rc;
}

TCgReturnCode CgCpuClockDestroy(void)
{
	TCgReturnCode rc = ECgOk;
//	rc = CgCpuVirtualFree((void**)&ckc);

	return ECgOk;
}

TCgReturnCode CgCpuGpioCreate(void)
{
	return ECgOk;
}



TCgReturnCode CgCpuGpioDestroy(void)
{
	return ECgOk;
}

// GPSB1_DMAREAD
TCgReturnCode CgCpuDmaSetupFromDevice_GPSB_DMA(U32 pTarget, U32 aLength, U32 aDeviceChannel)
{
	TCgReturnCode rc = ECgOk;

	if( aLength > 8191 ) 
	{
		RETAILMSG(1,(TEXT("\n\r[CgCpuDmaSetupFromDevice_GPSB_DMA] aLength is %d over 8191"),aLength));
		rc = ECgBadArgument;
		return rc;
	}

	sSPIC->INTEN.bit.DR = 1;
	sSPIC->INTEN.bit.DW = 1;

	sSPIC->PACKET.bit.COUNT = 0;		// packet number information (1~8192)	
	sSPIC->PACKET.bit.SIZE = aLength;// packet size information limit : (0~ 8191)

	sSPIC->TXBASE = tempTx.addr;		//======================> should be set when transfer	1)
	sSPIC->RXBASE = pTarget;		//======================> should be set when transfer	

	sSPIC->DMACTR.bit.DRE = 1;		// receive DMA request disable ======================> should change to enable '1'
	sSPIC->DMACTR.bit.DTE = 1; 		// trasmit DMA request disable ======================> should change to enable '1'	3)

	if( aDeviceChannel == 3 ) //loop_test
		sSPIC->DMACTR.bit.TXAM = 2; 		// TX addressing mode  '1':Fixed address
	else
		sSPIC->DMACTR.bit.TXAM = 1; 		// TX addressing mode  '1':Fixed address

	sSPIC->DMACTR.bit.RXAM = 2;		// RX addressing mode  '2':Single Packet

	sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
	sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

	sSPIC->DMAICR.bit.IEP = 0;	// IRQ enable for 'packet interrupt'		

	sSPIC->DMAICR.bit.IED = 1;	// IRQ enable for 'done interrupt'

	sSPIC->DMAICR.bit.IRQS = 0;	// IRQ select register	0 : for receive 1 : for transmit

	return rc;
}

TCgReturnCode CgCpuDmaSetupToDevice_GPSB_DMA(unsigned long pSource, unsigned long aLength)
{
	TCgReturnCode rc = ECgOk;

	if( aLength > 8191 ) 
	{
		rc = ECgBadArgument;
		RETAILMSG(1,(TEXT("\n\r!!!!! Exceed Number bytes %d\r\n"),aLength));
		return rc;
	}	
	sSPIC->INTEN.bit.DR = 1;
	sSPIC->INTEN.bit.DW = 1;

	sSPIC->PACKET.bit.COUNT = 0;		// packet number information (1~8192)	
	sSPIC->PACKET.bit.SIZE = aLength;// packet size information limit : (0~ 8191)

	sSPIC->TXBASE = pSource;		//======================> should be set when transfer	1)
	sSPIC->RXBASE = tempRx.addr;		//======================> should be set when transfer	

	sSPIC->DMACTR.bit.DRE = 1;		// receive DMA request disable ======================> should change to enable '1'
	sSPIC->DMACTR.bit.DTE = 1; 		// trasmit DMA request disable ======================> should change to enable '1'	3)
	sSPIC->DMACTR.bit.TXAM = 2; 		// TX addressing mode  '2':Single Packet
	sSPIC->DMACTR.bit.RXAM = 1;		// RX addressing mode  '1':Fixed address

	sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
	sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

	sSPIC->DMAICR.bit.IEP = 0;	// IRQ enable for 'packet interrupt'		

	sSPIC->DMAICR.bit.IED = 1;	// IRQ enable for 'done interrupt'

	sSPIC->DMAICR.bit.IRQS = 1;	// IRQ select register	0 : for receive 1 : for transmit

	return rc;
}

TCgReturnCode CgCpuDmaSetupFromDevice(U32 pTarget, U32 aLength, U32 aBlockLength, int aReadDmaChannel, int aWriteDmaChannel, int aDeviceChannel)
{
	TCgReturnCode rc = ECgOk;

	rc = CgCpuDmaSetupFromDevice_GPSB_DMA(pTarget,aLength,aDeviceChannel);

	return rc;
}

TCgReturnCode CgCpuDmaSetupToDevice(unsigned long pSource, unsigned long aLength, int aWriteDmaChannel, int aDeviceChannel)
{
	TCgReturnCode rc = ECgOk;

	rc = CgCpuDmaSetupToDevice_GPSB_DMA(pSource,aLength);

	return rc;
}

TCgReturnCode CgCpuDmaWaitFinish(int aDmaChannel)
{
	TCgReturnCode rc = ECgOk;
	DWORD dwStatus = 0;

	if( sSPIC->DMAICR.bit.IED== 0 )
	{
		int timeout = 0;
		while(sSPIC->DMACTR.bit.EN == 1){
			if( timeout++ >= 50000 ){
				RETAILMSG(1,(TEXT("\r\n[wait_for_dma_stop] timeout !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")));
				rc = ECgTimeout; 	
			}
		}

		sSPIC->INTEN.bit.DR = 0;
		sSPIC->INTEN.bit.DW = 0;

		sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
		sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

		sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
		sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

		sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
		sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

	}
	else
	{
		dwStatus = WaitForSingleObject(dma_info.intrevent, INFINITE);

		switch(dwStatus) 
		{
		case WAIT_FAILED:
			dwStatus = GetLastError();
			RETAILMSG(1,(TEXT("\r\n[DMAwait] wait_Failed %x %x"),dwStatus,pIntr->INTMSK1));
			sSPIC->INTEN.bit.DR = 0;
			sSPIC->INTEN.bit.DW = 0;

			sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
			sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

			sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
			sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

			sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
			sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'
			rc = ECgGeneralFailure; 		
			break;
		case WAIT_OBJECT_0:
			RETAILMSG(0,(TEXT("\r\n[DMAwait] %x "),pIntr->INTMSK1));
			sSPIC->INTEN.bit.DR = 0;
			sSPIC->INTEN.bit.DW = 0;

			sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
			sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

			sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
			sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

			sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
			sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

			break;
		case WAIT_ABANDONED:
			sSPIC->INTEN.bit.DR = 0;
			sSPIC->INTEN.bit.DW = 0;

			sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
			sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

			sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
			sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

			sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
			sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

			RETAILMSG(1,(TEXT("\r\n[DMAwait] abandoned !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")));
			rc = ECgGeneralFailure;		
			break;
		case WAIT_TIMEOUT:
			RETAILMSG(1,(TEXT("\r\n[DMAwait] timeout %x "),pIntr->INTMSK1));
			sSPIC->INTEN.bit.DR = 0;
			sSPIC->INTEN.bit.DW = 0;

			sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
			sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

			sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
			sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

			sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
			sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

			rc = ECgTimeout; 		
			break;
		default:
			RETAILMSG(1,(TEXT("\r\n[DMAwait] default %x "),dwStatus));
			sSPIC->INTEN.bit.DR = 0;
			sSPIC->INTEN.bit.DW = 0;

			sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
			sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

			sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
			sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

			sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
			sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'
			rc = ECgGeneralFailure; 	
			break;
		}
//		InterruptDone(dma_info.sysintr);
	}

	return rc;
}

TCgReturnCode CgCpuGpioIntCode(unsigned long aPin, unsigned long *aCode)
{
	TCgReturnCode rc = ECgOk;
	#if CGX_IP == 5500
		switch(aPin) {
			case CGX5000_DR : *aCode = IRQ0_EI0; break;
			case CGX5000_INT : *aCode = IRQ0_EI1; break;
			default: rc = ECgBadArgument;break;
		}
	#else
		#ifndef CGX_IP
			switch(aPin) 
			{
			case CGX5000_DR:			/*JR22 pin 4, EINT_4 */
				*aCode = IRQ0_EI6; 	
				break;

			default: 
				rc = ECgNotSupported;
				break;
			}
		#endif
	#endif
	return rc;
}

TCgReturnCode CgCpuGpioIntSource(unsigned long aPin, unsigned long *aSource)
{
	TCgReturnCode rc = ECgOk;
	unsigned long group = aPin / CG_CPU_GPIO_GROUP_SIZE;
	unsigned long pin = aPin % CG_CPU_GPIO_GROUP_SIZE;

	switch(group) 
	{
	case CG_CPU_GPIO_GROUP_INDEX_D :
		if ( pin < 5 || pin >20 )
			return ECgBadArgument;
		*aSource = pin + 11;
		break;
	default: rc = ECgBadArgument;break;
	}

	return rc;
}

TCgReturnCode CgCpuSpiSetup(U32 aDeviceChannel,unsigned long aPrescale, TCgCpuSpiMode aMode)
{
	return CgCpuSpiConfig(aDeviceChannel, aPrescale, aMode, 0);
}

TCgReturnCode CgCpuSpiConfig(U32 aDeviceChannel,U32 aPrescale, TCgCpuSpiMode aMode, U32 aLengthBytes)
{
	TCgReturnCode rc = ECgOk;

	switch(aMode) {
		case ECG_CPU_SPI_INIT:

			pIntr->MODE1 |= HwINT1_GPSB;			// Level
			pIntr->SEL1 |= HwINT1_GPSB;

			SetGPSBClock(30); // set SPI default clock 15Mhz

			//gpio setup :  Select function: GPIOD 15,16,19,20 => frm,clk,sdi,sdo (func 2 select - gpsb (port12))
			gpiod->GPFN1 &= ~0xf0000000;			//(15)
			gpiod->GPFN1 |=  0x20000000;
			gpiod->GPFN2 &= ~0x000ff00f;			// (16,19,20)
			gpiod->GPFN2 |=  0x00022002;

			//driver strength minimum, no direction
			gpiod->GPCD0 &= ~(0x3<<15);
			gpiod->GPCD1 &= ~(0x000003c3);			//driver strength minumun
			gpiod->GPPD0 &= ~(0x3<<15);
			gpiod->GPPD1 &= ~(0x000003c3);			//no direction 

			//gpsb2 block reset (iobus)
			iobuscfg->HCLKEN0 |= (0x1<<19);			//gpsb2 clock enable
			iobuscfg->HRSTEN0 &= ~(0x1<<19);		//gpsb2 reset
			iobuscfg->HRSTEN0 |= (0x1<<19);

			//gpsb2 => port 12
			gpsbcfg->PCFG0 &= ~0xff0000;
			gpsbcfg->PCFG0 |= 0x0c0000;

			// SPI frame signal position setting 
			sSPIC->INTEN.bit.RC = 0;  				// clear status at the end of read cycle
			sSPIC->INTEN.bit.CFGRTH = 0;  			// receive FIFO threshold for interrupt/DMA request
			sSPIC->INTEN.bit.CFGWTH = 0;  			// transmit FIFO threshold for interrupt/DMA request
			sSPIC->INTEN.bit.DR = 0;				// DMA request enable for receive FIFO 
			sSPIC->INTEN.bit.DW = 0;				// DMA request enable for transmit FIFO

			// TCgCpuSpi mode register
			sSPIC->MODE.bit.MD = 0;					// SPI compatible '0'
			sSPIC->MODE.bit.SLV = 0;				// master mode '0'
			sSPIC->MODE.bit.EN = 0;					// Operation disable ======================> should change to enable '1'		5)
			sSPIC->MODE.bit.CTF = 0;				// continuous transfer mode disable
			sSPIC->MODE.bit.LB = 0;					// Data loop-back disable
			sSPIC->MODE.bit.SD = 0;					// MSB first'0'
			sSPIC->MODE.bit.BWS = 7;				// Data bit width = 7+1 = 8
			sSPIC->MODE.bit.CWF = 0;				// clear write buffer counter
			sSPIC->MODE.bit.CRF = 0;				// clear read buffer counter

			sSPIC->MODE.bit.PCK = 1;				// polarity control SCKO start from - '1' for SPI timing 2
			sSPIC->MODE.bit.PRD = 0;				// polarity control for receive data - '0' for rising edge
			sSPIC->MODE.bit.PWD = 0;				// polarity control for transmit data - '0' for falling edge

			sSPIC->MODE.bit.PCD = 0;				// CMD(FRM) active low
			sSPIC->MODE.bit.PCS = 0;				// CS(FRM) active low
			sSPIC->MODE.bit.TSU = 0;				//master setup time
			sSPIC->MODE.bit.THL = 0;				// master hold time
			sSPIC->MODE.bit.TRE = 0;				//master recovery time
			sSPIC->MODE.bit.DIVLDV = aPrescale;		//clock divider load valude GCLK/((n+1)*2)

			RETAILMSG(0, (TEXT("\n\r[CgCpuSpiConfig] %x %x\r\n"), sSPIC->MODE.word,sSPIC->INTEN.word));

			// TCgCpuSpi DMA addresses of TX/RX data register
			sSPIC->TXBASE = 0;	//======================> should be set when transfer	1)
			sSPIC->RXBASE = 0;	//======================> should be set when transfer	

			// TCgCpuSpi packet register
			sSPIC->PACKET.bit.SIZE = 0;	
			sSPIC->PACKET.bit.COUNT = 0;	

			// TCgCpuSpi DMA control register 
			sSPIC->DMACTR.bit.DTE = 0; 		// trasmit DMA request disable ======================> should change to enable '1'	3)
			sSPIC->DMACTR.bit.DRE = 0;		// receive DMA request disable ======================> should change to enable '1'
			sSPIC->DMACTR.bit.CT = 0;		// continuous mode enable
			sSPIC->DMACTR.bit.END = 0;		// little endian mode
			sSPIC->DMACTR.bit.MP = 0;		// PID match mode (for MPEG2-TS mode)
			sSPIC->DMACTR.bit.MS =0;		// Sync byte match mode (for MPEG2-TS mode)
			sSPIC->DMACTR.bit.TXAM = 0;		// TX addressing mode '0':Multiple Packet (base) '1':fixed address '2':,'3':Single Packet
			sSPIC->DMACTR.bit.RXAM = 0;		// RX addressing mode '0':Multiple Packet (base) '1':fixed address '2':,'3':Single Packet		
			sSPIC->DMACTR.bit.MD = 0;		// DMA mode register '0' for normal mode
			sSPIC->DMACTR.bit.EN = 0;		// DMA enable register	======================> should change to enable '1'			4)

			//TCgCpuSpi DMA status register
			sSPIC->DMASTR.bit.RXPCNT = 0;	// receive packet count register				=======================> 6) check
			sSPIC->DMASTR.bit.TXPCNT= 0;		// trasmit packet count register

			//TCgCpuSpi DMA irq register
			sSPIC->DMAICR.bit.IRQS = 0;	// IRQ select register	0 : for transmit 1 : for receive
			sSPIC->DMAICR.bit.IED= 0;	// IRQ enable for 'done interrupt'
			sSPIC->DMAICR.bit.IEP = 0;	// IRQ enable for 'packet interrupt'		
			sSPIC->DMAICR.bit.IRQPCNT= 0;	// IRQ packet count register

			//[cs] 2008.02.27 
			sSPIC->MODE.bit.EN = 1;
			break;
			
		case ECG_CPU_SPI_SLEEP:
			//gpsb2 Clock init
			iobuscfg->HCLKEN0 &= ~(0x1<<19);	//gpsb2 clock enable
			iobuscfg->HRSTEN0 &= ~(0x1<<19); //gpsb2 reset
			break;

		case ECG_CPU_SPI_INPUT_POLLING:
		case ECG_CPU_SPI_OUTPUT_POLLING:
			sSPIC->INTEN.bit.DR = 0;
			sSPIC->INTEN.bit.DW = 0;

			sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
			sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

			sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
			sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

			sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
			sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

			sSPIC->MODE.bit.CWF = 1;                          // clear fifo
			sSPIC->MODE.bit.CRF = 1;                          // clear fifo

			sSPIC->DMACTR.bit.PCLR = 1;       
			sSPIC->DMACTR.bit.PCLR = 0;       

			sSPIC->MODE.bit.BWS = 7;	// Data bit width = 7+1 = 8

			sSPIC->MODE.bit.CWF = 0;                          
			sSPIC->MODE.bit.CRF = 0;                          
			break;

		case  ECG_CPU_SPI_INPUT_DMA:
		case  ECG_CPU_SPI_OUTPUT_DMA:
			sSPIC->INTEN.bit.DR = 0;
			sSPIC->INTEN.bit.DW = 0;

			sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
			sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

			sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
			sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

			sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
			sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

			sSPIC->MODE.bit.CWF = 1;                          // clear fifo
			sSPIC->MODE.bit.CRF = 1;                          // clear fifo

			sSPIC->DMACTR.bit.PCLR = 1;       
			sSPIC->DMACTR.bit.PCLR = 0;       

			sSPIC->MODE.bit.BWS = 31;	// Data bit width = 31+1 = 32

			sSPIC->MODE.bit.CWF = 0;                          
			sSPIC->MODE.bit.CRF = 0;       
			break;
	}

	return rc;
}

TCgReturnCode CgCpuSpiTxFinishWait(U32 aDeviceChannel)
{
	int i = 0;
	while(sSPIC->STAT.bit.WE == 0);// {if(i++>10000){ printf("\n\r[CgCpuSpiTxFinishWait] timeout!!!");break;}}//Write FIFO empty flag 

	return ECgOk;	
}

TCgReturnCode CgCpuSpiRxFinishWait(U32 aDeviceChannel)
{
	int i=0;
	while(sSPIC->STAT.bit.RNE == 0);// {if(i++>10000){ printf("\n\r[CgCpuSpiRxFinishWait] timeout!!!");break;}}	//Read FIFO not empty flag

	return ECgOk;
}



TCgReturnCode CgCpuSpiReadByte(U32 aDeviceChannel,volatile unsigned char *aByte)
{
	TCgReturnCode rc = ECgOk;
	if (aByte == NULL)
		return ECgNullPointer;

	*aByte = (unsigned char)sSPIC->PORT; 

	return rc;
}


TCgReturnCode CgCpuSpiWriteByte(U32 aDeviceChannel,unsigned char aValue)
{
	TCgReturnCode rc = ECgOk;
	sSPIC->PORT = aValue; 

	return rc;
}

void SetGPSBClock(int iFreq) 
{
	unsigned long reg_pll0 = ckc->PLL0CFG;
	int Fin = 12;
	int s = 0,m = 0,p = 0,sv=1,i = 0;
	int pll0 = 0,spi_div = 0;
	s = (reg_pll0>>24)&0x7;
	m = (reg_pll0>>8)&0xff;
	p = reg_pll0&0x3f;
	for(i=0;i<s;i++)
		sv*=2;

	pll0 = (m*Fin)/p/sv;
	//printf(" sv %x m %x p %x pll0 %x",sv,m,p,pll0);
	spi_div = (pll0+ iFreq/2)/iFreq - 1;
	ckc->PCLK_GPSB2 = 0x10000000 | spi_div;
}




TCgReturnCode CgCpuDmaStop(int aDmaChannel)
{
	TCgReturnCode rc = ECgOk;

	sSPIC->INTEN.bit.DR = 0;
	sSPIC->INTEN.bit.DW = 0;

	sSPIC->DMACTR.bit.DRE = 0; 		// receive DMA request disable ======================> should change to enable '1'
	sSPIC->DMACTR.bit.DTE = 0;		// trasmit DMA request disable ======================> should change to enable '1'	3)

	sSPIC->DMAICR.bit.IEP = 0;	// IRQ disable for 'packet interrupt'		
	sSPIC->DMAICR.bit.IED = 0;	// IRQ disable for 'done interrupt'

	sSPIC->DMAICR.bit.ISP = 1;	// IRQ status for 'packet interrupt'		
	sSPIC->DMAICR.bit.ISD = 1;	// IRQ status for 'done interrupt'

	sSPIC->DMACTR.bit.EN = 0;		// DMA enable register	======================> should change to enable '1'			4)

	return rc;
}

#endif 
