/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */

/**
  \file
  \brief Standard Microsoft Windows CE driver header file

*/

#ifndef _CGX_DRIVER_H__
#define _CGX_DRIVER_H__

#if 0
#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
__declspec(dllexport) DWORD CGX_Init (DWORD dwContext);
__declspec(dllexport) BOOL  CGX_Deinit (DWORD dwContext);
__declspec(dllexport) DWORD CGX_Open (DWORD dwContext, DWORD dwAccess, 
									  DWORD dwShare);
__declspec(dllexport) BOOL  CGX_Close (DWORD dwOpen);
__declspec(dllexport) DWORD CGX_Read (DWORD dwOpen, LPVOID pBuffer,		
									  DWORD dwCount);
__declspec(dllexport) DWORD CGX_Write (DWORD dwOpen, LPVOID pBuffer, 
									   DWORD dwCount);
__declspec(dllexport) DWORD CGX_Seek (DWORD dwOpen, long lDelta, 
									  WORD wType);
__declspec(dllexport) DWORD CGX_IOControl (DWORD dwOpen, DWORD dwCode, 
										   PBYTE pIn, DWORD dwIn,
					                       PBYTE pOut, DWORD dwOut, 
										   DWORD *pdwBytesWritten);
__declspec(dllexport) void CGX_PowerDown (DWORD dwContext);
__declspec(dllexport) void CGX_PowerUp (DWORD dwContext);
#ifdef __cplusplus
} // extern "C"
#endif //__cplusplus
#endif

// Suppress warnings by declaring the undeclared.
#ifndef GetCurrentPermissions
DWORD GetCurrentPermissions(void);
DWORD SetProcPermissions (DWORD);
#endif //GetCurrentPermissions


/**  Driver instance structure. */
typedef struct {
	U32 dwSize;							/**< Magic number */
	long nNumOpens;							/**< Number of opened instances (should be 0/1) */
	TCgCpuIST dataReadyIST;	/**< data ready interrupt service thread structure  */
	TCgCpuIST gpsIST;		/**< 'gps' interrupt service thread structure  */
	HANDLE transferEndSemaphore;			/**< Internal semaphore for blocking application */
	TCgxDriverPhysicalMemory chunk;			/**< Physical memory to hold single chunk of data (by DMA)*/
	TCgxDriverState state;					/**< Internal driver state structure */
} DRVCONTEXT, *PDRVCONTEXT;



DWORD WINAPI DataReadyISTMain(LPVOID plvParam);
TCgReturnCode CgxDriverDataReadyInterruptHandlerStart(void *pDriver);

//
// Debug zone support
//
// Used as a prefix string for all debug zone messages.
#define DTAG        TEXT ("CGXDrv: ")

// Debug zone constants
#define ZONE_ERROR      DEBUGZONE(0)
#define ZONE_WARNING    DEBUGZONE(1)
#define ZONE_FUNC       DEBUGZONE(2)
#define ZONE_INIT       DEBUGZONE(3)
#define ZONE_DRVCALLS   DEBUGZONE(4)








//#define CGX5000_REGISTER_MSG_LEN 8 /*GLU-LOGIC*/
#endif /* _CGX_DRIVER_H__ */
