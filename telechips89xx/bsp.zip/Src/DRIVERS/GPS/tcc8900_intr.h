/************************************************************************************************
*	TCC8900 WinCE Board Support Package
*	-----------------------------------
*
*	FUNCTION	: TCC8900 GPS Driver
*	MODEL		: TCC8900 WinCE
*	CPU	NAME	: TCC8900
*
*	DEVISION	: DEPT. 2GROUP SOC 2 TEAM
*				: TELECHIPS, INC.
************************************************************************************************/
//
// Copyright (c) Telechips Corporation.  All rights reserved.
//
//
//
//------------------------------------------------------------------------------
//
//  Header: TCC8900_intr.h
//
//  Defines the interrupt controller register layout and associated interrupt
//  sources and bit masks.
//
#ifndef __TCC8900_INTR_H
#define __TCC8900_INTR_H

#if __cplusplus
extern "C" {
#endif


/************************************************************************
*	2. Vectored Priority Interrupt Controller Register Map(Base Addr = 0xF0401000)
************************************************************************/
#define	HwPIC_BASE					*(volatile unsigned long *)0xF0401000

#define HwINT0_EI6 (0x1<<IRQ0_EI6)
#define HwINT1_GPSB (0x1<<IRQ1_GPSB)

typedef struct {
	volatile unsigned int	IEN0;					//     0x000  R/W  0x00000000  Interrupt Enable0 Register 
	volatile unsigned int	IEN1;					//     0x004  R/W  0x00000000  Interrupt Enable1 Register 
	volatile unsigned int	CLR0;					//     0x008  R/W  0x00000000  Interrupt Clear0 Register 
	volatile unsigned int	CLR1;					//     0x00C  R/W  0x00000000  Interrupt Clear1 Register 
	volatile unsigned int	STS0;					//     0x010  R  Unknown  Interrupt Status0 Register 
	volatile unsigned int	STS1;					//     0x014  R  Unknown  Interrupt Status1 Register 
	volatile unsigned int	SEL0;					//     0x018  R/W  0x00000000  IRQ or FIR Selection0 Register 
	volatile unsigned int	SEL1;					//     0x01C  R/W  0x00000000  IRQ or FIR Selection1 Register 
	volatile unsigned int	SRC0;					//     0x020  R  Unknown  Source Interrupt Status0 Register 
	volatile unsigned int	SRC1;					//     0x024  R  Unknown  Source Interrupt Status1 Register 
	volatile unsigned int	MSTS0;					//     0x028  R  0x00000000  Masked Status0 Register 
	volatile unsigned int	MSTS1;					//     0x02C  R  0x00000000  Masked Status1 Register 
	volatile unsigned int	TIG0;					//     0x030  R/W  0x00000000  Test Interrupt Generation0 Register 
	volatile unsigned int	TIG1;					//     0x034  R/W  0x00000000  Test Interrupt Generation1 Register 
	volatile unsigned int	POL0;					//     0x038  R/W  0x00000000  Interrupt Polarity0 Register 
	volatile unsigned int	POL1;					//     0x03C  R/W  0x00000000  Interrupt Polarity1 Register 
	volatile unsigned int	IRQ0;					//     0x040  R  0x00000000  IRQ Raw Status0 Register 
	volatile unsigned int	IRQ1;					//     0x044  R  0x00000000  IRQ Raw Status1 Register 
	volatile unsigned int	FIQ0;					//     0x048  R  Unknown  FIQ Status0 Register 
	volatile unsigned int	FIQ1;					//     0x04C  R  Unknown  FIQ Status1 Register 
	volatile unsigned int	MIRQ0;					//     0x050  R  0x00000000  Masked IRQ Status0 Register 
	volatile unsigned int	MIRQ1;					//     0x054  R  0x00000000  Masked IRQ Status1 Register 
	volatile unsigned int	MFIQ0;					//     0x058  R  0x00000000  Masked FIQ Status0 Register 
	volatile unsigned int	MFIQ1;					//     0x05C  R  0x00000000  Masked FIQ Status1 Register 
	volatile unsigned int	MODE0;					//     0x060  R/W  0x00000000  Trigger Mode0 Register ? Level or Edge 
	volatile unsigned int	MODE1;					//     0x064  R/W  0x00000000  Trigger Mode1 Register ? Level or Edge 
	volatile unsigned int	SYNC0;					//     0x068  R/W  0xFFFFFFFF  Synchronization Enable0 Register 
	volatile unsigned int	SYNC1;					//     0x06C  R/W  0xFFFFFFFF  Synchronization Enable1 Register 
	volatile unsigned int	WKEN0;					//     0x070  R/W  0x00000000  Wakeup Event Enable0 Register 
	volatile unsigned int	WKEN1;					//     0x074  R/W  0x00000000  Wakeup Event Enable1 Register 
	volatile unsigned int	MODEA0;					//     0x078  R/W  0x00000000  Both Edge or Single Edge0 Register 
	volatile unsigned int	MODEA1;					//     0x07C  R/W  0x00000000  Both Edge or Single Edge1 Register 
	volatile unsigned int	NOTDEFINE0[32];		//-  0x80-0xFC      Reserved 
	volatile unsigned int	INTMSK0;				//     0x100  R/W  0xFFFFFFFF  Interrupt Output Masking0 Register 
	volatile unsigned int	INTMSK1;				//     0x104  R/W  0xFFFFFFFF  Interrupt Output Masking1 Register 
	volatile unsigned int	ALLMSK;					//     0x108  R/W  0x00000003  All Mask Register 
}TCC8900_INTR_REG,*PTCC8900_INTR_REG;

typedef PTCC8900_INTR_REG pTccintr;

//------------------------------------------------------------------------------
//
//  Define: IRQ_XXX
//
//  Interrupt sources numbers
//

// Interrupt Enable 0
#define	IRQ0_EHI0					31					// 	R/W, External Host Interface0 Interrupt Enable
#define	IRQ0_ECC					30					// 	R/W, ECC Interrupt Enable 
#define	IRQ0_DMA					29					// 	R/W, DMA Controller Interrupt Enable
#define	IRQ0_TSADC					28					// 	R/W, TSADC Interrupt Enable
#define	IRQ0_G2D					27					// 	R/W, Graphic Engine 2D Hardware Interrupt Enable
#define	IRQ0_3DMMU					26					// 	R/W, 3D MMU Interrupt Enable
#define	IRQ0_3DGP					25					// 	R/W, 3D Geometary Interrupt Enable
#define	IRQ0_3DPP					24					// 	R/W, 3D Pixel Processor Interrupt Enable
#define	IRQ0_VCDC					23					// 	R/W, Video CODEC Interrupt Enable
#define	IRQ0_JPGD					22					// 	R/W, JPEG Decoder Interrupt Enable
#define	IRQ0_JPGE					21					// 	R/W, JPEG Encoder Interrupt Enable
#define	IRQ0_VIPET					20					// 	R/W, VIPET Controller Interrupt Enable
#define	IRQ0_LCD1					19					// 	R/W, LCD Controller1 Interrupt Enable
#define	IRQ0_LCD0					18					// 	R/W, LCD Controller0 Interrupt Enable
#define	IRQ0_CAM					17					// 	R/W, Camera Interrupt Enable
#define	IRQ0_SC1					16					// 	R/W, Mem-to-Mem Scaler1 Interrupt Enable
#define	IRQ0_SC0					15					// 	R/W, Mem-to-Mem Scaler0 Interrupt Enable
#define	IRQ0_EI11					14					// 	R/W, External Interrupt11 Enable
#define	IRQ0_EI10					13					// 	R/W, External Interrupt10 Enable
#define	IRQ0_EI9					12					// 	R/W, External Interrupt9 Enable
#define	IRQ0_EI8					11					// 	R/W, External Interrupt8 Enable
#define	IRQ0_EI7					10					// 	R/W, External Interrupt7 Enable
#define	IRQ0_EI6					9					// 	R/W, External Interrupt6 Enable
#define	IRQ0_EI5					8					// 	R/W, External Interrupt5 Enable
#define	IRQ0_EI4					7					// 	R/W, External Interrupt4 Enable
#define	IRQ0_EI3					6					// 	R/W, External Interrupt3 Enable
#define	IRQ0_EI2					5					// 	R/W, External Interrupt2 Enable
#define	IRQ0_EI1					4					// 	R/W, External Interrupt1 Enable
#define	IRQ0_EI0					3					// 	R/W, External Interrupt0 Enable
#define	IRQ0_SMUI2C					2					// 	R/W, SMU_I2C Interrupt Enable
#define	IRQ0_TC1					1					// 	R/W, Timer1 Interrupt Enable
#define	IRQ0_TC0					0					// 	R/W, Timer0 Interrupt Enable

// Interrupt Enable 1
#define	IRQ1_AEIRQ					31					// 	R/W, Not maskable error ARM DMA interrupt enable
#define	IRQ1_ASIRQ					30					// 	R/W, Secure ARM DMA select interrupt enable
#define	IRQ1_AIRQ					29					// 	R/W, Non secure ARM DMA interrupt enable
#define	IRQ1_APMU					28					// 	R/W, ARM System Metrics interrupt enable
#define	IRQ1_AUDIO					27					// 	R/W, AUDIO interrupt enable
#define	IRQ1_ADMA					26					// 	R/W, AUDIO DMA interrupt enable
#define	IRQ1_DAITX					25					// 	R/W, DAI transmit interrupt enable
#define	IRQ1_DAIRX					24					// 	R/W, DAI receive interrupt enable
#define	IRQ1_CDRX					23					// 	R/W, CDIF receive interrupt enable
#define	IRQ1_TSIF1					22					// 	R/W, TS interface 1 interrupt enable
#define	IRQ1_TSIF0					21					// 	R/W, TS interface 0 interrupt enable
#define	IRQ1_GPS2					20					// 	R/W, GPS AGPS interrupt enable
#define	IRQ1_GPS1					19					// 	R/W, GPS TCXO expired interrupt enable
#define	IRQ1_GPS0					18					// 	R/W, GPS RTC expired interrupt enable
#define	IRQ1_NotUsed				17					// 	R/W, Reserved
#define	IRQ1_UOTG					16					// 	R/W, USB 2.0 OTG interrupt enable
#define	IRQ1_UART					15					// 	R/W, UART interrupt enable
#define	IRQ1_SPDTX					14					// 	R/W, SPDIF transmitter interrupt enable
#define	IRQ1_SD1					13					// 	R/W, SD/MMC 1 interrupt enable
#define	IRQ1_SD0					12					// 	R/W, SD/MMC 0 interrupt enable
#define	IRQ1_RTC					11					// 	R/W, RTC interrupt enable
#define	IRQ1_RMT					10					// 	R/W, Remote Control interrupt enable
#define	IRQ1_NFC					9					// 	R/W, Nand flash controller interrupt enable
#define	IRQ1_MS						8					// 	R/W, Memory Stick interrupt enable
#define	IRQ1_MPEFEC					7					// 	R/W, MPEFEC interrupt enable
#define	IRQ1_I2C					6					// 	R/W, I2C interrupt enable
#define	IRQ1_HDD					5					// 	R/W, HDD controller interrupt enable
#define	IRQ1_GPSB					4					// 	R/W, GPSB Interrupt Enable
#define	IRQ1_NotUsed1				3					// 	R/W, Reserved
#define	IRQ1_HDMI					2					// 	R/W, HDMI interrupt enable
#define	IRQ1_NotUsed2				1					// 	R/W, Reserved
#define	IRQ1_EHI1					0					// 	R/W, External Host Interface1 Interrupt Enable

/************************************************************************
*	1. Clock Controller Register Define			(Base Addr = 0xF0400000) // R/W
************************************************************************/
//---------------------------------------------------------------------------------------------
//31  | 30  | 29  | 28  | 27  | 26  | 25  | 24  | 23  | 22  | 21  | 20  | 19  | 18  | 17  | 16 |
//  												 		|CFGEN|MODE | NCKOE/DPRD           |
//15  | 14  | 13  | 12  | 11  | 10  |  9  |  8  |  7  |   6 |   5 |   4 |   3 |   2 |   1 |  0 |
//   NCKOE/DMIN  		|		NCKOE/DMAX      |		  NCKOE/DCDIV   |     |	    CKSEL      |
//---------------------------------------------------------------------------------------------- 

#define CLK_BASE					*(volatile unsigned long *)0xF0400000

typedef struct __CKC{
	volatile unsigned int	CLK0CTRL;					//   0x00  R/W  0x2FFFF4  CPU & Bus Clock0 Control Register 
	volatile unsigned int	CLK1CTRL;					//   0x04  R/W  0x2FFFF4  CPU & Bus Clock1 Control Register 
	volatile unsigned int	CLK2CTRL;					//   0x08  R/W  0x2FFFF4  CPU & Bus Clock2 Control Register 
	volatile unsigned int	CLK3CTRL;					//   0x0C  R/W  0x2FFFF4  CPU & Bus Clock3 Control Register 
	volatile unsigned int	CLK4CTRL;					//   0x10  R/W  0x2FFFF4  CPU & Bus Clock4 Control Register 
	volatile unsigned int	CLK5CTRL;					//   0x14  R/W  0x2FFFF4  CPU & Bus Clock5 Control Register 
	volatile unsigned int	CLK6CTRL;					//   0x18  R/W  0x2FFFF4  CPU & Bus Clock6 Control Register 
	volatile unsigned int	CLK7CTRL;					//   0x1C  R/W  0x2FFFF4  CPU & Bus Clock 7Control Register 
	volatile unsigned int	PLL0CFG;					//   0x20  R/W  0x8010FA03  PLL0 Configuration Register 
	volatile unsigned int	PLL1CFG;					//   0x24  R/W  0x80009603  PLL1 Configuration Register 
	volatile unsigned int	PLL2CFG;					//   0x28  R/W  0x80007D03  PLL2 Configuration Register 
	volatile unsigned int	PLL3CFG;					//   0x2C  R/W  0x80009603  PLL3 Configuration Register 
	volatile unsigned int	CLKDIVC;					//   0x30  R/W  0x81818181  PLL Divider Configuration Register 
	volatile unsigned int	CLKDIVC1;					//   0x34  R/W  0x00008181  External Clock Divider Configuration Register 
	volatile unsigned int	CLKDIVC2;					//-  0x38     Reserved 
	volatile unsigned int	CLKDIVC3;					//-  0x3C      Reserved 
	volatile unsigned int	SWRESETPRD;					//   0x40  R/W  0x000000FF  Software Reset Period Register 
	volatile unsigned int	SWRESET;					//   0x44  R/W  0x00000000  Software Reset Control Register 
	volatile unsigned int	NOTDEFINE0[14];				//-  0x48-0x7C      Reserved 
	volatile unsigned int	PCLK_TCX;					//   0x80  R/W  0x00014000  Timer Counter 0 Oscillator-Clock Control Register   
	volatile unsigned int	PCLK_TCT;					//   0x84  R/W  0x00014000  Timer Counter 0 Clock Control Register   
	volatile unsigned int	PCLK_TCZ;					//   0x88  R/W  0x00014000  Timer Counter 1 Clock Control Register   
	volatile unsigned int	PCLK_LCD0;					//   0x8C  R/W  0x00014000  LCD0 Clock Control Register 
	volatile unsigned int	PCLK_LCD1;					//   0x90  R/W  0x00014000  LCD1 Clock Control Register 
	volatile unsigned int	PCLK_LCDSI;					//   0x94  R/W  0x00014000  LCDSI Clock Control Register 
	volatile unsigned int	PCLK_CIFMC;					//   0x98  R/W  0x00014000  Control Register for CIF Internal Clock
	volatile unsigned int	PCLK_CIFSC;					//   0x9C  R/W  0x00014000  Control Register for CIF Scaler Clock
	volatile unsigned int	PCLK_OUT0;					//   0xA0  R/W  0x00014000  Control Register for External Clock Output 0
	volatile unsigned int	PCLK_OUT1;					//   0xA4  R/W  0x00014000  Control Register for External Clock Output 1 
	volatile unsigned int	PCLK_HDMI;					//   0xA8  R/W  0x00014000  Control Register for HDMI PHY Input Clock 
	volatile unsigned int	PCLK_USB11H;				//   0xAC  R/W  0x00014000  Control Register for USB 1.1 Host 
	volatile unsigned int	PCLK_SDMMC0;				//   0xB0  R/W  0x00014000  Control Register for SD/MMC Channel 0
	volatile unsigned int	PCLK_MSTICK;				//   0xB4  R/W  0x00014000  Memory Stick Clock Control Register 
	volatile unsigned int	PCLK_I2C;					//   0xB8  R/W  0x00014000  I2C Clock Control Register 
	volatile unsigned int	PCLK_UART0;					//   0xBC  R/W  0x00014000  UART0 Clock Control Register 
	volatile unsigned int	PCLK_UART1;					//   0xC0  R/W  0x00014000  UART1 Clock Control Register 
	volatile unsigned int	PCLK_UART2;					//   0xC4  R/W  0x00014000  UART2 Clock Control Register 
	volatile unsigned int	PCLK_UART3;					//   0xC8  R/W  0x00014000  UART3 Clock Control Register 
	volatile unsigned int	PCLK_UART4;					//   0xCC  R/W  0x00014000  UART4 Clock Control Register 
	volatile unsigned int	PCLK_UART5;					//   0xD0  R/W  0x00014000  UART5 Clock Control Register 
	volatile unsigned int	PCLK_GPSB0;					//   0xD4  R/W  0x00014000  Control Register for GPSB Channel 0
	volatile unsigned int	PCLK_GPSB1;					//   0xD8  R/W  0x00014000  Control Register for GPSB Channel 1
	volatile unsigned int	PCLK_GPSB2;					//   0xDC  R/W  0x00014000  Control Register for GPSB Channel 2
	volatile unsigned int	PCLK_GPSB3;					//   0xE0  R/W  0x00014000  Control Register for GPSB Channel 3
	volatile unsigned int   PCLK_GPSB4; 				//	0x0E4 R/W  0x14000000  Control Register for GPSB Channel 4
	volatile unsigned int	PCLK_GPSB5;					//   0xE8  R/W  0x00014000  Control Register for GPSB Channel 5 
	volatile unsigned int	PCLK_ADC;					//   0xEC  R/W  0x00014000  Control Register for ADC (Touch Screen)
	volatile unsigned int	PCLK_SPDIF;					//   0xF0  R/W  0x00140000  Control Register for SPDIF 
	volatile unsigned int	PCLK_EHI0;					//   0xF4  R/W  0x00140000  Control Register for EHI Channel 0
	volatile unsigned int   PCLK_EHI1;					//	0x0F8 R/W  0x14000000 Control Register for EHI Channel 1 
	volatile unsigned int	PCLK_AUD;					//   0xFC  R/W  0x00014000  Control Register for Audio DMA
	volatile unsigned int	PCLK_CAN ;					//   0x100  R/W  0x00014000  Control Register for CAN 
	volatile unsigned int	NOTDEFINE1;					//   0x104  R/W  0x00140000  Reserved 
	volatile unsigned int	PCLK_SDMMC1;				//   0x108  R/W  0x00014000  Control Register for SD/MMC Channel 1
	volatile unsigned int	NOTDEFINE2;					//   0x10C  R/W  0x00014000  Reserved 
	volatile unsigned int	PCLK_DAI ;					//   0x110  R/W  0x00014000  Control Register for DAI (DAI Only) 
}SCKC, *PSCKC;


#if __cplusplus
}
#endif

#endif 
