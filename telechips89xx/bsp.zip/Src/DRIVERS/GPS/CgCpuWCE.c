/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
 \file 
 \brief CPU abstraction implementation for windows CE

 CPU API Implementation for Samsung 2440

*/
#include <windows.h>						/**< Windows CE specific */
#include <pkfuncs.h>						/**< Windows CE specific */
#include <Giisr.h>							/**< Windows CE shared interrupt support */
#include "CgCpu.h"							/**< CellGuide CPU low level functions API */

#define REG32(r) *((volatile U32*)(r))

unsigned long gLastError = 0;

TCgReturnCode CgCpuVirtualAllocate(volatile void **pObject, unsigned long aBaseAddr, unsigned long aSize)
{
	TCgReturnCode rc = ECgOk;
	*pObject = NULL;
	*pObject = VirtualAlloc(0, aSize, MEM_RESERVE, PAGE_NOACCESS);

	if(*pObject == NULL) 
		rc = ECgErrMemory;
	
	if (OK(rc) && !VirtualCopy((PVOID)*pObject, (PVOID)(aBaseAddr>>8), aSize, PAGE_PHYSICAL | PAGE_READWRITE | PAGE_NOCACHE))  
		rc = ECgErrMemory;

	return rc;
}

TCgReturnCode CgCpuVirtualFree(volatile void **pObject)
{
	TCgReturnCode rc = ECgOk;
	if(*pObject)  {
		if (VirtualFree((PVOID) *pObject, 0, MEM_RELEASE) == 0) {
			// fail
			gLastError = GetLastError();
			rc = ECgErrMemory;
			}
		}
        
	*pObject = NULL;
	
	return rc;
}


TCgReturnCode CgCpuKernelModeEnter(void)
{
	SetKMode(TRUE); 
	SetProcPermissions(0xFFFFFFFF);
	return ECgOk;
}

TCgReturnCode CgCpuKernelModeExit(void)
{
	SetKMode(FALSE); 
	return ECgOk;
}

TCgReturnCode CgCpuCacheSync(void)
{
	CacheSync(CACHE_SYNC_DISCARD); 
	return ECgOk;
}


TCgReturnCode CgCpuIntrRequestOsInterrupt(U32 aIRQ, U32 *apOSIntCode)
{
	TCgReturnCode rc = ECgOk;

	if(!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &aIRQ, sizeof(unsigned int), apOSIntCode, sizeof(unsigned int), NULL)){	
		RETAILMSG(1, (TEXT("ERROR: Failed to request intr value .\r\n")));
		rc = ECgGeneralFailure;
	}
	else
	{
		RETAILMSG(0, (TEXT("Intr value from OS = %d.\r\n"), *apOSIntCode));
	}



	return rc;
}

TCgReturnCode CgCpuIntrAttachEvent(U32 aRequestCode,	void *apEvent)
{
	TCgReturnCode rc = ECgOk;
	BOOL bRet = FALSE;

	if (OK(rc)) {
		bRet = InterruptInitialize(aRequestCode, (HANDLE)apEvent, NULL, 0);
		if(bRet == FALSE) {
			U32 dwError = GetLastError();
			rc = ECgGeneralFailure;
			}
		}
	
	return rc;
}



TCgReturnCode CgCpuIntrDisable(U32 aInterruptCode)
{
	TCgReturnCode rc = ECgOk;
	BOOL ret =TRUE;
	ret = KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &aInterruptCode, sizeof(DWORD), NULL, 0, NULL);
	//TRUE indicates success. FALSE indicates failure.
	if (ret == FALSE)
		rc = ECgGeneralFailure;
	InterruptDisable(aInterruptCode);
	return rc;
}




TCgReturnCode CgCpuIntrDone(U32 aInterruptCode)
{
	TCgReturnCode rc = ECgOk;
	InterruptDone(aInterruptCode);
	return rc;
}








TCgReturnCode CgCpuISTStart(TCgCpuIST *apIstInfo, void *aFunc, S32 aPriority, DWORD aIntCode, U32 aIrqCode, 
							void *aParam, const char *aEventName, void * apSharedISRInfo,
							const void * apSharedISRLibrary, const void * apSharedISR )
{
	TCgReturnCode rc = ECgOk;
	DWORD suspendCount = 0;
	DWORD errCode = 0;
	BOOL ret;

	apIstInfo->intCode = aIntCode;

	if (aEventName != NULL) 
	{
		TCHAR eventName[128];
		#if ( (_WIN32_WCE == 0x600) )	// Windows CE6 
				swprintf_s(eventName, 128, L"%S", aEventName);
		#else
				swprintf(eventName, L"%S", aEventName);
		#endif

		apIstInfo->event = CreateEvent(NULL, FALSE, FALSE, eventName);
	}
	else
		apIstInfo->event = CreateEvent(NULL, FALSE, FALSE, NULL);
	rc = (apIstInfo->event != NULL) ? ECgOk : ECgGeneralFailure;

	if ( OK(rc) && aIrqCode != 0)
	{
		rc = CgCpuIntrRequestOsInterrupt(aIrqCode, &apIstInfo->intCode );
	}

	if ( OK(rc) && apIstInfo->intCode != 0)
	{
		rc = CgCpuIntrAttachEvent(apIstInfo->intCode, apIstInfo->event);
	}		

	// A New thread will handle the interrupt
	if ( apSharedISRInfo == NULL )
	{
		// Create a new interrupt handler thread 
		if (OK(rc)) {
			(HANDLE*)apIstInfo->handle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)aFunc, aParam, CREATE_SUSPENDED, NULL);
			rc = ((HANDLE*)apIstInfo->handle != NULL) ? ECgOk : ECgGeneralFailure;
		}
		if (OK(rc)) {
			ret = CeSetThreadPriority((HANDLE*)apIstInfo->handle, (int)aPriority);
			//TRUE indicates success.FALSE indicates failure.To get extended error information, call GetLastError.
			rc = (ret != FALSE) ? ECgOk : ECgGeneralFailure;
		}
		if (OK(rc))  
		{
			suspendCount = ResumeThread(apIstInfo->handle); // TODO NG handle error : The thread's previous suspend count indicates success. 0xFFFFFFFF indicates failure. To get extended error information, call GetLastError.
			if (suspendCount == 0xFFFFFFFF) 
			{
				errCode = GetLastError();
				rc = ECgGeneralFailure;
			}
		}
	}

	else
	{
		// Use already existing shared interrupt handler routine 
		if(OK(rc))
		{
			HANDLE isrhandler = NULL;

			isrhandler = LoadIntChainHandler( (TCHAR*)apSharedISRLibrary, (TCHAR*)apSharedISR,(BYTE)aIrqCode);

			if(isrhandler == NULL){
				DWORD dwRet = GetLastError();	
				RETAILMSG(1, (TEXT("Load IntChainHandler return fail %d\r\n"),dwRet));			
				rc = -(TCgReturnCode)(dwRet);
			}

			if (OK(rc))  
			{
				((GIISR_INFO*)apSharedISRInfo)->SysIntr = apIstInfo->intCode;

				if (!KernelLibIoControl(isrhandler, IOCTL_GIISR_INFO,  apSharedISRInfo, sizeof(GIISR_INFO), NULL, 0, 0))
				{
					DWORD dwRet = GetLastError();	
					RETAILMSG(1, (TEXT("[GPS]IOCTL_GIISR_INFO return fail %d\r\n"),dwRet));			
					rc = -(TCgReturnCode)(dwRet);
				}
			}
		}
	}

	return rc;
}




TCgReturnCode CgCpuISTStop(TCgCpuIST *apIstInfo)
{
	TCgReturnCode rc = ECgOk;
	BOOL bRet = TRUE;
	DWORD dwError = 0;

	if (apIstInfo->intCode != 0)
		rc = CgCpuIntrDisable(apIstInfo->intCode);
	if(apIstInfo->handle) {
		bRet = SetEvent(apIstInfo->event);// TODO NG handle error
		dwError = WaitForSingleObject(apIstInfo->handle, INFINITE);
		bRet = CloseHandle(apIstInfo->handle);		// TODO NG handle error
		}
        
	CloseHandle(apIstInfo->event);

	return rc;
}


//CG_CPU_S3C2450_CGX5500_BASE
TCgReturnCode CgxCpuReadMemory(U32 aBaseAddr, U32 aOffset, U32 *apValue)
{
	TCgReturnCode rc =ECgOk;
	//CgCpuKernelModeEnter(); 
	*apValue = REG32(aBaseAddr + aOffset);
	//CgCpuKernelModeExit(); 
	return rc;
}


TCgReturnCode CgxCpuWriteMemory(U32 aBaseAddr, U32 aOffset, U32 aValue)
{
	DBG_FUNC_NAME("CgxCpuWriteMemory")
	TCgReturnCode rc =ECgOk;
	//DBGMSG2("0x%08X = 0x%08X", aBaseAddr + aOffset, aValue)
	CgCpuKernelModeEnter(); 
	REG32(aBaseAddr + aOffset) = aValue;
	CgCpuCacheSync();
	CgCpuKernelModeExit(); 
	return rc;
}



/**
	Send debug message to console

    \param[in]  aMessage			text message (null terminated) to send to console
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
#define MAX_LINE_LENGTH  256
TCgReturnCode CgxCpuMsg(const char *aFuncName, const char *aFileName, U32 aLineNum, char *aFormat, ...)
{
	const char *fn = NULL;
  	va_list args;
	char buf[MAX_LINE_LENGTH] = {0}; 
	int n = 0;
   	va_start(args, aFormat); // prepare the arguments
	#if ( (_WIN32_WCE == 0x600) )	// Windows CE6 
		n = _vsnprintf_s(buf, MAX_LINE_LENGTH, MAX_LINE_LENGTH, aFormat, args);
	#else
		n = _vsnprintf(buf, MAX_LINE_LENGTH, aFormat, args);
	#endif
   	va_end(args); // clean the stack
	fn = strrchr(aFileName, '\\');
	if (fn == NULL)
		fn = "\\<Unknown>";
	
	fn++; // ignore the slash...


	#ifdef _WIN32_WCE
		RETAILMSG(TRUE, (TEXT("[%S#%d  %S: %S]\r\n"), fn, aLineNum, aFuncName, buf));
	#endif
	return ECgOk;
}

TCgReturnCode CgxCpuSleep(U32 aMilliSeconds)
{
	Sleep(aMilliSeconds);

	return ECgOk;
}


