/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
  \file
  \brief CellGuide CGX5900 driver core prototypes (non-OS depended)

*/

#ifndef CGX_DRIVR_CORE_H
#define CGX_DRIVR_CORE_H
#include "CgReturnCodes.h"					/**< CellGuide Return codes definitions */
#include "CgxDriverApi.h"					/**< CellGuide Driver API */

//#define MIN(a,b) ((a) < (b)) ? (a) : (b)

#define CHUNK_SIZE_MAX		(6 * 1024)



/**
	Setup driver structure

    \param[in]  pDriver			Global driver structure pointer 	
    \param[in]  pState			Driver state structure pointer
    \param[in]  apChunk			Chunk memory information structure pointer
	
	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverConstruct(
	void *pDriver, 
	TCgxDriverState *pState, 
	TCgxDriverPhysicalMemory *apChunk);

/**
	Stop driver

    \param[in]  pDriver			Global driver structure pointer 	

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverStop(
	void *pDriver);



/**
	Execute request

    \param[in]  pDriver			Global driver structure pointer 	
    \param[in]  pState			Driver state structure pointer
    \param[in]  apChunk			Chunk memory information structure pointer
    \param[in]  aRequest		
    \param[in]  pControl		
    \param[in]  pResults		

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverExecute(
	void *pDriver, 
	TCgxDriverState *pState, 
	TCgxDriverPhysicalMemory *apChunk, 
	U32 aRequest, 
	TCgDriverControl *pControl, 
	TCgDriverStatus *pResults);

/**
	Move chip to power down mode

    \param[in]  apChunk			Chunk memory information structure pointer

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverPowerDown(TCgxDriverPhysicalMemory *apChunk);


/**
	Handle general interrupt

    \param[in]  pDriver			Global driver structure pointer 	
    \param[in]  pState			Driver state structure pointer

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode HandleGeneralInterrupt(
	void *pDriver, 
	TCgxDriverState *pState);



/**
	Handle data ready interrupt

    \param[in]  pDriver			Global driver structure pointer 	
    \param[in]  pState			Driver state structure pointer

	\return System wide return code
	\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverDataReadyInterruptHandler(
	void *pDriver, 
	TCgxDriverState *pState);

/**
Handle gps interrupt

\param[in]  pDriver			Global driver structure pointer 	
\param[in]  pState			Driver state structure pointer

\return System wide return code
\retval ECgOk if data ready is 0 (low active)

*/
TCgReturnCode CgxDriverGpsInterruptHandler(
	void *pDriver, 
	TCgxDriverState *pState);

TCgReturnCode CgxDriverHardwareReset(unsigned long aResetLevel);

#endif
