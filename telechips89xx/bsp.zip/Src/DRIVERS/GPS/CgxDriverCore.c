/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
  \file 
  \brief CellGuide CGX5900 driver core logic  (OS & CPU independed)

*/


#include "CgxDriverCore.h"					/**< CellGuide Driver core API */
#include "CgCpu.h"							/**< CellGuide CPU specific API */
#include "platform.h"						/**< CellGuide Driver platform specific details */
#include "CgxDriverOs.h"					/**< CellGuide Driver OS specific API */
#include "CgBuildNumber.h"					/**< CellGuide Build information */
#include "CgVersion.h"						/**< CellGuide Version API */
#include "CgxDriverPlatform.h"


const TCgVersion gCgDriverVersion = {
	CG_BUILD_VERSION, 
	CG_BUILD_ORIGINATOR,
	CGX_PLATFORM_NAME,
	CG_BUILD_NUMBER,
	CG_BUILD_DATE,
	CG_BUILD_TIME,
	CG_BUILD_MODE
};

extern void *memcpy(void *, const void *, unsigned int);
extern void *memset(void *, int, unsigned int);



#define CHUNK_SIZE_DEFAULT		(4 * 1024)
#define REGISTER_READ_TIME_OUT	(100)
#define CG_INT_DIV_CEIL(__counter__,__devider__)			( ((__counter__) + (__devider__) -1) / (__devider__) )

TCgReturnCode CgxDriverHardwareReset(unsigned long aResetLevel)
{
	TCgReturnCode rc = ECgOk;
	RETAILMSG(0,(TEXT("\n\r[reset] %x"),aResetLevel));
   switch (aResetLevel) {
	case 0:
		if (OK(rc)) rc = CgCpuGpioSet(CGX5000_SPI_CS);	// Make sure CS isn't '1' (CS is active low)
		if (OK(rc)) rc = CgCpuDelay(100000);
		if (OK(rc)) rc = CgCpuGpioSet(CGX5000_RESET);
		if (OK(rc)) rc = CgCpuDelay(100000);
		if (OK(rc)) rc = CgCpuGpioReset(CGX5000_RESET);
		if (OK(rc)) rc = CgCpuDelay(100000);
		if (OK(rc)) rc = CgCpuGpioSet(CGX5000_RESET);
		break;
	case 1:
		if (OK(rc)) rc = CgCpuGpioReset(CGX5000_SPI_CS);
		if (OK(rc)) rc = CgCpuDelay(100000);
		if (OK(rc)) rc = CgCpuGpioSet(CGX5000_RESET);
		if (OK(rc)) rc = CgCpuDelay(100000);
		if (OK(rc)) rc = CgCpuGpioReset(CGX5000_RESET);
		if (OK(rc)) rc = CgCpuDelay(100000);
		if (OK(rc)) rc = CgCpuGpioSet(CGX5000_RESET);
		if (OK(rc)) rc = CgCpuGpioSet(CGX5000_SPI_CS);
		break;
	case 2 :		//	HWResetLevelCPU
		RETAILMSG(1,(TEXT("\n\r[reset] %x"),aResetLevel));
		rc = CgCpuDmaDestroy(0,0);
		if (OK(rc)) rc = CgCpuDelay(100000);
		if (OK(rc)) rc = CgCpuDmaCreate(0,0);
		break;
	default:
		rc = ECgGeneralFailure;
	}

	if (OK(rc)) rc = CgxDriverDataReadyPrepare();

	return rc;
}




TCgReturnCode CgxDriverStop(void *pDriver)
{
	TCgReturnCode rc = ECgOk;
	rc = CgCpuGpioDestroy();
	if (OK(rc)) rc = CgCpuRtcDestroy();
	if (OK(rc)) rc = CgCpuSpiDestroy();
	if (OK(rc)) rc = CgCpuDmaDestroy(0,0);	// TODO : write correct values (#define them)
	if (OK(rc)) rc = CgCpuIntrDestroy();
	if (OK(rc)) rc = CgCpuClockDestroy();
	if (OK(rc)) rc = CgxDriverTransferEndDestroy(pDriver);
	return rc;
}






TCgReturnCode CgxDriverConstruct(void *pDriver, TCgxDriverState *pState, TCgxDriverPhysicalMemory *apChunk)
{
	TCgReturnCode rc = ECgOk;

	pState->counters.powerDown = 0;
	pState->counters.powerUp = 0;

	if (OK(rc)) rc = CgCpuAllocateVa();

	if (OK(rc)) rc = CgCpuGpioCreate();
	
	if (OK(rc)) rc = CgCpuRtcCreate();
	if (OK(rc)) rc = CgCpuSpiCreate();

	if (OK(rc)) rc = CgCpuDmaCreate(0,0);	// TODO : write correct values (#define them)
	if (OK(rc)) rc = CgCpuIntrCreate();
	if (OK(rc)) rc = CgCpuClockCreate();
	#ifdef CGX5000_POWER_EN 
		#ifdef CGX5000_POWER_EN_RESET
			if (OK(rc)) rc = CgCpuGpioReset(CGX5000_POWER_EN);	
		#else
			if (OK(rc)) rc = CgCpuGpioSet(CGX5000_POWER_EN);	
		#endif
	#endif
	#ifdef CGX5000_TCXO_EN
		if (OK(rc)) rc = CgCpuGpioReset(CGX5000_TCXO_EN);
	#endif

	if (OK(rc)) rc = CgxDriverInterruptPrepare();
	if (OK(rc)) rc = CgxDriverSpiPrepare();		
	if (OK(rc)) rc = CgxDriverResetPrepare();	
	if (OK(rc)) rc = CgxDriverHardwareReset(0);	
	if (OK(rc)) 
	{
		rc = CgxDriverAllocateChunkMemory(pDriver, apChunk, CHUNK_SIZE_MAX);
		if (!OK(rc)) 
		{
			apChunk->length = 0;
			apChunk->appContextVirtAddr = NULL;
			apChunk->physAddr = 0;
			apChunk->driverContextVirtBufferAddr = NULL;
		}
	}
	if (OK(rc)) rc = CgxDriverTransferEndCreate(pDriver);

	// set up Data interrupt handler
	//if (OK(rc)) rc = CgxDriverDataReadyInterruptPrepare();
	if (OK(rc)) rc = CgxDriverDataReadyInterruptHandlerStart(pDriver);

    if (CgxDriverGeneralInterruptCode())
		if (OK(rc)) rc = CgxDriverGeneralInterruptHandlerStart(pDriver);

	pState->lastErrorCode = rc;

	return rc;
}




#ifndef MIN
	#define MIN(__a__, __b__) 					((__a__) < (__b__) ? (__a__) : (__b__))
#endif

#ifndef MAX
	#define MAX(__a__, __b__) 					((__a__) > (__b__) ? (__a__) : (__b__))
#endif



TCgReturnCode CgxDriverWrite(unsigned char *pSource, unsigned long aLength, TCgxDriverPhysicalMemory *apChunk)
{
	// TODO pSource is user space!!! use CgxDriverMapPointer()
	TCgReturnCode rc = ECgOk;
	if(pSource == NULL)
		return ECgBadArgument;
	while( OK(rc) && aLength > 0 ) 
	{
		U32 length = MIN(aLength, apChunk->length);
		CgxCopyFromUser((unsigned char *)apChunk->driverContextVirtBufferAddr, pSource, length);

		rc = CgxDriverWriteData(apChunk->driverContextVirtBufferAddr, apChunk->physAddr, length);													
		aLength -= length;
		pSource += length;
	}
	return rc;
}





TCgReturnCode CgxDriverDebugGpio(int aControlLine, int aVal)
{
	TCgReturnCode rc = ECgOk;
	int gpioCode = 0;
	CgxDriverGpioCode(aControlLine, &gpioCode);
	if (aVal) 
		CgCpuGpioSet((U32)gpioCode); 
	else 
		CgCpuGpioReset((U32)gpioCode); 
	return rc;
}



TCgReturnCode CgxDriverDebugGpioRead(int aControlLine, int *aVal)
{
	TCgReturnCode rc = ECgOk;
	int gpioCode = 0;
	CgxDriverGpioCode(aControlLine, &gpioCode);

	CgCpuGpioGet((U32)gpioCode, aVal); 
	return rc;
}







TCgReturnCode HandleGeneralInterrupt(void *pDriver, TCgxDriverState *pState)
{
	pState->flags.overrun++;
	pState->counters.interrupt.overrun++;
	pState->counters.interrupt.all++;
	CgxDriverTransferEndSignal(pDriver);
	return ECgOk;
#define INT_DIV_CEIL(x,y) (((x) / (y)) + (x%y > 0)) // temporary, need to be replace by Koby
}









TCgReturnCode ClearOverrun(TCgxDriverState *pState, TCgxDriverPhysicalMemory *apChunk)
{
	TCgReturnCode rc = ECgOk;
	U32 cleanBlockSize = MIN(16, CHUNK_SIZE_MAX);
	for(pState->counters.overrunLeftOver = 0 ; pState->counters.overrunLeftOver < 100000; pState->counters.overrunLeftOver += cleanBlockSize) {		
		if(!OK(CgxDriverIsDataReady())) {
			pState->flags.overrun = 0;
			break;
			}
		rc = CgxDriverClearData(apChunk->driverContextVirtBufferAddr, apChunk->physAddr, cleanBlockSize);
		CgxDriverReadWait();
		}
	pState->transfer.bytes.received = 0;
	pState->transfer.bytes.required = 0;
	pState->transfer.blocks.received = 0;
	pState->transfer.blocks.required = 0;
	pState->transfer.chunks.received = 0;
	pState->transfer.chunks.required = 0;
	CgxDriverDataReadyPrepare();
	return ECgOk;
}



static U32 ReversBytes(U32 arg)
{
	arg = (arg & 0x00FF00FF) << 8 | (arg & 0xFF00FF00) >> 8;
	arg = (arg & 0x0000FFFF) << 16 | (arg & 0xFFFF0000) >> 16;
	return arg; 
}



static TCgReturnCode WriteRegister(TCgxDriverPhysicalMemory *apChunk, U32 aRegisterOffset, U32 aValue)
{
    TCgReturnCode rc = ECgOk;
	U32 spiCommand[2] = {0};
	spiCommand[0] = 0x00801AE5
				  | ((aRegisterOffset & 0x000000FF) << 24) 
				  | ((aRegisterOffset & 0x00000F00) << 8);

	spiCommand[1] = ReversBytes(aValue);
	rc = CgxDriverWrite((unsigned char *)&spiCommand, 8, apChunk);
    return rc;
}

TCgReturnCode CgxDriverPowerDown(TCgxDriverPhysicalMemory *apChunk)
{
	TCgReturnCode rc = ECgOk;
	rc =  WriteRegister(apChunk, 0xCC, 0xFDB96420);
	CgCpuGpioSet(CGX5000_SPI_CS); // CS --> 1
	return rc;
}

TCgReturnCode CgxDriverPowerUp(void)
{
	TCgReturnCode rc = ECgOk;

	if (OK(rc)) rc = CgCpuGpioReset(CGX5000_SPI_CS); 
	if (OK(rc)) rc = CgCpuDelay(5);
	if (OK(rc)) rc = CgCpuGpioSet(CGX5000_SPI_CS);
	if (OK(rc)) rc = CgCpuDelay(5);
	if (OK(rc)) rc = CgCpuGpioReset(CGX5000_SPI_CS);

	return rc;
}




TCgReturnCode CopyChunk(unsigned char *pSource, unsigned char *pDest, U32 aLength, TCgByteOrder aByteOrder)
{
	TCgReturnCode rc = ECgOk;
	
	if (CGX_DRIVER_NATIVE_BYTE_ORDER == aByteOrder) {
		memcpy(pDest, pSource, aLength);
		}
	else {
		// TODO NG should be according to byte order!!!!
		U32 i;
		U32 *p1;
		U32 *p2;

		/*lint -e826*/ 
		p1 = (U32*)pSource;
		/*lint -e826*/ 
		p2 = (U32*)pDest;

		for(i = 0;  i < aLength / sizeof(U32); i++, p2++, p1++) {
			*p2 = (*p1 & 0xFFFF0000) >> 16 | (*p1 & 0x0000FFFF) << 16;					
			}                
		}
	return rc;
}




//#define INT_DIV_CEIL(x,y) ((x + ((y)/2)) / (y))
#define CG_INT_DIV_CEIL(__counter__,__devider__)			( ((__counter__) + (__devider__) -1) / (__devider__) )


TCgReturnCode CgxDriverPrepareRecieve(
	TCgxDriverState *pState, 
	unsigned char *apBuf,
	U32 aBufSize,
	unsigned long aLength, 
	unsigned long aBlockLength,
	TCgByteOrder aByteOrder)
{
	DBG_FUNC_NAME("CgxDriverPrepareRecieve")
	TCgReturnCode rc = ECgOk;
	U32 blockIndex = 0;
	U32 numOfBlocksInBuffer = 0;

	pState->transfer.blockSize = ((aBlockLength == 0) || (aLength < aBlockLength)) ? aLength : aBlockLength;
	pState->transfer.bytes.received = 0;
	pState->transfer.blocks.received = 0;
	pState->transfer.chunks.received = 0;

	pState->transfer.originalBuffer = apBuf;
	if ( aLength <= 4 )
		// read a register
		pState->transfer.buffer = CgxDriverGetInternalBuff(apBuf, aLength);
	else
	{
		// TODO need to move this to WCE code
		#if ( (_WIN32_WCE == 0x600) )	// Windows CE6 
			// read snap data
			pState->transfer.buffer = (apBuf - pState->buffer.appContextVirtAddr) + pState->buffer.driverContextVirtBufferAddr;
		#else
			pState->transfer.buffer = CgxDriverGetInternalBuff(apBuf, aLength);
		#endif
	}

	//DBGMSG1("pState->transfer.buffer = 0x%x", pState->transfer.buffer)

	if (pState->transfer.buffer == NULL)
		return ECgErrNotInitialized;
	pState->transfer.byteOrder = aByteOrder;
	pState->transfer.bytes.required = aLength;
	pState->transfer.notificationThresholdBytes = aLength;
	pState->transfer.blocks.bytes = 0;
	pState->transfer.chunks.required = 0;
	pState->transfer.blocks.required = 0;

	pState->transfer.chunks.bytes = MIN(CHUNK_SIZE_DEFAULT, aLength);

	if(aBlockLength > 0) 
	{

//		pState->transfer.bufferSize = MAX((aBufSize / aBlockLength) * aBlockLength, 2 * aBlockLength);	// Length is either 8 bytes for read register,
																										// or the buffer size will be a multiple of 
																										// the block size, upto the maximum of the buffer length
		pState->transfer.bufferSize = (aBufSize / aBlockLength) * aBlockLength;	// the buffer size will be a multiple of 
																				// the block size, upto the maximum of the buffer length
		numOfBlocksInBuffer = pState->transfer.bufferSize / aBlockLength;
		pState->transfer.blocks.required = CG_INT_DIV_CEIL(aLength, aBlockLength);
		pState->transfer.blocks.fitInBuffer = pState->transfer.bufferSize / aBlockLength;
		pState->transfer.blocks.bytes = aBlockLength;
		pState->transfer.chunks.required = aBlockLength / pState->transfer.chunks.bytes;
		//DBGMSG1("transfer.chunks.required %d", pState->transfer.chunks.required)
		pState->transfer.notificationThresholdBytes = aBlockLength;
		
		for(blockIndex = 0; blockIndex < pState->transfer.blocks.required; blockIndex++)
		{
			// Init the snap's blocks' offsets
			pState->transfer.bufferOffset[blockIndex] = aBlockLength * (blockIndex % numOfBlocksInBuffer);	// roll-over to start of buffer, 
			// if we reached end of buffer.
			//DBGMSG2("buffer[%d] = 0x%08X", blockIndex, pState->transfer.bufferPhys + pState->transfer.bufferOffset[blockIndex])
				// TODO check chunk overflow (#chunks bigger then allocated memory)
		}
		
	}
	else
	{
		pState->transfer.bufferSize = aLength;

		pState->transfer.blocks.fitInBuffer = 1;	// TODO : check if when block size isn't specified, if buffer contains only 1 block
	}

		
	pState->transfer.chunks.required = pState->transfer.bytes.required / pState->transfer.chunks.bytes; 
	pState->transfer.nextChunkOffset = 0;

	//DBGMSG2("pState->transfer.chunks.required = %d, pState->transfer.bytes.required = %d", 
	//printf("\n\r p %x %x",pState->transfer.chunks.required, pState->transfer.bytes.required )		;
	return rc;
}






TCgReturnCode ReadRegister(void *pDriver,TCgxDriverState *pState, TCgxDriverPhysicalMemory *apChunk, U32 aRegisterOffset, U32 *apValue)
{
    TCgReturnCode rc = ECgOk;
	U32 spiCommand[2] = {0};
	U32 size = 0;
	unsigned char *pRegValue;
	spiCommand[0] = 0x00001AE5
				  | ((aRegisterOffset & 0x000000FF) << 24) 
				  | ((aRegisterOffset & 0x00000F00) << 8);
	
	// prepare driver to read the register value
	rc = CgxDriverPrepareRecieve(pState, (unsigned char *)apValue, 8, 4, 0, ECG_BYTE_ORDER_1234);
	// request read
	if (OK(rc)) rc = CgxDriverWrite((unsigned char *)&spiCommand, 4, apChunk);
	// wait for data
	if (OK(rc)) rc = CgxDriverTransferEndWait(pDriver, REGISTER_READ_TIME_OUT, &pRegValue, &size);
	if (OK(rc)) {
		*apValue = (*apValue & 0x00FF00FF) << 8 | (*apValue & 0xFF00FF00) >> 8;
		*apValue = (*apValue & 0x0000FFFF) << 16 | (*apValue & 0xFFFF0000) >> 16;
		}

    return rc;
}




#ifdef CGX_DRIVER_DATA_RECORDER


extern void * malloc(size_t);
extern void free(void *);
TCgCpuDmaTask *gDataRecorderTaskList = NULL;

/** 
	Recording was requested.
	aLength = total length of recording in bytes
	aBlockLength = length of one block of recording
  */
TCgReturnCode CgxDriverRecordStop(
	TCgxDriverState *pState)
{
	DBG_FUNC_NAME("CgxDriverRecordStop")
	TCgReturnCode rc = ECgOk;

	//TODO 


	return rc;
}

/** 
	Recording was requested.
	aLength = total length of recording in bytes
	aBlockLength = length of one block of recording
  */
TCgReturnCode CgxDriverRecordStart(
	TCgxDriverState *pState, 
	unsigned char *apBuf,
	unsigned long aLength, 
	unsigned long aBlockLength)
{
	DBG_FUNC_NAME("CgxDriverRecordStart")
	TCgReturnCode rc = ECgOk;
	U32 blockIndex = 0;	pState->transfer.bytes.received = 0;
	pState->transfer.blocks.received = 0;

	pState->transfer.originalBuffer = apBuf;
	pState->transfer.bufferPhys = pState->buffer.addr; 

	pState->transfer.bytes.required = aLength;
	pState->transfer.blocks.bytes = aBlockLength;
	pState->transfer.notificationThresholdBytes = aBlockLength;
	pState->transfer.blocks.required = aLength / aBlockLength;
	pState->transfer.bufferSize = 2 * aBlockLength; // TODO add support for N buffer	
	pState->transfer.nextChunkOffset = 0;

	if (gDataRecorderTaskList != NULL)
		free(gDataRecorderTaskList);
	gDataRecorderTaskList = malloc(sizeof(TCgCpuDmaTask) * pState->transfer.blocks.required);

	// generate DMA tasks list
	for(blockIndex = 0; blockIndex < pState->transfer.blocks.required; blockIndex++) {
		U32 dest = pState->transfer.bufferPhys + pState->transfer.bufferOffset[blockIndex % 2];		
		DBGMSG4("Block %02d/%02d: % 6d bytes @ 0x%08X", blockIndex + 1, pState->transfer.blocks.required, aBlockLength, dest)
		gDataRecorderTaskList[blockIndex].address = dest;
		gDataRecorderTaskList[blockIndex].length = aBlockLength;
		}

	// setup DMA 1st block (if support LLI, then all blocks)
	rc = CgCpuDmaSetupFromDeviceFirstTask(gDataRecorderTaskList, pState->transfer.blocks.required, CG_DRIVER_DMA_CHANNEL_READ, CG_CPU_DEVICE_SPI);
	rc = CgCpuDmaStart(CG_DRIVER_DMA_CHANNEL_READ);
	// setup SPI to receive data (slave...)
	rc = CgCpuSpiSlaveConfig(CG_CPU_DEVICE_SPI, aLength);
	// setup DMA next block - if not supporting LLI (wait for DMA to start, setup)
	rc = CgCpuDmaSetupFromDeviceNextTask(gDataRecorderTaskList, pState->transfer.blocks.required, pState->transfer.blocks.received, CG_DRIVER_DMA_CHANNEL_READ, CG_CPU_DEVICE_SPI);
	return rc;
}

#endif

TCgReturnCode CgxDriverExecute(
	void *pDriver, 
	TCgxDriverState *pState, 
	TCgxDriverPhysicalMemory *apChunk, 
	U32 aRequest, 
	TCgDriverControl *pControl, 
	TCgDriverStatus *pResults)
{
	DBG_FUNC_NAME("CgxDriverExecute")
	TCgReturnCode rc = ECgOk;

//	DBGMSG1("Start %d", aRequest)

    switch (aRequest) {
		case CGX_IOCTL_INIT: 
			rc = CgxDriverInit(pDriver);
			break;
			
		case CGX_IOCTL_STOP: 
			rc = CgxDriverStop(pDriver);
			break;

		case CGX_IOCTL_WRITE: 
			pState->request.abortReceive = FALSE;
			rc = CgxDriverWrite(pControl->write.pSource, pControl->write.length, apChunk);
			break;		
			
		case CGX_IOCTL_PREPARE_RECEIVE: 
			pState->request.abortReceive = FALSE;
			rc = CgxDriverPrepareRecieve(	pState, pControl->read.buf, pState->buffer.length, 
											pControl->read.alignedLength, pControl->read.blockLength, 
											pControl->read.byteOrder);
			break;

		case CGX_IOCTL_WAIT_RCV:
			pState->request.waitReceive = TRUE;

			// Check if the block required wasn't already received
			if ( pControl->wait.blockNumber >= pState->transfer.blocks.received )
			{
				// It wasn't received, so wait for one block (any block - could be several blocks before the requested one)
				rc = CgxDriverTransferEndWait(pDriver, pControl->wait.timeoutMS, &(U8*)(pResults->buffer.appVirtAddr), &pResults->buffer.size);

				// override the buffer address returned - with the already known buffer offset. We use the block number
				// we are waiting on to calculate the offset (It was calculated by the last received block)
				if ( OK(rc) )
					pResults->buffer.appVirtAddr = pState->transfer.originalBuffer + pState->transfer.bufferOffset[pControl->wait.blockNumber] ;
			}
			else
			{
				// Release possible event received, so we won't receive a false event - timeout is 0
				CgxDriverTransferEndWait(pDriver, 0, &(U8*)(pResults->buffer.appVirtAddr), &pResults->buffer.size);

				// Block was already received, and there is no need to wait for it
				pResults->buffer.appVirtAddr = pState->transfer.originalBuffer + pState->transfer.bufferOffset[pControl->wait.blockNumber] ;
				pResults->buffer.size = (pState->transfer.blocks.bytes == 0) 
					? pState->transfer.bytes.received 
					: pState->transfer.blocks.bytes;

			}

			// Check if no data was received by from the DMA, even after we waited for pControl->wait.timeoutMS
			if ( (rc == ECgTimeout) || (pState->transfer.blocks.received == 0) ) 
			{
				pResults->buffer.appVirtAddr = pState->transfer.originalBuffer;
				pResults->rc = ECgOutOfBounds;
			}

			pState->request.waitReceive = FALSE;
			break;
						
		case CGX_IOCTL_STATUS:
			// nothing to do - status is always returned.
			// leave this, so we can get the last status without doing any operation.
			pResults->rc = pState->lastErrorCode;
			break;

		case CGX_IOCTL_RESET:
			pState->request.abortReceive = FALSE;
			CgxDriverHardwareReset(pControl->reset.resetLevel);
			break;

		case CGX_IOCTL_POWER_DOWN:
			rc = CgxDriverPowerDown(apChunk);
			break;

		case CGX_IOCTL_POWER_UP:
			pState->request.abortReceive = FALSE;
			CgxDriverPowerUp();
			break;

		case CGX_IOCTL_CLEAR_OVERRUN:
			//printf("\n\r[ClearOverrun]");
			pState->request.abortReceive = FALSE;
			rc = ClearOverrun(pState, apChunk);
			break;

		case CGX_IOCTL_GPIO_SET:
			DBGMSG2("CGX_IOCTL_GPIO_SET 0x%08X = %d", pControl->GPIO.code, pControl->GPIO.out)
			if (pControl->GPIO.out) 
				CgCpuGpioSet(pControl->GPIO.code); 
			else 
				CgCpuGpioReset(pControl->GPIO.code); 
			pResults->GPIO.code = pControl->GPIO.code;
			pResults->GPIO.val = pControl->GPIO.out;
			break;

		case CGX_IOCTL_GPIO_GET:
			rc = CgCpuGpioGet(pControl->GPIO.code, &(pResults->GPIO.val)); 
			pResults->GPIO.code = pControl->GPIO.code;
			break;


		case CGX_IOCTL_GET_VERSION:
			DBGMSG("CGX_IOCTL_GET_VERSION")
			memcpy(pResults->version.buildVersion, gCgDriverVersion.buildVersion, sizeof(pResults->version.buildVersion));
			memcpy(pResults->version.buildMode, gCgDriverVersion.buildMode, sizeof(pResults->version.buildMode));
			memcpy(pResults->version.buildNumber, gCgDriverVersion.buildNumber, sizeof(pResults->version.buildNumber));
			memcpy(pResults->version.buildTime, gCgDriverVersion.buildTime, sizeof(pResults->version.buildTime));
			memcpy(pResults->version.buildDate, gCgDriverVersion.buildDate, sizeof(pResults->version.buildDate));
			memcpy(pResults->version.buildName, gCgDriverVersion.buildName, sizeof(pResults->version.buildName));
			break;

		case CGX_IOCTL_CANCEL_RECEIVE:
 

 			// protection against divide in zero
			if( pState->transfer.chunks.bytes != 0 )
			{
				pState->transfer.cancel.onChunk = (pControl->cancel.onByteCount / pState->transfer.chunks.bytes);

				if (pState->request.waitReceive && (pState->transfer.chunks.received > pState->transfer.cancel.onChunk))
					CgxDriverTransferEndSignal(pDriver);
			}
			else
			{
				pState->transfer.cancel.onChunk = 0;
				if (pState->request.waitReceive)
					CgxDriverTransferEndSignal(pDriver);
			}

			// set up receive abort flag.
			// the flag is cleared be prepare receive command
			pState->request.abortReceive = TRUE;
			RETAILMSG(0,(TEXT("[CANCELRV] %x"),pState->transfer.cancel.onChunk));
			break;

		case CGX_IOCTL_ALLOC_BUFF:
			/*
			 * XXX-PK-XXX: Check if already allocated...
			 */
			rc = CgxDriverAllocInternalBuff(pDriver, pControl->alloc.length, &pResults->buffer.appVirtAddr
											, pControl->alloc.processId);			
			if (OK(rc)) 
			{
				pResults->buffer.size = pControl->alloc.length;
				pResults->buffer.bufferPhysAddr = (U8*)pState->buffer.physAddr;
			}
			break;

		case CGX_IOCTL_FREE_BUFF:
			rc = CgxDriverFreeInternalBuff(pDriver, pControl->alloc.processId);
			break;

		case CGX_IOCTL_WRITE_REG:
			//pState->transfer.cancel.request = FALSE;
			rc =  WriteRegister(apChunk, pControl->writeReg.offset, pControl->writeReg.value);
			break;
		case CGX_IOCTL_READ_REG:
			rc =  ReadRegister(pDriver, pState, apChunk, pControl->readReg.offset, &pResults->readReg.value);
			pResults->readReg.offset = pControl->readReg.offset;

			break;
		case CGX_IOCTL_READ_RTC:
			rc = CgCpuRtcRead((TCgCpuRtcTime*)&(pResults->readRtc));
			break;
#ifdef CGX_DRIVER_DATA_RECORDER
		case CGX_IOCTL_RECORD_STOP: 
			DBGMSG("CGX_IOCTL_RECORD_STOP")
			rc = CgxDriverRecordStop(pState);
			break;

		case CGX_IOCTL_RECORD_START: 
			DBGMSG("CGX_IOCTL_RECORD_START")
			rc = CgxDriverRecordStart(pState, pControl->read.buf, pControl->read.alignedLength, pControl->read.blockLength);
			break;

		case CGX_IOCTL_RECORD_WAIT:
			DBGMSG("CGX_IOCTL_RECORD_WAIT")
			pState->request.waitReceive = TRUE;
			rc = CgxDriverTransferEndWait(pDriver, pControl->read.timeoutMS, &pResults->buffer.appVirtAddr, &pResults->buffer.size);
			pState->request.waitReceive = FALSE;
			break;	
#endif
		default:
			rc = ECgGeneralFailure;
		}
	pResults->state = *pState;
	pResults->rc = rc;
	
    return ECgOk;
}


TCgReturnCode CgxDriverDataReadyInterruptHandler(void *pDriver, TCgxDriverState *pState)
{
	DBG_FUNC_NAME("CgxDriverDataReadyInterruptHandler")
		
	TCgReturnCode rc = ECgOk;
	TCgxDriverPhysicalMemory * pChunk = (TCgxDriverPhysicalMemory*)GetDriverChunk(pDriver);

	//DBGMSG("start")
	//printf("\n\r dr");
	pState->counters.interrupt.dataReady++;
	pState->transfer.chunks.received++;

	if (pState->request.abortReceive && (pState->transfer.chunks.received > pState->transfer.cancel.onChunk)) {
		CgCpuGpioMode(CGX5000_DR, ECG_CPU_GPIO_INPUT);

		pState->transfer.chunks.required = pState->transfer.cancel.onChunk;
		RETAILMSG(0,(TEXT("[cancel] ")));
// 		CgCpuSpiDisable(SPI_CHANNEL);
// 		CgCpuGpioSet(CGX5000_SPI_CS); // CS --> 1
// 		CgCpuDmaStop(READ_DMA_CHANNEL);
// 		CgCpuDmaStop(WRITE_DMA_CHANNEL);
// 		return ECgCanceled;
		}

/*	/////////////////////////////////////  Read an extra 4kb if data ready is still 0 ////////////////////////////////////////////////

 	do{
		CgxDriverReadData(apChunk->ptr, apChunk->physAddr, pState->transfer.chunk.bytes);
		CgxDriverReadWait(); // wait for transfer to finish before informaing the application of new data (safe side)
		CgxDriverReadDataTail(apChunk->ptr, physicalAddr, pState->transfer.chunk.bytes);
 		ReorderBytes(apChunk->ptr, virtAddress, pState->transfer.chunk.bytes);
 		pState->transfer.nextChunkOffset += pState->transfer.chunk.bytes;

 	}while(CgxDriverIsDataReady() == 0);

	CgxDriverDataReadyPrepare();	
	
*/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// finish handling of last chunk
 	if(pState->transfer.chunks.received > 1) {
		U32 copyLength1 = MIN(pState->transfer.chunks.bytes, pState->transfer.bufferSize - pState->transfer.nextChunkOffset);
		U32 copyLength2 = pState->transfer.chunks.bytes - copyLength1;
		unsigned char *src = pChunk->driverContextVirtBufferAddr;
		unsigned char *dst = pState->transfer.buffer + pState->transfer.nextChunkOffset;

		rc = CgxDriverReadDataTail(pChunk->driverContextVirtBufferAddr, pChunk->physAddr, pState->transfer.chunks.bytes);

		// Copy 1st part of chunk
//		printf(" %x %x %x",src, dst, copyLength1);
 		if (OK(rc)) rc = CopyChunk(src, dst, copyLength1, pState->transfer.byteOrder);
		if (OK(rc)) pState->transfer.nextChunkOffset += copyLength1;

		// Copy leftover of chunk, if exists
		if (OK(rc) && (copyLength2 > 0)) {
			src += copyLength1;
			dst = pState->transfer.buffer;
			rc = CopyChunk(src, dst, copyLength2, pState->transfer.byteOrder);
			if (OK(rc)) pState->transfer.nextChunkOffset = copyLength2;
			}
		pState->transfer.bytes.received += pState->transfer.chunks.bytes;
  		}

//	DBGMSG("blahblah")

	// start receiving of new chunk
	#ifdef CGX_DRIVER_PRESET
		memset(pChunk->driverContextVirtBufferAddr, CGX_DRIVER_PRESET, pState->transfer.chunks.bytes);
	#endif
	CgxDriverReadData(pChunk->driverContextVirtBufferAddr, pChunk->physAddr, pState->transfer.chunks.bytes);


	if(pState->transfer.chunks.received >= pState->transfer.chunks.required) {		
		U32 copyLength = MIN(pState->transfer.chunks.bytes, pState->transfer.bufferSize - pState->transfer.nextChunkOffset);
		unsigned char *dst = pState->transfer.buffer + pState->transfer.nextChunkOffset;
		CgxDriverReadWait();
		CgxDriverReadDataTail(pChunk->driverContextVirtBufferAddr, pChunk->physAddr, pState->transfer.chunks.bytes);
//		DBGMSG3("CopyChunk from 0x%x to 0x%x, size = %d", pChunk->virtAddr, dst, copyLength)
// 		printf(" %x %x %x",pChunk->virtAddr, dst, copyLength);
		rc = CopyChunk(pChunk->driverContextVirtBufferAddr, dst, copyLength, pState->transfer.byteOrder);
		pState->transfer.bytes.received += pState->transfer.chunks.bytes;

		// transfer completed

		pState->transfer.blocks.received++;

		CgxDriverTransferEndSignal(pDriver);
		}
	else if(pState->transfer.bytes.received >= pState->transfer.notificationThresholdBytes) {
		// we have completely downloaded the next block, and it's not the final block
		pState->transfer.blockOffset = ((pState->transfer.blocks.received % pState->transfer.blocks.fitInBuffer) * 
										pState->transfer.blocks.bytes);

		pState->transfer.blocks.received++;
		pState->transfer.notificationThresholdBytes += pState->transfer.blocks.bytes;

		CgxDriverReadWait(); // ??????
		CgxDriverTransferEndSignal(pDriver);
		}
	

	return rc;
}
