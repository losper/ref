/* ???*/
/* Build: 3477 */
/**
 * \file CgVariant.h
 * \brief Variant type support

 * Defines the TCgVariant type and utilities
*/
#ifndef CG_VARIANT_H
#define CG_VARIANT_H

#ifdef	__cplusplus
extern "C" {
#endif /*__cplusplus*/

#include "CgTypes.h"
#include "CgReturnCodes.h"
#include "CgTime.h"

/**
@defgroup cgcommon_variant Variant type
*/
/*@{*/

#define E_VARIANT_STRING   (0)				/*!< String type */
#define E_VARIANT_U32      (1)				/*!< Unsigned 32 bit integer type */
#define E_VARIANT_U16      (2)				/*!< Unsigned 16 bit integer type */
#define E_VARIANT_U8       (3)				/*!< Unsigned 8 bit integer type */
#define E_VARIANT_S32      (4)				/*!< Signed 32 bit integer type */
#define E_VARIANT_S16      (5)				/*!< Signed 16 bit integer type */
#define E_VARIANT_S8       (6)				/*!< Signed 8 bit integer type */
#define E_VARIANT_FLOAT    (7)				/*!< Float type */
#define E_VARIANT_DOUBLE   (8)				/*!< Double type */
#define E_VARIANT_BOOL     (9)				/*!< Boolean type */
#define E_VARIANT_NONE     (10)				/*!< None type */
#define E_VARIANT_TIME     (11)				/*!< Time type */
#define E_VARIANT_VOID_PTR (12)				/*!< Generic pointer type*/
#define E_VARIANT_U64	   (13)				/*!< Unsigned 64 bit integer type*/

/**
 * Variant type to pass variant types of information using one union
*/
typedef struct SCgVariant{
	U32 type;
	union {
		U32 test[3];
		U64		i_u64;
		U32		i_u32;
		U16		i_u16;
		U8		i_u8;
		S32		i_s32;
		S16		i_s16;
		S8		i_s8;
		BOOL	i_bool;
		FLOAT	i_float;
		DOUBLE  i_double;
		const T8 *	i_text;
		TCgAgpsTime i_time;
		void *   i_ptr;
	} value;
} TCgVariant;


/** The Destructor */
#define CG_SET_VARIANT_U64(variant, val) 	    {(variant).value.i_u64 		= val; (variant).type = E_VARIANT_U64;}
#define CG_SET_VARIANT_U32(variant, val) 	    {(variant).value.i_u32 		= val; (variant).type = E_VARIANT_U32;}
#define CG_SET_VARIANT_U16(variant, val)		{(variant).value.i_u16 		= val; (variant).type = E_VARIANT_U16;}
#define CG_SET_VARIANT_U8(variant, val) 		{(variant).value.i_u8 		= val; (variant).type = E_VARIANT_U8;}
#define CG_SET_VARIANT_S32(variant, val) 	    {(variant).value.i_s32 		= val; (variant).type = E_VARIANT_S32;}
#define CG_SET_VARIANT_S16(variant, val) 	    {(variant).value.i_s16 		= val; (variant).type = E_VARIANT_S16;}
#define CG_SET_VARIANT_S8(variant, val) 		{(variant).value.i_s8  		= (val); (variant).type = E_VARIANT_S8;}
#define CG_SET_VARIANT_BOOL(variant, val) 	    {(variant).value.i_bool 	= (val); (variant).type = E_VARIANT_BOOL;}
#define CG_SET_VARIANT_FLOAT(variant, val) 	{(variant).value.i_float 	= (val); (variant).type = E_VARIANT_FLOAT;}
#define CG_SET_VARIANT_DOUBLE(variant, val) 	{(variant).value.i_double 	= (val); (variant).type = E_VARIANT_DOUBLE;}
#define CG_SET_VARIANT_STRING(variant, val) 	{(variant).value.i_text  	= (val); (variant).type = E_VARIANT_STRING;}
#define CG_SET_VARIANT_TIME(variant, val) 		{(variant).value.i_time  	= (val); (variant).type = E_VARIANT_TIME;}
#define CG_SET_VARIANT_VOID_PTR(variant, val) 	{(variant).value.i_ptr  	= (val); (variant).type = E_VARIANT_VOID_PTR;}

#define CG_VARIANT_U64(variant) 	    ((variant).value.i_u64)
#define CG_VARIANT_U32(variant) 	    ((variant).value.i_u32)
#define CG_VARIANT_U16(variant)		((variant).value.i_u16)
#define CG_VARIANT_U8(variant) 		((variant).value.i_u8)
#define CG_VARIANT_S32(variant) 	    ((variant).value.i_s32)
#define CG_VARIANT_S16(variant) 	    ((variant).value.i_s16)
#define CG_VARIANT_S8(variant) 		((variant).value.i_s8)
#define CG_VARIANT_BOOL(variant) 	    ((variant).value.i_bool != 0)
#define CG_VARIANT_FLOAT(variant) 		((variant).value.i_float)
#define CG_VARIANT_DOUBLE(variant) 	((variant).value.i_double)
#define CG_VARIANT_STRING(variant) 	(const char*)((variant).value.i_text)
#define CG_VARIANT_TIME(variant) 		((variant).value.i_time)
#define CG_VARIANT_VOID_PTR(variant)	((variant).value.i_ptr)

/**
    Convert types

    Converts one type of data to another usign variant union, according to each type.

    \param aSource Pointer to the source variant
    \param aDestination Pointer to the target variant
	\return ECgOk On success
*/
TCgReturnCode CgVariantConvert(const TCgVariant *aSource, TCgVariant *aDestination);

/*@}*/

#ifdef	__cplusplus
}
#endif /*__cplusplus*/


#endif
