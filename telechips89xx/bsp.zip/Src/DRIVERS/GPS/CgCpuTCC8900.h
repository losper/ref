/******************************************************************************
 *                                LEGAL NOTICE                                *
 *                                                                            *
 *  USE OF THIS SOFTWARE (including any copy or compiled version thereof) AND *
 *  DOCUMENTATION IS SUBJECT TO THE SOFTWARE LICENSE AND RESTRICTIONS AND THE *
 *  WARRANTY DISLCAIMER SET FORTH IN LEGAL_NOTICE.TXT FILE. IF YOU DO NOT     *
 *  FULLY ACCEPT THE TERMS, YOU MAY NOT INSTALL OR OTHERWISE USE THE SOFTWARE *
 *  OR DOCUMENTATION.                                                         *
 *  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS NOTICE, INSTALLING OR    *
 *  OTHERISE USING THE SOFTWARE OR DOCUMENTATION INDICATES YOUR ACCEPTANCE OF *
 *  THE LICENSE TERMS AS STATED.                                              *
 *                                                                            *
 ******************************************************************************/
/* Version: 1.8.3 */
/* Build  : 3477 */
/* Date   : 30/07/2009 */
/**
	\file 
	\brief CellGuide platform specific 

	\defgroup CG_CPU_TCC8900 Samsung TCC8900 CPU Specific
	\{
*/
#ifndef TCC8900_H
#define TCC8900_H

#include "tcc8900_gpsb.h"
#include "tcc8900_gpio.h"

#define CG_CPU_RESET_BIT_GPS					(28)

#define CG_CPU_CGX5500_BASE_PHYS		(0xF053A000)
#define CG_CPU_CGX5000_BASE_PA		*(volatile unsigned long *)(CG_CPU_CGX5500_BASE_PHYS)

#define CG_CPU_TCC8900_GPSCLK *(volatile unsigned long *)(0xF053A800)
#define CG_CPU_RESET_BIT_CGX5500_TCXO_POL		(0)
#define CG_CPU_RESET_BIT_CGX5500_GSM_EN			(1)
#define CG_CPU_RESET_BIT_CGX5500_RTC_EN			(2)
#define CG_CPU_RESET_BIT_CGX5500_BS_EN			(3)

#define CG_CPU_TCC8900_GPSRST *(volatile unsigned long *)(0xF053A804)
#define CG_CPU_RESET_BIT_CGX5500_CORE			(0)
#define CG_CPU_RESET_BIT_CGX5500_RTC			(1)
#define CG_CPU_RESET_BIT_CGX5500_TCXO			(2)
#define CG_CPU_RESET_BIT_CGX5500_BS				(3)

PTCC8900_GPION		gpiod;

#ifndef CGX_IP
	pGPSBportcfg	gpsbcfg;
#endif

U32 CgCpuDmaAddr(U32 aDmaChannel);

TCgReturnCode CgCpuGPSPrepare();
void CgCpuDRMaskOn();


#endif 
/**
\}
*/
