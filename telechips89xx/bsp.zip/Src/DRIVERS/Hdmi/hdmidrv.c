
/****************************************************************************
 *   FileName    : hdmidrv.cpp
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <Windows.h>
#include "bsp.h"

#include "TCC89x_Physical.h"
#include "TCC89x_Structures.h"
#include "ioctl_code.h"

#include "regs-hdmi.h"
#include "hdmi.h"
#include "audio.h"
#include "hdmidrv.h"

#include "tcc_gpio.h"
#include "tcc_gpioexp.h"


typedef unsigned int ssize_t;
typedef int irqreturn_t;

//#ifdef __cplusplus
//extern "C" {
//#endif

extern int hdmi_open(void);
extern int hdmi_release(void);

extern irqreturn_t hdmi_handler(int irq, void *dev_id);
extern ssize_t hdmi_read(char *buffer, size_t count);
extern ssize_t hdmi_write(const char *buffer, size_t count);
extern int hdmi_ioctl(unsigned int cmd, unsigned long arg);

extern void hdcp_reset(void);
extern void hdcp_enable(unsigned char enable);
extern void hdmi_avi_update_checksum(void);
extern void hdmi_aui_update_checksum(void);
extern int hdmi_set_color_space(int ColorSpace);
extern int hdmi_set_color_depth(int ColorDepth);
extern void hdmi_set_video_mode(struct device_video_params mode);
#if defined(TELECHIPS)
extern void hdmi_set_lcdc_timing(struct device_lcdc_timing_params mode);
#endif
extern int hdmi_set_pixel_limit(int PixelLimit);
extern int hdmi_set_pixel_aspect_ratio(int PixelAspectRatio);
extern int hdmi_set_audio_sample_freq(int SamplingFreq);
extern int hdmi_set_audio_packet_type(int HDMIASPType);
extern int hdmi_set_audio_channel_number(int ChannelNum);
extern void hdmi_start(void);
extern void hdcp_set_ksv_list(struct hdcp_ksv_list list);
extern void hdcp_check_result(unsigned char enable);
extern int hdcp_read_ri(void);


#define printk	printf

extern void tcc_lcd_on(void);	//temp!!!
extern void tcc_lcd_off(void);	//temp!!!

/************************************************************************************************
* Global Handle
************************************************************************************************/


/************************************************************************************************
* Global Variable define
************************************************************************************************/
#ifdef DEBUG
DBGPARAM dpCurSettings = {
    _T("usbmsfn"),
    {
        _T("Error"), _T("Warning"), _T("Init"), _T("Function"),
        _T("Comments"), _T(""), _T(""), _T(""),
        _T(""), _T(""), _T(""), _T(""), 
        _T(""), _T(""), _T(""), _T("")
    },
    0x5
};


#endif
extern unsigned int result127;
extern unsigned int thirdAuth;

//static unsigned int gHdmiInitFlag=0;
static unsigned int gHdmiOpenFirst = 1;

static stpwrinfo gHdmiPwrInfo = {PWR_STATUS_OFF};

/************************************************************************************************
* Global Defines
************************************************************************************************/
#define LOGLEVEL DBG_ERROR|DBG_WARN|DBG_TRACE|DBG_LOG

/************************************************************************************************
* FUNCTION		: 
BOOL DllEntry(HINSTANCE   hinstDll,	   //@parm Instance pointer. 
			  DWORD       dwReason,    //@parm Reason routine is called. 
			  LPVOID      lpReserved   //@parm system parameter. 
			  )
* DESCRIPTION	:  
*
************************************************************************************************/
BOOL DllEntry(HINSTANCE   hinstDll,	   /*@parm Instance pointer. */
			  DWORD       dwReason,    /*@parm Reason routine is called. */
			  LPVOID      lpReserved   /*@parm system parameter. */
			  )
{
	if (dwReason == DLL_PROCESS_ATTACH) {
		DEBUGREGISTER(hinstDll);
		DEBUGMSG(ZONE_INIT, (TEXT("port process attach\r\n")));
		DisableThreadLibraryCalls((HMODULE) hinstDll);
	}
	
	if (dwReason == DLL_PROCESS_DETACH) {
		DEBUGMSG(ZONE_INIT, (TEXT("process detach detach\r\n")));
	}
	
	return (TRUE);
}




/************************************************************************************************
* FUNCTION		: DWORD HDM_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HDM_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HDMI        ]%s.\r\n"), TEXT(__FUNCTION__)));

	return TRUE;
}


/************************************************************************************************
* FUNCTION		: BOOL HDM_Deinit( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL HDM_Deinit( DWORD hDeviceContext )
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HDMI        ]%s.\r\n"), TEXT(__FUNCTION__)));

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: DWORD TVO_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HDM_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
{
	int ret;

	if (gHdmiOpenFirst)
	{
		gHdmiOpenFirst = 0;
		return FALSE;
	}

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HDMI        ]%s.\r\n"), TEXT(__FUNCTION__)));

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: BOOL TVO_Close( DWORD hOpenContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL HDM_Close( DWORD hOpenContext )
{
	int ret;
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HDMI        ]%s.\r\n"), TEXT(__FUNCTION__)));

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: void HDM_Enable(void)
*
* DESCRIPTION	: 
*
************************************************************************************************/
void HDM_Enable(void)
{
	if (gHdmiPwrInfo.status == PWR_STATUS_ON)
		return;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HDMI        ]%s.\r\n"), TEXT("HDM_PowerUp")));

    {
        HANDLE hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
        if( INVALID_HANDLE_VALUE!=hGXP )
        {
            DWORD dwByteReturned;

            GXPINFO GxpInfo;
            GxpInfo.uiDevice=PCA9539LOW;
            GxpInfo.uiPort=PWRGP4;
            GxpInfo.uiState=ON;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: PWRGP4 Power On\r\n")));
            }

            GxpInfo.uiDevice=PCA9539HIGH;
            GxpInfo.uiPort=BTWAKE;	//HDMI_ON
            GxpInfo.uiState=ON;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: HDMI_ON Power On\r\n")));
            }

			#if (0)
            GxpInfo.uiDevice=PCA9538;
            GxpInfo.uiPort=SATAHDMI;	//HDMI_LVDS_ON
            GxpInfo.uiState=ON;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: HDMI_LVDS_ON Power On\r\n")));
            }
			#endif

            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
        }
    }

	hdmi_init();
	audio_init();

	gHdmiPwrInfo.status = PWR_STATUS_ON;
}

/************************************************************************************************
* FUNCTION		: void HDM_Disable( void )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void HDM_Disable( void )
{
	if (gHdmiPwrInfo.status == PWR_STATUS_OFF)
		return;

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HDMI        ]%s.\r\n"), TEXT("HDM_PowerDown")));

	audio_exit();
	hdmi_exit();

    {
        HANDLE hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
        if( INVALID_HANDLE_VALUE!=hGXP )
        {
            DWORD dwByteReturned;
            GXPINFO GxpInfo;

			#if (0)
            GxpInfo.uiDevice=PCA9539LOW;
            GxpInfo.uiPort=PWRGP4;
            GxpInfo.uiState=OFF;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: PWRGP4 Power On\r\n")));
            }
			#endif

			#if (1)
            GxpInfo.uiDevice=PCA9539HIGH;
            GxpInfo.uiPort=BTWAKE;	//HDMI_ON
            GxpInfo.uiState=OFF;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: HDMI_ON Power On\r\n")));
            }
			#endif

			#if (0)
            GxpInfo.uiDevice=PCA9538;
            GxpInfo.uiPort=SATAHDMI;	//HDMI_LVDS_ON
            GxpInfo.uiState=OFF;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: HDMI_LVDS_ON Power On\r\n")));
            }
			#endif

            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
        }
    }

	gHdmiPwrInfo.status = PWR_STATUS_OFF;
}

/************************************************************************************************
* FUNCTION		: BOOL TVO_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
*
* DESCRIPTION	: 
*
************************************************************************************************/
BOOL HDM_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
{
	DWORD *pInValue = (DWORD *)pBufIn; 
    unsigned long *arg = (unsigned long *)pBufIn;
//	stReg *temp;
	int ret;

	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[HDMI        ]%s[%d].\r\n"), TEXT(__FUNCTION__), dwCode));
#if (1)

	switch (dwCode)
    {
		case IOCTL_PWR_CONTROL:
		{
			stpwrioctl *pCmd  = (stpwrioctl*)pBufIn;
			stpwrinfo  *pInfo = (stpwrinfo *)pBufOut;

			if (pCmd == NULL)
			{
				return FALSE;
			}

			switch(pCmd->cmd)
			{
				case PWR_CMD_OFF:
				//	HDM_PowerDown(NULL);
					HDM_Disable();

					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gHdmiPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;
				case PWR_CMD_ON:
				//	HDM_PowerUp(NULL);
					HDM_Enable();

					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gHdmiPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;
				case PWR_CMD_GETSTATUS:
					if ( pBufOut && (dwLenOut >= sizeof(stpwrinfo)))
						memcpy(pInfo, &gHdmiPwrInfo, sizeof(stpwrinfo));

					if (pdwActualOut)
						*pdwActualOut = sizeof(stpwrinfo);

					break;

				default:
					return FALSE;	//break;
			}

			{
				HANDLE hDevice= INVALID_HANDLE_VALUE;
				stpwrioctl	pwrioctl;	// for input
				pwrioctl.deviceid = DEVICE_HDMI;
				pwrioctl.cmd = pCmd->cmd;

				hDevice = CreateFile(TEXT("HPD1:"), GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
				DeviceIoControl(hDevice, IOCTL_PWR_CONTROL, &pwrioctl, sizeof(stpwrioctl), NULL, NULL, NULL, NULL);				
				CloseHandle(hDevice);
			}

		}
		break;

		case HDMI_IOC_POWER_UP:
		//	HDM_PowerUp(NULL);
			HDM_Enable();
			break;
		case HDMI_IOC_POWER_DOWN:
		//	HDM_PowerDown(NULL);
			HDM_Disable();
			break;
		
		// hdmi drvier ioctl
        case HDMI_IOC_SET_COLORSPACE:
        case HDMI_IOC_SET_COLORDEPTH:
        case HDMI_IOC_SET_HDMIMODE:
        case HDMI_IOC_SET_VIDEOMODE:
#if defined(TELECHIPS)
		case HDMI_IOC_SET_LCDC_TIMING:
#endif /*TELECHIPS*/
        case HDMI_IOC_SET_BLUESCREEN:
        case HDMI_IOC_SET_PIXEL_LIMIT:
        case HDMI_IOC_SET_PIXEL_ASPECT_RATIO:
        case HDMI_IOC_SET_AVMUTE:
        case HDMI_IOC_SET_AUDIOPACKETTYPE:
        case HDMI_IOC_SET_AUDIOSAMPLEFREQ:
        case HDMI_IOC_SET_AUDIOCHANNEL:
        case HDMI_IOC_SET_SPEAKER_ALLOCATION:
        case HDMI_IOC_GET_PHYREADY:
        case HDMI_IOC_START_HDMI:
        case HDMI_IOC_STOP_HDMI:
        case HDMI_IOC_GET_HDCP_EVENT:
        // start HDCP
        case HDMI_IOC_START_HDCP:
        // stop HDCP
        case HDMI_IOC_STOP_HDCP:
        case HDMI_IOC_ENABLE_HDCP:
        case HDMI_IOC_SET_BKSV:
        case HDMI_IOC_SET_BCAPS:
        case HDMI_IOC_GET_AKSV:
        case HDMI_IOC_GET_AN:
        case HDMI_IOC_GET_RI: // only use if state is in first auth
        case HDMI_IOC_GET_AUTH_STATE:
        case HDMI_IOC_SET_HDCP_CHECK_RESULT:
        case HDMI_IOC_SET_ENCRYPTION:
        case HDMI_IOC_SET_BSTATUS:
        case HDMI_IOC_SET_KSV_LIST:
        case HDMI_IOC_SET_SHA1:
        case HDMI_IOC_SET_AUDIO_ENABLE:
        case HDMI_IOC_GET_SHA1_RESULT:
        case HDMI_IOC_GET_KSV_LIST_READ_DONE:
        case HDMI_IOC_SET_ILLEGAL_DEVICE:
        case HDMI_IOC_SET_REPEATER_TIMEOUT:
        case HDMI_IOC_RESET_HDCP: // reset hdcp state machine
        case HDMI_IOC_SET_KSV_LIST_EMPTY:
        case HDMI_IOC_RESET_AUISAMPLEFREQ:
		{
			ret = hdmi_ioctl(dwCode, pBufIn, dwLenIn, pBufOut, dwLenOut, pdwActualOut);
			if (ret < 0)
				return FALSE;

			break;
        }
		// audio drvier ioctl
        case AUDIO_IOC_SET_AUDIOINPUT:
        case AUDIO_IOC_SET_I2S_CUV_SET_SAMPLEFREQ:
        case AUDIO_IOC_SET_I2S_CUV_SET_CODINGTYPE:
        case AUDIO_IOC_SET_I2S_CUV_SET_CHANNELNUMBER:
        case AUDIO_IOC_SET_I2S_CUV_SET_WORDLENGTH:
        case AUDIO_IOC_SET_SPDIF_SET_CODINGTYPE:
        case AUDIO_IOC_SET_I2S_PARAMETER:
        case AUDIO_IOC_UPDATE_I2S_CUV:
        case AUDIO_IOC_RESET_I2S_CUV:
		{
			ret = audio_ioctl(dwCode, pBufIn, dwLenIn, pBufOut, dwLenOut, pdwActualOut);
			if (ret < 0)
				return FALSE;

			break;
        }
		case HDMI_IOC_TEST_LCD_ON:
		{
			tcc_lcd_on();
			break;
		}
		case HDMI_IOC_TEST_LCD_OFF:
		{
			tcc_lcd_off();
			break;
		}
		default:
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HDMI        ]Unknown IOCTL [%d].\r\n"), dwCode));
			break;
     }

#endif
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: void HDM_PowerUp( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void HDM_PowerUp( DWORD hDeviceContext )
{
	//none.
}

/************************************************************************************************
* FUNCTION		: void TVO_PowerDown( DWORD hDeviceContext )
*
* DESCRIPTION	: 
*
************************************************************************************************/
void HDM_PowerDown( DWORD hDeviceContext )
{
	HDM_Disable();
}

/************************************************************************************************
* FUNCTION		: DWORD TVO_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HDM_Read( DWORD hOpenContext, LPVOID pBuffer, DWORD Count )
{
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD TVO_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HDM_Write( DWORD hOpenContext, LPCVOID pBuffer, DWORD Count )
{
	return FALSE;
}

/************************************************************************************************
* FUNCTION		: DWORD TVO_Seek( DWORD hOpenContext, long Amount, WORD Type )
*
* DESCRIPTION	: 
*
************************************************************************************************/
DWORD HDM_Seek( DWORD hOpenContext, long Amount, WORD Type )
{
	return 0;
}

//#ifdef __cplusplus
//}
//#endif



