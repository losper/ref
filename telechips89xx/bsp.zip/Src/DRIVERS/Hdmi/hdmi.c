//-------------------------------------------------------------------
// Copyright (c) Telechips, Inc.
// All right reserved.
//
//-------------------------------------------------------------------
/**
 * @file hdmi.c
 * @brief This file implements HDMI device driver.
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

#include <Windows.h>
#include "bsp.h"

#include "TCC89x_Physical.h"
#include "TCC89x_Structures.h"
#include "ioctl_code.h"

#include "tcc_ckc.h"
//#include "tcc_gpio.h"

#include "errno-base.h"

#include "regs-hdmi.h"
#include "hdmi.h"
#include "audio.h"

#include "key.h"

static tSYSTEM_PARAM *gpBOOTARGS;
static LCDINFO	 gpLCDINFO;


#define VERSION "1.2" /* Driver version number */
#define HDMI_MINOR 240 /* Major 10, Minor 240, /dev/hdmi */

#define HDMI_DEBUG 0


/**
 * If 'SIMPLAYHD' is 1, check Ri of 127th and 128th frame -@n
 * on 3rd authentication. And also check if Ri of 127th frame is -@n
 * different from that of 128th frame. if 'SIMPLAYHD' is 0, check only Ri -@n
 * of 128th frame.
 */

#define HDMI_DEBUG_TIME 0

#define KERN_INFO

#define printk	printf

typedef unsigned int ssize_t;
typedef int irqreturn_t;

#if HDMI_DEBUG
#define DPRINTK    printk
#else
#define DPRINTK
#endif

/** I2C device address of HDCP Rx port*/
#define HDCP_RX_DEV_ADDR        0x74

/** Ri offset on HDCP Rx port */
#define HDCP_RI_OFFSET          0x08

/** Size of Ri */
#define HDCP_RI_SIZE            2

#if HDMI_DEBUG_TIME
unsigned long jstart, jend;
unsigned long ji2cstart, ji2cend;
#endif

/**
 * N value of ACR packet.@n
 * 4096  is the N value for 32 KHz sampling frequency @n
 * 6272  is the N value for 44.1 KHz sampling frequency @n
 * 12544 is the N value for 88.2 KHz sampling frequency @n
 * 25088 is the N value for 176.4 KHz sampling frequency @n
 * 6144  is the N value for 48 KHz sampling frequency @n
 * 12288 is the N value for 96 KHz sampling frequency @n
 * 24576 is the N value for 192 KHz sampling frequency @n
 */
 const unsigned int ACR_N_params[] =
{
    4096,
    6272,
    12544,
    25088,
    6144,
    12288,
    24576
};

#if (0)
/**
 * @struct hdcp_struct
 * Structure for processing hdcp
 */
struct hdcp_struct {
    /** Spinlock for synchronizing event */
    spinlock_t lock;

    /** Wait queue */
    wait_queue_head_t waitq;

    /** Contains event that occurs */
    enum hdcp_event event;

    /** Work queue for processing 3rd authentication */
    struct work_struct  work;
};
#endif

#if (0)
 struct hdcp_struct hdcp_struct;
#endif

int hdmi_open(void);
int hdmi_release(void);

irqreturn_t hdmi_handler(int irq, void *dev_id);
ssize_t hdmi_read(char *buffer, size_t count);
ssize_t hdmi_write(const char *buffer, size_t count);
int hdmi_ioctl(unsigned int cmd, unsigned long arg);

void hdcp_reset(void);
void hdcp_enable(unsigned char enable);
void hdmi_avi_update_checksum(void);
void hdmi_aui_update_checksum(void);
int hdmi_set_color_space(enum ColorSpace);
int hdmi_set_color_depth(enum ColorDepth);
void hdmi_set_video_mode(struct device_video_params mode);
#if defined(TELECHIPS)
void hdmi_set_lcdc_timing(struct device_lcdc_timing_params mode);
#endif
int hdmi_set_pixel_limit(enum PixelLimit);
int hdmi_set_pixel_aspect_ratio(enum PixelAspectRatio);
int hdmi_set_audio_sample_freq(enum SamplingFreq);
int hdmi_set_audio_packet_type(enum HDMIASPType);
int hdmi_set_audio_channel_number(enum ChannelNum);
void hdmi_start(void);
void hdcp_set_ksv_list(struct hdcp_ksv_list list);
void hdcp_check_result(unsigned char enable);
int hdcp_read_ri(void);


// for test...
typedef struct {
	unsigned int res_width;
	unsigned int res_height;

	unsigned int devide;

	unsigned int vpw;
	unsigned int vbp;
	unsigned int vfp;

	unsigned int hpw;
	unsigned int hbp;
	unsigned int hfp;

	unsigned int pwdx;	// 0xC : 24Bit(888)
						// 0x5 : 18Bit(565)

	unsigned int freq;	// freq

} lcd_cfg_t;


static lcd_cfg_t	lcd_cfg[3] = 
{
//////	W		H		DIV		VPW		VBP		VFP		HPW		HBP		HFP		PWDX	FREQ//
#if (0)
//	[TCCXXXX_LCD_5.0WVGA&24B_SV0.1]	- LW500AC9601
	{	800,	480,	0,		2,		33,		10,	  128,		88,		40,		0xC,	60	},	
#else
//	[TCCXXXX_LCD_4.8WVGA&24B_SV0.1]
	{	800,	480,	3,		3,		5,		5,		3,		13,		8,		0xC,	60	},
#endif
//	[CLAA104XA01CW 10"4 Color TFT LCD (LVDS)]
	{	1024,	768,	1,		1,		1,		36,		1,		1,		318,	0xC,	60	},

//	[HT121WX2-103 12"1 Color TFT LCD (LVDS)]
	{	1280,	800,	1,		1,		3,		20,		1,		10,		150,	0xC,	60	},
};

#define LCD_DEBUG	0

#if LCD_DEBUG
#define DPRINTF	printf
#else
#define DPRINTF
#endif

void lcd_setclock(int lcdc_id, lcd_cfg_t *pLcdCfg)
{
	PLCDC	pLCDC_BASE[2];	//   = {(LCDC *)&HwLCDC0_BASE,
							//   (LCDC *)&HwLCDC1_BASE};

	PLCDC	pLCDC;

	unsigned int dst_lclk;
	unsigned int dst_pxclk;
	unsigned int dst_freq;

	unsigned int v_total;
	unsigned int h_total;

	unsigned int pxclkdiv;
	unsigned int div;

	unsigned int src_pll;
	
	unsigned int ret_lclk;
	unsigned int ret_pxclk;
	unsigned int ret_freq_dHz;

	unsigned int tmp_h_total;
	unsigned int tmp_freq_dHz;
	unsigned int tmp_hbp, tmp_hfp;
	unsigned int bak_src_pll, bak_diff_tmp, bak_hbp, bak_hfp, bak_h_total;
	unsigned int bak_lclk;
	unsigned int flag_opt_timming;
	unsigned int diff_h_total;
	
	unsigned int diff_cur, diff_tmp;
	int i;

	pLCDC_BASE[0]  = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE);
	pLCDC_BASE[1]  = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE);

	pLCDC = pLCDC_BASE[lcdc_id];

	v_total = pLcdCfg->vpw + pLcdCfg->vbp + pLcdCfg->res_height + pLcdCfg->vfp;
	h_total = pLcdCfg->hpw + pLcdCfg->hbp + pLcdCfg->res_width + pLcdCfg->hfp;
	dst_freq = pLcdCfg->freq;
	
	pxclkdiv = pLcdCfg->devide;
	div = pxclkdiv?pxclkdiv*2:1;
	
	dst_pxclk = (h_total*v_total*(dst_freq))/100;
	dst_lclk = dst_pxclk*div;

	DPRINTF("\n");
	DPRINTF("--------------------------------------------------------------\n");
	DPRINTF("[LCDC%d       ] (LCLK %d) (PXCLK %d) (%dHz)\r\n", lcdc_id, dst_lclk, dst_lclk/div, dst_freq);

	src_pll  = PCDIRECTPLL0;
	diff_tmp = dst_lclk*2;

	flag_opt_timming = 0;
	bak_h_total = 0;

	for(i=PCDIRECTPLL0; i<=PCDIRECTPLL3; i++)
	{
		tcc_ckc_setperi(PERI_LCD0+lcdc_id,ENABLE,dst_lclk,i);
		ret_lclk = tcc_ckc_getperi(PERI_LCD0+lcdc_id);

		diff_cur = (ret_lclk>dst_lclk)?(ret_lclk-dst_lclk):(dst_lclk-ret_lclk);

		if(diff_cur <= diff_tmp)
		{
			src_pll = i;
			diff_tmp = diff_cur;
		}

		ret_pxclk = ret_lclk/div;

		DPRINTF("(Check PLL%d) - (LCLK %d) (PXCLK %d)", i, ret_lclk, ret_pxclk);
		ret_freq_dHz = ((ret_pxclk*10)*100)/(h_total*v_total);

		#if (1)	// auto timming setting.
		{
			tmp_h_total = (ret_pxclk*100)/(v_total*dst_freq);
			tmp_freq_dHz = ((ret_pxclk*10)*100)/(tmp_h_total*v_total);

			if (tmp_h_total > (pLcdCfg->res_width+pLcdCfg->hpw + 2))
			{
				#if 0
				// modify HBP, HFP
				tmp_hbp = (tmp_h_total - (pLcdCfg->hpw + pLcdCfg->res_width))>>1;
				tmp_hfp = (tmp_h_total - (pLcdCfg->hpw + pLcdCfg->res_width))-tmp_hbp;
				#else
				// modify only HFP
				tmp_hbp = pLcdCfg->hbp;
				tmp_hfp = (tmp_h_total - (pLcdCfg->hpw + pLcdCfg->res_width))-tmp_hbp;
				#endif

				DPRINTF( " -> H_TOTAL(%d%c%d->%d[hbp:%d,hfp:%d])->%d.%dHz ", //\r\n", 
					h_total,
					(tmp_h_total>=h_total)?'+':'-', 
					(tmp_h_total>=h_total)?tmp_h_total-h_total:h_total-tmp_h_total,
					tmp_h_total,
					tmp_hbp,
					tmp_hfp,
					tmp_freq_dHz/10, 
					tmp_freq_dHz%10);

				if ((tmp_hbp < 1) || (tmp_hfp < 1) || (tmp_hbp > 512) || (tmp_hfp > 512))
					continue;

				if ((bak_h_total == 0)
				|| (((bak_h_total>h_total)?(bak_h_total-h_total):(h_total-bak_h_total)) > ((tmp_h_total>h_total)?(tmp_h_total-h_total):(h_total-tmp_h_total))))
				{
					bak_hbp = tmp_hbp;
					bak_hfp = tmp_hfp;
					bak_h_total = tmp_h_total;
					bak_src_pll = i;
					bak_lclk = ret_lclk;
				}

				flag_opt_timming = 1;
			}
		}
		#endif

		DPRINTF("\r\n");
	}
	
	tcc_ckc_setperi(PERI_LCD0+lcdc_id,ENABLE,dst_lclk,src_pll);
	ret_lclk = tcc_ckc_getperi(PERI_LCD0+lcdc_id);
	ret_pxclk = ret_lclk/div;
	ret_freq_dHz = ((ret_pxclk*10)*100)/(h_total*v_total);
	DPRINTF( "            -> [LCLK %d] [PXCLK %d] (%d.%dHz) - (PLL%d)\r\n", ret_lclk, ret_pxclk, ret_freq_dHz/10, ret_freq_dHz%10, src_pll);

	if ((ret_freq_dHz != (pLcdCfg->freq*10)) && flag_opt_timming)
	{

		DPRINTF( "            !! Change Timming: HBP(%d)HFP(%d) -> HBP(%d)HFP(%d)\r\n",
			pLcdCfg->hbp, pLcdCfg->hfp,	bak_hbp, bak_hfp);

		pLcdCfg->hbp = bak_hbp;
		pLcdCfg->hfp = bak_hfp;
		src_pll = bak_src_pll;

		v_total = pLcdCfg->vpw + pLcdCfg->vbp + pLcdCfg->res_height + pLcdCfg->vfp;
		h_total = pLcdCfg->hpw + pLcdCfg->hbp + pLcdCfg->res_width + pLcdCfg->hfp;
		dst_freq = pLcdCfg->freq;
		
		pxclkdiv = pLcdCfg->devide;
		div = pxclkdiv?pxclkdiv*2:1;
		
		dst_pxclk = (h_total*v_total*(dst_freq))/100;
		dst_lclk = dst_pxclk*div;

		tcc_ckc_setperi(PERI_LCD0+lcdc_id,ENABLE,dst_lclk,src_pll);
		ret_lclk = tcc_ckc_getperi(PERI_LCD0+lcdc_id);
		ret_pxclk = ret_lclk/div;
		ret_freq_dHz = ((ret_pxclk*10)*100)/(h_total*v_total);
		DPRINTF( "            -> [LCLK %d] [PXCLK %d] (%d.%dHz) - (PLL%d)\r\n", ret_lclk, ret_pxclk, ret_freq_dHz/10, ret_freq_dHz%10, src_pll);
	}
	DPRINTF("--------------------------------------------------------------\n");
	DPRINTF("\n");
	
	pLCDC->LCLKDIV = div/2;
}

#include "tcc_gpioexp.h"
void lvds_onoff(int onoff)
{
    HANDLE hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
    if( INVALID_HANDLE_VALUE!=hGXP )
    {
        DWORD dwByteReturned;

        GXPINFO GxpInfo;
        GxpInfo.uiDevice=PCA9539LOW;
        GxpInfo.uiPort=LVDSIVT;
		if (onoff)
	        GxpInfo.uiState=ON;
		else
			GxpInfo.uiState=OFF;

        if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
        {
            RETAILMSG(1,(TEXT("ERROR: PWRGP4 Power On\r\n")));
        }
        CloseHandle(hGXP);
    }
    else
    {
        RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
    }
}

void demo1_hdmi_start(void)
{
	PDDICONFIG	pDDICfg;
	PGPIO	pGPIO 	= (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	PLCDC	pLCDC0;
	PLCDC	pLCDC1;

	if (gpLCDINFO.nDemoType != 1)
		return;

	pLCDC0  = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE);
	pLCDC1  = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE);
	pDDICfg = (PDDICONFIG)tcc_allocbaseaddress((unsigned int)&HwDDI_CONFIG_BASE);

#if 0
//	LCD_DISP Off
	BITCLR(pGPIO->GPCDAT, Hw28);
#endif

	if (pLCDC0->LCTRL & Hw0)
	{
		BITCLR(pLCDC0->LCTRL, Hw0);
		while(pLCDC0->LSTATUS & Hw30)	// BUSY
		{
			Sleep(1);
		}
	}

	if (gpLCDINFO.nLcdCfgIdx == 0)
	{
		BITCLR(pGPIO->GPCFN0, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN1, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN2, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN3, (Hw16-Hw0));

		//LCDC0 RGB Interface
		BITSET(pGPIO->GPCFN0, 0x22222222);
		BITSET(pGPIO->GPCFN1, 0x22222222);
		BITSET(pGPIO->GPCFN2, 0x22222222);
		BITCSET(pGPIO->GPCFN3, (Hw16-Hw0), 0x2222);
	}
	else
	{
		BITCLR(pDDICfg->LVDS_CTRL, Hw0); //LCDC0
//		BITSET(pDDICfg->LVDS_CTRL, Hw0); //LCDC1
	}

#if 1
	{
		PDDICACHE   pDDICache   = (DDICACHE *)tcc_allocbaseaddress((unsigned int)&HwDDI_CACHE_BASE);

		BITCSET(pDDICache->DDIC_CTRL, Hw8|Hw0, Hw0);
		BITCSET(pDDICache->DDIC_CFG1, Hw29-Hw24, (0)<<24);	//SEL31
	}
#endif

#if 1
	BITCSET (pLCDC1->LI1C, Hw28, (0) << 28); // Disable Image
#endif

	BITSET(pLCDC0->LCTRL, Hw0);

#if 0
//	LCD_DISP On
	BITSET(pGPIO->GPCDAT, Hw28);
#endif
}

void demo1_hdmi_stop(void)
{
	PDDICONFIG	pDDICfg;
	PLCDC		pLCDC0;
	PLCDC		pLCDC1;

	PGPIO	pGPIO 	= (GPIO *)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	PLCDC	pLCDC;

	lcd_cfg_t *cfg = &lcd_cfg[gpLCDINFO.nLcdCfgIdx];

	if (gpLCDINFO.nDemoType != 1)
		return;

	pDDICfg = (PDDICONFIG)tcc_allocbaseaddress((unsigned int)&HwDDI_CONFIG_BASE);
	pLCDC0  = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE);
	pLCDC1  = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE);

	if (pLCDC0->LCTRL & Hw0)
	{
		BITCLR(pLCDC0->LCTRL, Hw0);
		while(pLCDC0->LSTATUS & Hw30)	// BUSY
		{
			Sleep(1);
		}
	}

	if (gpLCDINFO.nLcdCfgIdx == 0)
	{
		BITCLR(pGPIO->GPCFN0, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN1, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN2, 0xFFFFFFFF);
		BITCLR(pGPIO->GPCFN3, (Hw16-Hw0));

		//LCDC1 RGB Interface
		BITSET(pGPIO->GPCFN0, 0x55555555);
		BITSET(pGPIO->GPCFN1, 0x55555555);
		BITSET(pGPIO->GPCFN2, 0x55555555);
		BITCSET(pGPIO->GPCFN3, (Hw16-Hw0), 0x5555);
	}
	else
	{
//		BITCLR(pDDICfg->LVDS_CTRL, Hw0); //LCDC0
		BITSET(pDDICfg->LVDS_CTRL, Hw0); //LCDC1
	}

	pLCDC = pLCDC1;

	lcd_setclock(1, cfg);

//	Set LCD controller
	pLCDC->LCTRL = (
	//			Hw31|			// EVP[31] - External VSYNC Polarity	(0: Direct Input, 1: Inverted Input)
	//			Hw30|			// EVS[30] - External VSYNC Enable		(0: Disabled, 1: Enabled)
				(0<<28)|		// R2YMD[29:28] - RGB to YCbCr Conversion Option (type0)
	//			(1<<28)|		// 												 (type1)
	//			(2<<28)|		//												 (type2)
	//			(3<<28)|		//												 (type3)
				(0<<26)|		// LUT[27:26] - LUT Option Bits	(Not used)
	//			(1<<26)|		// 								(Used for Image 0)
	//			(2<<26)|		//								(Used for Image 0)
	//			(3<<26)|		//								(Used for Image 0)
	//			Hw25|			// GEN[25] - Gamma Corection Enable Bit (0: Disabled, 1: Enabled)
	//			Hw24|			// 656[24] - CCIR 656 Mode (0: Disabled, 1: Enabled)
	//			Hw23|			// CKG[23] - Clock Gating Enable for Timing Generator
	//			Hw22|Hw21|Hw20| // BPP[22:20] - Bit Per Pixel for STN-LCD
				(cfg->pwdx<<16)|		//PXDW[19:16] - C : 24Bit(888) Hw19(1)|Hw18(1)|Hw17(0)|Hw16(0)|
										//PXDW[19:16] - 5 : 18Bit(666) Hw19(0)|Hw18(1)|Hw17(0)|Hw16(1)|
	//			Hw15|			// Inverted Data Enable (ACBIAS pin)
				Hw14|			// Inverted Vertical Sync
				Hw13|			// Inverted Horizontal Sync
	//			Hw12|			// Inverted Pixel Clock
	//			Hw11|			// Clipping Enable
	//			Hw10|			// RGB to YCbCr Converter Enable for OUTPUT
	//			Hw9 |			// Double Pixel Data
				Hw8 |			// Non-interlace
				(0x2<<5)|		// TFT-LCD mode: STN(Hw5), TFT(Hw6), TV(Hw7)
	//			Hw4 |			// Master Select for IMG0
				(0x5<<1)|		// OVP[3:1] - 5 : Image2 > Image1 > Image0
//				Hw0 |			// LCD Controller Enable
				0); 			// End Of Value

// Set LCD clock
	pLCDC->LCLKDIV &= 0xFF00FF00;
	pLCDC->LCLKDIV |= ( (1 << 16) | cfg->devide); //((PCK_LCD+1)/2)/((LCD_DEVIDE)*2)

//  Horizontal timing
    pLCDC->LHTIME1 = ((cfg->hpw-1) << 16) | (cfg->res_width - 1);
    pLCDC->LHTIME2 = ((cfg->hbp-1) << 16) | (cfg->hfp-1);

//  Vertical timing
    pLCDC->LVTIME1 = ((cfg->vpw-1) << 16) | (cfg->res_height - 1);
    pLCDC->LVTIME2 = ((cfg->vbp-1) << 16) | (cfg->vfp-1);
    pLCDC->LVTIME3 = ((cfg->vpw-1) << 16) | (cfg->res_height - 1);
    pLCDC->LVTIME4 = ((cfg->vbp-1) << 16) | (cfg->vfp-1);

//	Display Size
	pLCDC->LDS = (cfg->res_height << 16) | cfg->res_width;

	// non-interlace mode (progressive mode)
	{
		unsigned regl;
		regl = readl(&pLCDC->LI0C);
		writel(regl & ~(0x80000000), &pLCDC->LI0C);
		regl = readl(&pLCDC->LI1C);
		writel(regl & ~(0x80000000), &pLCDC->LI1C);
		regl = readl(&pLCDC->LI2C);
		writel(regl & ~(0x80000000), &pLCDC->LI2C);
	}

#if 1
	BITCSET (pLCDC1->LI1C, Hw28, (1) << 28); // Enable Image
#endif

#if 1
	{
		PDDICACHE   pDDICache   = (DDICACHE *)tcc_allocbaseaddress((unsigned int)&HwDDI_CACHE_BASE);

		BITCSET(pDDICache->DDIC_CTRL, Hw8|Hw0, Hw8);
		BITCSET(pDDICache->DDIC_CFG1, Hw29-Hw24, (8)<<24);	//SEL31
	}
#endif

	BITSET(pLCDC->LCTRL, Hw0);	// LCDC Enable
	
#if 0
//	LCD_DISP On
	BITSET(pGPIO->GPCDAT, Hw28);

//	LCD_BL_EN(Backlight) On
	BITCSET(pGPIO->GPAFN0,Hw32-Hw28,Hw29);//set GPIO_A7 as TCO0 Mode
	BITSET(pGPIO->GPAEN,Hw7);
	BITSET(pGPIO->GPADAT,Hw7);
#endif
}


void tcc_lcd_on(void)	//temp!!!
{
	PDDICONFIG	pDDICfg;
	PLCDC		pLCDC0;
	PLCDC		pLCDC1;

	PGPIO	pGPIO 	= (GPIO *)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	PLCDC	pLCDC;

	lcd_cfg_t *cfg = &lcd_cfg[gpLCDINFO.nLcdCfgIdx];

	if (gpLCDINFO.nDemoType == 1)
	{
		demo1_hdmi_stop();
		return;
	}

	pDDICfg = (PDDICONFIG)tcc_allocbaseaddress((unsigned int)&HwDDI_CONFIG_BASE);
	pLCDC0  = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE);
	pLCDC1  = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE);

	pLCDC = pLCDC1;

	lcd_setclock(1, cfg);

//	Set LCD controller
	pLCDC->LCTRL = (
	//			Hw31|			// EVP[31] - External VSYNC Polarity	(0: Direct Input, 1: Inverted Input)
	//			Hw30|			// EVS[30] - External VSYNC Enable		(0: Disabled, 1: Enabled)
				(0<<28)|		// R2YMD[29:28] - RGB to YCbCr Conversion Option (type0)
	//			(1<<28)|		// 												 (type1)
	//			(2<<28)|		//												 (type2)
	//			(3<<28)|		//												 (type3)
				(0<<26)|		// LUT[27:26] - LUT Option Bits	(Not used)
	//			(1<<26)|		// 								(Used for Image 0)
	//			(2<<26)|		//								(Used for Image 0)
	//			(3<<26)|		//								(Used for Image 0)
	//			Hw25|			// GEN[25] - Gamma Corection Enable Bit (0: Disabled, 1: Enabled)
	//			Hw24|			// 656[24] - CCIR 656 Mode (0: Disabled, 1: Enabled)
	//			Hw23|			// CKG[23] - Clock Gating Enable for Timing Generator
	//			Hw22|Hw21|Hw20| // BPP[22:20] - Bit Per Pixel for STN-LCD
				(cfg->pwdx<<16)|		//PXDW[19:16] - C : 24Bit(888) Hw19(1)|Hw18(1)|Hw17(0)|Hw16(0)|
										//PXDW[19:16] - 5 : 18Bit(666) Hw19(0)|Hw18(1)|Hw17(0)|Hw16(1)|
	//			Hw15|			// Inverted Data Enable (ACBIAS pin)
				Hw14|			// Inverted Vertical Sync
				Hw13|			// Inverted Horizontal Sync
	//			Hw12|			// Inverted Pixel Clock
	//			Hw11|			// Clipping Enable
	//			Hw10|			// RGB to YCbCr Converter Enable for OUTPUT
	//			Hw9 |			// Double Pixel Data
				Hw8 |			// Non-interlace
				(0x2<<5)|		// TFT-LCD mode: STN(Hw5), TFT(Hw6), TV(Hw7)
	//			Hw4 |			// Master Select for IMG0
				(0x5<<1)|		// OVP[3:1] - 5 : Image2 > Image1 > Image0
				Hw0 |			// LCD Controller Enable
				0); 			// End Of Value

// Set LCD clock
	pLCDC->LCLKDIV &= 0xFF00FF00;
	pLCDC->LCLKDIV |= ( (1 << 16) | cfg->devide); //((PCK_LCD+1)/2)/((LCD_DEVIDE)*2)

//  Horizontal timing
    pLCDC->LHTIME1 = ((cfg->hpw-1) << 16) | (cfg->res_width - 1);
    pLCDC->LHTIME2 = ((cfg->hbp-1) << 16) | (cfg->hfp-1);

//  Vertical timing
    pLCDC->LVTIME1 = ((cfg->vpw-1) << 16) | (cfg->res_height - 1);
    pLCDC->LVTIME2 = ((cfg->vbp-1) << 16) | (cfg->vfp-1);
    pLCDC->LVTIME3 = ((cfg->vpw-1) << 16) | (cfg->res_height - 1);
    pLCDC->LVTIME4 = ((cfg->vbp-1) << 16) | (cfg->vfp-1);

//	Display Size
	pLCDC->LDS = (cfg->res_height << 16) | cfg->res_width;

	// non-interlace mode (progressive mode)
	{
		unsigned regl;
		regl = readl(&pLCDC->LI0C);
		writel(regl & ~(0x80000000), &pLCDC->LI0C);
		regl = readl(&pLCDC->LI1C);
		writel(regl & ~(0x80000000), &pLCDC->LI1C);
		regl = readl(&pLCDC->LI2C);
		writel(regl & ~(0x80000000), &pLCDC->LI2C);
	}

	if (gpLCDINFO.nLcdCfgIdx == 0)
	{
	//	LCD_DISP On
		BITSET(pGPIO->GPCDAT, Hw28);

	//	LCD_BL_EN(Backlight) On
		BITCSET(pGPIO->GPAFN0,Hw32-Hw28,Hw29);//set GPIO_A7 as TCO0 Mode
		BITSET(pGPIO->GPAEN,Hw7);
		BITSET(pGPIO->GPADAT,Hw7);
	}
	else
	{
		lvds_onoff(1);
	}
	
}


void tcc_lcd_off(void)	////temp!!!
{
	PGPIO	pGPIO 	= (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);

	if (gpLCDINFO.nDemoType == 1)
	{
		demo1_hdmi_start();
		return;
	}

	if (gpLCDINFO.nLcdCfgIdx == 0)
	{
	//	LCD_DISP Off
		BITCLR(pGPIO->GPCDAT, Hw28);

	//	LCD_BL_EN(Backlight) Off

		BITCLR(pGPIO->GPAFN0,Hw32-Hw28);//set GPIO_A7 as TCO0 Mode
		BITSET(pGPIO->GPAEN,Hw7);
		BITCLR(pGPIO->GPADAT,Hw7);
	}
	else
	{
		lvds_onoff(0);
	}
}
// for test... end


#if defined(TELECHIPS)
struct device_lcdc_timing_params lcdc_timing_params;
#endif

/**
 * When 'SIMPLAYHD' is 1, contains Ri match result on 127th frame. @n
 * if match, 1;Otherwise, 0.
 */
unsigned int result127 = 0;
/**
 * Flags that contains if this is on 3rd auth or not. @n
 * if it is on 3rd auth, 1;Otherwise, 0.
 */
unsigned int thirdAuth = 0;

/**
 * Process 3rd authentication. @n
 * Read Ri' from Rx. then, compare it with Ri and set comparision result. @n
 * On 3rd authentication process, we have to read Ri' within 1 frame period. @n
 * Because of that, we process 3rd auth process by using linux work queue.
 */
void hdcp_work(void *arg)
{
    int matched;
    unsigned int result;
    unsigned char offset;
    unsigned char ri0,ri1;

    if (thirdAuth)
    {
#if HDMI_DEBUG_TIME
        ji2cstart = jiffies;
#endif

        result = hdcp_read_ri();

#if HDMI_DEBUG_TIME
        ji2cend = jiffies;
#endif

        ri0 = readb(HDCP_RI_0);
        ri1 = readb(HDCP_RI_1);

        offset = readb(HDCP_FRAME_COUNT);

        printk("frame count = %d\n", offset);

#if HDMI_DEBUG_TIME
        jend = jiffies;
#endif

        if (offset != 0) // if 127th
        {
            if ( ((result>>8) & 0xFF) == ri0 && (result & 0xFF) == ri1 )
            {
                result127 = result;
                matched = 1;
            }
            else
            {
                printk("Rj = 0x%04x\n",result);
                printk("Ri not Matched!!!!\n");
                printk("Ri = 0x%02x%02x\n",ri0,ri1);
                matched = 0;
            }
        }
        else // if 128th
        {
            if ( ((result>>8) & 0xFF) == ri0 && (result & 0xFF) == ri1 && result127 != result )
            {
                matched = 1;
            }
            else
            {
                printk("Rj = 0x%04x\n",result);
                printk("Ri not Matched!!!!\n");
                printk("Ri = 0x%02x%02x\n",ri0,ri1);
#ifdef SIMPLAYHD
                printk("127th = 0x%04x\n",result127);
#endif
                matched = 0;
            }
        }

#if HDMI_DEBUG_TIME
        printk("i2c time = %lu msec\n", (ji2cend - ji2cstart) * 1000 / HZ);
        printk("total time = %lu msec\n", (jend - jstart) * 1000 / HZ);
#endif

        if (!matched) // 3rd auth failed!!!
        {
            hdcp_check_result(0);
            writeb(0x00,HDCP_ENC_EN);
        }
    }
}

void load_hdcp_key(void);

#if (0)
 const struct file_operations hdmi_fops =
{
    .owner      = THIS_MODULE,
    .open       = hdmi_open,
    .release    = hdmi_release,
    .read       = hdmi_read,
    .write      = hdmi_write,
    .ioctl      = hdmi_ioctl,
};

 struct miscdevice hdmi_misc_device =
{
    HDMI_MINOR,
    "hdmi",  //"HDMI",
    &hdmi_fops,
};
#endif

int hdmi_open(void)
{
    return 0;
}

int hdmi_release(void)
{
    writeb(0x7F,HDCP_RI_COMPARE_1);

    thirdAuth = 0;
    return 0;
}

ssize_t hdmi_read(char *buffer, size_t count)
{
    return 0;
}

ssize_t hdmi_write(const char *buffer, size_t count)
{
    return 0;
}

#define EFAULT	0x01;


int hdmi_ioctl(unsigned int cmd, unsigned char * pBufIn, unsigned int dwLenIn, unsigned char * pBufOut, unsigned int dwLenOut, unsigned int * pdwActualOut )
{
#if (1)
	unsigned long arg = (unsigned long)pBufIn;

    DPRINTK(KERN_INFO "%s\n", __FUNCTION__);

    switch (cmd)
    {
        case HDMI_IOC_SET_COLORSPACE:
        {
			int space;

			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_COLORSPACE)\r\n")));

			// get arg
			memcpy((void*)&space, (const void*)arg, sizeof(int));

			if ( !hdmi_set_color_space(space) )
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_COLORSPACE) : Not Correct Arg = %d\r\n"), space));
				return -EFAULT;
			}

			break;
        }
        case HDMI_IOC_SET_COLORDEPTH:
        {
            int depth;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_COLORDEPTH)\r\n")));

            // get arg
            memcpy((void*)&depth, (const void*)arg, sizeof(int));

            if ( !hdmi_set_color_depth(depth) )
            {
                RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_COLORDEPTH) : Not Correct Arg = %d\r\n"), depth));
                return -EFAULT;
            }

            break;
        }
        case HDMI_IOC_SET_HDMIMODE:
        {
            int mode;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_HDMIMODE)\r\n")));

            // get arg
            memcpy((void*)&mode, (const void*)arg, sizeof(int));

            if (mode == HDMI)
            {
                writeb(HDMI_MODE_SEL_HDMI,HDMI_MODE_SEL);
                writeb(HDMICON2_HDMI,HDMI_CON_2);
            }
            else
            {
                writeb(HDMI_MODE_SEL_DVI,HDMI_MODE_SEL);
                writeb(HDMICON2_DVI,HDMI_CON_2);
            }

            break;
        }
        case HDMI_IOC_SET_VIDEOMODE:
        {
            struct device_video_params video_mode;
            //unsigned int ret;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_VIDEOMODE)\r\n")));


            // get arg
            memcpy((void*)&video_mode,(const void*)arg,sizeof(struct device_video_params));

            hdmi_set_video_mode(video_mode);

            break;
        }
		#if defined(TELECHIPS)
		case HDMI_IOC_SET_LCDC_TIMING:
		{
            struct device_lcdc_timing_params lcdc_mode;
            unsigned int ret;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_LCDC_TIMING)\n")));

            // get arg
            ret = memcpy((void*)&lcdc_mode,(const void*)arg,sizeof(struct device_lcdc_timing_params));
            
			#if 1
            hdmi_set_lcdc_timing(lcdc_mode);
			#else
			memcpy(&lcdc_timing_params, &lcdc_mode, sizeof(struct device_lcdc_timing_params));
			#endif

            break;
		}
		#endif /*TELECHIPS*/
        case HDMI_IOC_SET_BLUESCREEN:
        {
            unsigned char val,reg;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_BLUESCREEN)\r\n")));

            // get arg
            memcpy((void*)&val, (const void*)arg, sizeof(unsigned char));
            
            reg = readb(HDMI_CON_0);
            if (val) // if on
            {
                writeb(reg|HDMI_BLUE_SCR_ENABLE,HDMI_CON_0);
            }
            else // if off
            {
                writeb(reg &~HDMI_BLUE_SCR_ENABLE,HDMI_CON_0);
            }

            break;
        }
        case HDMI_IOC_SET_PIXEL_LIMIT:
        {
            int val;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_PIXEL_LIMIT)\r\n")));

            // get arg
            memcpy((void*)&val, (const void*)arg, sizeof(int));

            if (!hdmi_set_pixel_limit(val))
            {
                RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
                return -EFAULT;
            }

            break;
        }
        case HDMI_IOC_SET_PIXEL_ASPECT_RATIO:
        {
            int val;
            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_PIXEL_ASPECT_RATIO)\r\n")));

            // get arg
            memcpy((void*)&val, (const void*)arg, sizeof(int));

            if (!hdmi_set_pixel_aspect_ratio(val))
            {
                RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
                return -EFAULT;
            }
            break;
        }
        case HDMI_IOC_SET_AVMUTE:
        {
            unsigned char val,reg;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_AVMUTE)\r\n")));

            // get arg
            memcpy((void*)&val, (const void*)arg, sizeof(unsigned char));

            reg = readb(HDMI_MODE_SEL) & HDMI_MODE_SEL_HDMI;
            if (reg)
            {
                if (val)
                {
                    // set AV Mute
                    writeb(GCP_AVMUTE_ON,HDMI_GCP_BYTE1);
                    writeb(GCP_TRANSMIT_EVERY_VSYNC,HDMI_GCP_CON);
                }
                else
                {
                    // clear AV Mute
                    writeb(GCP_AVMUTE_OFF, HDMI_GCP_BYTE1);
                    writeb(GCP_TRANSMIT_EVERY_VSYNC,HDMI_GCP_CON);
                }
            }

            break;
        }
        case HDMI_IOC_SET_AUDIOPACKETTYPE:
        {
            int val;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_AUDIOPACKETTYPE)\r\n")));

            // get arg
            memcpy((void*)&val, (const void*)arg, sizeof(int));

            if (!hdmi_set_audio_packet_type(val))
            {
                RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
                return -EFAULT;
            }

            break;
        }
        case HDMI_IOC_SET_AUDIOSAMPLEFREQ:
        {
            int val;
            unsigned char reg = readb(HDMI_CON_0);
            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_AUDIOSAMPLEFREQ)\r\n")));

            // get arg
            memcpy((void*)&val, (const void*)arg, sizeof(int));

            if ( !hdmi_set_audio_sample_freq(val) )
            {
                RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
                return -EFAULT;
            }
            // set audio enable
            writeb(reg|HDMI_ASP_ENABLE ,HDMI_CON_0);
            break;
        }
        case HDMI_IOC_SET_AUDIOCHANNEL:
        {
            int val;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_AUDIOCHANNEL)\r\n")));

            // get arg
            memcpy((void*)&val, (const void*)arg, sizeof(int));

            if (!hdmi_set_audio_channel_number(val))
            {
                RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
                return -EFAULT;
            }

            break;
        }
        case HDMI_IOC_SET_SPEAKER_ALLOCATION:
        {
            unsigned int val;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_SPEAKER_ALLOCATION)\r\n")));

            // get arg
            memcpy((void*)&val, (const void*)arg, sizeof(unsigned int));

            writeb(val,HDMI_AUI_BYTE4);

            break;
        }
        case HDMI_IOC_GET_PHYREADY:
        {
            unsigned char phy_status;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_GET_PHYREADY)\r\n")));

            phy_status = readb(HDMI_PHY_STATUS);

			if (pBufOut == 0 && dwLenOut < sizeof(phy_status))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
				return -EFAULT;
			}
			
            memcpy((void*)pBufOut, (const void*)&phy_status, sizeof(phy_status));
			*pdwActualOut = sizeof(phy_status);


            break;
        }
        case HDMI_IOC_START_HDMI:
        {
            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_START_HDMI)\r\n")));

            hdmi_start();

            break;
        }
        case HDMI_IOC_STOP_HDMI:
        {
            unsigned char reg;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_STOP_HDMI)\r\n")));

            reg = readb(HDMI_CON_0);
            writeb(reg & ~HDMI_SYS_ENABLE,HDMI_CON_0);

            break;
        }
        case HDMI_IOC_GET_HDCP_EVENT:
        {
            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_WAIT_HDCP_STATE)\r\n")));
#if (0)
            // wait event
            wait_event_interruptible(hdcp_struct.waitq, hdcp_struct.event != 0);

            spin_lock_irq(&hdcp_struct.lock);
            // send event to user
            //put_user(hdcp_struct.event, (unsigned int __user*)arg);
            memcpy((void*)pBufOut, (const void*)&hdcp_struct.event, sizeof(hdcp_struct.event));
			*pdwActualOut = sizeof(hdcp_struct.event);
            
            // clear event
            hdcp_struct.event = 0;
            spin_unlock_irq(&hdcp_struct.lock);
#endif
            break;
        }
        // start HDCP
        case HDMI_IOC_START_HDCP:
        {
            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_START_HDCP)\r\n")));
#if (0)

            // add event HDCP_EVENT_START
            spin_lock_irq(&hdcp_struct.lock);
            hdcp_struct.event |= (1<<HDCP_EVENT_START);
            spin_unlock_irq(&hdcp_struct.lock);
            // wake up
            wake_up_interruptible(&hdcp_struct.waitq);
#endif
            break;
        }
        // stop HDCP
        case HDMI_IOC_STOP_HDCP:
        {
            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_STOP_HDCP)\r\n")));
#if 0

            // add event HDCP_EVENT_STOP
            spin_lock_irq(&hdcp_struct.lock);
            hdcp_struct.event |= (1<<HDCP_EVENT_STOP);
            spin_unlock_irq(&hdcp_struct.lock);

            // wake up
            wake_up_interruptible(&hdcp_struct.waitq);
#endif
            break;
        }
		case HDMI_IOC_ENABLE_HDCP:
        {
            unsigned char enable;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_ENABLE_HDCP)\r\n")));

            // get arg
            memcpy((void*)&enable, (const void*)arg, sizeof(unsigned char));
            
            // enable HDCP
            hdcp_enable(enable);

            break;
        }
        case HDMI_IOC_SET_BKSV:
        {
            struct hdcp_ksv Bksv;
            int ret;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_BKSV)\r\n")));

            // get arg
            ret = memcpy((void*)&Bksv, (const void*)arg, sizeof(Bksv));

            // set bksv
            writeb(Bksv.ksv[0],HDCP_BKSV_0);
            writeb(Bksv.ksv[1],HDCP_BKSV_1);
            writeb(Bksv.ksv[2],HDCP_BKSV_2);
            writeb(Bksv.ksv[3],HDCP_BKSV_3);
            writeb(Bksv.ksv[4],HDCP_BKSV_4);

            break;
        }
        case HDMI_IOC_SET_BCAPS:
        {
            unsigned char Bcaps;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_BCAPS)\r\n")));

            // get arg
            memcpy((void*)&Bcaps, (const void*)arg, sizeof(unsigned char));

            // set bcaps
            writeb(Bcaps,HDCP_BCAPS);

            break;
        }

        case HDMI_IOC_GET_AKSV:
        {
            struct hdcp_ksv Aksv;
            //int ret;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_GET_AKSV)\r\n")));

            // get Aksv
            Aksv.ksv[0] = readb(HDCP_AKSV_0);
            Aksv.ksv[1] = readb(HDCP_AKSV_1);
            Aksv.ksv[2] = readb(HDCP_AKSV_2);
            Aksv.ksv[3] = readb(HDCP_AKSV_3);
            Aksv.ksv[4] = readb(HDCP_AKSV_4);

			if (pBufOut == 0 && dwLenOut < sizeof(Aksv))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
				return -EFAULT;
			}

            // copy to user
            memcpy((void*)pBufOut, (const void*)&Aksv, sizeof(Aksv));
			*pdwActualOut = sizeof(Aksv);

            break;
        }
        case HDMI_IOC_GET_AN:
        {
            struct hdcp_an An;
            //int ret;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_GET_AN)\r\n")));

            // get an
            An.an[0] = readb(HDCP_AN_0);
            An.an[1] = readb(HDCP_AN_1);
            An.an[2] = readb(HDCP_AN_2);
            An.an[3] = readb(HDCP_AN_3);
            An.an[4] = readb(HDCP_AN_4);
            An.an[5] = readb(HDCP_AN_5);
            An.an[6] = readb(HDCP_AN_6);
            An.an[7] = readb(HDCP_AN_7);

			if (pBufOut == 0 && dwLenOut < sizeof(An))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
				return -EFAULT;
			}

            // put to user
            memcpy((void*)pBufOut, (const void*)&An, sizeof(An));
			*pdwActualOut = sizeof(An);

            break;
        }
        case HDMI_IOC_GET_RI: // only use if state is in first auth
        {
            int ret;
            unsigned int result;
            unsigned char ri0,ri1;

            // get rj from RX
            result = hdcp_read_ri();

            // get ri from TX
            ri0 = readb(HDCP_RI_0);
            ri1 = readb(HDCP_RI_1);

            // comparison
            if ( ((result>>8) & 0xFF) == ri0 && (result & 0xFF) == ri1 )
            {
                ret = 1;
            }
            else
            {
                printk("Ri not Matched!!!\n");
                printk("Ri = 0x%02x%02x\n",ri0,ri1);
                ret = 0;
            }

			if (pBufOut == 0 && dwLenOut < sizeof(ret))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
				return -EFAULT;
			}

            // put to user
            memcpy((void*)pBufOut, (const void*)&ret, sizeof(ret));
			*pdwActualOut = sizeof(ret);


            break;
        }

        case HDMI_IOC_GET_AUTH_STATE:
        {
            int result = 1;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_GET_AUTH_STATE)\r\n")));

            // check AUTH state
            if ( !(readb(HDMI_STATUS) & (1<<HDCP_AUTHEN_ACK_NUM)))
                result = 0;

			if (pBufOut == 0 && dwLenOut < sizeof(result))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
				return -EFAULT;
			}

            // put to user
            memcpy((void*)pBufOut, (const void*)&result, sizeof(result));
			*pdwActualOut = sizeof(result);


            break;
        }
        case HDMI_IOC_SET_HDCP_CHECK_RESULT:
        {
            unsigned char enable = 1;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_HDCP_CHECK_RESULT)\r\n")));

            // get arg
            memcpy((void*)&enable, (const void*)arg, sizeof(unsigned char));

            // set result
            hdcp_check_result(enable);

            break;
        }
        case HDMI_IOC_SET_ENCRYPTION:
        {
            unsigned char enable;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_ENCRYPTION)\r\n")));

            // get arg
            memcpy((void*)&enable, (const void*)arg, sizeof(unsigned char));

            // enable encryption
            if (enable)
            {
                writeb(0x01,HDCP_ENC_EN);
	#ifdef SIMPLAYHD
                writeb(HDCP_COMPARE_FRAME_COUNT1_ENABLE,HDCP_RI_COMPARE_1);
	#endif
                thirdAuth = 1;
            }
            else // disable encryption
            {
                writeb(0x00,HDCP_ENC_EN);
	#ifdef SIMPLAYHD
                writeb(0x7F,HDCP_RI_COMPARE_1);
	#endif
                thirdAuth = 0;
            }
            break;
        }
        case HDMI_IOC_SET_BSTATUS:
        {
            struct hdcp_status Bstatus;
            int ret;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_BSTATUS)\r\n")));

            // get arg
            ret = memcpy((void*)&Bstatus.status, (const void*)arg, sizeof(Bstatus));

            writeb(Bstatus.status[0], HDCP_BSTATUS_0);
            writeb(Bstatus.status[1], HDCP_BSTATUS_1);

            break;
        }
        case HDMI_IOC_SET_KSV_LIST:
        {
            struct hdcp_ksv_list list;
            //int ret;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_KSV_LIST)\r\n")));

            // get size arg;
            memcpy((void*)&list, (const void*)arg, sizeof(list));

            hdcp_set_ksv_list(list);

            break;
        }
        case HDMI_IOC_SET_SHA1:
        {
            struct hdcp_sha1 rx_sha1;
            int index;//,ret;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_SHA1)\r\n")));

            // get arg;
            memcpy((void*)&rx_sha1, (const void*)arg, sizeof(rx_sha1));

            // set sha1
            for (index=0; index < HDCP_SHA1_SIZE; index++)
                writeb(rx_sha1.sha1[index], HDCP_SHA1_00 + 4*index);

            break;
        }
        case HDMI_IOC_SET_AUDIO_ENABLE:
        {
            unsigned char enable;
            unsigned char reg;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_SET_AUDIO_ENABLE)\r\n")));

            // get arg
            memcpy((void*)&enable, (const void*)arg, sizeof(unsigned char));

            reg = readb(HDMI_CON_0);
            // enable audio output
            if (enable)
            {
#if (1) && defined(TELECHIPS)
                hdmi_aui_update_checksum();
                writeb(TRANSMIT_EVERY_VSYNC,HDMI_AUI_CON);
            //  writeb(ACR_MEASURED_CTS_MODE,HDMI_ACR_CON);
#endif
                writeb(reg|HDMI_ASP_ENABLE,HDMI_CON_0);
            }
            else // disable encryption
            {
#if (1) && defined(TELECHIPS)
                writeb(DO_NOT_TRANSMIT,HDMI_AUI_CON);
                writeb(DO_NOT_TRANSMIT,HDMI_ACR_CON);
#endif
                writeb(reg& ~HDMI_ASP_ENABLE,HDMI_CON_0);
            }

            break;
        }
        case HDMI_IOC_GET_SHA1_RESULT:
        {
            int result = 1;

            RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("HDMI: ioctl(HDMI_IOC_GET_SHA1_RESULT)\r\n")));

            if ( readb(HDCP_SHA_RESULT)&HDCP_SHA1_VALID_READY )
            {
                if (!(readb(HDCP_SHA_RESULT)&HDCP_SHA1_VALID))
                    result = 0;
            }
            else
                result = 0;

            // reset
            writeb(0x00,HDCP_SHA_RESULT);

			if (pBufOut == 0 && dwLenOut < sizeof(result))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
				return -EFAULT;
			}

            // put arg
            memcpy((void*)pBufOut, (const void*)&result, sizeof(result));
			*pdwActualOut = sizeof(result);


            break;
        }
        case HDMI_IOC_GET_KSV_LIST_READ_DONE:
        {
            unsigned char reg;

            reg = readb(HDCP_KSV_LIST_CON) & HDCP_KSV_LIST_READ_DONE;

			if (pBufOut == 0 && dwLenOut < sizeof(reg))
			{
				RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("Not available Arg\r\n")));
				return -EFAULT;
			}

            // put arg
            memcpy((void*)pBufOut, (const void*)&reg, sizeof(reg));
			*pdwActualOut = sizeof(reg);

            
            break;
        }
        case HDMI_IOC_SET_ILLEGAL_DEVICE:
        {
            // set
            writeb(HDCP_REVOCATION_SET,HDCP_CTRL2);
            // clear
            writeb(0x00,HDCP_CTRL2);

            break;
        }
        case HDMI_IOC_SET_REPEATER_TIMEOUT:
        {
            unsigned char reg;
            reg = readb(HDCP_CTRL1);
            // set
            writeb(reg|HDCP_TIMEOUT,HDCP_CTRL1);
            // clear
            writeb(reg,HDCP_CTRL1);
        }
        case HDMI_IOC_RESET_HDCP: // reset hdcp state machine
        {
            hdcp_reset();
            break;
        }
        case HDMI_IOC_SET_KSV_LIST_EMPTY:
        {
            writeb(HDCP_KSV_LIST_EMPTY,HDCP_KSV_LIST_CON);
            break;
        }
        case HDMI_IOC_RESET_AUISAMPLEFREQ:
        {
            unsigned char reg = readb(HDMI_AUI_BYTE2) & ~HDMI_AUI_SF_MASK;
            writeb(reg, HDMI_AUI_BYTE2);
            break;
        }
        default:
			RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("[HDMI        ]Unknown IOCTL.\r\n")));
            return -EINVAL;
    }

    return 0;
#endif
}

/**
 * HDCP IRQ handler. @n
 * If HDCP IRQ occurs, set hdcp_event and wake up the waitqueue.
 */
irqreturn_t hdmi_handler(int irq, void *dev_id)
{
#if (0)
    unsigned char flag;
    unsigned int event = 0;

    // check HDCP INT
    flag = readb(HDMI_SS_INTC_FLAG);

    if ( !(flag & (1<<HDMI_IRQ_HDCP)))
        return IRQ_NONE;

    DPRINTK(KERN_INFO "%s\n", __FUNCTION__);

    // check HDCP Status
    flag = readb(HDMI_STATUS);

    // processing interrupt
    // I2C INT
    if (flag & (1<<HDCP_I2C_INT_NUM) )
    {
        event |= (1<<HDCP_EVENT_READ_BKSV_START);
        // clear pending
        writeb((1<<HDCP_I2C_INT_NUM),HDMI_STATUS);
        writeb(0x00,HDCP_I2C_INT);
    }
    // AN INT
    if (flag & (1<<HDCP_AN_WRITE_INT_NUM))
    {
        event |= (1<<HDCP_EVENT_WRITE_AKSV_START);
        // clear pending
        writeb((1<<HDCP_AN_WRITE_INT_NUM),HDMI_STATUS);
        writeb(0x00,HDCP_AN_INT);
    }
    // RI INT
    if (flag & (1<<HDCP_UPDATE_RI_INT_NUM))
    {
        // clear pending
        writeb((1<<HDCP_UPDATE_RI_INT_NUM),HDMI_STATUS);
        writeb(0x00,HDCP_RI_INT);
        if (thirdAuth) // third auth
        {
#if HDMI_DEBUG_TIME
            jstart = jiffies;
#endif
            // register the work to a work queue
            schedule_work(&hdcp_struct.work);
            return IRQ_HANDLED;
        }
        else
            event |= (1<<HDCP_EVENT_CHECK_RI_START);
    }
    // WATCHDOG INT
    if (flag & (1<<HDCP_WATCHDOG_INT_NUM))
    {
        event |= (1<<HDCP_EVENT_SECOND_AUTH_START);
        // clear pending
        writeb((1<<HDCP_WATCHDOG_INT_NUM),HDMI_STATUS);
        writeb(0x00,HDCP_WDT_INT);
    }

    // set event
    spin_lock_irq(&hdcp_struct.lock);
    hdcp_struct.event |= event;
    spin_unlock_irq(&hdcp_struct.lock);

    // wake up
    wake_up_interruptible(&hdcp_struct.waitq);

    return IRQ_HANDLED;
#endif
}

 int hdmi_init(void)
{
    unsigned char reg;
	unsigned int  regl;

	gpBOOTARGS=(tSYSTEM_PARAM *) tcc_allocbaseaddress(SYSTEM_PARAM_BASEADDRESS);

	memcpy(&gpLCDINFO, &gpBOOTARGS->SYSTEM_ARGS.mLcdInfo, sizeof(LCDINFO));

	if(gpLCDINFO.nDemoType)
		printf("demotyp = %d\n", gpLCDINFO.nDemoType);

    DPRINTK(KERN_INFO "%s\n", __FUNCTION__);

    if (!machine_is_hdmidp())
        return -ENODEV;

    //printk(KERN_INFO "HDMI Driver ver. %s (built %s %s)\n", VERSION, __DATE__, __TIME__);


#if defined(TELECHIPS)
#if (0)
	tcc_pca953x_setup(PCA9539_U3_SLAVE_ADDR, Hw14 /*PWRGP4      */, OUTPUT, HIGH, SET_DIRECTION|SET_VALUE);
	tcc_pca953x_setup(PCA9539_U2_SLAVE_ADDR, Hw7  /*HDMI_ON     */, OUTPUT, HIGH, SET_DIRECTION|SET_VALUE);
	tcc_pca953x_setup(PCA9538_U4_SLAVE_ADDR, Hw2  /*HDMI_LVDS_ON*/, OUTPUT, HIGH, SET_DIRECTION|SET_VALUE);
#endif
	{volatile int ttt;for(ttt=0;ttt<0x5000;ttt++);}

	// disable HDMI PHY Power-off
	regl = readl(PMU_PWROFF);
	writel(regl & ~PWROFF_HDMIPHY, PMU_PWROFF);

	// disable HDMI Power-down
	regl = readl(DDICFG_PWDN);
	writel(regl & ~PWDN_HDMI, DDICFG_PWDN);
	
	// swreset DDI_BUS HDMI
	regl = readl(DDICFG_SWRESET);
	writel(regl | SWRESET_HDMI, DDICFG_SWRESET);
	{volatile int ttt;for(ttt=0;ttt<0x100;ttt++);}
	writel(regl & ~SWRESET_HDMI, DDICFG_SWRESET);
	
	// enable DDI_BUS HDMI CLK
	regl = readl(DDICFG_HDMICTRL);
	writel(regl | HDMICTRL_HDMI_ENABLE, DDICFG_HDMICTRL);

	// HDMI PHY Reset
	regl = readl(DDICFG_HDMICTRL);
	writel(regl | HDMICTRL_RESET_HDMI, DDICFG_HDMICTRL);
	{volatile int ttt;for(ttt=0;ttt<0x5000;ttt++);}
	writel(regl & ~HDMICTRL_RESET_HDMI, DDICFG_HDMICTRL);

	// HDMI SPDIF Reset
	regl = readl(DDICFG_HDMICTRL);
	writel(regl | HDMICTRL_RESET_SPDIF, DDICFG_HDMICTRL);
	{volatile int ttt;for(ttt=0;ttt<0x5000;ttt++);}
	writel(regl & ~HDMICTRL_RESET_SPDIF, DDICFG_HDMICTRL);

	// HDMI TMDS Reset
	regl = readl(DDICFG_HDMICTRL);
	writel(regl | HDMICTRL_RESET_TMDS, DDICFG_HDMICTRL);
	{volatile int ttt;for(ttt=0;ttt<0x5000;ttt++);}
	writel(regl & ~HDMICTRL_RESET_TMDS, DDICFG_HDMICTRL);

	// swreset DDI_BUS HDMI
	regl = readl(DDICFG_SWRESET);
	writel(regl | SWRESET_HDMI, DDICFG_SWRESET);
	{volatile int ttt;for(ttt=0;ttt<0x100;ttt++);}
	writel(regl & ~SWRESET_HDMI, DDICFG_SWRESET);

	{volatile int ttt;for(ttt=0;ttt<0x5000;ttt++);}

#endif

    // disable HDCP INT
    reg = readb(HDMI_SS_INTC_CON);
    writeb(reg & ~(1<<HDMI_IRQ_HDCP), HDMI_SS_INTC_CON);

#if (0)
    if (request_irq(IRQ_HDMI, hdmi_handler, IRQF_SHARED, "hdmi", hdmi_handler))
    {
        DPRINTK(KERN_WARNING "HDMI: IRQ %d is not free.\n", IRQ_HDMI);
        misc_deregister(&hdmi_misc_device);
        return -EIO;
    }

    init_waitqueue_head(&hdcp_struct.waitq);
    // set up work queue struct
    INIT_WORK(&hdcp_struct.work, hdcp_work/*, NULL*/);  //@storm::modify
#endif

    return 0;
}

 void hdmi_exit(void)
{
    unsigned char reg;
	unsigned int  regl;
//    DPRINTK(KERN_INFO "%s\n", __FUNCTION__);

    // disable HDCP INT
    reg = readb(HDMI_SS_INTC_CON);
    writeb(reg & ~(1<<HDMI_IRQ_HDCP), HDMI_SS_INTC_CON);

    // disable hdmi
    reg = readb(HDMI_CON_0);
    writeb(reg & ~HDMI_SYS_ENABLE,HDMI_CON_0);

#if (1) && defined(TELECHIPS)

	// disable DDI_BUS HDMI CLK
	regl = readl(DDICFG_HDMICTRL);
	writel(regl & ~HDMICTRL_HDMI_ENABLE, DDICFG_HDMICTRL);

	// enable HDMI Power-down
	regl = readl(DDICFG_PWDN);
	writel(regl | PWDN_HDMI, DDICFG_PWDN);

	// enable HDMI PHY Power-Off
	regl = readl(PMU_PWROFF);
	writel(regl | PWROFF_HDMIPHY, PMU_PWROFF);

#endif

#if (0)
    free_irq(IRQ_HDMI, hdmi_handler);
    misc_deregister(&hdmi_misc_device);
#endif
}

/**
 * Reset the HDCP H/W state machine.
 */
 void hdcp_reset(void)
{
    unsigned char reg;

//    DPRINTK(KERN_INFO "%s\n", __FUNCTION__);

    // disable HDCP
    writeb(0x00, HDCP_ENC_EN);
    writeb(0x00, HDCP_CTRL1);
    writeb(0x00, HDCP_CTRL2);

    // disable HPD_INT
    reg = readb(HDMI_SS_INTC_CON);
    writeb(reg & ~((1<<HDMI_IRQ_HPD_PLUG) | (1<<HDMI_IRQ_HPD_UNPLUG)) ,HDMI_SS_INTC_CON);

    // set SW HPD OFF and ON to initialize HDCP state machine
    writeb(HPD_SW_ENABLE|HPD_OFF,HDMI_HPD);
    writeb(HPD_SW_ENABLE|HPD_ON,HDMI_HPD);

    // disable SW HPD
    writeb(HPD_SW_DISABLE,HDMI_HPD);

    // restore HDMI_SS_INTC_CON
    writeb(reg ,HDMI_SS_INTC_CON);

    // set blue screen
    reg = readb(HDMI_CON_0);
    writeb(reg|HDMI_BLUE_SCR_ENABLE,HDMI_CON_0);

    // enable HDCP
    writeb(HDCP_ENABLE,HDCP_CTRL1);
}

/**
 * Enable/Disable HDCP H/W.
 * @param enable    [in] 1 to enable, 0 to disable
 */
void hdcp_enable(unsigned char enable)
{
    if (enable)
    {
        unsigned char reg;

//        DPRINTK(KERN_INFO "HDCP ENABLE\n");

        // load AES encrypted hdcp_key
        load_hdcp_key();

        // enable all HDCP INT in HDMI_STATUS reg
        reg = readb(HDMI_STATUS_EN);
        writeb((reg | 1<<HDCP_I2C_INT_NUM
          | 1<<HDCP_WATCHDOG_INT_NUM
          | 1<<HDCP_AN_WRITE_INT_NUM
          | 1<<HDCP_UPDATE_RI_INT_NUM),HDMI_STATUS_EN);

        // enable HDCP INT
        reg = readb(HDMI_SS_INTC_CON);
        writeb((reg | (1<<HDMI_IRQ_HDCP)), HDMI_SS_INTC_CON);

        // reset hdcp state machine
        hdcp_reset();

        // enable HDCP
        writeb(HDCP_ENABLE,HDCP_CTRL1);
    }
    else
    {
        unsigned char reg;

//        DPRINTK(KERN_INFO "HDCP DISABLE\n");

        //
        thirdAuth = 0;

        // disable HDCP INT
        reg = readb(HDMI_SS_INTC_CON);
        writeb(reg & ~(1<<HDMI_IRQ_HDCP), HDMI_SS_INTC_CON);

        // disable encryption
        writeb(0x00,HDCP_ENC_EN);
        // clear hdcp ctrl
        writeb(0x00,HDCP_CTRL1);
        writeb(0x00,HDCP_CTRL2);
#ifdef SIMPLAYHD
        writeb(0x7F,HDCP_RI_COMPARE_1);
#endif
    }
}


/**
 * Set the result whether Ri and Ri' are match or not.
 * @param enable    [in] 1 if Ri and Ri' are match;Otherwise, 0.
 */
void hdcp_check_result(unsigned char enable)
{
    if (enable)
    {
        // set
        writeb(HDCP_RI_MATCH,HDCP_CHECK_RESULT);
        // clear
        writeb(0x00,HDCP_CHECK_RESULT);
    }
    else
    {
        // set
        writeb(HDCP_RI_NOT_MATCH,HDCP_CHECK_RESULT);
        // clear
        writeb(0x00,HDCP_CHECK_RESULT);
        // clear
        thirdAuth = 0;
    }
}

/**
 * Set one KSV in KSV list which read from Rx on 2nd authentication.
 * @param list    [in] One KSV in KSV list and flag.
 */
void hdcp_set_ksv_list(struct hdcp_ksv_list list)
{
    writeb(list.ksv[0],HDCP_KSV_LIST_0);
    writeb(list.ksv[1],HDCP_KSV_LIST_1);
    writeb(list.ksv[2],HDCP_KSV_LIST_2);
    writeb(list.ksv[3],HDCP_KSV_LIST_3);
    writeb(list.ksv[4],HDCP_KSV_LIST_4);

    if (list.end) // if last one
    {
        // finish setting KSV_LIST
        writeb(HDCP_KSV_LIST_END | HDCP_KSV_WRITE_DONE, HDCP_KSV_LIST_CON);
    }
    else
    {
        // not finishing
        writeb(HDCP_KSV_WRITE_DONE, HDCP_KSV_LIST_CON);
    }
}

/**
 * Set HDCP Device Private Keys. @n
 * To activate HDCP H/W, user should set AES-encrypted HDCP Device Private Keys.@n
 * If user does not set this, HDCP H/W does not work.
 */
void load_hdcp_key(void)
{
    int index;
    for (index=0; index < HDCP_KEY_SIZE; index++)
    {
        writeb(HDCP_Test_key[index], AES_DATA);
    }
    writeb(0x01,AES_START);
}

/**
 * Set checksum in Audio InfoFrame Packet. @n
 * Calculate a checksum and set it in packet.
 */
void hdmi_aui_update_checksum(void)
{
    unsigned char index, checksum;

    checksum = AUI_HEADER;
    for (index = 0; index < AUI_PACKET_BYTE_LENGTH; index++)
    {
#if 1
        // when write this byte(PB5), HW shift 3 bit to right direction.
        // to compensate it, when read it, SW should shift 3 bit to left.
        if (index == 4)
            checksum += (readb(HDMI_AUI_BYTE1 + 4*index)<<3);
        else
            checksum += readb(HDMI_AUI_BYTE1 + 4*index);
#else
        checksum += readb(HDMI_AUI_BYTE1 + 4*index);
#endif
    }
    writeb(~checksum+1,HDMI_AUI_CHECK_SUM);
}

/**
 * Set checksum in AVI InfoFrame Packet. @n
 * Calculate a checksum and set it in packet.
 */
void hdmi_avi_update_checksum(void)
{
    unsigned char index, checksum;

    checksum = AVI_HEADER;
    for (index = 0; index < AVI_PACKET_BYTE_LENGTH; index++)
    {
        checksum += readb(HDMI_AVI_BYTE1 + 4*index);
    }
    writeb(~checksum+1,HDMI_AVI_CHECK_SUM);
}

/**
 * Set color space in HDMI H/W. @n
 * @param   space   [in] Color space
 * @return  If argument is invalid, return 0;Otherwise return 1.
 */
int hdmi_set_color_space(enum ColorSpace space)
{
    unsigned char reg,aviYY;
    int ret = 1;

    reg = readb(HDMI_CON_0);
    aviYY = readb(HDMI_AVI_BYTE1);
    // clear fields
    writeb(aviYY & ~(AVI_CS_Y422|AVI_CS_Y444),HDMI_AVI_BYTE1);

	//@2009-12-22
	aviYY = readb(HDMI_AVI_BYTE1);
	
    if (space == HDMI_CS_YCBCR422)
    {
        // set video input interface
        writeb( reg | HDMI_YCBCR422_ENABLE, HDMI_CON_0);
        // set avi
        writeb( aviYY | AVI_CS_Y422, HDMI_AVI_BYTE1);
    }
    else
    {
        // set video input interface
        writeb( reg & ~HDMI_YCBCR422_ENABLE, HDMI_CON_0);
        if (space == HDMI_CS_YCBCR444)
        {
            // set AVI packet
            writeb( aviYY | AVI_CS_Y444, HDMI_AVI_BYTE1);
        }
        // aviYY for RGB = 0, nothing to set
        else if (space != HDMI_CS_RGB)
        {
            ret = 0;
        }
    }

    return ret;
}

/**
 * Set color depth.@n
 * @param   depth   [in] Color depth of input vieo stream
 * @return  If argument is invalid, return 0;Otherwise return 1.
 */
int hdmi_set_color_depth(enum ColorDepth depth)
{
    int ret = 1;
    switch (depth)
    {
        case HDMI_CD_36:
        {
            // set GCP CD
            writeb(GCP_CD_36BPP,HDMI_GCP_BYTE2);
            // set DC_CTRL
            writeb(HDMI_DC_CTL_12,HDMI_DC_CONTROL);
            break;
        }
        case HDMI_CD_30:
        {
            // set GCP CD
            writeb(GCP_CD_30BPP,HDMI_GCP_BYTE2);
            // set DC_CTRL
            writeb(HDMI_DC_CTL_10,HDMI_DC_CONTROL);
            break;
        }
        case HDMI_CD_24:
        {
            // set GCP CD
            writeb(GCP_CD_24BPP,HDMI_GCP_BYTE2);
            // set DC_CTRL
            writeb(HDMI_DC_CTL_8,HDMI_DC_CONTROL);
            break;
        }

        default:
        {
            ret = 0;
        }
    }
    return ret;
}

/**
 * Set video timing parameters.@n
 * @param   mode   [in] Video timing parameters
 */
void hdmi_set_video_mode(struct device_video_params mode)
{
    unsigned char reg;
    unsigned int  val;

    // set HBLANK;
    val = mode.HBlank;
    reg = val & 0xff;
    writeb(reg,HDMI_H_BLANK_0);
    reg = (val>>8) & 0xff;
    writeb(reg,HDMI_H_BLANK_1);

    // set VBlank
    val = mode.VBlank;
    reg = val & 0xff;
    writeb(reg, HDMI_V_BLANK_0);
    reg = (val>>8) & 0xff;
    writeb(reg, HDMI_V_BLANK_1);
    reg = (val>>16) & 0xff;
    writeb(reg, HDMI_V_BLANK_2);

    // set HVLine
    val = mode.HVLine;
    reg = val & 0xff;
    writeb(reg, HDMI_H_V_LINE_0);
    reg = (val>>8) & 0xff;
    writeb(reg, HDMI_H_V_LINE_1);
    reg = (val>>16) & 0xff;
    writeb(reg, HDMI_H_V_LINE_2);

    // set VSync Polarity
    writeb(mode.polarity, HDMI_VSYNC_POL);

    // set HSyncGen
    val = mode.HSYNCGEN;
    reg = val & 0xff;
    writeb(reg, HDMI_H_SYNC_GEN_0);
    reg = (val>>8) & 0xff;
    writeb(reg, HDMI_H_SYNC_GEN_1);
    reg = (val>>16) & 0xff;
    writeb(reg, HDMI_H_SYNC_GEN_2);

    // set VSyncGen1
    val = mode.VSYNCGEN;
    reg = val & 0xff;
    writeb(reg, HDMI_V_SYNC_GEN1_0);
    reg = (val>>8) & 0xff;
    writeb(reg, HDMI_V_SYNC_GEN1_1);
    reg = (val>>16) & 0xff;
    writeb(reg, HDMI_V_SYNC_GEN1_2);

    // set interlace or progresive mode
    writeb(mode.interlaced,HDMI_INT_PRO_MODE);

    if ( mode.interlaced ) // interlaced mode
    {
        // set VBlank_F
        val = mode.VBLANK_F;
        reg = val & 0xff;
        writeb(reg, HDMI_V_BLANK_F_0);
        reg = (val>>8) & 0xff;
        writeb(reg, HDMI_V_BLANK_F_1);
        reg = (val>>16) & 0xff;
        writeb(reg, HDMI_V_BLANK_F_2);

        // set VSyncGen2
        val = mode.VSYNCGEN2;
        reg = val & 0xff;
        writeb(reg, HDMI_V_SYNC_GEN2_0);
        reg = (val>>8) & 0xff;
        writeb(reg, HDMI_V_SYNC_GEN2_1);
        reg = (val>>16) & 0xff;
        writeb(reg, HDMI_V_SYNC_GEN2_2);

        // set VSyncGen3
        val = mode.VSYNCGEN3;
        reg = val & 0xff;
        writeb(reg, HDMI_V_SYNC_GEN3_0);
        reg = (val>>8) & 0xff;
        writeb(reg, HDMI_V_SYNC_GEN3_1);
        reg = (val>>16) & 0xff;
        writeb(reg, HDMI_V_SYNC_GEN3_2);
    }
    else
    {
        // set VBlank_F with default value
        writeb(0x00, HDMI_V_BLANK_F_0);
        writeb(0x00, HDMI_V_BLANK_F_1);
        writeb(0x00, HDMI_V_BLANK_F_2);

        // set VSyncGen2 with default value
        writeb(0x01, HDMI_V_SYNC_GEN2_0);
        writeb(0x10, HDMI_V_SYNC_GEN2_1);
        writeb(0x00, HDMI_V_SYNC_GEN2_2);

        // set VSyncGen3 with default value
        writeb(0x01, HDMI_V_SYNC_GEN3_0);
        writeb(0x10, HDMI_V_SYNC_GEN3_1);
        writeb(0x00, HDMI_V_SYNC_GEN3_2);
    }

    // set pixel repetition
    reg = readb(HDMI_CON_1);
    if ( mode.repetition )
    {
        // set pixel repetition
        writeb(reg|HDMICON1_DOUBLE_PIXEL_REPETITION,HDMI_CON_1);
        // set avi packet
        writeb(AVI_PIXEL_REPETITION_DOUBLE,HDMI_AVI_BYTE5);
    }
    else
    {
        // clear pixel repetition
        writeb(reg & ~(1<<1|1<<0),HDMI_CON_1);
        // set avi packet
        writeb(0x00,HDMI_AVI_BYTE5);
    }

    // set AVI packet with VIC
	reg = readb(HDMI_AVI_BYTE2);

	if (reg & (unsigned char)AVI_PICTURE_ASPECT_RATIO_4_3)
		writeb(mode.AVI_VIC,HDMI_AVI_BYTE4);
	else
		writeb(mode.AVI_VIC_16_9,HDMI_AVI_BYTE4);

    return;
}

void hdmi_set_lcdc_timing(struct device_lcdc_timing_params mode)
{
    volatile unsigned int regl;
    unsigned int val;
	unsigned int lcdc_id;
	unsigned int cnt=0;

	PCKC 	pCKC = (PCKC)tcc_allocbaseaddress((unsigned int)&HwCLK_BASE);
	PLCDC	pLCDC;

	int is_lcdc_en = 0;
		
	// check hdmi connect path
	regl = readl(DDICFG_HDMICTRL);
	val = (regl & HDMICTRL_PATH_LCDC1) >> 15;
	if (val)	// lcdc1
	{
		lcdc_id = 1;
		pLCDC = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE);
		

		// disable lcdc
		regl = readl(&pLCDC->LCTRL);
//		writel(regl & ~(0x00000001), &pLCDC->LCTRL);
		if (regl & 0x00000001)
		{
			is_lcdc_en = 1;
			writel(regl & ~(0x00000001), &pLCDC->LCTRL);

			while(pLCDC->LSTATUS & 0x40000000)	// BUSY	Hw30
			{
				DPRINTK("LCDC%d-LCTRL[%x]STATUS[%x]\n", lcdc_id, pLCDC->LCTRL, pLCDC->LSTATUS);
				Sleep(1);

				if (pLCDC->LCTRL & 0x00000001)
				{
					DPRINTK(">>lcdc%d enabled\n", lcdc_id);
					break;
				}

				if (cnt++ == 30)
				{
					DPRINTK("lcdc%d busy!>\n", lcdc_id);
					break;
				}
			}
		}
		
		regl = readl(&pCKC->PCLK_LCD1);
		writel(regl & ~(0x10000000), &pCKC->PCLK_LCD1);	// EN: 0

		// set lcdc1 clock
		regl = readl(&pCKC->PCLK_LCD1);
		regl &= ~(0x1f000fff);
		writel(regl, &pCKC->PCLK_LCD1);	// EN : 0, init.
		regl |= 12<<24;					// SEL: HDMI PCLK(Variable)
		regl |= 0;						// DIV: 0
		writel(regl, &pCKC->PCLK_LCD1);
		regl |= 1 <<28;					// EN : 1
		writel(regl, &pCKC->PCLK_LCD1);
	}
	else		// lcdc0
	{
		lcdc_id = 0;
		pLCDC = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE);

		// disable lcdc
		regl = readl(&pLCDC->LCTRL);
//		writel(regl & ~(0x00000001), &pLCDC->LCTRL);
		if (regl & 0x00000001)
		{
			is_lcdc_en = 1;
			writel(regl & ~(0x00000001), &pLCDC->LCTRL);

			while(pLCDC->LSTATUS & 0x40000000)	// BUSY	Hw30
			{
				DPRINTK("LCDC%d-LCTRL[%x]STATUS[%x]\n", lcdc_id, pLCDC->LCTRL, pLCDC->LSTATUS);
				Sleep(1);

				if (pLCDC->LCTRL & 0x00000001)
				{
					DPRINTK(">>lcdc%d enabled\n", lcdc_id);
					break;
				}

				if (cnt++ == 30)
				{
					DPRINTK(">>lcdc%d busy!>\n", lcdc_id);
					break;
				}
			}
		}

		// set lcdc0 clock
		regl = readl(&pCKC->PCLK_LCD0);
		regl &= ~(0x1f000fff);
		writel(regl, &pCKC->PCLK_LCD0);	// EN : 0, init.
		regl |= 12<<24;					// SEL: HDMI PCLK(Variable)
		regl |= 0;						// DIV: 0
		writel(regl, &pCKC->PCLK_LCD0);
		regl |= 1 <<28;					// EN : 1
		writel(regl, &pCKC->PCLK_LCD0);
	}

	// set lctrl
	regl = readl(&pLCDC->LCTRL);
	regl &= ~(0x0000f3e0);
	regl |=((mode.id  & 0x1) <<15)
		 | ((mode.iv  & 0x1) <<14)
		 | ((mode.ih  & 0x1) <<13)
		 | ((mode.ip  & 0x1) <<12)
		 | ((mode.dp  & 0x1) << 9)
		 | ((mode.ni  & 0x1) << 8)
		 | ((mode.tv  & 0x1) << 7)
		 | ((mode.tft & 0x1) << 6)
		 | ((mode.stn & 0x1) << 5);
	regl = (regl & ~(0xf<<16)) | ((12)<<16);	//pxdw: 12 - rgb888
	writel(regl, &pLCDC->LCTRL);

	// set clkdiv
	writel(0x80000000, &pLCDC->LCLKDIV);
	
	// set timing
	writel((mode.lpw  <<16) | (mode.lpc  ), &pLCDC->LHTIME1);
	writel((mode.lswc <<16) | (mode.lewc ), &pLCDC->LHTIME2);
	writel((mode.fpw  <<16) | (mode.flc  ), &pLCDC->LVTIME1);
	writel((mode.fswc <<16) | (mode.fewc ), &pLCDC->LVTIME2);
	writel((mode.fpw2 <<16) | (mode.flc2 ), &pLCDC->LVTIME3);
	writel((mode.fswc2<<16) | (mode.fewc2), &pLCDC->LVTIME4);

	regl = readl(&pLCDC->LVTIME1);
	writel(regl | (mode.vdb  <<27) | (mode.vdf  <<22), &pLCDC->LVTIME1);

	// set lcdc.lds
	regl = ((mode.flc+1)<<16) | ((mode.dp==1)?((mode.lpc+1)/2):(mode.lpc+1));
	writel(regl, &pLCDC->LDS);

	// set lcdc.img dma interlace mode
	if (mode.ni)	// non-interlace mode (progressive mode)
	{
		regl = readl(&pLCDC->LI0C);
		writel(regl & ~(0x80000000), &pLCDC->LI0C);
		if(lcdc_id)
		{
			regl = readl(&pLCDC->LI1C);
			writel(regl & ~(0x80000000), &pLCDC->LI1C);
			regl = readl(&pLCDC->LI2C);
			writel(regl & ~(0x80000000), &pLCDC->LI2C);
		}
	}
	else			// interlace mode
	{
		regl = readl(&pLCDC->LI0C);
		writel(regl | (0x80000000), &pLCDC->LI0C);
		if(lcdc_id)
		{
			regl = readl(&pLCDC->LI1C);
			writel(regl | (0x80000000), &pLCDC->LI1C);
			regl = readl(&pLCDC->LI2C);
			writel(regl | (0x80000000), &pLCDC->LI2C);
		}
	}

	// enable lcdc
	if (is_lcdc_en)
	{
		regl = readl(&pLCDC->LCTRL);
		writel(regl | 0x00000001, &pLCDC->LCTRL);
	}

    return;
}

/**
 * Set pixel limitation.
 * @param   limit   [in] Pixel limitation.
* @return  If argument is invalid, return 0;Otherwise return 1.
 */
int hdmi_set_pixel_limit(enum PixelLimit limit)
{
    int ret = 1;
    unsigned char reg,aviQQ;

    // clear field
    reg = readb(HDMI_CON_1);
    reg &= ~HDMICON1_LIMIT_MASK;

    aviQQ = readb(HDMI_AVI_BYTE3);
    aviQQ &= ~AVI_QUANTIZATION_MASK;

    switch (limit) // full
    {
        case HDMI_FULL_RANGE:
        {
            aviQQ |= AVI_QUANTIZATION_FULL;
            break;
        }
        case HDMI_RGB_LIMIT_RANGE:
        {
            reg |= HDMICON1_RGB_LIMIT;
            aviQQ |= AVI_QUANTIZATION_LIMITED;
            break;
        }
        case HDMI_YCBCR_LIMIT_RANGE:
        {
            reg |= HDMICON1_YCBCR_LIMIT;
            aviQQ |= AVI_QUANTIZATION_LIMITED;
            break;
        }
        default:
        {
            ret = 0;
        }
    }
    // set pixel repetition
    writeb(reg,HDMI_CON_1);
    // set avi packet body
    writeb(aviQQ,HDMI_AVI_BYTE3);

    return ret;
}

/**
 * Set pixel aspect ratio information in AVI InfoFrame
 * @param   ratio   [in] Pixel Aspect Ratio
 * @return  If argument is invalid, return 0;Otherwise return 1.
 */
int hdmi_set_pixel_aspect_ratio(enum PixelAspectRatio ratio)
{
    int ret = 1;
    unsigned char reg = AVI_FORMAT_ASPECT_AS_PICTURE;

    switch (ratio)
    {
        case HDMI_PIXEL_RATIO_16_9:
            reg |= AVI_PICTURE_ASPECT_RATIO_16_9;
            break;
        case HDMI_PIXEL_RATIO_4_3:
            reg |= AVI_PICTURE_ASPECT_RATIO_4_3;
            break;
        default:
            ret = 0;
     }
    writeb(reg,HDMI_AVI_BYTE2);
    return ret;
}

/**
 * Set Audio Clock Recovery and Audio Infoframe packet -@n
 * based on sampling frequency.
 * @param   freq   [in] Sampling frequency
 * @return  If argument is invalid, return 0;Otherwise return 1.
 */
int hdmi_set_audio_sample_freq(enum SamplingFreq freq)
{
    unsigned char reg;
    unsigned int n;
    int ret = 1;

    // check param
    if ( freq > sizeof(ACR_N_params)/sizeof(unsigned int) || freq < 0 )
        return 0;

    // set ACR packet
    // set N value
    n = ACR_N_params[freq];
    reg = n & 0xff;
    writeb(reg,HDMI_ACR_N0);
    reg = (n>>8) & 0xff;
    writeb(reg,HDMI_ACR_N1);
    reg = (n>>16) & 0xff;
    writeb(reg,HDMI_ACR_N2);

    // set as measure cts mode
    writeb(ACR_MEASURED_CTS_MODE,HDMI_ACR_CON);

    // set AUI packet
    reg = readb(HDMI_AUI_BYTE2) & ~HDMI_AUI_SF_MASK;

    switch (freq)
    {
        case SF_32KHZ:
            reg |= HDMI_AUI_SF_SF_32KHZ;
            break;

        case SF_44KHZ:
            reg |= HDMI_AUI_SF_SF_44KHZ;
            break;

        case SF_88KHZ:
            reg |= HDMI_AUI_SF_SF_88KHZ;
            break;

        case SF_176KHZ:
            reg |= HDMI_AUI_SF_SF_176KHZ;
            break;

        case SF_48KHZ:
            reg |= HDMI_AUI_SF_SF_48KHZ;
            break;

        case SF_96KHZ:
            reg |= HDMI_AUI_SF_SF_96KHZ;
            break;

        case SF_192KHZ:
            reg |= HDMI_AUI_SF_SF_192KHZ;
            break;

        default:
            ret = 0;
    }

    writeb(reg, HDMI_AUI_BYTE2);

    return ret;
}

/**
 * Set HDMI audio output packet type.
 * @param   packet   [in] Audio packet type
 * @return  If argument is invalid, return 0;Otherwise return 1.
 */
int hdmi_set_audio_packet_type(enum HDMIASPType packet)
{
    int ret = 1;
    unsigned char reg;

    reg = readb(HDMI_ASP_CON);
    reg &= ~ASP_TYPE_MASK;

    switch (packet)
    {
        case HDMI_ASP:
        {
            reg |= ASP_LPCM_TYPE;
            break;
        }
        case HDMI_DSD:
        {
            reg |= ASP_DSD_TYPE;
            break;
        }
        case HDMI_HBR:
        {
            reg |= ASP_HBR_TYPE;
            break;
        }
        case HDMI_DST:
        {
            reg |= ASP_DST_TYPE;
            break;
        }
        default:
            ret = 0;
    }
    writeb(reg,HDMI_ASP_CON);
    return ret;
}

/**
 * Set layout and sample present fields in Audio Sample Packet -@n
 * and channel number field in Audio InfoFrame packet.
 * @param   channel   [in]  Number of channels
 * @return  If argument is invalid, return 0;Otherwise return 1.
 */
int hdmi_set_audio_channel_number(enum ChannelNum channel)
{
    int ret = 1;
    unsigned char reg;

    reg = readb(HDMI_ASP_CON);
    // clear field
    reg &= ~(ASP_MODE_MASK|ASP_SP_MASK);

    // set layout & SP_PRESENT on ASP_CON
    // set AUI Packet
    switch (channel)
    {
        case CH_2:
            reg |= (ASP_LAYOUT_0|ASP_SP_0);
            writeb(AUI_CC_2CH,HDMI_AUI_BYTE1);
            break;
        case CH_3:
            reg |= (ASP_LAYOUT_1|ASP_SP_0|ASP_SP_1);
            writeb(AUI_CC_3CH,HDMI_AUI_BYTE1);
            break;
        case CH_4:
            reg |= (ASP_LAYOUT_1|ASP_SP_0|ASP_SP_1);
            writeb(AUI_CC_4CH,HDMI_AUI_BYTE1);
            break;
        case CH_5:
            reg |= (ASP_LAYOUT_1|ASP_SP_0|ASP_SP_1|ASP_SP_2);
            writeb(AUI_CC_5CH,HDMI_AUI_BYTE1);
            break;
        case CH_6:
            reg |= (ASP_LAYOUT_1|ASP_SP_0|ASP_SP_1|ASP_SP_2);
            writeb(AUI_CC_6CH,HDMI_AUI_BYTE1);
            break;
        case CH_7:
            reg |= (ASP_LAYOUT_1|ASP_SP_0|ASP_SP_1|ASP_SP_2|ASP_SP_3);
            writeb(AUI_CC_7CH,HDMI_AUI_BYTE1);
            break;
        case CH_8:
            reg |= (ASP_LAYOUT_1|ASP_SP_0|ASP_SP_1|ASP_SP_2|ASP_SP_3);
            writeb(AUI_CC_8CH,HDMI_AUI_BYTE1);
            break;
        default:
            ret = 0;
    }
    writeb(reg,HDMI_ASP_CON);
    return ret;
}

/**
 * Enable HDMI output.
 */
void hdmi_start(void)
{
    unsigned char reg,mode;
	unsigned int  regl,val;
	int is_lcdc_en=0;
	unsigned int cnt=0;
	PLCDC pLCDC;

#if defined(TELECHIPS)
//	hdmi_set_lcdc_timing(lcdc_timing_params);
#endif

	regl = readl(DDICFG_HDMICTRL);
	val = (regl & HDMICTRL_PATH_LCDC1) >> 15;
	if (val)	// lcdc1
		pLCDC = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC1_BASE);
	else
		pLCDC = (PLCDC)tcc_allocbaseaddress((unsigned int)&HwLCDC0_BASE);

	mode = readb(HDMI_AVI_BYTE1) & (AVI_CS_Y422|AVI_CS_Y444);

	// disable lcdc
	regl = readl(&pLCDC->LCTRL);
//	writel(regl & ~(0x00000001), &pLCDC->LCTRL);
	if (regl & 0x00000001)
	{
		is_lcdc_en = 1;
		writel(regl & ~(0x00000001), &pLCDC->LCTRL);

		while(pLCDC->LSTATUS & 0x40000000)	// BUSY	Hw30
		{
			DPRINTF("LCDC-LCTRL[%x]STATUS[%x]\n", pLCDC->LCTRL, pLCDC->LSTATUS);
			Sleep(1);

			if (pLCDC->LCTRL & 0x00000001)
			{
				DPRINTF(">>lcdc enabled\n");
				break;
			}

			if (cnt++ == 30)
			{
				DPRINTF("lcdc busy!\n");
				break;
			}
		}
	}

	if(mode)	// YUV420 or YUV444
	{
		regl = readl(&pLCDC->LCTRL);
		regl |= Hw10;		//R2Y: enable
		regl = (regl&(~(Hw20-Hw16)) |8<<16);	//pxdw[19:16]	- YCbCr
		writel(regl, &pLCDC->LCTRL);
	}
	else		// RGB
	{
		regl = readl(&pLCDC->LCTRL);
		regl &= (~Hw10);	//R2Y: disable
		regl = (regl&(~(Hw20-Hw16)) |12<<16);	//pxdw[19:16]	- rgb888
		writel(regl, &pLCDC->LCTRL);
	}

	// enable lcdc
	if (is_lcdc_en)
	{
		regl = readl(&pLCDC->LCTRL);
		writel(regl | 0x00000001, &pLCDC->LCTRL);
	}

    // check HDMI mode
    mode = readb(HDMI_MODE_SEL) & HDMI_MODE_SEL_HDMI;
    reg = readb(HDMI_CON_0);

    // enable external vido gen.
    writeb(HDMI_EXTERNAL_VIDEO,HDMI_VIDEO_PATTERN_GEN);

    if (mode) // HDMI
    {
        // enable AVI packet: mandatory
        // update avi packet checksum
        hdmi_avi_update_checksum();
        // enable avi packet

        writeb(TRANSMIT_EVERY_VSYNC,HDMI_AVI_CON);

        // check if audio is enable
        if (readb(HDMI_ACR_CON))
        {
            // enable aui packet
            hdmi_aui_update_checksum();
            writeb(TRANSMIT_EVERY_VSYNC,HDMI_AUI_CON);
            reg |= HDMI_ASP_ENABLE;
        }

        // check if it is deep color mode or not
        if (readb(HDMI_DC_CONTROL))
        {
            // enable gcp
            writeb(GCP_TRANSMIT_EVERY_VSYNC,HDMI_GCP_CON);
        }
        // enable hdmi
#if defined(TELECHIPS)
		writeb(reg|HDMI_SYS_ENABLE,HDMI_CON_0);
#else
        writeb(reg|HDMI_SYS_ENABLE|HDMI_ENCODING_OPTION_ENABLE,HDMI_CON_0);
#endif
    }
    else // DVI
    {
        // disable all packet
        writeb(DO_NOT_TRANSMIT,HDMI_AUI_CON);
        writeb(DO_NOT_TRANSMIT,HDMI_AVI_CON);
        writeb(DO_NOT_TRANSMIT,HDMI_GCP_CON);

        // enable hdmi without audio
        reg &= ~HDMI_ASP_ENABLE;
#if defined(TELECHIPS)
		writeb(reg|HDMI_SYS_ENABLE,HDMI_CON_0);
#else
        writeb(reg|HDMI_SYS_ENABLE|HDMI_ENCODING_OPTION_ENABLE,HDMI_CON_0);
#endif
    }
    return;
}

/**
 * Read Ri' in  HDCP Rx port. The length of Ri' is 2 bytes. @n
 * Stores LSB first.
 * [0 : 0 : Ri'[1] : Ri'[0]]
 * @return Ri' value.
 */
int hdcp_read_ri(void)
{
#if (0)
    int result;
    struct i2c_adapter *adap;
    struct i2c_msg msgs[2];
    unsigned char buffer[2];
    unsigned char offset = HDCP_RI_OFFSET;

    adap = i2c_get_adapter(0);
    if (!adap)
        return 0;

    // set offset
    msgs[0].addr  = HDCP_RX_DEV_ADDR>>1;
    msgs[0].flags = 0;
    msgs[0].len   = 1;
    msgs[0].buf   = &offset;

    // read data
    msgs[1].addr  = HDCP_RX_DEV_ADDR>>1;
    msgs[1].flags = I2C_M_RD;
    msgs[1].len   = 2;
    msgs[1].buf   = buffer;

    // read from DDC line
    if (i2c_transfer(adap, msgs, 2) < 0)
        return 0;

    result = (buffer[0] << 8) | buffer[1];

    return result;
#else
	return 1;
#endif
}

#ifdef __cplusplus
}
#endif


