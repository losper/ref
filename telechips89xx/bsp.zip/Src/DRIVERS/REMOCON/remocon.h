
/****************************************************************************
 *   FileName    : tca_remocon.h
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __REMOCON_H__
#define __REMOCON_H__

/*******************************************************************************
 Decide the remote type
 if you don't select any one, it will be the default remote controller
********************************************************************************/ 
//#define DARE_IR

//*******************************************
//	Remote KEY value
//*******************************************
#define REM_PWR 		1
#define REM_LOAD		2
#define REM_SUBTITLE	3
#define REM_AUDIO		4
#define REM_ANGLE		5
#define REM_INFO		6

#define REM_KEY1		7	//"1"
#define REM_KEY2		8	//"2"
#define REM_KEY3		9	//"3"
#define REM_KEY4		10	//"4"
#define REM_KEY5		11	//"5"
#define REM_KEY6		12	//"6"
#define REM_KEY7		13	//"7"
#define REM_KEY8		14	//"8"
#define REM_KEY9		15	//"9"
#define REM_KEY0		16	//"0"
#define REM_KEY10		17	//"10+"

#define REM_GOTO		18	//GOTO
#define REM_TITLE		19
#define REM_MENU		20
#define REM_UP			21
#define REM_DOWN		22
#define REM_LEFT		23
#define REM_RIGHT		24
#define REM_ENTER		25
#define REM_SETUP		26
#define REM_RETURN		27
						
#define REM_STOP		28
#define REM_PLAY		29
#define REM_PAUSE		30
#define REM_FB			31
#define REM_FF			32
#define REM_LAST		33
#define REM_NEXT		34

#define REM_AB			35	//A_B
#define REM_REPEAT		36
#define REM_STEP		37
#define REM_PBC 		38
#define REM_ZOOM		39
#define REM_MUTE		40
#define REM_VOLDN		41
#define REM_VOLUP		42
#define REM_SLOW		43
#define REM_RANDOM		44
#define REM_KEYDEC		45	//KEY-
#define REM_KEYADD		46	//KEY+

#define REM_PROGRAM 	47
#define REM_CLEAR		48
#define REM_RESUME		49
#define REM_VIDEO		50
#define REM_PN			51
#define REM_DIGEST		52
#define REM_HDMI		53
#define REM_FUNCTION	54
#define REM_EPG 		55
#define REM_TELETEXT	56
#define REM_SERVICE 	57
#define REM_EXIT		58

#define REM_GUIDE		59
#define REM_LIST		60
#define REM_BROWSE		61
#define REM_RADIO		62
#define REM_FADEC		63	//FA-
#define REM_FAADD		64	//FA+	

#define REM_MODE		65
#define REM_LANG		66
#define REM_CHAR		67


//*******************************************
//	Remote controller define
//*******************************************

#define STATUS0 	0
#define STATUS1 	1
#define STATUS2 	2
#define STATUS3 	3

/* 1 unit = 1 / [IOBUS/(HwREMOCON->uCLKDIVIDE.bCLKDIVIDE.CLK_DIV)]
			  = 1 / [156/(500*20)]	us
			  = 64.1us
*/

//Low Bit
#define LOW_MIN 		0x0800 /* 64.1us x 0x08 = 512us */
#define LOW_MAX 		0x0B00 /* 64.1us x 0x0B = 705us */
//High Bit
#define HIGH_MIN		0x1800 /* 64.1us x 0x18 = 1.538ms */
#define HIGH_MAX		0x1D00 /* 64.1us x 0x1D = 1.859ms */
//Start Bit
#define START_MIN		0x4000 /* 64.1us x 0x40 = 4.102ms */
#define START_MAX		0x5000 /* 64.1us x 0x50 = 5.128ms */
//Repeat Bit
#define REPEAT_MIN		0x2000 /* 64.1us x 0x20 = 2.051ms */
#define REPEAT_MAX		0x2700 /* 64.1us x 0x27 = 2.5ms */

/*****************************************************************************
*
* IR remote controller scancode
*
******************************************************************************/
#define REM_ID_ERROR	0xFF

#define REMOCON_ID		0x00FF

#define SCAN_PWR		0xBA45
#define SCAN_LOAD		0x7887
#define SCAN_SUBTITLE	0xB24D
#define SCAN_AUDIO		0xF807
#define SCAN_ANGLE		0xF00F
#define SCAN_INFO		0x708F

#define SCAN_KEY1		0x926D	//"1"
#define SCAN_KEY2		0xD02F	//"2"
#define SCAN_KEY3		0x50AF	//"3"
#define SCAN_KEY4		0x827D	//"4"
#define SCAN_KEY5		0xC03F	//"5"
#define SCAN_KEY6		0x40BF	//"6"
#define SCAN_KEY7		0xA25D	//"7"
#define SCAN_KEY8		0xE01F	//"8"
#define SCAN_KEY9		0x609F	//"9"
#define SCAN_KEY0		0x9A65	//"0"
#define SCAN_KEY10		0xD827	//"10+"

#define SCAN_GOTO		0x58A7	//GOTO
#define SCAN_TITLE		0xAA55
#define SCAN_MENU		0x6897
#define SCAN_UP 		0xE817
#define SCAN_DOWN		0x4AB5
#define SCAN_LEFT		0x6A95
#define SCAN_RIGHT		0x728D
#define SCAN_ENTER		0xC837
#define SCAN_SETUP		0x8A75
#define SCAN_RETURN 	0x48B7

#define SCAN_STOP		0x5AA5
#define SCAN_PLAY		0x42BD
#define SCAN_PAUSE		0x7A85
#define SCAN_FB 		0x52AD
#define SCAN_FF 		0x629D
#define SCAN_LAST		0x8877
#define SCAN_NEXT		0x08F7

#define SCAN_AB 		0xEA15
#define SCAN_REPEAT 	0x2AD5
#define SCAN_STEP		0xA857
#define SCAN_PBC		0x28D7
#define SCAN_ZOOM		0xDA25
#define SCAN_MUTE		0x1AE5
#define SCAN_VOLDN		0x9867
#define SCAN_VOLUP		0x18E7
#define SCAN_SLOW		0xE21D
#define SCAN_RANDOM 	0x22DD
#define SCAN_KEYDEC 	0xA05F
#define SCAN_KEYADD 	0x20DF

#define SCAN_PROGRAM	0xC23D
#define SCAN_CLEAR		0x02FD
#define SCAN_RESUME 	0x807F
#define SCAN_VIDEO		0x00FF
#define SCAN_PN 		0xD22D
#define SCAN_DIGEST 	0x12ED
#define SCAN_HDMI		0x906F
#define SCAN_FUNCTION	0x10EF
#define SCAN_EPG		0xF20D
#define SCAN_TELETEXT	0x32CD
#define SCAN_SERVICE	0xB04F
#define SCAN_EXIT		0x30CF

#define SCAN_GUIDE		0xFA05
#define SCAN_LIST		0x3AC5
#define SCAN_BROWSE 	0xB847
#define SCAN_RADIO		0x38C7
#define SCAN_FADEC		0xCA35	//FA-
#define SCAN_FAADD		0x0AF5	//FA+	

// Scan-code mapping for keypad
typedef struct {
	unsigned short	rcode;
	unsigned char	vkcode;
}SCANCODE_MAPPING;

/*****************************************************************************
*
* External Variables
*
******************************************************************************/
#define NO_KEY		0
static SCANCODE_MAPPING key_mapping[] = 
{
	{SCAN_PWR, REM_PWR},
	{SCAN_LOAD, REM_LOAD},
	{SCAN_SUBTITLE, REM_SUBTITLE},
	{SCAN_AUDIO, REM_AUDIO},
	{SCAN_ANGLE, REM_ANGLE},
	{SCAN_INFO, REM_INFO},

	{SCAN_KEY1, REM_KEY1},	//"1"
	{SCAN_KEY2, REM_KEY2},	//"2"
	{SCAN_KEY3, REM_KEY3},	//"3"
	{SCAN_KEY4, REM_KEY4},	//"4"
	{SCAN_KEY5, REM_KEY5},	//"5"
	{SCAN_KEY6, REM_KEY6},	//"6"
	{SCAN_KEY7, REM_KEY7},	//"7"
	{SCAN_KEY8, REM_KEY8},	//"8"
	{SCAN_KEY9, REM_KEY9},	//"9"
	{SCAN_KEY0, REM_KEY0},	//"0"
	{SCAN_KEY10, REM_KEY10},	//"10+"

	{SCAN_GOTO, REM_GOTO},	//GOTO
	{SCAN_TITLE, REM_TITLE},
	{SCAN_MENU, REM_MENU},
	{SCAN_UP, REM_UP},
	{SCAN_DOWN, REM_DOWN},
	{SCAN_LEFT, REM_LEFT},
	{SCAN_RIGHT, REM_RIGHT},
	{SCAN_ENTER, REM_ENTER},
	{SCAN_SETUP, REM_SETUP},
	{SCAN_RETURN, REM_RETURN},
						
	{SCAN_STOP, REM_STOP},
	{SCAN_PLAY, REM_PLAY},
	{SCAN_PAUSE, REM_PAUSE},
	{SCAN_FB, REM_FB},
	{SCAN_FF, REM_FF},
	{SCAN_LAST, REM_LAST},
	{SCAN_NEXT, REM_NEXT},

	{SCAN_AB, REM_AB},	//A_B
	{SCAN_REPEAT, REM_REPEAT},
	{SCAN_STEP, REM_STEP},
	{SCAN_PBC, REM_PBC},
	{SCAN_ZOOM, REM_ZOOM},
	{SCAN_MUTE, REM_MUTE},
	{SCAN_VOLDN, REM_VOLDN},
	{SCAN_VOLUP, REM_VOLUP},
	{SCAN_SLOW, REM_SLOW},
	{SCAN_RANDOM, REM_RANDOM},
	{SCAN_KEYDEC, REM_KEYDEC},
	{SCAN_KEYADD, REM_KEYADD},

	{SCAN_PROGRAM, REM_PROGRAM},
	{SCAN_CLEAR, REM_CLEAR},
	{SCAN_RESUME, REM_RESUME},
	{SCAN_VIDEO, REM_VIDEO},
	{SCAN_PN, REM_PN},
	{SCAN_DIGEST, REM_DIGEST},
	{SCAN_HDMI, REM_HDMI},
	{SCAN_FUNCTION, REM_FUNCTION},
	{SCAN_EPG, REM_EPG},
	{SCAN_TELETEXT, REM_TELETEXT},
	{SCAN_SERVICE, REM_SERVICE},
	{SCAN_EXIT, REM_EXIT},

	{SCAN_GUIDE, REM_GUIDE},
	{SCAN_LIST, REM_LIST},
	{SCAN_BROWSE, REM_BROWSE},
	{SCAN_RADIO, REM_RADIO},
	{SCAN_FADEC, REM_FADEC},	//FA-
	{SCAN_FAADD, REM_FAADD},	//FA+	
/*
	{SCAN_MODE, REM_MODE},
	{SCAN_LANG, REM_LANG},
	{SCAN_CHAR, REM_CHAR},
*/
};

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern void tcc_rmt_init(void *pGPIOBaseAddr, void *pREMOTECONBaseAddr);
extern void tcc_rmt_clearandreceivedata(void *pREMOTECONBaseAddr);
extern unsigned int tcc_rmt_getreceivedata(void *pREMOTECONBaseAddr);

#ifdef __cplusplus
}
#endif // __cplusplus
 
#endif	//__REMOCON_H__

