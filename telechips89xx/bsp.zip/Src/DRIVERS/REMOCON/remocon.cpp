/****************************************************************************
 *   FileName    : remote.cpp
 *   Description : Telechips Remote Control Driver
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include <windows.h>
#include "bsp.h"
#include "tcc_gpio.h"

/*****************************************************************************
*
* Header Files Include
*
******************************************************************************/
#include "remocon.h"

#define DEV TEXT("[REMOTE CTL  ]")
static int startbit_time;
static int prev_startbit_time;

/*****************************************************************************
*
* structures
*
******************************************************************************/
typedef struct {
	unsigned int BitCnt;	//Data Bit Count
	unsigned int Buf;		//Data Buffer
	unsigned int Id;		//Remocon ID
	unsigned int Code;		//Parsing Return Value
	unsigned int Val;		//Parsing Value
	unsigned int Prev;		//Previous Data
	unsigned int RepKey;	//Repeat key		: 0 or 1
	unsigned int T1,T2; 	//Repeat Key Time Check
	unsigned int Stat;		//Remocon Status
	unsigned int PwrOff;	//Power Off Mode	: 0 or 1
}REM_DATA;

static REM_DATA Rem;
static char remocon_key;
static DWORD g_dwSysintrRemoteControlTx;
static HANDLE g_hRemoteControlTxInterrupt; 
static HANDLE g_hRemoteControlTxThread; 

GPIO *pstrGPIO_VirtualRegAddr = NULL;
REMOTECON *pstrREMOTECON_VirtualRegAddr = NULL;

/************************************************************************************************
* FUNCTION		: static unsigned int remocon_readcode(char ch)
*
* DESCRIPTION	: 
*
************************************************************************************************/
static unsigned int remocon_readcode(char ch)
{
	switch (Rem.Stat)
	{
		/* Initialize */
		case STATUS0:
			Rem.BitCnt = Rem.Buf = 0;
			Rem.RepKey = 0;
			Rem.Stat = STATUS1;
			break;
			
		/*Start Bit */
		case  STATUS1:
			if (ch == 'S')
			{
				//it appears to be HW bug that the 1st repeat pule is always 
				//recognized wrongly as start bit 
				if(startbit_time !=prev_startbit_time){
					prev_startbit_time=startbit_time;
					Rem.Code = 0;	//reset the memorized code if we get a start bit 
				}
				Rem.Stat = STATUS2;
			}

			//Repeat
			else if (ch == 'R')
			{
				if ((Rem.Code == SCAN_VOLUP)||(Rem.Code == SCAN_VOLDN)||(Rem.Code == SCAN_UP)
					||(Rem.Code == SCAN_DOWN)||(Rem.Code == SCAN_LEFT)||(Rem.Code == SCAN_RIGHT) ) 
				{
					
					Rem.RepKey =  1;
					return Rem.Prev;
				}
			}

			break;
		
		/* Data Code Check */
		case STATUS2:
			if (ch == '0')			//Bit '0' = 3.5ms
			{
				Rem.Buf =(Rem.Buf << 1) & ~Hw0;
				Rem.BitCnt++;
			}
			else if (ch == '1') 	//Bit '1' = 5.5ms
			{
				Rem.Buf = (Rem.Buf << 1) |Hw0;
				Rem.BitCnt++;
			}
			else if (ch == 'S') 	//If Receive Start Bit, Return 0;
			{
				return 0;
			}
			else
			{
				Rem.Stat =STATUS0;
			}
			if(Rem.BitCnt == 32)
			{

				Rem.Id = (Rem.Buf & 0xffff0000) >> 16;
				if (Rem.Id == REMOCON_ID)
				{
					Rem.Code = (Rem.Buf & 0x0000ffff);
					Rem.Stat = STATUS0;
					return Rem.Code;
				}
				else
				{
					Rem.Stat = STATUS0;
				}
			}
			break;
	}
	
	return 0;
}

/************************************************************************************************
* FUNCTION		: static int remocon_getkeycodebyscancode(unsigned short kc)
*
* DESCRIPTION	: return the keycode, return -1 if no key matched
*
************************************************************************************************/
static int remocon_getkeycodebyscancode(unsigned short kc)
{
    int i;
	for (i = 0;i < sizeof(key_mapping)/sizeof(SCANCODE_MAPPING);i++)
      if (kc == key_mapping[i].rcode) 
            return key_mapping[i].vkcode;
    return -1;
}

static void remocon_sendkeyevent(char VirKey)
{
	//Key Down Event
	keybd_event(VirKey,0,0,0);
	//Key Up Event		
	keybd_event(VirKey,0,KEYEVENTF_KEYUP,0);
}

/************************************************************************************************
* FUNCTION		: void remocon_sendremocondata(unsigned int Data)
*
* DESCRIPTION	: 
*
************************************************************************************************/
static void remocon_sendremocondata(unsigned int Data)
{
	int nRem;
	
	//Power Control Message
	if (Data == SCAN_PWR) {
		nRem = remocon_getkeycodebyscancode(Rem.Val);
		if(nRem == -1)
			return;

		remocon_key = (char)nRem;
        
		//Power Off Mode
		if (Rem.PwrOff == 0) {
			Rem.PwrOff = 1;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s remocon_key = 0x%x, PwrOff\r\n"), DEV, remocon_key));
		}
		//Power On Mode
		else {
			Rem.PwrOff = 0;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s remocon_key = 0x%x, PwrOn\r\n"), DEV, remocon_key));
		}
		//reset
		Rem.Val = 0;

		remocon_sendkeyevent(remocon_key);

	}	
	else 
	{
		if (Rem.PwrOff == 0 && Data)
		{
			Rem.Prev = Data;	//For Repeat Key, Current Value Save
			nRem = remocon_getkeycodebyscancode(Rem.Val);
			if(nRem == -1)
				return;

			remocon_key = (char)nRem;
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s remocon_key = 0x%x\r\n"), DEV, remocon_key));
			Rem.Val = 0;	 

			remocon_sendkeyevent(remocon_key);
		}
	}
}

/*****************************************************************************
* Function Name : remocon_process()
******************************************************************************/
static int remocon_process(char ch)
{
	Rem.Val = remocon_readcode(ch);

	if (Rem.Val) {
		if (Rem.RepKey) {
			Rem.RepKey = 0;
		}
		remocon_sendremocondata(Rem.Val);
		return 0;
	}
	else
		return -1;
}

void remocon_thread(void)
{
	DWORD status;
	int i;
	int nTemp;
	char scan_bit = 'x';
	int rd_data[20];

	while(TRUE)
    {
		status = WaitForSingleObject(g_hRemoteControlTxInterrupt, INFINITE);

		if (status == WAIT_OBJECT_0)
		{
			RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s remocon_interrupt\r\n"), DEV));
									
			for(i=0; i<20; i++)
			{
				rd_data[i] = tcc_rmt_getreceivedata(pstrREMOTECON_VirtualRegAddr);
			}
						
			for(i=0; i<20*2; i++)
			{
				if(!(i%2))
					nTemp = rd_data[i/2] & 0xffff;
				else
					nTemp = (rd_data[i/2] >> 16) & 0xffff;
				
				if (( nTemp >= LOW_MIN) && (nTemp <= LOW_MAX)) {			
					scan_bit='0';
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("0")));
				}
				else if ((nTemp >= HIGH_MIN) && (nTemp <= HIGH_MAX)) {			 
					scan_bit='1';
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("1")));
				}
				else if ((nTemp >= REPEAT_MIN) && (nTemp <= REPEAT_MAX)) 
				{		
					scan_bit='R';
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("\r\n\'R\'")));
				}
				else if ((nTemp >= START_MIN) && (nTemp <= START_MAX)) 
				{	
					scan_bit='S';
					startbit_time= rd_data[i/2];  //get Start bit timing  and the 1st data bit timing
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("\r\n\'S\'")));
				}
				else {
					scan_bit='E';
					RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("E")));
				}
				
				if(remocon_process(scan_bit) == 0)
					break;
			}

			/*In NEC Protocol, Diff Time to Next Command is 110ms.
			  2.25ms*32bit + 9ms + 4.5ms = 85.5ms */
			Sleep(10);
			
			tcc_rmt_clearandreceivedata(pstrREMOTECON_VirtualRegAddr);
			InterruptDone(g_dwSysintrRemoteControlTx);

		}		
	}
}

BOOL DllEntry(HINSTANCE hinst_dll, DWORD reason, LPVOID reserved)
{
    switch (reason) {
    case DLL_PROCESS_ATTACH:
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s Process Attach\r\n"), DEV));
		DisableThreadLibraryCalls((HMODULE) hinst_dll);
        break;
    case DLL_PROCESS_DETACH:
        RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s Process Detach\r\n"), DEV));
        break;
    }
    
    return TRUE;
}

DWORD RMT_Init(PVOID p_context)
{
	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
	UINT32 Irq = IRQ_RMT;

	//Get the virtual base address that maps the base physical address
	if(pstrGPIO_VirtualRegAddr == NULL)
		pstrGPIO_VirtualRegAddr = (GPIO*)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	if(pstrREMOTECON_VirtualRegAddr == NULL)
		pstrREMOTECON_VirtualRegAddr = (REMOTECON*)tcc_allocbaseaddress((unsigned int)&HwREMOCON_BASE);
	
	tcc_rmt_init(pstrGPIO_VirtualRegAddr, pstrREMOTECON_VirtualRegAddr);
 
	//Init IR variable
	remocon_key = NO_KEY;

	// Enable remocon interrupt
	if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &Irq, sizeof(UINT32), &g_dwSysintrRemoteControlTx, sizeof(UINT32), NULL))
    {
		RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Remote Control Driver IRQ Init Error!!!\r\n"), DEV));
        goto INIT_ERROR;
    }
	
	g_hRemoteControlTxInterrupt = CreateEvent(NULL, FALSE, FALSE, NULL);
	if (!g_hRemoteControlTxInterrupt)
	{
	   RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Unable to create interrupt event!!!\r\n"), DEV));
	   goto INIT_ERROR;
	}

	if (! InterruptInitialize(g_dwSysintrRemoteControlTx, g_hRemoteControlTxInterrupt, NULL, 0)) {
	   RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Unable to initialize output interrupt!!!\r\n"), DEV));
	   goto INIT_ERROR;
	}
	g_hRemoteControlTxThread	= CreateThread((LPSECURITY_ATTRIBUTES)NULL,
										   0,
										   (LPTHREAD_START_ROUTINE)remocon_thread,
										   NULL,
										   0,
										   NULL);
	if (!g_hRemoteControlTxThread)
	{
	   RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Unable to create interrupt thread!!!\r\n"), DEV));
	   goto INIT_ERROR;
	}

	RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s Init Remote Control Driver!!!\r\n"), DEV));
	return TRUE;

INIT_ERROR:
	RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Cannot init Remote Control Driver!!!\r\n"), DEV));
	return FALSE;	
}

DWORD RMT_Open(DWORD p_context, DWORD access_code, DWORD share_mode)
{
    DWORD ret = TRUE;
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    return ret;
}

BOOL RMT_Close(DWORD p_context)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    return TRUE;
}

DWORD RMT_Read(DWORD h_open_context, LPVOID p_buffer, DWORD count)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    DWORD ret = 0;

	if(remocon_key != NO_KEY)
	{
		*(char*)p_buffer = remocon_key;
		remocon_key = NO_KEY;
		return 1;
	}
	else
	{
		*(char*)p_buffer = NO_KEY;
		return -1;
	}

    return ret;
}

DWORD RMT_Write(DWORD h_open_context, LPVOID p_buffer, DWORD count)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    DWORD ret = 0;
    return ret;
}

BOOL RMT_IOControl(DWORD h_open_context,
                   DWORD code,
                   PBYTE p_inbuf,
                   DWORD inbuf_size,
                   PBYTE p_outbuf,
                   DWORD outbuf_size,
                   LPDWORD p_retruned)
{
	RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
	BOOL ret = FALSE;

	switch (code) {
		case IOCTL_RMT_PWRKEY:
			if(inbuf_size == sizeof(DWORD) && p_inbuf != NULL)
			{
				DWORD dwPWROnOff = *(DWORD *)p_inbuf;
				//Power On Mode
				if (dwPWROnOff == 1 && Rem.PwrOff==0)
				{
					remocon_sendremocondata(SCAN_PWR);
				}
				//Power Off Mode
				else if(dwPWROnOff == 0 && Rem.PwrOff==1)
				{
					remocon_sendremocondata(SCAN_PWR);
				}
			}

			if( outbuf_size == sizeof(DWORD) && p_outbuf != NULL )
			{
				if(Rem.PwrOff)
					*(DWORD *)p_outbuf = 0;
				else
					*(DWORD *)p_outbuf = 1;
			}
			
			ret = TRUE;
			break;
		default:
			RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s Unknown IOCTL[%x]\n"), DEV, code));
			ret = FALSE;
			break;
	}
	
    return ret;
}

DWORD RMT_Seek(DWORD h_open_context, long amount, DWORD type)
{
    RETAILMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
    return 0;
}

void RMT_PowerDown(DWORD p_context)
{
    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
}

void RMT_PowerUp(DWORD p_context)
{
    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
}

void RMT_Deinit(DWORD p_context)
{
	InterruptDisable(g_dwSysintrRemoteControlTx);
	
	if(g_hRemoteControlTxInterrupt)
		CloseHandle(g_hRemoteControlTxInterrupt);

	if(g_hRemoteControlTxThread)
		CloseHandle(g_hRemoteControlTxThread);
	
	KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &g_dwSysintrRemoteControlTx, sizeof(UINT32), NULL, 0, NULL);
    RETAILMSG(TC_LOG_LEVEL(TC_LOG), (TEXT("%s %s\r\n"), DEV, _T(__FUNCTION__)));
}
