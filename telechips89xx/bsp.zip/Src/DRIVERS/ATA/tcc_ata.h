//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//

#ifndef __TCC_ATA_H__
#define __TCC_ATA_H__

#include <atapipcicd.h>
#include <bsp.h>

#define PDC40518_UDMA_REG         0x11
#define PDC40518_SUB_SYSTEM_REG   0x12
#define PDC40518_MASTER_MODE_CTRL 0x1A
#define PDC40518_SYSTEM_CTRL      0x1C
#define PDC40518_ATAPI_TRANSFER   0x20

#define DEV_NAME TEXT("[    SATA    ]")
#define WAIT_TIME_FOR_DMA_DONE (1000 * 4)
#define CLOSE_HANDLE(H, N, F) do { if ((H) != (N)) { (F)(H); (H) = (N); } } while (0)

#define TCC_SATA_BASE_ADDR 0xF0560000

#define TCC_DMADR_REG          0x0400
#define TCC_DMADR_REG_ADDR     (TCC_SATA_BASE_ADDR + TCC_DMADR_REG)
#define CDR7_ERR 0

#define HSATA_INTMR_DMAT_BIT     Hw0
#define HSATA_INTMR_NEWFP_BIT    Hw1
#define HSATA_INTMR_PMABORT      Hw2
#define HSATA_INTMR_ERRM_BIT     Hw3
#define HSATA_INTMR_NEWBIST_BIT  Hw4
#define HSATA_INTMR_PRIMERR_BIT  Hw5
#define HSATA_INTMR_CMDABORT_BIT Hw6
#define HSATA_INTMR_CMDGOOD_BIT   Hw7

#define TCC_INTR_CHECK_BIT (HSATA_INTMR_DMAT_BIT \
                            | HSATA_INTMR_NEWFP_BIT \
                            | HSATA_INTMR_PMABORT \
                            | HSATA_INTMR_ERRM_BIT \
                            | HSATA_INTMR_NEWBIST_BIT \
                            | HSATA_INTMR_PRIMERR_BIT \
                            | HSATA_INTMR_CMDABORT_BIT \
                            | HSATA_INTMR_CMDGOOD_BIT)

#if 0
#define HSATA_ENABLE_INTERRUPTS(tcc_dev) \
   { \
      volatile u32 val32; \
      /* enable all err interrupts */ \
      /* COMRESET clears reg INTMR so .. see where this func is called */ \
      writel(0xffffffff, tcc_dev->membase + HSATA_ERRMR_REG); \
      val32 = readl(tcc_dev->membase + HSATA_INTMR_REG); \
      writel(val32 | TCC_INTR_CHECK_BIT, \
             tcc_dev->membase + HSATA_INTMR_REG); \
      val32 = readl(tcc_dev->membase + HSATA_INTMR_REG); \
      jprintk("INTMR=0x%x", val32);\
   }
#else
#define HSATA_ENABLE_INTERRUPTS(reg) \
   { \
      volatile unsigned int val; \
      /* enable all err interrupts */ \
      /* COMRESET clears reg INTMR so .. see where this func is called */ \
       reg->ERRMR = 0xFFFFFFFF; \
       val = reg->INTMR; \
       reg->INTMR = val | TCC_INTR_CHECK_BIT; \
   }
#endif

#if 1
#define __RX_TEST_DBTSR__ 8
#define __TX_TEST_DBTSR__ 8
#define HSATA_DMA_DBTSR_VAL (((__RX_TEST_DBTSR__) << 16) | ((254 - 8) << 0))
#else
#define __RX_TEST_DBTSR__ 1
#define __TX_TEST_DBTSR__ 1
#define HSATA_DMA_DBTSR_VAL (((__RX_TEST_DBTSR__) << 16) | ((__TX_TEST_DBTSR__) << 0))
#endif

#define HSATA_DMACR_TXMODE_BIT  0x04
#define HSATA_DMACR_TX_EN    0x01 | HSATA_DMACR_TXMODE_BIT
#define HSATA_DMACR_RX_EN    0x02 | HSATA_DMACR_TXMODE_BIT
#define HSATA_DMACR_TXRX_EN  0x03 | HSATA_DMACR_TXMODE_BIT
#define HSATA_DMACR_TXRX_CLEAR HSATA_DMACR_TXMODE_BIT




class TccSataDma
{
public:
    TccSataDma();
    virtual ~TccSataDma();

    HANDLE DeleteDmaIntr(HANDLE h);
    HANDLE NewDmaIntr(int iIrq, int iSysIrq, DWORD dwMask, DWORD dwPortAddr);

    BOOL Init();
    void Clear();

    inline DWORD GetDmaRxSIrq() { return m_dwRxSysIrq; }
    inline DWORD GetDmaTxSIrq() { return m_dwTxSysIrq; }

    BOOL WaitForDmaDone(BOOL isRx);

    void SetRxDma(DWORD dwPhyAddr, DWORD dwCount);
    void SetTxDma(DWORD dwPhyAddr, DWORD dwCount);
    void StartDma(BOOL isRx);
    void StopDma(BOOL isRx);
    void ClearDmaIntr(BOOL isRx);

public:
    HANDLE m_hRxIsr;
    HANDLE m_hTxIsr;
    HANDLE m_hDmaRxEvt;
    HANDLE m_hDmaTxEvt;
    GDMANCTRL *m_pDmaRxReg, *m_pDmaTxReg;
    GDMACTRL *m_pTxDma, *m_pRxDma;

    DWORD m_dwDmaIrq;
    DWORD m_dwRxSysIrq, m_dwTxSysIrq;
    BOOL m_isCurRx;

};


class TccATA : public CPCIDiskAndCD
{
public:
    HANDLE m_hIsr;
    HANDLE m_hEvent;
    DWORD  m_dwDelay;
    BYTE   m_bStatus;

    TccATA(HKEY hKey);
    virtual ~TccATA();

    virtual BOOL Init(HKEY hActiveKey);
    virtual BOOL ConfigPort();
    virtual BOOL WaitForInterrupt(DWORD dwTimeOut);
    virtual DWORD ReadCdRomDMA(DWORD dwLBAAddr, DWORD dwTransferLength, WORD wSectorSize, DWORD dwSgCount, SGX_BUF *pSgBuf);
    virtual VOID ConfigureRegisterBlock(DWORD dwStride);

    virtual BOOL BeginDMA(BOOL fRead);
    virtual BOOL EndDMA();
    virtual BOOL AbortDMA();
    virtual BOOL CompleteDMA(PSG_BUF pSgBuf, DWORD dwSgCount, BOOL fRead);

    static DWORD InterruptThreadStub(IN PVOID lParam);
    DWORD InterruptThread(IN PVOID lParam);

    void WriteBMCommand(BYTE bCommand) {}
    void WriteBMTable(DWORD dwPhys) {}

    inline BYTE ReadUDMAReg() {
        return ATA_READ_BYTE(m_pBMCommand + PDC40518_UDMA_REG);
    }
    inline BYTE ReadModeCtrlReg() {
        return ATA_READ_BYTE(m_pBMCommand + PDC40518_MASTER_MODE_CTRL);
    }
    inline BYTE ReadSubSystemReg() {
        return ATA_READ_BYTE(m_pBMCommand + PDC40518_SUB_SYSTEM_REG);
    }
    inline DWORD ReadSystemCtrlReg() {
        return ATA_READ_DWORD((LPDWORD)(m_pBMCommand + PDC40518_SYSTEM_CTRL));
    }
    inline DWORD ReadAtapiTransferReg() {
        return ATA_READ_DWORD((LPDWORD)(m_pBMCommand + PDC40518_ATAPI_TRANSFER));
    }
    inline void WriteUDMAReg(BYTE bValue) {
        ATA_WRITE_BYTE(m_pBMCommand + PDC40518_UDMA_REG, bValue);
    }
    inline void WriteModeCtrlReg(BYTE bValue) {
        ATA_WRITE_BYTE(m_pBMCommand + PDC40518_MASTER_MODE_CTRL, bValue);
    }
    inline void WriteSubSystemReg(BYTE bValue) {
        ATA_WRITE_BYTE(m_pBMCommand + PDC40518_SUB_SYSTEM_REG, bValue);
    }
    inline void WriteSystemCtrlReg(DWORD bValue) {
        ATA_WRITE_DWORD((LPDWORD)(m_pBMCommand + PDC40518_SYSTEM_CTRL), bValue);
    }
    inline void WriteAtapiTransferReg(DWORD dwValue) {
        ATA_WRITE_DWORD((LPDWORD)(m_pBMCommand + PDC40518_ATAPI_TRANSFER), dwValue);
    }

    virtual BOOL SetupDMA(PSG_BUF pSgBuf, DWORD dwSgCount, BOOL fRead);
    virtual DWORD ReadWriteDiskDMA(PIOREQ pIOReq, BOOL fRead);
    BOOL ReAllocTmpDma(DWORD dwSize);

    /* Telechips method */
    void TccGpioExp_SataOn(BOOL isOn);
    TccSataDma m_xSataDma;
    PSATA m_pSataReg;

    BYTE m_pTmp[512];
    DWORD m_dwRWSize;

    DWORD m_dwTmpPhy;
    unsigned char *m_pTmpVirt;
    DWORD m_dwTmpSize;

};

#endif //__TCC_ATA_H__

