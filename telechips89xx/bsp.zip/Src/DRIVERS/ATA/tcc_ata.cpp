//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES OR INDEMNITIES.
//

#include <tcc_ata.h>
#include <giisr.h>
#include <ceddk.h>

#include "tcc_gpio.h"
#include "tcc_gpioexp.h"
#include "tcc_ckc.h"


#if 0
#ifdef TC_LOG_LEVEL
#undef TC_LOG_LEVEL
#endif
#define TC_LOG_LEVEL(X) X

#ifdef TC_TRACE
#undef TC_TRACE
#endif
#define TC_TRACE 1
#endif

static int tcc_sata_hw_init(unsigned long sata_base);

/* ********************************
 * TCA function
 * ********************************/
static int tca_init_tx_dma(GDMANCTRL *reg, unsigned long fifo)
{
    if (reg) {
        BITCLR(reg->CHCTRL, Hw0);

        reg->ST_DADR = fifo;

        (reg->DPARAM)[0] = 0xFFFFE000 | 4; // fifo mask
        //(reg->DPARAM)[0] = 0; // fifo mask
        (reg->SPARAM)[0] = 0x0 | 4;

        reg->CHCTRL &= 0x00000001;

#if (__TX_TEST_DBTSR__ == 8)
        BITSET(reg->CHCTRL, (Hw3 | Hw5 | Hw6 | Hw7 | Hw8 | Hw9 | Hw12));
#elif (__TX_TEST_DBTSR__ == 4)
        BITSET(reg->CHCTRL, (Hw3 | Hw5 | Hw7 | Hw8 | Hw9 | Hw12));
#elif (__TX_TEST_DBTSR__ == 2)
        BITSET(reg->CHCTRL, (Hw3 | Hw5 | Hw6 | Hw8 | Hw9 | Hw12));
#else
        BITSET(reg->CHCTRL, (Hw3 | Hw5 | Hw8 | Hw9 | Hw12));
#endif
        /* Clear DRI at RPTCTRL */
        BITCLR(reg->RPTCTRL, Hw31);

        BITSET(reg->EXTREQ, Hw14);
        return 0;
    }
    return -1;
}

static int tca_init_rx_dma(GDMANCTRL *reg, unsigned long fifo)
{
    if (reg) {
        BITCLR(reg->CHCTRL, Hw0);

        reg->ST_SADR = fifo;

        (reg->SPARAM)[0] = 0xFFFFE000 | 4; // fifo mask
        //(reg->SPARAM)[0] = 0; // fifo mask
        (reg->DPARAM)[0] = 0x0 | 4;

        reg->CHCTRL &= 0x00000001;

#if (__RX_TEST_DBTSR__ == 8)
        BITSET(reg->CHCTRL, (Hw3 | Hw5 | Hw6 | Hw7 | Hw8 | Hw9));
#elif (__RX_TEST_DBTSR__ == 4)
        BITSET(reg->CHCTRL, (Hw3 | Hw5 | Hw7 | Hw8 | Hw9));
#elif (__RX_TEST_DBTSR__ == 2)
        BITSET(reg->CHCTRL, (Hw3 | Hw5 | Hw6 | Hw8 | Hw9));
#else
        BITSET(reg->CHCTRL, (Hw3 | Hw5 | Hw8 | Hw9));
#endif
        /* Clear DRI at RPTCTRL */
        BITCLR(reg->RPTCTRL, Hw31);

        BITSET(reg->EXTREQ, Hw13);
        return 0;
    }
    return -1;
}

#if 1
static void tca_start_dma(GDMANCTRL *reg)
{
    BITSET(reg->CHCTRL, Hw0 | Hw2);
}

static void tca_stop_dma(GDMANCTRL *reg)
{
    BITCLR(reg->CHCTRL, Hw0 | Hw2);
}

static void tca_clear_dma_intr(GDMANCTRL *reg)
{
    reg->CHCTRL |= Hw3;
}
#else
#define tca_start_dma(reg) BITSET((reg)->CHCTRL, Hw0 | Hw2)
#define tca_stop_dma(reg)  BITCLR((reg)->CHCTRL, Hw0 | Hw2)
#define tca_clear_dma_intr(reg) (reg)->CHCTRL |= Hw3
#endif






TccSataDma::TccSataDma()
{
    m_hRxIsr = m_hTxIsr = NULL;
    m_hDmaRxEvt = m_hDmaTxEvt = NULL;

    m_pDmaTxReg = m_pDmaRxReg = NULL;
    m_dwRxSysIrq = m_dwTxSysIrq = -1;
    m_dwDmaIrq = IRQ_DMA;
    m_isCurRx = FALSE;
}

TccSataDma::~TccSataDma()
{
    Clear();
}

void TccSataDma::Clear()
{
    m_hRxIsr = DeleteDmaIntr(m_hRxIsr);
    m_hTxIsr = DeleteDmaIntr(m_hTxIsr);

    CLOSE_HANDLE(m_hDmaRxEvt, NULL, CloseHandle);
    CLOSE_HANDLE(m_hDmaTxEvt, NULL, CloseHandle);

    m_dwRxSysIrq = m_dwTxSysIrq = -1;
}

BOOL TccSataDma::Init()
{
    DWORD dwTmpRet;
    BOOL bRetRx = FALSE, bRetTx = FALSE, bRet = FALSE;

    Clear();

    m_dwDmaIrq = IRQ_DMA;

    m_pRxDma = (GDMACTRL *)tcc_allocbaseaddress((unsigned int)&HwGDMA3_BASE);
    m_pTxDma = (GDMACTRL *)tcc_allocbaseaddress((unsigned int)&HwGDMA2_BASE);

    m_pDmaRxReg = (GDMANCTRL *)tcc_allocbaseaddress(((unsigned int)&HwGDMA3_BASE + 0x60));
    m_pDmaTxReg = (GDMANCTRL *)tcc_allocbaseaddress(((unsigned int)&HwGDMA2_BASE + 0x60));

    m_hDmaRxEvt = CreateEvent(0, FALSE, FALSE, NULL);
    m_hDmaTxEvt = CreateEvent(0, FALSE, FALSE, NULL);

    if (m_hDmaRxEvt && m_hDmaTxEvt) {
        bRetRx = KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR,
                                 (LPVOID)&m_dwDmaIrq, sizeof(DWORD),
                                 (LPVOID)&m_dwRxSysIrq, sizeof(DWORD),
                                 &dwTmpRet);
        bRetTx = KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR,
                                 (LPVOID)&m_dwDmaIrq, sizeof(DWORD),
                                 (LPVOID)&m_dwTxSysIrq, sizeof(DWORD),
                                 &dwTmpRet);

        if (bRetRx && bRetTx) {
            m_hRxIsr = NewDmaIntr(m_dwDmaIrq, m_dwRxSysIrq, Hw3, (DWORD)&(m_pRxDma->CHCTRL2));
            m_hTxIsr = NewDmaIntr(m_dwDmaIrq, m_dwTxSysIrq, Hw3, (DWORD)&(m_pTxDma->CHCTRL2));
            if (m_hRxIsr && m_hTxIsr) {
                bRetRx = InterruptInitialize(m_dwRxSysIrq, m_hDmaRxEvt, 0, 0);
                bRetTx = InterruptInitialize(m_dwTxSysIrq, m_hDmaTxEvt, 0, 0);
                if (bRetRx && bRetTx) {
                    PPIC pPIC = (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);
                    BITSET(pPIC->MODE0, Hw29);  // level-trigger
                    BITCLR(pPIC->POL0, Hw29);   // active-high

                    tca_init_rx_dma(m_pDmaRxReg, TCC_DMADR_REG_ADDR);
                    tca_init_tx_dma(m_pDmaTxReg, TCC_DMADR_REG_ADDR);
                    bRet = TRUE;
                } else {
                    RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                              (TEXT("%s InterruptInitialize fail !!! (%s %s)\r\n"),
                               DEV_NAME, (bRetRx == FALSE ? "Rx" : ""), (bRetTx == FALSE ? "Tx" : "")));
                }
            }
        } else {
            RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                      (TEXT("%s IOCTL_HAL_REQUEST_SYSINTR fail (%s %s)\r\n"),
                       DEV_NAME, (bRetRx == FALSE ? "Rx" : ""), (bRetTx == FALSE ? "Tx" : "")));
        }
    } else {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s cannot create event !!!  (%s %s)\r\n"),
                                           DEV_NAME, (m_hDmaRxEvt ? "" : "Rx"), (m_hDmaTxEvt ? "" : "Tx")));
    }

    return bRet;
}

BOOL TccSataDma::WaitForDmaDone(BOOL isRx)
{
    DWORD dwStatus = 0;
    HANDLE hIntrEvt = isRx ? m_hDmaRxEvt : m_hDmaTxEvt;

    dwStatus = WaitForSingleObject(hIntrEvt, WAIT_TIME_FOR_DMA_DONE);
    switch (dwStatus) {
    case WAIT_OBJECT_0:
        //ClearDmaIntr(isRx);
        StopDma(isRx);
        InterruptDone(isRx ? m_dwRxSysIrq : m_dwTxSysIrq);
        {
            GDMANCTRL *pReg = isRx ? m_pDmaRxReg : m_pDmaTxReg;
            RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ===== Done DMA HCOUNT[0x%X], hIntrEvt[0x%X]\r\n"),
                                               DEV_NAME, pReg->HCOUNT, hIntrEvt));
        }
        return TRUE;
        break;
    case WAIT_TIMEOUT:
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s  recv timeout [%dms] !!! \r\n"),
                                           DEV_NAME, _T(__FUNCTION__), WAIT_TIME_FOR_DMA_DONE));

        break;
    default:
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s %s  WaitForSingleObject unknown error !!! [%d]\r\n"),
                                           DEV_NAME, _T(__FUNCTION__), GetLastError()));
        break;
    }

    //ClearDmaIntr(isRx);
    StopDma(isRx);
    {
        GDMANCTRL *pReg = isRx ? m_pDmaRxReg : m_pDmaTxReg;
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s ===== DMA HCOUNT[0x%X]\r\n"), DEV_NAME, pReg->HCOUNT));
    }

    InterruptDone(isRx ? m_dwRxSysIrq : m_dwTxSysIrq);
    return FALSE;
}


HANDLE TccSataDma::DeleteDmaIntr(HANDLE h)
{
    CLOSE_HANDLE(h, NULL, FreeIntChainHandler);
    return NULL;
}

HANDLE TccSataDma::NewDmaIntr(int iIrq, int iSysIrq, DWORD dwMask, DWORD dwPortAddr)
{
    HANDLE hNew = NULL;

    hNew = LoadIntChainHandler(L"tcc_giisr.dll", L"DMAISRHandler", iIrq);
    if (hNew == NULL) {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s LoadIntChainHandler return fail %d\r\n"), DEV_NAME, GetLastError()));			
    } else {
        RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s LoadIntChainHandler success\r\n"), DEV_NAME));					
    }

    // Set up ISR handler
    if (hNew) {
        GIISR_INFO xInfo;
        memset(&xInfo, 0, sizeof(GIISR_INFO));
        xInfo.CheckPort = TRUE; //irq happen then chk port <-> false means don't chk port == no shared IRQ
        xInfo.PortIsIO = FALSE; // memory mapped - not real port (TRUE only used X86)
        xInfo.SysIntr = iSysIrq;
        xInfo.PortSize = sizeof(DWORD); // size of GPSB_CIRQST
        xInfo.UseMaskReg = FALSE;
        xInfo.MaskAddr = 0;

        xInfo.Mask = dwMask;
        xInfo.PortAddr = dwPortAddr;

        if (!KernelLibIoControl(hNew, IOCTL_GIISR_INFO,  &xInfo, sizeof(GIISR_INFO), NULL, 0, 0)) {
            RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s KernelLibIoControl return fail %d\r\n"), DEV_NAME, GetLastError()));
            hNew = DeleteDmaIntr(hNew);
        } else {
            RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s KernelLibIoControl return success\r\n"), DEV_NAME));
        }
    }

    return hNew;
}

void TccSataDma::SetRxDma(DWORD dwPhyAddr, DWORD dwCount)
{
    m_pDmaRxReg->ST_DADR = dwPhyAddr;
    m_pDmaRxReg->HCOUNT = dwCount / (4 * __RX_TEST_DBTSR__);                                                          
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ===== Rx DMA HCOUNT[0x%X]\r\n"), DEV_NAME, m_pDmaRxReg->HCOUNT));
}
void TccSataDma::SetTxDma(DWORD dwPhyAddr, DWORD dwCount)
{
    m_pDmaTxReg->ST_SADR = dwPhyAddr;
    m_pDmaTxReg->HCOUNT = dwCount / (4 * __TX_TEST_DBTSR__);                                                          
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ===== Tx DMA HCOUNT[0x%X]\r\n"), DEV_NAME, m_pDmaTxReg->HCOUNT));
}

void TccSataDma::StartDma(BOOL isRx)
{
    tca_start_dma(isRx ? m_pDmaRxReg : m_pDmaTxReg);
    m_isCurRx = isRx;
}
void TccSataDma::StopDma(BOOL isRx)
{
    tca_stop_dma(isRx ? m_pDmaRxReg : m_pDmaTxReg);
}
void TccSataDma::ClearDmaIntr(BOOL isRx)
{
    tca_clear_dma_intr(isRx ? m_pDmaRxReg : m_pDmaTxReg);
}












EXTERN_C CDisk *CreateTccATA(HKEY hKey)
{
    RETAILMSG(1, (TEXT("%s Create SATA\r\n"), DEV_NAME));
    return new TccATA(hKey);
}

// ----------------------------------------------------------------------------
// Function: TccATA
//     Constructor
//
// Parameters:
//     hKey -
// ----------------------------------------------------------------------------

TccATA::TccATA(HKEY hKey)
    : CPCIDiskAndCD(hKey)
{
    PPMU pPMU = (PPMU)tcc_allocbaseaddress((unsigned int)&HwPMU_BASE);
    PPIC pPIC = (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);

    RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s Constructor SATA\r\n"), DEV_NAME));
    m_hIsr = NULL;
    m_hEvent = NULL;
    m_dwDelay = 0;

    TccGpioExp_SataOn(TRUE);
    BITCLR(pPMU->PWROFF, Hw4); // SATA popwer on
    tcc_ckc_setiobus(RB_SATAHCONTROLLER, 1);

    BITSET(pPIC->SEL1, Hw3);
    BITSET(pPIC->MODE1, Hw3);

    m_pSataReg = (PSATA)tcc_allocbaseaddress((unsigned int)&HwSATA_BASE);

    m_dwTmpPhy = 0;
    m_pTmpVirt = NULL;
    m_dwTmpSize = 0;
}

TccATA::~TccATA()
{
    PPMU pPMU = (PPMU)tcc_allocbaseaddress((unsigned int)&HwPMU_BASE);

    BITSET(pPMU->PWROFF, Hw4); // SATA popwer off
    tcc_ckc_setiobus(RB_SATAHCONTROLLER, 0);
    TccGpioExp_SataOn(FALSE);
    CLOSE_HANDLE(m_pTmpVirt, NULL, FreePhysMem);
}

void TccATA::TccGpioExp_SataOn(BOOL isOn)
{
    HANDLE  hGxp; // ����̹� �ڵ�
    DWORD	dwRet;
    GXPINFO xGxpInfo; // Expander �������� ����ü

    hGxp = CreateFile(L"GXP1:",
                      GENERIC_READ | GENERIC_WRITE, NULL, NULL, OPEN_ALWAYS,
                      FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,
                      NULL);

    if (hGxp == INVALID_HANDLE_VALUE) {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s ERROR: Driver: Can't open GXP Driver - sata_on !!\r\n"), DEV_NAME));
        return;
    }

    if (isOn) {
        xGxpInfo.uiDevice = PCA9539LOW;
        xGxpInfo.uiPort = PWRGP4;
        xGxpInfo.uiState = isOn ? ON : OFF;
        if (!WriteFile(hGxp, &xGxpInfo, sizeof(xGxpInfo), &dwRet, NULL)) {
            RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                      (TEXT("%s ERROR: write error for gxp PWRGP4 !! err-code[0x%X]\r\n"), DEV_NAME, GetLastError()));
        }
    }

    xGxpInfo.uiDevice = PCA9539HIGH;
    xGxpInfo.uiPort = RTCRST_;
    xGxpInfo.uiState = isOn ? ON : OFF;
    if (!WriteFile(hGxp, &xGxpInfo, sizeof(xGxpInfo), &dwRet, NULL)) {
        RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                  (TEXT("%s ERROR: write error for gxp RTCRST_ !! err-code[0x%X]\r\n"), DEV_NAME, GetLastError()));
    }

    CloseHandle(hGxp);
}



// ----------------------------------------------------------------------------
// Function: Init
//     Initialize channel
//
// Parameters:
//     hActiveKey -
// ----------------------------------------------------------------------------
BOOL TccATA::Init(HKEY hActiveKey)
{
    // Save SYSINTR & IRQ value for Init
    HSATA_ENABLE_INTERRUPTS(m_pSataReg);
    m_pSataReg->DMACR = HSATA_DMACR_TXMODE_BIT;
    m_xSataDma.Init();
    m_pSataReg->DBTSR = HSATA_DMA_DBTSR_VAL;

    m_pPort->m_dwSysIntr = m_pPort->m_pController->m_pIdeReg->dwSysIntr;
    m_pPort->m_dwIrq     = m_pPort->m_pController->m_pIdeReg->dwIrq;

    ReAllocTmpDma(0x100000);

    return CPCIDisk::Init(hActiveKey);
}


// ----------------------------------------------------------------------------
// Function: InterruptThreadStub
//     SATA IST stub (needed so that InterruptThread may be made static)
//
// Parameters:
//     lParam -
// ----------------------------------------------------------------------------

DWORD TccATA::InterruptThreadStub(IN PVOID lParam)
{
    return ((TccATA *)lParam)->InterruptThread(lParam);
}


#define PDC405XX_SEQINTRSTATUS_OFFSET 0x40
#define PDC405XX_HOSTMODULECNTRL_OFFSET 0x00

// ----------------------------------------------------------------------------
// Function: InterruptThread
//     SATA IST
//
// Parameters:
//     lParam -
// ----------------------------------------------------------------------------

DWORD TccATA::InterruptThread(IN PVOID lParam)
{
    TccATA *pDisk = (TccATA *)lParam;
    unsigned int uiIntpr = 0;

    RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (_T("%s Atapi!CST202T_SATA::InterruptThread> Starting the Interrupt Thread\r\n"), DEV_NAME));


    while(TRUE) {
        WaitForSingleObject(pDisk->m_pPort->m_hIRQEvent, INFINITE);

        //RETAILMSG(ZONE_INIT, (_T("Atapi!CST202T_SATA::InterruptThread> Picked an Interrupt\r\n")));

#if 0
        DWORD temp;
        // Clear the interrupt in the Sequence Interrupt Status register
        // PDC405XX spec Page 26

        volatile DWORD *p_seqintrstatus = (volatile DWORD *)((BYTE *)(m_pPort->m_pController->m_dwControllerBase
                                                                      + PDC405XX_SEQINTRSTATUS_OFFSET));
        temp = (*p_seqintrstatus);
        *p_seqintrstatus = (temp & 0xFFFFFFFE) | 0x00000001 ;
        temp = (*p_seqintrstatus);


        // The SEQ CNT (bits:0-4) in the HOST Module Control Register is set to zero on interrupt
        // We need to set this to 1 to enable interrupts again
        // We also zero out SEQ INT Mask (bit 5) though this is not necessary
        // PDC405XX spec page 25-26.

        volatile DWORD * p_hostmodulecontrol = (volatile DWORD *)((BYTE *)(m_pPort->m_pController->m_dwControllerBase
                                                                           + PDC405XX_HOSTMODULECNTRL_OFFSET));
        temp = (*p_hostmodulecontrol);
        *p_hostmodulecontrol = (temp & 0xFFFFFFC0) | 0x00000001 ;
        temp = (*p_hostmodulecontrol);
#endif

        uiIntpr = m_pSataReg->INTPR;
        if (uiIntpr & TCC_INTR_CHECK_BIT) {
            if (uiIntpr & HSATA_INTMR_ERRM_BIT) {
                unsigned int val = m_pSataReg->SCR1;
                m_pSataReg->SCR1 = val;
                m_pSataReg->INTPR = HSATA_INTMR_ERRM_BIT;
                RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ***** intr ***** ************> SERROR\r\n"), DEV_NAME));
            } else if (uiIntpr & HSATA_INTMR_NEWFP_BIT) {
                unsigned char tag;
                m_pSataReg->INTPR = HSATA_INTMR_NEWFP_BIT;
                tag = m_pSataReg->FPTAGR;

                RETAILMSG(TC_LOG_LEVEL(TC_TRACE),
                          (TEXT("%s ***** intr ***** ************> HSATA_INTMR_NEWFP_BIT, tag[0x%X]\r\n"), DEV_NAME, tag));
            } else if (uiIntpr & HSATA_INTMR_DMAT_BIT) {
                m_pSataReg->INTPR = HSATA_INTMR_DMAT_BIT;
                RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ***** intr ***** ************> HSATA_INTMR_DMAT_BIT\r\n"), DEV_NAME));
            } else if (uiIntpr & HSATA_INTMR_PMABORT) {
                m_pSataReg->INTPR = HSATA_INTMR_PMABORT;
                RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ***** intr ***** ************> HSATA_INTMR_PMABORT\r\n"), DEV_NAME));
            } else if (uiIntpr & HSATA_INTMR_NEWBIST_BIT) {
                m_pSataReg->INTPR = HSATA_INTMR_NEWBIST_BIT;
                RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ***** intr ***** ************> HSATA_INTMR_NEWBIST_BIT\r\n"), DEV_NAME));
            } else if (uiIntpr & HSATA_INTMR_PRIMERR_BIT) {
                m_pSataReg->INTPR = HSATA_INTMR_PRIMERR_BIT;
                RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ***** intr ***** ************> HSATA_INTMR_PRIMERR_BIT\r\n"), DEV_NAME));
            } else if (uiIntpr & HSATA_INTMR_CMDABORT_BIT) {
                m_pSataReg->INTPR = HSATA_INTMR_CMDABORT_BIT;
                RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ***** intr ***** ************> HSATA_INTMR_CMDABORT_BIT\r\n"), DEV_NAME));
            } else if (uiIntpr & HSATA_INTMR_CMDGOOD_BIT) {
                m_pSataReg->INTPR = HSATA_INTMR_CMDGOOD_BIT;
                RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ***** intr ***** ************> HSATA_INTMR_CMDGOOD_BIT\r\n"), DEV_NAME));
            }
        } else {
            RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ***** intr ***** ************> maybe Hw31 [0x%X]\r\n"), DEV_NAME, uiIntpr));
            GetBaseStatus(); // clears ATA interrupt
            SetEvent(pDisk->m_hEvent); // Wakes up CDisk object in atapi.dll
        }
        //InterruptDone(pDisk->m_pPort->m_dwSysIntr);   // clears interrupt for the kernel
        InterruptDone(m_pPort->m_dwSysIntr);   // clears interrupt for the kernel
    }
    return(0);
}

// ----------------------------------------------------------------------------
// Function: WaitForInterrupt
//     Wait for a PDC40518 interrupt
//
// Parameters:
//     dwTimeOut -
// ----------------------------------------------------------------------------

BOOL TccATA::WaitForInterrupt(DWORD dwTimeOut)
{
    BOOL fRet = TRUE;
    DWORD dwRet;

    RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("##################### INTR Start #####################\r\n")));
    dwRet = WaitForSingleObject(m_hEvent, dwTimeOut);
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("##################### INTR End #####################\r\n")));
    if (dwRet == WAIT_TIMEOUT) {
        fRet = FALSE;
    } else {
        if (dwRet != WAIT_OBJECT_0) {
            if (!WaitForDisc(WAIT_TYPE_DRQ, dwTimeOut, 10)) {
                fRet = FALSE;
            }
        }
    }

    if (m_bStatus & ATA_STATUS_ERROR) {
        m_bStatus = GetError();
        fRet = FALSE;
    }

    return fRet;
}


// ----------------------------------------------------------------------------
// Function: ConfigPort
//     Setup SATA interrupt and do initial channel configuration.
//
// Parameters:
//     None
// ----------------------------------------------------------------------------

BOOL TccATA::ConfigPort()
{
    BOOL bRet = FALSE, bRetIsr = FALSE;

#if 0
    if (CPCIDisk::ConfigPort()) {
        //ASSERT(!m_hEvent);
        CLOSE_HANDLE(m_hEvent, NULL, CloseHandle);

        tcc_sata_hw_init((DWORD)m_pSataReg);
        m_hEvent = CreateEvent(NULL, FALSE, FALSE, NULL); // CHANGE THIS M_HEVENT SHOULD BELONG TO CIDEBUS!!!!
        if (m_hEvent) {
            HANDLE hThread = NULL;
            DWORD dwThreadPri;

            bRetIsr = KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR,
                                      &m_pPort->m_dwIrq, sizeof(UINT32),
                                      &m_pPort->m_dwSysIntr, sizeof(UINT32), NULL);
            if (bRetIsr) {
                if (InterruptInitialize(m_pPort->m_dwSysIntr, m_pPort->m_hIRQEvent, 0, 0)) {
                    hThread = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InterruptThreadStub, this, 0, NULL);
                    if (hThread) {
                        if (AtaGetRegistryValue (m_hDevKey, L"IstPriority256", &dwThreadPri)) {
                            ::CeSetThreadPriority(hThread, dwThreadPri);
                        }
                        CloseHandle(hThread);
                        bRet = TRUE;
                    } else {
                        RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                                  (TEXT("%s cannot create thread for intr !!! (%s)\r\n"), DEV_NAME, _T(__FUNCTION__)));
                    }
                } else {
                    RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                              (TEXT("%s InterruptInitialize fail !!! (%s)\r\n"), DEV_NAME, _T(__FUNCTION__)));
                }
            }
        } else {
            RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                      (TEXT("%s cannot create event !!! (%s)\r\n"), DEV_NAME, _T(__FUNCTION__)));
        }
    }
#else
    if (CPCIDisk::ConfigPort()) {
        //ASSERT(!m_hEvent);
        CLOSE_HANDLE(m_hEvent, NULL, CloseHandle);

        tcc_sata_hw_init((DWORD)m_pSataReg);
        m_hEvent = CreateEvent(NULL, FALSE, FALSE, NULL); // CHANGE THIS M_HEVENT SHOULD BELONG TO CIDEBUS!!!!
        if (m_hEvent) {
            HANDLE hThread = NULL;
            DWORD dwThreadPri;

            bRetIsr = TRUE;
            if (bRetIsr) {
                if (1) {
                    hThread = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InterruptThreadStub, this, 0, NULL);
                    if (hThread) {
#if 1
                        if (AtaGetRegistryValue (m_hDevKey, L"IstPriority256", &dwThreadPri)) {
                            dwThreadPri = CE_THREAD_PRIO_256_TIME_CRITICAL;
                            ::CeSetThreadPriority(hThread, dwThreadPri);
                        } else {
                            ::CeSetThreadPriority(hThread, CE_THREAD_PRIO_256_TIME_CRITICAL);
                        }
#endif
                        
                        CloseHandle(hThread);
                        bRet = TRUE;
                    } else {
                        RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                                  (TEXT("%s cannot create thread for intr !!! (%s)\r\n"), DEV_NAME, _T(__FUNCTION__)));
                    }
                } else {
                    RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                              (TEXT("%s InterruptInitialize fail !!! (%s)\r\n"), DEV_NAME, _T(__FUNCTION__)));
                }
            }
        } else {
            RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                      (TEXT("%s cannot create event !!! (%s)\r\n"), DEV_NAME, _T(__FUNCTION__)));
        }
    }
#endif

    return bRet;
}


// ----------------------------------------------------------------------------
// Function: ReadCdRomDMA
//     Read from CD-ROM with DMA
//
// Parameters:
//     None
// ----------------------------------------------------------------------------

DWORD TccATA::ReadCdRomDMA(DWORD dwLBAAddr, DWORD dwTransferLength, WORD wSectorSize, DWORD dwSgCount, SGX_BUF *pSgBuf)
{
    ATAPI_COMMAND_PACKET CmdPkt;
    DWORD dwError = ERROR_SUCCESS;
    DWORD dwSectorsToTransfer;
    SG_BUF CurBuffer[MAX_SG_BUF];
    DWORD dwValue = 0;
    WORD wCount;

    if (m_fInterruptSupported) {
        GetBaseStatus();
    }

    WaitForDisc(WAIT_TYPE_NOT_BUSY, 50);
    WaitForDisc(WAIT_TYPE_NOT_DRQ, 50);

    if (ERROR_SUCCESS != WaitForDisc(WAIT_TYPE_NOT_BUSY, 1000)) {
        //        DumpAllRegs(1);
    }
    if (ERROR_SUCCESS != WaitForDisc(WAIT_TYPE_NOT_DRQ, 1000)) {
        //        DumpAllRegs(1);
    }

    RETAILMSG(TC_LOG_LEVEL(TC_TRACE),
              (_T("Atapi!TccATA::ReadCdRomDMA> LBA(%d), transfer length(%d), sector size(%d), scatter/gather count(%d)\r\n"),
               dwLBAAddr, dwTransferLength, wSectorSize, dwSgCount));

    DWORD dwStartBufferNum = 0, dwEndBufferNum = 0, dwEndBufferOffset = 0;
    DWORD dwNumSectors = dwTransferLength;
    DWORD dwStartSector = dwLBAAddr;

    while (dwNumSectors) {
        dwSectorsToTransfer = (dwNumSectors > MAX_CD_SECT_PER_COMMAND) ? MAX_CD_SECT_PER_COMMAND : dwNumSectors;
        DWORD dwBufferLeft = dwSectorsToTransfer * wSectorSize;
        DWORD dwNumSg = 0;
        while (dwBufferLeft) {
            DWORD dwCurBufferLen = pSgBuf[dwEndBufferNum].sb_len - dwEndBufferOffset;
            if (dwBufferLeft < dwCurBufferLen) {
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_buf = pSgBuf[dwEndBufferNum].sb_buf + dwEndBufferOffset;
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_len = dwBufferLeft;
                dwEndBufferOffset += dwBufferLeft;
                dwBufferLeft = 0;
            } else {
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_buf = pSgBuf[dwEndBufferNum].sb_buf + dwEndBufferOffset;
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_len = dwCurBufferLen;
                dwEndBufferOffset = 0;
                dwEndBufferNum++;
                dwBufferLeft -= dwCurBufferLen;
            }
            dwNumSg++;
        }
        if (!SetupDMA(CurBuffer, dwNumSg, TRUE)) {
            dwError = ERROR_READ_FAULT;
            goto ExitFailure;
        }
        SetupCdRomRead(wSectorSize == CDROM_RAW_SECTOR_SIZE ? TRUE : FALSE, dwStartSector, dwSectorsToTransfer, &CmdPkt);
        wCount = (SHORT)((dwSectorsToTransfer * wSectorSize) >> 1);
        if (AtapiSendCommand(&CmdPkt, wCount, IsDMASupported())) {
            if (m_dwDelay) {
                StallExecution(m_dwDelay);
            }
            WriteAtapiTransferReg(0);
            dwValue = ReadAtapiTransferReg();

            m_dwRWSize = dwSectorsToTransfer * (DWORD)wSectorSize;
            if (!ReAllocTmpDma(m_dwRWSize)) {
                goto ExitFailure;
            }

            BeginDMA(TRUE);
            WriteAtapiTransferReg((1 << 24) | wCount);
            if (m_fInterruptSupported) {
                if (!WaitForInterrupt(m_dwDiskIoTimeOut)) {
                    RETAILMSG(TC_LOG_LEVEL(TC_ERROR),
                              (_T("Atapi!TccATA::ReadCdRomDMA> Failed to wait for interrupt; device(%d)\r\n"),
                               m_dwDeviceId));
                    WriteAtapiTransferReg(0);
                    dwError = ERROR_READ_FAULT;
                    goto ExitFailure;
                }
                WaitForDisc(WAIT_TYPE_NOT_BUSY, 5000, 100);
            }
            WriteAtapiTransferReg(0);
            if (EndDMA()) {
                WaitOnBusy(FALSE);
                CompleteDMA((PSG_BUF)pSgBuf, dwSgCount, TRUE);
            } else {
                dwError = ERROR_READ_FAULT;
                goto ExitFailure;
            }
        }
        dwStartSector += dwSectorsToTransfer;
        dwStartBufferNum = dwEndBufferNum;
        dwNumSectors -= dwSectorsToTransfer;
    }
ExitFailure:
    if (dwError != ERROR_SUCCESS) {
        AbortDMA();
    }
    return dwError;
}



#if 0
inline void TccATA::WriteBMCommand(BYTE bCommand)
{
    volatile DWORD * p_idecontrolandstatus = (volatile DWORD *)m_pBMCommand;
    DWORD temp;
    temp = (*p_idecontrolandstatus);
    RETAILMSG(ZONE_INIT|ZONE_ERROR,
              (_T("TccATA::WriteBMCommand> The p_idecontrolandstatus at 0x%x is 0x%08x \r\n"),
               p_idecontrolandstatus,temp));

    *p_idecontrolandstatus = (temp & 0xFFFFFF00)|bCommand;
    RETAILMSG(ZONE_INIT|ZONE_ERROR,
              (_T("TccATA::WriteBMCommand> The command is 0x%x and word written was 0x%08x \r\n"),
               bCommand, (temp & 0xFFFFFF00) | bCommand));

    temp = (*p_idecontrolandstatus);
    RETAILMSG(ZONE_INIT|ZONE_ERROR,
              (_T("TccATA::WriteBMCommand> The p_idecontrolandstatus at 0x%x is 0x%08x \r\n"),
               p_idecontrolandstatus, temp));

    /*
     RETAILMSG(ZONE_INIT|ZONE_ERROR,
     (_T("TccATA::WriteBMCommand> The BM address is 0x%x Command is 0x%08x \r\n"),
     m_pBMCommand, bCommand));
     ATA_WRITE_BYTE(m_pBMCommand, bCommand);
     */
}

inline void TccATA::WriteBMTable(DWORD dwPhys)
{
    RETAILMSG(ZONE_INIT|ZONE_ERROR, (_T(
                                        "TccATA::WriteBMTable> The BMTable address is 0x%x Param is 0x%08x \r\n"
                                       ),((BYTE *)(m_pPort->m_dwRegBase)) + 0x44,dwPhys));
    ATA_WRITE_DWORD((PULONG)((BYTE *)(m_pPort->m_dwRegBase)) + 0x44, dwPhys);
}
#endif

// ----------------------------------------------------------------------------
// Function: BeginDMA
//     Begin DMA transfer
//
// Parameters:
//     fRead -
// ----------------------------------------------------------------------------

BOOL TccATA::BeginDMA(BOOL fRead)
{
    // We should be reading in bits 0:5 and setting them as they were
    // Right now we just set 0:5 to zero all the time,
    // This works only if we are supporting one SATA drive per controller

#if 0
    BYTE bCommand;

    CacheSync(CACHE_SYNC_DISCARD);

    WriteBMCommand(0);
    ASSERT(0 == m_pPRDPhys.HighPart);
    WriteBMTable(m_pPRDPhys.LowPart);

    if (fRead) {
        bCommand = 0x00 | 0x80;
    } else {
        bCommand = 0x40 | 0x80;
    }

    WriteBMCommand(bCommand);

    return TRUE;
#else
    //RETAILMSG(TC_LOG_LEVEL(TC_ERROR), (TEXT("%s ===== debug =====  (%s) addr[0x%X:0x%X]\r\n"),
    //                                   DEV_NAME, _T(__FUNCTION__), m_pPRDPhys.HighPart, m_pPRDPhys.LowPart));

    CacheSync(CACHE_SYNC_DISCARD);

    ASSERT(0 == m_pPRDPhys.HighPart);

    {
        DWORD dwCnt = m_dwRWSize;
        DWORD fis_len = 0, len = 0;
        DWORD dwPos = 0;

        m_pSataReg->DMACR = HSATA_DMACR_TXRX_CLEAR;
        m_pSataReg->DBTSR = HSATA_DMA_DBTSR_VAL;
        m_pSataReg->DMACR = fRead ? HSATA_DMACR_RX_EN : HSATA_DMACR_TX_EN;
        RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s BeginDMA size  (%d)\r\n"), DEV_NAME, m_dwRWSize));

        do {
            len = dwCnt;

#if 0
            if ((fis_len + len) > 8192) {
                len = 8192 - fis_len;
                fis_len = 0;
            } else {
                fis_len += len;
            }

            if (fis_len == 8192) {
                fis_len = 0;
            }
#else
            if (len > 8192) { len = 8192; }
#endif

            dwCnt -= len;
            if (fRead) {
                m_xSataDma.SetRxDma(m_dwTmpPhy + dwPos, len);
            } else {
                m_xSataDma.SetTxDma(m_dwTmpPhy + dwPos, len);
            }
            m_xSataDma.StartDma(fRead);
            if (dwCnt) {
                if (!m_xSataDma.WaitForDmaDone(m_xSataDma.m_isCurRx)) {
                    return FALSE;
                }
            }
            dwPos += len;
        } while (dwCnt);
    }

    return TRUE;
#endif
}

// ----------------------------------------------------------------------------
// Function: EndDMA
//     End DMA transfer
//
// Parameters:
//     None
// ----------------------------------------------------------------------------

BOOL TccATA::EndDMA()
{
    // We should be reading in bits 0:5 and setting them as they were
    // Right now we just set 0:5 to zero all the time,
    // This works only if we are supporting one SATA drive per controller

    //WriteBMCommand(0);
    RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s ===== debug =====  (%s)\r\n"), DEV_NAME, _T(__FUNCTION__)));
    BOOL bRet = m_xSataDma.WaitForDmaDone(m_xSataDma.m_isCurRx);

#if 0
    if (!WaitForInterrupt(m_dwDiskIoTimeOut))) {
        RETAILMSG(ZONE_IO || ZONE_WARNING,
                  (_T("Atapi!TccATA::ReadWriteDiskDMA> Failed to wait for interrupt; device(%d)\r\n"), m_dwDeviceId));
        RETAILMSG(1, (_T("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++)\r\n")));
        RETAILMSG(1, (_T("++++++++++++++ SERROR [0x%X] ++++++++++++++++++++++++++++++++++++++++)\r\n"), m_pSataReg->SCR1));
        RETAILMSG(1, (_T("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++)\r\n")));
        AbortDMA();
    }
#endif
	return bRet;
}

// ----------------------------------------------------------------------------
// Function: AbortDMA
//     Abort DMA transfer
//
// Parameters:
//     None
// ----------------------------------------------------------------------------

BOOL TccATA::AbortDMA()
{
    //DWORD i;

    // We should be reading in bits 0:5 and setting them as they were
    // Right now we just set 0:5 to zero all the time,
    // This works only if we are supporting one SATA drive per controller

    //WriteBMCommand(0);

#if 0
    m_xSataDma.ClearDmaIntr(TRUE);
    m_xSataDma.ClearDmaIntr(FALSE);
#endif

    m_xSataDma.StopDma(TRUE);
    m_xSataDma.StopDma(FALSE);

    m_pSataReg->DMACR = HSATA_DMACR_TXRX_CLEAR;

#if 0
    for (i = 0; i < m_dwSGCount; i++) {
        if (!m_pSGCopy[i].pDstAddress) {
            UnlockPages(m_pSGCopy[i].pSrcAddress, m_pSGCopy[i].dwSize);
        }
    }

    // free all but the first @MIN_PHYS_PAGES pages; these are fixed
    for (i = MIN_PHYS_PAGES; i < m_dwPhysCount; i++) {
        FreePhysMem(m_pPhysList[i].pVirtualAddress);
    }
#endif

    return FALSE;
}

BOOL TccATA::ReAllocTmpDma(DWORD dwSize)
{
	if (m_pTmpVirt == NULL) {
        RETAILMSG(1, (_T("ReAllocTmpDma 1 [%u=>%u])\r\n"), m_dwTmpSize, dwSize));
        m_dwTmpSize = dwSize;
	    m_pTmpVirt = (unsigned char *)AllocPhysMem(dwSize, PAGE_READWRITE, 0, 0, &m_dwTmpPhy);
        RETAILMSG(1, (_T("ReAllocTmpDma 1 [%u=>%u]),    [0x%X:0x%X]\r\n"), m_dwTmpSize, dwSize, m_pTmpVirt, m_dwTmpPhy));
	} else if (m_dwTmpSize < dwSize){
        CLOSE_HANDLE(m_pTmpVirt, NULL, FreePhysMem);
        RETAILMSG(1, (_T("ReAllocTmpDma 2 [%u=>%u])\r\n"), m_dwTmpSize, dwSize));
        m_dwTmpSize = dwSize;
	    m_pTmpVirt = (unsigned char *)AllocPhysMem(dwSize, PAGE_READWRITE, 0, 0, &m_dwTmpPhy);
        RETAILMSG(1, (_T("ReAllocTmpDma 2 [%u=>%u]),    [0x%X:0x%X]\r\n"), m_dwTmpSize, dwSize, m_pTmpVirt, m_dwTmpPhy));
    }

    return (m_pTmpVirt ? TRUE : FALSE);
}

BOOL TccATA::SetupDMA(PSG_BUF pSgBuf, DWORD dwSgCount, BOOL fRead)
{
	DWORD dwPos = 0, i = 0;

    if (!fRead) {
        for (i = 0; i < dwSgCount; i++) {
			memcpy(m_pTmpVirt + dwPos, pSgBuf[i].sb_buf, pSgBuf[i].sb_len);
            RETAILMSG(TC_LOG_LEVEL(TC_TRACE),
                      (TEXT("%s @@@@@@ copy to PHY [%d: %d] \r\n"),
                       DEV_NAME, i, pSgBuf[i].sb_len));
            dwPos += pSgBuf[i].sb_len;
        }
    }	

    return TRUE;
}





// Promise SATA PDC405XX base addresses
#define PDC405XX_REG_DATA_IDE0_OFFSET  0x200
#define PDC405XX_ATA_IDE0_1WIDTH    0x080

#define PDC405XX_REG_SATA_IDE0_OFFSET  0x400
#define PDC405XX_SATA_IDE0_1WIDTH   0x080


// SATA host controller register offsets (replicated on a per-channel basis)
// These offsets represent the offset from the channel's host controller base
#define PDC405XX_REG_DATA               0x00
#define PDC405XX_REG_FEATURE            0x04     // write
#define PDC405XX_REG_ERROR              0x04     // read
#define PDC405XX_REG_SECT_CNT           0x08
#define PDC405XX_REG_SECT_NUM           0x0C     // CHS mode
#define PDC405XX_REG_CYL_LOW            0x10    // CHS mode
#define PDC405XX_REG_CYL_HIGH           0x14    // CHS mode
#define PDC405XX_REG_LBA_LOW            0x0C     // LBA mode
#define PDC405XX_REG_LBA_MID            0x10    // LBA mode 
#define PDC405XX_REG_LBA_HIGH           0x14    // LBA mode   
#define PDC405XX_REG_DEV_HEAD           0x18
#define PDC405XX_REG_COMMAND            0x1C    // write
#define PDC405XX_REG_STATUS             0x1C    // read     (reading this acknowledges the interrupt)

//#define PDC405XX_REG_ALT_OFFSET         0x38    // read     (reading this does not ack the interrupt)
//#define PDC405XX_IDE_CNTRL_STATUS       0x60


#define PDC405XX_REG_ALT_OFFSET         0x24    // read     (reading this does not ack the interrupt)
#define PDC405XX_IDE_CNTRL_STATUS       0x2C



// ----------------------------------------------------------------------------
// Function: ConfigureRegisterBlock
//     This function is called by DSK_Init before any other CDisk function to
//     set up the register block.
//
// Parameters:
//     dwStride -
// ----------------------------------------------------------------------------

VOID TccATA::ConfigureRegisterBlock(DWORD dwStride)
{
    ASSERT(dwStride == 1);
    // Standard ATA registers
    m_dwStride = dwStride;
    m_dwDataDrvCtrlOffset = PDC405XX_REG_DATA;
    m_dwFeatureErrorOffset = PDC405XX_REG_ERROR;
    m_dwSectCntReasonOffset = PDC405XX_REG_SECT_CNT;
    m_dwSectNumOffset = PDC405XX_REG_SECT_NUM;
    m_dwDrvHeadOffset = PDC405XX_REG_DEV_HEAD;
    m_dwCommandStatusOffset = PDC405XX_REG_COMMAND;
    m_dwByteCountLowOffset = PDC405XX_REG_CYL_LOW;
    m_dwByteCountHighOffset = PDC405XX_REG_CYL_HIGH;
    m_dwAltStatusOffset =  0;
    m_dwAltDrvCtrl = 0;

    // Configure pointers to register regions
    //    m_pPort->m_dwBMR = m_pPort->m_pController->m_dwControllerBase + PDC405XX_DMA_BASE_OFFSET;
#if 0
    m_pPort->m_dwRegBase = m_pPort->m_pController->m_dwControllerBase + PDC405XX_REG_DATA_IDE0_OFFSET;
    m_pPort->m_dwRegAlt = m_pPort->m_dwRegBase + PDC405XX_REG_ALT_OFFSET;
    m_pPort->m_dwBMR = m_pPort->m_dwRegBase + PDC405XX_IDE_CNTRL_STATUS;
    m_pBMCommand = (LPBYTE)m_pPort->m_dwBMR;
#else
    m_pPort->m_dwBMR = (DWORD)m_pTmp;
    m_pBMCommand = (LPBYTE)m_pPort->m_dwBMR;

    {
        DWORD dw = (DWORD)m_pSataReg;
        m_pPort->m_dwRegBase = dw;
        m_pPort->m_dwRegAlt = dw + 0x20;
    }

#endif

    // Register access macros use this
    m_pATAReg = (PBYTE)m_pPort->m_dwRegBase;
    m_pATARegAlt = (PBYTE)m_pPort->m_dwRegAlt;

#if 0
    // SATA registers
    m_pSATAReg = (PBYTE)(m_pPort->m_pController->m_dwControllerBase + PDC405XX_REG_SATA_IDE0_OFFSET);
#else
    m_pSATAReg = (PBYTE)m_pPort->m_dwRegBase;
#endif
}

BOOL TccATA::CompleteDMA(PSG_BUF pSgBuf, DWORD dwSgCount, BOOL fRead)
{
    DWORD dwPos = 0;
	DWORD i;
	
#if 0
    for (i = 0; i < m_dwSGCount; i++) {
        if (m_pSGCopy[i].pDstAddress) {
            // this corresponds to an unaligned region; copy it back to the
            // scatter/gather buffer

            memcpy(m_pSGCopy[i].pDstAddress, m_pSGCopy[i].pSrcAddress, m_pSGCopy[i].dwSize);
        } else {
            // this memory region needs to be unlocked
            UnlockPages(m_pSGCopy[i].pSrcAddress, m_pSGCopy[i].dwSize);
        }
    }

    // free all but the first @MIN_PHYS_PAGES pages; the first @MIN_PHYS_PAGES
    // pages are fixed

    for (i = MIN_PHYS_PAGES; i < m_dwPhysCount; i++) {
        FreePhysMem(m_pPhysList[i].pVirtualAddress);
    }
#endif

    if (fRead) {
        for (i = 0; dwPos < m_dwRWSize; i++) {
            memcpy(pSgBuf[i].sb_buf, m_pTmpVirt + dwPos, pSgBuf[i].sb_len);
            RETAILMSG(TC_LOG_LEVEL(TC_TRACE),
                      (TEXT("%s @@@@@@ copy from PHY [%d: %d] \r\n"),
                       DEV_NAME, i, pSgBuf[i].sb_len));
            dwPos += pSgBuf[i].sb_len;
        }
    }


    return TRUE;
}

DWORD TccATA::ReadWriteDiskDMA(PIOREQ pIOReq, BOOL fRead)
{
    DWORD dwError = ERROR_SUCCESS;
    PSG_REQ pSgReq = (PSG_REQ)pIOReq->pInBuf;
    DWORD dwSectorsToTransfer;
    SG_BUF CurBuffer[MAX_SG_BUF];
    BYTE bCmd;

    // pIOReq->pInBuf is a sterile copy of the caller's SG_REQ

    if ((pSgReq == NULL) || (pIOReq->dwInBufSize < sizeof(SG_REQ))) {
        return ERROR_INVALID_PARAMETER;
    }
    if ((pSgReq->sr_num_sec == 0) || (pSgReq->sr_num_sg == 0)) {
        return  ERROR_INVALID_PARAMETER;
    }
    if ((pSgReq->sr_start + pSgReq->sr_num_sec) > m_DiskInfo.di_total_sectors) {
        return ERROR_SECTOR_NOT_FOUND;
    }

#if 0
    RETAILMSG(ZONE_IO, (_T(
        "Atapi!ReadWriteDiskDMA> sr_start(%ld), sr_num_sec(%ld), sr_num_sg(%ld)\r\n"
        ), pSgReq->sr_start, pSgReq->sr_num_sec, pSgReq->sr_num_sg));
#endif

    GetBaseStatus(); // clear pending interrupt

    DWORD dwStartBufferNum = 0, dwEndBufferNum = 0, dwEndBufferOffset = 0;
    DWORD dwNumSectors = pSgReq->sr_num_sec;
    DWORD dwStartSector = pSgReq->sr_start;

    // process scatter/gather buffers in groups of MAX_SEC_PER_COMMAND sectors
    // each DMA request handles a new SG_BUF array which is a subset of the
    // original request, and may start/stop in the middle of the original buffer

    while (dwNumSectors) {

        // determine number of sectors to transfer
        dwSectorsToTransfer = (dwNumSectors > MAX_SECT_PER_COMMAND) ? MAX_SECT_PER_COMMAND : dwNumSectors;

        // determine size (in bytes) of transfer
        DWORD dwBufferLeft = dwSectorsToTransfer * BYTES_PER_SECTOR;

        DWORD dwNumSg = 0;

        // while the transfer is not complete
        while (dwBufferLeft) {

            // determine the size of the current scatter/gather buffer
            DWORD dwCurBufferLen = pSgReq->sr_sglist[dwEndBufferNum].sb_len - dwEndBufferOffset;

            if (dwBufferLeft < dwCurBufferLen) {
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_buf = pSgReq->sr_sglist[dwEndBufferNum].sb_buf + dwEndBufferOffset;
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_len = dwBufferLeft;
                dwEndBufferOffset += dwBufferLeft;
                dwBufferLeft = 0;
            }
            else {
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_buf = pSgReq->sr_sglist[dwEndBufferNum].sb_buf + dwEndBufferOffset;
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_len = dwCurBufferLen;
                dwEndBufferOffset = 0;
                dwEndBufferNum++;
                dwBufferLeft -= dwCurBufferLen;
            }
            dwNumSg++;
        }

        bCmd = fRead ? m_bDMAReadCommand : m_bDMAWriteCommand ;

        WaitForInterrupt(0);

        m_dwRWSize = dwSectorsToTransfer * BYTES_PER_SECTOR;
        if (!ReAllocTmpDma(m_dwRWSize)) {
            goto ExitFailure;
        }


        // setup the DMA transfer
        if (!SetupDMA(CurBuffer, dwNumSg, fRead)) {
            dwError = fRead ? ERROR_READ_FAULT : ERROR_WRITE_FAULT;
            goto ExitFailure;
        }

        // write the read/write command
        if (!SendIOCommand(dwStartSector, dwSectorsToTransfer, bCmd)) {
            dwError = fRead ? ERROR_READ_FAULT : ERROR_WRITE_FAULT;
            AbortDMA();
            goto ExitFailure;
        }

#if 1
        if (BeginDMA(fRead)) {
            if (fRead) {
                if (m_fInterruptSupported) {
                    if (!WaitForInterrupt(m_dwDiskIoTimeOut) || (CheckIntrState() == ATA_INTR_ERROR)) {
                        RETAILMSG(ZONE_IO || ZONE_WARNING, (_T(
                            "Atapi!TccATA::ReadWriteDiskDMA> Failed to wait for interrupt; device(%d)\r\n"
                            ), m_dwDeviceId));
                        dwError = ERROR_READ_FAULT;
                        AbortDMA();
                        goto ExitFailure;
                    }
                }
                // stop the DMA transfer
                m_pSataReg->DMACR = HSATA_DMACR_TXRX_CLEAR;
                if (EndDMA()) {
                    WaitOnBusy(FALSE);
                    CompleteDMA(CurBuffer, pSgReq->sr_num_sg, fRead);
                }
            } else {
                if (EndDMA()) {
                    m_pSataReg->DMACR = HSATA_DMACR_TXRX_CLEAR;
                    if (m_fInterruptSupported) {
                        if (!WaitForInterrupt(m_dwDiskIoTimeOut) || (CheckIntrState() == ATA_INTR_ERROR)) {
                            RETAILMSG(ZONE_IO || ZONE_WARNING, (_T(
                                "Atapi!TccATA::ReadWriteDiskDMA> Failed to wait for interrupt; device(%d)\r\n"
                                ), m_dwDeviceId));
                            dwError = ERROR_READ_FAULT;
                            AbortDMA();
                            goto ExitFailure;
                        }
                    }
                    WaitOnBusy(FALSE);
                    CompleteDMA(CurBuffer, pSgReq->sr_num_sg, fRead);	
                }
            }
        }
#else
        if (BeginDMA(fRead)) {
            // stop the DMA transfer
            if (EndDMA()) {
                WaitOnBusy(FALSE);
                CompleteDMA(CurBuffer, pSgReq->sr_num_sg, fRead);
            }
        }
#endif

        // update transfer
        dwStartSector += dwSectorsToTransfer;
        dwStartBufferNum = dwEndBufferNum;
        dwNumSectors -= dwSectorsToTransfer;
    }

ExitFailure:
    if (ERROR_SUCCESS != dwError) {
        ResetController();
    }
    pSgReq->sr_status = dwError;
    return dwError;
}




#define NUMPORTS 1

class IDETccATA: public CIDEController
{
public:
    virtual BOOL Init(PIDEREG p_idereg)
    {
        ASSERT(p_idereg);
        m_pPort[0] = new CPort(this);
        if (!m_pPort[0]) return FALSE;
        m_pIdeReg = p_idereg;
        m_bisIOMapped = FALSE;
        return true;
    }

    virtual DWORD GetNumPorts() { return NUMPORTS; }
    virtual CPort * GetPort(unsigned int i)
    {
        ASSERT(i < NUMPORTS);
        ASSERT(i < MAX_DEVICES_PER_CONTROLLER);
        return m_pPort[i];
    }

    virtual BOOL MapIORegisters(HKEY hDevKey, PTSTR szDevKey)
    {
        CIDEBUS *pBus = this;
        BOOL    fRet = FALSE;

        DEBUGCHK(pBus);

#if 0		
        if ((!AtaGetRegistryResources(hDevKey, &pBus->m_dwi))
            || (pBus->m_dwi.memWindows[0].dwBase == 0)
            || (pBus->m_dwi.memWindows[0].dwLen == 0)) {
            RETAILMSG(ZONE_INIT|ZONE_ERROR,
                      (_T("Atapi!GetIoPort> Resource configuration missing or invalid in device key(%s)\r\n"),
                       szDevKey));
            goto exit;
        }
#else
        pBus->m_dwi.memWindows[0].dwBase = TCC_SATA_BASE_ADDR;
        pBus->m_dwi.memWindows[0].dwLen = 0x100;
#endif

        // Save the base virtual addresss of the controller.

#if 0
        BOOL isIOMapped = pBus->m_bisIOMapped;
        ASSERT(isIOMapped == FALSE);
        pBus->m_dwControllerBase = DoIoTranslation(&pBus->m_dwi, 0, &isIOMapped);
        ASSERT(isIOMapped == pBus->m_bisIOMapped);
        if (isIOMapped != pBus->m_bisIOMapped) goto exit;
        pBus->m_dwControllerBaseStatic = DoStaticTranslation(&pBus->m_dwi, 0, &isIOMapped);
        if (isIOMapped != pBus->m_bisIOMapped) goto exit;
#endif

        // Save size of controller's register set so that it can later be unmapped
        pBus->m_dwControllerBase = pBus->m_dwi.memWindows[0].dwBase;
        pBus->m_dwControllerBaseStatic = pBus->m_dwi.memWindows[0].dwBase;
        pBus->m_dwControllerRegSize = pBus->m_dwi.memWindows[0].dwLen;

        fRet = TRUE;

#if 0
exit:;
#endif
     return fRet;
    }

    virtual BOOL MapIrqtoSysIntr()
    {
        // If no SysIntr is provided we have to map IRQ to SysIntr ourselves

        if (!m_pIdeReg->dwSysIntr) {
            DWORD dwReturned = 0;
            if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR,
                                 (LPVOID)&m_pIdeReg->dwIrq, sizeof(DWORD),
                                 (LPVOID)&m_pIdeReg->dwSysIntr, sizeof(DWORD),
                                 &dwReturned)) {
                RETAILMSG(ZONE_INIT|ZONE_ERROR,
                          (_T("Atapi!MapIrqtoSysIntr> Failed to map IRQ(%d) to SysIntr for device\r\n"),
                           m_pIdeReg->dwIrq));
                return FALSE;
            }
        }
        return TRUE;
    }

    virtual BOOL IsMasterSlaveDevice()
    {
        return FALSE;
    }

};


extern "C" CIDEController * NewIDETccATA()
{
    RETAILMSG(1, (TEXT("%s NewIDETccATA\r\n"), DEV_NAME));
    return new IDETccATA;
}

EXTERN_C DWORD TccATAConfig(DWORD dwContext)
{
    RETAILMSG(1, (TEXT("%s TccATAConfig\r\n"), DEV_NAME));
    return 0;
}

#define MAX_RETRY_CNT_IN_BUSY 50
static void wait_for_bits(volatile PSATA p_sata, int ret_on_rst, int timeout_val, int exp_val, int mask, int *matched)
{
    int timeout_cnt = 0, error = 0;
    int failed;
    int rdata = 0, i = 0;
    int phy_sig_det_w = 1;
    int retry_cnt = 0;

Retry:;
    timeout_cnt = error = rdata = i = 0;
    phy_sig_det_w = 1;
    
    *matched = 0;

    // wait for busy, and Drq to be cleared.
    // or timeout or reset, if checking reset
    while ((timeout_cnt < timeout_val)
           && !*matched && (error == 0)
           && !(!phy_sig_det_w && ret_on_rst)) {
        rdata = p_sata->CDR7;
        failed = 0;

        for (i = 0; i <= 31; i++) {
            if ((((mask >> i) & 1) == 1) && (((rdata >> i) & 1) != ((exp_val >> i) & 1))) {
                failed = 1;
            }
        }

        if (failed == 0) {
            *matched = 1;
        }

        // After bits matched, check for error
        if (*matched) {
            if (((rdata & 0xff) != 0x7f) // we're not in Power on reset
                && (((rdata >> CDR7_ERR) & 1) == 1))   // we do have error bit set
            {
                error = 1;
            }
        } else {
            timeout_cnt++;
        }

    }

    if ((ret_on_rst == 1) && !phy_sig_det_w) {
        RETAILMSG(1,
                  (TEXT("%s wait_for_bits: detected a Non recov err, while waiting for bits on reg 0x%x, cnt[%d]\r\n"),
                   DEV_NAME, 0x1C, timeout_cnt));
    } else if (timeout_cnt >= timeout_val) {
        if ((rdata & 0xFF) == 0x80) {
            retry_cnt++;
            if (retry_cnt < MAX_RETRY_CNT_IN_BUSY) {
                RETAILMSG(1,
                          (TEXT("%s RETRY[%d]: Timeout! Device is so busy that we retry negotiation. actual='0x%x'\r\n"),
                           DEV_NAME, retry_cnt, rdata));
                Sleep(100);
                goto Retry;
            }
        }
        RETAILMSG(1,
                  (TEXT("%s wait_for_bits: Timeout waiting reg at address '0x%x' to equal '0x%x', cnt[%d]\r\n"),
                   DEV_NAME, 0x1C, exp_val, timeout_cnt));
    } else {
        RETAILMSG(1,
                  (TEXT("%s wait_for_bits: Got register at address '0x%x' reg expected_value='0x%x', actual='0x%x', cnt[%d]\r\n"),
                   DEV_NAME, 0x1C, exp_val, rdata, timeout_cnt));
    }
}

static void wait_for_bsydrq(volatile PSATA p_sata, int ret_on_rst, int timeout_val, int *matched)
{
    int exp_val = 0;
    int mask = 0x88;

    wait_for_bits(p_sata, ret_on_rst, timeout_val, exp_val, mask, matched);
}

static int prog_host_speed(volatile PSATA p_sata, int speed, int *spd_ok)
{
    int spd_select;
    int reset;
    int reg_data;
    //int i;
    int ret_on_rst;
    int timeout_val;
    int matched;

    // Initialize
    ret_on_rst  = 0;
    timeout_val = 1000000; // Must Be Huge For Speed Negotiation

    // Set speed
    spd_select = (speed == 2) ? 0x2 : 0x1;

    // Reset Device with correct speed
    reset = 1;
    reg_data = (spd_select << 4) | reset;

    // Write SCR2 with speed and reset
    p_sata->SCR2 = reg_data;

    // Need to wait a few clocks of slowest
    //mdelay(1);
    Sleep(1);

    // Set normal operation & correct speed
    reset = 0;
    reg_data = spd_select << 4 | reset;
    //HwSATA->nSCR2 = reg_data;
    p_sata->SCR2 = reg_data;

    // Wait for BSY & DRQ to be cleared
    wait_for_bsydrq(p_sata, ret_on_rst, timeout_val, &matched);

    if (matched) {
        RETAILMSG(TC_LOG_LEVEL(TC_TRACE), (TEXT("%s prog_host_speed: Host Speed selected [speed:%d] SCR0[0x%X]\n"),
                                           DEV_NAME, speed, p_sata->SCR0));
        *spd_ok = 1;
        return 0;
    } else {
        RETAILMSG(TC_LOG_LEVEL(TC_TRACE),
                  (TEXT("%s prog_host_speed: TIMEOUT - Host Speed timed out waiting for speed change! [speed:%d], SCR0[0x%X]\n"),
                   DEV_NAME, speed, p_sata->SCR0));
        *spd_ok = 0;
    }
    return -1;
}

static int tcc_sata_hw_init(unsigned long sata_base)
{
    int spd_ok = 0;
    PSATA p_sata = (PSATA)sata_base;

    if (prog_host_speed(p_sata, 2, &spd_ok) == 0) {
        return 0;
    } else if (prog_host_speed(p_sata, 1, &spd_ok) == 0) {
        return 0;
    }
    return -1;
}

