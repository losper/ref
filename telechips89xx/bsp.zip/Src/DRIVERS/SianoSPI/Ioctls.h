/*************************************************************************
                                                                    
 FILE NAME:   ioctls.h		                                        
                                                                    
 DESCRIPTION: Declarations of the io controls codes for SPI Driver	
                                                                    
                                                                    
 Copyright (C) 2006 Consonance Ltd.                               
 All rights reserved                                                
                                                                    
*************************************************************************/

#ifndef IOCTLS_H
#define IOCTLS_H

#ifdef __cplusplus
extern "C" {
#endif

// We'll need some defines
#include <Windev.h>



	//IO controls
#define SPI_BASE_CODE	0x1000

#define SPI_PROPEITRY_IOCTL_NOTIFY_IP_DATA	CTL_CODE(FILE_DEVICE_UNKNOWN,  (SPI_BASE_CODE+0), METHOD_BUFFERED, FILE_ANY_ACCESS)
//#define SPI_REQUEST_INIT	CTL_CODE(FILE_DEVICE_UNKNOWN,  (SPI_BASE_CODE+0), METHOD_BUFFERED, FILE_ANY_ACCESS)
//#define SPI_NOTIFY_CTRL		CTL_CODE(FILE_DEVICE_UNKNOWN,  (SPI_BASE_CODE+1), METHOD_BUFFERED, FILE_ANY_ACCESS)
//#define SPI_NOTIFY_DATA		CTL_CODE(FILE_DEVICE_UNKNOWN,  (SPI_BASE_CODE+2), METHOD_BUFFERED, FILE_ANY_ACCESS)
//#define SPI_CANCEL_IO		CTL_CODE(FILE_DEVICE_UNKNOWN,  (SPI_BASE_CODE+3), METHOD_BUFFERED, FILE_ANY_ACCESS)
#ifdef __cplusplus
}
#endif

#endif
