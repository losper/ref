#ifndef __SPIHW_H__
#define __SPIHW_H__



#define CHIP_SELECT_nSS1					0xffffffdf
#define CHIP_DESELECT_nSS1				0x00000020

#define SPI_INTERNAL_CLOCK_ENABLE		(1<<18)				// Enable CPU clock to SPI controller

#define ENABLE_SPICLK0					0x08000000
#define ENABLE_SPIMSIO					0x02000000
#define DISABLE_SPICLK_SPIMSIO_PULLUP	0x00003000

//----- Register definitions for SPCON0 control register (global config register) -----
#define SPI_MODE_POLLING				0x00000000				// Data transfer modes
#define SPI_MODE_DMA					0x00000040
#define SPI_MODE_INTERRUPT				0x00000020
#define SPI_CLOCK_ENABLE				0x00000010				// Enable SPI clock (in master mode)
#define SPI_SELECT_MASTER				0x00000008				// Select master mode
#define SPI_CLOCK_POLARITY_HIGH		0x00000000				// Determines active clock type (high or low)
#define SPI_CLOCK_POLARITY_LOW			0x00000004
#define SPI_CLOCK_PHASE_FORMAT_A		0x00000000				// Determines transfer format (A or B)
#define SPI_CLOCK_PHASE_FORMAT_B		0x00000002					
#define SPI_TX_AUTO_GARBAGE				0x00000001				// Used when only receiving data


//----- Register definitions for SPSTA0 status register (global status register) -----
#define SPI_DATA_COLLISION				0x00000004				// Indicates I/O timing error (see datasheet)
#define SPI_MULTI_MASTER_ERROR			0x00000002				// Indicates both sender/reciever configured as Master
#define SPI_TRANSFER_READY				0x00000001				// Indicates SPI is ready to transfer/receive

//----- Register definitions for SPPIN0 control register (global config register) -----
//		NOTE: Bit 1 always needs to be a '1'
#define SPI_MULTI_MASTER_ERROR_ENABLE	0x00000006				// Enables checking for multi-master error 
#define SPI_MASTER_OUT_KEEP				0x00000003				// Determines MOSI drive or release (see datasheet)

void SMS1010_Reset_Low(void);
void SMS1010_Reset_High(void);
void SMS1010_Reset(void);
void SMS1010_PowerUp(void);
void SMS1010_PowerDown(void);
void SPI_CS_LOW();
void SPI_CS_HIGH();

void smsspiphy_deinit(PVOID context);
void* smsspiphy_init(PVOID Context, void(*smsspi_interruptHandler)(void*), PVOID intrContext);


#endif
