#include <windows.h>
#include <CEDDK.h>

#if defined(_TCC79x_)
#include "TCC_IoctlCode.h"
#include "tca_ckcstr.h"

#include "TCC79x_Virtual.h"
#include "SianoSPI.h"
#include "SpiHw.h"
#include "pkfuncs.h"


#elif defined(_TCC80x_)
#include "TCC80x_Virtual.h"
#include "SianoSPI.h"

#define IOCTL_SPI_SETUP		1200
#define IOCTL_SPI_LOOPBACK	1201

HANDLE ghSPI=INVALID_HANDLE_VALUE;

typedef struct _spi_param {
	BOOL CPL;	// SCK Polarity
	BOOL CPH;	// SCK Phase
	BOOL MLB;	// MSB/LSB
	BOOL END;	// Select Endian
	BOOL FP;	// Frame Pulse Polarity
	unsigned int Mhz;	// SPI clock (Mhz)
} spi_param_t;


#elif defined(_TCC89x_)
#include "SianoSPI.h"
#include "bsp.h"
#include "tcc_gpio.h"
#include "tcc_gpioexp.h"

HANDLE ghSPI=INVALID_HANDLE_VALUE;

typedef struct _spi_param {
	BOOL CPL;			// SCK Polarity (= PCK)
	BOOL CPH;			// SCK Phase (= PWD,PRD)
	BOOL LSB;			// MSB/LSB (= SD)
	BOOL FP;			// Frame Pulse Polarity (= PCS,PCD)
	unsigned int Mhz;	// SPI clock (Mhz)
} spi_param_t;

#endif


#define _CMMB_SIANO_INT_PIN_ 19

#define SPI_ACTIVATION_PREAMBLE1 0xc1de0000
#define SPI_ACTIVATION_PREAMBLE2 0xedf151a5
#define SPI_COMMAND_PREAMBLE	 0x7ee75aa5

typedef struct SmsMsgHdr_S
{
    UINT16	msgType;
    UINT8	msgSrcId;
    UINT8	msgDstId;
    UINT16	msgLength;	// Length is of the entire message, including header
    UINT16	msgFlags;
    
} SmsMsgHdr_ST;


typedef struct SmsMsgData_S
{
	SmsMsgHdr_ST	xMsgHeader;
	UINT32			msgData[1];
} SmsMsgData_ST;

#define SMS_MAX_PAYLOAD_SIZE	240

typedef struct SmsDataDownload_S
{
	SmsMsgHdr_ST	xMsgHeader;
	UINT32			MemAddr;
	UINT32			Payload[SMS_MAX_PAYLOAD_SIZE/4];
} SmsDataDownload_ST;


#define MSG_SMS_DATA_DOWNLOAD_REQ		660
#define MSG_SMS_SWDOWNLOAD_TRIGGER_REQ	664
#define MSG_SMS_SPI_INT_LINE_SET_REQ	710
#define MAX_REG_PATH_SIZE 100
#define MAX_REG_KEY_SIZE 100

typedef struct
{
	DWORD					useSSPPort;
//	CHAR					DmaDllName[MAX_REG_PATH_SIZE];
//	DEVICE_DMA_SERVICE_ST*	dmaService;
//	volatile XLLP_SSP_REGS *sspCtrl;
	DWORD					sspDataRegPhy;
	HANDLE					rxEvent;
	HANDLE					SmsInterruptEvent;
	DWORD					spiSysIntr;
	DWORD					RxInterruptCnt;		//For debug
	BOOL					drvActive;
	HANDLE					RxIST;
	PVOID					intrContext;
	BOOL					novaDevice;
	DWORD					novaIntrPin;
	void(*InterruptCallback)(void*);
	HANDLE                               	SmsSPIDMAInterruptEvent;
	HANDLE                               	DMATxCompleteEvent;
	HANDLE                               	SPIDMAInterruptIST;
	DWORD					spiSysIntrDMA3;
}SPIPHY, *PSPIPHY;

void SetupSPI(PSPIPHY pSpiPhy);
void UnSetupSPI(PSPIPHY pSpiPhy);

//#define USESPIDMA

/*------------------------------ GLOBALS -------------------------------------------
volatile S3C2440A_IOPORT_REG		*g_pIOPregs		= NULL;		// GPIO registers (needed to enable I2S and SPI)
volatile S3C2440A_SPI_REG			*g_pSPIregs        = NULL;		// SPI control registers
volatile S3C2440A_CLKPWR_REG		*g_pCLKPWRreg	= NULL;		// Clock power registers (needed to enable I2S and SPI clocks)
volatile S3C2440A_DMA_REG		*g_pDMAregs	= NULL;		// DMA registers (needed for I/O on SPI bus)
volatile S3C2440A_INTR_REG 		*s2440INT 		= NULL;
char     				*DMARXBuffer 	= NULL;
char     				*DMATXBuffer	= NULL;
volatile DWORD 		g_dwWaitCounter = 0;

PHYSICAL_ADDRESS g_PhysDMABufferAddr;
*/

//extern char TranferMsgQueueTimeOutMode;
CRITICAL_SECTION SPI_Section;

void MyDelay(int time)
{
    // resolution of time is 100ns, because delayLoopCount=4901
    int i;
    for(;time>0;time--)
       	for(i=0;i<5;i++);
}

void SPI_CS_LOW()
{
#if defined(_TCC79x_)
    BITCSET (HwPORTCFG7, Hw28-Hw24, Hw24);	// CS=FRM1 DATA VALID (Active Low)
   	HwGPDEN |= Hw9;
	HwGPDDAT &= ~Hw9;

#elif defined(_TCC80x_)
	HwGPIOPS_FS0&=~Hw18;
	HwGPIOPS_DOE|=Hw18;
	HwGPIOPS_DAT&=~Hw18;

#elif defined(_TCC89x_)
    // use driver
#endif
}

void SPI_CS_HIGH()
{
#if defined(_TCC79x_)
    BITCSET (HwPORTCFG7, Hw28-Hw24, Hw24);	// CS=FRM1 DATA VALID (Active High)
    HwGPDEN |= Hw9;
    HwGPDDAT |= Hw9;	

#elif defined(_TCC80x_)
	HwGPIOPS_FS0&=~Hw18;
	HwGPIOPS_DOE|=Hw18;
	HwGPIOPS_DAT|=Hw18;

#elif defined(_TCC89x_)
    // use driver
#endif
}

VOID StartSPIClock(VOID)
{
	//g_pCLKPWRreg->CLKCON |= SPI_INTERNAL_CLOCK_ENABLE;		// Enable the CPU clock to the SPI controller
	//g_pSPIregs->SPCON0 |= SPI_CLOCK_ENABLE;					// Enable the SPI clock
	return;
}

VOID StopSPIClock(VOID)
{
	//g_pCLKPWRreg->CLKCON &= ~SPI_INTERNAL_CLOCK_ENABLE;	// Disable the CPU clock to the SPI controller
	//g_pSPIregs->SPCON0 &= ~SPI_CLOCK_ENABLE;				// Disable the SPI clock
	return;
}

BOOL SPIWriteString(BYTE *pData,DWORD Length)
{
      BOOL    bRet = TRUE;
/*	
      static  DWORD waitCount = 0;
	DWORD i;
       StartSPIClock();
	   
	g_pIOPregs->GPFDAT &= CHIP_SELECT_nSS1; 

	waitCount = 100;
	while(!(g_pSPIregs->SPSTA1 & SPI_TRANSFER_READY))
	{
		    if(--waitCount == 0)
			{
			    RETAILMSG(1, (TEXT("SPI: SPIWriteString() - timeout occurred while waiting to transfer byte\r\n")));
                	    bRet = FALSE;
			    goto SEND_ERROR;
			}
	}
	
	for(i=0; i<Length; i++)
	{
		g_pSPIregs->SPTDAT1= *(pData++);
		MyDelay(16);   // about 100ns*8

	       waitCount = 100;
	       while(!(g_pSPIregs->SPSTA1 & SPI_TRANSFER_READY))
		{
		    if(--waitCount == 0)
			{
			    RETAILMSG(1, (TEXT("SPI: SPIWriteString() - timeout occurred while waiting to transfer byte\r\n")));
                	    bRet = FALSE;
			    goto SEND_ERROR;
			}
		}
	}

	g_pIOPregs->GPFDAT |= CHIP_DESELECT_nSS1; 
//*/
#if defined(_TCC79x_)

	unsigned char *  pSourceBytes=pData;
	unsigned char tmp;
	int i;

	SPI_CS_LOW();

	EnterCriticalSection(&SPI_Section);
		
	for(i=0; i<Length; i++){
 		HwGPSB_CH1PORT = pSourceBytes[i];
/*		
		MyDelay(16);   // about 100ns*8
	       waitCount = 100;
	       while(!(HwGPSB_CH1STAT & HwGPSB_CH1STAT_RNE))
		{
		       if(--waitCount == 0)
			{
			    RETAILMSG(1, (TEXT("SPI: SPIWriteString() - timeout occurred while waiting to transfer byte\r\n")));
                	    bRet = FALSE;
			    goto SEND_ERROR;
			}
		}
//*/
		while(!(HwGPSB_CH1STAT & HwGPSB_CH1STAT_RNE));
		tmp = HwGPSB_CH1PORT; //Recieve data
	}
	
	LeaveCriticalSection(&SPI_Section);
	
	SPI_CS_HIGH();
	
	return bRet;

	
SEND_ERROR:
    
//       StopSPIClock();
	return bRet;

#elif defined(_TCC80x_) || defined(_TCC89x_)

    DWORD r;
    BOOL b=WriteFile(ghSPI, pData, Length, &r, NULL);
    ///printf("[w]%d\r\n", Length);

    if( r!=Length )
        printf("!!!!Write::%d %d\r\n", Length, r);

    return b;
#endif
}

BOOL SPIWriteReadString(BYTE *pBufIn, BYTE *pBufOut, DWORD Length)
{
	BOOL    bRet = TRUE;
/*
	BYTE * pOrgBufIn = pBufIn;    // remember bufin so we can print it later
	BYTE * pOrgBufOut = pBufOut;    // remember bufin so we can print it later
	static  DWORD waitCount = 0;
	DWORD i;

        #ifdef SMIT_DEBUG_MSG
	RETAILMSG(1, (TEXT("SPI: SPIWriteReadString() sending - %02x %02x %02x %02x %02x %02x\r\n"),
                          pBufIn[0],pBufIn[1],pBufIn[2],pBufIn[3],pBufIn[4],pBufIn[5]));
        #endif

	StartSPIClock();

	g_pIOPregs->GPFDAT &= CHIP_SELECT_nSS1;

	waitCount = 100;
	while(!(g_pSPIregs->SPSTA1 & SPI_TRANSFER_READY))
	{
		    if(--waitCount == 0)
			{
			    RETAILMSG(1, (TEXT("SPI: SPIWriteReadString() - A - timeout occurred while waiting to transfer byte\r\n")));
                	    bRet = FALSE;
			    goto WRITEREAD_ERROR;
			}
	}

	for(i=0; i<Length; i++)
	{
          g_pSPIregs->SPTDAT1= *(pBufIn++);
	   MyDelay(16);   // about 100ns*8
	 
	   waitCount = 100;
	   while(!(g_pSPIregs->SPSTA1 & SPI_TRANSFER_READY))
	   {
		    if(--waitCount == 0)
			{
			    RETAILMSG(1, (TEXT("SPI: SPIWriteReadString() - B - timeout occurred while waiting to transfer byte\r\n")));
                	    bRet = FALSE;
			    goto WRITEREAD_ERROR;
			}
	   }

	   *(pBufOut++)=g_pSPIregs->SPRDAT1;
	}

	waitCount = 100;
	while(!(g_pSPIregs->SPSTA1 & SPI_TRANSFER_READY))
	{
		    if(--waitCount == 0)
			{
			    RETAILMSG(1, (TEXT("SPI: SPIWriteReadString() - C - timeout occurred while waiting to transfer byte\r\n")));
                	    bRet = FALSE;
			    goto WRITEREAD_ERROR;
			}
	}
	
	*(pBufOut++)=g_pSPIregs->SPRDAT1;

	waitCount = 100;
	while(!(g_pSPIregs->SPSTA1 & SPI_TRANSFER_READY))
	{
		    if(--waitCount == 0)
			{
			    RETAILMSG(1, (TEXT("SPI: SPIWriteReadString() - D - timeout occurred while waiting to transfer byte\r\n")));
                	    bRet = FALSE;
			    goto WRITEREAD_ERROR;
			}
	}

	g_pIOPregs->GPFDAT |= CHIP_DESELECT_nSS1;
//*/
#if defined(_TCC79x_)

    unsigned char *  pSourceBytes=pBufIn;
	unsigned char *  pDestBytes=pBufOut;

	int i;

	SPI_CS_LOW();

	EnterCriticalSection(&SPI_Section);
		
	for(i=0; i<Length; i++){
 		HwGPSB_CH1PORT = pSourceBytes[i];
/*		
		MyDelay(16);   // about 100ns*8
	       waitCount = 100;
	       while(!(HwGPSB_CH1STAT & HwGPSB_CH1STAT_RNE))
		{
		       if(--waitCount == 0)
			{
			    RETAILMSG(1, (TEXT("SPI: SPIWriteString() - timeout occurred while waiting to transfer byte\r\n")));
                	    bRet = FALSE;
			    goto SEND_ERROR;
			}
		}
//*/
		while(!(HwGPSB_CH1STAT & HwGPSB_CH1STAT_RNE));
		pDestBytes[i] = HwGPSB_CH1PORT; //Recieve data
	}


WRITEREAD_ERROR:

 //      StopSPIClock();

//	for(i=0; i<Length; i++)
//		*(pBufOut+i) = *(pBufOut+i+1); 

	LeaveCriticalSection(&SPI_Section);
	SPI_CS_HIGH();

/*	
	RETAILMSG(1,(TEXT("Receive Start %d: "),Length));	
	for(i=0; i<Length; i++)
	{
		RETAILMSG(1,(TEXT("%x  "),pBufOut[i]));	
	}
	RETAILMSG(1,(TEXT("\r\n")));	
//*/	
	return bRet;

#elif defined(_TCC80x_) || defined(_TCC89x_)

    DWORD r;
    BOOL b=ReadFile(ghSPI, pBufIn, Length, &r, NULL);

    if( r!=Length )
        printf("!!!!Read::%d %d\r\n", Length, r);

    memcpy(pBufOut, pBufIn, r);
    ///printf("[r]%d\r\n", r);

    return b;
#endif
}

BOOL SPIDMAWriteString(PSPIPHY pSpiPhy, BYTE *pBufIn,DWORD Length)
{
	BOOL bRet=TRUE;
/*
	memcpy(DMATXBuffer, pBufIn, Length);
	g_pIOPregs->GPFDAT &= CHIP_SELECT_nSS1; 	

       g_pDMAregs->DISRC3	= (int)(g_PhysDMABufferAddr.LowPart+320);
       g_pDMAregs->DISRCC3 &= ~(SOURCE_PERIPHERAL_BUS | INCREASE_SOURCE_ADDRESS);		// Source is system bus, increment addr

      g_pDMAregs->DIDST3	= (int)(S3C2440A_BASE_REG_PA_SPI+0x30);
      g_pDMAregs->DIDSTC3 |= (DESTINATION_PERIPHERAL_BUS | FIXED_DESTINATION_ADDRESS);	// Dest is  periperal bus, fixed addr

	g_pDMAregs->DCON3	= (  HANDSHAKE_MODE | GENERATE_INTERRUPT | SPI_DMA3 | DMA_TRIGGERED_BY_HARDWARE | NO_DMA_AUTO_RELOAD
						   | TRANSFER_BYTE | Length );

       g_pSPIregs->SPCON1 = (2<<5)|(1<<4)|(1<<3)|(0<<2)|(0<<1)|(0<<0);//DMA,en-SCK,master,low,A,normal
       g_pSPIregs->SPPIN1  = (0<<2)|(1<<1)|(0<<0);//dis-ENMUL,SBO,release

	g_pDMAregs->DMASKTRIG3 &= ~STOP_DMA_TRANSFER;
	g_pDMAregs->DMASKTRIG3 |= ENABLE_DMA_CHANNEL;

	if (WaitForSingleObject(pSpiPhy->DMATxCompleteEvent, 1000) == WAIT_OBJECT_0)
	{
		RETAILMSG(ZONE_INFO,(TEXT("SPI: SPIDMAWriteString(): DMA transfer ended in time\n")));
	}
	else
	{
		RETAILMSG(ZONE_ERROR,(TEXT("SPI: SPIDMAWriteString(): Recieved Timeout for DMA transfer\n")));
	    	bRet = FALSE;
	}

	g_pIOPregs->GPFDAT |= CHIP_DESELECT_nSS1;
//*/
	return bRet;	
}


BOOL SPIDMAReadString(PSPIPHY pSpiPhy, BYTE *pBufOut, DWORD Length)
{
	BOOL bRet=TRUE;
/*
	static  DWORD waitCount = 0;

	g_pIOPregs->GPFDAT &= CHIP_SELECT_nSS1; 

	g_pDMAregs->DISRC3 = (int)(S3C2440A_BASE_REG_PA_SPI+0x34);	
	g_pDMAregs->DISRCC3 = (1<<1)|(1);		 //APB(SPI1), fix
    
	g_pDMAregs->DIDST3 = (int)(g_PhysDMABufferAddr.LowPart);
       g_pDMAregs->DIDSTC3 = (0<<1)|(0);		 //AHB(Memory), inc

	g_pDMAregs->DCON3 = (1<<31)|(0<<30)|(1<<29)|(0<<28)|(0<<27)|(2<<24)|(1<<23)|(1<<22)|(0<<20)|(Length);
	    
       g_pSPIregs->SPCON1 = (2<<5)|(1<<4)|(1<<3)|(0<<2)|(0<<1)|(1<<0);//DMA,en-SCK,master,low,A,TAGD
       g_pSPIregs->SPPIN1  = (0<<2)|(1<<1)|(0<<0);//dis-ENMUL,SBO,release	
	    
	g_pDMAregs->DMASKTRIG3 = (0<<2)|(1<<1)|(0);    //run, DMA3 channel on, no-sw trigger

	// Moving 256 Bytes through SPI using 6.5Mbps takes ~0.5mS, so we wait much longet than that.
	if (WaitForSingleObject(pSpiPhy->DMATxCompleteEvent, 100) == WAIT_OBJECT_0)			
	{
		//int i;
		//MyDelay(10);
		g_pSPIregs->SPCON1=(0<<5)|(1<<4)|(1<<3)|(0<<2)|(0<<1)|(0<<0);   //poll,en-SCK,master,high,A,normal
		*(DMARXBuffer+Length) = g_pSPIregs->SPRDAT1;

		waitCount = 100;
		while(!(g_pSPIregs->SPSTA1 & SPI_TRANSFER_READY))
		{
			    if(--waitCount == 0)
				{
				    RETAILMSG(1, (TEXT("SPI: SPIDMAReadString() - timeout occurred while waiting to transfer byte\r\n")));
	                	    bRet = FALSE;
				    goto READ_ERROR;
				}
		}
		*(DMARXBuffer+Length+1) = g_pSPIregs->SPRDAT1;
		
		memcpy(pBufOut, DMARXBuffer+2, Length);
		DEBUGMSG(ZONE_INFO, (TEXT("SPI: SPIDMAReadString(): DMA transfer ended in time\r\n")));

//		for (i=0; i<256; i++)
//			RETAILMSG(ZONE_ERROR, (TEXT("%02X "), pBufOut[i]));
//		RETAILMSG(ZONE_ERROR, (TEXT("\r\n")));

	}
	else
	{
		RETAILMSG(ZONE_ERROR, (TEXT("SPI: SPIDMAWriteRead(): Recieved Timeout for DMA transfer\r\n")));
		bRet = FALSE;
	}

	g_pIOPregs->GPFDAT |= CHIP_DESELECT_nSS1; 
//*/
READ_ERROR:

	return bRet;
}

BOOL ConfigureSpiHw(PSPIPHY pSpiPhy)
{
/*

	 PBYTE pVirtDMABufferAddr = NULL;
     DMA_ADAPTER_OBJECT Adapter;

// SPI	
    	g_pSPIregs = (volatile S3C2440A_SPI_REG*)VirtualAlloc(0, sizeof(S3C2440A_SPI_REG), MEM_RESERVE, PAGE_NOACCESS);
	if (!g_pSPIregs)
	{
		DEBUGMSG(1, (TEXT("SPIreg: VirtualAlloc failed!\r\n")));
		return(FALSE);
	}
	if (!VirtualCopy((PVOID)g_pSPIregs, (PVOID)(S3C2440A_BASE_REG_PA_SPI >> 8), sizeof(S3C2440A_SPI_REG), PAGE_PHYSICAL | PAGE_READWRITE | PAGE_NOCACHE))
	{
		DEBUGMSG(1, (TEXT("SPIreg: VirtualCopy failed!\r\n")));
		return(FALSE);
	}

//IO
	g_pIOPregs = (volatile S3C2440A_IOPORT_REG*)VirtualAlloc(0, sizeof(S3C2440A_IOPORT_REG), MEM_RESERVE, PAGE_NOACCESS);
	if (!g_pIOPregs)
	{
		DEBUGMSG(1, (TEXT("IOPreg: VirtualAlloc failed!\r\n")));
		return(FALSE);
	}
	if (!VirtualCopy((PVOID)g_pIOPregs, (PVOID)(S3C2440A_BASE_REG_PA_IOPORT >> 8), sizeof(S3C2440A_IOPORT_REG), PAGE_PHYSICAL | PAGE_READWRITE | PAGE_NOCACHE))
	{
		DEBUGMSG(1, (TEXT("IOPreg: VirtualCopy failed!\r\n")));
		return(FALSE);
	}
// CLK
	g_pCLKPWRreg = (volatile S3C2440A_CLKPWR_REG*)VirtualAlloc(0, sizeof(S3C2440A_CLKPWR_REG), MEM_RESERVE, PAGE_NOACCESS);
	if (!g_pCLKPWRreg)
	{
		DEBUGMSG(1, (TEXT("DMAreg: VirtualAlloc failed!\r\n")));
		return(FALSE);
	}
	if (!VirtualCopy((PVOID)g_pCLKPWRreg, (PVOID)(S3C2440A_BASE_REG_PA_CLOCK_POWER >> 8), sizeof(S3C2440A_CLKPWR_REG), PAGE_PHYSICAL | PAGE_READWRITE | PAGE_NOCACHE))
	{
		DEBUGMSG(1, (TEXT("DMAreg: VirtualCopy failed!\r\n")));
		return(FALSE);
	}	
// DMA
	g_pDMAregs = (volatile S3C2440A_DMA_REG*)VirtualAlloc(0, sizeof(S3C2440A_DMA_REG), MEM_RESERVE, PAGE_NOACCESS);
	if (!g_pDMAregs)
	{
		DEBUGMSG(1, (TEXT("DMAreg: VirtualAlloc failed!\r\n")));
		return(FALSE);
	}
	if (!VirtualCopy((PVOID)g_pDMAregs, (PVOID)(S3C2440A_BASE_REG_PA_DMA >> 8), sizeof(S3C2440A_DMA_REG), PAGE_PHYSICAL | PAGE_READWRITE | PAGE_NOCACHE))
	{
		DEBUGMSG(1, (TEXT("DMAreg: VirtualCopy failed!\r\n")));
		return(FALSE);
	}	
// INT
	s2440INT = (volatile S3C2440A_INTR_REG*)VirtualAlloc(0, sizeof(S3C2440A_INTR_REG), MEM_RESERVE, PAGE_NOACCESS);
	if (!s2440INT)
	{
		DEBUGMSG(1, (TEXT("INTreg: VirtualAlloc failed!\r\n")));
		return(FALSE);
	}
	if (!VirtualCopy((PVOID)s2440INT, (PVOID)(S3C2440A_BASE_REG_PA_INTR >> 8), sizeof(S3C2440A_INTR_REG), PAGE_PHYSICAL | PAGE_READWRITE | PAGE_NOCACHE))
	{
		DEBUGMSG(1, (TEXT("INTreg: VirtualCopy failed!\r\n")));
		return(FALSE);
	}
// DMA BUFFER
   	memset(&Adapter, 0, sizeof(DMA_ADAPTER_OBJECT));
	Adapter.InterfaceType = Internal;
	Adapter.ObjectSize = sizeof(DMA_ADAPTER_OBJECT);

	// Allocate a block of virtual memory (physically contiguous) for the DMA buffers.
	pVirtDMABufferAddr = (PBYTE)HalAllocateCommonBuffer(&Adapter, 320+40960, &g_PhysDMABufferAddr, FALSE);
       if (pVirtDMABufferAddr == NULL)
       {
           RETAILMSG(TRUE, (TEXT("WAVEDEV.DLL:HardwareContext::MapDMABuffers() - Failed to allocate DMA buffer.\r\n")));
           return(FALSE);
       }

       DMARXBuffer = pVirtDMABufferAddr;
       DMATXBuffer = pVirtDMABufferAddr + 320;
//*/
	SetupSPI(pSpiPhy);

	return TRUE;
} 

VOID UnConfigureSpiHw(PSPIPHY pSpiPhy)
{

	//Unconfiguring all the SPI protocol...
	UnSetupSPI(pSpiPhy);
/*
	//unmapping all physical addresses used to access register....
	VirtualFree((PVOID)g_pSPIregs, 0, MEM_RELEASE);
	VirtualFree((PVOID)g_pIOPregs, 0, MEM_RELEASE);
	VirtualFree((PVOID)g_pCLKPWRreg, 0, MEM_RELEASE);
	VirtualFree((PVOID)g_pDMAregs, 0, MEM_RELEASE);
	VirtualFree((PVOID)s2440INT, 0, MEM_RELEASE);

	if(DMARXBuffer)
	{
		VirtualFree((PVOID)DMARXBuffer, 0, MEM_RELEASE);
	}
//*/
}

void SMS1010_Reset_Low(void)
{
#if defined(_TCC79x_)
//	g_pIOPregs->GPBDAT &= ~0x4;
	BITCLR(HwPORTCFG7, Hw12-Hw8);	// DXB1_CHW1=GPIOA6 
	BITSET(HwGPAEN , Hw6);
	BITCLR(HwGPADAT, Hw6);

#elif defined(_TCC80x_)
	BITCLR(HwGPIOPK_FS0, Hw12);
	BITSET(HwGPIOPK_DOE, Hw12);
	BITCLR(HwGPIOPK_DAT, Hw12);

#elif defined(_TCC89x_)
    // GPIO_D12
    PGPION pGPIOD=(PGPION)tcc_allocbaseaddress((unsigned int)&HwGPIOD_BASE);
    BITCLR(pGPIOD->GPFN1, Hw20-Hw16);
    BITSET(pGPIOD->GPEN, Hw12);
    BITCLR(pGPIOD->GPDAT, Hw12);
    //tcc_freebaseaddress((unsigned int)pGPIOD, sizeof(GPION));

#endif
}

void SMS1010_Reset_High(void)
{
#if defined(_TCC79x_)
//	g_pIOPregs->GPBDAT |= 0x4;
	BITCLR(HwPORTCFG7, Hw12-Hw8);	// DXB1_CHW1=GPIOA6 
	BITSET(HwGPAEN , Hw6);
	BITSET(HwGPADAT, Hw6);

#elif defined(_TCC80x_)
	BITCLR(HwGPIOPK_FS0, Hw12);
	BITSET(HwGPIOPK_DOE, Hw12);
	BITSET(HwGPIOPK_DAT, Hw12);

#elif defined(_TCC89x_)
    // GPIO_D12
    PGPION pGPIOD=(PGPION)tcc_allocbaseaddress((unsigned int)&HwGPIOD_BASE);
    BITCLR(pGPIOD->GPFN1, Hw20-Hw16);
    BITSET(pGPIOD->GPEN, Hw12);
    BITSET(pGPIOD->GPDAT, Hw12);
    //tcc_freebaseaddress((unsigned int)pGPIOD, sizeof(GPION));

#endif
}
void SMS1010_Reset(void)
{
#if defined(_TCC79x_)
//	g_pIOPregs->GPBDAT |= 0x4;   // Reset Siano
//	MyDelay(20);
//	g_pIOPregs->GPBDAT &= ~0x4;
//	MyDelay(20);
//	g_pIOPregs->GPBDAT |= 0x4;
	BITCLR(HwPORTCFG7, Hw12-Hw8);	// DXB1_CHW1=GPIOA6 
	BITSET(HwGPAEN , Hw6);
	BITCLR(HwGPADAT, Hw6);
	Sleep(250);
	BITSET(HwGPADAT, Hw6);

#elif defined(_TCC80x_)
	BITCLR(HwGPIOPK_FS0, Hw12);
	BITSET(HwGPIOPK_DOE, Hw12);

	BITCLR(HwGPIOPK_DAT, Hw12);
	Sleep(250);
	BITSET(HwGPIOPK_DAT, Hw12);

#elif defined(_TCC89x_)
    // GPIO_D12
    PGPION pGPIOD=(PGPION)tcc_allocbaseaddress((unsigned int)&HwGPIOD_BASE);
    
    BITCLR(pGPIOD->GPFN1, Hw20-Hw16);
    BITSET(pGPIOD->GPEN, Hw12);

    BITCLR(pGPIOD->GPDAT, Hw12);
    Sleep(250);
    BITSET(pGPIOD->GPDAT, Hw12);

    //tcc_freebaseaddress((unsigned int)pGPIOD, sizeof(GPION));

#endif
}

void SMS1010_PowerUp(void)
{
#if defined(_TCC79x_)
//	g_pIOPregs->GPBDAT |= 0x10;   // PU
	BITCLR(HwPORTCFG8, Hw28-Hw24);	// DXB1_PWDN=GPIOA10 high
	BITSET(HwGPAEN , Hw10);
	BITSET(HwGPADAT, Hw10);	
#elif defined(_TCC80x_)
	// s 23
	BITCLR(HwGPIOPS_FS0, Hw23);
	BITSET(HwGPIOPS_DOE, Hw23);
	BITSET(HwGPIOPS_DAT, Hw23);

#elif defined(_TCC89x_)
    {
        HANDLE hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
        if( INVALID_HANDLE_VALUE!=hGXP )
        {
            DWORD dwByteReturned;

            GXPINFO GxpInfo;
            GxpInfo.uiDevice=PCA9539LOW;
            GxpInfo.uiPort=DXB;
            GxpInfo.uiState=ON;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: DXB Power On\r\n")));
            }

            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
        }
    }
    {
        // GPIO_E3
        PGPION pGPIOE=(PGPION)tcc_allocbaseaddress((unsigned int)&HwGPIOE_BASE);
        BITCLR(pGPIOE->GPFN0, Hw16-Hw12);
        BITSET(pGPIOE->GPEN, Hw3);
        BITSET(pGPIOE->GPDAT, Hw3);
        //tcc_freebaseaddress((unsigned int)pGPIOE, sizeof(GPION));
		
    }

#endif
}

void SMS1010_PowerDown(void)
{
#if defined(_TCC79x_)
	BITCLR(HwPORTCFG8, Hw28-Hw24);	// DXB1_PWDN=GPIOA10 low
	BITSET(HwGPAEN , Hw10);
	BITCLR(HwGPADAT, Hw10);	

//	g_pIOPregs->GPBDAT &= ~0x10;   // PD 
#if 0	
	RETAILMSG(1, (TEXT("--->>> GPBDAT = %08x   GPBCON = %08x   GPBDN = %08x\n"),g_pIOPregs->GPBDAT, g_pIOPregs->GPBCON, g_pIOPregs->GPBDN));
#endif

#elif defined(_TCC80x_)
	BITCLR(HwGPIOPS_FS0, Hw23);
	BITSET(HwGPIOPS_DOE, Hw23);
	BITCLR(HwGPIOPS_DAT, Hw23);

#elif defined(_TCC89x_)
    // GPIO_E3
    PGPION pGPIOE=(PGPION)tcc_allocbaseaddress((unsigned int)&HwGPIOE_BASE);
    BITCLR(pGPIOE->GPFN0, Hw16-Hw12);
    BITSET(pGPIOE->GPEN, Hw3);
    BITCLR(pGPIOE->GPDAT, Hw3);
    //tcc_freebaseaddress((unsigned int)pGPIOE, sizeof(GPION));

    {
        HANDLE hGXP=CreateFile(L"GXP1:", GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH, NULL);
        if( INVALID_HANDLE_VALUE!=hGXP )
        {
            DWORD dwByteReturned;

            GXPINFO GxpInfo;
            GxpInfo.uiDevice=PCA9539LOW;
            GxpInfo.uiPort=DXB;
            GxpInfo.uiState=OFF;

            if( FALSE==WriteFile(hGXP, &GxpInfo, sizeof(GxpInfo), &dwByteReturned, NULL) )
            {
                RETAILMSG(1,(TEXT("ERROR: DXB Power On\r\n")));
            }

            CloseHandle(hGXP);
        }
        else
        {
            RETAILMSG(1,(TEXT("ERROR: Driver: Can't open GXP Driver!!\n")));
        }
    }
#endif
}

////////////////////////////   Internal fucntions /////////////////////////////////

void SetupSPI(PSPIPHY pSpiPhy)
{
#if defined(_TCC79x_)
	stCKCIOCTL  stCKC;
	stCKCINFO	stCKCInfo;
	unsigned long	returnedbyte;
	InitializeCriticalSection(&SPI_Section);

	BITCLR(HwPORTCFG7, Hw28-Hw24);	// SFRM=GPIOD9
	BITCLR(HwPORTCFG7, Hw24-Hw20);	// SCLK=GPIOD10
	BITCLR(HwPORTCFG7, Hw20-Hw16);	// SDI=GPIOD11
	BITCLR(HwPORTCFG7, Hw16-Hw12);	// SDO=GPIOD12
	BITCSET(HwCPUD5,HwCPUD5_SCMD1(3)|HwCPUD5_SCLK1(3)|HwCPUD5_SDI1(3)|HwCPUD5_SDO1(3),
		HwCPUD5_SCMD1(1)|HwCPUD5_SCLK1(1)|HwCPUD5_SDI1(1)|HwCPUD5_SDO1(1));

//	HwPCK_GPSB1 = 0x14000000;
//*

	stCKC.ControlCode = IOCTL_CKC_SET_PERICLOCK;
	stCKC.PeriClockName = PERI_GPSB1;
	stCKC.PeriClockSource = DIRECTPLL0;
	stCKC.PeriUnit = MHz;
	stCKC.PeriFreq = 30;

	KernelIoControl(IOCTL_HAL_TCCCKC,
                        &stCKC,
                        sizeof(stCKCIOCTL),
                        &stCKCInfo,
                        sizeof(stCKCINFO),
                        &returnedbyte);
//*/

	BITSET(HwBCLKCTR, HwBCLKCTR_GPSB1_ON); 	 
	BITSET(HwSWRESET, Hw18);
	Sleep(1);
	BITCLR(HwSWRESET, Hw18);		 
	
	//SPI config
	HwGPSB_CH1MODE = (7<<8);
		 
	//SPI control
	HwGPSB_CH1MODE |= HwGPSB_CH1MODE_EN;
	HwGPSB_PCFG |= Hw10|Hw8; //channel 1 using port 5


	BITCLR(HwPORTCFG7, Hw12-Hw8);	// DXB1_CHW1=GPIOA6 high
	BITCLR(HwPORTCFG8, Hw28-Hw24);	// DXB1_PWDN=GPIOA10 high
	BITSET(HwGPAEN , Hw6|Hw10);
	BITSET(HwGPADAT, Hw6);
	BITSET(HwGPADAT, Hw10);	


	BITCLR(HwPORTCFG7, HwPORTCFG7_GPIOA6(15));	// DXB1_CHW1=GPIOA6 reset
	BITSET(HwGPAEN , Hw6);	
	BITCLR(HwGPADAT, Hw6);
	Sleep(300);	
	BITSET(HwGPADAT, Hw6);
	Sleep(500);

#elif defined(_TCC80x_)
    ghSPI=CreateFile(TEXT("SPI0:"), GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if( INVALID_HANDLE_VALUE==ghSPI )
    {
        printf("INVALID_HANDLE_VALUE==ghSPI");
    }
    else
    {
		//SET SPI using IOCTL
		BOOL ret;
		spi_param_t p_param;
		int loopback;
		DWORD ret_byte;

		p_param.CPL=0;
		p_param.CPH=1;
		p_param.MLB=1;
		p_param.END=1;
		p_param.FP=0;
		p_param.Mhz=30;
		ret=DeviceIoControl(ghSPI, IOCTL_SPI_SETUP, &p_param, sizeof(spi_param_t), 0, 0, &ret_byte, 0);

		loopback=1;
		ret=DeviceIoControl(ghSPI, IOCTL_SPI_LOOPBACK, &loopback, sizeof(int), 0, 0, &ret_byte, 0);

        printf("SPI OK\r\n");
    }
	
	BITCLR(HwGPIOPK_FS0, Hw12);
	BITCLR(HwGPIOPS_FS0, Hw23);

	BITSET(HwGPIOPK_DOE, Hw12);
	BITSET(HwGPIOPS_DOE, Hw23);

	BITSET(HwGPIOPK_DAT, Hw12);
	BITSET(HwGPIOPS_DAT, Hw23);


	BITCLR(HwGPIOPK_FS0, Hw12);
	BITSET(HwGPIOPK_DOE, Hw12);

	BITCLR(HwGPIOPK_DAT, Hw12);
	Sleep(300);
	BITSET(HwGPIOPK_DAT, Hw12);
	Sleep(500);

#elif defined(_TCC89x_)
    ghSPI=CreateFile(TEXT("SPI1:"), GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if( INVALID_HANDLE_VALUE==ghSPI )
    {
        printf("INVALID_HANDLE_VALUE==ghSPI");
    }
    else
    {
		//SET SPI using IOCTL
		BOOL ret;
		spi_param_t p_param;
		int loopback;
		DWORD ret_byte;

		p_param.CPL=0;
		p_param.CPH=0;
		p_param.LSB=0;
		p_param.FP=0;
		p_param.Mhz=20;
		ret=DeviceIoControl(ghSPI, IOCTL_SPI_SETUP, &p_param, sizeof(spi_param_t), 0, 0, &ret_byte, 0);

		loopback=1;
		ret=DeviceIoControl(ghSPI, IOCTL_SPI_LOOPBACK, &loopback, sizeof(int), 0, 0, &ret_byte, 0);

        printf("[TCC89]SPI OK\r\n");
    }

    SMS1010_PowerUp();
    SMS1010_Reset();

#endif
}

void UnSetupSPI(PSPIPHY pSpiPhy)
{
/*
	g_pSPIregs->SPCON1=(0<<5)|(0<<4)|(1<<3)|(0<<2)|(0<<1)|(0<<0);//Polling,dis-SCK,master,low,A,normal
	//disable the hardware interrupt and to deregister the event
	InterruptDisable(pSpiPhy->spiSysIntr);   // EINT3
#ifdef USESPIDMA
    	InterruptDisable(pSpiPhy->spiSysIntrDMA3);   // SPI0 DMA
#endif
//*/
	DeleteCriticalSection(&SPI_Section);
	///BITCLR(HwIEN, HwINT_EI3);
	///BITCLR(HwCLR, HwINT_EI3);  
}

#if 0	
//writing to SPI device
static void SSPWriteDWord(PSPIPHY pSpiPhy,DWORD dwVal)
{
	
	DWORD sb;	
	sb = SWAP32(dwVal);
	pSpiPhy->sspCtrl->ssdr = sb;	
}

//reading from SPI device
static DWORD SSPReadDWord(PSPIPHY pSpiPhy)
{
	DWORD sb;	
	DWORD v = pSpiPhy->sspCtrl->ssdr;
	sb = SWAP32(v);
	return sb;
}

//write and read to/from SPI device
static DWORD ReadWriteDWord(PSPIPHY pSpiPhy,DWORD dwInVal)
{
	DWORD dwRetVal;
	DWORD timeout;
	
	timeout = POLLING_TIMEOUT;	
	//Loop while there is any data in the fifo
	while(!(pSpiPhy->sspCtrl->ssr & SSSR_TNF) && timeout--);
	if (timeout == -1)
		return 0;
	SSPWriteDWord(pSpiPhy,dwInVal);
	
	timeout = POLLING_TIMEOUT;
	while(!(pSpiPhy->sspCtrl->ssr & SSSR_RNE) && timeout--);
	if (timeout == -1)
		return 0;
	dwRetVal = SSPReadDWord(pSpiPhy);
	return dwRetVal;
}


static void endOfDmaTransfer(DWORD	transactionId, DWORD status)
{
	DBGMSG( ZONE_INFO,(TEXT("SmsSpi:  DMA transaction end.\r\n")));
	SetEvent((HANDLE)transactionId);
}
#endif

static BOOL spiPhyGetRegistrySettings(PVOID Context, PSPIPHY pSpiPhy )
{
	TCHAR*	regKey;
	BOOL	st;
	HKEY	hKey;
	DWORD	dataSize, type;
	regKey = (TCHAR *)LocalAlloc (LPTR, MAX_REG_KEY_SIZE);
	if (regKey == NULL)
	{
		DBGMSG( ZONE_ERROR,(TEXT("Siano SPI - ERROR!! Allocating memory for registry reading failed.\r\n")));
		return FALSE;
	}


	st = RegOpenKeyEx(HKEY_LOCAL_MACHINE, (LPCWSTR)Context, 0, 0, &hKey);						
	if(st != ERROR_SUCCESS)
	{
		DBGMSG( ZONE_ERROR,(TEXT("Siano SPI - ERROR!! Could not open registry key.\r\n")));
		LocalFree(regKey);
		return (FALSE);
	}

	dataSize=MAX_REG_KEY_SIZE;
	st = RegQueryValueEx(	hKey, 
							TEXT("Key"), 
							NULL,
							&type, 
							(LPBYTE)regKey, 
							&dataSize);
	
	RegCloseKey(hKey);
	if(st!=ERROR_SUCCESS)	
	{
		DBGMSG( ZONE_ERROR,(TEXT("Siano SPI - ERROR!! Could not get registry key name.\r\n")));
		LocalFree(regKey);
		return (FALSE);
	}
	
	// Now - read all the needed parameters for the driver from the registry.


	st = RegOpenKeyEx(HKEY_LOCAL_MACHINE, regKey, 0, 0, &hKey);
	if(st != ERROR_SUCCESS)
	{
		DBGMSG( ZONE_ERROR,(TEXT("Siano SPI - ERROR!! Could not open registry key.\r\n")));
		LocalFree(regKey);
		return (FALSE);
	}

#if 0
	dataSize=MAX_REG_PATH_SIZE;
	st = RegQueryValueEx( hKey, 
						  L"DmaServicesPlugin", 
						  0, 
						  &type, 
						  (LPBYTE)&pSpiPhy->DmaDllName, 
						  &dataSize);
	if(st != ERROR_SUCCESS)
	{ //Set default value if registry entry is not found.
		pSpiPhy->DmaDllName[0] = 0;
	}
	
	dataSize = sizeof(pSpiPhy->useSSPPort);
	st = RegQueryValueEx( hKey, 
					  L"useSSPPort", 
					  0, 
					  &type, 
					  (LPBYTE)&pSpiPhy->useSSPPort, 
					  &dataSize);

	if(st != ERROR_SUCCESS)
	{ //Set default value if registry entry is not found.
		pSpiPhy->useSSPPort = 1;
	}

	dataSize = sizeof(pSpiPhy->spiSysIntr);
	st = RegQueryValueEx( hKey, 
					  L"useSysIntr", 
					  0, 
					  &type, 
					  (LPBYTE)&pSpiPhy->spiSysIntr, 
					  &dataSize);

	if(st != ERROR_SUCCESS)
	{ //Set default value if registry entry is not found.
		pSpiPhy->spiSysIntr = 34;
	}
	if (pSpiPhy->spiSysIntr == 0xffff)
	{
		DWORD Irq_GpioXX_2;
		Irq_GpioXX_2 = DEFAULT_IRQ_GPIOXX_2;//consonance irq number
		DBGMSG( ZONE_INFO,(TEXT("Irq Number = %d!!!\r\n"),DEFAULT_IRQ_GPIOXX_2));
		if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &Irq_GpioXX_2, sizeof(DWORD), &pSpiPhy->spiSysIntr, sizeof(DWORD), NULL))
		{
			DBGMSG( ZONE_INFO, (TEXT("SPI : IOCTL_HAL_REQUEST_SYSINTR failed (x%08x)\r\n"), GetLastError()));
		}
		else
		{
			DBGMSG( ZONE_INFO, (TEXT("SPI : IOCTL_HAL_REQUEST_SYSINTR Succeded SysIntr %d\r\n"), pSpiPhy->spiSysIntr));
		}
	}


	dataSize = sizeof(pSpiPhy->novaDevice);
	st = RegQueryValueEx( hKey, 
					  L"novaDevice", 
					  0, 
					  &type, 
					  (LPBYTE)&pSpiPhy->novaDevice, 
					  &dataSize);

	if(st != ERROR_SUCCESS)
	{ //Set default value if registry entry is not found.
		pSpiPhy->novaDevice = FALSE;
	}
	
	dataSize = sizeof(pSpiPhy->novaIntrPin);
	st = RegQueryValueEx( hKey, 
					  L"novaIntrPin", 
					  0, 
					  &type, 
					  (LPBYTE)&pSpiPhy->novaIntrPin, 
					  &dataSize);

	if(st != ERROR_SUCCESS)
	{ //Set default value if registry entry is not found.
		pSpiPhy->novaIntrPin = 16;
	}
#endif
	
	st = RegCloseKey(hKey);
	if(st!=ERROR_SUCCESS)	
	{
		DBGMSG( ZONE_ERROR,(TEXT("Siano SPI - ERROR!! Could not get registry key name.\r\n")));
		LocalFree(regKey);
		return (FALSE);
	}

	LocalFree(regKey);
	return (TRUE);

}


#if 0
static BOOL	activateDMAService(PSPIPHY pSpiPhy)
{
	DMA_INIT_PARAMS_ST dmaSetUp;
	
	if (pSpiPhy->DmaDllName[0] == 0)
	{
		DBGMSG(ZONE_INIT | ZONE_ERROR, (TEXT("SmsSpi: activateDMAService() There is no DMA service name.\r\n")));
		return FALSE;
	}
	
	pSpiPhy->dmaService = (DEVICE_DMA_SERVICE_ST*)LocalAlloc(LPTR, sizeof(DEVICE_DMA_SERVICE_ST));
	if (pSpiPhy->dmaService == NULL)
	{
		DBGMSG(ZONE_INIT | ZONE_ERROR, (TEXT("SmsSpi: activateDMAService() Could not allocate DMA service structure.\r\n")));
		return FALSE;
	}
	
	pSpiPhy->dmaService->hdl = LoadLibrary((LPCWSTR)pSpiPhy->DmaDllName);
	if (pSpiPhy->dmaService->hdl == NULL)
	{
		DBGMSG(ZONE_INIT | ZONE_ERROR, (TEXT("SmsSpi: activateDMAService() Could not load DMA service library.\r\n")));
		LocalFree(pSpiPhy->dmaService);
		pSpiPhy->dmaService = NULL;
		return FALSE;
	}

	pSpiPhy->dmaService->dmaSetUpChannel = (DMA_SetUpChannelF)GetProcAddress(pSpiPhy->dmaService->hdl, TEXT("DMA_SetUpChannel"));
	pSpiPhy->dmaService->dmaConfigChannel = (DMA_ConfigChannelF)GetProcAddress(pSpiPhy->dmaService->hdl, TEXT("DMA_ConfigChannel"));
	pSpiPhy->dmaService->dmaRemoveChannel = (DMA_RemoveChannelF)GetProcAddress(pSpiPhy->dmaService->hdl, TEXT("DMA_RemoveChannel"));
	if (pSpiPhy->dmaService->dmaSetUpChannel == NULL ||
		pSpiPhy->dmaService->dmaConfigChannel == NULL ||
		pSpiPhy->dmaService->dmaRemoveChannel == NULL)
	{
		DBGMSG(ZONE_INIT | ZONE_ERROR, (TEXT("SmsSpi: activateDMAService() Could not find DMA library routines.\r\n")));
		FreeLibrary(pSpiPhy->dmaService->hdl);
		LocalFree(pSpiPhy->dmaService);
		pSpiPhy->dmaService = NULL;
		return FALSE;
	}


	dmaSetUp.flags = DMA_USE_HW_FLOW_CTRL;
	if (pSpiPhy->useSSPPort == 1)	
		dmaSetUp.dmaReq = SSP1_TX_CMR;
	else if (pSpiPhy->useSSPPort == 2)	
		dmaSetUp.dmaReq = SSP2_TX_CMR;
    else if (pSpiPhy->useSSPPort == 3)	
        dmaSetUp.dmaReq = SSP3_TX_CMR;
    else if (pSpiPhy->useSSPPort == 4)	
        dmaSetUp.dmaReq = SSP4_TX_CMR;
	dmaSetUp.burstSize = DMA_BURST_8_BYTES;
	dmaSetUp.busWidth = DMA_BUS_WIDTH_4_BYTE;
	pSpiPhy->dmaService->txDmaDevice=pSpiPhy->dmaService->dmaSetUpChannel(&dmaSetUp);

	dmaSetUp.flags = DMA_USE_HW_FLOW_CTRL;
    if (pSpiPhy->useSSPPort == 1)	
        dmaSetUp.dmaReq = SSP1_RX_CMR;
    else if (pSpiPhy->useSSPPort == 2)	
        dmaSetUp.dmaReq = SSP2_RX_CMR;
    else if (pSpiPhy->useSSPPort == 3)	
        dmaSetUp.dmaReq = SSP3_RX_CMR;
    else if (pSpiPhy->useSSPPort == 4)	
        dmaSetUp.dmaReq = SSP4_RX_CMR;
	dmaSetUp.burstSize = DMA_BURST_8_BYTES;
	dmaSetUp.busWidth = DMA_BUS_WIDTH_4_BYTE;
	pSpiPhy->dmaService->rxDmaDevice=pSpiPhy->dmaService->dmaSetUpChannel(&dmaSetUp);
	return TRUE;
}


static BOOL	deactivateDMAService(PSPIPHY pSpiPhy)
{
	if (pSpiPhy->dmaService != NULL)
	{
		if (pSpiPhy->dmaService->rxDmaDevice)
			pSpiPhy->dmaService->dmaRemoveChannel(pSpiPhy->dmaService->rxDmaDevice);
		if (pSpiPhy->dmaService->txDmaDevice)
			pSpiPhy->dmaService->dmaRemoveChannel(pSpiPhy->dmaService->txDmaDevice);
		if (pSpiPhy->dmaService->hdl)
			FreeLibrary(pSpiPhy->dmaService->hdl);
		LocalFree(pSpiPhy->dmaService);
		pSpiPhy->dmaService = NULL;
	}
	return TRUE;
}
#endif

VOID SpiRxIST(PVOID pArg)
{
	PSPIPHY pSpiPhy = (PSPIPHY)pArg;

	pSpiPhy->RxInterruptCnt = 0;
	while (1)
	{
		WaitForSingleObject(pSpiPhy->SmsInterruptEvent, INFINITE);
		if (pSpiPhy->drvActive == FALSE)
		{
			return;
		}
		pSpiPhy->RxInterruptCnt++;
		if (pSpiPhy->RxInterruptCnt==30)
			;//TranferMsgQueueTimeOutMode = 1;

		if (pSpiPhy->InterruptCallback)
			pSpiPhy->InterruptCallback(pSpiPhy->intrContext);//
		
		InterruptDone(pSpiPhy->spiSysIntr);
	}
}

/*
VOID SPIDMAInterruptThread(PVOID pArg)
{
	PSPIPHY pSpiPhy = (PSPIPHY)pArg;
	while(TRUE)
	{
		WaitForSingleObject(pSpiPhy->SmsSPIDMAInterruptEvent, INFINITE);
		if (s2440INT->INTMSK & (1 << IRQ_DMA3))   // ???
		{
			InterruptDone(pSpiPhy->spiSysIntrDMA3);
			SetEvent(pSpiPhy->DMATxCompleteEvent);
		}		
	}
}
//*/
////////////////////////////   Internal fucntions /////////////////////////////////


/*************************************************************************************
FUNCTION NAME:	WriteFW

DESCRIPTION:	the actual writing to the firmwere
*************************************************************************************/


VOID WriteFWtoStellar(PSPIPHY pSpiPhy,BYTE* pFW,DWORD Len)
{
	DBGMSG(ZONE_INFO, (TEXT("SmsSpi: WriteFW :Len %d bytes\r\n"),Len));
#ifdef FWUSESPIDMA   // USESPIDMA
       SPIDMAWriteString(pSpiPhy, pFW, Len);
#else
	SPIWriteString(pFW, Len);
#endif
	Sleep(100);
#if 0
	DWORD Padding;
	DWORD Cnt = 0;
	DWORD *pPos = (DWORD*)pFW;
	int LeftOver;

	//Data Must be sent in 256 Bytes chuncks --- CHANGED: Pre DMA init in Siano device, pass the exact file size.
	Padding = Len%MIN_BUFF_PARTITION;
	if(Padding)
		Padding = MIN_BUFF_PARTITION - Padding;//to complete to 256;
	DBGMSG( ZONE_INFO, (TEXT("SmsSpi: WriteFW :Len %d bytes Padding %d Bytes\r\n"),Len,Padding));

	//1st Phaze
	DBGMSG( ZONE_INFO, (TEXT("SmsSpi: WriteFW :Entering Phaze 1\r\n")));
	while((Cnt+FW_STEP)<=Len)
	{
		//actual Device Writing
		//no need checking the data received from the device
			
		DWORD ret = ReadWriteDWord(pSpiPhy,*pPos);
		//DBGMSG( ZONE_INFO,(TEXT("r:0x%x\r\n"),dwval));
		//Change Stats
		Cnt+=fwmin(FW_STEP,Len-Cnt);
		pPos++;//+4

	}

	//2nd Phaze
	//Check if we have left over data we didn't send
	DBGMSG( ZONE_INFO, (TEXT("SPI!WriteFW :Entering Phaze 2\r\n")));
	LeftOver = (Len - Cnt);
	DBGMSG( ZONE_INFO, (TEXT("SPI!WriteFW :LeftOver Data Len %d Bytes\r\n"),LeftOver));
	if (LeftOver>0)
	{
		DWORD dwval;
		pPos = (DWORD*)(pFW+Cnt);
		dwval= ReadWriteDWord(pSpiPhy,*pPos);
	}
	Sleep(100);
#endif
}

void prepareForFWDnl(void* context)
{

#if 0
	unsigned char buff1[8]={0x00,0x00,0xde,0xc1,0xa5,0x51,0xf1,0xed};
//	unsigned char buff2[4]={0xa5,0x51,0xf1,0xed};
	unsigned char buff3[248] ={0};

	SPIWriteString(buff1,8);

#else

	PDWORD msgBuf;
	SmsMsgData_ST		*setIntMsg;
	SmsMsgData_ST		*setWidth;
	DWORD i;
	PSPIPHY pSpiPhy = (PSPIPHY)context;
	unsigned char buff1[8]={0x00,0x00,0xde,0xc1,0xa5,0x51,0xf1,0xed};
//	unsigned char buff2[4]={0xa5,0x51,0xf1,0xed};
	unsigned char buff3[248] ={0};

	SPIWriteString(buff1,8);

	msgBuf = LocalAlloc(LPTR, SPI_PACKET_SIZE);
	msgBuf[0] = SPI_COMMAND_PREAMBLE;

	setIntMsg = (SmsMsgData_ST*)&msgBuf[1];
	setIntMsg->xMsgHeader.msgType = MSG_SMS_SPI_INT_LINE_SET_REQ;
	setIntMsg->xMsgHeader.msgDstId = 11;			// to MSGPROC_TASK
	setIntMsg->xMsgHeader.msgSrcId = 35;//WM_DRIVER;			// to MSGPROC_TASK
	setIntMsg->xMsgHeader.msgFlags = 0;
	setIntMsg->xMsgHeader.msgLength = sizeof(SmsMsgHdr_ST) + 3 * sizeof(UINT32);
	setIntMsg->msgData[0] = 0;				// Main Spi Controller (0) 
	setIntMsg->msgData[1] = _CMMB_SIANO_INT_PIN_;				// Interrupt GPIO.
	setIntMsg->msgData[2] = 20;				// Default pulse width.
	for (i = 0; i < (SPI_PACKET_SIZE/ sizeof(DWORD)); i++) //SPI_PACKET_SIZE
	{
		DWORD ret = SPIWriteString(msgBuf+i,4);//ReadWriteDWord(pSpiPhy,msgBuf[i]);
	}
	Sleep(50);
	LocalFree(msgBuf);
	
#endif

	
}

void fwDnlComplete(void* context, BD_APP_TYPE_E App)
{
#if 0
	PDWORD msgBuf;
	SmsMsgData_ST		*setIntMsg;
	SmsMsgData_ST		*setWidth;
	DWORD i;
	PSPIPHY pSpiPhy = (PSPIPHY)context;

	msgBuf = LocalAlloc(LPTR, SPI_PACKET_SIZE);
	msgBuf[0] = SPI_COMMAND_PREAMBLE;

	setIntMsg = (SmsMsgData_ST*)&msgBuf[1];
	setIntMsg->xMsgHeader.msgType = MSG_SMS_SPI_INT_LINE_SET_REQ;
	setIntMsg->xMsgHeader.msgDstId = 11;			// to MSGPROC_TASK
	setIntMsg->xMsgHeader.msgSrcId = 35;//WM_DRIVER;			// to MSGPROC_TASK
	setIntMsg->xMsgHeader.msgFlags = 0;
	setIntMsg->xMsgHeader.msgLength = sizeof(SmsMsgHdr_ST) + 3 * sizeof(UINT32);
	setIntMsg->msgData[0] = 0;				// Main Spi Controller (0) 
	setIntMsg->msgData[1] = 26;				// Interrupt GPIO.
	setIntMsg->msgData[2] = 20;				// Default pulse width.
	for (i = 0; i < (SPI_PACKET_SIZE / sizeof(DWORD)); i++)
	{
		DWORD ret = SPIWriteString(msgBuf,4);//ReadWriteDWord(pSpiPhy,msgBuf[i]);
	}
	Sleep(50);
	LocalFree(msgBuf);	
#endif
}

void smsspibus_xfer(void* context, 
				   unsigned char * txbuf, unsigned long txbuf_phy_addr, 
				   unsigned char* rxbuf, unsigned long rxbuf_phy_addr, 
				   int len)
{
	PSPIPHY pSpiPhy = (PSPIPHY)context;
	unsigned char buffer[4096];
	memset(buffer,0xff,4096);
//	DWORD timeout;
//	DWORD* pdw;
	if (txbuf)
	{
		DBGMSG( ZONE_INFO, (TEXT("transfer buf starting with: 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x.\r\n"), txbuf[0], 
		txbuf[1], txbuf[2], txbuf[3], txbuf[4], txbuf[5], txbuf[6], txbuf[7]));
	}
	

#ifdef USESPIDMA
	if (txbuf)
	{
//		RETAILMSG(1, (TEXT("### %02X ### "), txbuf[0]));
		SPIWriteReadString(txbuf, rxbuf, len);
	}
	else
		SPIDMAReadString(pSpiPhy, rxbuf, len);
#else
	if (txbuf)
		SPIWriteReadString(txbuf, rxbuf, len);
	else
	{
		SPIWriteReadString(buffer, rxbuf, len);
		
	}
#endif

#if 0
	if (pSpiPhy->dmaService == NULL)
	{ //No DMA service - copy using CPU
		//Loop as long as the TX packet has not been completly trasmitterd, or 
		//until the RX FIFO is emty
		DBGMSG( ZONE_DETAILED, (TEXT("transfer %d bytes without DMA.\r\n"), len));
		pdw = (DWORD*)rxbuf;
		while(len > 0)
		{
			//Loop while there is any data in the fifo
			while(!(pSpiPhy->sspCtrl->ssr & SSSR_TNF));
			if(txbuf)
			{
				DWORD sb = *((DWORD*)txbuf);
				SSPWriteDWord(pSpiPhy,sb);
				txbuf+=4;
			}
			else
			{
				SSPWriteDWord(pSpiPhy,0);						
			}
			timeout = POLLING_TIMEOUT;
			while(!(pSpiPhy->sspCtrl->ssr & SSSR_RNE) && timeout--);
			if (timeout == -1)	//This is for debugginf - timeout should never expire. If it does - SSP controler is not working.
				timeout = 0;
			*pdw = SSPReadDWord(pSpiPhy);
			pdw++;//pointer to DWORD inc by 4
			len-=4;					
		}
	}
	else // Using DMA
	{
		DMA_PARAMS_ST dmaParams;
		int i, tmp;

		if(txbuf)
		{
			//Set the Tx buffer DMA transaction.
			for (i = 0; i < (len+3)>>2; i++)
				((DWORD*)txbuf)[i] = SWAP32(((DWORD*)txbuf)[i]);										
		}

		/*Activate the DMA for the recieve of bytes*/
		dmaParams.srcAddr = pSpiPhy->sspDataRegPhy;
		dmaParams.dstAddr = rxbuf_phy_addr;
		dmaParams.len = len;
		dmaParams.flags = DMA_USE_SRC_FLOW_CONTROL | DMA_INC_DST_ADDR;
		dmaParams.transactionId = (DWORD)pSpiPhy->rxEvent;
		dmaParams.callBack = endOfDmaTransfer;
		pSpiPhy->dmaService->dmaConfigChannel((LPVOID)pSpiPhy->dmaService->rxDmaDevice, &dmaParams);
		DBGMSG( ZONE_DETAILED, (TEXT("DMA transfer src=0x%x, dst=0x%x, len=%d \r\n"), dmaParams.srcAddr, dmaParams.dstAddr, len));

		/*Activate the DMA for the transmit of bytes*/
		dmaParams.srcAddr = txbuf_phy_addr;
		dmaParams.dstAddr = pSpiPhy->sspDataRegPhy;
		dmaParams.len = len;
		dmaParams.flags = DMA_USE_DST_FLOW_CONTROL | DMA_INC_SRC_ADDR;
		dmaParams.transactionId = 0;
		dmaParams.callBack = NULL;
		pSpiPhy->dmaService->dmaConfigChannel((LPVOID)pSpiPhy->dmaService->txDmaDevice, &dmaParams);
		DBGMSG( ZONE_DETAILED, (TEXT("DMA transfer src=0x%x, dst=0x%x, len=%d \r\n"), dmaParams.srcAddr, dmaParams.dstAddr, len));

		// Moving 256 Bytes through SPI using 6.5Mbps takes ~0.3mS, so we wait much longer than that.
		if (WaitForSingleObject(pSpiPhy->rxEvent, 5000) == WAIT_OBJECT_0)
		{
//					DBGMSG( ZONE_INFO, (TEXT("-----------DMA transfer ended   at %d\r\n"), GetTickCount()));
			for (i = 0; i < len>>2; i++)
			{
				tmp =((DWORD*)rxbuf)[i];
				((DWORD*)rxbuf)[i] =  SWAP32(tmp);
			}
		}
		else
			DBGMSG( ZONE_ERROR, (TEXT("SPI!Read from device :Recieved Timeout for DMA transfer.\r\n")));
	}
#endif	
}



void smsspiphy_deinit(PVOID context)
{
	DWORD	exitCode;
	PSPIPHY pSpiPhy = (PSPIPHY)context;
	if (pSpiPhy)
	{
		pSpiPhy->drvActive = FALSE;
		if (pSpiPhy->RxIST)
		{
			if (pSpiPhy->SmsInterruptEvent) // Set an event to start the thread.
				SetEvent(pSpiPhy->SmsInterruptEvent);
			CloseHandle(pSpiPhy->RxIST);
			while (GetExitCodeThread(pSpiPhy->RxIST, &exitCode) == STILL_ACTIVE);
			pSpiPhy->RxIST = NULL;
		}
		

		if (pSpiPhy->SPIDMAInterruptIST)
		{
			if (pSpiPhy->SmsSPIDMAInterruptEvent) // Set an event to start the thread.
				SetEvent(pSpiPhy->SmsSPIDMAInterruptEvent);
			CloseHandle(pSpiPhy->SPIDMAInterruptIST);
			while (GetExitCodeThread(pSpiPhy->SPIDMAInterruptIST, &exitCode) == STILL_ACTIVE);
			pSpiPhy->SPIDMAInterruptIST = NULL;
		}
		
		if (pSpiPhy->rxEvent)
		{
			CloseHandle(pSpiPhy->rxEvent);
			pSpiPhy->rxEvent = NULL;

		}
		
		if (pSpiPhy->SmsInterruptEvent)
		{
			CloseHandle(pSpiPhy->SmsInterruptEvent);
			pSpiPhy->SmsInterruptEvent = NULL;

		}

		if (pSpiPhy->SmsSPIDMAInterruptEvent)
		{
			CloseHandle(pSpiPhy->SmsSPIDMAInterruptEvent);
			pSpiPhy->SmsSPIDMAInterruptEvent = NULL;

		}

		if (pSpiPhy->DMATxCompleteEvent)
		{
			CloseHandle(pSpiPhy->DMATxCompleteEvent);
			pSpiPhy->DMATxCompleteEvent = NULL;

		}

		UnConfigureSpiHw(pSpiPhy);
		KernelIoControl(IOCTL_HAL_RELEASE_SYSINTR, &pSpiPhy->spiSysIntr, sizeof(DWORD), NULL, 0, NULL);
#if defined(_TCC89x_)
        InterruptDisable(pSpiPhy->spiSysIntr);
#endif
		
		LocalFree(pSpiPhy);
	}

#if 0	
#ifdef GET_GPIOXX_2_IRQ
	//disable the hardware interrupt and to deregister the event 
	InterruptDisable(pSpiPhy->spiSysIntr);
#endif						  
	//cancel all Threads...ISRThread
	//cancel all Events...

//unmapping all physical addresses used to access register....
	//unmapping SSP registers
	MmUnmapIoSpace((PVOID)pSpiPhy->sspCtrl ,sizeof(XLLP_SSP_REGS));
	//unmapping CLK registers	
#endif


#if defined(_TCC79x_)

#elif defined(_TCC80x_)
    CloseHandle(ghSPI);

#elif defined(_TCC89x_)
    InterruptDisable(pSpiPhy->spiSysIntr);

    CloseHandle(ghSPI);
    SMS1010_PowerDown();

    RETAILMSG(1, (TEXT("smsspiphy_deinit-----\r\n")));

#endif
}

void* smsspiphy_init(PVOID Context, void(*smsspi_interruptHandler)(void*), PVOID intrContext)
{
	UINT32 Irq;
	PSPIPHY pSpiPhy = (PSPIPHY)LocalAlloc(LPTR,sizeof(SPIPHY));

	pSpiPhy->intrContext = intrContext;
	spiPhyGetRegistrySettings(Context, pSpiPhy);
//    activateDMAService(pSpiPhy);
	pSpiPhy->InterruptCallback = smsspi_interruptHandler;
	pSpiPhy->drvActive = TRUE;

	pSpiPhy->SmsInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if (pSpiPhy->SmsInterruptEvent == NULL)
	{
		DBGMSG(ZONE_INIT | ZONE_ERROR, (TEXT("SmsSpi: smsspiphy_init() failed to create SmsInterruptEvent event.\r\n")));
		smsspiphy_deinit(pSpiPhy);
		return NULL;
	}
	DBGMSG(ZONE_INIT, (TEXT("SmsSpi: Interrupt event create: 0x%x.\r\n"), pSpiPhy->SmsInterruptEvent));

	ConfigureSpiHw(pSpiPhy);


#if defined(_TCC79x_)
	// Call the OAL to translate the audio IRQ into a SYSINTR value.
	Irq = IRQ_EI3;  
	if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &Irq, sizeof(UINT32), &pSpiPhy->spiSysIntr, sizeof(UINT32), NULL))
	{
 		RETAILMSG(ZONE_ERROR, (TEXT("ERROR: HardwareContext::Init: Failed to obtain sysintr value for output interrupt.\r\n")));
		return NULL;
	}
	
   	if (!InterruptInitialize(pSpiPhy->spiSysIntr, pSpiPhy->SmsInterruptEvent, 0, 0)) // EINT3
    {
		RETAILMSG(ZONE_ERROR, (TEXT("SPI: InterruptInitialize(0x%08x,0x%08x) failed (0x%08x)\r\n"), 
                   pSpiPhy->spiSysIntr, pSpiPhy->SmsInterruptEvent, GetLastError()));
		return NULL;
 	}


	BITCSET(HwPORTCFG8, HwPORTCFG8_GPIOA11(15), HwPORTCFG8_GPIOA11(0));
	BITCLR(HwGPAEN , Hw11);
	BITCSET(HwCPUD5, HwCPUD5_GPIOA11(3), HwCPUD5_GPIOA11(1));

	BITCSET(HwEINTSEL0, HwEINTSEL0_EINT3SEL_MASK, HwEINTSEL0_EINT3(SEL_GPIOA11));

	BITCLR(HwMODE, HwINT_EI3); // Edge triggered
	BITSET(HwPOL, HwINT_EI3); // low active
	BITSET(HwSEL, HwINT_EI3); // IRQ
	BITSET(HwCLR, HwINT_EI3); // 
	BITCLR(HwIEN, HwINT_EI3);

#elif defined(_TCC80x_)
	BITSET(HwPMIO_FS0, Hw4); // 1 : PK pin controlled by GPIOPK_DAT/DOE/FS0~2 
	BITSET(HwGPIOPK_FS0, Hw4); // External Interrupt Inputs [7:0] to Interrupt Controller 
	BITCLR(HwGPIOPK_DOE, Hw4); // GPIO_PK7 Input mode Setting 
	BITSET(HwGPIOPK_IRQST, Hw4); // Interrupt Status for PK[31:0] 
	BITCLR(HwGPIOPK_IRQTM0, Hw4); // Edge Trigger
	BITCLR(HwGPIOPK_IRQTM1, Hw4); // Single EdgeTrigger

	BITSET(HwGPIOPK_IRQEN, Hw4);// Interrupt Enable for PK[31:0] (0 = Disable, 1 = Enable)

	BITSET(HwPOL_B, Hw4); // Low Active
	BITCLR(HwTMODE_B,Hw4); // Edge
	BITSET(HwSYNC_B,Hw4); // Sync Disable

	Irq=IRQ_EI4;
	if (!KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &Irq, sizeof(UINT32), &pSpiPhy->spiSysIntr, sizeof(UINT32), NULL))
	{
 		RETAILMSG(ZONE_ERROR, (TEXT("ERROR: HardwareContext::Init: Failed to obtain sysintr value for output interrupt.\r\n")));
		return NULL;
	}
	
   	if (!InterruptInitialize(pSpiPhy->spiSysIntr, pSpiPhy->SmsInterruptEvent, 0, 0))
    {
		RETAILMSG(ZONE_ERROR, (TEXT("SPI: InterruptInitialize(0x%08x,0x%08x) failed (0x%08x)\r\n"), pSpiPhy->spiSysIntr, pSpiPhy->SmsInterruptEvent, GetLastError()));
		return NULL;
 	}

#elif defined(_TCC89x_)
    {
        PGPIO pGPIO=(PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	    PPIC pPIC=(PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);

        DWORD IRQ=IRQ_EI3;

        BITCSET(pGPIO->EINTSEL0, Hw30-Hw24, 11*Hw24);
	    BITCLR(pGPIO->GPAFN1, Hw16-Hw12);
	    BITCLR(pGPIO->GPAEN, Hw11);

        BITSET(pPIC->POL0, Hw6);
        BITSET(pPIC->SEL0, Hw6);
        BITCLR(pPIC->MODE0, Hw6);
        BITCLR(pPIC->MODEA0, Hw6);
    	
	    KernelIoControl(IOCTL_HAL_REQUEST_SYSINTR, &IRQ, sizeof(DWORD), &pSpiPhy->spiSysIntr, sizeof(UINT32), NULL);
	    RETAILMSG(1,(TEXT("[SIANO       ]-Siano SPI Enable\n")));

        //tcc_freebaseaddress((unsigned int)pGPIO, sizeof(GPIO));
        //tcc_freebaseaddress((unsigned int)pPIC, sizeof(PIC));


       	if (!InterruptInitialize(pSpiPhy->spiSysIntr, pSpiPhy->SmsInterruptEvent, 0, 0))
        {
    		///RETAILMSG(ZONE_ERROR, (TEXT("SPI: InterruptInitialize(0x%08x,0x%08x) failed (0x%08x)\r\n"), pSpiPhy->spiSysIntr, pSpiPhy->SmsInterruptEvent, GetLastError()));
            RETAILMSG(1, (TEXT("SPI: InterruptInitialize(0x%08x,0x%08x) failed (0x%08x)\r\n"), pSpiPhy->spiSysIntr, pSpiPhy->SmsInterruptEvent, GetLastError()));
            return NULL;
        }
        RETAILMSG(1,(TEXT("[SIANO       ]-InterruptInitialize OK\n")));
    }

#endif

    pSpiPhy->RxIST = CreateThread (NULL, 0, (LPTHREAD_START_ROUTINE)SpiRxIST, pSpiPhy, 0, NULL);
	if (pSpiPhy->RxIST == NULL)
	{
		DBGMSG(ZONE_INIT | ZONE_ERROR, (TEXT("SmsSpi: smsspiphy_init() failed to create transferThread thread.\r\n")));
		smsspiphy_deinit(pSpiPhy);
		return 0;
	}

	if (CeSetThreadPriority(pSpiPhy->RxIST, 240) == FALSE)
	{
		DBGMSG(ZONE_INIT | ZONE_ERROR, (TEXT("SmsSpi: smsspiphy_init() failed to set Interrupt thread priority.\r\n")));
		smsspiphy_deinit(pSpiPhy);
		return 0;
	}

#if defined(_TCC79x_)
	BITSET(HwIEN, HwINT_EI3);

#elif defined(_TCC80x_)
	InterruptDone(pSpiPhy->spiSysIntr);

#elif defined(_TCC89x_)

#endif

 	RETAILMSG(ZONE_INIT, (TEXT("smsspiphy_init-----\r\n")));

	return pSpiPhy;
}

void smschipreset(PVOID context)
{
}
