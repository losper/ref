#ifndef _SPIPHY_H_
#define _SPIPHY_H_

void smsspibus_xfer(void* context, 
                    unsigned char * txbuf, unsigned long txbuf_phy_addr, 
                    unsigned char* rxbuf, unsigned long rxbuf_phy_addr, 
                    int len);
void* smsspiphy_init(void* Context, void(*smsspi_interruptHandler)(void*), PVOID intrContext);
void smsspiphy_deinit(void* context);

void smschipreset(void* context);
void WriteFWtoStellar(void* pSpiPhy,unsigned char* pFW,unsigned long Len);
void prepareForFWDnl(void* pSpiPhy);
void fwDnlComplete(void* context, int App);

#endif
