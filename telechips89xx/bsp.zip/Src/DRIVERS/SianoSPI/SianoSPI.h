#ifndef _SIANOSPI_H_
#define _SIANOSPI_H_


#include <windows.h>
#include <pm.h>

#include "BusDrvIf.h"
//#include "SianoDMA_API.h"
#include "smsspicommon.h"



/************************************************************************/
/* Debug Zones definitions.                                             */
/************************************************************************/

/* Debug zones: */
#define ZONE_NONE_SET		0x0000
#define ZONE_ERROR			0//DEBUGZONE(0)
#define ZONE_ERROR_SET		0x0001
#define ZONE_WARNING		0//DEBUGZONE(1)
#define ZONE_WARNING_SET	0x0002
#define ZONE_INIT			0//DEBUGZONE(2)
#define ZONE_INIT_SET		0x0004
#define ZONE_INFO			0//DEBUGZONE(3)
//#define ZONE_INFO			1
#define ZONE_INFO_SET		0x0008
#define ZONE_DETAILED		0//DEBUGZONE(4)
#define ZONE_DETAILED_SET	0x0010
#define ZONE_ALL_SET		0xFFFF /* All of the zones */

#ifdef ENABLE_LOGS

#ifdef LOG_TO_FILE

	#define REGISTERZONES(hMod)
	#define DBGMSG(m, s) ((m & dpCurSettings.ulZoneMask) ? (LogStrToFile s),1:0)

#else
	#if defined(DEBUG)

		#define REGISTERZONES(hMod) DEBUGREGISTER(hMod)
		#define DBGMSG				DEBUGMSG

	#else

		#define REGISTERZONES(hMod) RETAILREGISTERZONES(hMod)
		#define DBGMSG				RETAILMSG

	#endif
#endif

#else

	#define REGISTERZONES(hMod)
	#define DBGMSG					RETAILMSG

#endif

extern DBGPARAM dpCurSettings;
/************************************************************************/


/////////////////////////////////////////////////
//for posting RETAILMSG for debug - remove remark
//#define POSTDEBUGMSG
/////////////////////////////////////////////////

typedef enum _CLIENTTYPE {ClientTypeNone,ClientTypeControl,ClientTypeData,ClientTypeIpData}CLIENTTYPE;

#define SPI_PACKET_SIZE	256
#define RX_PACKET_SIZE	0x1000
#define NUM_OF_RX_PACKES	100//48//24//4
#define SMM100_HDR_SIZE	8
#define SPI_PREAMBLE 0x7EE75AA5//0xA55AE77E//0xA5, 0x5A, 0xE7, 0x7E,//Preamble in little endian
#define SPI_PREAMBLE_REVERSE 0xA55AE77E
#define SPI_PREAMBLE_SIZE 4


#if 0
typedef struct DEVICE_DMA_SERVICE_S
{
	HMODULE				hdl;
	LPVOID				rxDmaDevice;
	LPVOID				txDmaDevice;
	DMA_SetUpChannelF	dmaSetUpChannel;
	DMA_ConfigChannelF	dmaConfigChannel;
	DMA_RemoveChannelF	dmaRemoveChannel;
}DEVICE_DMA_SERVICE_ST;
#endif

#define MAX_REG_PATH_SIZE 100
										//adapter//Buff//Len



typedef struct _SPIDEVICEEXTENSION
{

	struct spi_dev		dev;
	void (*Callback)(PCHAR buf, int len) ;
	BOOL 				PaddingAllowed;
	rx_buffer_st		rxbuf;
	char 				*txbuf;
	unsigned long		txbuf_phy_addr;
	HANDLE				WriteOperation;
	HANDLE				transferMsgQueue;
	HANDLE				transferThread;
	HANDLE				performanceThread;
	PVOID				phyDrv;
	HANDLE				hSmsGenDrv;				//GenDriver handle.
	BD_ReadCBFunc		pBD_ReadCBFunc;
	BOOL				novaDevice;
	CEDEVICE_POWER_STATE	powerState;
	DWORD					hBDContext;
}SPIDEVICEEXTENSION, *PSPIDEVICEEXTENSION;


#define SYSINTR_GPSBCH1DMA_ALARM	48


#endif
