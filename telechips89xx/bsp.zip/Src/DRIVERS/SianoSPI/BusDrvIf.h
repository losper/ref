
#ifndef _BUS_DRV_IF_H
#define _BUS_DRV_IF_H

#include <windows.h>
#include <winioctl.h>

/* Bus driver type. used in ClientInfo key to detect which driver loaded the SmsGenDrv */
typedef enum
{
	BD_TYPE_SDIO_STELLAR = 0,
	BD_TYPE_SPI_STELLAR,
	BD_TYPE_HIF_STELLAR,
	BD_TYPE_USB_STELLAR,
	BD_TYPE_USB_FW,
	BD_TYPE_SDIO_NOVA,
	BD_TYPE_SPI_NOVA,
	BD_TYPE_HIF_NOVA,
	BD_TYPE_USB_NOVA
} BD_TYPE_E;

typedef enum {
    BD_APP_UNSUPPORTED = -1,
    BD_APP_DVBH = 0,
    BD_APP_DVBT = 1,
    BD_APP_TDMB = 2,
    BD_APP_ISDBT= 3,
    BD_APP_CMMB = 4
} BD_APP_TYPE_E;


/* Bus driver prefix */
#define SIANO_SDIO_PREFIX	TEXT("SDI")
#define SIANO_SPI_PREFIX	TEXT("SSD")
#define SIANO_HIF_PREFIX	TEXT("HIF")
#define SIANO_USB_PREFIX	TEXT("SMU")

#define SMS_GEN_DRIVER_REGISTRY_PATH TEXT("Drivers\\Siano\\SMS1000\\SmsGenDrv")

/* callback to be registered in SIANO_BD_IOCTL_REGISTER_READ_CB */
typedef void (*BD_ReadCBFunc) (DWORD hContext, void* pBuffer, UINT32 BufSize);

typedef struct BD_IOCTL_REGISTER_READ_PARAMS_S
{
	BD_ReadCBFunc	pBD_ReadCBFunc;
	DWORD			hContext;

} BD_IOCTL_REGISTER_READ_PARAMS_ST, *PBD_IOCTL_REGISTER_READ_PARAMS_ST;


typedef struct BD_IOCTL_DOWNLOAD_FW_S
{
	PVOID						buf;
	DWORD						size;
	BD_APP_TYPE_E				application;

} BD_IOCTL_DOWNLOAD_FW_ST, *PBD_IOCTL_DOWNLOAD_FW_ST;

typedef struct BD_IOCTL_DNL_COMPLETE_S
{
	BD_APP_TYPE_E				application;

} BD_IOCTL_DNL_COMPLETE_ST, *PBD_IOCTL_DNL_COMPLETE_ST;

/* IOCTLS */

#define SIANO_MAKE_IOCTL(index) \
      CTL_CODE(40000, 2048 + (index), METHOD_BUFFERED, FILE_ANY_ACCESS)

/* Description : register callback to be called after driver read buffer from the device */
/* input  : pointer to PBD_IOCTL_REGISTER_READ_PARAMS_ST structure */
/* output : none */
#define SIANO_BD_IOCTL_REGISTER_READ_CB					SIANO_MAKE_IOCTL(0)

/* Description : write FW buffer to the device */
/* input  : buffer holds the FW to be written */
/* output : none */
#define SIANO_BD_IOCTL_WRITE_FW_BUFF_TO_DEVICE			SIANO_MAKE_IOCTL(1)

/* Description : Prepare interface for FW download */
/* input  : none */
/* output : none */
#define SIANO_BD_IOCTL_PREPARE_FOR_FW_DNL   			SIANO_MAKE_IOCTL(2)

/* Description : FW download complete */
/* input  : none */
/* output : none */
#define SIANO_BD_IOCTL_FW_DNL_COMPLETE      			SIANO_MAKE_IOCTL(3)

#endif
