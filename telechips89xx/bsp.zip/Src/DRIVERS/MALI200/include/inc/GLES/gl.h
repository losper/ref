/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2005, 2007-2009 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

/*
 * This is the Mali gl wrapper, for use in driver development only
 *  all applications should be built with the stock gl.h and egl.h
 */

/*
 * if tracing is enabled, include oglestraceredef.h to change gl* to
 * DRVgl*, so that all entry points can be logged by trace library
 */
#ifdef GL_TRACE_WRAPPER
	#include <GLES/oglestraceredef.h>
#endif

/* current khronos distributed gl.h, must be on include path */
#if MALI_USE_GLES_1 && MALI_USE_GLES_2
	#include <GLES_GLES2/mali_gl_gl2.h>
#else
	#include <khronos/GLES/gl.h>
#endif

#ifndef _MALI_GL_H_
#define _MALI_GL_H_

/* driver specific contents can be defined here */

/* These tokens have been removed from the Khronos version of gl.h. We
 * define them here for backwards compatibility.
 */
#ifndef GL_MAX_ELEMENTS_VERTICES
#define GL_MAX_ELEMENTS_VERTICES  0x80E8
#endif

#ifndef GL_MAX_ELEMENTS_INDICES
#define GL_MAX_ELEMENTS_INDICES   0x80E9
#endif

#endif /* _MALI_GL_H_ */
