//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
// GIISR.c
//
// Generic Installable Interrupt Service Routine.
//
//
#include <windows.h>
#include <nkintr.h>
#include <ceddk.h>
#include <giisr.h>
#include <bsp.h>
// Globals
static GIISR_INFO g_Info[MAX_GIISR_INSTANCES];
static DWORD g_PortValue[MAX_GIISR_INSTANCES];
static BOOL g_InstanceValid[MAX_GIISR_INSTANCES] = {FALSE};
static DWORD g_Instances = 0;

//you an use option under 115200 baudrate.
//if you want use this option, enable serial driver's below option also.
//-DLOW_SERIAL_PERFORMANCE (exist on serial driver's sources file )
#define LOW_SERIAL_PERFORMANCE

/*
 @doc INTERNAL
 @func    BOOL | DllEntry | Process attach/detach api.
 *
 @rdesc The return is a BOOL, representing success (TRUE) or failure (FALSE).
 */
BOOL __stdcall
DllEntry(
    HINSTANCE hinstDll,         // @parm Instance pointer.
    DWORD dwReason,             // @parm Reason routine is called.
    LPVOID lpReserved           // @parm system parameter.
     )
{
     if (dwReason == DLL_PROCESS_ATTACH) {
     }

     if (dwReason == DLL_PROCESS_DETACH) {
     }

     return TRUE;
}


DWORD CreateInstance(
    void
    )
{
    DWORD InstanceIndex;
    
    if (g_Instances >= MAX_GIISR_INSTANCES) {
        return -1;
    }
    
    g_Instances++;

    // Search for next free instance
    for (InstanceIndex = 0; InstanceIndex < MAX_GIISR_INSTANCES; InstanceIndex++) {
        if (!g_InstanceValid[InstanceIndex]) break;
    }

    // Didn't find a free instance (this shouldn't happen)
    if (InstanceIndex >= MAX_GIISR_INSTANCES) {
        return -1;
    }

    g_InstanceValid[InstanceIndex] = TRUE;
    
    // Initialize info
    g_Info[InstanceIndex].SysIntr = SYSINTR_CHAIN;
    g_Info[InstanceIndex].CheckPort = FALSE;
    g_Info[InstanceIndex].UseMaskReg = FALSE;

    // Initialize data
    g_PortValue[InstanceIndex] = 0;

    return InstanceIndex;
}


void DestroyInstance(
    DWORD InstanceIndex 
    )
{
    if (g_InstanceValid[InstanceIndex]) {
        g_InstanceValid[InstanceIndex] = FALSE;
        g_Instances--;
    }
}


// The compiler generates a call to memcpy() for assignments of large objects.
// Since this library is not linked to the CRT, define our own copy routine.
void
InfoCopy(
    PGIISR_INFO dst,
    const GIISR_INFO *src
    )
{
    size_t count = sizeof(GIISR_INFO);
    
    while (count--) {
        *((PBYTE)dst)++ = *((PBYTE)src)++;
    }
}


BOOL 
IOControl(
    DWORD   InstanceIndex,
    DWORD   IoControlCode, 
    LPVOID  pInBuf, 
    DWORD   InBufSize,
    LPVOID  pOutBuf, 
    DWORD   OutBufSize, 
    LPDWORD pBytesReturned
    ) 
{
    if (pBytesReturned) {
        *pBytesReturned = 0;
    }

    switch (IoControlCode) {
    case IOCTL_GIISR_PORTVALUE:
        if ((OutBufSize != g_Info[InstanceIndex].PortSize) || !g_Info[InstanceIndex].CheckPort || !pOutBuf) {
            // Invalid size of output buffer, not checking port, or invalid output buffer pointer
            return FALSE;
        }

        if (pBytesReturned) {
            *pBytesReturned = g_Info[InstanceIndex].PortSize;
        }
        
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            *(BYTE *)pOutBuf = (BYTE)g_PortValue[InstanceIndex];
            break;
            
        case sizeof(WORD):
            *(WORD *)pOutBuf = (WORD)g_PortValue[InstanceIndex];
            break;

        case sizeof(DWORD):
            *(DWORD *)pOutBuf = g_PortValue[InstanceIndex];
            break;

        default:
            if (pBytesReturned) {
                *pBytesReturned = 0;
            }
            
            return FALSE;
        }

        break;
        
    case IOCTL_GIISR_INFO:
        // Copy instance information
        if ((InBufSize != sizeof(GIISR_INFO)) || !pInBuf) {
            // Invalid size of input buffer or input buffer pointer
            return FALSE;
        }

        // The compiler may generate a memcpy call for a structure assignment,
        // and we're not linking with the CRT, so use our own copy routine.
        InfoCopy(&g_Info[InstanceIndex], (PGIISR_INFO)pInBuf);

        break;

    default:
        // Invalid IOCTL
        return FALSE;
    }
    
    return TRUE;
}

DWORD
ISRHandler(
    DWORD InstanceIndex
    )
{
	int i;
	DWORD nRet;
    DWORD Mask = g_Info[InstanceIndex].Mask;
    
    if (!g_Info[InstanceIndex].CheckPort) {
        return g_Info[InstanceIndex].SysIntr;
    }
    
    if (g_Info[InstanceIndex].PortAddr == 0 ) {
        return SYSINTR_CHAIN ;
    }

    g_PortValue[InstanceIndex] = 0;
    
    // Check port
    if (g_Info[InstanceIndex].PortIsIO) {
        // I/O port
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            g_PortValue[InstanceIndex] = READ_PORT_UCHAR((PUCHAR)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_UCHAR((PUCHAR)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(WORD):
            g_PortValue[InstanceIndex] = READ_PORT_USHORT((PUSHORT)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_USHORT((PUSHORT)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(DWORD):
            g_PortValue[InstanceIndex] = READ_PORT_ULONG((PULONG)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_ULONG((PULONG)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        default:
            // No interrupt will be returned
            break;
        }
    } else {
        // Memory-mapped port
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            g_PortValue[InstanceIndex] = READ_REGISTER_UCHAR((BYTE *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_UCHAR((BYTE *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(WORD):
            g_PortValue[InstanceIndex] = READ_REGISTER_USHORT((WORD *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_USHORT((WORD *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(DWORD):
            g_PortValue[InstanceIndex] = READ_REGISTER_ULONG((DWORD *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_ULONG((DWORD *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        default:
            // No interrupt will be returned
            break;
        }    
    }

	return (g_PortValue[InstanceIndex] & Mask) ? g_Info[InstanceIndex].SysIntr : SYSINTR_CHAIN;
}



DWORD
DMAISRHandler(
    DWORD InstanceIndex
    )
{
	int i;
	DWORD nRet;
    DWORD Mask = g_Info[InstanceIndex].Mask;
    
    if (!g_Info[InstanceIndex].CheckPort) {
        return g_Info[InstanceIndex].SysIntr;
    }
    
    if (g_Info[InstanceIndex].PortAddr == 0 ) {
        return SYSINTR_CHAIN ;
    }

    g_PortValue[InstanceIndex] = 0;
    
    // Check port
    if (g_Info[InstanceIndex].PortIsIO) {
        // I/O port
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            g_PortValue[InstanceIndex] = READ_PORT_UCHAR((PUCHAR)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_UCHAR((PUCHAR)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(WORD):
            g_PortValue[InstanceIndex] = READ_PORT_USHORT((PUSHORT)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_USHORT((PUSHORT)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(DWORD):
            g_PortValue[InstanceIndex] = READ_PORT_ULONG((PULONG)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_ULONG((PULONG)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        default:
            // No interrupt will be returned
            break;
        }
    } else {
        // Memory-mapped port
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            g_PortValue[InstanceIndex] = READ_REGISTER_UCHAR((BYTE *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_UCHAR((BYTE *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(WORD):
            g_PortValue[InstanceIndex] = READ_REGISTER_USHORT((WORD *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_USHORT((WORD *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(DWORD):
            g_PortValue[InstanceIndex] = READ_REGISTER_ULONG((DWORD *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_ULONG((DWORD *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        default:
            // No interrupt will be returned
            break;
        }    
    }


	
    // If interrupt bit set, return corresponding SYSINTR
    //return (g_PortValue[InstanceIndex] & Mask) ? g_Info[InstanceIndex].SysIntr : SYSINTR_CHAIN;
	//pdma->CHCTRL1 &= ~Hw2;
    //If interrupt bit set, return corresponding SYSINTR
    nRet =  (g_PortValue[InstanceIndex] & Mask) ? g_Info[InstanceIndex].SysIntr : SYSINTR_CHAIN;


	if(SYSINTR_CHAIN != nRet){
		*(volatile unsigned long *)g_Info[InstanceIndex].PortAddr &= ~Hw2;		
	}
	
	return nRet;
		
	
}


DWORD
DMAUARTISRHandler(
    DWORD InstanceIndex
    )
{
	int i;
	DWORD nRet;
    DWORD Mask = g_Info[InstanceIndex].Mask;
    
    if (!g_Info[InstanceIndex].CheckPort) {
        return g_Info[InstanceIndex].SysIntr;
    }
    
    if (g_Info[InstanceIndex].PortAddr == 0 ) {
        return SYSINTR_CHAIN ;
    }

    g_PortValue[InstanceIndex] = 0;
    
    // Check port
    if (g_Info[InstanceIndex].PortIsIO) {
        // I/O port
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            g_PortValue[InstanceIndex] = READ_PORT_UCHAR((PUCHAR)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_UCHAR((PUCHAR)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(WORD):
            g_PortValue[InstanceIndex] = READ_PORT_USHORT((PUSHORT)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_USHORT((PUSHORT)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(DWORD):
            g_PortValue[InstanceIndex] = READ_PORT_ULONG((PULONG)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_ULONG((PULONG)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        default:
            // No interrupt will be returned
            break;
        }
    } else {
        // Memory-mapped port
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            g_PortValue[InstanceIndex] = READ_REGISTER_UCHAR((BYTE *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_UCHAR((BYTE *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(WORD):
            g_PortValue[InstanceIndex] = READ_REGISTER_USHORT((WORD *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_USHORT((WORD *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(DWORD):
            g_PortValue[InstanceIndex] = READ_REGISTER_ULONG((DWORD *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_ULONG((DWORD *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        default:
            // No interrupt will be returned
            break;
        }    
    }


	//OALMSG(TC_LOG_LEVEL(TC_LOG), (L"[+GIISR     ]portval[%x] mask[%x] sysintr[%x]\r\n",*(volatile unsigned long *)g_Info[InstanceIndex].PortAddr,Mask,g_Info[InstanceIndex].SysIntr));
    // If interrupt bit set, return corresponding SYSINTR
    nRet =  (g_PortValue[InstanceIndex] & Mask) ? g_Info[InstanceIndex].SysIntr : SYSINTR_CHAIN;

	if(SYSINTR_CHAIN != nRet){
		#ifdef LOW_SERIAL_PERFORMANCE
		*(volatile unsigned long *)g_Info[InstanceIndex].PortAddr &= ~Hw2;
		*(volatile unsigned long *)g_Info[InstanceIndex].PortAddr |= Hw3;
		#else
		*(volatile unsigned long *)g_Info[InstanceIndex].PortAddr |= Hw2;
		#endif
	}

	//OALMSG(TC_LOG_LEVEL(TC_LOG), (L"[-GIISR     ]portval[%x] mask[%x] sysintr[%x]\r\n",*(volatile unsigned long *)g_Info[InstanceIndex].PortAddr,Mask,g_Info[InstanceIndex].SysIntr));

	return nRet;
		
	
}

DWORD
GPSBISRHandler(
    DWORD InstanceIndex
    )
{
	int i;
	DWORD nRet;
    DWORD Mask = g_Info[InstanceIndex].Mask;
    
    if (!g_Info[InstanceIndex].CheckPort) {
        return g_Info[InstanceIndex].SysIntr;
    }
    
    if (g_Info[InstanceIndex].PortAddr == 0 ) {
        return SYSINTR_CHAIN ;
    }

    g_PortValue[InstanceIndex] = 0;
    
    // Check port
    if (g_Info[InstanceIndex].PortIsIO) {
        // I/O port
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            g_PortValue[InstanceIndex] = READ_PORT_UCHAR((PUCHAR)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_UCHAR((PUCHAR)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(WORD):
            g_PortValue[InstanceIndex] = READ_PORT_USHORT((PUSHORT)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_USHORT((PUSHORT)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(DWORD):
            g_PortValue[InstanceIndex] = READ_PORT_ULONG((PULONG)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_PORT_ULONG((PULONG)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        default:
            // No interrupt will be returned
            break;
        }
    } else {
        // Memory-mapped port
        switch (g_Info[InstanceIndex].PortSize) {
        case sizeof(BYTE):
            g_PortValue[InstanceIndex] = READ_REGISTER_UCHAR((BYTE *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_UCHAR((BYTE *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(WORD):
            g_PortValue[InstanceIndex] = READ_REGISTER_USHORT((WORD *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_USHORT((WORD *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        case sizeof(DWORD):
            g_PortValue[InstanceIndex] = READ_REGISTER_ULONG((DWORD *)g_Info[InstanceIndex].PortAddr);

            if (g_Info[InstanceIndex].UseMaskReg) {
                // Read mask from mask register
                Mask = READ_REGISTER_ULONG((DWORD *)g_Info[InstanceIndex].MaskAddr);
            }
            
            break;

        default:
            // No interrupt will be returned
            break;
        }    
    }

    nRet = (g_PortValue[InstanceIndex] & Mask) ? g_Info[InstanceIndex].SysIntr : SYSINTR_CHAIN;

	if( SYSINTR_CHAIN != nRet ) {
		*(DWORD *)g_Info[InstanceIndex].PortAddr |= Mask;
	}

	return nRet;
}

