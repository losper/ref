
/****************************************************************************
 *   FileName    :  tca_spi_hwset.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#if defined(_LINUX_)
#include <linux/module.h>
#include <mach/io.h>
#else
#include <stdlib.h>
#include "tcc_gpio.h"
#endif

#include <bsp.h>
#include "tca_spi_hwset.h"


static int tca_spi_isenabledma(struct tca_spi_handle *h)
{
    return (h->regs->DMACTR & Hw0) ? 1 : 0;
}

static int tca_spi_dmastop(struct tca_spi_handle *h)
{
    BITCLR(h->regs->DMACTR, Hw31 | Hw30); /* disable DMA Transmit & Receive */
    BITSET(h->regs->DMAICR, Hw29| Hw28);
    BITCLR(h->regs->DMACTR, Hw0); /* DMA disable */
	return 0;
}

static int tca_spi_dmastart(struct tca_spi_handle *h)
{
    BITSET(h->regs->DMACTR, Hw31 | Hw30); /* enable DMA Transmit & Receive */
    BITCLR(h->regs->DMACTR, Hw17 | Hw16 | Hw15 | Hw14); /* set Multiple address mode */

    BITCLR(h->regs->DMAICR, Hw16); /* disable DMA Packet Interrupt */
    BITSET(h->regs->DMAICR, Hw17); /* enable DMA Done Interrupt */
    BITCLR(h->regs->DMAICR, Hw20); /* set rx interrupt */

    BITSET(h->regs->DMACTR, Hw0); /* DMA enable */
	return 0;
}

static int tca_spi_dmastart_slave(struct tca_spi_handle *h)
{
    //BITSET(h->regs->DMACTR, Hw31 | Hw30); /* enable DMA Transmit & Receive */
    BITSET(h->regs->DMACTR, Hw30); /* enable DMA Transmit */
    BITCLR(h->regs->DMACTR, Hw17 | Hw16 | Hw15 | Hw14); /* set Multiple address mode */

    BITSET(h->regs->DMAICR, Hw16); /* enable DMA Packet Interrupt */
    //BITSET(h->regs->DMAICR, Hw17); /* enable DMA Done Interrupt */
    BITCLR(h->regs->DMAICR, Hw20); /* set rx interrupt */

    //h->regs->DMAICR = h->regs->DMAICR | (256 & 0x1FFF);
    BITSET(h->regs->DMAICR, Hw16); /* enable DMA Packet Interrupt */

	if (h->dma_mode == 0) {
		BITCSET(h->regs->DMACTR, Hw5|Hw4, Hw29);	/* Normal mode & Continuous mode*/
	} else {
		BITSET(h->regs->DMACTR, Hw4);				/* MPEG2-TS mode */
	}

    BITSET(h->regs->DMACTR, Hw0); /* DMA enable */
	return 0;
}

static void tca_spi_clearfifopacket(struct tca_spi_handle *h)
{
    /* clear tx/rx FIFO & Packet counter  */
    BITSET(h->regs->MODE, Hw15 | Hw14);
    BITSET(h->regs->DMACTR, Hw2);
    BITCLR(h->regs->DMACTR, Hw2);
    BITCLR(h->regs->MODE, Hw15 | Hw14);
}

static void tca_spi_setpacketcnt(struct tca_spi_handle *h, int size)
{
    /* set packet count & size */
    h->regs->PACKET = (size & 0x1FFF);
}

static void tca_spi_setpacketcnt_slave(struct tca_spi_handle *h, int size)
{
    unsigned int packet_cnt = (h->dma_total_packet_cnt & 0x1FFF) - 1;
    unsigned int packet_size = (MPEG_PACKET_SIZE & 0x1FFF);
    unsigned int intr_packet_cnt = (h->dma_intr_packet_cnt & 0x1FFF) - 1;

    if (packet_size != size) {
        size = packet_size;
    }

    h->regs->PACKET = (packet_cnt << 16) | packet_size;
    BITCSET(h->regs->DMAICR, 0x1FFF, intr_packet_cnt);
}

static void tca_spi_setbitwidth(struct tca_spi_handle *h, int width)
{
    int width_value = (width - 1) & 0x1F;

    /* set bit width */
    BITCLR(h->regs->MODE, Hw12 | Hw11 | Hw10 | Hw9 | Hw8);
    h->regs->MODE |= (width_value << 8);
    if (width_value & Hw4) {
        BITCLR(h->regs->DMACTR, Hw28);
    } else {
        BITSET(h->regs->DMACTR, Hw28);
    }
}

static void tca_spi_setdmaaddr(struct tca_spi_handle *h)
{
    /* set dma txbase/rxbase & request DMA tx/rx */
    h->regs->TXBASE = h->tx_dma.dma_addr;
    h->regs->RXBASE = h->rx_dma.dma_addr;

    h->regs->INTEN = h->tx_dma.dma_addr ? (h->regs->INTEN | Hw31) : (h->regs->INTEN & ~Hw31);
    h->regs->INTEN = h->rx_dma.dma_addr ? (h->regs->INTEN | Hw30) : (h->regs->INTEN & ~Hw30);
}

static void tca_spi_setdmaaddr_slave(struct tca_spi_handle *h)
{
    /* set dma txbase/rxbase & request DMA tx/rx */
    h->regs->RXBASE = h->rx_dma.dma_addr;
    h->regs->INTEN = h->rx_dma.dma_addr ? (h->regs->INTEN | Hw30) : (h->regs->INTEN & ~Hw30);
}

static void tca_spi_hwinit(struct tca_spi_handle *h)
{
    /* init => set SPI mode, set Master mode ... */
    memset((void *)(h->regs), 0, sizeof(struct tca_spi_regs));

    h->set_bit_width(h, 32);

    /* [SCK] Tx: risiing edge, Rx: falling edge & enable Operation */
    BITSET((h->regs)->MODE, Hw17 | Hw18 | Hw3);

    h->set_dma_addr(h);
    h->clear_fifo_packet(h);
}

static void tca_spi_hwinit_slave(struct tca_spi_handle *h)
{
    /* init => set SPI mode, set Master mode ... */
    memset((void *)(h->regs), 0, sizeof(struct tca_spi_regs));

    h->set_bit_width(h, 32);

    /* [SCK] Tx: risiing edge, Rx: falling edge & enable Operation */
    BITSET((h->regs)->MODE, Hw17 | Hw18 | Hw3);
    BITSET((h->regs)->MODE, Hw2 | Hw5);

    h->set_dma_addr(h);
    h->clear_fifo_packet(h);
}

static void tca_spi_set_mpegtspidmode(struct tca_spi_handle *h, int is_set)
{
    if (is_set) {
        BITSET(h->regs->DMACTR, Hw19 | Hw18);
    } else {
        BITCLR(h->regs->DMACTR, Hw19 | Hw18);
    }
}


/******************************
 * return value
 *
 * ret == 0: success
 * ret > 0 or ret < 0: fail
 ******************************/
int tca_spi_init(tca_spi_handle_t *h,
                 volatile struct tca_spi_regs *regs,
                 int irq,
                 dma_alloc_f tea_dma_alloc,
                 dma_free_f tea_dma_free,
                 int dma_size,
                 int id,
                 int is_slave)
{
    int ret = -1;

#if defined(_LINUX_)
	volatile PPIC pic_regs = (volatile PPIC)tcc_p2v(HwPIC_BASE);
	volatile PGPIO gpio_regs = (volatile PGPIO)tcc_p2v(HwGPIO_BASE);
	volatile PGPSBPORTCFG gpsb_pcf_regs = (volatile PGPSBPORTCFG)tcc_p2v(HwGPSBPORTCFG_BASE);
#else
	PPIC pic_regs = (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);
	PGPIO gpio_regs = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	PGPSBPORTCFG gpsb_pcf_regs = (PGPSBPORTCFG)tcc_allocbaseaddress((unsigned int)&HwGPSBPORTCFG_BASE);
#endif

    if (h) { memset(h, 0, sizeof(tca_spi_handle_t)); }
    if (regs) {
        h->regs = regs;
        h->irq = irq;
        h->id = id;
		h->is_slave = is_slave;
		h->gpio_set = 0x1234;

        h->dma_stop = tca_spi_dmastop;
        h->dma_start = is_slave ? tca_spi_dmastart_slave : tca_spi_dmastart;
        h->clear_fifo_packet = tca_spi_clearfifopacket;
        h->set_packet_cnt = is_slave ? tca_spi_setpacketcnt_slave : tca_spi_setpacketcnt;
        h->set_bit_width = tca_spi_setbitwidth;
        h->set_dma_addr = is_slave ? tca_spi_setdmaaddr_slave : tca_spi_setdmaaddr;
        h->hw_init = is_slave ? tca_spi_hwinit_slave : tca_spi_hwinit;
        h->is_enable_dma = tca_spi_isenabledma;
        h->set_mpegts_pidmode = tca_spi_set_mpegtspidmode;

        h->tea_dma_alloc = tea_dma_alloc;
        h->tea_dma_free = tea_dma_free;

        h->dma_total_size = dma_size;
		h->dma_mode = 1;	/* default MPEG2-TS DMA mode */

        /* interrupt init */
		BITSET(pic_regs->MODE1, HwINT1_GPSB);	// level-trigger
		BITCLR(pic_regs->POL1, HwINT1_GPSB);	// active-high

		/* clear gpsb port config except used port (ch0, ch1) */
		//BITSET(gpsb_pcf_regs->PCFG0, Hw32-Hw16);	// GPS use ch2
		BITSET(gpsb_pcf_regs->PCFG1, Hw16-Hw0);

        if (h->id == 0) {
#if 1
			/* GPIO_C[31:29] - port 10(0xA) - TSIF only */
			BITCSET(gpio_regs->GPCFN3, Hw32-Hw20, Hw29|Hw25|Hw21);
			BITCSET(gpsb_pcf_regs->PCFG0, Hw8-Hw0, 0xA);
#else
            /* port config (SPI0 == DXB0, GPIO_D[8:5]) --- TODO:GPIO_C[31:29]*/
            BITCSET(gpio_regs->GPDFN0, Hw32-Hw20, Hw29|Hw25|Hw21);		// GPIOD[7:5]
			if (is_slave) {
            	BITCLR(gpio_regs->GPDFN1, Hw4-Hw0);						// for TSIF (GPIOD[8] is reset pin)
			} else {
				BITCSET(gpio_regs->GPDFN1, Hw4-Hw0, Hw1);				// for Master (GPIOD[8] is SDO1)
			}
            /* GPSB port config (channel 0 port mapping == 11) */
            BITCSET(gpsb_pcf_regs->PCFG0, Hw8-Hw0, 0xB);
#endif
        } else {
        	/* port config (SPI1 == DXB1) */
        	if (is_slave) {
				BITCSET(gpio_regs->GPEFN1, Hw12-Hw0, Hw9|Hw5|Hw1);		// for TSIF (GPIOE[10:8])
        	} else {
				BITCSET(gpio_regs->GPEFN1, Hw16-Hw0, Hw13|Hw9|Hw5|Hw1);	// for Master (GPIOE[11:8])
        	}
            /* GPSB port config (channel 1 port mapping == 4) */
			BITCSET(gpsb_pcf_regs->PCFG0, Hw16-Hw8, 0x400);
        }

        if (h->tea_dma_alloc) {
			if (h->tea_dma_alloc(&(h->rx_dma), dma_size) == 0) {
                if (is_slave) {
                    ret = 0;
                } else if (h->tea_dma_alloc(&(h->tx_dma), dma_size) == 0 && h->tea_dma_alloc(&(h->tx_dma_1), dma_size) == 0) {
                    ret = 0;
                }
            }
        } else {
        	/* Already, tsif has rx_dma buf */
        	ret = 0;
        }

        if (ret) { tca_spi_clean(h); }
    }
	
    return ret;
}

void tca_spi_clean(tca_spi_handle_t *h)
{
    if (h) {
        if (h->tea_dma_free) {
			h->tea_dma_free(&(h->tx_dma));
			h->tea_dma_free(&(h->rx_dma));
			h->tea_dma_free(&(h->tx_dma_1));
		}
        memset(h, 0, sizeof(tca_spi_handle_t));

		/* release GPIO */
		if (h->gpio_set == 0x1234) {
			#if defined(_LINUX_)
			volatile PGPIO gpio_regs = (volatile PGPIO)tcc_p2v(HwGPIO_BASE);
			#else
			PGPIO gpio_regs = (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
			#endif

			if (h->id == 0) {
#if 1
				/* GPIO_C[31:29] set "GPIO output low" */
				BITCLR(gpio_regs->GPCFN3, Hw32-Hw20);
				BITSET(gpio_regs->GPCEN, Hw31|Hw30|Hw29);
				BITCLR(gpio_regs->GPCDAT, Hw31|Hw30|Hw29);			
#else
	            /* port config (SPI0 == DXB0, GPIO_D[8:5]) */
	            BITCLR(gpio_regs->GPDFN0, Hw32-Hw20);	// GPIOD[7:5]
	            BITCLR(gpio_regs->GPDFN1, Hw4-Hw0);		// GPIOD[8]
				BITSET(gpio_regs->GPDEN, Hw8|Hw7|Hw6|Hw5);
				BITCLR(gpio_regs->GPDDAT, Hw8|Hw7|Hw6|Hw5);
#endif
	        } else {
	        	/* port config (SPI1 == DXB1) */
	        	if (h->is_slave) {
					BITCLR(gpio_regs->GPEFN1, Hw12-Hw0);	// for TSIF (GPIOE[10:8])
					BITSET(gpio_regs->GPEEN, Hw10|Hw9|Hw8);
					BITCLR(gpio_regs->GPEDAT, Hw10|Hw9|Hw8);
	        	} else {
					BITCLR(gpio_regs->GPEFN1, Hw16-Hw0);	// for Master (GPIOE[11:8])
					BITSET(gpio_regs->GPEEN, Hw11|Hw10|Hw9|Hw8);
					BITCLR(gpio_regs->GPEDAT, Hw11|Hw10|Hw9|Hw8);
	        	}
	        }
		}
    }
}

#if defined(_LINUX_)
EXPORT_SYMBOL(tca_spi_init);
EXPORT_SYMBOL(tca_spi_clean);
#endif
