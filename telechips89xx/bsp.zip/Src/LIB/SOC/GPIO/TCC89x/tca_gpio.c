/****************************************************************************
*   FileName    : tca_gpio.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/
#include <bsp.h>
#include "tca_gpio.h"

/************************************************************************************************
* Global Handle
************************************************************************************************/

/************************************************************************************************
* Global Variable define
************************************************************************************************/

/************************************************************************************************
* Global Defines
************************************************************************************************/
/************************************************************************************************
* FUNCTION		: int tca_getvirtualaddress()
*
* DESCRIPTION	: 
*
************************************************************************************************/
unsigned int tea_allocbaseaddress(unsigned int iphysicalbaseaddress, unsigned int isize)
{
	PHYSICAL_ADDRESS pa;
	pa.LowPart = (unsigned int)(iphysicalbaseaddress);

	return (unsigned int)MmMapIoSpace(pa, isize, FALSE); 
}

/************************************************************************************************
* FUNCTION		: int tca_getvirtualaddress()
*
* DESCRIPTION	: 
*
************************************************************************************************/
unsigned int tca_allocbaseaddress(unsigned int iphysicalbaseaddress, unsigned int isize)
{
	
	return tea_allocbaseaddress( iphysicalbaseaddress, isize);
}


/************************************************************************************************
* FUNCTION		: int tca_freebaseaddress()
*
* DESCRIPTION	: 
*
************************************************************************************************/
int tea_freebaseaddress(unsigned int ivirtualbaseaddress, unsigned int isize)
{
	MmUnmapIoSpace(&ivirtualbaseaddress, isize);
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: int tca_getvirtualaddress()
*
* DESCRIPTION	: 
*
************************************************************************************************/
unsigned int tca_freebaseaddress(unsigned int ivirtualbaseaddress, unsigned int  isize)
{
	
	return tea_freebaseaddress(ivirtualbaseaddress, isize);
}


/************************************************************************************************
* FUNCTION		: int tea_setchangemode()
*
* DESCRIPTION	: 
*
************************************************************************************************/
int tea_setchangemode(void * devhandle, char * pbuffer, unsigned int isize)
{
	unsigned int retBytes;

	WriteFile(  devhandle,   pbuffer, isize, &retBytes,NULL);

	return retBytes;
}

/************************************************************************************************
* FUNCTION		: int tca_setchangemode()
*
* DESCRIPTION	: 
*
************************************************************************************************/
unsigned int tca_setchangemode(void * devhandle, char * pbuffer, unsigned int isize)
{
	
	return tea_setchangemode( devhandle, pbuffer, isize);
}

