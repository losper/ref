
/****************************************************************************
 *   FileName    : tca_backlight.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
/*****************************************************************************
*
* Header Files Include
*
******************************************************************************/
#include "bsp.h"
#include "tca_backlight.h"

/*****************************************************************************
*
* Defines
*
******************************************************************************/
#define BKL_LEVEL_MAX	(50)
/*****************************************************************************
*
* structures
*
******************************************************************************/

/*****************************************************************************
*
* Variables
*
******************************************************************************/

/*****************************************************************************
*
* Functions
*
******************************************************************************/

/*****************************************************************************
* Function Name : tca_bkl_init()
******************************************************************************/
void tca_bkl_init(unsigned int tmr_vaddr, unsigned int gpio_vaddr)
{
	PTIMER vTimerAddr = (PTIMER) tmr_vaddr;
	PGPIO vGpioAddr = (PGPIO) gpio_vaddr;

	vTimerAddr->TCFG3 = 0x124;
	vTimerAddr->TREF3 = BKL_LEVEL_MAX;
	vTimerAddr->TMREF3= BKL_LEVEL_MAX;
	vTimerAddr->TCFG3 = 0x125;
	
	BITCSET(vGpioAddr->GPAFN0, Hw32-Hw28, Hw29);
	BITSET(vGpioAddr->GPAEN,Hw7);
	BITSET(vGpioAddr->GPADAT,Hw7);
}

/*****************************************************************************
* Function Name : tca_bkl_powerup()
******************************************************************************/
void tca_bkl_powerup(unsigned int tmr_vaddr, unsigned int gpio_vaddr)
{

	//PTIMER vTimerAddr = (PTIMER) tmr_vaddr;
	PGPIO vGpioAddr = (PGPIO) gpio_vaddr;

	BITCSET(vGpioAddr->GPAFN0,Hw32-Hw28,Hw29);//set GPIO_A7 as TCO0 Mode
	BITSET(vGpioAddr->GPAEN,Hw7);
	BITSET(vGpioAddr->GPADAT,Hw7);
}

/*****************************************************************************
* Function Name : tca_bkl_powerdown()
******************************************************************************/
void tca_bkl_powerdown(unsigned int tmr_vaddr, unsigned int gpio_vaddr)
{

	//PTIMER vTimerAddr = (PTIMER) tmr_vaddr;
	PGPIO vGpioAddr = (PGPIO) gpio_vaddr;

	//BL ON/OFF config
	BITCLR(vGpioAddr->GPAFN0,Hw32-Hw28);//set GPIO_A7 as TCO0 Mode
	BITSET(vGpioAddr->GPAEN,Hw7);
	BITCLR(vGpioAddr->GPADAT,Hw7);
}


/*****************************************************************************
* Function Name : tca_bkl_setpowerval()
******************************************************************************/
void tca_bkl_setpowerval(int inValue, unsigned int tmr_vaddr)
{
	PTIMER vTimerAddr = (PTIMER) tmr_vaddr;
	
	if(inValue <= 0)
		inValue=1;

	if(inValue > 100)
		inValue=100;

	vTimerAddr->TMREF3 = (BKL_LEVEL_MAX*inValue)/100;
}


/*****************************************************************************
* Function Name : tca_bkl_getpowerval()
******************************************************************************/
int tca_bkl_getpowerval(unsigned int tmr_vaddr)
{
	int outValue=0;
	PTIMER vTimerAddr = (PTIMER) tmr_vaddr;

	outValue = (int)((100*vTimerAddr->TMREF3)/BKL_LEVEL_MAX);

	return outValue;
}

/*****************************************************************************
* Function Name : tca_bkl_getpowerval()
******************************************************************************/
int tca_bkl_gettmrref(unsigned int tmr_vaddr)
{
	int tmrref=0;
	PTIMER vTimerAddr = (PTIMER) tmr_vaddr;

	tmrref = vTimerAddr->TMREF3;
	
	return tmrref;
}
