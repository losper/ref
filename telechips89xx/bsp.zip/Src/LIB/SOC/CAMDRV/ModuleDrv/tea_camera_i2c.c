/****************************************************************************
*   FileName    : camera_i2c.c
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/

/*****************************************************************************
*
* Header Files Include
*
******************************************************************************/
#include "tea_camera_i2c.h"
#include "tcc_gpioexp.h"
#include "ioctl_code.h"
/*****************************************************************************
*
* Defines
*
******************************************************************************/

/*****************************************************************************
*
* Enum
*
******************************************************************************/

/*****************************************************************************
*
* Type Defines
*
******************************************************************************/

/*****************************************************************************
*
* Structures
*
******************************************************************************/

/*****************************************************************************
*
* External Variables
*
******************************************************************************/

/*****************************************************************************
*
* Global Variables
*
******************************************************************************/
HANDLE ghCamI2C;



/*****************************************************************************
*
* Local Functions
*
******************************************************************************/
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tea_timedelay(int ticks){
	volatile int ms;
	while(ticks --){
		ms = 2000;
		while(ms --);
	}
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tea_openi2c(void)
{
	return;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tea_closei2c(void)
{
	return;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int	tea_initializei2c(void)
{
		ghCamI2C =  CreateFile(L"I2C1:",
			GENERIC_READ | GENERIC_WRITE,
			0,
			0,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			0);
	if(!ghCamI2C)
		RETAILMSG(1,(TEXT("[CAMDRV		]ERROR: Can't open I2C Driver for Camera!!\n")));
	return 0;
}

int tea_deiniti2c(void)
{
	if(ghCamI2C)
		CloseHandle(ghCamI2C);
	return 0;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int	tea_terminatei2c(void)
{
	if(ghCamI2C)
		CloseHandle(ghCamI2C);
	return 0;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int	tea_writei2c(unsigned int uiFlag, unsigned int uiHbyte, unsigned int uiLbyte)
{
	int iReturn = 0;
	DWORD Contents = 0;
	BOOL nRet;
	DWORD returned_bytes;
	I2C_Param sendParam;
        						
	if(uiFlag == I2C_CAMERA)
	{
#if defined(_MT9D112_)
		Contents |= (uiLbyte&0x000000FF)<<24;
		Contents |= (uiLbyte&0x0000FF00)<<8; // Data
		Contents |= (uiHbyte&0x000000FF)<<8;
		Contents |= (uiHbyte&0x0000FF00)>>8; // Address
#else
		Contents |= (uiLbyte&0x00FF)<<16;
		Contents |= (uiLbyte&0xFF00);
		Contents |= (uiHbyte&0xFF);
#endif	
		sendParam.DeviceAddr = (BYTE)CAM_WRADR; //uiHbyte;
		sendParam.nMode = 0;
#if defined(_MT9D112_)		
		sendParam.nWriteByte = 4;
#else
		sendParam.nWriteByte = 3;
#endif
		sendParam.pWriteBuffer =(BYTE *)&Contents;//ucSzDataBuff;
		sendParam.nPort = 0;
		sendParam.nTimeout	 = 100;

		nRet = DeviceIoControl(ghCamI2C,
			IOCTL_I2C_WRITE,
			&sendParam,
			sizeof(I2C_Param),
			0,
			0,
			&returned_bytes,
			0) ;

	}
	return 0;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int	tea_camera_readi2c(unsigned int uiFlag, unsigned int uiHbyte, unsigned int uiLbyte)
{
	int iReturn = 0;
	DWORD Contents = 0;
	BOOL nRet;
	DWORD returned_bytes;
	I2C_Param sendParam;
	RetParam  recvParam;
	unsigned short recvData = 0;
	unsigned short buffer = 0;
	
								
	if(uiFlag == I2C_CAMERA)
	{
#if defined(_MT9D112_)
		Contents |= (uiHbyte&0x000000FF)<<8;
		Contents |= (uiHbyte&0x0000FF00)>>8; // Address
#else
		Contents |= (uiHbyte&0xFF);
#endif			
	
		sendParam.DeviceAddr = (BYTE)CAM_WRADR; //uiHbyte;
		sendParam.nMode = 1;
#if defined(_MT9D112_)		
		sendParam.nWriteByte = 2;
#else
		sendParam.nWriteByte = 1;
#endif
		sendParam.pWriteBuffer =(BYTE *)&Contents;//ucSzDataBuff;
		sendParam.nPort = 0;
		sendParam.nTimeout	 = 100;
		sendParam.nReadByte  = 2;
		sendParam.pReadBuffer= &buffer;

		recvParam.pReadBuffer = &recvData;

		nRet = DeviceIoControl(ghCamI2C,
			IOCTL_I2C_READ,
			&sendParam,
			sizeof(I2C_Param),
			&recvParam,
			sizeof(RetParam),
			&returned_bytes,
			0) ;

		recvData = 0;
		recvData += buffer<<8;
		recvData += buffer>>8;

	}

	if(nRet)
	{
		return recvData;
	}
	else 
	{
		RETAILMSG(1,(TEXT("[CAMDRV      ]iic error:\n"),nRet));
		return 0;
	}
}

int tea_cam_readi2c(unsigned int uiAddr, unsigned int uiData)
{
	return tea_camera_readi2c(I2C_CAMERA, uiAddr, uiData);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tea_cam_writei2c(unsigned int uiAddr, unsigned int uiData)
{
	unsigned int uiReadValue;
	
	tea_writei2c(I2C_CAMERA, uiAddr, uiData);
#if 0
	uiReadValue = tea_cam_readi2c(uiAddr, 0x00);
	if(uiData != uiReadValue)
	{
		RETAILMSG(1,(TEXT("[CAMDRV ghCamI2C=0x%x]tea_cam_writei2c error - addr: 0x%x, value: 0x%x, read value:0x%x I2C ERROR Dev Addr: 0x%x!!!!!!!!!!!!!!!!!!\r\n"
			),ghCamI2C,uiAddr, uiData, uiReadValue, CAM_WRADR));
	}
#endif	
}

void tec_gpioexp_setcampwrctl(int pwrctl_onoff)
{
	HANDLE hGXP; // ����̹� �ڵ�
	DWORD	ret;
	DWORD	dwByteReturned;
	GXPINFO    GxpInfo; // Expander �������� ����ü
	BYTE	GxpData[5]; // PCA9539_H, PCA9539_L, PCA9538 ������ 2B,2B,1B
	
	hGXP = CreateFile(L"GXP1:",
			GENERIC_READ | GENERIC_WRITE,
			NULL,
			NULL,
			OPEN_ALWAYS,
			FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,
			NULL);
	
	if(!hGXP)
		RETAILMSG(1,(TEXT("[CAMDRV 	]ERROR: Driver: Can't open GXP Driver - codec pwr control!!\n")));

	GxpInfo.uiDevice = PCA9539LOW; // GPIO Expander Device
	GxpInfo.uiPort = CAM;

	if(pwrctl_onoff)
		GxpInfo.uiState = ON;
	else
		GxpInfo.uiState = OFF;
	
	ret = WriteFile(  hGXP,  &GxpInfo,	sizeof(GxpInfo),   &dwByteReturned,  NULL);
	CloseHandle(hGXP);

	tea_timedelay(1000);
}

/* end of file */

