

/****************************************************************************
*   FileName    : camera_i2c.h
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/
#ifndef __TEA_CAMI2C_H__
#define __TEA_CAMI2C_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>
#include <types.h>
#include "../../../../drivers/i2c1/TCC_I2C.h"

/*****************************************************************************
*
* Defines
*
******************************************************************************/
#if defined(_MT9D112_)
#define 	CAM_RDADR			0x7B
#define 	CAM_WRADR			0x7A
#else
!error
#endif

#define 	I2C_WR				0
#define 	I2C_RD				1


/*****************************************************************************
*
* Enum
*
******************************************************************************/
enum 
{
	I2C_CODEC,
	I2C_FM,
	I2C_CAMERA,
	I2C_TVOUT,
	I2C_MAX_VECTOR
} ;

/*****************************************************************************
*
* Type Defines
*
******************************************************************************/

/*****************************************************************************
*
* Structures
*
******************************************************************************/

/*****************************************************************************
*
* External Variables
*
******************************************************************************/

/*****************************************************************************
*
* External Functions
*
******************************************************************************/
int		tea_initializei2c(void);
int		tea_deiniti2c(void);
int		tea_terminatei2c(void);
int		tea_writei2c(unsigned int uiFlag, unsigned int uiHbyte, unsigned int uiLbyte);
int		tea_readi2c(unsigned int uiFlag, unsigned int uiHbyte, unsigned int uiLbyte);
void	tea_cam_writei2c(unsigned int uiAddr, unsigned int uiData);
void	tea_timedelay(int ticks);
void 	tea_gpioexp_setcampwrctl(int pwrctl_onoff);
#ifdef __cplusplus
} 
#endif

#endif	//__TEA_CAMI2C_H__

