/****************************************************************************
*   FileName    : tca_sensor_micron_MT9D111.c
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/
#include "bsp.h"
#if defined(_MT9D112_)
#include "tca_mt9d112.h"
#endif

static void delayLoop(int count)
{
	volatile int j,k;
	for(j = 0; j < count; j++)
	{
		for(k=0;k<100000;k++);
	}
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	: 
* Parameter 	: 
* Return		: 
* Note			: 
******************************************************************************/
int tcc_camsensor_initi2c(void)
{
	return tea_initializei2c();
}

int tcc_camsensor_deiniti2c(void)
{
	return tea_deiniti2c();
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tcc_camsensor_capture(unsigned char ucOnOff)
{
#if defined(_MT9D112_)	
	tca_mt9d112_capture(ucOnOff);
#endif
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tcc_camsensor_cameramoduleinit(unsigned char ucPreviewMode)
{
	tca_mt9d112_moduleinit(ucPreviewMode);
}

void tcc_gpioexp_setcampwrctl(int pwrctl_onoff)
{
	tec_gpioexp_setcampwrctl(pwrctl_onoff);
}

void tcc_camreset_onoff(void *pGPIORegAddr, unsigned int uiON)
{
#if defined(_MT9D112_)	
	tca_mt9d112_camresetonoff(pGPIORegAddr, uiON);
#endif
}

unsigned int tcc_cam_checki2s(void)
{
#if defined(_MT9D112_)		
	return tca_mt9d112_checki2s();
#else
	return TRUE;
#endif
}

/* end of file */
