/****************************************************************************
*   FileName    : tca_sensor_micron_MT9D111.c
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/

#include "tca_sensor_micron_MT9D111.h"
#include "../tea_camera_i2c.h"

#undef	NULL
#define NULL	0

static SENSOR_DATA Preview_800x600_30fps[] = 
{
	{0xf0, 0x0000},		// set page 0

	{0x05, 0x011E},		// HORZ_BLANK_B
	{0x06, 0x000B},		// VERT_BLANK_B
	{0x07, 0x01D6},     // HORZ_BLANK_A
	{0x08, 0x000B},     // VERT_BLANK_A
	{0x20, 0x0300},     // READ_MODE_B
	{0x21, 0x8000},     // READ_MODE_A
	#ifdef _TEST_33FPS_
	{0x66, 0x520C},     // PLL_REG
	#else
	//{0x66, 0x400A},   // PLL_REG
	{0x66, 0x1802},     // PLL_REG
	#endif
	{0x67, 0x500},      // PLL2_REG
	{0x65, 0xA000},     // CLOCK_ENABLING
	{0x65, 0x2000},     // CLOCK_ENABLING

	{CAMDLY, 50},	    // Delay 500ms
	
	{0xF0, 0x0001},
	{0xC6, 0xA122},        {0xC8, 0x0001},    //SEQ_PREVIEW_0_AE
	{0xC6, 0xA123},        {0xC8, 0x0000},    //SEQ_PREVIEW_0_FD
	{0xC6, 0xA124},        {0xC8, 0x0001},    //SEQ_PREVIEW_0_AWB
	{0xC6, 0xA125},        {0xC8, 0x0000},    //SEQ_PREVIEW_0_AF
	{0xC6, 0xA126},        {0xC8, 0x0001},    //SEQ_PREVIEW_0_HG
	{0xC6, 0xA127},        {0xC8, 0x0000},    //SEQ_PREVIEW_0_FLASH
	{0xC6, 0xA128},        {0xC8, 0x0000},    //SEQ_PREVIEW_0_SKIPFRAME
	{0xC6, 0xA129},        {0xC8, 0x0003},    //SEQ_PREVIEW_1_AE
	{0xC6, 0xA12A},        {0xC8, 0x0002},    //SEQ_PREVIEW_1_FD
	{0xC6, 0xA12B},        {0xC8, 0x0003},    //SEQ_PREVIEW_1_AWB
	{0xC6, 0xA12C},        {0xC8, 0x0000},    //SEQ_PREVIEW_1_AF
	{0xC6, 0xA12D},        {0xC8, 0x0003},    //SEQ_PREVIEW_1_HG
	{0xC6, 0xA12E},        {0xC8, 0x0000},    //SEQ_PREVIEW_1_FLASH
	{0xC6, 0xA12F},        {0xC8, 0x0000},    //SEQ_PREVIEW_1_SKIPFRAME
	{0xC6, 0xA130},        {0xC8, 0x0004},    //SEQ_PREVIEW_2_AE
	{0xC6, 0xA131},        {0xC8, 0x0000},    //SEQ_PREVIEW_2_FD
	{0xC6, 0xA132},        {0xC8, 0x0001},    //SEQ_PREVIEW_2_AWB
	{0xC6, 0xA133},        {0xC8, 0x0000},    //SEQ_PREVIEW_2_AF
	{0xC6, 0xA134},        {0xC8, 0x0001},    //SEQ_PREVIEW_2_HG
	{0xC6, 0xA135},        {0xC8, 0x0000},    //SEQ_PREVIEW_2_FLASH
	{0xC6, 0xA136},        {0xC8, 0x0000},    //SEQ_PREVIEW_2_SKIPFRAME
	{0xC6, 0xA137},        {0xC8, 0x0000},    //SEQ_PREVIEW_3_AE
	{0xC6, 0xA138},        {0xC8, 0x0000},    //SEQ_PREVIEW_3_FD
	{0xC6, 0xA139},        {0xC8, 0x0000},    //SEQ_PREVIEW_3_AWB
	{0xC6, 0xA13A},        {0xC8, 0x0000},    //SEQ_PREVIEW_3_AF
	{0xC6, 0xA13B},        {0xC8, 0x0000},    //SEQ_PREVIEW_3_HG
	{0xC6, 0xA13C},        {0xC8, 0x0000},    //SEQ_PREVIEW_3_FLASH
	{0xC6, 0xA13D},        {0xC8, 0x0000},    //SEQ_PREVIEW_3_SKIPFRAME

	{0xC6, 0x2703},        {0xC8, 0x0320},    //MODE_OUTPUT_WIDTH_A
	{0xC6, 0x2705},        {0xC8, 0x0258},    //MODE_OUTPUT_HEIGHT_A
	{0xC6, 0x2707},        {0xC8, 0x0640},    //MODE_OUTPUT_WIDTH_B
	{0xC6, 0x2709},        {0xC8, 0x04B0},    //MODE_OUTPUT_HEIGHT_B
	{0xC6, 0x270B},        {0xC8, 0x0030},    //MODE_CONFIG
	{0xC6, 0x270F},        {0xC8, 0x001C},    //MODE_SENSOR_ROW_START_A
	{0xC6, 0x2711},        {0xC8, 0x003C},    //MODE_SENSOR_COL_START_A
	{0xC6, 0x2713},        {0xC8, 0x04B0},    //MODE_SENSOR_ROW_HEIGHT_A
	{0xC6, 0x2715},        {0xC8, 0x0640},    //MODE_SENSOR_COL_WIDTH_A

	//{0xC6, 0x2717},        {0xC8, 0x01AC},    //MODE_SENSOR_X_DELAY_A
	{0xC6, 0x2717},        {0xC8, 0x000},    //MODE_SENSOR_EXTRA_DELAY_A

	{0xC6, 0x2719},        {0xC8, 0x0011},    //MODE_SENSOR_ROW_SPEED_A
	{0xC6, 0x271B},        {0xC8, 0x001C},    //MODE_SENSOR_ROW_START_B
	{0xC6, 0x271D},        {0xC8, 0x003C},    //MODE_SENSOR_COL_START_B
	{0xC6, 0x271F},        {0xC8, 0x04B0},    //MODE_SENSOR_ROW_HEIGHT_B
	{0xC6, 0x2721},        {0xC8, 0x0640},    //MODE_SENSOR_COL_WIDTH_B

	//{0xC6, 0x2723},        {0xC8, 0x0359},    //MODE_SENSOR_X_DELAY_B
	{0xC6, 0x2723},        {0xC8, 0x0000},    //MODE_SENSOR_EXTRA_DELAY_B

	{0xC6, 0x2725},        {0xC8, 0x0011},    //MODE_SENSOR_ROW_SPEED_B
	{0xC6, 0x2727},        {0xC8, 0x0000},    //MODE_CROP_X0_A
	{0xC6, 0x2729},        {0xC8, 0x0320},    //MODE_CROP_X1_A
	{0xC6, 0x272B},        {0xC8, 0x0000},    //MODE_CROP_Y0_A
	{0xC6, 0x272D},        {0xC8, 0x0258},    //MODE_CROP_Y1_A
	{0xC6, 0x2735},        {0xC8, 0x0000},    //MODE_CROP_X0_B
	{0xC6, 0x2737},        {0xC8, 0x0640},    //MODE_CROP_X1_B
	{0xC6, 0x2739},        {0xC8, 0x0000},    //MODE_CROP_Y0_B
	{0xC6, 0x273B},        {0xC8, 0x04B0},    //MODE_CROP_Y1_B
	// Gamma
	{0xC6, 0xA743},        {0xC8, 0x0042},    //MODE_GAM_CONT_A
	{0xC6, 0xA744},        {0xC8, 0x0042},    //MODE_GAM_CONT_B
	{0xC6, 0xA745},        {0xC8, 0x0000},    //MODE_GAM_TABLE_A_0
	{0xC6, 0xA746},        {0xC8, 0x0009},    //MODE_GAM_TABLE_A_1
	{0xC6, 0xA747},        {0xC8, 0x0012},    //MODE_GAM_TABLE_A_2
	{0xC6, 0xA748},        {0xC8, 0x0025},    //MODE_GAM_TABLE_A_3
	{0xC6, 0xA749},        {0xC8, 0x0045},    //MODE_GAM_TABLE_A_4
	{0xC6, 0xA74A},        {0xC8, 0x0061},    //MODE_GAM_TABLE_A_5
	{0xC6, 0xA74B},        {0xC8, 0x0075},    //MODE_GAM_TABLE_A_6
	{0xC6, 0xA74C},        {0xC8, 0x0086},    //MODE_GAM_TABLE_A_7
	{0xC6, 0xA74D},        {0xC8, 0x0094},    //MODE_GAM_TABLE_A_8
	{0xC6, 0xA74E},        {0xC8, 0x00A1},    //MODE_GAM_TABLE_A_9
	{0xC6, 0xA74F},        {0xC8, 0x00AE},    //MODE_GAM_TABLE_A_10
	{0xC6, 0xA750},        {0xC8, 0x00B9},    //MODE_GAM_TABLE_A_11
	{0xC6, 0xA751},        {0xC8, 0x00C4},    //MODE_GAM_TABLE_A_12
	{0xC6, 0xA752},        {0xC8, 0x00CF},    //MODE_GAM_TABLE_A_13
	{0xC6, 0xA753},        {0xC8, 0x00D9},    //MODE_GAM_TABLE_A_14
	{0xC6, 0xA754},        {0xC8, 0x00E3},    //MODE_GAM_TABLE_A_15
	{0xC6, 0xA755},        {0xC8, 0x00ED},    //MODE_GAM_TABLE_A_16
	{0xC6, 0xA756},        {0xC8, 0x00F6},    //MODE_GAM_TABLE_A_17
	{0xC6, 0xA757},        {0xC8, 0x00FF},    //MODE_GAM_TABLE_A_18
	{0xC6, 0xA758},        {0xC8, 0x0000},    //MODE_GAM_TABLE_B_0
	{0xC6, 0xA759},        {0xC8, 0x0009},    //MODE_GAM_TABLE_B_1
	{0xC6, 0xA75A},        {0xC8, 0x0012},    //MODE_GAM_TABLE_B_2
	{0xC6, 0xA75B},        {0xC8, 0x0025},    //MODE_GAM_TABLE_B_3
	{0xC6, 0xA75C},        {0xC8, 0x0045},    //MODE_GAM_TABLE_B_4
	{0xC6, 0xA75D},        {0xC8, 0x0061},    //MODE_GAM_TABLE_B_5
	{0xC6, 0xA75E},        {0xC8, 0x0075},    //MODE_GAM_TABLE_B_6
	{0xC6, 0xA75F},        {0xC8, 0x0086},    //MODE_GAM_TABLE_B_7
	{0xC6, 0xA760},        {0xC8, 0x0094},    //MODE_GAM_TABLE_B_8
	{0xC6, 0xA761},        {0xC8, 0x00A1},    //MODE_GAM_TABLE_B_9
	{0xC6, 0xA762},        {0xC8, 0x00AE},    //MODE_GAM_TABLE_B_10
	{0xC6, 0xA763},        {0xC8, 0x00B9},    //MODE_GAM_TABLE_B_11
	{0xC6, 0xA764},        {0xC8, 0x00C4},    //MODE_GAM_TABLE_B_12
	{0xC6, 0xA765},        {0xC8, 0x00CF},    //MODE_GAM_TABLE_B_13
	{0xC6, 0xA766},        {0xC8, 0x00D9},    //MODE_GAM_TABLE_B_14
	{0xC6, 0xA767},        {0xC8, 0x00E3},    //MODE_GAM_TABLE_B_15
	{0xC6, 0xA768},        {0xC8, 0x00ED},    //MODE_GAM_TABLE_B_16
	{0xC6, 0xA769},        {0xC8, 0x00F6},    //MODE_GAM_TABLE_B_17
	{0xC6, 0xA76A},        {0xC8, 0x00FF},    //MODE_GAM_TABLE_B_18

	{0xC6, 0x276D}, {0xC8, 0xE0E2},    //MODE_FIFO_CONF1_A
	{0xC6, 0xA76F}, {0xC8, 0x00E1},    //MODE_FIFO_CONF2_A
	{0xC6, 0x2774}, {0xC8, 0xE0E1},    //MODE_FIFO_CONF1_B
	{0xC6, 0xA776}, {0xC8, 0x00E1},    //MODE_FIFO_CONF2_B
	{0xC6, 0x220B}, {0xC8, 0x0000},    //AE_MAX_R12
	{0xC6, 0xA217}, {0xC8, 0x0008},    //AE_INDEX_TH23
	{0xC6, 0x2228}, {0xC8, 0x013D},    //AE_ROWTIME
	{0xC6, 0x222F}, {0xC8, 0x0000},    //AE_R9_STEP
	{0xC6, 0xA408}, {0xC8, 0x0FF},    //FD_SEARCH_F1_50
	{0xC6, 0xA409}, {0xC8, 0x001},    //FD_SEARCH_F2_50
	{0xC6, 0xA40A}, {0xC8, 0x0FF},    //FD_SEARCH_F1_60
	{0xC6, 0xA40B}, {0xC8, 0x001},    //FD_SEARCH_F2_60
	{0xC6, 0x2411}, {0xC8, 0x0000},    //FD_R9_STEP60
	{0xC6, 0x2413}, {0xC8, 0x0000},    //FD_R9_STEP50
	// Initial - Refresh
	{0xC6, 0xA103},        {0xC8, 0x005},    //SEQ_CMD

	{CAMDLY, 250},		// Delay 500ms
	{0xF0, 0x0001},
	{0xC6, 0xA103}, {0xC8, 0x0006},    //SEQ_CMD
	
    // Lens Shading
    {0xF0, 0x0002},
    {0x80, 0x01F0},     // LENS_CORRECTION_CONTROL
    {0x81, 0x6432},     // ZONE_BOUNDS_X1_X2
    {0x82, 0x3296},     // ZONE_BOUNDS_X0_X3
    {0x83, 0x9664},     // ZONE_BOUNDS_X4_X5
    {0x84, 0x5028},     // ZONE_BOUNDS_Y1_Y2
    {0x85, 0x2878},     // ZONE_BOUNDS_Y0_Y3
    {0x86, 0x7850},     // ZONE_BOUNDS_Y4_Y5
    {0x87, 0x0000},     // CENTER_OFFSET
    {0x88, 0x0107},     // FX_RED
    {0x8B, 0x00B6},     // FY_RED
    {0x8E, 0x091A},     // DF_DX_RED
    {0x91, 0x0A98},     // DF_DY_RED
    {0x94, 0xF615},     // SECOND_DERIV_ZONE_0_RED
    {0x97, 0x1F22},     // SECOND_DERIV_ZONE_1_RED
    {0x9A, 0x2D59},     // SECOND_DERIV_ZONE_2_RED
    {0x9D, 0x464B},     // SECOND_DERIV_ZONE_3_RED
    {0xA0, 0x4441},     // SECOND_DERIV_ZONE_4_RED
    {0xA3, 0x5446},     // SECOND_DERIV_ZONE_5_RED
    {0xA6, 0x0418},     // SECOND_DERIV_ZONE_6_RED
    {0xA9, 0xF723},     // SECOND_DERIV_ZONE_7_RED
    {0x89, 0x00C4},     // FX_GREEN
    {0x8C, 0x007B},     // FY_GREEN
    {0x8F, 0x09E1},     // DF_DX_GREEN
    {0x92, 0x0B1C},     // DF_DY_GREEN
    {0x95, 0x0B19},     // SECOND_DERIV_ZONE_0_GREEN
    {0x98, 0x1435},     // SECOND_DERIV_ZONE_1_GREEN
    {0x9B, 0x2646},     // SECOND_DERIV_ZONE_2_GREEN
    {0x9E, 0x3C36},     // SECOND_DERIV_ZONE_3_GREEN
    {0xA1, 0x3231},     // SECOND_DERIV_ZONE_4_GREEN
    {0xA4, 0x4032},     // SECOND_DERIV_ZONE_5_GREEN
    {0xA7, 0x0D25},     // SECOND_DERIV_ZONE_6_GREEN
    {0xAA, 0xBAD3},     // SECOND_DERIV_ZONE_7_GREEN
    {0x8A, 0x00BB},     // FX_BLUE
    {0x8D, 0x00A0},     // FY_BLUE
    {0x90, 0x0A11},     // DF_DX_BLUE
    {0x93, 0x0BCC},     // DF_DY_BLUE
    {0x96, 0x0E44},     // SECOND_DERIV_ZONE_0_BLUE
    {0x99, 0x0F2F},     // SECOND_DERIV_ZONE_1_BLUE
    {0x9C, 0x1D3E},     // SECOND_DERIV_ZONE_2_BLUE
    {0x9F, 0x3027},     // SECOND_DERIV_ZONE_3_BLUE
    {0xA2, 0x2725},     // SECOND_DERIV_ZONE_4_BLUE
    {0xA5, 0x3A24},     // SECOND_DERIV_ZONE_5_BLUE
    {0xA8, 0x0412},     // SECOND_DERIV_ZONE_6_BLUE
    {0xAB, 0xEF29},     // SECOND_DERIV_ZONE_7_BLUE
    {0xAC, 0x8018},     // X2_FACTORS
    {0xAD, 0x0000},     // GLOBAL_OFFSET_FXY_FUNCTION
    {0xAE, 0x0000},     // K_FACTOR_IN_K_FX_FY
    {0xF0, 0x0001},
    {0x08, 0x01FC},     // COLOR_PIPELINE_CONTROL
    // AE Target
    {0xC6, 0xA206},    //AE_TARGET
    {0xC8, 0x004A},    //AE_TARGET
    // AWB & CCM Param.
    {0xC6, 0x2306},    //AWB_CCM_L_0
    {0xC8, 0x0266},    //AWB_CCM_L_0
    {0xC6, 0x2308},    //AWB_CCM_L_1
    {0xC8, 0xFEA1},    //AWB_CCM_L_1
    {0xC6, 0x230A},    //AWB_CCM_L_2
    {0xC8, 0x0000},    //AWB_CCM_L_2
    {0xC6, 0x230C},    //AWB_CCM_L_3
    {0xC8, 0xFEDF},    //AWB_CCM_L_3
    {0xC6, 0x230E},    //AWB_CCM_L_4
    {0xC8, 0x0255},    //AWB_CCM_L_4
    {0xC6, 0x2310},    //AWB_CCM_L_5
    {0xC8, 0xFFD7},    //AWB_CCM_L_5
    {0xC6, 0x2312},    //AWB_CCM_L_6
    {0xC8, 0xFF31},    //AWB_CCM_L_6
    {0xC6, 0x2314},    //AWB_CCM_L_7
    {0xC8, 0xFD96},    //AWB_CCM_L_7
    {0xC6, 0x2316},    //AWB_CCM_L_8
    {0xC8, 0x046E},    //AWB_CCM_L_8
    {0xC6, 0x2318},    //AWB_CCM_L_9
    {0xC8, 0x0020},    //AWB_CCM_L_9
    {0xC6, 0x231A},    //AWB_CCM_L_10
    {0xC8, 0x0035},    //AWB_CCM_L_10
    {0xC6, 0x231C},    //AWB_CCM_RL_0
    {0xC8, 0xFF3C},    //AWB_CCM_RL_0
    {0xC6, 0x231E},    //AWB_CCM_RL_1
    {0xC8, 0x00B9},    //AWB_CCM_RL_1
    {0xC6, 0x2320},    //AWB_CCM_RL_2
    {0xC8, 0x0002},    //AWB_CCM_RL_2
    {0xC6, 0x2322},    //AWB_CCM_RL_3
    {0xC8, 0x00D4},    //AWB_CCM_RL_3
    {0xC6, 0x2324},    //AWB_CCM_RL_4
    {0xC8, 0xFF77},    //AWB_CCM_RL_4
    {0xC6, 0x2326},    //AWB_CCM_RL_5
    {0xC8, 0xFFE1},    //AWB_CCM_RL_5
    {0xC6, 0x2328},    //AWB_CCM_RL_6
    {0xC8, 0x00B4},    //AWB_CCM_RL_6
    {0xC6, 0x232A},    //AWB_CCM_RL_7
    {0xC8, 0x01D3},    //AWB_CCM_RL_7
    {0xC6, 0x232C},    //AWB_CCM_RL_8
    {0xC8, 0xFD3F},    //AWB_CCM_RL_8
    {0xC6, 0x232E},    //AWB_CCM_RL_9
    {0xC8, 0x000A},    //AWB_CCM_RL_9
    {0xC6, 0x2330},    //AWB_CCM_RL_10
    {0xC8, 0xFFF1},    //AWB_CCM_RL_10
    {0xC6, 0xA348},    //AWB_GAIN_BUFFER_SPEED
    {0xC8, 0x0008},    //AWB_GAIN_BUFFER_SPEED
    {0xC6, 0xA349},    //AWB_JUMP_DIVISOR
    {0xC8, 0x0002},    //AWB_JUMP_DIVISOR
    {0xC6, 0xA34A},    //AWB_GAIN_MIN
    {0xC8, 0x0053},    //AWB_GAIN_MIN
    {0xC6, 0xA34B},    //AWB_GAIN_MAX
    {0xC8, 0x00C0},    //AWB_GAIN_MAX
    {0xC6, 0xA34F},    //AWB_CCM_POSITION_MIN
    {0xC8, 0x0000},    //AWB_CCM_POSITION_MIN
    {0xC6, 0xA350},    //AWB_CCM_POSITION_MAX
    {0xC8, 0x007F},    //AWB_CCM_POSITION_MAX
    {0xC6, 0xA352},    //AWB_SATURATION
    {0xC8, 0x0090},    //AWB_SATURATION
    {0xC6, 0xA35B},    //AWB_STEADY_BGAIN_OUT_MIN
    {0xC8, 0x0073},    //AWB_STEADY_BGAIN_OUT_MIN
    {0xC6, 0xA35C},    //AWB_STEADY_BGAIN_OUT_MAX
    {0xC8, 0x008C},    //AWB_STEADY_BGAIN_OUT_MAX
    {0xC6, 0xA35D},    //AWB_STEADY_BGAIN_IN_MIN
    {0xC8, 0x007C},    //AWB_STEADY_BGAIN_IN_MIN
    {0xC6, 0xA35E},    //AWB_STEADY_BGAIN_IN_MAX
    {0xC8, 0x0083},    //AWB_STEADY_BGAIN_IN_MAX
    {0xC6, 0x235F},    //AWB_CNT_PXL_TH
    {0xC8, 0x0064},    //AWB_CNT_PXL_TH
    {0xC6, 0xA361},    //AWB_TG_MIN0
    {0xC8, 0x00E2},    //AWB_TG_MIN0
    {0xC6, 0xA362},    //AWB_TG_MAX0
    {0xC8, 0x00F6},    //AWB_TG_MAX0
    {0xC6, 0xA302},    //AWB_WINDOW_POS
    {0xC8, 0x0000},    //AWB_WINDOW_POS
    {0xC6, 0xA303},    //AWB_WINDOW_SIZE
    {0xC8, 0x00EF},    //AWB_WINDOW_SIZE
    {0xC6, 0xA103},    //SEQ_CMD
    {0xC8, 0x0005},    //SEQ_CMD

	{CAMDLY, 250},	// Delay 500ms

    {0xF0, 0x0002},    // 2 Page Select    
    // Context B YUV Output Setting
    {0xC6, 0x270B},     //MODE_CONFIG
    {0xC8, 0x0030},     //MODE_CONFIG
    {0xC6, 0xA77E},     //MODE_OUTPUT_FORMAT_B
    {0xC8, 0x0000},     //MODE_OUTPUT_FORMAT_B
    {0xC6, 0x2774},     //MODE_FIFO_CONF1_B
    {0xC8, 0xE5E1},     //MODE_FIFO_CONF1_B
    {0xC6, 0xA776},     //MODE_FIFO_CONF2_B
    {0xC8, 0x00E3},     //MODE_FIFO_CONF2_B
	    		
    {NULL, NULL}
};           


static SENSOR_DATA sensor_init1[] =
{
	{0xF0, 0x0000},
	{0x05, 0x012C},    // HORZ_BLANK_B
	{0x06, 0x004E},    // VERT_BLANK_B
	{0x07, 0x044C},     // HORZ_BLANK_A
	{0x08, 0x0023},     // VERT_BLANK_A

	{0x1f, 0x8000},	// margin
	
	{0x20, 0x0300},     // READ_MODE_B
	{0x21, 0x8000},     // READ_MODE_A
	{0x66, 0x1802},     // PLL_REG
	{0x67, 0x0501},     // PLL2_REG
	{0x65, 0xA000},     // CLOCK_ENABLING
	{NULL, NULL}    
};

static SENSOR_DATA sensor_init2[] = 
{	// MCU_ADDRESS & MCU_DATA_0 ~ 7
	{0x65, 0x2000},    // CLOCK_ENABLING
	// State Param.
	{0xF0, 0x0001},
	{0xC6, 0xA122},    //SEQ_PREVIEW_0_AE
	{0xC8, 0x0001},    //SEQ_PREVIEW_0_AE
	{0xC6, 0xA123},    //SEQ_PREVIEW_0_FD
	{0xC8, 0x0000},    //SEQ_PREVIEW_0_FD
	{0xC6, 0xA124},    //SEQ_PREVIEW_0_AWB
	{0xC8, 0x0001},    //SEQ_PREVIEW_0_AWB
	{0xC6, 0xA125},    //SEQ_PREVIEW_0_AF
	{0xC8, 0x0000},    //SEQ_PREVIEW_0_AF
	{0xC6, 0xA126},    //SEQ_PREVIEW_0_HG
	{0xC8, 0x0001},    //SEQ_PREVIEW_0_HG
	{0xC6, 0xA127},    //SEQ_PREVIEW_0_FLASH
	{0xC8, 0x0000},    //SEQ_PREVIEW_0_FLASH
	{0xC6, 0xA128},    //SEQ_PREVIEW_0_SKIPFRAME
	{0xC8, 0x0040},    //SEQ_PREVIEW_0_SKIPFRAME
	{0xC6, 0xA129},    //SEQ_PREVIEW_1_AE
	{0xC8, 0x0003},    //SEQ_PREVIEW_1_AE
	{0xC6, 0xA12A},    //SEQ_PREVIEW_1_FD
	{0xC8, 0x0002},    //SEQ_PREVIEW_1_FD
	{0xC6, 0xA12B},    //SEQ_PREVIEW_1_AWB
	{0xC8, 0x0003},    //SEQ_PREVIEW_1_AWB
	{0xC6, 0xA12C},    //SEQ_PREVIEW_1_AF
	{0xC8, 0x0000},    //SEQ_PREVIEW_1_AF
	{0xC6, 0xA12D},    //SEQ_PREVIEW_1_HG
	{0xC8, 0x0003},    //SEQ_PREVIEW_1_HG
	{0xC6, 0xA12E},    //SEQ_PREVIEW_1_FLASH
	{0xC8, 0x0000},    //SEQ_PREVIEW_1_FLASH
	{0xC6, 0xA12F},    //SEQ_PREVIEW_1_SKIPFRAME
	{0xC8, 0x0000},    //SEQ_PREVIEW_1_SKIPFRAME
	{0xC6, 0xA130},    //SEQ_PREVIEW_2_AE
	{0xC8, 0x0004},    //SEQ_PREVIEW_2_AE
	{0xC6, 0xA131},    //SEQ_PREVIEW_2_FD
	{0xC8, 0x0000},    //SEQ_PREVIEW_2_FD
	{0xC6, 0xA132},    //SEQ_PREVIEW_2_AWB
	{0xC8, 0x0001},    //SEQ_PREVIEW_2_AWB
	{0xC6, 0xA133},    //SEQ_PREVIEW_2_AF
	{0xC8, 0x0000},    //SEQ_PREVIEW_2_AF
	{0xC6, 0xA134},    //SEQ_PREVIEW_2_HG
	{0xC8, 0x0001},    //SEQ_PREVIEW_2_HG
	{0xC6, 0xA135},    //SEQ_PREVIEW_2_FLASH
	{0xC8, 0x0000},    //SEQ_PREVIEW_2_FLASH
	{0xC6, 0xA136},    //SEQ_PREVIEW_2_SKIPFRAME
	{0xC8, 0x0000},    //SEQ_PREVIEW_2_SKIPFRAME
	{0xC6, 0xA137},    //SEQ_PREVIEW_3_AE
	{0xC8, 0x0000},    //SEQ_PREVIEW_3_AE
	{0xC6, 0xA138},    //SEQ_PREVIEW_3_FD
	{0xC8, 0x0000},    //SEQ_PREVIEW_3_FD
	{0xC6, 0xA139},    //SEQ_PREVIEW_3_AWB
	{0xC8, 0x0000},    //SEQ_PREVIEW_3_AWB
	{0xC6, 0xA13A},    //SEQ_PREVIEW_3_AF
	{0xC8, 0x0000},    //SEQ_PREVIEW_3_AF
	{0xC6, 0xA13B},    //SEQ_PREVIEW_3_HG
	{0xC8, 0x0000},    //SEQ_PREVIEW_3_HG
	{0xC6, 0xA13C},    //SEQ_PREVIEW_3_FLASH
	{0xC8, 0x0000},    //SEQ_PREVIEW_3_FLASH
	{0xC6, 0xA13D},    //SEQ_PREVIEW_3_SKIPFRAME
	{0xC8, 0x0040},    //SEQ_PREVIEW_3_SKIPFRAME
	// Sensor Timing Setting (54MHz)
	{0xC6, 0x2703},    //MODE_OUTPUT_WIDTH_A
	{0xC8, 0x0320},    //MODE_OUTPUT_WIDTH_A
	{0xC6, 0x2705},    //MODE_OUTPUT_HEIGHT_A
	{0xC8, 0x0258},    //MODE_OUTPUT_HEIGHT_A
	{0xC6, 0x2707},    //MODE_OUTPUT_WIDTH_B
	{0xC8, 0x0640},    //MODE_OUTPUT_WIDTH_B
	{0xC6, 0x2709},    //MODE_OUTPUT_HEIGHT_B
	{0xC8, 0x04B0},    //MODE_OUTPUT_HEIGHT_B
	{0xC6, 0x270B},    //MODE_CONFIG
	{0xC8, 0x0030},    //MODE_CONFIG
	{0xC6, 0x270F},    //MODE_SENSOR_ROW_START_A
	{0xC8, 0x001C},    //MODE_SENSOR_ROW_START_A
	{0xC6, 0x2711},    //MODE_SENSOR_COL_START_A
	{0xC8, 0x003C},    //MODE_SENSOR_COL_START_A
	{0xC6, 0x2713},    //MODE_SENSOR_ROW_HEIGHT_A
	{0xC8, 0x04B0},    //MODE_SENSOR_ROW_HEIGHT_A
	{0xC6, 0x2715},    //MODE_SENSOR_COL_WIDTH_A
	{0xC8, 0x0640},    //MODE_SENSOR_COL_WIDTH_A
	{0xC6, 0x2717},    //MODE_SENSOR_X_DELAY_A
	{0xC8, 0x01AC},    //MODE_SENSOR_X_DELAY_A
	{0xC6, 0x2719},    //MODE_SENSOR_ROW_SPEED_A
	{0xC8, 0x0011},    //MODE_SENSOR_ROW_SPEED_A
	{0xC6, 0x271B},    //MODE_SENSOR_ROW_START_B
	{0xC8, 0x001C},    //MODE_SENSOR_ROW_START_B
	{0xC6, 0x271D},    //MODE_SENSOR_COL_START_B
	{0xC8, 0x003C},    //MODE_SENSOR_COL_START_B
	{0xC6, 0x271F},    //MODE_SENSOR_ROW_HEIGHT_B
	{0xC8, 0x04B0},    //MODE_SENSOR_ROW_HEIGHT_B
	{0xC6, 0x2721},    //MODE_SENSOR_COL_WIDTH_B
	{0xC8, 0x0640},    //MODE_SENSOR_COL_WIDTH_B
	{0xC6, 0x2723},    //MODE_SENSOR_X_DELAY_B
	{0xC8, 0x0359},    //MODE_SENSOR_X_DELAY_B
	{0xC6, 0x2725},    //MODE_SENSOR_ROW_SPEED_B
	{0xC8, 0x0011},    //MODE_SENSOR_ROW_SPEED_B
	{0xC6, 0x2727},    //MODE_CROP_X0_A
	{0xC8, 0x0000},    //MODE_CROP_X0_A
	{0xC6, 0x2729},    //MODE_CROP_X1_A
	{0xC8, 0x0320},    //MODE_CROP_X1_A
	{0xC6, 0x272B},    //MODE_CROP_Y0_A
	{0xC8, 0x0000},    //MODE_CROP_Y0_A
	{0xC6, 0x272D},    //MODE_CROP_Y1_A
	{0xC8, 0x0258},    //MODE_CROP_Y1_A
	{0xC6, 0x2735},    //MODE_CROP_X0_B
	{0xC8, 0x0000},    //MODE_CROP_X0_B
	{0xC6, 0x2737},    //MODE_CROP_X1_B
	{0xC8, 0x0640},    //MODE_CROP_X1_B
	{0xC6, 0x2739},    //MODE_CROP_Y0_B
	{0xC8, 0x0000},    //MODE_CROP_Y0_B
	{0xC6, 0x273B},    //MODE_CROP_Y1_B
	{0xC8, 0x04B0},    //MODE_CROP_Y1_B
	// Gamma
	{0xC6, 0xA743},    //MODE_GAM_CONT_A
	{0xC8, 0x0041},    //MODE_GAM_CONT_A
	{0xC6, 0xA744},    //MODE_GAM_CONT_B
	{0xC8, 0x0041},    //MODE_GAM_CONT_B
	{0xC6, 0xA745},    //MODE_GAM_TABLE_A_0
	{0xC8, 0x0000},    //MODE_GAM_TABLE_A_0
	{0xC6, 0xA746},    //MODE_GAM_TABLE_A_1
	{0xC8, 0x0009},    //MODE_GAM_TABLE_A_1
	{0xC6, 0xA747},    //MODE_GAM_TABLE_A_2
	{0xC8, 0x0012},    //MODE_GAM_TABLE_A_2
	{0xC6, 0xA748},    //MODE_GAM_TABLE_A_3
	{0xC8, 0x0025},    //MODE_GAM_TABLE_A_3
	{0xC6, 0xA749},    //MODE_GAM_TABLE_A_4
	{0xC8, 0x0045},    //MODE_GAM_TABLE_A_4
	{0xC6, 0xA74A},    //MODE_GAM_TABLE_A_5
	{0xC8, 0x0061},    //MODE_GAM_TABLE_A_5
	{0xC6, 0xA74B},    //MODE_GAM_TABLE_A_6
	{0xC8, 0x0075},    //MODE_GAM_TABLE_A_6
	{0xC6, 0xA74C},    //MODE_GAM_TABLE_A_7
	{0xC8, 0x0086},    //MODE_GAM_TABLE_A_7
	{0xC6, 0xA74D},    //MODE_GAM_TABLE_A_8
	{0xC8, 0x0094},    //MODE_GAM_TABLE_A_8
	{0xC6, 0xA74E},    //MODE_GAM_TABLE_A_9
	{0xC8, 0x00A1},    //MODE_GAM_TABLE_A_9
	{0xC6, 0xA74F},    //MODE_GAM_TABLE_A_10
	{0xC8, 0x00AE},    //MODE_GAM_TABLE_A_10
	{0xC6, 0xA750},    //MODE_GAM_TABLE_A_11
	{0xC8, 0x00B9},    //MODE_GAM_TABLE_A_11
	{0xC6, 0xA751},    //MODE_GAM_TABLE_A_12
	{0xC8, 0x00C4},    //MODE_GAM_TABLE_A_12
	{0xC6, 0xA752},    //MODE_GAM_TABLE_A_13
	{0xC8, 0x00CF},    //MODE_GAM_TABLE_A_13
	{0xC6, 0xA753},    //MODE_GAM_TABLE_A_14
	{0xC8, 0x00D9},    //MODE_GAM_TABLE_A_14
	{0xC6, 0xA754},    //MODE_GAM_TABLE_A_15
	{0xC8, 0x00E3},    //MODE_GAM_TABLE_A_15
	{0xC6, 0xA755},    //MODE_GAM_TABLE_A_16
	{0xC8, 0x00ED},    //MODE_GAM_TABLE_A_16
	{0xC6, 0xA756},    //MODE_GAM_TABLE_A_17
	{0xC8, 0x00F6},    //MODE_GAM_TABLE_A_17
	{0xC6, 0xA757},    //MODE_GAM_TABLE_A_18
	{0xC8, 0x00FF},    //MODE_GAM_TABLE_A_18
	{0xC6, 0xA758},    //MODE_GAM_TABLE_B_0
	{0xC8, 0x0000},    //MODE_GAM_TABLE_B_0
	{0xC6, 0xA759},    //MODE_GAM_TABLE_B_1
	{0xC8, 0x0009},    //MODE_GAM_TABLE_B_1
	{0xC6, 0xA75A},    //MODE_GAM_TABLE_B_2
	{0xC8, 0x0012},    //MODE_GAM_TABLE_B_2
	{0xC6, 0xA75B},    //MODE_GAM_TABLE_B_3
	{0xC8, 0x0025},    //MODE_GAM_TABLE_B_3
	{0xC6, 0xA75C},    //MODE_GAM_TABLE_B_4
	{0xC8, 0x0045},    //MODE_GAM_TABLE_B_4
	{0xC6, 0xA75D},    //MODE_GAM_TABLE_B_5
	{0xC8, 0x0061},    //MODE_GAM_TABLE_B_5
	{0xC6, 0xA75E},    //MODE_GAM_TABLE_B_6
	{0xC8, 0x0075},    //MODE_GAM_TABLE_B_6
	{0xC6, 0xA75F},    //MODE_GAM_TABLE_B_7
	{0xC8, 0x0086},    //MODE_GAM_TABLE_B_7
	{0xC6, 0xA760},    //MODE_GAM_TABLE_B_8
	{0xC8, 0x0094},    //MODE_GAM_TABLE_B_8
	{0xC6, 0xA761},    //MODE_GAM_TABLE_B_9
	{0xC8, 0x00A1},    //MODE_GAM_TABLE_B_9
	{0xC6, 0xA762},    //MODE_GAM_TABLE_B_10
	{0xC8, 0x00AE},    //MODE_GAM_TABLE_B_10
	{0xC6, 0xA763},    //MODE_GAM_TABLE_B_11
	{0xC8, 0x00B9},    //MODE_GAM_TABLE_B_11
	{0xC6, 0xA764},    //MODE_GAM_TABLE_B_12
	{0xC8, 0x00C4},    //MODE_GAM_TABLE_B_12
	{0xC6, 0xA765},    //MODE_GAM_TABLE_B_13
	{0xC8, 0x00CF},    //MODE_GAM_TABLE_B_13
	{0xC6, 0xA766},    //MODE_GAM_TABLE_B_14
	{0xC8, 0x00D9},    //MODE_GAM_TABLE_B_14
	{0xC6, 0xA767},    //MODE_GAM_TABLE_B_15
	{0xC8, 0x00E3},    //MODE_GAM_TABLE_B_15
	{0xC6, 0xA768},    //MODE_GAM_TABLE_B_16
	{0xC8, 0x00ED},    //MODE_GAM_TABLE_B_16
	{0xC6, 0xA769},    //MODE_GAM_TABLE_B_17
	{0xC8, 0x00F6},    //MODE_GAM_TABLE_B_17
	{0xC6, 0xA76A},    //MODE_GAM_TABLE_B_18
	{0xC8, 0x00FF},    //MODE_GAM_TABLE_B_18
	// AE Param.
	{0xC6, 0x276D},    //MODE_FIFO_CONF1_A
	{0xC8, 0xE0E2},    //MODE_FIFO_CONF1_A
	{0xC6, 0xA76F},    //MODE_FIFO_CONF2_A
	{0xC8, 0x00E1},    //MODE_FIFO_CONF2_A
	{0xC6, 0x2774},    //MODE_FIFO_CONF1_B
	{0xC8, 0xE0E1},    //MODE_FIFO_CONF1_B
	{0xC6, 0xA776},    //MODE_FIFO_CONF2_B
	{0xC8, 0x00E1},    //MODE_FIFO_CONF2_B
	{0xC6, 0x220B},    //AE_MAX_R12
	{0xC8, 0x024D},    //AE_MAX_R12
	{0xC6, 0xA217},    //AE_INDEX_TH23
	{0xC8, 0x0008},    //AE_INDEX_TH23
	{0xC6, 0x2228},    //AE_ROWTIME
	{0xC8, 0x01DB},    //AE_ROWTIME
	{0xC6, 0x222F},    //AE_R9_STEP
	{0xC8, 0x0075},    //AE_R9_STEP
	{0xC6, 0xA408},    //FD_SEARCH_F1_50
	{0xC8, 0x0016},    //FD_SEARCH_F1_50
	{0xC6, 0xA409},    //FD_SEARCH_F2_50
	{0xC8, 0x0018},    //FD_SEARCH_F2_50
	{0xC6, 0xA40A},    //FD_SEARCH_F1_60
	{0xC8, 0x001B},    //FD_SEARCH_F1_60
	{0xC6, 0xA40B},    //FD_SEARCH_F2_60
	{0xC8, 0x001D},    //FD_SEARCH_F2_60
	{0xC6, 0x2411},    //FD_R9_STEP60
	{0xC8, 0x0075},    //FD_R9_STEP60
	{0xC6, 0x2413},    //FD_R9_STEP50
	{0xC8, 0x008D},    //FD_R9_STEP50
	// Initial - Refresh
	{0xC6, 0xA103},    //SEQ_CMD
	{0xC8, 0x0005},    //SEQ_CMD
	{NULL, NULL}
};
         
/*	Flicker Set	*/
static SENSOR_DATA sensor_init3[] = 
{
	{0xF0, 0x0001},
	{0xC6, 0xA103}, {0xC8, 0x0006},    //SEQ_CMD
	{NULL, NULL}
};

/*	Lens Shading Correction	*/
static SENSOR_DATA sensor_init4_LensCorrect[] =
{
	// Lens Shading
	{0xF0, 0x0002},
	{0x80, 0x01F0},     // LENS_CORRECTION_CONTROL
	{0x81, 0x6432},     // ZONE_BOUNDS_X1_X2
	{0x82, 0x3296},     // ZONE_BOUNDS_X0_X3
	{0x83, 0x9664},     // ZONE_BOUNDS_X4_X5
	{0x84, 0x5028},     // ZONE_BOUNDS_Y1_Y2
	{0x85, 0x2878},     // ZONE_BOUNDS_Y0_Y3
	{0x86, 0x7850},     // ZONE_BOUNDS_Y4_Y5
	{0x87, 0x0000},     // CENTER_OFFSET
	{0x88, 0x0107},     // FX_RED
	{0x8B, 0x00B6},     // FY_RED
	{0x8E, 0x091A},     // DF_DX_RED
	{0x91, 0x0A98},     // DF_DY_RED
	{0x94, 0xF615},     // SECOND_DERIV_ZONE_0_RED
	{0x97, 0x1F22},     // SECOND_DERIV_ZONE_1_RED
	{0x9A, 0x2D59},     // SECOND_DERIV_ZONE_2_RED
	{0x9D, 0x464B},     // SECOND_DERIV_ZONE_3_RED
	{0xA0, 0x4441},     // SECOND_DERIV_ZONE_4_RED
	{0xA3, 0x5446},     // SECOND_DERIV_ZONE_5_RED
	{0xA6, 0x0418},     // SECOND_DERIV_ZONE_6_RED
	{0xA9, 0xF723},     // SECOND_DERIV_ZONE_7_RED
	{0x89, 0x00C4},     // FX_GREEN
	{0x8C, 0x007B},     // FY_GREEN
	{0x8F, 0x09E1},     // DF_DX_GREEN
	{0x92, 0x0B1C},     // DF_DY_GREEN
	{0x95, 0x0B19},     // SECOND_DERIV_ZONE_0_GREEN
	{0x98, 0x1435},     // SECOND_DERIV_ZONE_1_GREEN
	{0x9B, 0x2646},     // SECOND_DERIV_ZONE_2_GREEN
	{0x9E, 0x3C36},     // SECOND_DERIV_ZONE_3_GREEN
	{0xA1, 0x3231},     // SECOND_DERIV_ZONE_4_GREEN
	{0xA4, 0x4032},     // SECOND_DERIV_ZONE_5_GREEN
	{0xA7, 0x0D25},     // SECOND_DERIV_ZONE_6_GREEN
	{0xAA, 0xBAD3},     // SECOND_DERIV_ZONE_7_GREEN
	{0x8A, 0x00BB},     // FX_BLUE
	{0x8D, 0x00A0},     // FY_BLUE
	{0x90, 0x0A11},     // DF_DX_BLUE
	{0x93, 0x0BCC},     // DF_DY_BLUE
	{0x96, 0x0E44},     // SECOND_DERIV_ZONE_0_BLUE
	{0x99, 0x0F2F},     // SECOND_DERIV_ZONE_1_BLUE
	{0x9C, 0x1D3E},     // SECOND_DERIV_ZONE_2_BLUE
	{0x9F, 0x3027},     // SECOND_DERIV_ZONE_3_BLUE
	{0xA2, 0x2725},     // SECOND_DERIV_ZONE_4_BLUE
	{0xA5, 0x3A24},     // SECOND_DERIV_ZONE_5_BLUE
	{0xA8, 0x0412},     // SECOND_DERIV_ZONE_6_BLUE
	{0xAB, 0xEF29},     // SECOND_DERIV_ZONE_7_BLUE
	{0xAC, 0x8018},     // X2_FACTORS
	{0xAD, 0x0000},     // GLOBAL_OFFSET_FXY_FUNCTION
	{0xAE, 0x0000},     // K_FACTOR_IN_K_FX_FY
	{0xF0, 0x0001},
	{0x08, 0x01FC},     // COLOR_PIPELINE_CONTROL
	// AE Target
	{0xC6, 0xA206},    //AE_TARGET
	{0xC8, 0x004A},    //AE_TARGET
	// AWB & CCM Param.
	{0xC6, 0x2306},    //AWB_CCM_L_0
	{0xC8, 0x0266},    //AWB_CCM_L_0
	{0xC6, 0x2308},    //AWB_CCM_L_1
	{0xC8, 0xFEA1},    //AWB_CCM_L_1
	{0xC6, 0x230A},    //AWB_CCM_L_2
	{0xC8, 0x0000},    //AWB_CCM_L_2
	{0xC6, 0x230C},    //AWB_CCM_L_3
	{0xC8, 0xFEDF},    //AWB_CCM_L_3
	{0xC6, 0x230E},    //AWB_CCM_L_4
	{0xC8, 0x0255},    //AWB_CCM_L_4
	{0xC6, 0x2310},    //AWB_CCM_L_5
	{0xC8, 0xFFD7},    //AWB_CCM_L_5
	{0xC6, 0x2312},    //AWB_CCM_L_6
	{0xC8, 0xFF31},    //AWB_CCM_L_6
	{0xC6, 0x2314},    //AWB_CCM_L_7
	{0xC8, 0xFD96},    //AWB_CCM_L_7
	{0xC6, 0x2316},    //AWB_CCM_L_8
	{0xC8, 0x046E},    //AWB_CCM_L_8
	{0xC6, 0x2318},    //AWB_CCM_L_9
	{0xC8, 0x0020},    //AWB_CCM_L_9
	{0xC6, 0x231A},    //AWB_CCM_L_10
	{0xC8, 0x0035},    //AWB_CCM_L_10
	{0xC6, 0x231C},    //AWB_CCM_RL_0
	{0xC8, 0xFF3C},    //AWB_CCM_RL_0
	{0xC6, 0x231E},    //AWB_CCM_RL_1
	{0xC8, 0x00B9},    //AWB_CCM_RL_1
	{0xC6, 0x2320},    //AWB_CCM_RL_2
	{0xC8, 0x0002},    //AWB_CCM_RL_2
	{0xC6, 0x2322},    //AWB_CCM_RL_3
	{0xC8, 0x00D4},    //AWB_CCM_RL_3
	{0xC6, 0x2324},    //AWB_CCM_RL_4
	{0xC8, 0xFF77},    //AWB_CCM_RL_4
	{0xC6, 0x2326},    //AWB_CCM_RL_5
	{0xC8, 0xFFE1},    //AWB_CCM_RL_5
	{0xC6, 0x2328},    //AWB_CCM_RL_6
	{0xC8, 0x00B4},    //AWB_CCM_RL_6
	{0xC6, 0x232A},    //AWB_CCM_RL_7
	{0xC8, 0x01D3},    //AWB_CCM_RL_7
	{0xC6, 0x232C},    //AWB_CCM_RL_8
	{0xC8, 0xFD3F},    //AWB_CCM_RL_8
	{0xC6, 0x232E},    //AWB_CCM_RL_9
	{0xC8, 0x000A},    //AWB_CCM_RL_9
	{0xC6, 0x2330},    //AWB_CCM_RL_10
	{0xC8, 0xFFF1},    //AWB_CCM_RL_10
	{0xC6, 0xA348},    //AWB_GAIN_BUFFER_SPEED
	{0xC8, 0x0008},    //AWB_GAIN_BUFFER_SPEED
	{0xC6, 0xA349},    //AWB_JUMP_DIVISOR
	{0xC8, 0x0002},    //AWB_JUMP_DIVISOR
	{0xC6, 0xA34A},    //AWB_GAIN_MIN
	{0xC8, 0x0053},    //AWB_GAIN_MIN
	{0xC6, 0xA34B},    //AWB_GAIN_MAX
	{0xC8, 0x00C0},    //AWB_GAIN_MAX
	{0xC6, 0xA34F},    //AWB_CCM_POSITION_MIN
	{0xC8, 0x0000},    //AWB_CCM_POSITION_MIN
	{0xC6, 0xA350},    //AWB_CCM_POSITION_MAX
	{0xC8, 0x007F},    //AWB_CCM_POSITION_MAX
	{0xC6, 0xA352},    //AWB_SATURATION
	{0xC8, 0x0090},    //AWB_SATURATION
	{0xC6, 0xA35B},    //AWB_STEADY_BGAIN_OUT_MIN
	{0xC8, 0x0073},    //AWB_STEADY_BGAIN_OUT_MIN
	{0xC6, 0xA35C},    //AWB_STEADY_BGAIN_OUT_MAX
	{0xC8, 0x008C},    //AWB_STEADY_BGAIN_OUT_MAX
	{0xC6, 0xA35D},    //AWB_STEADY_BGAIN_IN_MIN
	{0xC8, 0x007C},    //AWB_STEADY_BGAIN_IN_MIN
	{0xC6, 0xA35E},    //AWB_STEADY_BGAIN_IN_MAX
	{0xC8, 0x0083},    //AWB_STEADY_BGAIN_IN_MAX
	{0xC6, 0x235F},    //AWB_CNT_PXL_TH
	{0xC8, 0x0064},    //AWB_CNT_PXL_TH
	{0xC6, 0xA361},    //AWB_TG_MIN0
	{0xC8, 0x00E2},    //AWB_TG_MIN0
	{0xC6, 0xA362},    //AWB_TG_MAX0
	{0xC8, 0x00F6},    //AWB_TG_MAX0
	{0xC6, 0xA302},    //AWB_WINDOW_POS
	{0xC8, 0x0000},    //AWB_WINDOW_POS
	{0xC6, 0xA303},    //AWB_WINDOW_SIZE
	{0xC8, 0x00EF},    //AWB_WINDOW_SIZE
	{0xC6, 0xA103},    //SEQ_CMD
	{0xC8, 0x0005},    //SEQ_CMD
	{NULL, NULL}
 };

static SENSOR_DATA sensor_init5_ColorCorrect[] =
{
	{0xF0, 0x0002},     // 2 Page Select    
	// Context B YUV Output Setting
	{0xC6, 0x270B},     //MODE_CONFIG
	{0xC8, 0x0030},     //MODE_CONFIG
	{0xC6, 0xA77E},     //MODE_OUTPUT_FORMAT_B
	{0xC8, 0x0000},     //MODE_OUTPUT_FORMAT_B
	{0xC6, 0x2774},     //MODE_FIFO_CONF1_B
	{0xC8, 0xE5E1},     //MODE_FIFO_CONF1_B
	{0xC6, 0xA776},     //MODE_FIFO_CONF2_B
	{0xC8, 0x00E3},     //MODE_FIFO_CONF2_B
	{NULL, NULL}
};
         
static SENSOR_DATA sensor_init6[] =
{
	{NULL, NULL}
};


static SENSOR_DATA Preview_CtxAData1[] =
{
    {0xF0, 0x0001},
    {0xC6, 0xA120}, {0xC8, 0x0000},
    {0xC6, 0xA103}, {0xC8, 0x0001},
    {NULL, NULL}
};

static void delayLoop(int count)
{
	volatile int j,k;
	for(j = 0; j < count; j++)
	{
		for(k=0;k<100000;k++);
	}
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_capture(unsigned char ucOnOff)
{
	if(ucOnOff == ON)
	{

		tea_cam_writei2c(CAM_PAGE_REG,									CAM_IFP_PAGE_1);
		tea_cam_writei2c(0xC6, 0x270B);		// Global Context Control
		tea_cam_writei2c(0xC8, 0x0030);		// Global Context Control
		tea_cam_writei2c(0xC6, 0xA77E);		// Global Context Control
		tea_cam_writei2c(0xC8, 0x0000);		// Global Context Control	
		tea_cam_writei2c(0xC6, 0x2774);		// Global Context Control
		tea_cam_writei2c(0xC8, 0xE5E1);		// Global Context Control
		tea_cam_writei2c(0xC6, 0xA776);		// Global Context Control
		tea_cam_writei2c(0xC8, 0x00E3);		// Global Context Control	
		tea_cam_writei2c(0xC6, 0xA70B);		// Global Context Control
		tea_cam_writei2c(0xC8, 0x0030);		// Global Context Control	
		delayLoop(50);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA120);				// SEQ_CAP_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0002);				// SEQ_CAP_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA103);				// SEQ_CMD
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0002);				// SEQ_CMD

		//WINCE
//		Sleep(20);																		// {DELAY, 50, 100}
		delayLoop(60);

	}	
	else if(ucOnOff == OFF)
	{
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0000);				// SEQ_CMD
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA120);				// SEQ_CAP_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0000);				// SEQ_CAP_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA103);				// SEQ_CMD
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0001);				// SEQ_CMD
		//WINCE
		delayLoop(20);																		// {DELAY, 50, 100}
		delayLoop(60);
	}
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_selectprevieworsnapshot(unsigned char ucType)
{

}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_resolution(unsigned int usResolution)
{
	tea_cam_writei2c(CAM_PAGE_REG,CAM_IFP_PAGE_1);
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_cameramoduleinit(unsigned char ucPreviewMode)
{
	int i;

	if( ucPreviewMode == CAMCODER_PREVIEW )
	{
		i = 0;
		while(1)
		{
			if((Preview_800x600_30fps[i].Add == NULL) && (Preview_800x600_30fps[i].Data == NULL)) 
				break;
			if(Preview_800x600_30fps[i].Add == CAMDLY)
				delayLoop( (Preview_800x600_30fps[i].Data/5) + 1 );
			else
				tea_cam_writei2c(Preview_800x600_30fps[i].Add, Preview_800x600_30fps[i].Data);
			i++;
		}    

	}
	else if( ucPreviewMode == SNAPSHOT_PREVIEW )
	{
		i = 0;
		while(1)
		{
			if((sensor_init1[i].Add == NULL) && (sensor_init1[i].Data == NULL)) break;
			tea_cam_writei2c(sensor_init1[i].Add, sensor_init1[i].Data);
			i++;
		}
		delayLoop(10);

		i = 0;
		while(1)
		{
			if((sensor_init2[i].Add == NULL) && (sensor_init2[i].Data == NULL)) break;
			tea_cam_writei2c(sensor_init2[i].Add, sensor_init2[i].Data);
	 		i++;
		}
		delayLoop(10);

		i = 0;
		while(1)
		{
			if((sensor_init3[i].Add == NULL) && (sensor_init3[i].Data == NULL)) break;
			tea_cam_writei2c(sensor_init3[i].Add, sensor_init3[i].Data);
			i++;
		}

		delayLoop(10);

		i = 0;
		while(1)
		{
			if((sensor_init4_LensCorrect[i].Add == NULL) && (sensor_init4_LensCorrect[i].Data == NULL)) break;
			tea_cam_writei2c(sensor_init4_LensCorrect[i].Add, sensor_init4_LensCorrect[i].Data);
	 		i++;
		}
		delayLoop(10);

		i = 0;
		while(1)
		{
			if((sensor_init5_ColorCorrect[i].Add == NULL) && (sensor_init5_ColorCorrect[i].Data == NULL)) break;
			tea_cam_writei2c(sensor_init5_ColorCorrect[i].Add, sensor_init5_ColorCorrect[i].Data);
			i++;
		}

		while(1)
		{
			if((sensor_init6[i].Add == NULL) && (sensor_init6[i].Data == NULL)) break;
			tea_cam_writei2c(sensor_init6[i].Add, sensor_init6[i].Data);
			i++;
		}
	}
	// Preview Mode Context A
	delayLoop(20);
	i = 0;
	while(1)
	{
		if((Preview_CtxAData1[i].Add == NULL) && (Preview_CtxAData1[i].Data == NULL)) 
			break;
		
		if(Preview_CtxAData1[i].Add == CAMDLY)
			delayLoop( (Preview_CtxAData1[i].Data/5) + 1 );
		else
			tea_cam_writei2c(Preview_CtxAData1[i].Add, Preview_CtxAData1[i].Data);
		i++;
	}
	delayLoop(50);
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_init(void)
{
	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x270B);				// Mode Config
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0030);				// Mode Config

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA77E);				// Mode Output Format B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// Mode Output Format B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x2774);				// Mode Fifo Config1 B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xE5E1);				// Mode Fifo Config1 B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA776);				// Mode Fifo Config2 B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x00E3);				// Mode Fifo Config2 B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// Seq CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0006);				// Seq CMD

	delayLoop(10);																							// {DELAY, 10, 100},

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x104C);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// MCU DATA 0

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0310);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x3C3C);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xCC01);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x33BD);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xD43F);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x30ED);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x02DC);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xB7A3);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0223);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0320);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0DF6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x02BD);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xF102);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xBE23);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x107A);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x02BD);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x200B);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xF602);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0330);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xBDF1);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x02BF);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x2403);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x7C02);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xBDCC);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x011F);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xED00);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xF602);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0340);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xBD4F);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xBDD4);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x2BCC);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x0130);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xBDD4);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x3FD7);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xB026);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x04C6);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0350);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x01D7);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xB0CC);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x0131);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xBDD4);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x3FD7);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xB126);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x04C6);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x01D7);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0360);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xB1CC);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0132);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xBDD4);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x3FD7);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xB25D);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x2604);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xC601);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xD7B2);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0370);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x5F38);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x3839);				// MCU DATA 1

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0400);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x308F);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xC3FF);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xEF8F);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x35F6);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x01D0);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x860C);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x3DC3);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x01DD);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0410);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x8FEC);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0630);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED07);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xF601);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xD086);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x0C3D);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xC301);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xDD8F);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0420);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xEC04);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x30ED);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x05F6);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x01D0);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x4FED);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x02CC);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x0021);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xA302);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0430);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xBDD4);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x3F30);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED0F);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x1F0F);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x800A);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xEC07);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x04ED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x07EC);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0440);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0504);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xED05);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xD65A);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xC40F);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xE704);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xEC07);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xED02);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xE604);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0450);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x4FED);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x00CC);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x0010);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xBDD3);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x4330);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xEC02);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xED0D);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xD65A);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0460);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x5454);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x5454);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xE704);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xEC05);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xED02);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xE604);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x4FED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x00CC);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0470);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0010);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xBDD3);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x4330);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xEC02);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xED0B);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xD65B);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xC40F);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xCB01);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0480);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xE704);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xEC07);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED02);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xE604);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x4FED);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x00CC);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x0010);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xBDD3);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0490);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x4330);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xEC02);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED07);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xD65B);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x5454);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x5454);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xCB01);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xE704);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x04A0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xEC05);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xED02);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xE604);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x4FED);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x00CC);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x0010);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xBDD3);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x4330);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x04B0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xEC02);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xED05);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xE30B);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xED09);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xC300);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x0ADD);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x5CEC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0DE3);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x04C0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x07ED);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x02EC);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x0DED);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x00C6);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x08BD);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xD319);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x30ED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0FCC);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x04D0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x012D);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xED00);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xEC0F);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xBDD4);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x2B30);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xEC09);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xED02);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xEC0B);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x04E0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xED00);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xC608);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xBDD3);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x1930);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xED0F);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xCC01);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x2EED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x00EC);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x04F0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0FBD);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xD42B);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x30C6);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x113A);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x3539);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x308F);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xC3FF);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xED8F);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0500);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x35F6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x01D0);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x860E);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x3DC3);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x01F5);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x8FEC);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x0030);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xED06);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0510);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xF601);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xD086);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x0E3D);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xC301);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xF58F);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xEC04);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x30ED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x04EC);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0520);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x15ED);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0BEC);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x17ED);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x09D6);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x02C4);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x0FE7);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x08EC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0BED);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0530);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x02E6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x084F);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED00);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xCC00);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x10BD);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xD343);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x30EC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x02ED);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0540);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0FE3);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x06ED);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x0FD6);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x0254);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x5454);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x54E7);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x08EC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x09ED);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0550);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x02E6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x084F);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED00);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xCC00);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x10BD);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xD343);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x30EC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x02ED);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0560);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0DE3);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x04ED);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x0DD6);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x03C4);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x0FCB);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x01E7);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x08EC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0BED);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0570);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x02E6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x084F);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED00);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xCC00);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x40BD);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xD343);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x30EC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x02ED);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0580);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0BD6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0354);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x5454);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x54CB);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x01E7);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x08EC);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x09ED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x02E6);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0590);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x084F);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xED00);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xCC00);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x40BD);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xD343);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x30EC);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x02ED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0905);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x05A0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x05E3);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0DC3);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x000A);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xDD04);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xEC0D);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xED02);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xEC0F);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xED00);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x05B0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xC608);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xBD08);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x1930);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xED11);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xCC02);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xC0ED);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x00EC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x11BD);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x05C0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xD42B);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x30EC);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x09ED);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x02EC);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x0BED);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x00C6);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x02BD);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xD319);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x05D0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x30ED);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x11CC);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x02C1);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xED00);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xEC11);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xBDD4);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x2B7F);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x10C4);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x05E0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x30EC);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x09C4);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xFEFD);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x10C5);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xEC0B);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xC4FE);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xFD10);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xC701);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x05F0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0101);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xCC02);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xC2ED);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x00FC);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x10C2);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xBDD4);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x2BFC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x10C0);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0600);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xCA06);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x30ED);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x11CC);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x02C3);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xED00);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xEC11);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xBDD4);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x2B30);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0610);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xC613);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x3A35);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x393C);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xDC25);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x30ED);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x00BD);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x81BE);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x7D00);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0620);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x1E27);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x227F);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x10C4);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xD61E);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x4FFD);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x10C5);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xDC2F);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xFD10);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0630);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xC701);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0101);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xFC10);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xC2DD);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x25D6);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x31C1);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x0224);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0BC6);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0640);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x02D7);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x3120);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x0530);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xEC00);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xDD25);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x3839);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x373C);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x3CD6);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0650);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x1E30);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xE701);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xDC25);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xED02);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xE607);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xE700);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xE604);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xBD87);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0660);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x01D6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x1FD1);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x1023);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x04D6);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x10D7);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x1F30);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xE607);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xC101);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0670);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x2612);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xD61E);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xE101);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x240C);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xD610);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xD71F);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xE601);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xD71E);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0680);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xEC02);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xDD25);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x3838);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x3139);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x3CDE);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x00EE);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x12AD);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x00D6);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0690);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x4630);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xE701);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xC601);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xE700);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xE600);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x4F8F);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xE646);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x30EB);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x06A0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x01E7);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x016C);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x00E6);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x00C1);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x0525);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xED4F);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xE601);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x2A01);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x06B0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x43CE);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0005);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xBD07);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xD0D7);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x4E30);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x6F01);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x96D5);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x112F);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x06C0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x04C6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x01E7);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x01E6);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x0138);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x393C);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x3C3C);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x3C34);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xC620);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x06D0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xF702);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xBD7F);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x02BE);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xF702);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xBFC6);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xF6D7);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xBACC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x02AB);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x06E0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x30ED);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x06FE);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x1050);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xEC06);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xFD02);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xA7FE);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x02A7);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xEC00);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x06F0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xFD02);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xA930);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x6F08);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xE608);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x4F05);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xF302);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xA98F);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xEC00);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0700);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x30ED);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x00E6);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x084F);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x05E3);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x0618);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x8FEC);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x0018);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xED00);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0710);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x6C08);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xE608);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xC109);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x25DE);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xEE06);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xCC03);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x10ED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0230);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0720);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xEE06);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xCC04);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x00ED);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x04CC);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x02AB);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xDD58);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xCC02);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xC430);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0730);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xED04);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xFE10);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x50EC);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x04FD);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x02C0);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xFE02);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xC0EC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x00FD);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0740);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x02C2);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x306F);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x08E6);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x084F);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x05F3);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x02C2);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x8FEC);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0030);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0750);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xED00);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xE608);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x4F05);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xE304);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x188F);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xEC00);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x18ED);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x006C);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0760);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x08E6);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x08C1);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x0E25);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xDEEE);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x04CC);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x04FA);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xED04);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x30EE);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0770);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x04CC);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0615);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED0A);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x30EE);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x04CC);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x064C);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xED0C);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xCC02);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0780);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xC4DD);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x00CC);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x02E4);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x30ED);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x02FE);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x1050);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xEC02);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xFD02);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x0790);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xE0FE);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x02E0);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xEC00);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0xFD02);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xE230);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x6F08);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0xE608);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x4F05);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x07A0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xF302);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0xE28F);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xEC00);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x30ED);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x00E6);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x084F);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x05E3);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x0218);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x07B0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x8FEC);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x0018);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0xED00);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x6C08);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xE608);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0xC112);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x25DE);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0xEE02);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x07C0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0xCC06);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x88ED);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x1CCC);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x02E4);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0xDDC2);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x30C6);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x093A);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x3539);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x07D0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x8F4D);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x2C13);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x4353);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x8F08);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x4D2C);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x0643);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x5302);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x088F);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x07E0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x3902);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x098F);				// MCU DATA 1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG,	0x4353);				// MCU DATA 2
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG,	0x398F);				// MCU DATA 3
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG,	0x4D2C);				// MCU DATA 4
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG,	0x0743);				// MCU DATA 5
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG,	0x5302);				// MCU DATA 6
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG,	0x8F43);				// MCU DATA 7

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x07F0);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x5339);				// MCU DATA 0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG,	0x028F);				// MCU DATA 1

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x87F4);				// MCU Address
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0039);				// MCU DATA 0


	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x2003);				// MON ARG1
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x06C9);				// MON ARG1

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA002);				// MON CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0001);				// MON CMD

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_SENSOR_PAGE);
//	tea_cam_writei2c(CAM_PLL_CONTROL_1_REG,											0x470A);				// PLL REG
//	tea_cam_writei2c(CAM_PLL_CONTROL_2_REG,											0x0500);				// PLL2 REG
//	tea_cam_writei2c(CAM_CLOCK_REG,													0xA000);				// CLOCK Enabling
//	tea_cam_writei2c(CAM_CLOCK_REG,													0x2000);				// CLOCK Enabling
	tea_cam_writei2c(CAM_HORIZONTAL_BLANKING_B_REG,									0x0204);				// Horz blank B
	tea_cam_writei2c(CAM_VERTICAL_BLANKING_B_REG,									0x002D);				// Vert blank B
	tea_cam_writei2c(CAM_HORIZONTAL_BLANKING_A_REG,									0x00FE);				// Horz blank A
	tea_cam_writei2c(CAM_VERTICAL_BLANKING_A_REG,									0x0012);				// Vert blank A
	tea_cam_writei2c(CAM_READ_MODE_B_REG,											0x0300);				// Read Mode B
	tea_cam_writei2c(CAM_READ_MODE_A_REG,											0x8400);				// Read Mode A
	
	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x271B);				// Mode Sensor Row Start B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x001C);				// Mode Sensor Row Start B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x271D);				// Mode Sensor Col Start B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x003C);				// Mode Sensor Col Start B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x271F);				// Mode Sensor Row Height B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x04B0);				// Mode Sensor Row Height B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x2721);				// Mode Sensor Col Width B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0640);				// Mode Sensor Col Width B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x2723);				// Mode Sensor X Delay B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0468);				// Mode Sensor X Delay B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x2725);				// Mode Sensor Row Speed B
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0011);				// Mode Sensor Row Speed B

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x220B);				// AE Max R12
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0192);				// AE Max R12

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA217);				// AE Index TH23
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				// AE Index TH23

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x2228);				// AE Row Time
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x020F);				// AE Row Time

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x222F);				// AE R9 Step
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x009C);				// AE R9 Step

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA408);				// FD Search F1 50
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0024);				// FD Search F1 50

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA409);				// FD_SEARCH_F2_50
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0026);				// FD_SEARCH_F2_50

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA40A);				// FD_SEARCH_F1_60
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x001E);				// FD_SEARCH_F1_60

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA40B);				// FD_SEARCH_F2_60
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0020);				// FD_SEARCH_F2_60

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x2411);				// FD_R9_STEP60
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x009C);				// FD_R9_STEP60

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0x2413);				// FD_R9_STEP50
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x00BC);				// FD_R9_STEP50

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0005);				// SEQ_CMD

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_2);
	tea_cam_writei2c(CAM_LENS_CORRECTION_CONTROL_REG,								0x01E8);				// LENS_CORRECTION_CONTROL
	tea_cam_writei2c(CAM_ZONE_BOUNDARIES_X1_AND_X2_REG,								0x6533);				// ZONE_BOUNDS_X1_X2
	tea_cam_writei2c(CAM_ZONE_BOUNDARIES_X0_AND_X3_REG,								0x3198);				// ZONE_BOUNDS_X0_X3
	tea_cam_writei2c(CAM_ZONE_BOUNDARIES_X4_AND_X5_REG,								0x9463);				// ZONE_BOUNDS_X4_X5
	tea_cam_writei2c(CAM_ZONE_BOUNDARIES_Y1_AND_Y2_REG, 							0x4824);				// ZONE_BOUNDS_Y1_Y2
	tea_cam_writei2c(CAM_ZONE_BOUNDARIES_Y0_AND_Y3_REG,								0x276D);				// ZONE_BOUNDS_Y0_Y3
	tea_cam_writei2c(CAM_ZONE_BOUNDARIES_Y4_AND_Y5_REG,								0x744E);				// ZONE_BOUNDS_Y4_Y5
	tea_cam_writei2c(CAM_CENTER_OFFSET_REG,											0xFB03);				// CENTER_OFFSET
	tea_cam_writei2c(CAM_FX_FOR_RED_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,		0x010E);
	tea_cam_writei2c(CAM_FY_FOR_RED_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,		0x00AA);
	tea_cam_writei2c(CAM_DF_DX_FOR_RED_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,	0x0B59);
	tea_cam_writei2c(CAM_DF_DY_FOR_RED_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,	0x0852);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_0_RED_COLOR_REG,				0x1E31);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_1_RED_COLOR_REG,				0x2D14);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_2_RED_COLOR_REG,				0x382B);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_3_RED_COLOR_REG,				0x4F4A);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_4_RED_COLOR_REG,				0x544E);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_5_RED_COLOR_REG,				0x362D);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_6_RED_COLOR_REG,				0x2B06);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_7_RED_COLOR_REG,				0x0C4D);
	tea_cam_writei2c(CAM_FX_FOR_GREEN_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,	0x00C1);
	tea_cam_writei2c(CAM_FY_FOR_GREEN_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,	0x0073);
	tea_cam_writei2c(CAM_DF_DX_FOR_GREEN_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,	0x0CAD);
	tea_cam_writei2c(CAM_DF_DY_FOR_GREEN_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,	0x0BCA);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_0_GREEN_COLOR_REG,				0xF820);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_1_GREEN_COLOR_REG,				0x1310);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_2_GREEN_COLOR_REG,				0x3224);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_3_GREEN_COLOR_REG,				0x3833);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_4_GREEN_COLOR_REG,				0x3635);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_5_GREEN_COLOR_REG,				0x3321);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_6_GREEN_COLOR_REG,				0x2008);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_7_GREEN_COLOR_REG,				0xCF01);
	tea_cam_writei2c(CAM_FX_FOR_BLUE_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,		0x00A5);
	tea_cam_writei2c(CAM_FY_FOR_BLUE_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,		0x0064);
	tea_cam_writei2c(CAM_DF_DX_FOR_BLUE_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,	0x0CEF);
	tea_cam_writei2c(CAM_DF_DY_FOR_BLUE_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG,	0x0CD8);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_0_BLUE_COLOR_REG,				0xE927);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_1_BLUE_COLOR_REG,				0x150F);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_2_BLUE_COLOR_REG,				0x2419);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_3_BLUE_COLOR_REG,				0x2E2E);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_4_BLUE_COLOR_REG,				0x2E2E);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_5_BLUE_COLOR_REG,				0x281A);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_6_BLUE_COLOR_REG,				0x2807);
	tea_cam_writei2c(CAM_SECOND_DERIVATIVE_FOR_ZONE_7_BLUE_COLOR_REG,				0xD927);
	tea_cam_writei2c(CAM_X2_FACTORS_REG,											0x0000);
	tea_cam_writei2c(CAM_GLOBAL_OFFSET_OF_FXY_FUNCTION_REG,							0x0000);
	tea_cam_writei2c(CAM_K_FACTOR_IN_K_FX_FY_REG,									0x018E);

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	tea_cam_writei2c(CAM_COLOR_PIPELINE_CONTROL_REG,								0x01FC);
	tea_cam_writei2c(CAM_2D_APERTURE_CORRECTION_PARAMETERS_REG,						0x1408);
	 
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA206);				// AE_TARGET
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x004A);				// AE_TARGET

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA207);				// AE_TARGET
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				// AE_TARGET
	// HG
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xAB05);				// HG_PERCENT
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x000A);				// HG_PERCENT
	 
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA210);				// AE_MAX_VIRTGAIN
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0040);				// AE_MAX_VIRTGAIN

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA218);				// AE_MAXGAIN23
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x003C);				// AE_MAXGAIN23

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0005);				// SEQ_CMD
	 
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA34A);				// AWB_GAIN_MIN
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0060);				// AWB_GAIN_MIN

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA34B);				// AWB_GAIN_MAX
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x00A0);				// AWB_GAIN_MAX

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA34F);				// AWB_CCM_POSITION_MIN
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0040);				// AWB_CCM_POSITION_MIN

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA350);				// AWB_CCM_POSITION_MAX
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x007F);				// AWB_CCM_POSITION_MAX

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0005);				// SEQ_CMD

	delayLoop(10);																							// {DELAY, 10, 100},

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_SENSOR_PAGE);
	tea_cam_writei2c(CAM_GREEN_1_GAIN_REG,											0x0020);
	
	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA122);				// SEQ_PREVIEW_0_AE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_0_AE

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA124);				// SEQ_PREVIEW_0_AWB
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_0_AWB

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA126);				// SEQ_PREVIEW_0_HG
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_0_HG

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA129);				// SEQ_PREVIEW_1_AE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_1_AE

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA12B);				// SEQ_PREVIEW_1_AWB
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_1_AWB

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA12A);				// SEQ_PREVIEW_1_FD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_1_FD

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA12D);				// SEQ_PREVIEW_1_HG
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_1_HG

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA130);				// SEQ_PREVIEW_2_AE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_2_AE

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA132);				// SEQ_PREVIEW_2_AWB
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_2_AWB

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA131);				// SEQ_PREVIEW_2_FD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_2_FD

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA134);				// SEQ_PREVIEW_2_HG
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_PREVIEW_2_HG

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA120);				// SEQ_CAP_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0002);				// SEQ_CAP_MODE

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA120);				// SEQ_CAP_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0012);				// SEQ_CAP_MODE

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA120);				// SEQ_CAP_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x001A);				// SEQ_CAP_MODE

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA120);				// SEQ_CAP_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x003A);				// SEQ_CAP_MODE

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0005);				// SEQ_CMD
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_contextadata(void)
{
	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA120);				// SEQ_CAP_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// SEQ_CAP_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0001);				// SEQ_CMD

	delayLoop(10);																							// {DELAY, 50, 100}
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA20E);				// MCU_ADDRESS
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				// MCU_DATA_0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA217);				// MCU_ADDRESS
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				// MCU_DATA_0

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_SENSOR_PAGE);
	tea_cam_writei2c(CAM_VERTICAL_BLANKING_A_REG,									0x02B3);				// VERT_BLANK_A

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	 
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA702);				// SEQ_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0000);				// 

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// MCU_ADDRESS
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0005);				// MCU_DATA_0
	tea_cam_writei2c(CAM_2D_APERTURE_CORRECTION_PARAMETERS_REG,						0x1408);				// AE_TARGET
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_contextbdata(void)
{
/* CHANGE DISPLAY MODE CONTEXTB*/
	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA120);				// SEQ_CAP_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0072);				// SEQ_CAP_MODE
	delayLoop(10);																							// {DELAY, 10, 100}

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0002);				// SEQ_CMD
	delayLoop(10);																							// {DELAY, 10, 100}

	// fixed 10 fps
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA20E);				// MCU_ADDRESS
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x000C);				// MCU_DATA_0
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA217);				// MCU_ADDRESS
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				// MCU_DATA_0

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_SENSOR_PAGE);
	tea_cam_writei2c(CAM_VERTICAL_BLANKING_B_REG,									0x02A3);				// VERT_BLANK_B

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	 
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA102);				// SEQ_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x000F);				// SEQ_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA209);				// AE_JUMP_DIVISOR
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0002);				// AE_JUMP_DIVISOR
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA20A);				// AE_LUMA_BUFFER_SPEED
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				// AE_LUMA_BUFFER_SPEED
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA349);				// AWB_JUMP_DIVISOR
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0002);				// AWB_JUMP_DIVISOR
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA348);				// AWB_GAIN_BUFFER_SPEED
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				// AWB_GAIN_BUFFER_SPEED
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xAB02);				// HG_DLEVEL_BUFFERSPEED
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				// HG_DLEVEL_BUFFERSPEED

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				// SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0005);				// SEQ_CMD - REFRESH

	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA702);				// SEQ_MODE
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0001);				//

}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_daymode(void)
{
/* Use for Back to Day Mode (10fps) - Context B only! */
	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA20E);				//AE_MAX_INDEX
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x000C);				//AE_MAX_INDEX
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA217);				//AE_INDEX_TH23
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				//AE_INDEX_TH23

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_SENSOR_PAGE);
	tea_cam_writei2c(CAM_VERTICAL_BLANKING_B_REG,									0x02A3);				// VERT_BLANK_B

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				//SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0005);				//SEQ_CMD
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_nightmode(void)
{
/* Use to go Night Mode (5fps) - Context B only! */
	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA20E);				//AE_MAX_INDEX
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0018);				//AE_MAX_INDEX
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA217);				//AE_INDEX_TH23
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0008);				//AE_INDEX_TH23

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_SENSOR_PAGE);
	tea_cam_writei2c(CAM_VERTICAL_BLANKING_B_REG,									0x09FE);				// VERT_BLANK_B

	tea_cam_writei2c(CAM_PAGE_REG,													CAM_IFP_PAGE_1);
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,						0xA103);				//SEQ_CMD
	tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,							0x0005);				//SEQ_CMD
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_effect(unsigned char ucMode)
{

	if(ucMode == SET_EFFECTNONE)
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x277F);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6440);// VAR=7, 0x7F, 0x6440  // MODE_SPEC_EFFECTS_A
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x2781);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6440);// VAR=7, 0x81, 0x6440  // MODE_SPEC_EFFECTS_B
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA103);//REG=1, 0xC6, 0xA103 //SEQ_CMD 
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0006);//REG=1, 0xC8, 0x0006 //SEQ_CMD  
	}
	else if(ucMode == SET_EFFECTMONO)
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x277F);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6441);// VAR=7, 0x7F, 0x6441  // MODE_SPEC_EFFECTS_A
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x2781);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6441);// VAR=7, 0x81, 0x6441  // MODE_SPEC_EFFECTS_B
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA103);//REG=1, 0xC6, 0xA103 //SEQ_CMD
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0006);//REG=1, 0xC8, 0x0006 //SEQ_CMD 
	}
	else if(ucMode == SET_EFFECTSEPIA)
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x277F);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6442);// VAR=7, 0x7F, 0x6442  // MODE_SPEC_EFFECTS_A
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x2781);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6442);// VAR=7, 0x81, 0x6442  // MODE_SPEC_EFFECTS_B
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA103);//REG=1, 0xC6, 0xA103 //SEQ_CMD
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0006);//REG=1, 0xC8, 0x0006 //SEQ_CMD  
	}
	else if(ucMode == SET_EFFECTNEGA)
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x277F);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6443);// VAR=7, 0x7F, 0x6443  // MODE_SPEC_EFFECTS_A
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x2781);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6443);// VAR=7, 0x81, 0x6443  // MODE_SPEC_EFFECTS_B
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA103);//REG=1, 0xC6, 0xA103 //SEQ_CMD 
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0006);//REG=1, 0xC8, 0x0006 //SEQ_CMD
	}
	else if(ucMode == SET_EFFECTSOLA1)
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x277F);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6444);// VAR=7, 0x7F, 0x6444  // MODE_SPEC_EFFECTS_A
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x2781);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6444);// VAR=7, 0x81, 0x6444  // MODE_SPEC_EFFECTS_B
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA103);//REG=1, 0xC6, 0xA103 //SEQ_CMD  
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0006);//REG=1, 0xC8, 0x0006 //SEQ_CMD
	}
	else if(ucMode == SET_EFFECTSOLA2)
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x277F);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6445);// VAR=7, 0x7F, 0x6445  // MODE_SPEC_EFFECTS_A
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0x2781);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x6445);// VAR=7, 0x81, 0x6445  // MODE_SPEC_EFFECTS_B
	
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA103);//REG=1, 0xC6, 0xA103 //SEQ_CMD
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0006);//REG=1, 0xC8, 0x0006 //SEQ_CMD  
	}
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_brightness(unsigned char ucMode)
{
	if(ucMode == -3)			// Brightness 3 down
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA206);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0015);
	}	
	else if(ucMode == -2)		// Brightness 2 down
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA206);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0025);
	} 
	else if(ucMode == -1)		// Brightness 1 down
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA206);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0034);
	}
	else if(ucMode == 0)		// Brightness reference
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA206);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x004A);
	}
 	else if(ucMode == 1)		// Brightness 1 up
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA206);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0069);
	}
	else if(ucMode == 2)		// Brightness 2 up
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA206);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0094);
	}
	else if(ucMode == 3)		// Brightness 3 up
	{
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA206);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x00B4);
	}
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_whitebalance(unsigned char ucMode)
{
	if(ucMode == SET_WB_DEFAULT)
	{
		//[Enable AWB-recovery of MANUAL WB]
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34D);//(6) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0080);//(6) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA102);//SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x000F);//SEQ_MOD
	}
	else if(ucMode == SET_WB_DAYLIGHT)
	{
		//[MANUAL_DAY]
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA102);//(14) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x000B);//(14) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34C);//(33) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0095);//(33) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34D);//(39) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x007C);//(39) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34E);//(14) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0071);//(14) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA351);//(143) AWB_CCM_POSITION
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x007F);//(143) AWB_CCM_POSITION
	}
 	else if(ucMode == SET_WB_COOLWHITE)
	{
		/* manual mode change */
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA102);//(12) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x000B);//(12) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34C);//(27) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0086);//(27) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34D);//(33) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0076);//(33) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34E);//(8) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x008B);//(8) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA351);//(142) AWB_CCM_POSITION
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0054);//(142) AWB_CCM_POSITION
	}
	else if(ucMode == SET_WB_TL84)
	{
		/* manual mode change */
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA102);//(10) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x000B);//(10) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34C);//(16) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0081);//(16) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34D);//(21) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x007C);//(21) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34E);//(7) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0085);//(7) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA351);//(70) AWB_CCM_POSITION
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x002D);//(70) AWB_CCM_POSITION
	}
 	else if(ucMode == SET_WB_WHITHLIGHT)
	{
		/* manual mode change */
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA102);//(4) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x000B);//(4) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34C);//(2) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x007A);//(2) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34D);//(14) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0079);//(14) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34E);//(5) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0086);//(5) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA351);//(48) AWB_CCM_POSITION
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0019);//(48) AWB_CCM_POSITION
	}
	else if(ucMode == SET_WB_HORIZON)
	{
		/* manual mode change */
		tea_cam_writei2c(CAM_PAGE_REG,								CAM_IFP_PAGE_1);
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA102);//(2) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x000B);//(2) SEQ_MODE
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34C);//(1) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x006E);//(1) AWB_GAIN_R
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34D);//(6) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x007A);//(6) AWB_GAIN_G
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA34E);//(1) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0096);//(1) AWB_GAIN_B
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG,	0xA351);//AWB_CCM_POSITION
		tea_cam_writei2c(CAM_MICROCONTROLLER_VARIABLE_DATA_REG,		0x0000);//AWB_CCM_POSITION
	}
}

#if 0 // TEST zminc
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_powerdown(void)
{
	BITSET(HwGPFEN, Hw1);
	BITCLR(HwGPFDAT, Hw1);

	tea_cam_writei2c(CAM_PAGE_REG, CAM_SENSOR_PAGE);
	tea_cam_writei2c(CAM_CLOCK_REG, 0xA000);
	tea_cam_writei2c(CAM_CLOCK_REG, 0xE000);
	tea_cam_writei2c(CAM_RESET_REG, 0x0005);

}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tca_sensor_powerresume(void)
{
	BITSET(HwGPFEN, Hw1);
	BITSET(HwGPFDAT, Hw1);
	tea_cam_writei2c(CAM_PAGE_REG, CAM_SENSOR_PAGE);
	tea_cam_writei2c(CAM_CLOCK_REG, 0xA000);
	tea_cam_writei2c(CAM_CLOCK_REG, 0x2000);
	tea_cam_writei2c(CAM_RESET_REG, 0x0000);
	
}

#endif
/* end of file */

