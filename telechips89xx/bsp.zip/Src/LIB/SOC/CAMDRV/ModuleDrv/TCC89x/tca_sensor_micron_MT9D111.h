
/****************************************************************************
*   FileName    : tca_sensor_micron_MT9D111.h
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/
#ifndef __TCA_SENSORMODULE_H__
#define __TCA_SENSORMODULE_H__


#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>

/*****************************************************************************
*
* Defines
*
******************************************************************************/
#define		ON			1
#define		OFF			0
#define		SNAPSHOT_PREVIEW			1
#define		CAMCODER_PREVIEW			2

/* CAM All Page Common Register */
#define CAM_SENSOR_PAGE                                                    0x0000    // Sensor Core Register Address
#define CAM_IFP_PAGE_1                                                     0x0001    // Colorpipe Register Address
#define CAM_IFP_PAGE_2                                                     0x0002    // Camera Control Register Address
#define CAM_PAGE_REG                                                       0xF0    // Page Map Register
#define CAM_BYTEWISE_ADDRESS_REG                                           0xF1    // Byte-Wise Address Register

/* Sensor Core Register Page = 0 */
#define CAM_ROW_START_REG                                                  0x01    // Row Start Register
#define CAM_COLUMN_START_REG                                               0x02    // Column Start Register
#define CAM_ROW_WIDTH_REG                       	                       0x03    // Row Width Register
#define CAM_COLUNM_WIDTH_REG                                               0x04    // Window Width Register
#define CAM_HORIZONTAL_BLANKING_B_REG               	                   0x05    // Horizontal Blanking - Context B Register
#define CAM_VERTICAL_BLANKING_B_REG                                        0x06    // Vertical Blanking - Context B Register
#define CAM_HORIZONTAL_BLANKING_A_REG                   	               0x07    // Horizontal Blanking - Context A Register
#define CAM_VERTICAL_BLANKING_A_REG                                        0x08    // Vertical Blanking - Context A Register
#define CAM_SHUTTER_WIDTH_REG                               	           0x09    // Shutter Width Register
#define CAM_ROW_SPEED_REG                                                  0x0A    // Row Speed Register
#define CAM_EXTRA_DELAY_REG                                                0x0B    // Extra Delay Register
#define CAM_SHUTTER_DELAY_REG                                              0x0C    // Shutter Delay Register
#define CAM_RESET_REG                                                      0x0D    // Reset Register
#define CAM_FRAME_VALID_CONTROL_REG                                        0x1F    // Frame Valid Control Resigter
#define CAM_READ_MODE_B_REG                                                0x20    // Read Mode - Context B Register
#define CAM_READ_MODE_A_REG                                                0x21    // Read Mode - Context A Register
#define CAM_SHOW_CONTROL_REG                                               0x22    // Show Control Register
#define CAM_FLASH_CONTROL_REG                                              0x23    // Flash Control Register
#define CAM_EXTRA_RESET_REG                                     	       0x24    // Extra Reset Register
#define CAM_LINE_VALID_CONTROL                                      	   0x25    // Line Valid Control Register
#define CAM_BOTTOM_DARK_ROWS_REG    	                                   0x26    // Bottom Dark Rows Register
#define CAM_GREEN_1_GAIN_REG                                               0x2B    // Green 1 Gain Register
#define CAM_BLUE_GAIN_REG                                                  0x2C    // Blue Gain Register
#define CAM_RED_GAIN_REG                                                   0x2D    // Red Gain Register
#define CAM_GREEN_2_GAIN_REG                                               0x2E    // Green 2 Gain Register
#define CAM_GLOBAL_GAIN_REG                                                0x2F    // Global Gain Register
#define CAM_ROW_NOISE_REG                                                  0x30    // Row Noise Reigster
#define CAM_BLACK_ROWS_REG                                                 0x59    // Black Rows Register
#define CAM_GREEN_1_FRAME_AVERAGE_REG                                      0x5B    // Green 1 Frame Average Register
#define CAM_BLUE_FRAME_AVERAGE_REG                                         0x5C    // Blue Frame Average Register
#define CAM_REG_FRAME_AVERAGE_REG                                          0x5D    // Red Frame Average Register
#define CAM_GREEN_2_FRAME_AVERAGE_REG                                      0x5E    // Green 2 Frame Average Register
#define CAM_THRESHOLD_REG                                                  0x5F    // Threshold Register
#define CAM_CALIBRATION_CONTROL_REG                                        0x60    // Calibration Register
#define CAM_GREEN_1_CALIBRATION_VALUE_REG                                  0x61    // Green 1 Calibration Value Register
#define CAM_BLUE_CALIBRATION_VALUE_REG                                     0x62    // Blue Calibration Value Register
#define CAM_RED_CALIBRATION_VALUE_REG                                      0x63    // Red Calibration Value Register
#define CAM_GREEN_2_CALIBRATION_VALUE_REG                                  0x64    // Green 2 Calibration Value Register
#define CAM_CLOCK_REG                                                      0x65    // Clock Register
#define CAM_PLL_CONTROL_1_REG                                              0x66    // PLL Control 1 Register
#define CAM_PLL_CONTROL_2_REG                                              0x67    // PLL Control 2 Register
#define CAM_GLOBAL_RESET_CONTROL_REG                                       0xC0    // Global Reset Control Register
#define CAM_START_INTEGRATION_TIME_REG                                     0xC1    // Start Integration Time (T1) Register
#define CAM_START_READOUT_TIME_REG                                         0xC2    // Start Readout Time (T2) Register
#define CAM_ASSERT_STROBE_TIME_REG                                         0xC3    // Assert Strobe Time (T3) Register
#define CAM_DEASSERT_STROBE_TIME_REG                                       0xC4    // De-assert Strobe Time (T4) Register
#define CAM_ASSERT_FLASH_TIME_REG                                          0xC5    // Assert Flash Time Register
#define CAM_DEASSERT_FLASH_TIME_REG                                        0xC6    // De-assert Flash Time Register
#define CAM_AIN3_SAMPLE_REG                                                0xE0    // AIN3 Sample Register
#define CAM_AIN2_SAMPLE_REG                                                0xE1    // AIN2 Sample Register
#define CAM_AIN1_SAMPLE_REG                                                0xE2    // AIN1 Sample Register
#define CAM_EXTERNAL_SIGNAL_SAMPLING_CONTROL_REG                           0xE3    // External Signal Sampling Control Register
#define CAM_CONTEXT_CONTROL_REG                                            0xF2    // Context Control Register

/* IFP Registers, Page 1 */
#define CAM_COLOR_PIPELINE_CONTROL_REG                                                          0x08    // Color Pipeline Control Register
#define CAM_FACTORY_BYPASS_REG                                                                  0x09    // Factory Bypass Reigster
#define CAM_PAD_SLEW_REG                                                                        0x0A    // Pad Slew Register
#define CAM_INTERNAL_CLOCK_CONTROL_REG                                                          0x0B    // Internal Clock Control Register
#define CAM_X0_COORDINATE_FOR_CROP_WINDOW_REG                                                   0x11    // X0 Coordinate for Crop Window Register
#define CAM_X1_COORDINATE_FOR_CROP_WINDOW_PLUS1_REG                                             0x12    // X1 Coordinate for Crop Window +1 Register
#define CAM_Y0_COORDINATE_FOR_CROP_WINDOW_REG                                                   0x13    // Y0 Coordinate for Crop Window Register
#define CAM_Y1_COORDINATE_FOR_CROP_WINDOW_PLUS1_REG                                             0x14    // Y2 Coordinate for Crop Window +1 Register
#define CAM_DECIMATOR_CONTROL_REG                                                               0x15    // Decimator Control Register
#define CAM_WEIGHT_FOR_HORIZONTAL_DECIMATION_REG                                                0x16    // Weight for Horizontal Decimator Register
#define CAM_WEIGHT_FOR_VERTICAL_DECIMATION_REG                                                  0x17    // Weight for Vertical Decimator Register
#define CAM_LUMINANCE_RANGE_OF_PIXELS_CONSIDERED_IN_WB_STATISTICS_REG                           0x20    // Luminance Range Of Pixels Considered In WB Statistics Register
#define CAM_RIGHT_LEFT_COORDINATES_OF_AWB_MEASUREMENT_WINDOW_REG                                0x2D    // Right/Left Coordinates Of AWB Measurement Window Register
#define CAM_BOTTOM_TOP_COORDINATES_OF_AWB_MEASUREMENT_WINDOW_REG                                0x2E    // Right/Left Coordinates Of AWB Measurement Window Register
#define CAM_RED_CHROMINANCE_MEASURE_CALCULATED_BY_AWB_REG                                       0x30    // Red Chrominance Measure Calculated By AWB Register
#define CAM_LUMINANCE_MEASURE_CALCULATED_BY_AWB_REG                                             0x31    // Luminance Measure Calculated By AWB Register
#define CAM_BLUE_CHROMINANCE_MEASURE_CALCULATED_BY_AWB_REG                                      0x32    // Blue Chrominance Measure Calculated By AWB Register
#define CAM_1D_APERTURE_CORRECTION_PARAMETERS_REG                                               0x35    // 1D Aperture Correction Parameters Register
#define CAM_2D_APERTURE_CORRECTION_PARAMETERS_REG                                               0x36    // 2D Aperture Correction Parameters Register
#define CAM_FILTERS_REG                                                                         0x37    // Filters Register
#define CAM_SECOND_BLACK_LEVEL_REG                                                              0x3B    // Second Black Level Register
#define CAM_FIRST_BLACK_LEVEL_REG                                                               0x3C    // First Black Level Register
#define CAM_ENABLE_SUPPORT_FOR_PREVIEW_MODES                                                    0x43    // Enable Support for Preview Modes
#define CAM_MIRRORS_SENSOR_REGISTER_0X20_REG                                                    0x44    // Mirrors Sensor Register 0x20 Register
#define CAM_MIRRORS_SENSOR_REGISTER_0XF2_REG                                                    0x45    // Mirrors Sensor Register 0xF2 Register
#define CAM_MIRRORS_SENSOR_REGISTER_0X21_REG                                                    0x46    // Mirrors Sensor Register 0x21 Register
#define CAM_EDGE_THRESHOLD_FOR_INTERPOLATION_REG                                                0x47    // Edge Threshold for Interpolation Register
#define CAM_TEST_PATTERN_REG                                                                    0x48    // Test Pattern Register
#define CAM_TEST_PATTERN_R_MONOCHROME_VALUE_REG                                                 0x49    // Test Pattern R/Monochrome Value Register
#define CAM_TEST_PATTERN_G_MONOCHROME_VALUE_REG                                                 0x4A    // Test Pattern G/Monochrome Value Register
#define CAM_TEST_PATTERN_B_VALUE_REG                                                            0x4B    // Test Pattern B Value Register
#define CAM_DIGITAL_GAIN_2_REG                                                                  0x4E    // Digital Gain 2 Register
#define CAM_COLOR_CORRECTION_MATRIX_EXPONENTS_FOR_C11_C22_REG                                   0x60    // Color Correction Matrix Exponents for C11..C22 Register
#define CAM_COLOR_CORRECTION_MATRIX_EXPONENTS_FOR_C22_C33_REG                                   0x61    // Color Correction Matrix Exponents for C22..C33 Register
#define CAM_COLOR_CORRECTION_MATRIX_ELEMENTS_1_AND_2_MANTISSAS_REG                              0x62    // Color Correction Matrix Elements 1 And 2 Mantissas Register
#define CAM_COLOR_CORRECTION_MATRIX_ELEMENTS_3_AND_4_MANTISSAS_REG                              0x63    // Color Correction Matrix Elements 3 And 4 Mantissas Register
#define CAM_COLOR_CORRECTION_MATRIX_ELEMENTS_5_AND_6_MANTISSAS_REG                              0x64    // Color Correction Matrix Elements 5 And 6 Mantissas Register
#define CAM_COLOR_CORRECTION_MATRIX_ELEMENTS_7_AND_8_MANTISSAS_REG                              0x65    // Color Correction Matrix Elements 7 And 8 Mantissas Register
#define CAM_COLOR_CORRECTION_MATRIX_ELEMENTS_9_AND_SIGNS_REG                                    0x66    // Color Correction Matrix Elements 9 And Signs Register
#define CAM_DIGITAL_GAIN_1_FOR_RED_PIXELS_REG                                                   0x6A    // Digtal Gain 1 for Red Pixels Register
#define CAM_DIGITAL_GAIN_1_FOR_GREEN_1_PIXELS_REG                                               0x6B    // Digtal Gain 1 for Green 1 Pixels Register
#define CAM_DIGITAL_GAIN_1_FOR_GREEN_2_PIXELS_REG                                               0x6C    // Digtal Gain 1 for Green 2 Pixels Register
#define CAM_DIGITAL_GAIN_1_FOR_BLUE_PIXELS_REG                                                  0x6D    // Digtal Gain 1 for Blue Pixels Register
#define CAM_DIGITAL_GAIN_1_FOR_ALL_COLORS_REG                                                   0x6E    // Digtal Gain 1 for All Colors Register
#define CAM_BOUNDARIES_OF_FLICKER_MEASUREMENT_WINDOW_LEFT_RIGHT_REG                             0x7A    // Boundaries Of Flicker Measurement Window (Left/Right) Register
#define CAM_BOUNDARIES_OF_FLICKER_MEASUREMENT_WINDOW_TOP_BOTTOM_REG                             0x7B    // Boundaries Of Flicker Measurement Window (Top/Bottom) Register
#define CAM_FLICKER_MEASUREMENT_WINDOW_SIZE_REG                                                 0x7C    // Flicker Measurement Window Size Register
#define CAM_MEASUREMENT_OF_AVERAGE_LUMINANCE_IN_FLICKER_MEASUREMENT_WINDOW_REG                  0x7D    // Measure Of Average Luminance In Flicker Measurement Window Register
#define CAM_BLANK_FRAMES_REG                                                                    0x96    // Blank Frames Register
#define CAM_OUTPUT_FORMAT_CONFIGURATION_REG                                                     0x97    // Output Format Configuration Register
#define CAM_OUTPUT_FORMAT_TEST_REG                                                              0x98    // Output Format Test Register
#define CAM_LINE_COUNT_REG                                                                      0x99    // Line Count Register
#define CAM_FRAME_COUNT_REG                                                                     0x9A    // Frame Count Register
#define CAM_SPECIAL_EFFECTS_REG                                                                 0xA4    // Special Effects Register
#define CAM_SEPIA_CONSTANTS_REG                                                                 0xA5    // Sepia Constants Register
#define CAM_GAMMA_CURVE_KNEES_0_AND_1_REG                                                       0xB2    // Gamma Curve Knees 0 And 1 Register
#define CAM_GAMMA_CURVE_KNEES_2_AND_3_REG                                                       0xB3    // Gamma Curve Knees 2 And 3 Register
#define CAM_GAMMA_CURVE_KNEES_4_AND_5_REG                                                       0xB4    // Gamma Curve Knees 4 And 5 Register
#define CAM_GAMMA_CURVE_KNEES_6_AND_7_REG                                                       0xB5    // Gamma Curve Knees 6 And 7 Register
#define CAM_GAMMA_CURVE_KNEES_8_AND_9_REG                                                       0xB6    // Gamma Curve Knees 8 And 9 Register
#define CAM_GAMMA_CURVE_KNEES_10_AND_11_REG                                                     0xB7    // Gamma Curve Knees 10 And 11 Register
#define CAM_GAMMA_CURVE_KNEES_12_AND_13_REG                                                     0xB8    // Gamma Curve Knees 12 And 13 Register
#define CAM_GAMMA_CURVE_KNEES_14_AND_15_REG                                                     0xB9    // Gamma Curve Knees 14 And 15 Register
#define CAM_GAMMA_CURVE_KNEES_16_AND_17_REG                                                     0xBA    // Gamma Curve Knees 16 And 17 Register
#define CAM_GAMMA_CURVE_KNEE_18_REG                                                             0xBB    // Gamma Curve Knee 18 Register
#define CAM_YUV_YCBCR_CONTROL_REG                                                               0xBE    // YUV/YCbCr Control Register
#define CAM_Y_RGB_OFFSET_REG                                                                    0xBF    // Y/RGB Offset Register
#define CAM_MICROCONTROLLER_BOOT_MODE_REG                                                       0xC3    // Microcontroller Boot Mode Register
#define CAM_MICROCONTROLLER_VARIABLE_ADDRESS_REG                                                0xC6    // Microcontroller Variable Address Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_REG                                                   0xC8    // Microcontroller Variable Data Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_REG                              0xC9    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_0_REG                            0xC9    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 0 Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_1_REG                            0xCA    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 1 Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_2_REG                            0xCB    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 2 Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_3_REG                            0xCC    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 3 Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_4_REG                            0xCD    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 4 Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_5_REG                            0xCE    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 5 Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_6_REG                            0xCF    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 6 Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_7_REG                            0xD0    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 7 Register
#define CAM_MICROCONTROLLER_VARIABLE_DATA_USING_B2W_SIF_ACCESS_8_REG                            0xD1    // Microcontroller Variable Data Using Burst Two-Wire Serial Interface Access 8 Register

/* IFP Registers, Page 2 */
#define CAM_JPEG_CONTROL_REG                                                                    0x00    // JPEG Control Register
#define CAM_JPEG_STATUS_0_REG                                                                   0x02    // JPEG Status Register 0
#define CAM_JPEG_STATUS_1_REG                                                                   0x03    // JPEG Status Register 1 - JPEG Data Length Bits 15:0
#define CAM_JPEG_STATUS_2_REG                                                                   0x04    // JPEG Status Register 2 - Output FIFO Fullness Status
#define CAM_JPEG_FRONT_END_CONFIGURATION_REG                                                    0x05    // JPEG Front End Configuration Register
#define CAM_JPEG_CORE_CONFIGURATION_REG                                                         0x06    // JPEG Core Configuration Register - Extend JPEG Quantization Matrix
#define CAM_JPEG_ENCODER_BYPASS_REG                                                             0x0A    // JPEG Encoder Bypass
#define CAM_OUTPUT_CONFIGURATION_REG                                                            0x0D    // Output Configuration Register
#define CAM_OUTPUT_PCLK1_AND_PCLK2_CONFIGURATION_REG                                            0x0E    // Output PCLK1 & PCLK2 Configuration Register
#define CAM_OUTPUT_PCLK3_CONFIGURATION_REG                                                      0x0F    // Output PCLK3 Configuration Register
#define CAM_SPOOF_FRAME_WIDTH_REG                                                               0x10    // Spoof Frame Width Register
#define CAM_SPOOF_FRAME_HEIGHT_REG                                                              0x11    // Spoof Frame Height Register
#define CAM_SPOOF_FRAME_LINE_TIMING_REG                                                         0x12    // Spoof Frame Line Timing Register
#define CAM_JPEG_RAM_TEST_CONTROL_REG                                                           0x1D    // JPEG RAM Test Control Register
#define CAM_JPEG_INDIRECT_ACCESS_CONTROL_REG                                                    0x1E    // JPEG Indirect Access Control Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_REG                                                       0x1F    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_0_REG                                                     0x1F    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_1_REG                                                     0x20    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_2_REG                                                     0x21    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_3_REG                                                     0x22    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_4_REG                                                     0x23    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_5_REG                                                     0x24    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_6_REG                                                     0x25    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_7_REG                                                     0x26    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_8_REG                                                     0x27    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_9_REG                                                     0x28    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_10_REG                                                    0x29    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_11_REG                                                    0x2A    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_12_REG                                                    0x2B    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_13_REG                                                    0x2C    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_14_REG                                                    0x2D    // JPEG Indirect Access Data Register
#define CAM_JPEG_INDIRECT_ACCESS_DATA_15_REG                                                    0x2E    // JPEG Indirect Access Data Register
#define CAM_BOUNDARIES_OF_FIRST_AF_MEASUREMENT_WINDOW_TOP_LEFT_REG                              0x40    // Boundaries of First AF Measurement Window (Top/Left) Register
#define CAM_BOUNDARIES_OF_FIRST_AF_MEASUREMENT_WINDOW_HEIGHT_WIDTH_REG                          0x41    // Boundaries of First AF Measurement Window (Height/Width) Register
#define CAM_AF_MEASUREMENT_WINDOW_SIZE_REG                                                      0x42    // AF Measurement Window Size Register
#define CAM_AVERAGE_LUMINANCE_IN_AF_WINDOWS_W12_AND_W11_REG                                     0x43    // Average Luminance in AF Windows W12 and W11 Register
#define CAM_AVERAGE_LUMINANCE_IN_AF_WINDOWS_W14_AND_W13_REG                                     0x44    // Average Luminance in AF Windows W14 and W13 Register
#define CAM_AVERAGE_LUMINANCE_IN_AF_WINDOWS_W22_AND_W21_REG                                     0x45    // Average Luminance in AF Windows W22 and W21 Register
#define CAM_AVERAGE_LUMINANCE_IN_AF_WINDOWS_W24_AND_W23_REG                                     0x46    // Average Luminance in AF Windows W24 and W23 Register
#define CAM_AVERAGE_LUMINANCE_IN_AF_WINDOWS_W32_AND_W31_REG                                     0x47    // Average Luminance in AF Windows W32 and W31 Register
#define CAM_AVERAGE_LUMINANCE_IN_AF_WINDOWS_W34_AND_W33_REG                                     0x48    // Average Luminance in AF Windows W34 and W33 Register
#define CAM_AVERAGE_LUMINANCE_IN_AF_WINDOWS_W42_AND_W41_REG                                     0x49    // Average Luminance in AF Windows W42 and W41 Register
#define CAM_AVERAGE_LUMINANCE_IN_AF_WINDOWS_W44_AND_W43_REG                                     0x4A    // Average Luminance in AF Windows W44 and W43 Register
#define CAM_AF_FILTER_1_COEFFICIENTS_REG                                                        0x4B    // AF Filter 1 Coefficients Register
#define CAM_AF_FILTER_1_CONFIGURATION_REG                                                       0x4C    // AF Filter 1 Configuration Register
#define CAM_AF_FILTER_1_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W12_AND_W11_REG                0x4D    // AF Filter 1 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_1_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W14_AND_W13_REG                0x4E    // AF Filter 1 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_1_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W22_AND_W21_REG                0x4F    // AF Filter 1 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_1_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W24_AND_W23_REG                0x50    // AF Filter 1 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_1_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W32_AND_W31_REG                0x51    // AF Filter 1 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_1_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W34_AND_W33_REG                0x52    // AF Filter 1 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_1_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W42_AND_W41_REG                0x53    // AF Filter 1 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_1_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W44_AND_W43_REG                0x54    // AF Filter 1 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_2_COEFFICIENTS_REG                                                        0x55    // AF Filter 2 Coefficients Register
#define CAM_AF_FILTER_2_CONFIGURATION_REG                                                       0x56    // AF Filter 2 Configuration Register
#define CAM_AF_FILTER_2_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W12_AND_W11_REG                0x57    // AF Filter 2 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_2_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W14_AND_W13_REG                0x58    // AF Filter 2 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_2_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W22_AND_W21_REG                0x59    // AF Filter 2 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_2_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W24_AND_W23_REG                0x5A    // AF Filter 2 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_2_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W32_AND_W31_REG                0x5B    // AF Filter 2 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_2_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W34_AND_W33_REG                0x5C    // AF Filter 2 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_2_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W42_AND_W41_REG                0x5D    // AF Filter 2 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_AF_FILTER_2_AVERAGE_SHARPNESS_MEASURE_FOR_AF_WINDOWS_W44_AND_W43_REG                0x5E    // AF Filter 2 Average Sharpness Measure for AF Windows W12 And W11 Register
#define CAM_LENS_CORRECTION_CONTROL_REG                                                         0x80    // Lens Correction Control Register
#define CAM_ZONE_BOUNDARIES_X1_AND_X2_REG                                                       0x81    // Zone Boundaries X1 and X2 Register
#define CAM_ZONE_BOUNDARIES_X0_AND_X3_REG                                                       0x82    // Zone Boundaries X0 and X3 Register
#define CAM_ZONE_BOUNDARIES_X4_AND_X5_REG                                                       0x83    // Zone Boundaries X4 and X5 Register
#define CAM_ZONE_BOUNDARIES_Y1_AND_Y2_REG                                                       0x84    // Zone Boundaries Y1 and Y2 Register
#define CAM_ZONE_BOUNDARIES_Y0_AND_Y3_REG                                                       0x85    // Zone Boundaries Y0 and Y3 Register
#define CAM_ZONE_BOUNDARIES_Y4_AND_Y5_REG                                                       0x86    // Zone Boundaries Y4 and Y5 Register
#define CAM_CENTER_OFFSET_REG                                                                   0x87    // Center Offset Register
#define CAM_FX_FOR_RED_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                                0x88    // F(x) for Red Color at the First Pixel of the Array Register
#define CAM_FX_FOR_GREEN_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                              0x89    // F(x) for Green Color at the First Pixel of the Array Register
#define CAM_FX_FOR_BLUE_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                               0x8A    // F(x) for Blue Color at the First Pixel of the Array Register
#define CAM_FY_FOR_RED_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                                0x8B    // F(y) for Red Color at the First Pixel of the Array Register
#define CAM_FY_FOR_GREEN_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                              0x8C    // F(y) for Green Color at the First Pixel of the Array Register
#define CAM_FY_FOR_BLUE_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                               0x8D    // F(y) for Blue Color at the First Pixel of the Array Register
#define CAM_DF_DX_FOR_RED_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                             0x8E    // dF/dx for Red Color at the First Pixel of the Array Register
#define CAM_DF_DX_FOR_GREEN_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                           0x8F    // dF/dx for Green Color at the First Pixel of the Array Register
#define CAM_DF_DX_FOR_BLUE_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                            0x90    // dF/dx for Blue Color at the First Pixel of the Array Register
#define CAM_DF_DY_FOR_RED_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                             0x91    // dF/dy for Red Color at the First Pixel of the Array Register
#define CAM_DF_DY_FOR_GREEN_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                           0x92    // dF/dy for Green Color at the First Pixel of the Array Register
#define CAM_DF_DY_FOR_BLUE_COLOR_AT_THE_FIRST_PIXEL_OF_THE_ARRAY_REG                            0x93    // dF/dy for Blue Color at the First Pixel of the Array Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_0_RED_COLOR_REG                                          0x94    // Second Derivative for Zone 0 Red Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_0_GREEN_COLOR_REG                                        0x95    // Second Derivative for Zone 0 Green Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_0_BLUE_COLOR_REG                                         0x96    // Second Derivative for Zone 0 Blue Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_1_RED_COLOR_REG                                          0x97    // Second Derivative for Zone 1 Red Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_1_GREEN_COLOR_REG                                        0x98    // Second Derivative for Zone 1 Green Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_1_BLUE_COLOR_REG                                         0x99    // Second Derivative for Zone 1 Blue Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_2_RED_COLOR_REG                                          0x9A    // Second Derivative for Zone 2 Red Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_2_GREEN_COLOR_REG                                        0x9B    // Second Derivative for Zone 2 Green Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_2_BLUE_COLOR_REG                                         0x9C    // Second Derivative for Zone 2 Blue Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_3_RED_COLOR_REG                                          0x9D    // Second Derivative for Zone 3 Red Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_3_GREEN_COLOR_REG                                        0x9E    // Second Derivative for Zone 3 Green Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_3_BLUE_COLOR_REG                                         0x9F    // Second Derivative for Zone 3 Blue Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_4_RED_COLOR_REG                                          0xA0    // Second Derivative for Zone 4 Red Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_4_GREEN_COLOR_REG                                        0xA1    // Second Derivative for Zone 4 Green Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_4_BLUE_COLOR_REG                                         0xA2    // Second Derivative for Zone 4 Blue Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_5_RED_COLOR_REG                                          0xA3    // Second Derivative for Zone 5 Red Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_5_GREEN_COLOR_REG                                        0xA4    // Second Derivative for Zone 5 Green Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_5_BLUE_COLOR_REG                                         0xA5    // Second Derivative for Zone 5 Blue Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_6_RED_COLOR_REG                                          0xA6    // Second Derivative for Zone 6 Red Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_6_GREEN_COLOR_REG                                        0xA7    // Second Derivative for Zone 6 Green Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_6_BLUE_COLOR_REG                                         0xA8    // Second Derivative for Zone 6 Blue Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_7_RED_COLOR_REG                                          0xA9    // Second Derivative for Zone 7 Red Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_7_GREEN_COLOR_REG                                        0xAA    // Second Derivative for Zone 7 Green Color Register
#define CAM_SECOND_DERIVATIVE_FOR_ZONE_7_BLUE_COLOR_REG                                         0xAB    // Second Derivative for Zone 7 Blue Color Register
#define CAM_X2_FACTORS_REG                                                                      0xAC    // X2 Factors Register
#define CAM_GLOBAL_OFFSET_OF_FXY_FUNCTION_REG                                                   0xAD    // Global Offset_of F(x,y) Function Register
#define CAM_K_FACTOR_IN_K_FX_FY_REG                                                             0xAE    // K Factor in K F(x) F(y) Register
#define CAM_BOUNDARIES_OF_FIRST_AE_MEASUREMENT_WINDOW_TOP_LEFT_REG                              0xC0    // Boundaries of First AE Measurement Window (Top/Left) Register
#define CAM_BOUNDARIES_OF_FIRST_AE_MEASUREMENT_WINDOW_HEIGHT_WIDTH_REG                          0xC1    // Boundaries of First AE Measurement Window (Height/Width) Register
#define CAM_AE_MEASUREMENT_WINDOW_SIZE_REG                                                      0xC2    // AE Measurement Window Size Register
#define CAM_AE_AF_MEASUREMENT_ENABLE_REG                                                        0xC3    // AE/AF Measurement Enable Register
#define CAM_AVERAGE_LUMINANCE_IN_AE_WINDOWS_W12_AND_W11_REG                                     0xC4    // Average Luminance in AE Windows W12 and W11 Register
#define CAM_AVERAGE_LUMINANCE_IN_AE_WINDOWS_W14_AND_W13_REG                                     0xC5    // Average Luminance in AE Windows W14 and W13 Register
#define CAM_AVERAGE_LUMINANCE_IN_AE_WINDOWS_W22_AND_W21_REG                                     0xC6    // Average Luminance in AE Windows W22 and W21 Register
#define CAM_AVERAGE_LUMINANCE_IN_AE_WINDOWS_W24_AND_W23_REG                                     0xC7    // Average Luminance in AE Windows W24 and W23 Register
#define CAM_AVERAGE_LUMINANCE_IN_AE_WINDOWS_W32_AND_W31_REG                                     0xC8    // Average Luminance in AE Windows W32 and W31 Register
#define CAM_AVERAGE_LUMINANCE_IN_AE_WINDOWS_W34_AND_W33_REG                                     0xC9    // Average Luminance in AE Windows W34 and W33 Register
#define CAM_AVERAGE_LUMINANCE_IN_AE_WINDOWS_W42_AND_W41_REG                                     0xCA    // Average Luminance in AE Windows W42 and W41 Register
#define CAM_AVERAGE_LUMINANCE_IN_AE_WINDOWS_W44_AND_W43_REG                                     0xCB    // Average Luminance in AE Windows W44 and W43 Register
#define CAM_SATURATION_AND_COLOR_KILL_REG                                                       0xD2    // Saturation and Color Kill Register
#define CAM_HISTOGRAM_WINDOW_LOWER_BOUNDARIES_REG                                               0xD3    // Histogram Window Lower Boundaries Register
#define CAM_HISTOGRAM_WINDOW_UPPER_BOUNDARIES_REG                                               0xD4    // Histogram Window Upper Boundaries Register
#define CAM_FIRST_SET_OF_BIN_DEFINITIONS_REG                                                    0xD5    // First Set of Bin Definitions Register
#define CAM_SECOND_SET_OF_BIN_DEFINITIONS_REG                                                   0xD6    // Second Set of Bin Definitions Register
#define CAM_HISTOGRAM_WINDOW_SIZE_REG                                                           0xD7    // Histogram Window Size Register
#define CAM_PIXEL_COUNTS_FOR_BIN0_AND_BIN1_REG                                                  0xD8    // Pixel Counts for Bin 0 and Bin 1 Register
#define CAM_PIXEL_COUNTS_FOR_BIN2_AND_BIN3_REG                                                  0xD9    // Pixel Counts for Bin 2 and Bin 3 Register
#define CAMDLY                                                                                  0xFF


/*****************************************************************************
*
* Enum
*
******************************************************************************/
enum
{
	SET_EFFECTCANCEL=0,
	SET_EFFECTMONO,
	SET_EFFECTSEPIA,
	SET_EFFECTNEGA,
	SET_EFFECTSOLA1,
	SET_EFFECTSOLA2,
	SET_EFFECTMENU1,
	SET_EFFECTMENU2,
	SET_EFFECTMENU3,
	SET_EFFECTMENU4,
	SET_EFFECTMENU5,
	SET_EFFECTMENU6,
	SET_EFFECTMENU7,
	SET_EFFECTMENU8,	
	SET_EFFECTNONE
};

enum
{
	SET_WB_DEFAULT,
	SET_WB_DAYLIGHT,
 	SET_WB_COOLWHITE,
	SET_WB_TL84,
 	SET_WB_WHITHLIGHT,
	SET_WB_HORIZON
};


/*****************************************************************************
*
* Type Defines
*
******************************************************************************/
typedef struct _SENSOR_DATA
{
    unsigned char Add;
    unsigned int Data;
}SENSOR_DATA;

/*****************************************************************************
*
* Structures
*
******************************************************************************/

/*****************************************************************************
*
* External Variables
*
******************************************************************************/

/*****************************************************************************
*
* External Functions
*
******************************************************************************/
void tca_sensor_cameramoduleinit(unsigned char ucPreviewMode);
void tca_sensor_capture(unsigned char ucOnOff);
void tca_sensor_init(void);
void tca_sensor_contextadata(void);
void tca_sensor_contextbdata(void);
void tca_sensor_daymode(void);
void tca_sensor_nightmode(void);
void tca_sensor_effect(unsigned char ucMode);
void tca_sensor_brightness(unsigned char ucMode);
void tca_sensor_whitebalance(unsigned char ucMode);
void tca_sensor_resolution(unsigned int usResolution);

#if 0 // TEST zminc
void tca_sensor_powerdown(void);
void tca_sensor_powerresume(void);
#endif
//void CAM_SEND_CMD(unsigned int uiAddr, unsigned int uiData);



#ifdef __cplusplus
 } 
#endif

#endif	//__TCA_SENSORMODULE_H__
/* end of file */