#define		ON			1
#define		OFF			0
#define		SNAPSHOT_PREVIEW			1
#define		CAMCODER_PREVIEW			2


typedef struct _SENSOR_DATA
{
    unsigned int Addr;
    unsigned int Data;
}SENSOR_DATA;


void tca_mt9d112_moduleinit(unsigned char ucPreviewMode);
void tca_mt9d112_capture(unsigned char ucOnOff);
unsigned int tca_mt9d112_checki2s(void);
void tca_mt9d112_camresetonoff(void *pGPIORegAddr, unsigned int uiON);
