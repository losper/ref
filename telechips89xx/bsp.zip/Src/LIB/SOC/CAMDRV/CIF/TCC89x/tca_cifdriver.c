
/****************************************************************************
 *   FileName    : tca_cifdriver.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
/ ****************************************************************************/

/****************************************************************************
*
* Header Files Include
*
******************************************************************************/
#include "bsp.h"
#include "camdef.h"
#include "tca_cifdriver.h"
#include "CIFRegisterSet.h"


/*****************************************************************************
*
* Defines
*
******************************************************************************/

/*****************************************************************************
*
* Enum
*
******************************************************************************/

/*****************************************************************************
*
* Type Defines
*
******************************************************************************/

/*****************************************************************************
*
* Structures
*
******************************************************************************/

/*****************************************************************************
*
* External Variables
*
******************************************************************************/

/*****************************************************************************
*
* Local Functions
*
******************************************************************************/

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_timedly(int ticks)
{
	volatile int ms;
	while(ticks --){
		ms = 2000;
		while(ms --);
	}
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_portopen(void *pCIFRegAddr, void *pGPIORegAddr, void *pCKCRegAddr, void *pDDICONFIGRegAddr)
{
	GPIO *pGPIOReg = (GPIO*)pGPIORegAddr;
	DDICONFIG *pDDICONFIGReg = (DDICONFIG*)pDDICONFIGRegAddr;
	CKC *pCKCReg = (CKC *)pCKCRegAddr;
	//This register doesn't exist.
	//BITSET(HwBCLKCTR, HwBCLKCTR_CIC_ON|Hw30); //CAM and MailBox
	BITSET(pCKCReg->PCLK_CIFMC, Hw28);
	
	BITCSET(pGPIOReg->GPEPD0, 0xFF000000, 0xAA000000); // Camera Port D0~D3 Pull down
	BITCSET(pGPIOReg->GPEPD1, 0x00003FFF, 0x00002AAA); // Camera Port D4~D7, cvs,chs,cki Pull down
	
	//CPD[0] - CPD[3]
	BITCSET(pGPIOReg->GPEFN1, 0xFFFF0000, Hw28|Hw24|Hw20|Hw16);
	//CCKI, CVS, CHS, CCKO, CPD[7] - CPD[4]
	BITCSET(pGPIOReg->GPEFN2, 0xFFFFFFFF, Hw28|Hw24|Hw20|Hw16|Hw12|Hw8|Hw4|Hw0);
	BITCLR(pGPIOReg->GPEEN, 0x7FF000); // CPD Data bus as Input mode
//	BITSET(pGPIOReg->GPEEN, 0x800000); // CCKO output mode
	BITSET(pGPIOReg->GPEEN, 0x4800000); // CCKO output mode

	//Enable Scaler Clock divider enable register 
	BITSET(pCKCReg->PCLK_CIFSC, Hw28);

	//Disable DDIBUS PWDN for CIF
	BITCLR(pDDICONFIGReg->PWDN, Hw0);
	
	//SWReset for DDIBUS(Camera interface)
	BITSET(pDDICONFIGReg->SWRESET, Hw0);
	BITCLR(pDDICONFIGReg->SWRESET, Hw0);

	tca_cif_setinterrupt(pCIFRegAddr, SET_CIF_INT_DISABLE);
	tca_cif_setinterrupt(pCIFRegAddr, SET_CIF_RESPONCEINT_ENABLE);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_portclose(void *pGPIORegAddr, void *pCKCRegAddr, void *pDDICONFIGRegAddr)
{
	GPIO *pGPIOReg = (GPIO*)pGPIORegAddr;
	CKC *pCKCReg = (CKC *)pCKCRegAddr;
	DDICONFIG *pDDICONFIGReg = (DDICONFIG*)pDDICONFIGRegAddr;
	tca_cif_set_ctrl(pCKCRegAddr, SET_CIF_OPERATING_DISABLE, 0, 0);	
	tca_cif_setinterrupt(pCKCRegAddr, SET_CIF_INT_DISABLE);	
	//Disable CAM Clock divider enable register 
	BITCLR(pCKCReg->PCLK_CIFMC, Hw28);
	//SWReset for DDIBUS(Camera interface)
	//BITSET(pDDICONFIGReg->SWRESET, Hw0);
	BITCLR(pDDICONFIGReg->SWRESET, Hw0);

	//Enable DDIBUS PWDN for CIF
	BITSET(pDDICONFIGReg->PWDN, Hw0);	
	//[GPIO set output & low] 
	BITCSET(pGPIOReg->GPEFN1, 0xFFFF0000, 0);//CPD[0] - CPD[3]
	BITCSET(pGPIOReg->GPEFN2, 0xFFFFFFFF, 0);//CCKI, CVS, CHS, CCKO, CPD[7] - CPD[4]
	BITSET(pGPIOReg->GPEEN, 0xFFF000);
	BITCLR(pGPIOReg->GPEDAT, 0xFFF000);
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_onoff_new(void *pCIFRegAddr, void *pCKCRegAddr, void *pGPIORegAddr, void *pDDICONFIGRegAddr, unsigned int uiControl)
{
	GPIO *pGPIOReg = (GPIO *)pGPIORegAddr;
	CKC *pCKCReg = (CKC *)pCKCRegAddr;
	DDICONFIG *pDDICONFIGReg = (DDICONFIG*)pDDICONFIGRegAddr;

	if(uiControl == ON)
	{
		// Wait Until CVS Port being Low
	 	while (pGPIOReg->GPEDAT & Hw21);	

		//DDI_CIF_SetCtrl(SET_CIF_OPERATING_ENABLE, 0, 0);
		tca_cif_set_ctrl(pCIFRegAddr, SET_CIF_OPERATING_ENABLE, 0, 0);
	}
	else if(uiControl == OFF)
	{
		//DDI_CIF_SetInterrupt(SET_CIF_INT_DISABLE);	
		//DDI_CIF_SetCtrl(SET_CIF_OPERATING_DISABLE, 0, 0);
		tca_cif_setinterrupt(pCIFRegAddr, SET_CIF_INT_DISABLE);	
		tca_cif_set_ctrl(pCIFRegAddr, SET_CIF_OPERATING_DISABLE, 0, 0);
		//Disable CAM Clock divider enable register 
		BITCLR(pCKCReg->PCLK_CIFMC, Hw28);
		//Disable Scaler Clock divider enable register 
		BITCLR(pCKCReg->PCLK_CIFSC, Hw28);
		//SWReset for DDIBUS(Camera interface)
		BITSET(pDDICONFIGReg->SWRESET, Hw0);
		BITCLR(pDDICONFIGReg->SWRESET, Hw0);
	}
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
int	tca_cif_opstart(void *pCIFRegAddr, void *pGPIORegAddr , unsigned int mode, unsigned int cam_mod)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	GPIO *pGPIOReg = (GPIO *)pGPIORegAddr;	
	int ErrCnt = 0;
	// Set CVS(CAM_VS) Port Direction into Input-Mode
	BITCSET(pGPIOReg->GPEFN2, (Hw24-Hw20), Hw20);
	BITCLR(pGPIOReg->GPEEN, Hw21);

	tca_cif_setinterrupt(pCIFRegAddr, SET_CIF_CAPFRAME_DISABLE);
	tca_cif_setcapturectrl(pCIFRegAddr, SET_CIF_CAP_DISABLE);

	if(cam_mod == TVP5150A || cam_mod==TVP5150A_PAL)
	{
		if(mode == 1) // Used YUV422 Deinterlace
		{
			BITSET (pCIFReg->ICPCR1, Hw28);
			BITSET(pCIFReg->CCIR656FCR2, Hw13|Hw12|Hw10);
		}
		else
			BITCLR(pCIFReg->ICPCR1, Hw26);
	}
	else
	{
		// Wait Until CVS(CAM_VS) Port being Low
		while (pGPIOReg->GPEDAT & Hw21);
	}

	// Enable CIF
	BITSET (pCIFReg->ICPCR1, Hw31);

	// Wait Until Receiving the Stored One Frame
	if(cam_mod == TVP5150A || cam_mod==TVP5150A_PAL)
	{
		if(mode == 1) // Used YUV422 Deinterlace
		{
			BITCLR(pCIFReg->CIRQ, Hw30);
		}
		BITCLR(pCIFReg->CIRQ, Hw0);
	}	
	BITSET(pCIFReg->CIRQ, Hw0);

	while ((pCIFReg->CIRQ & Hw0) != Hw0) // Get One Frame
	{
		tca_cif_timedly(1);
		if(ErrCnt ++ > 2000)
		{
			return CIF_NORESPONSE;
		}
	}
	BITSET(pCIFReg->CIRQ, Hw0);

	if(cam_mod == TVP5150A || cam_mod==TVP5150A_PAL)
	{
		if(mode == 1) // Used YUV422 Deinterlace
			tca_cif_setinterrupt(pCIFRegAddr, SET_CIF_INTTYPE_HOLDUP);
		else
			tca_cif_setinterrupt(pCIFRegAddr, SET_CIF_REGISTERUP_VSYNC|SET_CIF_INTTYPE_HOLDUP);
	}
	else
		tca_cif_setinterrupt(pCIFRegAddr, SET_CIF_REGISTERUP_VSYNC|SET_CIF_INTTYPE_HOLDUP);

	return CIF_SUCCESS;
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_opstop(void *pCIFRegAddr, void *pGPIORegAddr)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	GPIO *pGPIOReg = (GPIO *)pGPIORegAddr;
	// Set CVS Port Direction into Input-Mode
	BITCSET(pGPIOReg->GPEFN2, (Hw24-Hw20), Hw20);
	BITCLR(pGPIOReg->GPEEN, Hw21);

	// Wait Until CVS Port being Low
 	while (pGPIOReg->GPEDAT & Hw21);

	//Disable CIF
	BITCLR (pCIFReg->ICPCR1, Hw31);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_opresume(void *pCIFRegAddr, void *pGPIORegAddr, unsigned int cam_mod)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	GPIO *pGPIOReg = (GPIO *)pGPIORegAddr;
	// Wait Until CVS(CAM_VS) Port being Low
	if(cam_mod != TVP5150A || cam_mod==TVP5150A_PAL)
		while (pGPIOReg->GPEDAT & Hw21);

	// Enable CIF
	BITSET (pCIFReg->ICPCR1, Hw31);
}

void tca_cif_getcapturedframe(void *pCIFRegAddr, void *pGPIORegAddr)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	GPIO *pGPIOReg = (GPIO *)pGPIORegAddr;
	//Clear VS positive
	BITSET(pCIFReg->CIRQ, Hw9);
	//Clear Stored One Frame
	BITSET(pCIFReg->CIRQ, Hw0);
	//Wait Stored One Frame
	while (tca_cif_readintstatus(pCIFRegAddr, READ_CIF_ONEFRAME_STATUS) != Hw0);
	//Clear Stored One Frame
	BITSET(pCIFReg->CIRQ, Hw0);
	//Wait VS positive
	while (tca_cif_readintstatus(pCIFRegAddr, READ_CIF_VSPOSI_STATUS) != Hw9);
	//Clear VS positive
	BITSET(pCIFReg->CIRQ, Hw9);
	//Wait Stored One Frame
	while (tca_cif_readintstatus(pCIFRegAddr, READ_CIF_ONEFRAME_STATUS) != Hw0);

	tca_cif_setcapturectrl(pCIFRegAddr, SET_CIF_CAP_ENABLE);
	//Wait Stored One Frame
	while (tca_cif_readintstatus(pCIFRegAddr, READ_CIF_ONEFRAME_STATUS) != Hw0);

	//Stored One Frame
	BITSET(pCIFReg->CIRQ, Hw0);
	//VS positive(CVS rising edge is detected)
	BITSET(pCIFReg->CIRQ, Hw9);
	//VS negative(CVS falling edge is detected)
	BITSET(pCIFReg->CIRQ, Hw10);
	//SF(Scaler Finish)
	BITSET(pCIFReg->CIRQ, Hw6);
	//SE(Scaler Error)
	BITSET(pCIFReg->CIRQ, Hw7);

	tca_cif_opstop(pCIFRegAddr, pGPIORegAddr);
}
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_set_info(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiBypass, unsigned int uiBypassBusSel, unsigned int uiColorPattern, unsigned int uiPatternFormat, unsigned int uiRGBMode, unsigned int uiRGBBitMode, unsigned int uiColorSequence, unsigned int uiBusOrder)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	unsigned uICPCR1 = pCIFReg->ICPCR1;

	if(uiFlag & SET_CIF_BYPASS_MODE)
	{
		//Bypass (Non-Separate) 
		//BP 0 : if M420 is set, YUV4:2:0. Otherwise, YUV4:2:2
		//BP 1 : YUV4:2:2SEQ0
		BITCSET(uICPCR1, Hw15, (uiBypass << 15));
	}	

	if(uiFlag & SET_CIF_BYPASS_BUS)
	{
		//????
		BITCSET(uICPCR1, Hw14, (uiBypassBusSel << 14));
	}	

	if(uiFlag & SET_CIF_COLOR_PATTERN)
	{
		//Color Pattern
		BITCSET(uICPCR1, Hw12, (uiColorPattern << 12));
	}	

	if(uiFlag & SET_CIF_PATTERN_FORMAT)
	{
		//Pattern Format
		BITCSET(uICPCR1, (Hw11|Hw10), (uiPatternFormat << 10));
	}	

	if(uiFlag & SET_CIF_RGB_MODE)
	{
		//RGB Mode
		BITCSET(uICPCR1, (Hw9|Hw8), (uiRGBMode << 8));
	}	

	if(uiFlag & SET_CIF_RGBBIT_MODE)
	{
		//RGB Bit Mode
		BITCSET(uICPCR1, (Hw7|Hw6), (uiRGBBitMode << 6));
	}	

	if(uiFlag & SET_CIF_COLOR_SEQUENCE)
	{
		//Color Sequence
		BITCSET(uICPCR1, (Hw5|Hw4), (uiColorSequence << 4));
	}	

	if(uiFlag & SET_CIF_BUS_ORDER)
	{
		//Bus order
		BITCSET(uICPCR1, Hw2, (uiBusOrder << 2));
	}	
	pCIFReg->ICPCR1 = uICPCR1;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_set_ctrl(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiSkipFrame, unsigned int uiM420)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	unsigned uICPCR1 = pCIFReg->ICPCR1;
	
	if(uiFlag & SET_CIF_OPERATING_ENABLE)
	{
		//Enable CIF
		BITSET(uICPCR1, Hw31);
	}
	if(uiFlag & SET_CIF_OPERATING_DISABLE)
	{
		//Disable CIF
		BITCLR(uICPCR1, Hw31);
	}
	if(uiFlag & SET_CIF_PWDN_ENABLE)
	{
		//Enable Power down mode in camera
		BITSET(uICPCR1, Hw30);
	}
	if(uiFlag & SET_CIF_PWDN_DISABLE)
	{
		//Disable Power down mode in camera
		BITCLR(uICPCR1, Hw30);
	}
	if(uiFlag & SET_CIF_BYPASS_SCALER_ENABLE)
	{
		//CIF scaler is used
		BITSET(uICPCR1, Hw23);
	}
	if(uiFlag & SET_CIF_BYPASS_SCALER_DISABLE)
	{
		//CIF scaler is not used
		BITCLR(uICPCR1, Hw23);
	}
	if(uiFlag & SET_CIF_PXCLK_NEGATIVE_EDGE)
	{
		//PXCLK Polarity is falling edge.
		BITSET(uICPCR1, Hw21);
	}
	if(uiFlag & SET_CIF_PXCLK_POSITIVE_EDGE)
	{
		//PXCLK Polarity is rising edge.
		BITCLR(uICPCR1, Hw21);
	}
	if(uiFlag & SET_CIF_SKIPFRAME_ENABLE)
	{
		//Number of frames to be skipped.
		BITCSET(uICPCR1, 0x001C0000, (uiSkipFrame << 18));
	}
	if(uiFlag & SET_CIF_SKIPFRAME_DISABLE)
	{
		//Not skipped
		BITCLR(uICPCR1, 0x001C0000);
	}
	if(uiFlag & SET_CIF_420CONVERT_ENABLE)
	{
		//Enable YUV4:2:2 -> 4:2:0
		BITCSET(uICPCR1, 0x00030000, (uiM420 << 16));
	}
	if(uiFlag & SET_CIF_420CONVERT_DISABLE)
	{
		//Disable YUV4:2:2 -> 4:2:0
		BITCLR(uICPCR1, 0x00030000);
	}
	if(uiFlag & SET_CIF_656CONVERT_ENABLE)
	{
		//Enable convert 656 format
		BITSET(uICPCR1, Hw13);
	}
	if(uiFlag & SET_CIF_656CONVERT_DISABLE)
	{
		//Enable convert 656 format
		BITCLR(uICPCR1, Hw13);
	}
	if(uiFlag & SET_CIF_TVSIGNAL_ENABLE)
	{
		//TV sync signal
		BITSET(uICPCR1, Hw29);
	}
	if(uiFlag & SET_CIF_TVSIGNAL_DISABLE)
	{
		//CIF sync signal
		BITCLR(uICPCR1, Hw29);
	}

	pCIFReg->ICPCR1 = uICPCR1;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_set_transfer(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiTransMode, unsigned int uiBurst, unsigned int uiLock)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	unsigned uCDCR1 = pCIFReg->CDCR1;
	
	if(uiFlag & SET_CIF_TRANSFER_BURST)
	{
		//00: DMA transfers the image data as 1 word to memorty
		//01: DMA transfers the image data as 2 word to memorty
		//10: DMA transfers the image data as 3 word to memorty
		//11: DMA transfers the image data as 4 word to memorty
		BITCSET(uCDCR1, (Hw1 | Hw0), uiBurst);
	}	

	if(uiFlag & SET_CIF_TRANSFER_LOCK)
	{
		//Lock(1) or Non-lock(default: 0) transfer
		BITCSET(uCDCR1, Hw2, (uiLock << 2));
	}	

	if(uiFlag & SET_CIF_TRANSFER_MODE)
	{
		//INC Transfer(1) or Burst Transfer(default: 0)
		BITCSET(uCDCR1, Hw3, (uiTransMode << 3));
	}	
	pCIFReg->CDCR1 = uCDCR1;
}
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_sync_pol(void *pCIFRegAddr, unsigned int uiHPolarity, unsigned int uiVpolarity)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	//Horizontal Sync Polarity: Active low(1) or Acitve high(default : 0)
	//Vertical Sync Polarity: Active low(1) or Acitve high Y(default : 0)
	BITCSET(pCIFReg->ICPCR1, (Hw1|Hw0), ((uiHPolarity << 1)|uiVpolarity));
	
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_set_img(void *pCIFRegAddr, unsigned int uiType, unsigned int uiHsize, unsigned int uiVsize, unsigned int uiHorWindowingStart, unsigned int uiHorWindowingEnd, unsigned int uiVerWindowingStart, unsigned int uiVerWindowingEnd)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	if (uiType & IN_IMG)
	{
		//input image size
		BITCSET(pCIFReg->IIS, 0xFFFFFFFF, ((uiHsize << 16) | uiVsize));
		//input image windowing1
		BITCSET(pCIFReg->IIW1, 0xFFFFFFFF, ((uiHorWindowingStart<< 16) | uiHorWindowingEnd));
		//input image windowing2
		BITCSET(pCIFReg->IIW2, 0xFFFFFFFF, ((uiVerWindowingStart<< 16) | uiVerWindowingEnd));
		//input image offset
		BITSET(pCIFReg->CDCR5, ((uiHsize/2)<<16) | uiHsize);
	} 

	if(uiType & OVER_IMG)
	{
		//overaly image size
		BITCSET(pCIFReg->OIS, 0xFFFFFFFF, ((uiHsize << 16) | uiVsize));
		//overaly image windowing1
		BITCSET(pCIFReg->OIW1, 0xFFFFFFFF, ((uiHorWindowingStart<< 16) | uiHorWindowingEnd));
		//overaly image windowing2
		BITCSET(pCIFReg->OIW2, 0xFFFFFFFF, ((uiVerWindowingStart<< 16) | uiVerWindowingEnd));
	}
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	:
* Parameter 	:
* Return		:
* Note			: 
******************************************************************************/
void tca_cif_set_offset(void *pCIFRegAddr, unsigned int uiOffsetY, unsigned int uiOffsetUV)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	BITSET(pCIFReg->CDCR5, (uiOffsetUV<<16) | uiOffsetY);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_set_addr(void *pCIFRegAddr, unsigned int uiType, unsigned int uiBaseAddr0, unsigned int uiBaseAddr1, unsigned int uiBaseAddr2)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;

	if (uiType & IN_IMG)
	{
		//Y(G) channel base address
		BITCSET(pCIFReg->CDCR2, 0xFFFFFFFF, uiBaseAddr0);
		//U(R) channel base address
		BITCSET(pCIFReg->CDCR3, 0xFFFFFFFF, uiBaseAddr1);
		//V(B) channel base address
		BITCSET(pCIFReg->CDCR4, 0xFFFFFFFF, uiBaseAddr2);
	} 
	if(uiType & OVER_IMG)
	{
		//CIF Overlay base adderss - default is 0x20100000
		BITCSET(pCIFReg->COBA, 0xFFFFFFFF, uiBaseAddr0);
	}
	if(uiType & IN_IMG_ROLLING)
	{
		//Y(G) channel end address
		BITCSET(pCIFReg->CDCR6, 0xFFFFFFFF, uiBaseAddr0);
		//U(R) channel end address
		BITCSET(pCIFReg->CDCR7, 0xFFFFFFFF, uiBaseAddr1);
		//V(B) channel end address
		BITCSET(pCIFReg->CDCR8, 0xFFFFFFFF, uiBaseAddr2);
	}
	if(uiType & IN_IMG_ENC_START_ADDR)
	{
		//CIF Encoding start address - default 0x20100000
		BITCSET(pCIFReg->CESA, 0xFFFFFFFF, uiBaseAddr0);
	}
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_scale(void *pCIFRegAddr, unsigned int uiScaleEnable, unsigned int uiXScale, unsigned int uiYScale)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;

	//CIF Down Scaler
	//Horizontal Scale Factor[5:4] : 1/1 down scale(0), 1/2 down scale(1), 1/4 down scale(2), 1/8 down scale(3)
	//Vertical Scale Factor[3:2] : 1/1 down scale(0), 1/2 down scale(1), 1/4 down scale(2), 1/8 down scale(3)
	//Scale enable[0]
	BITCSET(pCIFReg->CDS, (Hw5|Hw4|Hw3|Hw2|Hw0), ((uiXScale << 4)|(uiYScale << 2)|uiScaleEnable));
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_setinterrupt(void *pCIFRegAddr, unsigned int uiFlag)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;	
	unsigned uCIRQ = pCIFReg->CIRQ;
	
	if(uiFlag & SET_CIF_INT_ENABLE)
	{
		// Camera Interrupt enable
		BITSET(uCIRQ, Hw31);		
	}	
	if(uiFlag & SET_CIF_INT_DISABLE)
	{
		// Camera Interrupt disable
		BITCLR(uCIRQ, Hw31);		
	}	
	if(uiFlag & SET_CIF_REGISTERUP_VSYNC)
	{
		//All CIF registers are applied to CIF operation at rising edge of CVS signal
		BITSET(uCIRQ, Hw30);
	}
	if(uiFlag & SET_CIF_REGISTERUP_ALWAYS)
	{
		//All CIF registers are applied to CIF operation regardless of VSYNC
		BITCLR(uCIRQ, Hw30);
	}
	if(uiFlag & SET_CIF_INTTYPE_HOLDUP)
	{
		// Hold-up Interrupt Type (Hold until respond signal (ICR) is high)
		BITSET(uCIRQ, Hw29);
	}
	if(uiFlag & SET_CIF_INTTYPE_PULSE)
	{
		BITCLR(uCIRQ, Hw29);
	}
	if(uiFlag & SET_CIF_INT_CLEAR)
	{
		// Interrupt Clear (When writing 1 to this bit, th e CIF interrupt is cleared)
		BITSET(uCIRQ, Hw28);
	}
	if(uiFlag & SET_CIF_VSNEGA_ENABLE)
	{
		//Enable : Mask Interrupt of VS negative edge(When VN[10] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw26);
	}
	if(uiFlag & SET_CIF_VSNEGA_DISABLE)
	{
		//Disable : Mask Interrupt of VS negative edge(When VN[10] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw26);
	}
	if(uiFlag & SET_CIF_VSPOSI_ENABLE)
	{
		//Enable : Mask Interrupt of VP positive edge(When VP[9] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw25);
	}
	if(uiFlag & SET_CIF_VSPOSI_DISABLE)
	{
		//Disable : Mask Interrupt of VP positive edge(When VP[9] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw25);
	}
	if(uiFlag & SET_CIF_VCNT_ENABLE)
	{
		//Enable : Mask Interrupt of VCNT interrupt(When VIT[8] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw24);
	}
	if(uiFlag & SET_CIF_VCNT_DISABLE)
	{
		//Disable : Mask Interrupt of VCNT interrupt(When VIT[8] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw24);
	}
	if(uiFlag & SET_CIF_SERROR_ENABLE)
	{
		//Enable : Mask Interrupt of Scaler Error(When SE[7] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw23);
	}
	if(uiFlag & SET_CIF_SERROR_DISABLE)
	{
		//Disable : Mask Interrupt of Scaler Error(When SE[7] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw23);
	}
	if(uiFlag & SET_CIF_SFINISH_ENABLE)
	{
		//Enable : Mask Interrupt of Scaler finish(When SF[6] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw22);
	}
	if(uiFlag & SET_CIF_SFINISH_DISABLE)
	{
		//Disable : Mask Interrupt of Scaler finish(When SF[6] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw22);
	}
	if(uiFlag & SET_CIF_ENCSTART_ENABLE)
	{
		//Enable : Mask Interrupt of Encoding start(When ENS[5] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw21);
	}
	if(uiFlag & SET_CIF_ENCSTART_DISABE)
	{
		//Disable : Mask Interrupt of Encoding start(When ENS[5] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw21);
	}
	if(uiFlag & SET_CIF_RVADDR_ENABLE)
	{
		//Enable : Mask Interrupt of Rolling V address(When RLV[4] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw20);
	}
	if(uiFlag & SET_CIF_RVADDR_DISABLE)
	{
		//Disable : Mask Interrupt of Rolling V address(When RLV[4] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw20);
	}
	if(uiFlag & SET_CIF_RUADDR_ENABLE)
	{
		//Enable : Mask Interrupt of Rolling U address(When RLU[3] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw19);
	}
	if(uiFlag & SET_CIF_RUADDR_DISABLE)
	{
		//Disable : Mask Interrupt of Rolling U address(When RLU[3] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw19);
	}
	if(uiFlag & SET_CIF_RYADDR_ENABLE)
	{
		//Enable : Mask Interrupt of Rolling Y address(When RLY[2] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw18);
	}
	if(uiFlag & SET_CIF_RYADDR_DISABLE)
	{
		//Disable : Mask Interrupt of Rolling Y address(When RLY[2] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw18);
	}
	if(uiFlag & SET_CIF_CAPFRAME_ENABLE)
	{
		//Enable : Mask Interrupt of Capture frame(When SCF[1] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw17);
	}
	if(uiFlag & SET_CIF_CAPFRAME_DISABLE)
	{
		//Disable : Mask Interrupt of Capture frame(When SCF[1] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw17);
	}
	if(uiFlag & SET_CIF_RESPONCEINT_ENABLE)
	{
		//Disable : Mask Interrupt of Stored one frame frame(When SOF[0] bit is set to 1, the CIF interrupt request is issued.)
		BITCLR(uCIRQ, Hw16);
	}	
	if(uiFlag & SET_CIF_RESPONCEINT_DISABLE)
	{
		//Enable : Mask Interrupt of Stored one frame frame(When SOF[0] bit is set to 1, the CIF interrupt request is issued.)
		BITSET(uCIRQ, Hw16);
	}
	pCIFReg->CIRQ = uCIRQ;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
unsigned int tca_cif_readintstatus(void *pCIFRegAddr, unsigned int uiFlag)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;	
	unsigned int uiReadOneFrameStatus = 0;
	unsigned uCIRQ = pCIFReg->CIRQ;
	
	if(uiFlag & READ_CIF_VSYNC_STATUS)
	{
		//VSS: Non-vertical sync blank area(0), Vertical sync blank area(1)
		uiReadOneFrameStatus |= (uCIRQ & Hw12);
	}
	if(uiFlag & READ_CIF_VSNEGA_STATUS)
	{
		//VS negative: It represents that CVS falling-edge is detected.(1)
		uiReadOneFrameStatus |= (uCIRQ & Hw10);
	}
	if(uiFlag & READ_CIF_VSPOSI_STATUS)
	{
		//VS positive: It represents that CVS rising-edge is detected.(1)
		uiReadOneFrameStatus |= (uCIRQ & Hw9);
	}
	if(uiFlag & READ_CIF_VCNT_STATUS)
	{
		//VCNT interrupt: CCM_2 register. When writing 1 to thsi bit, it is cleared
		uiReadOneFrameStatus |= (uCIRQ & Hw8);
	}
	if(uiFlag & READ_CIF_SERROR_STATUS)
	{
		//Scaler error: CIF scaler has an error during scaling operation. When writing 1 to thsi bit, it is cleared		
		uiReadOneFrameStatus |= (uCIRQ & Hw7);
	}
	if(uiFlag & READ_CIF_SFINISH_STATUS)
	{
		//Scaler Finish: CIF scaler operation is completed. When writing 1 to thsi bit, it is cleared				
		uiReadOneFrameStatus |= (uCIRQ & Hw6);
	}
	if(uiFlag & READ_CIF_ENCSTART_STATUS)
	{
		//Encoding start status : CESA register. When writing 1 to thsi bit, it is cleared						
		uiReadOneFrameStatus |= (uCIRQ & Hw5);
	}
	if(uiFlag & READ_CIF_RVADDR_STATUS)
	{
		//Rolling V address status : Current DMA V address reaches the DMA V rolling end address. 
		//When writing 1 to thsi bit, it is cleared
		uiReadOneFrameStatus |= (uCIRQ & Hw4);
	}
	if(uiFlag & READ_CIF_RUADDR_STATUS)
	{
		//Rolling U address status : Current DMA U address reaches the DMA U rolling end address. 
		//When writing 1 to thsi bit, it is cleared
		uiReadOneFrameStatus |= (uCIRQ & Hw3);
	}
	if(uiFlag & READ_CIF_RYADDR_STATUS)
	{
		//Rolling Y address status : Current DMA Y address reaches the DMA Y rolling end address. 
		//When writing 1 to thsi bit, it is cleared
		uiReadOneFrameStatus |= (uCIRQ & Hw2);
	}
	if(uiFlag & READ_CIF_CAPFRAME_STATUS)
	{
		//Stored One frame for CAPTURE: It is only available when CAP bit of CCM_1 register is set to 1.
		//CIF has recived one frame data from the camera module and stored them to the specified memory completely
		uiReadOneFrameStatus |= (uCIRQ & Hw1);
	}
	if(uiFlag & READ_CIF_ONEFRAME_STATUS)
	{
		//Stored One frame: 
		//CIF has recived one frame data from the camera module and stored them to the specified memory completely.
		//It does not consider CAP bit
		uiReadOneFrameStatus |= (uCIRQ & Hw0);
	}
	return uiReadOneFrameStatus;
}	

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_set656formatconfig(void *pCIFRegAddr, unsigned int uiType, unsigned int uiPsl, unsigned int uiFpv, unsigned int uiSpv, unsigned int uiTpv, unsigned int uiHb, unsigned int uiVb)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;	
	unsigned u656FCR1 = pCIFReg->CCIR656FCR1;
	unsigned u656FCR2 = pCIFReg->CCIR656FCR2;
	
	if(uiType & SET_CIF_656_PSL)
	{
		//Preamble ans status location
		// 00 : The status word is located in the first byte of EAV & SAV
		// 01 : The status word is located in the second byte of EAV & SAV
		// 10 : The status word is located in the third byte of EAV & SAV
		// 11 : The status word is located in the forth byte of EAV & SAV
		BITCSET(u656FCR1, (Hw26|Hw25), (uiPsl << 25));
	}
	if(uiType & SET_CIF_656_FPV)
	{
		//First preamble value
		BITCSET(u656FCR1, (Hw24-Hw16), (uiFpv << 16));
	}
	if(uiType & SET_CIF_656_SPV)
	{
		//Second preamble value
		BITCSET(u656FCR1, (Hw16-Hw8), (uiSpv << 8));
	}
	if(uiType & SET_CIF_656_TPV)
	{
		//Third preamble value
		BITCSET(u656FCR1, (Hw9-Hw0), uiFpv);
	}
	if(uiType & SET_CIF_656_H_BLANK)
	{
		//Horizontal blank
		BITCSET(u656FCR2, (Hw9-Hw5), (uiHb << 5));
	}
	if(uiType & SET_CIF_656_V_BLANK)
	{
		//Vertical blank
		BITCSET(u656FCR2, (Hw4-Hw0), uiVb);
	}

	pCIFReg->CCIR656FCR1 = u656FCR1;
	pCIFReg->CCIR656FCR2 = u656FCR2;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
unsigned int tca_cif_readfifostate(void *pCIFRegAddr, unsigned int uiType)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;		
	unsigned int uiRet = 0;
	unsigned uFIFOSTATE = pCIFReg->FIFOSTATE;

	if(uiType & SET_CIF_FIFO_STATE_CLR)
	{
		//Clear FIFO stats : When writing 1 to this bit, all status bits are cleared.
		BITSET(pCIFReg->FIFOSTATE, Hw21);
		BITCLR(pCIFReg->FIFOSTATE, Hw21);
	}
	if(uiType & READ_CIF_OVERLAY_READ_ERR)
	{
		//Overaly FIFO Read Error
		uiRet |= (uFIFOSTATE & Hw19);
	}
	if(uiType & READ_CIF_VCH_READ_ERR)
	{
		//V(B) channel FIFO Read Error
		uiRet |= (uFIFOSTATE & Hw18);
	}
	if(uiType & READ_CIF_UCH_READ_ERR)
	{
		//U(R) channel FIFO Read Error
		uiRet |= (uFIFOSTATE & Hw17);
	}
	if(uiType & READ_CIF_YCH_READ_ERR)
	{
		//Y(G) channel FIFO Read Error
		uiRet |= (uFIFOSTATE & Hw16);
	}
	if(uiType & READ_CIF_OVERLAY_WRITE_ERR)
	{
		//Overlay FIFO Write Error
		uiRet |= (uFIFOSTATE & Hw13);
	}
	if(uiType & READ_CIF_VCH_WRITE_ERR)
	{
		//V(B) channel FIFO Write Error
		uiRet |= (uFIFOSTATE & Hw12);
	}
	if(uiType & READ_CIF_UCH_WRITE_ERR)
	{
		//U(R) channel FIFO Write Error
		uiRet |= (uFIFOSTATE & Hw11);
	}
	if(uiType & READ_CIF_YCH_WRITE_ERR)
	{
		//Y(G) channel FIFO Write Error
		uiRet |= (uFIFOSTATE & Hw10);
	}
	if(uiType & READ_CIF_OVERLAY_EMPTY_ERR)
	{
		//Overlay FIFO Empty Signal
		uiRet |= (uFIFOSTATE & Hw8);
	}
	if(uiType & READ_CIF_VCH_EMPTY_ERR)
	{
		//V(B) FIFO Empty Signal
		uiRet |= (uFIFOSTATE & Hw7);
	}
	if(uiType & READ_CIF_UCH_EMPTY_ERR)
	{
		//U(R) FIFO Empty Signal
		uiRet |= (uFIFOSTATE & Hw6);
	}
	if(uiType & READ_CIF_YCH_EMPTY_ERR)
	{
		//Y(G) FIFO Empty Signal
		uiRet |= (uFIFOSTATE & Hw5);
	}
	if(uiType & READ_CIF_OVERLAY_FULL_ERR)
	{
		//Overlay FIFO Full Signal
		uiRet |= (uFIFOSTATE & Hw3);
	}
	if(uiType & READ_CIF_VCH_FULL_ERR)
	{
		//V(B) FIFO Full Signal
		uiRet |= (uFIFOSTATE & Hw2);
	}
	if(uiType & READ_CIF_UCH_FULL_ERR)
	{
		//U(R) FIFO Full Signal
		uiRet |= (uFIFOSTATE & Hw1);
	}
	if(uiType & READ_CIF_YCH_FULL_ERR)
	{
		//Y(G) FIFO Full Signal
		uiRet |= (uFIFOSTATE & Hw0);
	}
	return uiRet;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_setencrolskipnum(void *pCIFRegAddr, unsigned int uiType, unsigned int uiEncNum, unsigned int uiRolNumV, unsigned int uiRolNumU, unsigned int uiRolNumY, unsigned int uiSkipNum, unsigned int uiVCnt)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	//CIF Capture mode
	unsigned uCCM1 = pCIFReg->CCM1;
	unsigned uCCM2 = pCIFReg->CCM2;
	
	if(uiType & SET_CIF_ENC_NUM)
	{
		//Encode INT number (using CAP mode)
		BITCSET(uCCM1, (Hw32-Hw28), (uiEncNum << 28));
	}
	if(uiType & SET_CIF_ROLV_NUM)
	{
		//Rolling Number in V (using CAP mode)
		//The number of times which V address is rolled while capture mode and
		//rolling mode are enabled and one frame data is stored to the memory 
		BITCSET(uCCM1, (Hw28-Hw24), (uiRolNumV<< 24));
	}
	if(uiType & SET_CIF_ROLU_NUM)
	{
		//Rolling Number in U (using CAP mode)
		//The number of times which U address is rolled while capture mode and
		//rolling mode are enabled and one frame data is stored to the memory 
		BITCSET(uCCM1, (Hw24-Hw20), (uiRolNumU << 20));
	}
	if(uiType & SET_CIF_ROLY_NUM)
	{
		//Rolling Number in Y (using CAP mode)
		//The number of times which Y address is rolled while capture mode and
		//rolling mode are enabled and one frame data is stored to the memory 
		BITCSET(uCCM1, (Hw20-Hw16), (uiRolNumY << 16));
	}
	if(uiType & SET_CIF_SKIP_NUM)
	{
		//Skip frame number (using CAP mode)
		BITCSET(uCCM1, (Hw8-Hw4), (uiSkipNum << 4));
	}
	if(uiType & SET_CIF_VCNT_NUM)
	{
		//VCNT (Using CAP mode)
		//Ex) VCNT = 3, the VIT bit is set to 1 whenever a number of line 
		//to be stored is equal to a multiple of 48(=16*VCNT) line, which is 48, 96, 144, etc.
		BITCSET(uCCM2, (Hw8-Hw4), (uiVCnt << 4));
	}
	
	pCIFReg->CCM1 = uCCM1;
	pCIFReg->CCM2 = uCCM2;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
unsigned int tca_cif_setcapturectrl(void *pCIFRegAddr, unsigned int uiType)
{
	CIF *pCIFReg = (CIF *)pCIFRegAddr;
	unsigned int uiRet = 0;
	//CIF Capture mode
	unsigned uCCM1 = pCIFReg->CCM1;
	unsigned uCCM2 = pCIFReg->CCM2;

	if(uiType & READ_CIF_CAPTURE_BUSY)
	{
		//Capture busy - frame data is storing to the memory during thre capture mode
		uiRet |= (uCCM1 & Hw10);
	}
	if(uiType & SET_CIF_EIT_ENC_INT)
	{
		//Enable Encoding INT count
		BITSET(uCCM1, Hw9);
	}
	if(uiType & SET_CIF_EIT_ALWAYS_1_PULSE)
	{
		//Disable Encoding INT count
		BITCLR(uCCM1, Hw9);
	}
	if(uiType & SET_CIF_UES_ENABLE)
	{
		//The use of CESA(CIF Encoding Start Address) reg is enabled.
		BITSET(uCCM1, Hw8);
	}
	if(uiType & SET_CIF_UES_DISABLE)
	{
		//The use of CESA(CIF Encoding Start Address) reg is disabled.
		BITCLR(uCCM1, Hw8);
	}
	if(uiType & SET_CIF_RLV_ENABLE)
	{
		//Enable Rolling mode for V image
		BITSET(uCCM1, Hw3);
	}
	if(uiType & SET_CIF_RLV_DISABLE)
	{
		//Disable Rolling mode for V image
		BITCLR(uCCM1, Hw3);
	}
	if(uiType & SET_CIF_RLU_ENABLE)
	{
		//Enable Rolling mode for U image
		BITSET(uCCM1, Hw2);
	}
	if(uiType & SET_CIF_RLU_DISABLE)
	{
		//Disable Rolling mode for U image
		BITCLR(uCCM1, Hw2);
	}
	if(uiType & SET_CIF_RLY_ENABLE)
	{
		//Enable Rolling mode for Y image
		BITSET(uCCM1, Hw1);
	}
	if(uiType & SET_CIF_RLY_DISABLE)
	{
		//Disable Rolling mode for Y image
		BITCLR(uCCM1, Hw1);
	}
	if(uiType & SET_CIF_CAP_ENABLE)
	{
		// 1 : Previes mode
		BITSET(uCCM1, Hw0);
	}
	if(uiType & SET_CIF_CAP_DISABLE)
	{
		// 0 : Capture mode
		BITCLR(uCCM1, Hw0);
	}
	if(uiType & SET_CIF_VEN_ENABLE)
	{
		//VCNT enable (using CAP mode)
		BITSET(uCCM2, Hw0);
	}
	if(uiType & SET_CIF_VEN_DISABLE)
	{
		//VCNT disable (using CAP mode)
		BITCLR(uCCM2, Hw0);
	}

	pCIFReg->CCM1 = uCCM1;
	pCIFReg->CCM2 = uCCM2;
	return uiRet;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_seteffectinimgsize(void *pEFFECTRegAddr, unsigned int uiHSize, unsigned int uiVSize)
{
	EFFECT *pEFFECTReg = (EFFECT *)pEFFECTRegAddr;	 
	//CIF Effect Image Size : HSIZE[26:16], VSIZE[10:0]
	BITCSET(pEFFECTReg->CEIS, ((Hw27-Hw16) | (Hw11-Hw0)), ((uiHSize << 16) | uiVSize));
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_seteffectmode(void *pEFFECTRegAddr, unsigned int uiFlag)
{
	EFFECT *pEFFECTReg = (EFFECT *)pEFFECTRegAddr;
	unsigned uCEM = pEFFECTReg->CEM;
	
	if(uiFlag & SET_CIF_EFFECT_VUVU_SEQ)
	{
		// 0 : U-V-U-V sequence, 1 : V-U-V-U sequence
		BITSET(uCEM, Hw15);
	}
	if(uiFlag & SET_CIF_EFFECT_UVUV_SEQ)
	{
		// 0 : U-V-U-V sequence, 1 : V-U-V-U sequence
		BITCLR(uCEM, Hw15);
	}
	if(uiFlag & SET_CIF_EFFECT_VB_ENABLE)
	{
		//Enable V Bias(V channel value offset)
		BITSET(uCEM, Hw14);
	}
	if(uiFlag & SET_CIF_EFFECT_VB_DISABLE)
	{
		//Disable V Bias(V channel value offset)
		BITCLR(uCEM, Hw14);
	}
	if(uiFlag & SET_CIF_EFFECT_UB_ENABLE)
	{
		//Enable U Bias(U channel value offset)
		BITSET(uCEM, Hw13);
	}
	if(uiFlag & SET_CIF_EFFECT_UB_DISABLE)
	{
		//Disable U Bias(U channel value offset)
		BITCLR(uCEM, Hw13);
	}
	if(uiFlag & SET_CIF_EFFECT_YB_ENALBE)
	{
		//Enable Y Bias(Y channel value offset)
		BITSET(uCEM, Hw12);
	}
	if(uiFlag & SET_CIF_EFFECT_YB_DISABLE)
	{
		//Disable Y Bias(Y channel value offset)
		BITCLR(uCEM, Hw12);
	}
	if(uiFlag & SET_CIF_EFFECT_YUYV_SEQ)
	{
		//YC Swap : Y-U(or V)-Y-V(or U) sequence
		BITSET(uCEM, Hw11);
	}
	if(uiFlag & SET_CIF_EFFECT_UYVY_SEQ)
	{
		//YC Swap : U(or V)-Y-V(or U)-Y sequence
		BITCLR(uCEM, Hw11);
	}
	if(uiFlag & SET_CIF_EFFECT_YINVERT_ENALBE)
	{
		//Enable Inver Y
		BITSET(uCEM, Hw10);
	}
	if(uiFlag & SET_CIF_EFFECT_YINVERT_DISABLE)
	{
		//Disable Inver Y
		BITCLR(uCEM, Hw10);
	}
	if(uiFlag & SET_CIF_EFFECT_STRONGC_ENABLE)
	{
		//Enable Strong C
		BITSET(uCEM, Hw9);
	}
	if(uiFlag & SET_CIF_EFFECT_STRONGC_DISABLE)
	{
		//Disable Strong C
		BITCLR(uCEM, Hw9);
	}
	if(uiFlag & SET_CIF_EFFECT_YCLAMP_ENALBE)
	{
		//Enable Y Clame(Y value clipping)
		BITSET(uCEM, Hw8);
	}
	if(uiFlag & SET_CIF_EFFECT_YCLAMP_DISALBE)
	{
		//Disable Y Clame(Y value clipping)
		BITCLR(uCEM, Hw8);
	}
	if(uiFlag & SET_CIF_EFFECT_CSELECT_ENABLE)
	{
		//Enable C Select (Color filter)
		BITSET(uCEM, Hw7);
	}
	if(uiFlag & SET_CIF_EFFECT_CSELECT_DISABLE)
	{
		//Disable C Select (Color filter)
		BITCLR(uCEM, Hw7);
	}
	if(uiFlag & SET_CIF_EFFECT_SKETCH_ENABLE)
	{
		//Enable sketch
		BITSET(uCEM, Hw6);
	}
	if(uiFlag & SET_CIF_EFFECT_SKETCH_DISABLE)
	{
		//Disable sketch
		BITCLR(uCEM, Hw6);
	}
	if(uiFlag & SET_CIF_EFFECT_NEGATIVE_EMBOSS)
	{
		//Enable positive emboss mode
		BITSET(uCEM, Hw5);
	}
	if(uiFlag & SET_CIF_EFFECT_POSITIVE_EMBOSS)
	{
		//Disable negative emboss mode
		BITCLR(uCEM, Hw5);
	}
	if(uiFlag & SET_CIF_EFFECT_EMBOSS_ENABLE)
	{
		//Enable emboss
		BITSET(uCEM, Hw4);
	}
	if(uiFlag & SET_CIF_EFFECT_EMBOSS_DISABLE)
	{
		//Disable emboss		
		BITCLR(uCEM, Hw4);
	}
	if(uiFlag & SET_CIF_EFFECT_NEGATIVE_ENABLE)
	{
		//Enable negative mode
		BITSET(uCEM, Hw3);
	}
	if(uiFlag & SET_CIF_EFFECT_NEGATIVE_DISABLE)
	{
		//Enable positive mode
		BITCLR(uCEM, Hw3);
	}
	if(uiFlag & SET_CIF_EFFECT_GRAY_ENABLE)
	{
		//Enable gray mode
		BITSET(uCEM, Hw2);
	}
	if(uiFlag & SET_CIF_EFFECT_GRAY_DISABLE)
	{
		//Disable gray mode
		BITCLR(uCEM, Hw2);
	}
	if(uiFlag & SET_CIF_EFFECT_SEPIA_ENABLE)
	{
		//Enable sepia mode
		BITSET(uCEM, Hw1);
	}
	if(uiFlag & SET_CIF_EFFECT_SEPIA_DISABLE)
	{
		//Disable sepia mode		
		BITCLR(uCEM, Hw1);
	}
	if(uiFlag & SET_CIF_EFFECT_NORMAL_MODE)
	{
		//Normal mode(Effecter is disabled)
		BITSET(uCEM, Hw0);
	}
	if(uiFlag & SET_CIF_EFFECT_EFFECT_MODE)
	{
		//Effect mode(Effecter is enabled)
		BITCLR(uCEM, Hw0);
	}

	/* Invalid effect setting -> set to normal mode */
	if(uCEM == 0)
	{
		// 0: Effect mode(Effecter is enabled), 1: Normal mode(Effecter is disabled)
		BITSET(uCEM, Hw0);
	}

	pEFFECTReg->CEM = uCEM;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_seteffectsepiauv(void *pEFFECTRegAddr, unsigned int uiSepiaU, unsigned int uiSepiaV)
{
	EFFECT *pEFFECTReg = (EFFECT *)pEFFECTRegAddr;
	//CIF sepia UV SEPIA_U[15:8], SEPIA_V[7:0]
	BITCSET(pEFFECTReg->CSUV, (Hw16-Hw0), ((uiSepiaU << 8)|uiSepiaV));
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_seteffectsketchclampth(void *pEFFECTRegAddr, unsigned int uiType, unsigned int uiSketch, unsigned int uiClamp)
{
	EFFECT *pEFFECTReg = (EFFECT *)pEFFECTRegAddr;
	if(uiType & SET_CIF_EFFECT_SKETCH_THRE)
	{
		//CIF Sketch Threshold
		BITCSET(pEFFECTReg->CST, 0x000000FF, uiSketch);
	}
	if(uiType & SET_CIF_EFFECT_CLAMP_THRE)
	{
		//CIF Clamp Threshold
		BITCSET(pEFFECTReg->CCT, 0x000000FF, uiClamp);
	}
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_setscalerctrl(void *pCIFSCALERRegAddr, unsigned int uiType)
{
	CIFSCALER *pCIFSCALER = (CIFSCALER *)pCIFSCALERRegAddr;	

	if(uiType & SET_CIF_SCALER_ENABLE)
	{
		//Enable scaler
		BITSET(pCIFSCALER->CSC, Hw0);
	}
	if(uiType & SET_CIF_SCALER_DISABLE)
	{
		//Disable scaler
		BITCLR(pCIFSCALER->CSC, Hw0);
	}
}



/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tca_cif_setscalerimgsizeoffsetscale(void *pCIFSCALERRegAddr, unsigned int uiType, unsigned int uiSrcHSize, unsigned int uiSrcVSize, unsigned int uiOffH, unsigned int uiOffV, unsigned int uiDstHSize, unsigned int uiDstVSize, unsigned int uiHScale, unsigned int uiVScale)
{
	CIFSCALER *pCIFSCALER = (CIFSCALER *)pCIFSCALERRegAddr;	

	if(uiType & SET_CIF_SCALER_SRC_SIZE)
	{
		//CIF Scaler Source Size - SRC_HSIZE[27:16], SRC_VSIZE[11:0] Horizontal(or vertical) size in source iamge
		BITCSET(pCIFSCALER->CSSS, 0xFFFFFFFF, ((uiSrcHSize << 16)|uiSrcVSize));
	}
	if(uiType & SET_CIF_SCALER_SRC_OFFSET)
	{
		//CIF Scaler Source Offset - H_OFFSET[27:16], V_OFFSET[11:0] Horizontal(or vertical) offset
		BITCSET(pCIFSCALER->CSSO, 0xFFFFFFFF, ((uiOffH << 16)|uiOffV));
	}
	if(uiType & SET_CIF_SCALER_DST_SIZE)
	{
		//CIF Scaler DST_Size - DST_HSIZE[27:16], DST_VSIZE[11:0] Horizontal(or vertical) size in destination iamge
		BITCSET(pCIFSCALER->CSDS, 0xFFFFFFFF, ((uiDstHSize << 16)|uiDstVSize));
	}
	if(uiType & SET_CIF_SCALER_FACTOR)
	{
		//CIF Scaler Factor - HSCALE[29:16], VSCALE[13:0]
		//HSCALE = SRC_HSIZE*256/DST_HSIZE;
		//VSCALE = SRC_VSIZE*256/DST_VSIZE;
		BITCSET(pCIFSCALER->CSSF, 0xFFFFFFFF, ((uiHScale<< 16)|uiVScale));
	}
}

void tca_cif_powerupdown(void *pCKCRegAddr, int iCIFPowerOn)
{
	CKC *pCKCReg = (CKC *)pCKCRegAddr;
	
	if(iCIFPowerOn)
	{
		//Enable CAM Clock divider enable register 
		BITSET(pCKCReg->PCLK_CIFMC, Hw28);
		//Enable Scaler Clock divider enable register 
		BITSET(pCKCReg->PCLK_CIFSC, Hw28);
	}
	else
	{
		//Disable CAM Clock divider enable register 
		BITCLR(pCKCReg->PCLK_CIFMC, Hw28);
		//Disable Scaler Clock divider enable register 
		BITCLR(pCKCReg->PCLK_CIFSC, Hw28);
	}
}

/* end of file */

