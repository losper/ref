
/****************************************************************************
 *   FileName    : tca_cifdriver.h
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#ifndef __TCA_CIF_H__
#define __TCA_CIF_H__

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
*
* Defines
*
******************************************************************************/
#define	CAM_INPUTIMAGE_HSIZE	800
#define	CAM_INPUTIMAGE_VSIZE	600
#define	CAM_LCD_PREV_HSIZE		320
#define	CAM_LCD_PREV_VSIZE		240
#define	CAM_HSIZE			CAM_LCD_PREV_HSIZE
#define	CAM_VSIZE			CAM_LCD_PREV_VSIZE
#define	CAM_HSIZE_TV		640
#define	CAM_VSIZE_TV		480

#define	CAM_SUCCESS			0
#define	CAM_NO_RESPONSE		-1


/*****************************************************************************
*
* Enum
*
******************************************************************************/

/*****************************************************************************
*
* Type Defines
*
******************************************************************************/
// CIF Controller : Device Code = 0x08
#define CIF_ERRORCODE						0xFF080000
#define CIF_SUCCESS 						0x0
#define CIF_NORESPONSE						(CIF_ERRORCODE | 0x0001)

/*****************************************************************************
*
* Structures
*
******************************************************************************/
typedef struct _CIF_CONTROL_INFO
{
	unsigned int uiFlag;
	unsigned int uiBypass;
	unsigned int uiBypassBusSel;
	unsigned int uiColorPattern;
	unsigned int uiPatternFormat;
	unsigned int uiRGBMode;
	unsigned int uiRGBBitMode;
	unsigned int uiColorSequence;
	unsigned int uiBusOrder;
	unsigned int uiOverlayCNT;
}CIF_CONTROL_INFO;

typedef struct _CIF_TRANSFER_CONFIG
{
	unsigned int uiFlag;
	unsigned int uiTransMode;
	unsigned int uiBurst;
	unsigned int uiLock;
}CIF_TRANSFER_CONFIG;

typedef struct _CIF_OVERLAY_CONFIG
{
	unsigned int uiFlag;
	unsigned int uiOverlayCNT;
	unsigned int uiOverlayMethod;
	unsigned int uiXOR1;
	unsigned int uiXOR0;
	unsigned int uiAlpha1;
	unsigned int uiAlpha0;
}CIF_OVERLAY_CONFIG;

typedef struct _CIF_OVERLAY_KEY
{
	unsigned int uiFlag;
	unsigned int uiKEYR;
	unsigned int uiKEYG;
	unsigned int uiKEYB;
	unsigned int uiMKEYR;
	unsigned int uiMKEYG;
	unsigned int uiMKEYB;
}CIF_OVERLAY_KEY;

typedef struct _CIF_SYNC_POLARITY
{
	unsigned int uiHPolarity;
	unsigned int uiVpolarity;
}CIF_SYNC_POLARITY;

typedef struct _CIF_IMAGE_CONFIG
{
	unsigned int uiType;
	unsigned int uiHsize;
	unsigned int uiVsize;
	unsigned int uiHorWindowingStart;
	unsigned int uiHorWindowingEnd;
	unsigned int uiVerWindowingStart;
	unsigned int uiVerWindowingEnd;
}CIF_IMAGE_CONFIG;

typedef struct _CIF_SCALE_CONFIG
{
	unsigned int uiScaleEnable;
	unsigned int uiXScale;
	unsigned int uiYScale;
}CIF_SCALE_CONFIG;

typedef struct _CIF_BASE_ADDRESS
{
	unsigned int uiType;
	unsigned int uiBaseAddr0;
	unsigned int uiBaseAddr1;
	unsigned int uiBaseAddr2;
}CIF_BASE_ADDRESS;	

typedef struct _CIF_OVERLAY_CONTROL
{
	unsigned int uiFlag;
	unsigned int uiAlphaEnable;
	unsigned int uiChromakeyEnable;
	unsigned int uiOverlayEnable;
}CIF_OVERLAY_CONTROL;		

typedef struct _CIF_INTANDOPERATING_CONTROL
{
	unsigned int uiFlag;
	unsigned int uiReadOneFrameStatus;
}CIF_INTANDOPERATING_CONTROL;	

typedef struct _CAM_OVERLAY_INFO
{
	void			*pBase_overlay;
	unsigned long	overlayfilenum;
	unsigned int	nOverlayPage;
	unsigned int	uiOverlayOn;
}CAM_OVERLAY_INFO;
/*****************************************************************************
*
* External Variables
*
******************************************************************************/

/*****************************************************************************
*
* External Functions
*
******************************************************************************/
void tca_cif_portopen(void *pCIFRegAddr, void *pGPIORegAddr, void *pCKCRegAddr, void *pDDICONFIGRegAddr);
void tca_cif_portclose(void *pGPIORegAddr, void *pCKCRegAddr, void *pDDICONFIGRegAddr);
void tca_cif_onoff_new(void *pCIFRegAddr, void *pCKCRegAddr, void *pGPIORegAddr, void *pDDICONFIGRegAddr, unsigned int uiControl);
int tca_cif_opstart(void *pCIFRegAddr, void *pGPIORegAddr, unsigned int mode, unsigned int cam_mod);
void tca_cif_opstop(void *pCIFRegAddr, void *pGPIORegAddr);
void tca_cif_opresume(void *pCIFRegAddr, void *pGPIORegAddr, unsigned int cam_mod);
void tca_cif_getcapturedframe(void *pCIFRegAddr, void *pGPIORegAddr);
void tca_cif_set_info(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiBypass, unsigned int uiBypassBusSel, unsigned int uiColorPattern, unsigned int uiPatternFormat, unsigned int uiRGBMode, unsigned int uiRGBBitMode, unsigned int uiColorSequence, unsigned int uiBusOrder);
void tca_cif_set_ctrl(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiSkipFrame, unsigned int uiM420);
void tca_cif_set_transfer(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiTransMode, unsigned int uiBurst, unsigned int uiLock);
void tca_cif_sync_pol(void *pCIFRegAddr, unsigned int uiHPolarity, unsigned int uiVpolarity);
void tca_cif_set_img(void *pCIFRegAddr, unsigned int uiType, unsigned int uiHsize, unsigned int uiVsize, unsigned int uiHorWindowingStart, unsigned int uiHorWindowingEnd, unsigned int uiVerWindowingStart, unsigned int uiVerWindowingEnd);
void tca_cif_set_addr(void *pCIFRegAddr, unsigned int uiType, unsigned int uiBaseAddr0, unsigned int uiBaseAddr1, unsigned int uiBaseAddr2);
void tca_cif_scale(void *pCIFRegAddr, unsigned int uiScaleEnable, unsigned int uiXScale, unsigned int uiYScale);
void tca_cif_setinterrupt(void *pCIFRegAddr, unsigned int uiFlag);
unsigned int tca_cif_readintstatus(void *pCIFRegAddr, unsigned int uiFlag);
void tca_cif_set656formatconfig(void *pCIFRegAddr, unsigned int uiType, unsigned int uiPsl, unsigned int uiFpv, unsigned int uiSpv, unsigned int uiTpv, unsigned int uiHb, unsigned int uiVb);
unsigned int tca_cif_readfifostate(void *pCIFRegAddr, unsigned int uiType);
void tca_cif_setencrolskipnum(void *pCIFRegAddr, unsigned int uiType, unsigned int uiEncNum, unsigned int uiRolNumV, unsigned int uiRolNumU, unsigned int uiRolNumY, unsigned int uiSkipNum, unsigned int uiVCnt);
unsigned int tca_cif_setcapturectrl(void *pCIFRegAddr, unsigned int uiType);
void tca_cif_seteffectinimgsize(void *pEFFECTRegAddr, unsigned int uiHSize, unsigned int uiVSize);
void tca_cif_seteffectmode(void *pEFFECTRegAddr, unsigned int uiFlag);
void tca_cif_seteffectsepiauv(void *pEFFECTRegAddr, unsigned int uiSepiaU, unsigned int uiSepiaV);
void tca_cif_seteffectsketchclampth(void *pEFFECTRegAddr, unsigned int uiType, unsigned int uiSketch, unsigned int uiClamp);
void tca_cif_setscalerctrl(void *pCIFSCALERRegAddr, unsigned int uiType);
void tca_cif_setscalerimgsizeoffsetscale(void *pCIFSCALERRegAddr, unsigned int uiType, unsigned int uiSrcHSize, unsigned int uiSrcVSize, unsigned int uiOffH, unsigned int uiOffV, unsigned int uiDstHSize, unsigned int uiDstVSize, unsigned int uiHScale, unsigned int uiVScale);
void tca_cif_powerupdown(void *pCKCRegAddr, int iCIFPowerOn);
void tca_cif_set_offset(void *pCIFRegAddr, unsigned int uiOffsetY, unsigned int uiOffsetUV);
#ifdef __cplusplus
 } 
#endif

#endif	// __TCA_CIF_H__
/* end of file */

