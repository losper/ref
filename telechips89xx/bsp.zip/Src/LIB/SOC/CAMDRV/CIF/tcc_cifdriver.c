
/****************************************************************************
 *   FileName    : tca_cifdriver.c
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
/ ****************************************************************************/

/****************************************************************************
*
* Header Files Include
*
******************************************************************************/
#include "bsp.h"
#include "tca_cifdriver.h"
#include "CIFRegisterSet.h"


/*****************************************************************************
*
* Defines
*
******************************************************************************/

/*****************************************************************************
*
* Enum
*
******************************************************************************/

/*****************************************************************************
*
* Type Defines
*
******************************************************************************/

/*****************************************************************************
*
* Structures
*
******************************************************************************/

/*****************************************************************************
*
* External Variables
*
******************************************************************************/

/*****************************************************************************
*
* Local Functions
*
******************************************************************************/


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_portopen(void *pCIFRegAddr, void *pGPIORegAddr, void *pCKCRegAddr, void *pDDICONFIGRegAddr)
{
	tca_cif_portopen(pCIFRegAddr, pGPIORegAddr, pCKCRegAddr, pDDICONFIGRegAddr);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_portclose(void *pGPIORegAddr, void *pCKCRegAddr, void *pDDICONFIGRegAddr)
{
	tca_cif_portclose(pGPIORegAddr, pCKCRegAddr, pDDICONFIGRegAddr);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_onoff_new(void *pCIFRegAddr, void *pCKCRegAddr, void *pGPIORegAddr, void *pDDICONFIGRegAddr, unsigned int uiControl)
{
	tca_cif_onoff_new(pCIFRegAddr, pCKCRegAddr, pGPIORegAddr, pDDICONFIGRegAddr, uiControl);
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
int	tcc_cif_opstart(void *pCIFRegAddr, void *pGPIORegAddr, unsigned int mode, unsigned int cam_mod)
{
	return tca_cif_opstart(pCIFRegAddr, pGPIORegAddr , mode, cam_mod);
}


/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_opstop(void *pCIFRegAddr, void *pGPIORegAddr)
{
	tca_cif_opstop(pCIFRegAddr, pGPIORegAddr);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_opresume(void *pCIFRegAddr, void *pGPIORegAddr, unsigned int cam_mod)
{
	tca_cif_opresume(pCIFRegAddr, pGPIORegAddr, cam_mod);
}

void tcc_cif_getcapturedframe(void *pCIFRegAddr, void *pGPIORegAddr)
{
	tca_cif_getcapturedframe(pCIFRegAddr, pGPIORegAddr);
}
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_set_info(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiBypass, unsigned int uiBypassBusSel, unsigned int uiColorPattern, unsigned int uiPatternFormat, unsigned int uiRGBMode, unsigned int uiRGBBitMode, unsigned int uiColorSequence, unsigned int uiBusOrder)
{
	tca_cif_set_info(pCIFRegAddr, uiFlag, uiBypass, uiBypassBusSel, uiColorPattern, uiPatternFormat, uiRGBMode, uiRGBBitMode, uiColorSequence, uiBusOrder);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_set_ctrl(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiSkipFrame, unsigned int uiM420)
{
	tca_cif_set_ctrl(pCIFRegAddr, uiFlag, uiSkipFrame, uiM420);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_set_transfer(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiTransMode, unsigned int uiBurst, unsigned int uiLock)
{
	tca_cif_set_transfer(pCIFRegAddr, uiFlag, uiTransMode, uiBurst, uiLock);
}
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_sync_pol(void *pCIFRegAddr, unsigned int uiHPolarity, unsigned int uiVpolarity)
{
	tca_cif_sync_pol(pCIFRegAddr, uiHPolarity, uiVpolarity);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_set_img(void *pCIFRegAddr, unsigned int uiType, unsigned int uiHsize, unsigned int uiVsize, unsigned int uiHorWindowingStart, unsigned int uiHorWindowingEnd, unsigned int uiVerWindowingStart, unsigned int uiVerWindowingEnd)
{
	tca_cif_set_img(pCIFRegAddr, uiType, uiHsize, uiVsize, uiHorWindowingStart, uiHorWindowingEnd, uiVerWindowingStart, uiVerWindowingEnd);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	:
* Parameter 	:
* Return		:
* Note			: 
******************************************************************************/
void tcc_cif_set_offset(void *pCIFRegAddr, unsigned int uiOffsetY, unsigned int uiOffsetUV)
{
	tca_cif_set_offset(pCIFRegAddr, uiOffsetY, uiOffsetUV);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_set_addr(void *pCIFRegAddr, unsigned int uiType, unsigned int uiBaseAddr0, unsigned int uiBaseAddr1, unsigned int uiBaseAddr2)
{
	tca_cif_set_addr(pCIFRegAddr, uiType, uiBaseAddr0, uiBaseAddr1, uiBaseAddr2);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_scale(void *pCIFRegAddr, unsigned int uiScaleEnable, unsigned int uiXScale, unsigned int uiYScale)
{
	tca_cif_scale(pCIFRegAddr, uiScaleEnable, uiXScale, uiYScale);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_setinterrupt(void *pCIFRegAddr, unsigned int uiFlag)
{
	tca_cif_setinterrupt(pCIFRegAddr, uiFlag);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_set656formatconfig(void *pCIFRegAddr, unsigned int uiType, unsigned int uiPsl, unsigned int uiFpv, unsigned int uiSpv, unsigned int uiTpv, unsigned int uiHb, unsigned int uiVb)
{
	tca_cif_set656formatconfig(pCIFRegAddr, uiType, uiPsl, uiFpv, uiSpv, uiTpv, uiHb, uiVb);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
unsigned int tcc_cif_readfifostate(void *pCIFRegAddr, unsigned int uiType)
{
	return tca_cif_readfifostate(pCIFRegAddr, uiType);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_setencrolskipnum(void *pCIFRegAddr, unsigned int uiType, unsigned int uiEncNum, unsigned int uiRolNumV, unsigned int uiRolNumU, unsigned int uiRolNumY, unsigned int uiSkipNum, unsigned int uiVCnt)
{
	tca_cif_setencrolskipnum(pCIFRegAddr, uiType, uiEncNum, uiRolNumV, uiRolNumU, uiRolNumY, uiSkipNum, uiVCnt);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
unsigned int tcc_cif_setcapturectrl(void *pCIFRegAddr, unsigned int uiType)
{
	return tca_cif_setcapturectrl(pCIFRegAddr, uiType);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_seteffectinimgsize(void *pEFFECTRegAddr, unsigned int uiHSize, unsigned int uiVSize)
{
	tca_cif_seteffectinimgsize(pEFFECTRegAddr, uiHSize, uiVSize);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_seteffectmode(void *pEFFECTRegAddr, unsigned int uiFlag)
{
	tca_cif_seteffectmode(pEFFECTRegAddr, uiFlag);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	:
* Parameter 	:
* Return		:
* Note			: 
******************************************************************************/
void tcc_cif_setscalerctrl(void *pCIFSCALERRegAddr, unsigned int uiType)
{
	tca_cif_setscalerctrl(pCIFSCALERRegAddr, uiType);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_seteffectsepiauv(void *pEFFECTRegAddr, unsigned int uiSepiaU, unsigned int uiSepiaV)
{
	tca_cif_seteffectsepiauv(pEFFECTRegAddr, uiSepiaU, uiSepiaV);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_seteffectsketchclampth(void *pEFFECTRegAddr, unsigned int uiType, unsigned int uiSketch, unsigned int uiClamp)
{
	tca_cif_seteffectsketchclampth(pEFFECTRegAddr, uiType, uiSketch, uiClamp);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	:
* Parameter   	:
* Return      	:
* Note          : 
******************************************************************************/
void tcc_cif_setscalerimgsizeoffsetscale(void *pCIFSCALERRegAddr, unsigned int uiType, unsigned int uiSrcHSize, unsigned int uiSrcVSize, unsigned int uiOffH, unsigned int uiOffV, unsigned int uiDstHSize, unsigned int uiDstVSize, unsigned int uiHScale, unsigned int uiVScale)
{
	tca_cif_setscalerimgsizeoffsetscale(pCIFSCALERRegAddr, uiType, uiSrcHSize, uiSrcVSize,  uiOffH,  uiOffV, uiDstHSize, uiDstVSize, uiHScale, uiVScale);
}

void tcc_cif_powerupdown(void *pCKCRegAddr, int iCIFPowerOn)
{
	tca_cif_powerupdown(pCKCRegAddr, iCIFPowerOn);
}

/* end of file */

