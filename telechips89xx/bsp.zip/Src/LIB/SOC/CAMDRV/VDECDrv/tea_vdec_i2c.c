/****************************************************************************
*   FileName    : camera_i2c.c
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/

/*****************************************************************************
*
* Header Files Include
*
******************************************************************************/
#include "tea_vdec_i2c.h"
#include "ioctl_code.h"
#include "tcc_gpioexp.h"
/*****************************************************************************
*
* Defines
*
******************************************************************************/

/*****************************************************************************
*
* Enum
*
******************************************************************************/

/*****************************************************************************
*
* Type Defines
*
******************************************************************************/

/*****************************************************************************
*
* Structures
*
******************************************************************************/

/*****************************************************************************
*
* External Variables
*
******************************************************************************/

/*****************************************************************************
*
* Global Variables
*
******************************************************************************/
HANDLE ghVDECI2C;

/*****************************************************************************
*
* Local Functions
*
******************************************************************************/
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tea_vdec_initializei2c(void)
{
	ghVDECI2C =  CreateFile(L"I2C1:",
			GENERIC_READ | GENERIC_WRITE,
			0,
			0,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			NULL);
	if(!ghVDECI2C)
		RETAILMSG(1,(TEXT("ERROR: Can't open I2C Driver !!\n")));
}

void tea_vdec_deiniti2c(void)
{
	if(ghVDECI2C)
		CloseHandle(ghVDECI2C);
}

void tea_vdec_setpwrctl(int pwrctl_onoff)
{
#if defined(_TVP5150A_) 	
	HANDLE hGXP; // ����̹� �ڵ�
	DWORD	ret;
	DWORD	dwByteReturned;
	GXPINFO    GxpInfo; // Expander �������� ����ü
	BYTE	GxpData[5]; // PCA9539_H, PCA9539_L, PCA9538 ������ 2B,2B,1B
	
	hGXP = CreateFile(L"GXP1:",
			GENERIC_READ | GENERIC_WRITE,
			NULL,
			NULL,
			OPEN_ALWAYS,
			FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,
			NULL);
	
	if(!hGXP)
		RETAILMSG(1,(TEXT("[CAMDRV 	]ERROR: Driver: Can't open GXP Driver - codec pwr control!!\n")));

	GxpInfo.uiDevice = PCA9539LOW; // GPIO Expander Device
	GxpInfo.uiPort = CAM;

	if(pwrctl_onoff)
		GxpInfo.uiState = ON;
	else
		GxpInfo.uiState = OFF;
	
	ret = WriteFile(  hGXP,  &GxpInfo,	sizeof(GxpInfo),   &dwByteReturned,  NULL);
	CloseHandle(hGXP);
#endif
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
int	tea_vdec_terminatei2c(void)
{
	if(ghVDECI2C)
		CloseHandle(ghVDECI2C);
	return 0;
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
void tea_vdec_writei2c(unsigned char hb, unsigned char lb)
{
	BOOL nRet;
	DWORD nTemp=0;
	DWORD returned_bytes;
	I2C_Param sendParam;
	
	RETAILMSG(0,(TEXT("CODEC_SEND_CMD [%x]\n"),&nTemp));
	RETAILMSG(0,(TEXT("[%d]\n"),nTemp));
	nTemp=lb<<8;
	RETAILMSG(0,(TEXT("[%d]\n"),nTemp));
	nTemp+=hb;
	RETAILMSG(0,(TEXT("[%d]\n"),nTemp));

	sendParam.DeviceAddr = (BYTE)0xB8;
	sendParam.nMode = 0;
	sendParam.nWriteByte = 2;
	sendParam.pWriteBuffer =(BYTE *)&nTemp;
	sendParam.nPort 	 = 0;
	sendParam.nTimeout	 = 100;

	nRet = DeviceIoControl(ghVDECI2C,
				IOCTL_I2C_WRITE,
				&sendParam,
				sizeof(I2C_Param),
				NULL,
				0,
				&returned_bytes,
				NULL) ;
	if(nRet <= 0)
		RETAILMSG(1,(TEXT("DeviceIoControl return Fail [%d]\n"),nRet));
	return ;
}


/************************************************************************************************
* FUNCTION		: void VDEC_MULTIWRITE_CMD( unsigned char *data, DWORD nCnt)
*
* DESCRIPTION	: Video Decoder I2C Multi Write Command
*
************************************************************************************************/
void tea_vdec_multiwritei2c(unsigned char *data, DWORD nCnt)
{
	I2C_Param sendParam;
	BOOL nRet;
	DWORD returned_bytes;

	

	sendParam.DeviceAddr = (BYTE)0xB8;
	sendParam.nMode = 0;
	sendParam.nWriteByte = (BYTE)nCnt;

	sendParam.pWriteBuffer = data;

	sendParam.nPort		 = 0;
	sendParam.nTimeout	 = 100;


	nRet = DeviceIoControl(ghVDECI2C,
				IOCTL_I2C_WRITE,
				&sendParam,
				sizeof(I2C_Param),
				NULL,
				0,
				&returned_bytes,
				NULL) ;
	if(nRet <= 0)
		RETAILMSG(1,(TEXT("DeviceIoControl return Fail [%d]\n"),nRet));
	return ;
}
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription  	: 
* Parameter   	: 
* Return      	: 
* Note          : 
******************************************************************************/
unsigned char tea_vdec_readi2c(unsigned char hb)
{
	short value;
	I2C_Param sendParam;
	unsigned char nTemp=0;
	RetParam recvParam;
	BYTE nBfrTXD[2], nBfrRXD[2];
	DWORD returned_bytes,ret;

	sendParam.DeviceAddr = (BYTE)0xB8;
	sendParam.nMode = 0;	
	sendParam.nPort 	 = 0;
	sendParam.nTimeout	 = 100;
	sendParam.nWriteByte = 1;

	nBfrTXD[0] = hb;
	sendParam.pWriteBuffer = nBfrTXD;
	
	sendParam.nReadByte  = 1;
	sendParam.pReadBuffer= nBfrRXD;;
	
	ret = DeviceIoControl(ghVDECI2C,
				IOCTL_I2C_READ,
				&sendParam,
				sizeof(I2C_Param),
				&recvParam,
				sizeof(RetParam),
				&returned_bytes,
				NULL) ;
	
	if(returned_bytes) 
	{

		RETAILMSG(0,(TEXT("[%d]RET Value[%x][%x][%d]\n"),
			ret,
			(unsigned long)recvParam.pReadBuffer[0],
			(unsigned long)recvParam.pReadBuffer[1],
			recvParam.nReadByte));		

		value  = ( recvParam.pReadBuffer[0] & 0x00ff) ;

		RETAILMSG(0,(TEXT("[%x]]\n"),value));
		//RETAILMSG(1,(TEXT("tea_tas5414_i2c_Read :[0x%X] [0x%x]\n"),hb,value));
		return value;
	}
	else
		RETAILMSG(0,(TEXT("[%d]IOCTL_I2C_READ Ret Value FAIL\n"),ret));
	return 0;
}
/* end of file */

