/****************************************************************************
*   FileName    : tca_sensor_micron_MT9D111.c
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/
#include "bsp.h"
#include "tea_vdec_i2c.h"
#if defined(_TVP5150A_)
#include "tca_tvp5150a.h"
#endif

static void delayLoop(int count)
{
	volatile int j,k;
	for(j = 0; j < count; j++)
	{
		for(k=0;k<100000;k++);
	}
}
/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	: 
* Parameter 	: 
* Return		: 
* Note			: 
******************************************************************************/
//CAM_RST#
void tcc_vdec_hwreset(void *pGPIORegAddr)
{
	//GPIO *pGPIOReg = (GPIO*)pGPIORegAddr;
	GPIO *lGPIO_Reg = (GPIO *)tcc_allocbaseaddress((unsigned int)&(HwGPIO_BASE));	
	BITSET(lGPIO_Reg->GPEDAT, Hw26);
	delayLoop(10);
	BITCLR(lGPIO_Reg->GPEDAT, Hw26);
	delayLoop(10);
	BITSET(lGPIO_Reg->GPEDAT, Hw26);
	delayLoop(30);

}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	: 
* Parameter 	: 
* Return		: 
* Note			: 
******************************************************************************/
int tcc_vdec_outputdetect(void *pGPIORegAddr)
{
	//GPIO *pGPIOReg = (GPIO*)pGPIORegAddr;
	GPIO *lGPIO_Reg = (GPIO *)tcc_allocbaseaddress((unsigned int)&(HwGPIO_BASE));	
	return (lGPIO_Reg->GPDDAT & Hw6);
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	: 
* Parameter 	: 
* Return		: 
* Note			: 
******************************************************************************/
void tcc_vdec_regcheck(void)
{
#if defined(_TVP5150A_)	
	unsigned char Data, Addr;

	RETAILMSG(1, (TEXT("  \r\n")));
	RETAILMSG(1, (TEXT(" ******************************************** \r\n")));
	RETAILMSG(1, (TEXT(" ******** Video Decoder (TVP5150A) ********** \r\n")));
	RETAILMSG(1, (TEXT(" ******************************************** \r\n")));
	for (Addr=0; Addr<0x50; Addr++) {
		Data = tea_vdec_readi2c(Addr);
		RETAILMSG(1,(TEXT(":::Addr[0x%02X] = Data[0x%02X]\r\n"), Addr, Data));
	}
	RETAILMSG(1, (TEXT(" ******************************************** \r\n")));
#endif	
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	: 
* Parameter 	: 
* Return		: 
* Note			: 
******************************************************************************/
void tcc_vdec_initialize(void)
{
#if defined(_TVP5150A_)		
	tca_tvp5105a_initialize();
#endif
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	: 
* Parameter 	: 
* Return		: 
* Note			: 
******************************************************************************/
void tcc_vdec_outputctrl(int OnOff)
{
#if defined(_TVP5150A_)		
	tca_tvp5150a_outputctrl(OnOff);
#endif
}

void tcc_vdec_setcampwrctl(int pwrctl_onoff)
{
#if defined(_TVP5150A_) 	
	tea_vdec_setpwrctl(pwrctl_onoff);
#endif
}

/*****************************************************************************
* Function Name : 
******************************************************************************
* Desription	: 
* Parameter 	: 
* Return		: 
* Note			: 
******************************************************************************/
void tcc_vdec_initializei2c(void)
{
#if defined(_TVP5150A_) 	
	tea_vdec_initializei2c();
#endif
}

void tcc_vdec_deiniti2c(void)
{
#if defined(_TVP5150A_) 	
	tea_vdec_deiniti2c();
#endif
}
/* end of file */
