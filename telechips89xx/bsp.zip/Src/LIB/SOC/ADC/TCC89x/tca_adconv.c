/****************************************************************************
 *	 FileName	 : tca_adconv.c
 *	 Description : 
 ****************************************************************************
*
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
*
 ****************************************************************************/
#include <bsp.h>
#include "tca_adconv.h"
#if defined(_LINUX_)
#include <mach/tsadc.h>
#else
#include "oal_memory.h"
#include "tsadc.h"
#endif

/************************************************************************************************
* Global Defines
************************************************************************************************/
#define MASK_ADCDATA10(n)   ( (n)&0x3FF )
#define MASK_ADCDATA12(n)   ( (n)&0xFFF )

 /************************************************************************************************
* Global Handle
************************************************************************************************/


/************************************************************************************************
* Type Define
************************************************************************************************/
#if defined(_LINUX_)
#define Sleep(time) msleep(time)
#endif


/************************************************************************************************
* Global Variable define
************************************************************************************************/
static PGPIO  pGPIO;
static PTSADC pTSADC;


/************************************************************************************************
* FUNCTION		: 
*
* DESCRIPTION	: 
*
************************************************************************************************/

unsigned int    tca_adc_adcinitialize(unsigned int devAddress, void* param )
{
    unsigned int    ret = 0;
    pTSADC = (PTSADC)devAddress;

    pTSADC->ADCDLY = ADC_DELAY(10);
    pTSADC->ADCCON = RESSEL_12BIT | PRESCALER_EN | PRESCALER_VAL(1)|Hw2;
    pTSADC->ADCTSC = ADCTSC_WAIT_PENDOWN;
    pTSADC->ADCCLRINT = CLEAR_ADC_INT;
    pTSADC->ADCCLRUPDN = CLEAR_ADCWK_INT;


    return ret;
}

unsigned int    tca_adc_portinitialize(unsigned int devAddress, void* param)
{
    unsigned int    ret = 0;
    pGPIO = (PGPIO)devAddress;
    BITCSET(pGPIO->GPEFN3 , 0xFFFF0000, Hw28|Hw24|Hw20|Hw16 );  // Function ADCIN
    BITCLR(pGPIO->GPEEN , 0xFF000000); // Port as Input
    BITSET(pGPIO->GPECD1,0xFFFF0000); // Strength Max
    
     return ret;
}


unsigned int    tca_adc_read(unsigned int channel)
{
    unsigned int    ret = 0;
    unsigned int    uiCh;
    switch(channel)
    {
        case ADC_CHANNEL0:
            uiCh = SEL_MUX_AIN0;
            break;
            
        case ADC_CHANNEL1:
            uiCh = SEL_MUX_AIN1;
            break;

        case ADC_CHANNEL2:
            uiCh = SEL_MUX_AIN2;
            break;

        case ADC_CHANNEL3:
            uiCh = SEL_MUX_AIN3;
            break;
    }
	BITCLR(pTSADC->ADCCON, Hw2);//wakeup
	BITCLR(pTSADC->ADCCON , Hw5|Hw4|Hw3);
    BITSET(pTSADC->ADCCON ,(uiCh|ENABLE_START_EN) );

    while (pTSADC->ADCCON & ENABLE_START_EN)
    {	// Wait for Start Bit Cleared
        Sleep(1);
    }
    while (!(pTSADC->ADCCON & ECFLG_END))
    {	// Wait for ADC Conversion Ended
        Sleep(1);
   }

    //ret = MASK_ADCDATA10( (pTSADC->ADCDAT0) );
    ret = MASK_ADCDATA12( (pTSADC->ADCDAT0) );
    BITCSET(pTSADC->ADCCON, SEL_MUX_MASK ,ENABLE_START_EN);
	BITSET(pTSADC->ADCCON, Hw2);

    return ret;
}

unsigned int    tca_adc_tsautoread(int* xpos, int* ypos)
{
    unsigned int    ret = 0;

    BITSET( pTSADC->ADCTSC , ADCTSC_AUTO_ADC4);	// Auto Conversion
	BITCLR(pTSADC->ADCCON, Hw2);//wakeup
    BITSET( pTSADC->ADCCON , ENABLE_START_EN );	// ADC Conversion Start

    while (pTSADC->ADCCON & ENABLE_START_EN)
    {	// Wait for Start Bit Cleared
        Sleep(1);
    }

    while (!(pTSADC->ADCCON & ECFLG_END))
    {	// Wait for ADC Conversion Ended
        Sleep(1);
    }
    //read x value
    *xpos= D_XPDATA_MASK12(pTSADC->ADCDAT0);

    //read y value
    *ypos= D_YPDATA_MASK12(pTSADC->ADCDAT1);

    BITCLR( pTSADC->ADCTSC , ADCTSC_AUTO_ADC5);	// Auto Conversion	

    pTSADC->ADCCLRINT = CLEAR_ADC_INT;
    pTSADC->ADCCLRUPDN = CLEAR_ADCWK_INT;
    pTSADC->ADCTSC = ADCTSC_WAIT_PENDOWN;
	BITSET(pTSADC->ADCCON, Hw2);//Standby
	return ret;
}

unsigned int    tca_adc_tsread(int* x, int* y, int *xp, int *ym)
{
	BITCLR(pTSADC->ADCCON, Hw2);//wakeup
////////////////read x
	pTSADC->ADCTSC = Hw3|Hw0; 
	//gpio setting - 30 high
	BITCLR(pGPIO->GPEFN3 ,Hw32-Hw24);//gpio E31, E30 using GPIO Mode
	BITSET(pGPIO->GPEEN, Hw32-Hw30);//gpio E31, E30 using GPIO Output Mode
	BITSET(pGPIO->GPEDAT, Hw31); // E31 High
	BITCLR(pGPIO->GPEDAT, Hw30); // E30 Low
	BITCSET(pTSADC->ADCCON,Hw6-Hw3,  Hw5|Hw3);
	pTSADC->ADCCON |= ENABLE_START_EN;	// ADC Conversion Start

	while (pTSADC->ADCCON & ENABLE_START_EN)
	{	// Wait for Start Bit Cleared
		;//Sleep(1);
	}

	while (!(pTSADC->ADCCON & ECFLG_END))
	{	// Wait for ADC Conversion Ended
		;//Sleep(1);
	}
	//read x value
	*x= D_XPDATA_MASK12(pTSADC->ADCDAT0);
	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);
	pTSADC->ADCTSC = ADCTSC_AUTO_ADC5;	


////////////////read y
	pTSADC->ADCTSC = Hw3|Hw1;
	//gpio setting - 31,28 high
	BITCLR(pGPIO->GPEFN3 ,Hw24-Hw16);//gpio E29, E28 using GPIO Mode
	BITSET(pGPIO->GPEEN, Hw30-Hw28);//gpio E29, E28 using GPIO Output Mode
	BITSET(pGPIO->GPEDAT, Hw29); // 
	BITCLR(pGPIO->GPEDAT, Hw28); // 
	BITCSET(pTSADC->ADCCON,Hw6-Hw3,  Hw5|Hw4|Hw3);
	pTSADC->ADCCON |= ENABLE_START_EN;	// ADC Conversion Start

	while (pTSADC->ADCCON & ENABLE_START_EN)
	{	// Wait for Start Bit Cleared
		;//Sleep(1);
	}

	while (!(pTSADC->ADCCON & ECFLG_END))
	{	// Wait for ADC Conversion Ended
		;//Sleep(1);
	}
	//read y value
	*y= D_XPDATA_MASK12(pTSADC->ADCDAT1);

	
	pTSADC->ADCTSC = ADCTSC_AUTO_ADC5;	
	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);
	

#if 1
#if 1
	
////////////////read YP
	pTSADC->ADCTSC = Hw3|Hw6|Hw7;	
/*	BITCLR(pGPIO->GPEFN3 ,Hw32-Hw28);//gpio E31 GPIO Mode
	BITCLR(pGPIO->GPEFN3 ,Hw20-Hw16);//gpio E28 GPIO Mode

	BITSET(pGPIO->GPEEN, Hw31); //E31 OUTPUT Mode
	BITSET(pGPIO->GPEEN, Hw28); //E28 OUTPUT Mode

	BITSET(pGPIO->GPEDAT, Hw31); // High
	BITCLR(pGPIO->GPEDAT, Hw28); // Low
*/
	BITCSET(pTSADC->ADCCON,Hw6-Hw3,  Hw5|Hw3);
	pTSADC->ADCCON |= ENABLE_START_EN;	// ADC Conversion Start

	while (pTSADC->ADCCON & ENABLE_START_EN)
	{	// Wait for Start Bit Cleared
		;//Sleep(1);
	}

	while (!(pTSADC->ADCCON & ECFLG_END))
	{	// Wait for ADC Conversion Ended
		;//Sleep(1);
	}
	//read x value
	*xp= D_XPDATA_MASK12(pTSADC->ADCDAT0);

	pTSADC->ADCTSC = ADCTSC_AUTO_ADC5;	
	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);
/*
////////////////read YP
	pTSADC->ADCTSC = Hw3|Hw6|Hw7;	
	BITCLR(pGPIO->GPEFN3 ,Hw32-Hw28);//gpio E31 GPIO Mode
	BITCLR(pGPIO->GPEFN3 ,Hw20-Hw16);//gpio E28 GPIO Mode

	BITSET(pGPIO->GPEEN, Hw31); //E31 OUTPUT Mode
	BITSET(pGPIO->GPEEN, Hw28); //E28 OUTPUT Mode

	BITSET(pGPIO->GPEDAT, Hw31); // High
	BITCLR(pGPIO->GPEDAT, Hw28); // Low
	
	BITCSET(pTSADC->ADCCON,Hw6-Hw3,  Hw5|Hw4);
	pTSADC->ADCCON |= ENABLE_START_EN;	// ADC Conversion Start

	while (pTSADC->ADCCON & ENABLE_START_EN)
	{	// Wait for Start Bit Cleared
		;//Sleep(1);
	}

	while (!(pTSADC->ADCCON & ECFLG_END))
	{	// Wait for ADC Conversion Ended
		;//Sleep(1);
	}
	//read x value
	*ym= D_XPDATA_MASK12(pTSADC->ADCDAT0);
	*/
	*ym=0;
	BITSET(pTSADC->ADCCON, Hw2);//Standby
    BITCLR( pTSADC->ADCTSC , ADCTSC_AUTO_ADC5);	// Auto Conversion	

    pTSADC->ADCCLRINT = CLEAR_ADC_INT;
    pTSADC->ADCCLRUPDN = CLEAR_ADCWK_INT;
    pTSADC->ADCTSC = ADCTSC_WAIT_PENDOWN;


	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);
#else

////////////////read XP
	pTSADC->ADCTSC = Hw3|Hw4|Hw5;	
	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);
	BITCSET(pTSADC->ADCCON,Hw6-Hw3,  Hw5|Hw4|Hw3);
	pTSADC->ADCCON &= ~Hw16;	//using 10Bit
	pTSADC->ADCCON |= ENABLE_START_EN;	// ADC Conversion Start

	while (pTSADC->ADCCON & ENABLE_START_EN)
	{	// Wait for Start Bit Cleared
		;//Sleep(1);
	}

	while (!(pTSADC->ADCCON & ECFLG_END))
	{	// Wait for ADC Conversion Ended
		;//Sleep(1);
	}
	//read x value
	*xp= D_XPDATA_MASK10(pTSADC->ADCDAT0);

	pTSADC->ADCCON |= Hw16;	//using 12Bit
	pTSADC->ADCTSC = ADCTSC_AUTO_ADC5;	
	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);

	////////////////read YM
	pTSADC->ADCTSC = Hw3|Hw4|Hw5;	
	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);
	BITCSET(pTSADC->ADCCON,Hw6-Hw3,  Hw5);
	pTSADC->ADCCON &= ~Hw16;	//using 10Bit
	pTSADC->ADCCON |= ENABLE_START_EN;	// ADC Conversion Start

	while (pTSADC->ADCCON & ENABLE_START_EN)
	{	// Wait for Start Bit Cleared
		;//Sleep(1);
	}

	while (!(pTSADC->ADCCON & ECFLG_END))
	{	// Wait for ADC Conversion Ended
		;//Sleep(1);
	}
	//read x value
	*ym= D_XPDATA_MASK10(pTSADC->ADCDAT0);

	pTSADC->ADCCON |= Hw16;	//using 12Bit
    BITCLR( pTSADC->ADCTSC , ADCTSC_AUTO_ADC5);	// Auto Conversion	

    pTSADC->ADCCLRINT = CLEAR_ADC_INT;
    pTSADC->ADCCLRUPDN = CLEAR_ADCWK_INT;
    pTSADC->ADCTSC = ADCTSC_WAIT_PENDOWN;

	BITSET(pTSADC->ADCCON, Hw2);//Standby
	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);
#endif
#else

////////////////read XP
	pTSADC->ADCTSC = Hw3|Hw4|Hw6;	
	//gpio setting - 30,29 high
	BITCLR(pGPIO->GPEFN3 ,Hw28-Hw20);//gpio E30, E29 GPIO Mode
	BITSET(pGPIO->GPEEN, Hw31-Hw29); //E30, E29 OUTPUT Mode
	BITSET(pGPIO->GPEDAT, Hw29); // High
	BITCLR(pGPIO->GPEDAT, Hw30); // Low
	BITCSET(pTSADC->ADCCON,Hw6-Hw3,  Hw5|Hw4|Hw3);
	pTSADC->ADCCON |= ENABLE_START_EN;	// ADC Conversion Start

	while (pTSADC->ADCCON & ENABLE_START_EN)
	{	// Wait for Start Bit Cleared
		;//Sleep(1);
	}

	while (!(pTSADC->ADCCON & ECFLG_END))
	{	// Wait for ADC Conversion Ended
		;//Sleep(1);
	}
	//read x value
	*xp= D_XPDATA_MASK12(pTSADC->ADCDAT0);

	pTSADC->ADCTSC = ADCTSC_AUTO_ADC5;	
	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);
////////////////read YM
	pTSADC->ADCTSC = Hw3|Hw4|Hw6;	
	//gpio setting - 30,29 high
	BITCLR(pGPIO->GPEFN3 ,Hw28-Hw20);//gpio E30, E29 GPIO Mode
	BITSET(pGPIO->GPEEN, Hw31-Hw29); //E30, E29 OUTPUT Mode
	BITSET(pGPIO->GPEDAT, Hw29); // High
	BITCLR(pGPIO->GPEDAT, Hw30); // Low
	BITCSET(pTSADC->ADCCON,Hw6-Hw3,  Hw5);
	pTSADC->ADCCON |= ENABLE_START_EN;	// ADC Conversion Start

	while (pTSADC->ADCCON & ENABLE_START_EN)
	{	// Wait for Start Bit Cleared
		;//Sleep(1);
	}

	while (!(pTSADC->ADCCON & ECFLG_END))
	{	// Wait for ADC Conversion Ended
		;//Sleep(1);
	}
	//read x value
	*ym= D_XPDATA_MASK12(pTSADC->ADCDAT0);

    BITCLR( pTSADC->ADCTSC , ADCTSC_AUTO_ADC5);	// Auto Conversion	

    pTSADC->ADCCLRINT = CLEAR_ADC_INT;
    pTSADC->ADCCLRUPDN = CLEAR_ADCWK_INT;
    pTSADC->ADCTSC = ADCTSC_WAIT_PENDOWN;

	BITCSET(pGPIO->GPEFN3 ,Hw32-Hw16, Hw28|Hw24|Hw20|Hw16);

#endif
#if defined(_LINUX_)
#else
	RETAILMSG(0, (TEXT("[TOUCH       ]RAW:(%d,%d) \r\n"), *x, *y));
	RETAILMSG(0, (TEXT("[TOUCH       ]RAW:(%d,%d) \r\n"), *xp, *ym ));
#endif
	return 1;
}

unsigned int    tca_adc_powerdown(void)
{
    unsigned int    ret = 0;
    pTSADC->ADCCLRINT = Hw0;
    pTSADC->ADCCLRUPDN = Hw0;
    pTSADC->ADCTSC |= ADCTSC_WAIT_PENDOWN;

    BITSET(pTSADC->ADCCON, STDBM_STANDBY);
    return ret;
}

unsigned int    tca_adc_powerup(void)
{
    unsigned int    ret = 0;
    BITCLR(pTSADC->ADCCON, STDBM_STANDBY); // Because STDBM_NORMAL is [ 0<<2 ] 
     return ret;

}
