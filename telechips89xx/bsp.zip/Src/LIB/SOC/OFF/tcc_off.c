/****************************************************************************
 *	 FileName	 : tcc_off.c
 *	 Description : 
 ****************************************************************************
 *
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include "bsp.h"
#include "tca_off.h"

/*****************************************************************************
* Function Name : tca_off_entersleep()
******************************************************************************/
void tcc_off_entersleep(unsigned int gpiovaddress)
{
	tca_off_entersleep(gpiovaddress);}

/*****************************************************************************
* Function Name : tca_off_entershutdown()
******************************************************************************/
void tcc_off_entersuspend(unsigned int gpiovaddress)
{
	tca_off_entersuspend(gpiovaddress);
}
