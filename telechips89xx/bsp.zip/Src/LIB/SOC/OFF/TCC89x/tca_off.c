/****************************************************************************
 *   FileName    : tca_off.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
 
 /*****************************************************************************
 * tca_off_entersleep 		--> tca_off_copysram --> tca_off_sleep
 * tca_off_entershutdown 	-->	tca_off_copysram --> tca_off_shutdown --> tca_off_sdramselfrefresh
 ******************************************************************************/
/*****************************************************************************
*
* Header Files Include
*
******************************************************************************/
#include "bsp.h"
#include "tca_off.h"
/*****************************************************************************
*
* Defines
*
******************************************************************************/
#if defined(_LINUX_)
	#define addr(b) (0xF0000000+b)
#else
	#if defined(DRAM_SIZE_512)
		#define addr(b) (0xBF000000+b)
	#else
		#define addr(b) (0xB0000000+b)
	#endif
#endif

#define tca_delay(a)				{ volatile int i; for (i=0; i<0x1000; i++); }

/*****************************************************************************
*
* structures
*
******************************************************************************/


/*****************************************************************************
*
* Variables
*
******************************************************************************/

#define BUS_CONTROL
#define GPIOSIZE (16*6 +8) 
unsigned long bkreg[GPIOSIZE];

TCC_REG* p89reg = (TCC_REG*)SUS_DRAM_DATA_ADDR;

/*****************************************************************************
*
* Functions
*
******************************************************************************/
typedef void (*lpfunc)();
lpfunc lpSelfRefresh;

extern int arm_changestack(void);
extern void arm_restorestack(unsigned int restack);
extern void IO_ARM_SaveREG(int addr);

#if defined(DRAM_MDDR)
/*****************************************************************************
* Function Name : tca_off_sdramselfrefresh()
******************************************************************************/
volatile static void tca_off_mddrselfrefresh(void)
{
	// SDRAM into Self Refresh
	volatile unsigned int nCount = 0;

	*(volatile unsigned long *)addr(0x102004) |= Hw2; // GPIOADAT == corebus
	nCount = *(volatile unsigned long *)addr(0x102000); 			


	//Enter Self-Refresh Mode
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 2);	// Wait until PAUSE

	*(volatile unsigned long *)addr(0x301004) = 0x00000001; 		// PL341_SLEEP
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 3);	// Wait until SLEEP

	// To prevent input leakage
	*(volatile unsigned long *)addr(0x304400) |= 0x00000004; 
	// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	// DDR Clock Output Disable		
	nCount = ((*(volatile unsigned long *)addr(0x30100C)) & ~(0x00004000));
	*(volatile unsigned long *)addr(0x30100C) = nCount| (1<<14);		// Stop-MCLK Enter Self-refresh mode
		
	nCount = 1600;
	for ( ; nCount > 0 ; nCount --);		// Wait 
	

	*(volatile unsigned long *)addr(0x400000) = 0x002ffff4; // CKC-CLKCTRL0 - set cpu clk to XIN
	*(volatile unsigned long *)addr(0x400004) = 0x00200014; // CKC-CLKCTRL1 - set display clk to XIN
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; // CKC-CLKCTRL2 - set memory clk to XIN
	*(volatile unsigned long *)addr(0x40000c) = 0x00200014; // CKC-CLKCTRL3 - set graphic clk to XIN
	*(volatile unsigned long *)addr(0x400010) = 0x00200014; // CKC-CLKCTRL4 - set io clk to XIN

	*(volatile unsigned long *)addr(0x400014) = 0x00200014; // CKC-CLKCTRL5 - set video bus clk to XIN
	*(volatile unsigned long *)addr(0x400018) = 0x00200014; // CKC-CLKCTRL6 - set video core clk to XIN
	*(volatile unsigned long *)addr(0x40001c) = 0x00200014; // CKC-CLKCTRL7 - set SMU clk to XIN
	

	*(volatile unsigned long *)addr(0x400020) &= ~0x80000000; // CKC-PLL0CFG - PLL disable
	*(volatile unsigned long *)addr(0x400024) &= ~0x80000000; // CKC-PLL1CFG - PLL disable
	*(volatile unsigned long *)addr(0x400028) &= ~0x80000000; // CKC-PLL2CFG - PLL disable
	*(volatile unsigned long *)addr(0x40002c) &= ~0x80000000; // CKC-PLL3CFG - PLL disable
	
	 while(1)
	 {
		*(volatile unsigned long *)addr(0x102000) &= ~Hw2; 			
		*(volatile unsigned long *)addr(0x102000) &= ~Hw2; 			
	 }	

}

/*****************************************************************************
* Function Name : tca_off_mddrsleep()
******************************************************************************/
volatile static void tca_off_mddrsleep(void)
{
	
		volatile unsigned int nCount = 0;

		unsigned long	*lPLL0,*lPLL1, *lPLL2, *lPLL3;
		unsigned long	*lFBUS_CORE,*lFBUS_MEM, *lFBUS_DDI,*lFBUS_GRP, *lFBUS_IOB, *lFBUS_VBUS, *lFBUS_VCODEC, *lFBUS_SMU;
		unsigned long	*i, *j, *pPCK, *BAKPCK;
		unsigned long *BACK4, *BACK5; //for pmu backup

		int lmem_div = 0;
		int lmem_source = 0;
		int tmpread = *(volatile unsigned long *)addr(0x400008);
		int count = 0;


		tmpread &= ~0x00200000;
		lmem_source = tmpread & 0xf;
		tmpread &= 0xf0;

		while(tmpread){
			tmpread -= 16;
			lmem_div++;
		}	
		
		lmem_div += 1;
	
	

		// Let CPU Speed Lower, Low Clock Operation
		// Assign Registers to Pointers
		lPLL0		= (unsigned long*)(SRAM_ADDR_VAR);
		lPLL1		= (unsigned long*)(SRAM_ADDR_VAR+0x04);
		lPLL2		= (unsigned long*)(SRAM_ADDR_VAR+0x08);
		lPLL3		= (unsigned long*)(SRAM_ADDR_VAR+0x0C);
		BACK4 	    = (unsigned long*)(SRAM_ADDR_VAR+0x10);
		BACK5		= (unsigned long*)(SRAM_ADDR_VAR+0x14);
		lFBUS_CORE  = (unsigned long*)(SRAM_ADDR_VAR+0x18);
		lFBUS_MEM   = (unsigned long*)(SRAM_ADDR_VAR+0x1C);
		lFBUS_DDI   = (unsigned long*)(SRAM_ADDR_VAR+0x20);
		lFBUS_GRP   = (unsigned long*)(SRAM_ADDR_VAR+0x24);
		lFBUS_IOB   = (unsigned long*)(SRAM_ADDR_VAR+0x28);
		lFBUS_VBUS  = (unsigned long*)(SRAM_ADDR_VAR+0x30);
		lFBUS_VCODEC = (unsigned long*)(SRAM_ADDR_VAR+0x34);
		lFBUS_SMU   = (unsigned long*)(SRAM_ADDR_VAR+0x38);
		i = (unsigned long*)(SRAM_ADDR_VAR+0x3C);
		BAKPCK = 	(unsigned long*)(SRAM_ADDR_VAR+0x40);
		


		
		*lFBUS_CORE  = *(volatile unsigned long *)addr(0x400000) ;
		*lFBUS_DDI   = *(volatile unsigned long *)addr(0x400004);
		*lFBUS_MEM   = *(volatile unsigned long *)addr(0x400008);
		*lFBUS_GRP   = *(volatile unsigned long *)addr(0x40000C);  
		*lFBUS_IOB   = *(volatile unsigned long *)addr(0x400010);   
		*lFBUS_VBUS  = *(volatile unsigned long *)addr(0x400014);
		*lFBUS_VCODEC  = *(volatile unsigned long *)addr(0x400018);
		*lFBUS_SMU     = *(volatile unsigned long *)addr(0x40001C);

		*lPLL0 = *(volatile unsigned long *)addr(0x400020);
		*lPLL1 = *(volatile unsigned long *)addr(0x400024);
		*lPLL2 = *(volatile unsigned long *)addr(0x400028);
		*lPLL3 = *(volatile unsigned long *)addr(0x40002c);

		// Save All of PCK_XXX Register
		pPCK	=	(unsigned long*)addr(0x400080);
		
		for( *i=0; *i<37; (*i)++ )
		{
			BAKPCK[*i] = *pPCK;
			if(((BAKPCK[*i] & 0x1f000000) != 0x14000000) ){
					*pPCK = (BAKPCK[*i] & ~0x10000000);
			}
			pPCK ++;
		}

		*BACK4 = *(volatile unsigned long *)addr(0x404004);
		*BACK5 = *(volatile unsigned long *)addr(0x404000);
		
		*BACK4 = (*(volatile unsigned long *)addr(0x404018)) & 0xFF;
	
	//Enter Self-Refresh Mode
		*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
		while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 2);	// Wait until PAUSE

		*(volatile unsigned long *)addr(0x301004) = 0x00000001; 		// PL341_SLEEP
		while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 3);	// Wait until SLEEP
	
		// To prevent input leakage
		*(volatile unsigned long *)addr(0x304400) |= 0x00000004; 
	// DLL OFF
		*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
		*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
		*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	// DDR Clock Output Disable		
		nCount = ((*(volatile unsigned long *)addr(0x30100C)) & ~(0x00004000));
		*(volatile unsigned long *)addr(0x30100C) = nCount| (1<<14);		// Stop-MCLK Enter Self-refresh mode
	
		
		nCount = 800;
		for ( ; nCount > 0 ; nCount --);		// Wait 
		nCount = 800;
		for ( ; nCount > 0 ; nCount --);		// Wait 

		

	*(volatile unsigned long *)addr(0x400000) = 0x002ffff4; // CKC-CLKCTRL0 - set cpu clk to XIN
	*(volatile unsigned long *)addr(0x400004) = 0x00200014; // CKC-CLKCTRL1 - set display clk to XIN
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; // CKC-CLKCTRL2 - set memory clk to XIN
	

	*(volatile unsigned long *)addr(0x40000c) = 0x00200014; // CKC-CLKCTRL3 - set graphic clk to XIN
	*(volatile unsigned long *)addr(0x400010) = 0x00200014; // CKC-CLKCTRL4 - set io clk to XIN

	*(volatile unsigned long *)addr(0x400014) = 0x00200014; // CKC-CLKCTRL5 - set video bus clk to XIN
	*(volatile unsigned long *)addr(0x400018) = 0x00200014; // CKC-CLKCTRL6 - set video core clk to XIN
	*(volatile unsigned long *)addr(0x40001c) = 0x00200014; // CKC-CLKCTRL7 - set SMU clk to XIN


	*(volatile unsigned long *)addr(0x400020) &= ~0x80000000; // CKC-PLL0CFG - PLL disable
	*(volatile unsigned long *)addr(0x400024) &= ~0x80000000; // CKC-PLL1CFG - PLL disable
	*(volatile unsigned long *)addr(0x400028) &= ~0x80000000; // CKC-PLL2CFG - PLL disable
	*(volatile unsigned long *)addr(0x40002c) &= ~0x80000000; // CKC-PLL3CFG - PLL disable

	//go power down mode......

	
	*(volatile unsigned long *)addr(0x102024) &= ~(0x0000f000); // 
	*(volatile unsigned long *)addr(0x102004) &= ~(0x00000008); // 


	*(volatile unsigned long *)addr(0x404008) = 0x00008000; // PMU-WKUPPOL  - SRCS[15](GPIO A3) active low	
	*(volatile unsigned long *)addr(0x404004) = 0x00008000; // PMU-WKUPEN  - SRCS[15](GPIO A3) enable	
	

#ifdef BUS_CONTROL
		*(volatile unsigned long *)addr(0x240050) |= Hw0;
		*(volatile unsigned long *)addr(0x404018) &= ~0x1F; 
		nCount = 5000;	
		for ( ; nCount > 0 ; nCount --);		// delay
		*(volatile unsigned long *)addr(0x404018) |= 0x1F; 

		//Video Bus, DDi Bus, Graphic Bus, IO Bus  off
		//SWRESET ON
		*(volatile unsigned long *)addr(0x400044) |= Hw6|Hw5;//Graphic Bus 
		*(volatile unsigned long *)addr(0x400044) |= Hw3;//Video Bus 
		*(volatile unsigned long *)addr(0x400044) |= Hw1;//Ddi Bus
		nCount = 5000;
		for ( ; nCount > 0 ; nCount --);		// delay
		
		//pmu disable
		*(volatile unsigned long *)addr(0x404018) |= Hw8;//Graphic Bus  
		*(volatile unsigned long *)addr(0x404018) |= Hw6;//Video Bus 
		*(volatile unsigned long *)addr(0x404018) |= Hw7;//Ddi Bus 
		
		nCount = 1000;
		for ( ; nCount > 0 ; nCount --);		// Wait 
#endif


		*(volatile unsigned long *)addr(0x404000) |= 0x00000004; // PMU-CONTROL - Power Down(BSP default)



		nCount = 10;
		for ( ; nCount > 0 ; nCount --);		// Wait 

		*(volatile unsigned long *)addr(0x400020) = *lPLL0;
		*(volatile unsigned long *)addr(0x400024) = *lPLL1;
		*(volatile unsigned long *)addr(0x400028) = *lPLL2;
		*(volatile unsigned long *)addr(0x40002c) = *lPLL3;

			//wakeup start
#ifdef BUS_CONTROL
		
		nCount = 1000;
		for ( ; nCount > 0 ; nCount --);		// Wait 
		//pmu disable
		*(volatile unsigned long *)addr(0x404018) &= ~Hw8;//Graphic Bus  
		*(volatile unsigned long *)addr(0x404018) &= ~Hw6;//Video Bus 
		*(volatile unsigned long *)addr(0x404018) &= ~Hw7;//Ddi Bus 
		nCount = 10000;
		for ( ; nCount > 0 ; nCount --);		// delay
		//SWRESET OFF
		*(volatile unsigned long *)addr(0x400044) &= ~(Hw6|Hw5);//Graphic Bus 
		*(volatile unsigned long *)addr(0x400044) &= ~(Hw3);//Video Bus 
		*(volatile unsigned long *)addr(0x400044) &= ~(Hw1);//Ddi Bus
		*(volatile unsigned long *)addr(0x240050) &= ~Hw0;
		*(volatile unsigned long *)addr(0x404018) = *BACK4; 		
#endif	

	//wakeup start
		nCount = 10;
		for ( ; nCount > 0 ; nCount --);		// Wait 

		/*
		for (nCount=0;nCount<10;nCount++)
			*(volatile unsigned long *)addr(0x302008) = 0x00040000; // Direct COmmnad Register 
		*/
		*(volatile unsigned long *)addr(0x400000) = *lFBUS_CORE ;
		*(volatile unsigned long *)addr(0x400008) = *lFBUS_MEM;
		/*
		for (nCount=0;nCount<10;nCount++)
			*(volatile unsigned long *)addr(0x302008) = 0x00040000; // Direct COmmnad Register 
		*/
		
		pPCK = (unsigned long*)addr(0x400080);
		
		for( (*i)=0; (*i)<37; (*i)++)
			*pPCK++ = BAKPCK[*i];
		
		nCount = 0x100;
		for ( ; nCount > 0 ; nCount --);		// Wait 
		
		*(volatile unsigned long *)addr(0x400004) = *lFBUS_DDI;
		*(volatile unsigned long *)addr(0x40000C) = *lFBUS_GRP;  
		*(volatile unsigned long *)addr(0x400010) = *lFBUS_IOB;	
		*(volatile unsigned long *)addr(0x400014) = *lFBUS_VBUS;
		*(volatile unsigned long *)addr(0x400018) = *lFBUS_VCODEC;
		*(volatile unsigned long *)addr(0x40001C) = *lFBUS_SMU;

	//Exit Self-Refresh Mode	
		// Exit SelfRefresh
		*(volatile unsigned long *)addr(0x30100C)	&= ~(0x00004000);
		*(volatile unsigned long *)addr(0x304400) &= ~(0x00000004); 
		
#if 1
		*(volatile unsigned long *)addr(0x301004) = 0x00000002; 		// PL340_WAKEUP
		while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 2);	// Wait until PAUSE

		*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL340_CONFIGURE
		while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 0);	// Wait until CONFIGURE	

		*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
		while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 2);	// Wait until PAUSE

		*(volatile unsigned long *)addr(0x301004) = 0x00000001; 		// PL341_SLEEP
		while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 3);	// Wait until SLEEP
		
#endif

	// DLL ON	
		*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		*(volatile unsigned long *)addr(0x303020) &=  ~(0x00000001);		// SW ? AXI_SEL     = 0
		*(volatile unsigned long *)addr(0x303020) |= 0x00000002; 		// SW ? IO_SEL      = 1;
		*(volatile unsigned long *)addr(0x303024) = 0x00000100;		// Hw8 SDR/mDDR/DDR


		*(volatile unsigned long *)addr(0x304400) = 0x00000002; 		// DDR2PHY_PHYMODE
		*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL

	
		//160Mhz
		*(volatile unsigned long *)addr(0x304408)=0x00002020; 


	*(volatile unsigned long *)addr(0x304404)=0x00000003; // DLLCTRL - DLL ON, DLL start
	while (!((*(volatile unsigned long *)addr(0x304404)) & (3<<3) == 0x18));	// Wait until PDFL == 1
	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000003; 		// GATECTRL	
	*(volatile unsigned long *)addr(0x304430) = 0x00000001; 	// RDDELAY	

	*(volatile unsigned long *)addr(0x304428) = 0x00068351; 		// ZQCTRL
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) = 0x00068353; 		// ZQCTRL
	*(volatile unsigned long *)addr(0x304428) = 0x00068351; 		// ZQCTRL
	
	// END DLL On
	
	*(volatile unsigned long *)addr(0x301004) = 0x00000002; 		// PL340_WAKEUP
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 2);	// Wait until PAUSE

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL340_CONFIGURE
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 0);	// Wait until CONFIGURE	

	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY



}

#endif

#if defined(DRAM_DDR2)
/*****************************************************************************
* Function Name : tca_off_sdramselfrefresh()
******************************************************************************/
volatile static void tca_off_ddr2selfrefresh(void)
{
	// SDRAM into Self Refresh
	volatile unsigned int nCount = 0;

	*(volatile unsigned long *)addr(0x102004) |= Hw2; // GPIOADAT == corebus
	nCount = *(volatile unsigned long *)addr(0x102000); 			


	//Enter Self-Refresh Mode
		*(volatile unsigned long *)addr(0x302004) = 0x00000003; // PL341_PAUSE
		while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED
	
		*(volatile unsigned long *)addr(0x302004) = 0x00000001; // PL341_SLEEP
		while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=3); // Wait PL34X_STATUS_LOWPOWER
	
		// To prevent input leakage
		*(volatile unsigned long *)addr(0x304400) |= 0x00000004; 
	// DLL OFF
		*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	 // DLL-0FF,DLL-Stop running
		*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); // Calibration Start,Update Calibration
		*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);  //SDRAM IO Control Register Gatein Signal Power Down
			
		nCount = ((*(volatile unsigned long *)addr(0x30200C)) & ~(0x00004000));
		*(volatile unsigned long *)addr(0x30200C) = nCount| (1<<14);		// Stop-MCLK Enter Self-refresh mode
	
		
		nCount = 1600;
		for ( ; nCount > 0 ; nCount --);		// Wait 
	

	*(volatile unsigned long *)addr(0x400000) = 0x002ffff4; // CKC-CLKCTRL0 - set cpu clk to XIN
	*(volatile unsigned long *)addr(0x400004) = 0x00200014; // CKC-CLKCTRL1 - set display clk to XIN
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; // CKC-CLKCTRL2 - set memory clk to XIN
	*(volatile unsigned long *)addr(0x40000c) = 0x00200014; // CKC-CLKCTRL3 - set graphic clk to XIN
	*(volatile unsigned long *)addr(0x400010) = 0x00200014; // CKC-CLKCTRL4 - set io clk to XIN

	*(volatile unsigned long *)addr(0x400014) = 0x00200014; // CKC-CLKCTRL5 - set video bus clk to XIN
	*(volatile unsigned long *)addr(0x400018) = 0x00200014; // CKC-CLKCTRL6 - set video core clk to XIN
	*(volatile unsigned long *)addr(0x40001c) = 0x00200014; // CKC-CLKCTRL7 - set SMU clk to XIN
	

	*(volatile unsigned long *)addr(0x400020) &= ~0x80000000; // CKC-PLL0CFG - PLL disable
	*(volatile unsigned long *)addr(0x400024) &= ~0x80000000; // CKC-PLL1CFG - PLL disable
	*(volatile unsigned long *)addr(0x400028) &= ~0x80000000; // CKC-PLL2CFG - PLL disable
	*(volatile unsigned long *)addr(0x40002c) &= ~0x80000000; // CKC-PLL3CFG - PLL disable
	
	 while(1)
	 {
		*(volatile unsigned long *)addr(0x102000) &= ~Hw2; 			
		*(volatile unsigned long *)addr(0x102000) &= ~Hw2; 			
	 }	

}

/*****************************************************************************
* Function Name : tca_off_sleep()
******************************************************************************/
volatile static void tca_off_ddr2sleep(void)
{
	
		volatile unsigned int nCount = 0;

		unsigned long	*lPLL0,*lPLL1, *lPLL2, *lPLL3;
		unsigned long	*lFBUS_CORE,*lFBUS_MEM, *lFBUS_DDI,*lFBUS_GRP, *lFBUS_IOB, *lFBUS_VBUS, *lFBUS_VCODEC, *lFBUS_SMU;
		unsigned long	*i,*pPCK, *BAKPCK;

		unsigned long *BACK4, *BACK5; //for pmu backup

		int lmem_div = 0;
		int lmem_source = 0;
		int tmpread = *(volatile unsigned long *)addr(0x400008);
		int count = 0;


		tmpread &= ~0x00200000;
		lmem_source = tmpread & 0xf;
		tmpread &= 0xf0;

		while(tmpread){
			tmpread -= 16;
			lmem_div++;
		}	
		
		lmem_div += 1;
	
	

		// Let CPU Speed Lower, Low Clock Operation
		// Assign Registers to Pointers
		lPLL0		= (unsigned long*)(SRAM_ADDR_VAR);
		lPLL1		= (unsigned long*)(SRAM_ADDR_VAR+0x04);
		lPLL2		= (unsigned long*)(SRAM_ADDR_VAR+0x08);
		lPLL3		= (unsigned long*)(SRAM_ADDR_VAR+0x0C);
		BACK4 	    = (unsigned long*)(SRAM_ADDR_VAR+0x10);
		BACK5		= (unsigned long*)(SRAM_ADDR_VAR+0x14);
		lFBUS_CORE  = (unsigned long*)(SRAM_ADDR_VAR+0x18);
		lFBUS_MEM   = (unsigned long*)(SRAM_ADDR_VAR+0x1C);
		lFBUS_DDI   = (unsigned long*)(SRAM_ADDR_VAR+0x20);
		lFBUS_GRP   = (unsigned long*)(SRAM_ADDR_VAR+0x24);
		lFBUS_IOB   = (unsigned long*)(SRAM_ADDR_VAR+0x28);
		lFBUS_VBUS  = (unsigned long*)(SRAM_ADDR_VAR+0x30);
		lFBUS_VCODEC = (unsigned long*)(SRAM_ADDR_VAR+0x34);
		lFBUS_SMU   = (unsigned long*)(SRAM_ADDR_VAR+0x38);
		i = (unsigned long*)(SRAM_ADDR_VAR+0x3C);
		
		BAKPCK = 	(unsigned long*)(SRAM_ADDR_VAR+0x40);



		
		*lFBUS_CORE  = *(volatile unsigned long *)addr(0x400000) ;
		*lFBUS_DDI   = *(volatile unsigned long *)addr(0x400004);
		*lFBUS_MEM   = *(volatile unsigned long *)addr(0x400008);
		*lFBUS_GRP   = *(volatile unsigned long *)addr(0x40000C);  
		*lFBUS_IOB   = *(volatile unsigned long *)addr(0x400010);   
		*lFBUS_VBUS  = *(volatile unsigned long *)addr(0x400014);
		*lFBUS_VCODEC  = *(volatile unsigned long *)addr(0x400018);
		*lFBUS_SMU     = *(volatile unsigned long *)addr(0x40001C);

		*lPLL0 = *(volatile unsigned long *)addr(0x400020);
		*lPLL1 = *(volatile unsigned long *)addr(0x400024);
		*lPLL2 = *(volatile unsigned long *)addr(0x400028);
		*lPLL3 = *(volatile unsigned long *)addr(0x40002c);

		// Save All of PCK_XXX Register
		pPCK	=	(unsigned long*)addr(0x400080);
		
		for( *i=0; *i<37; (*i)++ )
		{
			BAKPCK[*i] = *pPCK;
			if(((BAKPCK[*i] & 0x1f000000) != 0x14000000) ){
					*pPCK = (BAKPCK[*i] & ~0x10000000);
			}
			pPCK ++;
		}

		*BACK4 = *(volatile unsigned long *)addr(0x404004);
		*BACK5 = *(volatile unsigned long *)addr(0x404000);


		*BACK4 = (*(volatile unsigned long *)addr(0x404018)) & 0xFF;

	//Enter Self-Refresh Mode
		*(volatile unsigned long *)addr(0x302004) = 0x00000003; // PL341_PAUSE
		while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED
	
		*(volatile unsigned long *)addr(0x302004) = 0x00000001; // PL341_SLEEP
		while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=3); // Wait PL34X_STATUS_LOWPOWER
	
		// To prevent input leakage
		*(volatile unsigned long *)addr(0x304400) |= 0x00000004; 
	// DLL OFF
		*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	 // DLL-0FF,DLL-Stop running
		*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); // Calibration Start,Update Calibration
		*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);  //SDRAM IO Control Register Gatein Signal Power Down
			
		nCount = ((*(volatile unsigned long *)addr(0x30200C)) & ~(0x00004000));
		*(volatile unsigned long *)addr(0x30200C) = nCount| (1<<14);		// Stop-MCLK Enter Self-refresh mode
	

	//DRAM controller power down
		*(volatile unsigned long *)addr(0x30302C) =0x3fff;
		*(volatile unsigned long *)addr(0x30302C) &= ~Hw14;
		for (nCount=0; nCount<10; nCount++);
		*(volatile unsigned long *)addr(0x304400) = 0x2;
		for (nCount=0; nCount<10; nCount++);
		*(volatile unsigned long *)addr(0x304404) &= ~(Hw0|Hw1);
		*(volatile unsigned long *)addr(0x304428) &= ~(Hw0|Hw1);
		*(volatile unsigned long *)addr(0x304428) |= Hw12;
		*(volatile unsigned long *)addr(0x304428) |= Hw0;
		
		*(volatile unsigned long *)addr(0x304400) = 0x6;
		



		nCount = 800;
		for ( ; nCount > 0 ; nCount --);		// Wait 
		nCount = 800;
		for ( ; nCount > 0 ; nCount --);		// Wait 

		

		*(volatile unsigned long *)addr(0x400000) = 0x002ffff4; // CKC-CLKCTRL0 - set cpu clk to XIN
		*(volatile unsigned long *)addr(0x400004) = 0x00200014; // CKC-CLKCTRL1 - set display clk to XIN
		*(volatile unsigned long *)addr(0x400008) = 0x00200014; // CKC-CLKCTRL2 - set memory clk to XIN
		

		*(volatile unsigned long *)addr(0x40000c) = 0x00200014; // CKC-CLKCTRL3 - set graphic clk to XIN
		*(volatile unsigned long *)addr(0x400010) = 0x00200014; // CKC-CLKCTRL4 - set io clk to XIN

		*(volatile unsigned long *)addr(0x400014) = 0x00200014; // CKC-CLKCTRL5 - set video bus clk to XIN
		*(volatile unsigned long *)addr(0x400018) = 0x00200014; // CKC-CLKCTRL6 - set video core clk to XIN
		*(volatile unsigned long *)addr(0x40001c) = 0x00200014; // CKC-CLKCTRL7 - set SMU clk to XIN


		*(volatile unsigned long *)addr(0x400020) &= ~0x80000000; // CKC-PLL0CFG - PLL disable
		*(volatile unsigned long *)addr(0x400024) &= ~0x80000000; // CKC-PLL1CFG - PLL disable
		*(volatile unsigned long *)addr(0x400028) &= ~0x80000000; // CKC-PLL2CFG - PLL disable
		*(volatile unsigned long *)addr(0x40002c) &= ~0x80000000; // CKC-PLL3CFG - PLL disable

		nCount = 100;
		for ( ; nCount > 0 ; nCount --);		// Wait 

		//go power down mode......

		*(volatile unsigned long *)addr(0x102024) &= ~(0x0000f000); // 
		*(volatile unsigned long *)addr(0x102004) &= ~(0x00000008); // 


		*(volatile unsigned long *)addr(0x404008) = 0x00008000; // PMU-WKUPPOL  - SRCS[15](GPIO A3) active low	
		*(volatile unsigned long *)addr(0x404004) = 0x00008000; // PMU-WKUPEN  - SRCS[15](GPIO A3) enable	

#ifdef BUS_CONTROL
		*(volatile unsigned long *)addr(0x240050) |= Hw0;
		*(volatile unsigned long *)addr(0x404018) &= ~0x1F; 
		nCount = 5000;	
		for ( ; nCount > 0 ; nCount --);		// delay
		*(volatile unsigned long *)addr(0x404018) |= 0x1F; 

		//Video Bus, DDi Bus, Graphic Bus, IO Bus  off
		//SWRESET ON
		*(volatile unsigned long *)addr(0x400044) |= Hw6|Hw5;//Graphic Bus 
		*(volatile unsigned long *)addr(0x400044) |= Hw3;//Video Bus 
		*(volatile unsigned long *)addr(0x400044) |= Hw1;//Ddi Bus
		nCount = 5000;
		for ( ; nCount > 0 ; nCount --);		// delay
		
		//pmu disable
		*(volatile unsigned long *)addr(0x404018) |= Hw8;//Graphic Bus  
		*(volatile unsigned long *)addr(0x404018) |= Hw6;//Video Bus 
		*(volatile unsigned long *)addr(0x404018) |= Hw7;//Ddi Bus 
		
		nCount = 1000;
		for ( ; nCount > 0 ; nCount --);		// Wait 
#endif


		*(volatile unsigned long *)addr(0x404000) |= 0x00000004; // PMU-CONTROL - Power Down(BSP default)



		nCount = 10;
		for ( ; nCount > 0 ; nCount --);		// Wait 

		*(volatile unsigned long *)addr(0x400020) = *lPLL0;
		*(volatile unsigned long *)addr(0x400024) = *lPLL1;
		*(volatile unsigned long *)addr(0x400028) = *lPLL2;
		*(volatile unsigned long *)addr(0x40002c) = *lPLL3;

			//wakeup start
#ifdef BUS_CONTROL
		
		nCount = 1000;
		for ( ; nCount > 0 ; nCount --);		// Wait 
		//pmu disable
		*(volatile unsigned long *)addr(0x404018) &= ~Hw8;//Graphic Bus  
		*(volatile unsigned long *)addr(0x404018) &= ~Hw6;//Video Bus 
		*(volatile unsigned long *)addr(0x404018) &= ~Hw7;//Ddi Bus 
		nCount = 10000;
		for ( ; nCount > 0 ; nCount --);		// delay
		//SWRESET OFF
		*(volatile unsigned long *)addr(0x400044) &= ~(Hw6|Hw5);//Graphic Bus 
		*(volatile unsigned long *)addr(0x400044) &= ~(Hw3);//Video Bus 
		*(volatile unsigned long *)addr(0x400044) &= ~(Hw1);//Ddi Bus
		*(volatile unsigned long *)addr(0x404018) = *BACK4; 		
		*(volatile unsigned long *)addr(0x240050) &= ~Hw0;
#endif	



	nCount = 10;
	for ( ; nCount > 0 ; nCount --);		// Wait 


		*(volatile unsigned long *)addr(0x400000) = *lFBUS_CORE ;
		*(volatile unsigned long *)addr(0x400008) = *lFBUS_MEM;

		
		pPCK = (unsigned long*)addr(0x400080);
		
		for( (*i)=0; (*i)<37; (*i)++)
			*pPCK++ = BAKPCK[*i];
		
		nCount = 0x100;
		for ( ; nCount > 0 ; nCount --);		// Wait 
		
		*(volatile unsigned long *)addr(0x400004) = *lFBUS_DDI;
		*(volatile unsigned long *)addr(0x40000C) = *lFBUS_GRP;  
		*(volatile unsigned long *)addr(0x400010) = *lFBUS_IOB;	
		*(volatile unsigned long *)addr(0x400014) = *lFBUS_VBUS;
		*(volatile unsigned long *)addr(0x400018) = *lFBUS_VCODEC;
		*(volatile unsigned long *)addr(0x40001C) = *lFBUS_SMU;






	//Exit Self-Refresh Mode	
		// Exit SelfRefresh
		*(volatile unsigned long *)addr(0x30200C)	&= ~(0x00004000);
		*(volatile unsigned long *)addr(0x304400) &= ~(0x00000004); 
		
		/*
		*(volatile unsigned long *)addr(0x302004 = 0x00000002; // PL341_WakeUP
		while (((*(volatile unsigned long *)0xF0302000) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED
		*(volatile unsigned long *)addr(0x302004 = 0x00000004; // PL341_Configure
		while (((*(volatile unsigned long *)addr(0x302000) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG
		*(volatile unsigned long *)addr(0x302004 = 0x00000003; // PL341_PAUSE
		while (((*(volatile unsigned long *)addr(0x302000) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED
		*(volatile unsigned long *)addr(0x302004 = 0x00000001; // PL341_SLEEP
		while (((*(volatile unsigned long *)addr(0x302000) & 0x3)!=3); // Wait PL34X_STATUS_LOWPOWER
		*/
	
	// DLL ON	
		*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; // SSTL SDRAM IO Control Register 
		*(volatile unsigned long *)addr(0x303020) |= 0x00000001; // Common Register AXI_SEL
		*(volatile unsigned long *)addr(0x303020) |= 0x00000002; // Common Register IO_SEL 
		*(volatile unsigned long *)addr(0x303024) &= ~(0x00000100); // PHYCTRL	Seletct DDR2
	
		*(volatile unsigned long *)addr(0x304400) =  0x0;	  
		*(volatile unsigned long *)addr(0x304404) =  0x00000001;	  // DLL-On
	
		//330Mhz
		if(lmem_div == 1){
			if((*lPLL0/1) >= 400 && lmem_source == 0)
				*(volatile unsigned long *)addr(0x304408) = 0x00001212; // DLLPDCFG
			else
				*(volatile unsigned long *)addr(0x304408) = 0x00001717; // DLLPDCFG
		}
		else{
			if((*lPLL0/2) >= 400 && lmem_source == 0)
				*(volatile unsigned long *)addr(0x304408) = 0x00001212; // DLLPDCFG
			else
				*(volatile unsigned long *)addr(0x304408) = 0x00001717; // DLLPDCFG
		}


//		*(volatile unsigned long *)addr(0x304408 = 0x00001414; // DLLPDCFG
		*(volatile unsigned long *)addr(0x304404) =  (0x00000003);	  // DLL-On, DLL-Start
		while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	
		*(volatile unsigned long *)addr(0x304424) = 0x35; // DLL Force Lock Value Register
		*(volatile unsigned long *)addr(0x30440C) = 0x6; // Gate Control
	
		if(lmem_div == 1){
			if((*lPLL0/1) >= 400 && lmem_source == 0)
				*(volatile unsigned long *)addr(0x304430) = 0x1; // uRDDELAY  Read Delay Register
			else
				*(volatile unsigned long *)addr(0x304430) = 0x4; // uRDDELAY  Read Delay Register
		}
		else{
			
			if((*lPLL0/2) >= 400 && lmem_source == 0)
				*(volatile unsigned long *)addr(0x304430) = 0x1; // uRDDELAY  Read Delay Register
			else
				*(volatile unsigned long *)addr(0x304430) = 0x4; // uRDDELAY  Read Delay Register
		
		}

	
		//DBG_PRINT ("ZQ Cal ...");
		/*
		*(volatile unsigned long *)addr(0x304428 = 0
												| (0x1		<< 0)	// Calibration Start
												| (0x0		<< 1)	// Update Calibration
												| (0x0		<< 2)	// Override ctrl_force_impp[2:0]/impn[2:0]
												| (0x2		<< 3)	// Calibration PULL-UP forced value
												| (0x5		<< 6)	// Calibration PULL-DOWN forced value
												| (0x0		<< 9)	// On-Die Termination Resistor Value Selection
												| (0x1		<< 12)	// Termination Selection	: 0 for disable
												| (0x4		<< 13)	// Drive Strength
												| (0x0		<< 16)	// Periodic Calibration
												| (0x3		<< 17)	// Update Counter Load Value
													;
													*/
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (0 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
		//ZQCalWait 
		while (((*(volatile unsigned long *)addr(0x30442C)	& (0x00000001)) != (0x00000001)));
	
		//ZQCalUpdate
		*(volatile unsigned long *)addr(0x304428) |= 0x00000002;
		*(volatile unsigned long *)addr(0x304428) &= ~0x00000002;
	// END DLL On
	
		*(volatile unsigned long *)addr(0x302004) = 0x00000002; // PL341_WakeUP
		while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED
		*(volatile unsigned long *)addr(0x302004) = 0x00000004; // PL341_Configure
		while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG
		*(volatile unsigned long *)addr(0x302004) = 0x00000000; // PL341_GO
		while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=1); //Wait PL34X_STATUS_READY	


}

#endif

/*****************************************************************************
* Function Name : tca_off_shutdown()
******************************************************************************/
volatile static void tca_off_suspend(void)
{

	volatile unsigned int nCount = 0;

	
	CKC* ckc = (CKC*)(OALPAtoVA((unsigned int)&HwCLK_BASE,FALSE)); 
	PIC* pic = (PIC*)(OALPAtoVA((unsigned int)&HwPIC_BASE,FALSE)); 
	VIC* vic = (VIC*)(OALPAtoVA((unsigned int)&HwVIC_BASE,FALSE)); 
	TIMER* timer = (TIMER*)(OALPAtoVA((unsigned int)&HwTMR_BASE,FALSE)); 
	PMU* pmu = (PMU*)(OALPAtoVA((unsigned int)&HwPMU_BASE,FALSE)); 
	GPIO* gpio = (GPIO*)(OALPAtoVA((unsigned int)&HwGPIO_BASE,FALSE)); 
	//DRAM* dram= (DRAM*)(OALPAtoVA((unsigned int)&HwDRAM_BASE,FALSE));
	//DRAMMX* drammx= (DRAMMX*)(OALPAtoVA((unsigned int)&HwDRAM_BASE,FALSE));
	//DRAMPHY* dramphy= (DRAMPHY*)(OALPAtoVA((unsigned int)&HwDRAMPHY_BASE,FALSE));
	//DRAMMISC* drammisc= (DRAMMISC*)(OALPAtoVA((unsigned int)&HwDRAMMISC_BASE,FALSE));
	//DRAMMEMBUS* drammembus= (DRAMMEMBUS*)(OALPAtoVA((unsigned int)&HwDRAMMEMBUS_BASE,FALSE));
	MISCCOREBUS* misccorebus= (MISCCOREBUS*)(OALPAtoVA((unsigned int)&HwCORECFG_BASE,FALSE));
	IOBUSCFG* iobuscfg= (IOBUSCFG*)(OALPAtoVA((unsigned int)&HwIOBUSCFG_BASE,FALSE));
	TSADC* tsadc = (TSADC*)(OALPAtoVA((unsigned int)&HwTSADC_BASE,FALSE));
/*	
	SMUI2CMASTER* smui2cmaster0 = (SMUI2CMASTER*)(OALPAtoVA((unsigned int)&HwSMU_I2CMASTER0_BASE,FALSE));
	SMUI2CMASTER* smui2cmaster1 = (SMUI2CMASTER*)(OALPAtoVA((unsigned int)&HwSMU_I2CMASTER1_BASE,FALSE));
	SMUI2CICLK* smui2ciclk = (SMUI2CICLK*)(OALPAtoVA((unsigned int)&HwSMU_I2CICLK_BASE,FALSE));
*/
	DDICONFIG* ddiconfig = (DDICONFIG*)(OALPAtoVA((unsigned int)&HwDDI_CONFIG_BASE,FALSE));
	DDICACHE* ddicache = (DDICACHE*)(OALPAtoVA((unsigned int)&HwDDI_CACHE_BASE,FALSE));

	USBHOST11* usbhost11 = (USBHOST11*)(OALPAtoVA((unsigned int)&HwUSBHOST_BASE,FALSE));
	USBHOST11CFG* usbhost11cfg = (USBHOST11CFG*)(OALPAtoVA((unsigned int)&HwUSBHOSTCFG_BASE,FALSE));
/*
	USB20OTG* usb20otg = (USB20OTG*)(OALPAtoVA((unsigned int)&HwUSB20OTG_BASE,FALSE));
	USBOTGCFG* usbotgconfig = (USBOTGCFG*)(OALPAtoVA((unsigned int)&HwUSBOTGCFG_BASE,FALSE));
	USBPHYCFG* usbphycfg = (USBPHYCFG*)(OALPAtoVA((unsigned int)&HwUSBPHYCFG_BASE,FALSE));
*/
	RTC* rtc = (RTC*)(OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE));
	//NFC* nfc = (NFC*)(OALPAtoVA((unsigned int)&HwNFC_BASE,FALSE));
	//LCDC* lcdc0 = (LCDC*)(OALPAtoVA((unsigned int)&HwLCDC0_BASE,FALSE));
	//LCDC* lcdc1 = (LCDC*)(OALPAtoVA((unsigned int)&HwLCDC1_BASE,FALSE));

	//M2MSCALER* m2mscaler0 = (M2MSCALER*)(OALPAtoVA((unsigned int)&HwM2MSCALER0_BASE,FALSE));
	//M2MSCALER* m2mscaler1 = (M2MSCALER*)(OALPAtoVA((unsigned int)&HwM2MSCALER1_BASE,FALSE));
	
	
	UARTPORTMUX* uartportmux = (UARTPORTMUX*)(OALPAtoVA((unsigned int)&HwUARTPORTMUX_BASE,FALSE));
	 

	//backup iobus state
	p89reg->backup_peri_iobus0 = *(volatile unsigned long*)addr(0x5F5010);
	p89reg->backup_peri_iobus1 = *(volatile unsigned long*)addr(0x5F5014);
	//all peri io bus on
	*(volatile unsigned long*)addr(0x5F5010) = 0xFFFFFFFF;
	*(volatile unsigned long*)addr(0x5F5014) |= 0x7;

	
	

	memcpy(&p89reg->ckc,ckc,sizeof(CKC));
	memcpy(&p89reg->pic,pic,sizeof(PIC));
	memcpy(&p89reg->vic,vic,sizeof(VIC));
	memcpy(&p89reg->timer,timer,sizeof(TIMER));
	memcpy(&p89reg->pmu,pmu,sizeof(PMU));
	memcpy(&p89reg->gpio,gpio,sizeof(GPIO));
	//memcpy(&p89reg->dram,dram,sizeof(DRAM));
	//memcpy(&p89reg->drammx,drammx,sizeof(DRAMMX));
	//memcpy(&p89reg->dramphy,dramphy,sizeof(DRAMPHY));
	//memcpy(&p89reg->drammisc,drammisc,sizeof(DRAMMISC));
	//memcpy(&p89reg->drammembus,drammembus,sizeof(DRAMMEMBUS));
	memcpy(&p89reg->misccorebus,misccorebus,sizeof(MISCCOREBUS));
	memcpy(&p89reg->iobuscfg,iobuscfg,sizeof(IOBUSCFG));
	memcpy(&p89reg->tsadc,tsadc,sizeof(TSADC));
	
//	memcpy(&p89reg->smui2cmaster0,smui2cmaster0,sizeof(SMUI2CMASTER));
//	memcpy(&p89reg->smui2cmaster1,smui2cmaster1,sizeof(SMUI2CMASTER));
//	memcpy(&p89reg->smui2ciclk,smui2ciclk,sizeof(SMUI2CICLK));
	memcpy(&p89reg->ddiconfig,ddiconfig,sizeof(DDICONFIG));
	memcpy(&p89reg->ddicache,ddicache,sizeof(DDICACHE));

	memcpy(&p89reg->usbhost11,usbhost11,sizeof(USBHOST11));
	memcpy(&p89reg->usbhost11cfg,usbhost11cfg,sizeof(USBHOST11CFG));
//	memcpy(&p89reg->usb20otg,usb20otg,sizeof(USB20OTG));
//	memcpy(&p89reg->usbotgconfig,usbotgconfig,sizeof(USBOTGCFG));
//	memcpy(&p89reg->usbphycfg,usbphycfg,sizeof(USBPHYCFG));


	memcpy(&p89reg->rtc,rtc,sizeof(RTC));
	//memcpy(&p89reg->nfc,nfc,sizeof(NFC));
/*
	memcpy(&p89reg->lcdc0,lcdc0,sizeof(LCDC));
	memcpy(&p89reg->lcdc1,lcdc1,sizeof(LCDC));
	memcpy(&p89reg->m2mscaler0,m2mscaler0,sizeof(M2MSCALER));
	memcpy(&p89reg->m2mscaler1,m2mscaler1,sizeof(M2MSCALER));
*/
	
	memcpy(&p89reg->uartportmux,uartportmux,sizeof(UARTPORTMUX));
	
	
	
	IO_ARM_SaveREG(SRAM_ADDR_STANDBY);

//Restore 
	nCount = 100;
	for ( ; nCount > 0 ; nCount --);		// Wait 

	//all peri io bus on
	*(volatile unsigned long*)addr(0x5F5010) = 0xFFFFFFFF;
	*(volatile unsigned long*)addr(0x5F5014) |= 0x7;


	ckc = (CKC*)(OALPAtoVA((unsigned int)&HwCLK_BASE,FALSE)); 
	pic = (PIC*)(OALPAtoVA((unsigned int)&HwPIC_BASE,FALSE)); 
	vic = (VIC*)(OALPAtoVA((unsigned int)&HwVIC_BASE,FALSE)); 
	timer = (TIMER*)(OALPAtoVA((unsigned int)&HwTMR_BASE,FALSE)); 
	pmu = (PMU*)(OALPAtoVA((unsigned int)&HwPMU_BASE,FALSE)); 
	gpio = (GPIO*)(OALPAtoVA((unsigned int)&HwGPIO_BASE,FALSE)); 
//	dram= (DRAM*)(OALPAtoVA((unsigned int)&HwDRAM_BASE,FALSE));
//	drammx= (DRAMMX*)(OALPAtoVA((unsigned int)&HwDRAM_BASE,FALSE));
//	dramphy= (DRAMPHY*)(OALPAtoVA((unsigned int)&HwDRAMPHY_BASE,FALSE));
//	drammisc= (DRAMMISC*)(OALPAtoVA((unsigned int)&HwDRAMMISC_BASE,FALSE));
//	drammembus= (DRAMMEMBUS*)(OALPAtoVA((unsigned int)&HwDRAMMEMBUS_BASE,FALSE));
	misccorebus= (MISCCOREBUS*)(OALPAtoVA((unsigned int)&HwCORECFG_BASE,FALSE));
	iobuscfg= (IOBUSCFG*)(OALPAtoVA((unsigned int)&HwIOBUSCFG_BASE,FALSE));
	tsadc = (TSADC*)(OALPAtoVA((unsigned int)&HwTSADC_BASE,FALSE));
	
//	smui2cmaster0 = (SMUI2CMASTER*)(OALPAtoVA((unsigned int)&HwSMU_I2CMASTER0_BASE,FALSE));
//	smui2cmaster1 = (SMUI2CMASTER*)(OALPAtoVA((unsigned int)&HwSMU_I2CMASTER1_BASE,FALSE));
//	smui2ciclk = (SMUI2CICLK*)(OALPAtoVA((unsigned int)&HwSMU_I2CICLK_BASE,FALSE));
	ddiconfig = (DDICONFIG*)(OALPAtoVA((unsigned int)&HwDDI_CONFIG_BASE,FALSE));
	ddicache = (DDICACHE*)(OALPAtoVA((unsigned int)&HwDDI_CACHE_BASE,FALSE));
	
	usbhost11 = (USBHOST11*)(OALPAtoVA((unsigned int)&HwUSBHOST_BASE,FALSE));
	usbhost11cfg = (USBHOST11CFG*)(OALPAtoVA((unsigned int)&HwUSBHOSTCFG_BASE,FALSE));
//	usb20otg = (USB20OTG*)(OALPAtoVA((unsigned int)&HwUSB20OTG_BASE,FALSE));
//	usbotgconfig = (USBOTGCFG*)(OALPAtoVA((unsigned int)&HwUSBOTGCFG_BASE,FALSE));
//	usbphycfg = (USBPHYCFG*)(OALPAtoVA((unsigned int)&HwUSBPHYCFG_BASE,FALSE));
	
	rtc = (RTC*)(OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE));
//	nfc = (NFC*)(OALPAtoVA((unsigned int)&HwNFC_BASE,FALSE));
/*
	lcdc0 = (LCDC*)(OALPAtoVA((unsigned int)&HwLCDC0_BASE,FALSE));
	lcdc1 = (LCDC*)(OALPAtoVA((unsigned int)&HwLCDC1_BASE,FALSE));
	m2mscaler0 = (M2MSCALER*)(OALPAtoVA((unsigned int)&HwM2MSCALER0_BASE,FALSE));
	m2mscaler1 = (M2MSCALER*)(OALPAtoVA((unsigned int)&HwM2MSCALER1_BASE,FALSE));
*/
	
	uartportmux = (UARTPORTMUX*)(OALPAtoVA((unsigned int)&HwUARTPORTMUX_BASE,FALSE));




	memcpy(ckc,&p89reg->ckc,sizeof(CKC));
	memcpy(pic,&p89reg->pic,sizeof(PIC));
	memcpy(vic,&p89reg->vic,sizeof(VIC));
	memcpy(timer,&p89reg->timer,sizeof(TIMER));
	memcpy(pmu,&p89reg->pmu,sizeof(PMU));
	memcpy(gpio,&p89reg->gpio,sizeof(GPIO));
	//memcpy(dram,&p89reg->dram,sizeof(DRAM));
	//memcpy(drammx,&p89reg->drammx,sizeof(DRAMMX));
	//memcpy(dramphy,&p89reg->dramphy,sizeof(DRAMPHY));
	//memcpy(drammisc,&p89reg->drammisc,sizeof(DRAMMISC));
	//memcpy(drammembus,&p89reg->drammembus,sizeof(DRAMMEMBUS));
	memcpy(misccorebus,&p89reg->misccorebus,sizeof(MISCCOREBUS));
	memcpy(iobuscfg,&p89reg->iobuscfg,sizeof(IOBUSCFG));
	
	memcpy(tsadc,&p89reg->tsadc,sizeof(TSADC));
		
//	memcpy(smui2cmaster0,&p89reg->smui2cmaster0,sizeof(SMUI2CMASTER));
//	memcpy(smui2cmaster1,&p89reg->smui2cmaster1,sizeof(SMUI2CMASTER));
//	memcpy(smui2ciclk,&p89reg->smui2ciclk,sizeof(SMUI2CICLK));
	memcpy(ddiconfig,&p89reg->ddiconfig,sizeof(DDICONFIG));
	memcpy(ddicache,&p89reg->ddicache,sizeof(DDICACHE));

	memcpy(usbhost11,&p89reg->usbhost11,sizeof(USBHOST11));
	memcpy(usbhost11cfg,&p89reg->usbhost11cfg,sizeof(USBHOST11CFG));
	//memcpy(usb20otg,&p89reg->usb20otg,sizeof(USB20OTG));
	//memcpy(usbotgconfig,&p89reg->usbotgconfig,sizeof(USBOTGCFG));
	//memcpy(usbphycfg,&p89reg->usbphycfg,sizeof(USBPHYCFG));

	memcpy(rtc,&p89reg->rtc,sizeof(RTC));
	//memcpy(nfc,&p89reg->nfc,sizeof(NFC));
/*
	memcpy(lcdc0,&p89reg->lcdc0,sizeof(LCDC));
	memcpy(lcdc1,&p89reg->lcdc1,sizeof(LCDC));
	memcpy(m2mscaler0,&p89reg->m2mscaler0,sizeof(M2MSCALER));
	memcpy(m2mscaler1,&p89reg->m2mscaler1,sizeof(M2MSCALER));
*/
	
	memcpy(uartportmux,&p89reg->uartportmux,sizeof(UARTPORTMUX));


	//all peri io bus restore
	*(volatile unsigned long*)addr(0x5F5010) = p89reg->backup_peri_iobus0;
	*(volatile unsigned long*)addr(0x5F5014) = p89reg->backup_peri_iobus1;
}


/*****************************************************************************
* Function Name : tca_off_copysram()
******************************************************************************/
unsigned int lstack = 0;
volatile static void tca_off_copysram(unsigned int mode)
{
	// Setup Pointer
	volatile unsigned int	*fptr;
	volatile unsigned int	*p;
	int 					i;


	if(mode)	// Suspend Mode
	{
		// Copy Function Contents to SRAM
		#if defined(DRAM_MDDR)
			fptr = (volatile unsigned int*)tca_off_mddrselfrefresh;
		#else
			fptr = (volatile unsigned int*)tca_off_ddr2selfrefresh;
		#endif
		p = (volatile unsigned int*)SRAM_ADDR_STANDBY;
		
		for (i = 0;i < (SRAM_FUNC_SIZE+0x100);i++)
		{
			*p = *fptr;
			p++;
			fptr++;
		}
		
		while(--i);
			

		*(volatile unsigned long *)(SUS_DRAM_VALID1_VADDR) = PWRCTL_DRAMMASK1;
		*(volatile unsigned long *)(SUS_DRAM_VALID2_VADDR) = PWRCTL_DRAMMASK2;
		tca_off_suspend();
	}
	else		// Sleep Mode
	{
		// Copy Function Contents to SRAM
		#if defined(DRAM_MDDR)
			fptr = (volatile unsigned int*)tca_off_mddrsleep;
		#else
			fptr = (volatile unsigned int*)tca_off_ddr2sleep;
		#endif
		
		lpSelfRefresh = (lpfunc)(SRAM_ADDR_STANDBY);
		
		p = (volatile unsigned int*)SRAM_ADDR_STANDBY;
		
		for (i = 0;i < (SRAM_FUNC_SIZE+0x100);i++)
		{
			*p = *fptr;
			p++;
			fptr++;
		}
		
		while(--i);
		
		// Jump to Function Start Point
		lstack = arm_changestack();
		lpSelfRefresh();
		arm_restorestack(lstack);
	}
}

volatile void tca_off_setgpiodefualt(unsigned int gpiovaddress)
{
	PGPIO pGPIO = (PGPIO)gpiovaddress;
	
	//GPC
	
	pGPIO->	GPCDAT= 0x0000000;					//   0x080  R/W  0x00000000  GPC Data Register 
	pGPIO->	GPCEN= 0xFFFFFFFF;					//   0x084  R/W  0x00000000  GPC Output Enable Register 

	//pGPIO->GPCPD1 &= ~Hw6; //pull - up remove
	//pGPIO->GPCPD1 &= ~Hw7; //pull - down remove
	

	pGPIO->GPCPD0 = 0; //pull - up 
	pGPIO->GPCPD1 = 0; //pull - up 

	pGPIO->	GPCFN0= 0x00000000;					//   0x0A4  W  0x00000000  Port Configuration on GPC Output Data 
	pGPIO->	GPCFN1= 0x00000000;					//   0x0A8  W  0x00000000  Port Configuration on GPC Output Data 
	pGPIO->	GPCFN2= 0x00000000;					//   0x0AC  W  0x00000000  Port Configuration on GPC Output Data 
	pGPIO->	GPCFN3= 0x00000000;					//   0x0B0  W  0x00000000  Port Configuration on GPC Output Data 





//GPD
	pGPIO->	GPDDAT= 0x00000000;					//   0x0C0  R/W  0x00000000  GPD Data Register 
	pGPIO->	GPDEN= 0x00000000;					//   0x0C4  R/W  0x00000000  GPD Output Enable Register 
	pGPIO->	GPDFN0= 0x00000000;					//   0x0E4  W  0x00000000  Port Configuration on GPD Output Data 
	pGPIO->	GPDFN1= 0x00000000;					//   0x0E8  W  0x00000000  Port Configuration on GPD Output Data 
	pGPIO->	GPDFN2= 0x00000000;					//   0x0EC  W  0x00000000  Port Configuration on GPD Output Data 
	pGPIO->	GPDFN3= 0x00000000;					//   0x0F0  W  0x00000000  Port Configuration on GPD Output Data 
//GPE
	pGPIO->	GPEDAT= 0x00000000;					//   0x100  R/W  0x00000000  GPE Data Register 
	pGPIO->	GPEEN= 0x0F000000;					//   0x104  R/W  0x00000000  GPE Output Enable Register 
	pGPIO->	GPEFN0= 0x00000000;					//   0x124  W  0x00000000  Port Configuration on GPE Output Data 
	pGPIO->	GPEFN1= 0x00000000;					//   0x128  W  0x00000000  Port Configuration on GPE Output Data 
	pGPIO->	GPEFN2= 0x00000000;					//   0x12C  W  0x00000000  Port Configuration on GPE Output Data 
	pGPIO->	GPEFN3= 0x00000000;					//   0x130  W  0x00000000  Port Configuration on GPE Output Data 
//GPF
	pGPIO->	GPFDAT= 0x00000000;					//   0x140  R/W  0x00000000  GPF Data Register 
	pGPIO->	GPFEN= 0xffffffff;					//   0x144  R/W  0x00000000  GPF Output Enable Register 
	pGPIO->	GPFFN0= 0x00000000;					//   0x164  W  0x00000000  Port Configuration on GPF Output Data 
	pGPIO->	GPFFN1= 0x00000000;					//   0x168  W  0x00000000  Port Configuration on GP Output Data 
	pGPIO->	GPFFN2= 0x00000000;					//   0x16C  W  0x00000000  Port Configuration on GPF Output Data 
	pGPIO->	GPFFN3= 0x00000000;					//   0x170  W  0x00000000  Port Configuration on GPF Output Data 
//EXTEND
	pGPIO->	EINTSEL0= 0x00000000;				//   0x184  R/W  0x00000000  External Interrupt Select Register 01
	pGPIO->	EINTSEL1= 0x00000000;				//   0x188  R/W  0x00000000  External Interrupt Select Register 1 
	pGPIO->	EINTSEL2= 0x00000000;				//   0x18C  R/W  0x00000000  External Interrupt Select Register 2 
	pGPIO->	MON= 0x00000000;					//   0x190  R/W  0x00000000  System Monitor Enable Register   
	pGPIO->	ECID0= 0x00000000;					//   0x194  R/W  0x00000000  CID output Register 
	pGPIO->	ECID1= 0x00000000;					//   0x198  R  -  CID serial input Register 
	pGPIO->	ECID2= 0x00000000;					//   0x19C  R  -  CID parallel input 0 Register 
	pGPIO->	ECID3= 0x00000000;	
}

volatile void tca_off_gpiobackup(unsigned int gpiovaddress)
{
	int i = 0;
	PGPIO pGPIO = (PGPIO)gpiovaddress;

	for(i = 0 ; i < GPIOSIZE-8 ; i++ ){
		switch(i%16){
			case 2:
			case 3:
			case 4:
			case 13:
			case 14:
			case 15:
				break;
			default:
				bkreg[i] = *((volatile unsigned int*)(gpiovaddress+4*i));
			break;
		}
	}

	bkreg[GPIOSIZE-8] = pGPIO->EINTSEL0;
	bkreg[GPIOSIZE-8+1] = pGPIO->EINTSEL1;
	bkreg[GPIOSIZE-8+2] = pGPIO->EINTSEL2;
	bkreg[GPIOSIZE-8+3] = pGPIO->MON;
	bkreg[GPIOSIZE-8+4] = pGPIO->ECID0;

	


	tca_off_setgpiodefualt(gpiovaddress);

}

volatile void tca_off_gpiorestore(unsigned int gpiovaddress)
{
	int i = 0;
	PGPIO pGPIO = (PGPIO)gpiovaddress;
	
	
	for(i = 0 ; i < GPIOSIZE-8 ; i++ ){
		switch(i%16){
			case 2:
			case 3:
			case 4:
			case 13:
			case 14:
			case 15:
				break;
			default:
				*((volatile unsigned int*)(gpiovaddress+4*i)) = bkreg[i];
			break;
		}
	}

	
	pGPIO->EINTSEL0 = bkreg[GPIOSIZE-8];
	pGPIO->EINTSEL1 = bkreg[GPIOSIZE-8+1];
	pGPIO->EINTSEL2 = bkreg[GPIOSIZE-8+2];
	pGPIO->MON = bkreg[GPIOSIZE-8+3];
	pGPIO->ECID0 = bkreg[GPIOSIZE-8+4];

}


/*****************************************************************************
* Function Name : tca_off_entershutdown()
******************************************************************************/
volatile void tca_off_entersuspend(unsigned int gpiovaddress)
{
	unsigned int temp; 

	*(volatile unsigned long *)(KSUS_DRAM_START_ADDR) = SUS_DRAM_ARMREG_VADDR;
	*(volatile unsigned long *)(BSUS_DRAM_START_ADDR) = SUS_DRAM_ARMREG_PADDR;

	
	
	//go to sleep
	temp = *(volatile unsigned long *)addr(0x400000); // pll0 == corebus
	temp = *(volatile unsigned long *)addr(0x102024); // GPIOAFN == corebus
	temp = *(volatile unsigned long *)addr(0x102004); // GPIOAEN == corebus
	temp = *(volatile unsigned long *)addr(0x102000); // GPIOADAT == corebus

	temp = *(volatile unsigned long *)addr(0x5F5010); // iobus
	temp = *(volatile unsigned long *)addr(0x5F5014); // iobus
	
	tca_off_copysram(1);
	
}


/*****************************************************************************
* Function Name : tca_off_entersleep()
******************************************************************************/
volatile void tca_off_entersleep(unsigned int gpiovaddress)
{
	unsigned int temp; 
	tca_off_gpiobackup(gpiovaddress);

	//go to sleep
	
	temp = *(volatile unsigned long *)addr(0x102024); // GPIOAFN == corebus
	temp = *(volatile unsigned long *)addr(0x102004); //
	temp = *(volatile unsigned long *)addr(0x230000);
	temp = *(volatile unsigned long *)addr(0x404018);
	temp = *(volatile unsigned long *)addr(0x400044);

	temp =	*(volatile unsigned long *)addr(0x400000);
	temp =	*(volatile unsigned long *)addr(0x400004);
	temp =	*(volatile unsigned long *)addr(0x400008);
	temp =	*(volatile unsigned long *)addr(0x40000c);
	temp =	*(volatile unsigned long *)addr(0x400010);
	temp =	*(volatile unsigned long *)addr(0x400014);
	temp =	*(volatile unsigned long *)addr(0x400018);
	temp =	*(volatile unsigned long *)addr(0x40001c);

	temp =	*(volatile unsigned long *)addr(0x240050);
	temp =	*(volatile unsigned long *)addr(0x30302C);
	temp =	*(volatile unsigned long *)addr(0x304400);
	temp =	*(volatile unsigned long *)addr(0x304404);
	temp =	*(volatile unsigned long *)addr(0x304428);

	tca_off_copysram(0);


	tca_off_gpiorestore(gpiovaddress);
		
}


