
#if defined(_LINUX_)
#include "../usb/usb_manager.h"
extern int fwdn_connect;
#elif defined(_WINCE_)
#include "..\USB\usb_manager.h"
int fwdn_connect = 0;
#endif


extern char FirmwareVersion[];

void FWDN_Check(void)
{
#if 1 //eugeun_check
	if ( FirmwareVersion[3] != '?') 
		return;
	else /* connect FWDN */
#endif	
		fwdn_connect = 1;

	USB_DEVICE_Init();

	for(;;)
	{
		USB_DEVICE_Isr();
		USB_DEVICE_Run();
	}
}
