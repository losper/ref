/****************************************************************************
 *   FileName    : Fwdn_drv_v2.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

/****************************************************************************

  Revision History

 ****************************************************************************

 ****************************************************************************/
#if defined(FWDN_V6)

#if defined(_LINUX_)
#include "common.h"
#endif

#if defined(_LINUX_) || defined(_WINCE_)
//#include "IO_TCC7XX.h"
//#include "globals.h"
#include "fwdn_drv_v3.h"
#include "fwupgrade.h"
#include "Disk.h"
#include "TC_File.h"
#include "FSAPP.h"
#include "nand_drv.h"

#if defined (NKUSE)
	#include "windows.h"
	#include "stdlib.h"
#endif
#endif

#define	byte_of(X)					( *(volatile unsigned char *)((X)) )

#if defined(NKUSE)
#ifdef NAND_INCLUDE
const unsigned int DISK_DefaultDriveType = DISK_DEVICE_NAND;
#endif
#ifdef TRIFLASH_INCLUDE
const unsigned int DISK_DefaultDriveType = DISK_DEVICE_TRIFLASH;
#endif
#endif

#if defined(_WINCE_)
#pragma pack(push, 1)
#endif

typedef struct __PARTITION_INFO_T
{
	unsigned int	size;
	unsigned int	bFormat;
	char			volumeLabel[12];
#if defined(_LINUX_)
} __attribute__((packed)) PARTITION_INFO_T;
#else
} PARTITION_INFO_T;
#endif

typedef struct  __MultiPartitionInfo
{
	unsigned int		partitionNum;
	PARTITION_INFO_T	partition[4];
#if defined(_LINUX_)
} __attribute__((packed)) MULTI_PARTITION_INFO;
#else
} MULTI_PARTITION_INFO;
#endif

#if defined(_WINCE_)
#pragma pack(pop)
#endif


//==============================================================
//
//		Global Variables
//
//==============================================================
unsigned char gFWDN_FirmwareDevice		=
	#ifdef FWDN_ONLY
		0
	#else
		#ifdef SFLASH_INCLUDE
			FWDN_DRV_TARGET_SFLASH
		#elif defined(NAND_INCLUDE)
			FWDN_DRV_TARGET_NAND
		#elif defined(TRIFLASH_INCLUDE)
			FWDN_DRV_TARGET_TRIFLASH
		#elif defined(HDD_INCLUDE)
			FWDN_DRV_TARGET_NOR
		#else
		0//	#error	there is no device to store F/W image.
		#endif
	#endif
;
unsigned char gFWDN_SerialNumberDevice	=
	#ifdef FWDN_ONLY
		0
	#else
		#ifdef SFLASH_INCLUDE
			FWDN_DRV_TARGET_SFLASH
		#elif defined(NAND_INCLUDE)
			FWDN_DRV_TARGET_NAND
		#elif defined(TRIFLASH_INCLUDE)
			FWDN_DRV_TARGET_TRIFLASH
		#elif defined(HDD_INCLUDE)
			FWDN_DRV_TARGET_HDD
		#else
		0//	#error	there is no device to store F/W image.
		#endif
	#endif
;
unsigned char								gFWDN_SelectedDisk;
unsigned int								gImagePosition;
unsigned int								ResetHandler_ptr;
unsigned int								g_uiFWDN_OverWriteSNFlag;
unsigned int								g_uiFWDN_WriteSNFlag;
unsigned int								gFWDN_DRV_SDCFG=0;
unsigned int								gFWDN_DRV_ErrorCode;

FWDN_DEVICE_INFORMATION						FWDN_DeviceInformation;
NAND_HIDDEN_INFO							gNAND_HIDDEN_INFO[2];
NAND_DEVICE_INFO							gNAND_DEVICE_INFO;
fpFWDN_DRV_FirmwareWrite_ReadFromHost		gfFWDN_DRV_FirmwareWrite_ReadFromHost;
MULTI_PARTITION_INFO						sMultiPartInfo;

#define FWDN_BUF_SIZE		(64*1024)			// It should be larger then 2048 + 512

#ifdef _LINUX_
static unsigned char	gFWDN_Buf[FWDN_BUF_SIZE]__attribute__((aligned(8)));
static unsigned char	gFWDN_VerifyBuf[FWDN_BUF_SIZE]__attribute__((aligned(8)));
#else
static unsigned char	gFWDN_Buf[FWDN_BUF_SIZE];
static unsigned char	gFWDN_VerifyBuf[FWDN_BUF_SIZE];
#endif


//==============================================================
//
//		External Variables
//
//==============================================================
//extern unsigned long				ResetHandler;
extern unsigned long				_start;
extern unsigned long				FirmwareSize;

extern unsigned long				ImageRwBase;

extern char							FirmwareVersion[];

extern unsigned int					gMAX_ROMSIZE;
//extern unsigned						CRC32_TABLE[];
//==============================================================
//
//		External Functionss
//
//==============================================================

void initSourcePosition(void) 
{
#if defined (NKUSE)
#else
	//ResetHandler_ptr	= (unsigned int ) & ResetHandler;
	ResetHandler_ptr	= (unsigned int ) &_start;
	gImagePosition = ResetHandler_ptr;
#endif
}

static unsigned char FWDN_DRV_FWDNDISK_to_DISK(unsigned char fwdnDisk)
{
	unsigned char disk = MAX_DEVICE_NUM;
	switch(fwdnDisk)
	{
		case FWDN_DISK_HDD:
			disk = DISK_DEVICE_HDD;
			break;
		case FWDN_DISK_MMC:
			disk = DISK_DEVICE_MMC;
			break;
		case FWDN_DISK_UHP:
			disk = DISK_DEVICE_UHP;
			break;
		case FWDN_DISK_NAND:
			disk = DISK_DEVICE_NAND;
			break;
		case FWDN_DISK_TRIFLASH:
			disk = DISK_DEVICE_TRIFLASH;
			break;
	}
	return disk;
}

static unsigned char FWDN_DRV_DISK_to_FWDNDISK(unsigned char disk)
{
	unsigned char fwdnDisk = FWDN_DISK_NONE;
	switch(disk)
	{
		case DISK_DEVICE_HDD:
			fwdnDisk = FWDN_DISK_HDD;
			break;
		case DISK_DEVICE_MMC:
			fwdnDisk = FWDN_DISK_MMC;
			break;
		case DISK_DEVICE_UHP:
			fwdnDisk = FWDN_DISK_UHP;
			break;
		case DISK_DEVICE_NAND:
			fwdnDisk = FWDN_DISK_NAND;
			break;
		case DISK_DEVICE_TRIFLASH:
			fwdnDisk = FWDN_DISK_TRIFLASH;
			break;
	}
	return fwdnDisk;
}

void FWDN_DRV_SaveSdCfg(unsigned int sdCfg)
{
	gFWDN_DRV_SDCFG = sdCfg;
}

unsigned int FWDN_DRV_GetSdCfg(void)
{
	return gFWDN_DRV_SDCFG;
}

pFWDN_DEVICE_INFORMATION FWDN_DRV_GetDeviceInfo(void)
{
#if defined (NKUSE)
#else
	unsigned int res;

	switch(gFWDN_SerialNumberDevice)
	{
		#ifndef WITHOUT_FILESYSTEM
		#ifdef NAND_INCLUDE
		case FWDN_DRV_TARGET_NAND:
			FwdnGetNandSerial();
			//res	= FWDN_DISK_NAND;
			break;
		#endif
		#ifdef 	TRIFLASH_INCLUDE
		case FWDN_DRV_TARGET_TRIFLASH:
			FwdnGetTriflashSerial();
			//res	= FWDN_DISK_TRIFLASH;
			break;
		#endif
		#endif //WITHOUT_FILESYSTEM

		#ifdef HDD_INCLUDE
		case FWDN_DRV_TARGET_HDD:
			FwdnGetNorSerial();
			//res	= FWDN_DISK_HDD;
			break;
		#endif
		#ifdef SFLASH_INCLUDE
		case FWDN_DRV_TARGET_SFLASH:
			FwdnGetSFlashSerial();
			//res	= FWDN_DISK_NONE;
			break;
		#endif
	}

	FWDN_DeviceInformation.DefaultDiskType = FWDN_DRV_DISK_to_FWDNDISK(DISK_DefaultDriveType);
	res	= ((unsigned int)FWDN_DRV_GetDeviceInfo) & 0xF0000000;
	//if (FWDN_DeviceInformation.DefaultDiskType != FWDN_DISK_NONE)
	//{
	//	#ifndef WITHOUT_FILESYSTEM
	//		DISK_Ioctl( DISK_DefaultDriveType, DEV_GET_HIDDEN_SIZE, (void *) &res);
	//		FWDN_DeviceInformation.DevHiddenSize	=	res;
	//	#endif
	//}
	//else
	//	FWDN_DeviceInformation.DevHiddenSize	=	-1;

#endif
	return &FWDN_DeviceInformation;
}

int	FWDN_DRV_SerialNumberWrite(unsigned char *serial, unsigned int overwrite)
{
	int	res	= -1;

	#ifdef FWDN_ONLY
		if (overwrite)
			gFWDN_SerialNumberDevice	= overwrite;
		else
			return TRUE;
	#endif

	#ifndef WITHOUT_FILESYSTEM
		TC_SyncDrives(-1, 1);	// clean & flush entire cache
	#endif

	switch (gFWDN_SerialNumberDevice) {
		#ifndef WITHOUT_FILESYSTEM
			#ifdef NAND_INCLUDE
			case FWDN_DRV_TARGET_NAND:
				res = FwdnSetNandSerial( serial, overwrite);
				break;
			#endif
			#ifdef TRIFLASH_INCLUDE
			case FWDN_DRV_TARGET_TRIFLASH:
				res = FwdnSetTriflashSerial( serial, overwrite);
				break;
			#endif
		#endif

		#ifdef HDD_INCLUDE
		case FWDN_DRV_TARGET_HDD:
			res = FwdnSetNorSerial( serial, overwrite);
			break;
		#endif
		#ifdef SFLASH_INCLUDE
		case FWDN_DRV_TARGET_SFLASH:
			res = FwdnSetSFlashSerial( serial, overwrite);
			break;
		#endif
	}

	if ( res == 0)
		return TRUE;
	else
		return FALSE;
}

int FWDN_DRV_FirmwareWrite(unsigned int fwSize, unsigned int TargetMemType, fpFWDN_DRV_FirmwareWrite_ReadFromHost fFWDN_DRV_FirmwareWrite_ReadFromHost)
{
	gfFWDN_DRV_FirmwareWrite_ReadFromHost = fFWDN_DRV_FirmwareWrite_ReadFromHost;

	#ifndef WITHOUT_FILESYSTEM
		TC_SyncDrives(-1, 1);	// clean & flush entire cache
	#endif
	switch (gFWDN_FirmwareDevice)
	{
		#ifndef WITHOUT_FILESYSTEM
		#ifdef NAND_INCLUDE
		case FWDN_DRV_TARGET_NAND:
			return 	FwdnWriteNandFirmware(fwSize);
		#endif
		#ifdef TRIFLASH_INCLUDE
		case FWDN_DRV_TARGET_TRIFLASH:
			return	FwdnWriteTriflashFirmware(fwSize);
		#endif
		#endif //WITHOUT_FILESYSTEM

		#ifdef HDD_INCLUDE
		case FWDN_DRV_TARGET_HDD:
		case FWDN_DRV_TARGET_NOR:
			return	FwdnWriteNorFlashFirmware(fwSize);
		#endif

		#ifdef SFLASH_INCLUDE
		case FWDN_DRV_TARGET_SFLASH:
			gMAX_ROMSIZE	= 0x400000;
			return	FwdnWriteSFlashFirmware(0, (unsigned)&FWDN_DRV_FirmwareWrite, fwSize);
		#endif
	}

	return	0;
}

int FWDN_DRV_FirmwareWrite_Read(unsigned char *buff, unsigned int size, unsigned int percent)
{
	int					res;
	unsigned int		readSize;
	//unsigned int		ImageDataBase;
	unsigned int		ImageAddr;

	readSize		= 0;
	//ImageDataBase	= ImageRwBase;
	ImageAddr		= gImagePosition - ResetHandler_ptr;

	//if( ImageAddr < ImageDataBase )
	//{
	//	if( (ImageAddr+size) <= ImageDataBase )
	//		readSize = size;
	//	else
	//		readSize = ImageDataBase - ImageAddr;
	//
	//	memcpy(buff, (void *)gImagePosition, readSize);
	//	gImagePosition += readSize;
	//	size -= readSize;
	//}

	ImageAddr		= gImagePosition - ResetHandler_ptr;
	res = (*gfFWDN_DRV_FirmwareWrite_ReadFromHost)( (unsigned char *)((unsigned int)buff+readSize), size, ImageAddr, percent);
	if ( res < 0)
		return res;
	gImagePosition += size;
	readSize += size;

	return readSize;
}

void FWDN_DRV_DISK_Select(unsigned char fwdnDiskType)
{
	if( fwdnDiskType == FWDN_DISK_NONE )
		gFWDN_SelectedDisk = FWDN_DRV_DISK_to_FWDNDISK(DISK_DefaultDriveType);
	else
		gFWDN_SelectedDisk = fwdnDiskType;
}

#ifdef NAND_INCLUDE
extern void NAND_SetExtPartitionInfoLoagFlag( unsigned char On_Off );
#endif
int FWDN_DRV_DISK_Init(TNFTL_CALLBACK_HANDLER pCallBackHandler, unsigned int stage, void *pInfo, unsigned short infoSize)
{
#ifndef WITHOUT_FILESYSTEM
#if defined (NKUSE)
#else

#ifdef TNFTL_V7_INCLUDE
	unsigned int	*pExtPartition;
#endif
	if ( gFWDN_SelectedDisk == FWDN_DISK_NAND )
	{
	#ifdef NAND_INCLUDE
		//stage range ( -1, 0, 1, 2 )
		if( stage == (unsigned int)-1 )
		{
			TNFTL_SetCallBackHandler( pCallBackHandler );
			//Low-Level Format
			NAND_LowLevelFormat(1);
			stage = 0;
		}
		else if( stage == (unsigned int)-2 )
		{
			TNFTL_SetCallBackHandler( pCallBackHandler );
			//Low-Level Format
			NAND_LowLevelFormat(2);;
			stage = 0;
		}
		else if ( stage == 2 )
		{
			TNFTL_SetCallBackHandler( pCallBackHandler );
			//Total-Image Dump
			NAND_LowLevelFormat(3);
			stage = 0;
		}

		if( stage == 0 )
		{
			TNFTL_SetCallBackHandler( pCallBackHandler );
			NAND_Init();

			if ( TNFTL_CheckIsExistBMP( gNAND_DrvInfo[0].NFTLDrvInfo ) != SUCCESS )	// NAND�� ������ ����ϴ� BMP�� �ִ��� Ȯ��
			{
				// BMP�� ���� ��� RomFile�� Size�� Init
				NAND_SetFlagOfChangeAreaSize( ENABLE );
				if( DISK_Ioctl( DISK_DEVICE_NAND, DEV_INITIALIZE, NULL ) != SUCCESS )
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_IOCTRL_DEV_INITIALIZE);
					return FALSE;
				}
			}
			else
			{
				// BMP�� �ִ� ��� NAND�� Hidden, Multi Hidden�� Seeting�� �״�� ����.
				NAND_SetFlagOfChangeAreaSize( DISABLE );
				if( DISK_Ioctl( DISK_DEVICE_NAND, DEV_INITIALIZE, NULL ) != SUCCESS )
				{
					if ( gNAND_DrvInfo[0].NFTLDrvInfo->DrvReturnValue != ERR_TNFTL_OVERSIZE_MULTIHIDDEN_NUM )
					{
						FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_IOCTRL_DEV_INITIALIZE);
						return FALSE;
					}
				}
			}
		}
		else if( stage == 1 )
		{
			void * nandHiddenInfo = pInfo;
#ifdef TNFTL_V7_INCLUDE
			pExtPartition = pInfo;

			
			if( nandHiddenInfo == NULL /*|| infoSize != sizeof(TNFTL_EXT_PART_INFO) */)
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_WRONG_PARAMETER);
				return FALSE;
			}

			// Hidden Area Size
			gTNFTL_ExtPartitionInfo[0].ExtPartitionSize[0] = pExtPartition[0];

			// Multi-Hidden Num
			gTNFTL_ExtPartitionInfo[0].ExtendedPartitionNum = pExtPartition[1] + 1;

			gTNFTL_ExtPartitionInfo[0].ExtPartitionSize[1] = pExtPartition[2];
			gTNFTL_ExtPartitionInfo[0].ExtPartitionSize[2] = pExtPartition[3];
			gTNFTL_ExtPartitionInfo[0].ExtPartitionSize[3] = pExtPartition[4];

			gTNFTL_ExtPartitionInfo[0].ROAreaSize = pExtPartition[10];

//			memcpy( &gTNFTL_ExtPartitionInfo, nandHiddenInfo, sizeof(TNFTL_EXT_PART_INFO));

			NAND_SetExtPartitionInfoLoagFlag( ENABLE );
#else
			if( nandHiddenInfo == NULL || infoSize != sizeof(gTNFTL_HiddenInfo) )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_WRONG_PARAMETER);
				return FALSE;
			}
			memcpy( &gTNFTL_HiddenInfo, nandHiddenInfo, sizeof(gTNFTL_HiddenInfo));
			NAND_SetHiddenInfoLoagFlag( ENABLE );
#endif
			NAND_SetFlagOfChangeAreaSize( ENABLE );
			if (DISK_Ioctl(DISK_DEVICE_NAND, DEV_INITIALIZE, NULL) != SUCCESS )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_IOCTRL_DEV_INITIALIZE);
				return FALSE;
			}
		}
		else
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_WRONG_PARAMETER);
			return FALSE;
		}
	#endif
	}
	else
	{
		#ifdef TRIFLASH_INCLUDE
		if(stage == 0)
		{
			if(DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_INITIALIZE, NULL ) < 0 )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_IOCTRL_DEV_INITIALIZE);
				return FALSE;
			}
		}
		else
		{
			if(DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_SET_HIDDEN_SIZE, (void *)pInfo) < 0 )
				return FALSE;
		}
		#endif
	}
#endif	//NKUSE

#endif	//WITHOUT_FILESYSTEM

	return TRUE;
}

int FWDN_DRV_DISK_Read(unsigned int lba, unsigned int size, FXN_FWDN_DRV_SendToHost fxnFwdnDrvSendToHost)
{
#if defined (NKUSE)
	return FALSE;
#else
	unsigned char *sendBuf = gFWDN_Buf;
	unsigned int res = TRUE, sendSize, nSector;

	while(size)
	{
		if( size > FWDN_BUF_SIZE )
			sendSize = FWDN_BUF_SIZE;
		else
			sendSize = size;
		nSector = (sendSize+511)>>9;

		if( gFWDN_SelectedDisk == FWDN_DISK_NAND )
		{
			if( DISK_ReadSector(DISK_DEVICE_NAND, 0, lba, nSector, sendBuf) != 0 )
				res = FALSE;
			lba += nSector;
		}
		else
		{
			res = FALSE;
		}

		fxnFwdnDrvSendToHost(sendBuf,sendSize);
		size -= sendSize;
	}
	return res;
#endif //NKUSE
}

void FWDN_DRV_DISK_InfoRead(void *pDiskInfo, unsigned char *pSize)
{
#if defined (NKUSE)
#else

	*pSize = 0;

#ifdef NAND_INCLUDE
	if( gFWDN_SelectedDisk == FWDN_DISK_NAND )
	{
		NAND_DISK_INFO_T nandDiskInfo;
		unsigned int i,NBAreaSize, dataAreaSize, hiddenAreaSize, multiHiddenAreaSize;
		unsigned long int nSysBlkSize,nMHD;

		NBAreaSize = gMAX_ROMSIZE * 2 >> 20;													//NBArea Size = R/O Area

#if defined( TNFTL_V6_INCLUDE )
		dataAreaSize = (unsigned int)(gNAND_DrvInfo[0].NFTLDrvInfo->DTArea.TotalSectorSize >> 11);			//Data Area Size
		hiddenAreaSize = (unsigned int)(gNAND_DrvInfo[0].NFTLDrvInfo->HDArea.TotalSectorSize >> 11);		//Hidden Area Size

		multiHiddenAreaSize = 0;
		nMHD = gNAND_DrvInfo[0].NFTLDrvInfo->MultiHiddendNums;
		for ( i = 0 ; i < nMHD ; ++i )
			multiHiddenAreaSize += (unsigned int)(gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[i].TotalSectorSize >> 11);		// Multi Hidden Size

		// Multi Hidden System Info Size
		nSysBlkSize = ( gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].WCacheNums * 4 ) + 2 ;
		nSysBlkSize = (( nSysBlkSize << gNAND_DrvInfo[0].NFTLDrvInfo->ShiftPpB ) * gNAND_DrvInfo[0].NFTLDrvInfo->PageSize ) >> 20;
#elif defined( TNFTL_V7_INCLUDE )
		dataAreaSize = (unsigned int)(gNAND_DrvInfo[0].NFTLDrvInfo->PriPartition.TotalSectorSize >> 11);			//Data Area Size
		hiddenAreaSize = (unsigned int)(gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[0].TotalSectorSize >> 11);		//Hidden Area Size

		multiHiddenAreaSize = 0;
		nMHD = gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo - 1;
		for ( i = 1 ; i < nMHD+1 ; ++i )
			multiHiddenAreaSize += (unsigned int)(gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[i].TotalSectorSize >> 11);		// Multi Hidden Size

		// Multi Hidden System Info Size
		nSysBlkSize = ( gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].WCacheNums * 4 ) + 2 ;
		nSysBlkSize = (( nSysBlkSize << gNAND_DrvInfo[0].NFTLDrvInfo->ShiftPpB ) * gNAND_DrvInfo[0].NFTLDrvInfo->PageSize ) >> 20;
#else
#error
#endif

		nandDiskInfo.bootSize_MB = NBAreaSize;
		nandDiskInfo.totalSize_MB = NBAreaSize+hiddenAreaSize+multiHiddenAreaSize+nSysBlkSize*nMHD+dataAreaSize;
		nandDiskInfo.multiHiddenSystemSize_MB = nSysBlkSize;

		memcpy(pDiskInfo, (void*)&nandDiskInfo, sizeof(NAND_DISK_INFO_T));
		*pSize = sizeof(NAND_DISK_INFO_T);
	}
#endif //NAND_INCLUDE

#ifdef TRIFLASH_INCLUDE
	if(gFWDN_SelectedDisk == FWDN_DISK_TRIFLASH)
	{
		MMC_DISK_INFO_T		triflashDiskInfo;
		int					res;
		
		res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_GET_HIDDEN_SIZE, (void *) &triflashDiskInfo);	
		memcpy(pDiskInfo, (void*)&triflashDiskInfo, sizeof(MMC_DISK_INFO_T));
		*pSize = sizeof(MMC_DISK_INFO_T);
	}
#endif

#endif	//NKUSE
}

int FWDN_DRV_DISK_Write(unsigned int lba, unsigned int size, FXN_FWDN_DRV_ReadFromHost fxnFwdnDrvReadFromHost)
{
#if defined (NKUSE)
	return FALSE;
#else
	unsigned char *receiveBuf = gFWDN_Buf;
	unsigned char *verifyBuf = gFWDN_VerifyBuf;
	unsigned int res = TRUE, receiveSize, nSector;

#ifndef WITHOUT_FILESYSTEM
    TC_SyncDrives(-1, 1);	// clean & flush entire cache
#endif

	while(size)
	{
		if( size > FWDN_BUF_SIZE )
			receiveSize = FWDN_BUF_SIZE;
		else
			receiveSize = size;
		nSector = (receiveSize+511)>>9;

		if( fxnFwdnDrvReadFromHost(receiveBuf, receiveSize) != receiveSize )
			res = FALSE;

		if( gFWDN_SelectedDisk == FWDN_DISK_NAND )
		{
			#ifndef WITHOUT_FILESYSTEM
            if ( res == TRUE )
			{
                if( DISK_WriteSector(DISK_DEVICE_NAND, 0, lba, nSector, receiveBuf) != SUCCESS )
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_WRITE);
					res	= FALSE;
				}
				else if( DISK_ReadSector(DISK_DEVICE_NAND, 0, lba, nSector, verifyBuf) != SUCCESS )
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_READ);
					res	= FALSE;
				}
				else if (memcmp(receiveBuf, verifyBuf, nSector<<9) != 0)
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_COMPARE);
					res	= FALSE;
				}
				lba += nSector;
            }
			#endif
		}
		else
		{
			res = FALSE;
		}

		size -= receiveSize;
	}
	return res;
#endif //NKUSE
}

void FWDN_DRV_DISK_Hidden_InfoRead(void *pInfo, unsigned char *pSize)
{
#ifdef NKUSE
#else
	if( gFWDN_SelectedDisk == FWDN_DISK_NAND )
	{
	#ifdef NAND_INCLUDE
		#ifndef WITHOUT_FILESYSTEM
		unsigned int		i;

#ifdef TNFTL_V7_INCLUDE
		// Rom File Hidden Info
		gNAND_HIDDEN_INFO[0].HiddenPageSize		= gTNFTL_ExtPartitionInfo[0].ExtPartitionSize[0];//gTNFTL_HiddenInfo[0].HiddenPageSize;
		gNAND_HIDDEN_INFO[0].MultiHiddenAreaNum = gTNFTL_ExtPartitionInfo[0].ExtendedPartitionNum - 1;//gTNFTL_HiddenInfo[0].MultiHiddenAreaNum;
		for ( i = 0; i < gNAND_HIDDEN_INFO[0].MultiHiddenAreaNum; ++i )
			gNAND_HIDDEN_INFO[0].MultiHiddenSize[i] = gTNFTL_ExtPartitionInfo[0].ExtPartitionSize[i+1];

		// Current NAND Hidden Info
		gNAND_HIDDEN_INFO[1].HiddenPageSize		= gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[0].TotalSectorSize;

		if ( gNAND_DrvInfo[0].NFTLDrvInfo->DrvReturnValue == ERR_TNFTL_OVERSIZE_MULTIHIDDEN_NUM )
		{
			gNAND_HIDDEN_INFO[1].MultiHiddenAreaNum = 0xFFFFFFFF;
		}
		else
		{
			gNAND_HIDDEN_INFO[1].MultiHiddenAreaNum = gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo - 1;
			for ( i = 0; i < gNAND_HIDDEN_INFO[1].MultiHiddenAreaNum; ++i )
				gNAND_HIDDEN_INFO[1].MultiHiddenSize[i] = gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[i+1].TotalSectorSize;
		}

		gNAND_HIDDEN_INFO[1].ROAreaSize = gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaSize >> 20;
#else
		//================================
		// Rom File Hidden Info
		//================================
		gNAND_HIDDEN_INFO[0].HiddenPageSize		= gTNFTL_HiddenInfo[0].HiddenPageSize;
		gNAND_HIDDEN_INFO[0].MultiHiddenAreaNum = gTNFTL_HiddenInfo[0].MultiHiddenAreaNum;
		for ( i = 0; i < gNAND_HIDDEN_INFO[0].MultiHiddenAreaNum; ++i )
			gNAND_HIDDEN_INFO[0].MultiHiddenSize[i] = gTNFTL_HiddenInfo[0].MultiHiddenSize[i];

		gNAND_HIDDEN_INFO[0].ROAreaSize = gTNFTL_HiddenInfo[0].ROAreaSize;
		
		//================================
		// Current NAND Hidden Info
		//================================
		gNAND_HIDDEN_INFO[1].HiddenPageSize		= gNAND_DrvInfo[0].NFTLDrvInfo->HDArea.TotalSectorSize;

		if ( gNAND_DrvInfo[0].NFTLDrvInfo->DrvReturnValue == ERR_TNFTL_OVERSIZE_MULTIHIDDEN_NUM )
		{
			gNAND_HIDDEN_INFO[1].MultiHiddenAreaNum = 0xFFFFFFFF;
		}
		else
		{
			gNAND_HIDDEN_INFO[1].MultiHiddenAreaNum = gNAND_DrvInfo[0].NFTLDrvInfo->MultiHiddendNums;
			for ( i = 0; i < gNAND_HIDDEN_INFO[1].MultiHiddenAreaNum; ++i )
				gNAND_HIDDEN_INFO[1].MultiHiddenSize[i] = gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[i].TotalSectorSize;
		}

		gNAND_HIDDEN_INFO[1].ROAreaSize = gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaSize >> 20;
		#endif
		#endif
		memcpy(pInfo, gNAND_HIDDEN_INFO, sizeof(gNAND_HIDDEN_INFO));
		*pSize = (unsigned char)sizeof(gNAND_HIDDEN_INFO);
	#endif
	}
	else
	{
		#if 0
		unsigned int hiddenPageSize;
		if (gFWDN_SelectedDisk != FWDN_DISK_NONE)
		{
			#ifndef WITHOUT_FILESYSTEM
			DISK_Ioctl( FWDN_DRV_FWDNDISK_to_DISK(gFWDN_SelectedDisk), DEV_GET_HIDDEN_SIZE, (void *) &hiddenPageSize);
			#else
			hiddenPageSize = -1;
			#endif
		}
		else
			hiddenPageSize = -1;
		memcpy(pInfo, &hiddenPageSize, sizeof(hiddenPageSize));
		*pSize = (unsigned char)sizeof(hiddenPageSize);
		#endif
	}
#endif
}

int FWDN_DRV_DISK_Hidden_Clean(void)
{
	int res;
#if defined (NKUSE)
	res= 0;
#else

	#ifndef WITHOUT_FILESYSTEM
		switch (DISK_DefaultDriveType)
		{
			default:
			res = 0;
			#ifdef NAND_INCLUDE
			case DISK_DEVICE_NAND:
				res = FwdnClearNandHiddenArea(0,0);	/*	[1255] */
				res |= NAND_InitDrive(0);
				break;
			#endif
			#ifdef TRIFLASH_INCLUDE
			case DISK_DEVICE_TRIFLASH:
//				res = FwdnClearTriflashHiddenArea();
				break;
			#endif
			#ifdef HDD_INCLUDE
			case DISK_DEVICE_HDD:
				res = FwdnClearHddHiddenArea();
				break;
			#endif
		}
	#else
		res = 0;
	#endif
#endif
	if ( res == 0)
		return TRUE;
	else
		return FALSE;
}

int FWDN_DRV_DISK_Hidden_Write(unsigned int index, unsigned int startpage, unsigned int sizebyte, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData)
{
#if defined (NKUSE)
	return TRUE;
#else
	unsigned char	*readBuf = gFWDN_Buf;
	unsigned char	*verifyBuf = gFWDN_VerifyBuf;

	unsigned int	readBufSize;
	unsigned int	readBytes, remain;
	unsigned short	writenum;
	unsigned int	startpageParam;

	#ifdef SFLASH_INCLUDE
	int				writeskip;
	#endif

	#ifdef FEATURE_CRC
	unsigned int	uCRC32;
	#endif
#if 0
	if (gFWDN_FirmwareDevice == FWDN_DRV_TARGET_SFLASH)
	{
		if (pSFInfo)
			readBufSize	= pSFInfo->ProgramSize;
		else
			readBufSize	= 512 * 16;
	}
	else
#endif
	readBufSize	= FWDN_BUF_SIZE;

	if (readBufSize > sizebyte)
		readBufSize	= sizebyte;

	#ifndef WITHOUT_FILESYSTEM
		TC_SyncDrives(-1, 1);	// clean & flush entire cache
	#endif

	//1 Receive Data and Hidden Write

//printf("    startpage (%d) \n", startpage);

	startpageParam	= startpage;
	remain		= sizebyte;
	while (remain > 0)
	{
		if( remain > readBufSize )
			readBytes = readBufSize;
		else
		{
			memset(readBuf, 0xFF, readBufSize);
			readBytes = remain;
		}

		writenum	= (readBytes + 511) / 512;

		if(fxnFwdnDrvRequestData(readBuf,readBytes)<0)
			return FALSE;

		if (gFWDN_FirmwareDevice == FWDN_DRV_TARGET_SFLASH)
		{
			#ifdef SFLASH_INCLUDE
				if (pSFInfo)
					writeskip	= TCCAPI_SF_ProgramSECTOR(startpage, readBuf);
				startpage	+= readBufSize;
			#endif
		}
		else if(DISK_DefaultDriveType==DISK_DEVICE_NAND && index!=0)
		{
			if( DISK_WriteSector(DISK_DEVICE_NAND_HD, index-1, startpage, writenum, readBuf) != SUCCESS )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_WRITE);
				return FALSE;
			}
			else if( DISK_ReadSector(DISK_DEVICE_NAND_HD, index-1, startpage, writenum, verifyBuf) != SUCCESS )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_READ);
				return FALSE;
			}
			else if( memcmp(readBuf, verifyBuf, readBytes) != 0 )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_COMPARE);
				return FALSE;
			}
			startpage	+= writenum;
		}
		else
		{
			if( DISK_HDWriteSector(DISK_DefaultDriveType, startpage, writenum, readBuf) != SUCCESS )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_WRITE);
				return FALSE;
			}
			else if( DISK_HDReadSector(DISK_DefaultDriveType, startpage, writenum, verifyBuf) != SUCCESS )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_READ);
				return FALSE;
			}
			else if (memcmp(readBuf, verifyBuf, readBytes) != 0)
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_COMPARE);
				return FALSE;
			}
			startpage	+= writenum;
		}

		remain	-= readBytes;
	}

	#ifdef FEATURE_CRC
	//1 Check CRC32
	uCRC32 = 0;
	startpage	= startpageParam;
	remain		= sizebyte;
	while( remain > 0 )
	{
		if( remain > readBufSize )
			readBytes = readBufSize;
		else
		{
			memset(readBuf, 0xFF, readBufSize);
			readBytes = remain;
		}

		writenum	= (readBytes + 511) / 512;
		
		if (gFWDN_FirmwareDevice == VTC_PARAM_TARGET_SFLASH)
		{
		}
		else
		{
			#ifndef WITHOUT_FILESYSTEM
			DISK_HDReadSector(DISK_DefaultDriveType, startpage, writenum, verifyBuf);
			uCRC32 = FWUG_CalcCrc8_Input(verifyBuf, readBytes, uCRC32, CRC32_TABLE);
			startpage	+= writenum;
			#endif
		}
		remain	-= readBytes;
	}
	#endif

#endif

	return TRUE;
}

extern int NAND_MTD_Init( U32* rMTDStBlk, U32* rMTDEdBlk );
extern int NAND_MTD_WritePage( U32 nPageAddr, U8* nPageBuffer );
extern int NAND_MTD_ReadPage( U32 nPageAddr, U8* nPageBuffer );
int FWDN_DRV_DISK_MTD_Write(unsigned int startpage, unsigned int sizebyte, FXN_FWDN_DRV_ReadFromHost fxnFwdnDrvReadFromHost)
{
	unsigned int	i;
	int				res = 0;
	unsigned int	rMTDStBlk, rMTDEdBlk;
	unsigned int	nBlkAddr, nPageAddr;

	unsigned char	*readBuf = gFWDN_Buf;
	unsigned char	*verifyBuf = gFWDN_VerifyBuf;

	unsigned int	readBufSize;
	unsigned int	readBytes, remain;
	unsigned int	startpageParam;

	//#define TEST_BUF

	#ifdef TEST_BUF		/* 09.05.11 */
	unsigned char	*nPageBuffer;
	
	nPageBuffer = 0x40100000;
	if( fxnFwdnDrvReadFromHost(nPageBuffer, sizebyte) != sizebyte )
		res = -1;
	#endif /* TEST_BUG */

	readBufSize	= ( 2048 + 512 );		// 1Block Size	

	res = NAND_MTD_Init( &rMTDStBlk, &rMTDEdBlk );
	if ( res != 0 )
		return FALSE;

	nBlkAddr = rMTDStBlk;

	if (readBufSize > sizebyte)
		readBufSize	= sizebyte;
	
	//1 Receive Data and Hidden Write
	startpageParam	= 0;
	remain			= sizebyte;

	while (remain > 0)
	{
		for ( i = rMTDStBlk; i < rMTDEdBlk; ++i )
		{
			nPageAddr = i << gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;
			res = NAND_IO_EraseBlock( &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0], nPageAddr, INTER_LEAVE_OFF );
			if ( res == SUCCESS )
			{
				rMTDStBlk = i + 1;
				break;
			}
		}

		if( res >= 0 )
		{
			for ( i = 0; i < gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PpB; ++i )
			{
				if( remain > readBufSize )
				{
					readBytes = readBufSize;
				}
				else
				{
					memset(readBuf, 0xFF, readBufSize);
					readBytes = remain;
				}

				#ifdef TEST_BUF		/* 09.05.11 */
				memcpy( readBuf, nPageBuffer, readBytes );
				#else
				//printf("\nRemainByte:%d, readBytes:%d", remain, readBytes);
				if( fxnFwdnDrvReadFromHost(readBuf, readBytes) != readBytes )
					res = -1;
				#endif /* TEST_BUF */

				if( NAND_MTD_WritePage( nPageAddr + i, readBuf ) != SUCCESS )
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_WRITE);
					res = -1;
				}
				else if( NAND_MTD_ReadPage( nPageAddr + i, verifyBuf ) != SUCCESS )
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_READ);
					res = -1;
				}
				else if (memcmp(readBuf, verifyBuf, (2048+32)) != 0)
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_COMPARE);
					res = -1;
				}

				#ifdef TEST_BUF		/* 09.05.11 */
				nPageBuffer += readBytes;
				#endif
				//printf("\n..");
				remain	-= readBytes;
				if ( remain == 0 )
				{
					res = 0;
					goto MTD_WRITE_COMPLETE;
				}
			}
		}
	}

MTD_WRITE_COMPLETE:

	if( res >= 0 )
		return TRUE;
	else
		return FALSE;
}

#ifndef WITHOUT_FILESYSTEM
int FWDN_DRV_DISK_DATA_Partition(void *pMultiPartitionSizeArray, unsigned int length)
{
#if defined (NKUSE)
	return TRUE;
#else
	unsigned int			i;
	unsigned int			sizePartition[4];
	unsigned int			validFAT[4];
	
	memcpy(&sMultiPartInfo, pMultiPartitionSizeArray, length );
	memset(sizePartition, 0x00, 4);
	for(i=0; i<sMultiPartInfo.partitionNum; i++)
	{
		if(i==sMultiPartInfo.partitionNum-1)
			sizePartition[i] = 1;	
		else
			sizePartition[i] = sMultiPartInfo.partition[i].size * (1024 / 512);	// KB -> sector

		if(sMultiPartInfo.partition[i].bFormat == 1)
		{
			validFAT[i] = 1;	
			FSAPP_SetVolumeLabel(i, sMultiPartInfo.partition[i].volumeLabel);
		}
		else
			validFAT[i] = 0;
	}

	if(FSAPP_FormatDrive(DISK_DefaultDriveType, sizePartition, validFAT) > 0)
		return TRUE;
	else
		return FALSE;
#endif
}

int FWDN_DRV_DISK_DATA_Image_Write(unsigned int nPartitionID, unsigned int offset, unsigned int size, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData)
{
	unsigned int lba = offset>>9;
	unsigned char *receiveBuf = gFWDN_Buf;
	unsigned char *verifyBuf = gFWDN_VerifyBuf;
	unsigned int bufSize;

	if(offset&0x1FF)
	{
		FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_WRONG_PARAMETER);
		return FALSE;
	}
	bufSize = (FWDN_BUF_SIZE>>9)<<9;
	while(size&0xFFFFFE00)
	{
		unsigned int packetSize = (size>bufSize)? bufSize : (size&0xFFFFFE00);
		size -= packetSize;
		if(fxnFwdnDrvRequestData(receiveBuf,packetSize)<0)
			return FALSE;

		if(FSAPP_PartitionWrite(DISK_DefaultDriveType,nPartitionID,lba,receiveBuf,packetSize>>9)==0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_WRITE);
			return FALSE;
		}
		if(FSAPP_PartitionRead(DISK_DefaultDriveType,nPartitionID,lba,verifyBuf,packetSize>>9)==0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_READ);
			return FALSE;
		}
		if(memcmp(receiveBuf,verifyBuf,packetSize)!=0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_COMPARE);
			return FALSE;
		}
		lba += packetSize>>9;
	}
	if(size)
	{
		memset(receiveBuf,0xFF,1<<9);
		if(fxnFwdnDrvRequestData(receiveBuf,size)<0)
			return FALSE;
		if(FSAPP_PartitionWrite(DISK_DefaultDriveType,nPartitionID,lba,receiveBuf,1)==0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_WRITE);
			return FALSE;
		}
		if(FSAPP_PartitionRead(DISK_DefaultDriveType,nPartitionID,lba,verifyBuf,1)==0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_READ);
			return FALSE;
		}
		if(memcmp(receiveBuf,verifyBuf,size)!=0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_COMPARE);
			return FALSE;
		}
	}
	return TRUE;
}

int FWDN_DRV_DISK_FS_Mount(unsigned int partID)
{
#if defined (NKUSE)
	return TRUE;
#else
	return Initialize_FileSystem(FWDN_DRV_FWDNDISK_to_DISK(gFWDN_SelectedDisk), (int)partID);
#endif
}

int FWDN_DRV_DISK_FS_Format(unsigned int partID, char *volumeParam)
{
#if defined (NKUSE)
	return TRUE;
#else
	char volume[12];
	memcpy(volume,volumeParam,11);
	volume[11]=0;
	//if(FSAPP_FormatPartition(DISK_DefaultDriveType, partID, (void*)volume)==0)
		return FALSE;

	return TRUE;
#endif
}

/************************************************************************
* FUNCTION                                                                
*			FWDN_DRV_FS_MkDir
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
int FWDN_DRV_DISK_FS_MkDir(unsigned char *name)
{
	int		res;
	res	= TC_Make_Dir((TC_STR8)name, 1);
	
	if((signed)(res)<0)		return FALSE;
	else					return TRUE;
}

/************************************************************************
* FUNCTION                                                                
*			FWDN_DRV_FS_ChDir
*                                                                        
* DESCRIPTION
*
* INPUTS
*
* OUTPUTS
*
*************************************************************************/
int FWDN_DRV_DISK_FS_ChDir(unsigned char *name)
{
	int		res;
	res	= TC_Set_Current_Dir(TC_INTERNAL_DRIVE(0), (TC_STR8)name, 1);
	
	if((signed)(res)<0)		return FALSE;
	else					return TRUE;
}

int FWDN_DRV_DISK_FS_FileWrite(unsigned char *name, unsigned int size, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData)
{
	int					Fd;
	//int					ack;
	unsigned char 		*filebuf = gFWDN_Buf;
	unsigned int		filebuf_size, remain, readSize;
	unsigned char		*verifyFileBuf = gFWDN_VerifyBuf;

	#ifdef FEATURE_CRC
	unsigned int		uCRC32;
	#endif

	filebuf_size		= FWDN_BUF_SIZE;

	//1 1. Receive sample file
	Fd	= TC_Open((char*)name, TC_O_CREAT|TC_O_TRUNC|TC_O_RDWR, TC_A_WRITE, 1);
	if (TC_ISHERR(Fd))
	{
		//LPRINTF("Open failed (%s), -%d\n", name, -Fd);
		return FALSE;
	}else {
		//LPRINTF("Open Success (%s), %d\n", name, Fd);
	}

	remain = size;
	while( remain > 0 )
	{
		if( remain > filebuf_size)
			readSize = filebuf_size;
		else
			readSize = remain;

		if(fxnFwdnDrvRequestData(filebuf,readSize)<0)
			return FALSE;

		if(TC_Write(Fd, filebuf, readSize)==(-1))
		{
			//EdbgOutputDebugString("Writing Fail\n");			//eugeun
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_WRITE);
			return FALSE;
		}
		if(TC_Seek(Fd, -(TC_S32)readSize, TC_SEEK_CUR)<0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_READ);
			return FALSE;
		}
		if (TC_Read(Fd, verifyFileBuf, readSize) != readSize)
		{
			//EdbgOutputDebugString("Reading Fail\n");		//eugeun
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_READ);
			return FALSE;
		}
		if (memcmp(filebuf, verifyFileBuf, readSize) != 0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_DISK_COMPARE);
			//EdbgOutputDebugString("Compare Fail\n");		//eugeun
			return FALSE;
		}

		remain -= readSize;
	}

	#ifdef FEATURE_CRC
	//1 Check CRC32
	uCRC32 = 0;
	remain = size;
	if( res >= 0 )
		res = TC_Seek(Fd, 0, TC_SEEK_SET);
	while( remain > 0 && res >= 0 )
	{
		if( remain > filebuf_size)
			readSize = filebuf_size;
		else
			readSize = remain;
		
		res = TC_Read(Fd, verifyFileBuf, readSize);
		if( res >= 0 )
			uCRC32 = FWUG_CalcCrc8_Input(verifyFileBuf, readSize, uCRC32, CRC32_TABLE);
		remain -= readSize;
	}
	#endif

	TC_Close(Fd);

	return TRUE;
}
#endif

unsigned char FWDN_DRV_DISK_DUMP_InfoRead(unsigned char *pBuf)
{
	unsigned int  i = 0;
	unsigned char length = 0;

	if( gFWDN_SelectedDisk == FWDN_DISK_NAND )
	{
		#ifndef WITHOUT_FILESYSTEM
		length = sizeof(NAND_DEVICE_INFO);
		memset( (void*)&gNAND_DEVICE_INFO, 0xFF, length );
		
		for ( i = 0; i < 6; ++i )
			gNAND_DEVICE_INFO.DevID[i] = gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.DeviceID.Code[i];
		gNAND_DEVICE_INFO.MediaNums	 			= gNAND_DrvInfo[0].NFTLDrvInfo->MediaNums;
		gNAND_DEVICE_INFO.MAX_ROMSize			= gMAX_ROMSIZE;
		gNAND_DEVICE_INFO.ExtendedPartitionNum 	= gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo;
		for ( i = 0; i < gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo; ++i )
			gNAND_DEVICE_INFO.ExtPartitionSize[i] = 4096;
		for ( i = 0; i < 12; ++i )
			gNAND_DEVICE_INFO.ExtPartitionWCacheNum[i] = gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[i].WCacheNums;
		gNAND_DEVICE_INFO.ROAreaSize			= gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaSize;
		gNAND_DEVICE_INFO.PBpV			= gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PBpV;
		gNAND_DEVICE_INFO.PpB				= gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PpB;
		gNAND_DEVICE_INFO.PageSize		= gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PageSize;
		gNAND_DEVICE_INFO.SpareSize		= gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.SpareSize;
		#endif

		memcpy((void*)pBuf, (void*)&gNAND_DEVICE_INFO, length);
	}

	return length;
}

static int FWDN_DRV_NAND_DUMP_BlockRead(unsigned int blockAddrParam, unsigned int nBlockParam, unsigned int mediaIndex, FXN_FWDN_DRV_SendToHost fxnFwdnDrvSendToHost)
{
#ifndef WITHOUT_FILESYSTEM
	#define	FWDN_DRV_BLOCKREAD_BUFFER_SIZE		FWDN_BUF_SIZE
	// nBlockAddr	: Read Block Address
	// nPageAddr	: Page Number Per Block
	// nMediaNum	: Media Num
	// nReadBuffer	: Buffer Pointer
	// �ѹ��� 1���� Physical Page�� Read�Ѵ�.  Data Size = ( Nand PageSize + Nand SpareSize ) Byte

	unsigned char *pUsbBuffer = gFWDN_Buf;
	unsigned int usbBufferIndex;
	unsigned int nandPhyReadSizeInByte;
	unsigned int nPageAddr;
	unsigned int blockAddr;
	unsigned int nBlock;

	nandPhyReadSizeInByte = gNAND_DEVICE_INFO.PageSize + gNAND_DEVICE_INFO.SpareSize;

	//for( mediaNumIndex = 0 ; mediaNumIndex < gNAND_DEVICE_INFO.MediaNums ; mediaNumIndex++ )
	{
		usbBufferIndex = 0;
		nPageAddr = 0;
		blockAddr = blockAddrParam;
		nBlock = nBlockParam;
		
		while( nBlock != 0 )
		{
			while( (usbBufferIndex + nandPhyReadSizeInByte) <= FWDN_DRV_BLOCKREAD_BUFFER_SIZE && nBlock != 0 )
			{
				NAND_PhyReadPage( blockAddr, nPageAddr, mediaIndex, &pUsbBuffer[usbBufferIndex] );
				if( ++nPageAddr >= gNAND_DEVICE_INFO.PpB )
				{
					nPageAddr = 0;
					blockAddr++;
					nBlock--;
				}
				usbBufferIndex += nandPhyReadSizeInByte;
			}

			{
				unsigned int sendSize = usbBufferIndex & 0xFFFFFE00;
				usbBufferIndex = usbBufferIndex&0x1FF;
				fxnFwdnDrvSendToHost( pUsbBuffer, sendSize );
				memmove( pUsbBuffer, &pUsbBuffer[sendSize], usbBufferIndex );
			}
		}

		fxnFwdnDrvSendToHost( pUsbBuffer, usbBufferIndex );
	}
#endif
	
	return TRUE;
}

int FWDN_DRV_DISK_DUMP_BlockRead(unsigned int Param0, unsigned int Param1, unsigned int Param2, FXN_FWDN_DRV_SendToHost fxnFwdnDrvSendToHost)
{
	if( gFWDN_SelectedDisk == FWDN_DISK_NAND )
		return FWDN_DRV_NAND_DUMP_BlockRead(Param0, Param1, Param2, fxnFwdnDrvSendToHost);
	else
		return FALSE;
}

unsigned int FWDN_FNT_SetSN(unsigned char* ucTempData, unsigned int uiSNOffset)
{
	unsigned int		uiVerifyCrc;
	unsigned int		uiTempCrc;

	if (memcmp( &ucTempData[20+uiSNOffset], "ZERO", 4 ) == 0)
	{
		uiVerifyCrc = (ucTempData[uiSNOffset + 16] <<24) ^ ( ucTempData[uiSNOffset + 17] <<16) ^ 
			( ucTempData[uiSNOffset + 18] << 8) ^ ( ucTempData[uiSNOffset + 19]); 
		uiTempCrc = FWUG_CalcCrc8((uiSNOffset + ucTempData), 16, CRC32_TABLE);

		if ( ( uiTempCrc == uiVerifyCrc ) || (uiVerifyCrc == 0x0000 )) 	//16 bytes Serial Exist
		{
			g_uiFWDN_WriteSNFlag = 1;
			return SUCCESS;
		}
	}
	else if (memcmp(&ucTempData[20+uiSNOffset], "FWDN", 4) == 0 || memcmp(&ucTempData[20+uiSNOffset], "GANG", 4) == 0)
	{
		uiVerifyCrc = ( ucTempData[uiSNOffset + 16] <<24) ^ ( ucTempData[uiSNOffset + 17] <<16) ^ 
			( ucTempData[uiSNOffset + 18] << 8) ^ ( ucTempData[uiSNOffset + 19]);
		uiTempCrc = FWUG_CalcCrc8( (uiSNOffset + ucTempData), 16, CRC32_TABLE);
		if  (uiVerifyCrc == 0x0000 )
		{
			g_uiFWDN_WriteSNFlag = 0; 										// cleared SN
			return 1;
		}
		else
		{
			if (memcmp(&ucTempData[52+uiSNOffset], "FWDN", 4) == 0 || memcmp(&ucTempData[52+uiSNOffset], "GANG", 4) == 0)
			{
				uiVerifyCrc = ( ucTempData[uiSNOffset + 48] <<24) ^ ( ucTempData[uiSNOffset + 49] <<16) ^ 
					( ucTempData[uiSNOffset + 50] << 8) ^ ( ucTempData[uiSNOffset + 51]);
				uiTempCrc = FWUG_CalcCrc8((uiSNOffset + ucTempData+32), 16, CRC32_TABLE);
				if (( uiVerifyCrc == uiTempCrc ) && ( uiVerifyCrc != 0x0000 ))
				{
					g_uiFWDN_WriteSNFlag = 1;

				#if defined (NKUSE)
				#else
					#ifndef WITHOUT_FILESYSTEM
					if ( DISK_DefaultDriveType == DISK_DEVICE_HDD ) //for erasing NOR Flash before writing FW 
					{
						memcpy ( FWDN_DeviceInformation.DevSerialNumber, ucTempData, 16 );
						memcpy ( FWDN_DeviceInformation.DevSerialNumber+16, ucTempData+32, 16 );
					}
					#endif
				#endif	
					return SUCCESS;
				}				
				else
					g_uiFWDN_WriteSNFlag = 0; 										// cleared SN
			}
			else
				g_uiFWDN_WriteSNFlag = 0; 										// cleared SN
		}
	}
	return 1;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void FWDN_FNT_VerifySN(unsigned char* ucTempData, unsigned int uiSNOffset);
*  
*  DESCRIPTION : Verify the validity of Serial Number format
*  
*  INPUT:
*			ucTempData	= base pointer of serial number format
*			uiSNOffset	= offset of serial number format
*  
*  OUTPUT:	void - Return Type
*			update global structure of FWDN_DeviceInformation according to verification result.
*  
**************************************************************************/
void FWDN_FNT_VerifySN(unsigned char* ucTempData, unsigned int uiSNOffset)
{
	unsigned int		uiVerifyCrc;
	unsigned int		uiTempCrc;

	/*---------------------------------------------------------------------
		Check Type for Serial Number of 16 digits
	----------------------------------------------------------------------*/
	if (memcmp(&ucTempData[20+uiSNOffset], "ZERO", 4) == 0)
	{		
		uiVerifyCrc = (ucTempData[uiSNOffset + 16] <<24) ^ ( ucTempData[uiSNOffset + 17] <<16) ^
			( ucTempData[uiSNOffset + 18] << 8) ^ ( ucTempData[uiSNOffset + 19]); 
		uiTempCrc = FWUG_CalcCrc8((uiSNOffset + ucTempData), 16, CRC32_TABLE);

		if ( ( uiTempCrc == uiVerifyCrc ) || (uiVerifyCrc == 0x0000 ))
		{
			if (uiVerifyCrc == 0x0000 ) 
			{
				memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 16);
				memset(FWDN_DeviceInformation.DevSerialNumber+16, 0x30, 16);
				FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_16;
			}
			else
			{
				memcpy(FWDN_DeviceInformation.DevSerialNumber, (uiSNOffset + ucTempData), 16);
				memset(FWDN_DeviceInformation.DevSerialNumber+16, 0x30, 16);
				FWDN_DeviceInformation.DevSerialNumberType = SN_VALID_16;
			}
		}
	}
	/*---------------------------------------------------------------------
		Check Type for Serial Number of 32 digits
	----------------------------------------------------------------------*/
	else if (memcmp(&ucTempData[20+uiSNOffset], "FWDN", 4) == 0 || memcmp(&ucTempData[20+uiSNOffset], "GANG", 4) == 0)
	{
		uiVerifyCrc = ( ucTempData[uiSNOffset + 16] <<24) ^ ( ucTempData[uiSNOffset + 17] <<16) ^ 
			( ucTempData[uiSNOffset + 18] << 8) ^ ( ucTempData[uiSNOffset + 19]); 
		uiTempCrc = FWUG_CalcCrc8(uiSNOffset + ucTempData, 16, CRC32_TABLE);
		if  (uiVerifyCrc == 0x0000 )
		{
			memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
			FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_32;			
		}
		else
		{
			if (memcmp(&ucTempData[52+uiSNOffset], "FWDN", 4) == 0 || memcmp(&ucTempData[52+uiSNOffset], "GANG", 4) == 0)
			{
				uiVerifyCrc = ( ucTempData[uiSNOffset + 48] <<24) ^ ( ucTempData[uiSNOffset + 49] <<16) ^ 
					( ucTempData[uiSNOffset + 50] << 8) ^ ( ucTempData[uiSNOffset + 51]); 
				uiTempCrc = FWUG_CalcCrc8(( uiSNOffset + ucTempData + 32), 16, CRC32_TABLE);
				if (( uiVerifyCrc == uiTempCrc ) && ( uiVerifyCrc != 0x0000 ))
				{
					memcpy(FWDN_DeviceInformation.DevSerialNumber, (uiSNOffset + ucTempData), 16);
					memcpy(FWDN_DeviceInformation.DevSerialNumber+16, (uiSNOffset + ucTempData + 32 ), 16);
					FWDN_DeviceInformation.DevSerialNumberType = SN_VALID_32;
				}				
				else
				{
					memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
					FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_32;			
				}
			}
			else
			{
				memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
				FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_32;			
			}
		}		
	}
	else
	{
		memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
		FWDN_DeviceInformation.DevSerialNumberType = SN_NOT_EXIST;	
	}
}

void FWDN_FNT_InsertSN(unsigned char *pSerialNumber)
{
	unsigned	uCRC;

	memcpy (pSerialNumber, FWDN_DeviceInformation.DevSerialNumber, 16 );
	uCRC	= FWUG_CalcCrc8(pSerialNumber, 16, CRC32_TABLE);
	
	pSerialNumber[16] = (uCRC & 0xFF000000) >> 24;
	pSerialNumber[17] = (uCRC & 0x00FF0000) >> 16;
	pSerialNumber[18] = (uCRC & 0x0000FF00) >> 8;
	pSerialNumber[19] = (uCRC & 0x000000FF) ;

	memcpy(pSerialNumber+20, "FWDN", 4);
	memset(pSerialNumber+24, 0x00, 8);
	memcpy(pSerialNumber+32, FWDN_DeviceInformation.DevSerialNumber+16, 16);
	uCRC	= FWUG_CalcCrc8(pSerialNumber+32, 16, CRC32_TABLE);

	pSerialNumber[48] = (uCRC & 0xFF000000) >> 24;
	pSerialNumber[49] = (uCRC & 0x00FF0000) >> 16;
	pSerialNumber[50] = (uCRC & 0x0000FF00) >> 8;
	pSerialNumber[51] = (uCRC & 0x000000FF) ;

	memcpy(pSerialNumber+52, "FWDN", 4);
	memset(pSerialNumber+56, 0x00, 8);
}

unsigned char FWDN_DRV_FirmwareMemoryType(void)
{
	return (unsigned int)gFWDN_FirmwareDevice;
}

#endif //FWDN_V6
/************* end of file *************************************************************/
