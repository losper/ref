/***************************************************************************************
*	FileName    : fwdn_protocol_v3.c
*	Description : FWDN Protocol Version 3. Functions
****************************************************************************************
*
*	TCC Board Support Package
*	Copyright (c) Telechips, Inc.
*	ALL RIGHTS RESERVED
*
****************************************************************************************/
#if defined(FWDN_V6)

#include "fwdn_protocol_v3.h"
#include "fwdn_drv_v3.h"

#if defined(_LINUX_)
#include "common.h"
#include "../usb/usb_defs.h"
#include "../usb/vtc.h"
#elif defined(_WINCE_)
#include "..\USB\usb_defs.h"
#include "..\USB\vtc.h"
#endif

#define	FWDN_PROT_VERSION			0x03000005


//==============================================================
//
//		Global Variables
//
//==============================================================

//==============================================================
//
//		External Variables
//
//==============================================================
extern unsigned int FWUG_VERSION;
extern const unsigned char TNFTL_Library_Version[];


//=====================================================================
//
//		Extern Functions
//
//=====================================================================
//unsigned USB_JumpUSB(void);
unsigned char* FWUG_V3_TellLibraryVersion( void );

//==============================================================
//
//		Variables
//
//==============================================================
static unsigned short gFwdn_CmdType;


static void FWDN_PROT_Response_Reset(FWDN_RESPONSE_T *pFwdnRsp)
{
	memset(pFwdnRsp,0,sizeof(FWDN_RESPONSE_T));
	pFwdnRsp->Signature = FWDN_RESPONSE_SIGNATURE;
	pFwdnRsp->CmdType = gFwdn_CmdType;
}

__inline unsigned long FWDN_PROT_ExtraCommand(void *pBuf, unsigned short extraCmdSize)
{
	return (unsigned long)VTC_ReceiveData(pBuf,(unsigned int)extraCmdSize);
}

__inline void FWDN_PROT_Response(FWDN_RESPONSE_T *pFwdnRsp)
{
	VTC_SendData((void*)pFwdnRsp, sizeof(FWDN_RESPONSE_T));
}

__inline void FWDN_PROT_ExtraResponse(void *pBuf, unsigned char ExtraRspSize)
{
	VTC_SendData(pBuf,(unsigned int)ExtraRspSize);
}

__inline unsigned int FWDN_PROT_Data_Send(void *pBuf, unsigned int length)
{
	return VTC_SendData(pBuf,length);
}

__inline unsigned int FWDN_PROT_Data_Receive(void *pBuf, unsigned int length)
{
	return VTC_ReceiveData(pBuf,length);
}

void FWDN_PROT_ResponseAck(void)
{
	FWDN_RESPONSE_T fwdnRsp;

	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_ACK;

	FWDN_PROT_Response(&fwdnRsp);
}

void FWDN_PROT_ResponseNack(void)
{
	FWDN_RESPONSE_T fwdnRsp;

	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_NACK;
	fwdnRsp.Param0 = FWDN_DRV_GetErrorCode();

	FWDN_PROT_Response(&fwdnRsp);
}

static void FWDN_PROT_CallBack_From_TNFTL( unsigned short SMC_DrvNo, unsigned short STATUS_CODE, unsigned int WParam )
{
	if( STATUS_CODE == TNFTL_CALLBACK_LCD_BMP_UPDATE_PROCESS
		|| STATUS_CODE == TNFTL_CALLBACK_LCD_FORMAT_PROCESS )
	{
		if(VTC_CheckIsTransmitReady() == TRUE)
		{
			FWDN_RESPONSE_T fwdnRsp;

			FWDN_PROT_Response_Reset(&fwdnRsp);
			fwdnRsp.AckType = FWDN_RSP_NYET;
			fwdnRsp.Param0 = (unsigned long)WParam;

			FWDN_PROT_Response(&fwdnRsp);
		}
	}
}

static int _loc_RequestData(unsigned char *buff, unsigned int size)
{
	FWDN_RESPONSE_T fwdnRsp;
	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_NYET;

	fwdnRsp.DataSize = size;
	FWDN_PROT_Response(&fwdnRsp);

	if( FWDN_PROT_Data_Receive((void *)buff, fwdnRsp.DataSize) != fwdnRsp.DataSize )
		return -1;

	return 0;
}

static void FWDN_PROT_Device_Reset(void)
{
	//USB_JumpUSB();
}

static void FWDN_PROT_Ping(void)
{
	FWDN_RESPONSE_T fwdnRsp;

	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_ACK;
	fwdnRsp.Param0 = FWDN_PROT_VERSION;

	FWDN_PROT_Response(&fwdnRsp);
}

static void FWDN_PROT_Test(void)
{
	unsigned int i;
#ifdef _LINUX_
	unsigned char testvec[64]__attribute__((aligned(8)));
#else
	unsigned char testvec[64];
#endif
	for(i=0;i<64;i++)
		testvec[i] = (unsigned char)i+64;
	VTC_SendData((void*)testvec, 64);
}

static void FWDN_PROT_DeviceSetting(FWDN_COMMAND_T *pFwdnCmd)
{
	FWDN_DRV_SaveSdCfg(pFwdnCmd->Param0);
	FWDN_PROT_ResponseAck();
}

static void FWDN_PROT_DeviceInfoRead(FWDN_COMMAND_T *pFwdnCmd)
{
#if 0
typedef struct	 _tag_DeviceInfoType {
	unsigned int		DefaultDiskType;		// Default Disk Type. nand, tri-flash, hdd ...
	unsigned int		DevSerialNumberType;	// Device Serial Number type SN_NOT_EXIST..
	unsigned char		DevSerialNumber[32];
} FWDN_DEVICE_INFORMATION, *pFWDN_DEVICE_INFORMATION;
	FWDN_DEVICE_INFORMATION fwdnDeviceInfo = {
		0,
		3,
		{
			'0','1','2','3','4','5','6','7',
			'0','1','2','3','4','5','6','7',
			'0','1','2','3','4','5','6','7',
			'0','1','2','3','4','5','6','7'
		}
	};
#endif
	FWDN_RESPONSE_T fwdnRsp;

	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_ACK;
	fwdnRsp.ExtraRspSize = (unsigned char)sizeof(FWDN_DEVICE_INFORMATION);
	
	FWDN_PROT_Response(&fwdnRsp);
	//FWDN_PROT_ExtraResponse((void *)&fwdnDeviceInfo, fwdnRsp.ExtraRspSize);
	FWDN_PROT_ExtraResponse((void *)FWDN_DRV_GetDeviceInfo(), fwdnRsp.ExtraRspSize);
}

static void FWDN_PROT_SerialNumberWrite(FWDN_COMMAND_T *pFwdnCmd)
{
	int result = FALSE;
	
	if( pFwdnCmd->ExtraCmdSize == 32 )
	{
#ifdef _LINUX_
		unsigned char serial[32]__attribute__((aligned(8)));
#else
		unsigned char serial[32];
#endif
		unsigned int overwrite;
		
		FWDN_PROT_ExtraCommand((void *)serial, pFwdnCmd->ExtraCmdSize);
		overwrite = (unsigned int)pFwdnCmd->Param0;
		
		result = FWDN_DRV_SerialNumberWrite(serial, overwrite);
	}

	if( result == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static int FWDN_PROT_FirmwareWrite_ReadFromUSB(unsigned char *buff, unsigned int size, unsigned int srcAddr, unsigned int percent)
{
	FWDN_RESPONSE_T fwdnRsp;

	// If caller doesn't need data, it doesn't need to respond at everytime.
	if( size == 0 && VTC_CheckIsTransmitReady() == FALSE )
		return 0;

	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_NYET;
	fwdnRsp.DataSize = (unsigned long)size;
	fwdnRsp.Param0 = (unsigned long)percent;
	fwdnRsp.Param1 = (unsigned long)srcAddr;
	FWDN_PROT_Response(&fwdnRsp);

	if( FWDN_PROT_Data_Receive((void *)buff, fwdnRsp.DataSize) == fwdnRsp.DataSize )
		return 0;
	else
		return -1;
}

static void FWDN_PROT_FirmwareWrite(FWDN_COMMAND_T *pFwdnCmd)
{
	int				err;
	unsigned int	fwSize;
	unsigned int	targetMemoryType;

	fwSize				= (unsigned int)pFwdnCmd->Param0;
	targetMemoryType	= (unsigned int)pFwdnCmd->Param1;
	
	err = FWDN_DRV_FirmwareWrite(fwSize, targetMemoryType, &FWDN_PROT_FirmwareWrite_ReadFromUSB);
	if( err == 0 )
		FWDN_PROT_ResponseAck();
	else
	{
		FWDN_RESPONSE_T fwdnRsp;

		FWDN_PROT_Response_Reset(&fwdnRsp);
		fwdnRsp.AckType = FWDN_RSP_NACK;
		fwdnRsp.Param0 = (unsigned long)err;
		if( targetMemoryType == 0 )
		{
			fwdnRsp.Param1	= (unsigned long)FWDN_DRV_FirmwareMemoryType();
		}
		else
		{
			fwdnRsp.Param1	= (unsigned long)targetMemoryType;
		}
		FWDN_PROT_Response(&fwdnRsp);
	}
}

static void FWDN_PROT_SessionStart(void)
{
#if defined(_WINCE_)
	KITLOutputDebugString("===== FWDN Session Start! =====\n");
#endif

	FWDN_PROT_ResponseAck();
}

static void FWDN_PROT_SessionEnd(FWDN_COMMAND_T *pFwdnCmd)
{
	unsigned long bSuccess = pFwdnCmd->Param0;
	if(bSuccess)
	{
#if defined(_WINCE_)
		KITLOutputDebugString("===== FWDN Session End! =====\n");
#endif
	}
	else
	{
#if defined(_WINCE_)
		KITLOutputDebugString("===== FWDN Session is Failed!=====\n");
#endif
	}
	FWDN_PROT_ResponseAck();
}

static void FWDN_PROT_DISK_Select(FWDN_COMMAND_T *pFwdnCmd)
{
	FWDN_DRV_DISK_Select((unsigned char)pFwdnCmd->Param0);
	FWDN_PROT_ResponseAck();
}

static void FWDN_PROT_DISK_Init(FWDN_COMMAND_T *pFwdnCmd)
{
#ifdef _LINUX_
	unsigned char info[256]__attribute__((aligned(8)));
#else
	unsigned char info[256];
#endif

	if (pFwdnCmd->ExtraCmdSize != 0)
		FWDN_PROT_ExtraCommand((void *)info, pFwdnCmd->ExtraCmdSize);

	if( FWDN_DRV_DISK_Init(FWDN_PROT_CallBack_From_TNFTL,(unsigned int)pFwdnCmd->Param0,(void*)info,pFwdnCmd->ExtraCmdSize) == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_InfoRead(FWDN_COMMAND_T *pFwdnCmd)
{
	FWDN_RESPONSE_T fwdnRsp;
#ifdef _LINUX_
	unsigned char diskInfo[FWDN_EXTRA_RSP_MAX_SIZE]__attribute__((aligned(8)));
#else
	unsigned char diskInfo[FWDN_EXTRA_RSP_MAX_SIZE];
#endif
	unsigned char size;

	FWDN_DRV_DISK_InfoRead(diskInfo,&size);

	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_ACK;
	fwdnRsp.ExtraRspSize = size;

	FWDN_PROT_Response(&fwdnRsp);
	FWDN_PROT_ExtraResponse((void*)diskInfo, size);
}

static void FWDN_PROT_DISK_Read(FWDN_COMMAND_T *pFwdnCmd)
{
	if( FWDN_DRV_DISK_Read((unsigned int)pFwdnCmd->Param0, (unsigned int)pFwdnCmd->DataSize, &FWDN_PROT_Data_Send) == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_Write(FWDN_COMMAND_T *pFwdnCmd)
{
	if( FWDN_DRV_DISK_Write((unsigned int)pFwdnCmd->Param0, (unsigned int)pFwdnCmd->DataSize, &FWDN_PROT_Data_Receive) == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_Hidden_InfoRead(void)
{
	FWDN_RESPONSE_T fwdnRsp;
#ifdef _LINUX_
	unsigned char hiddenInfo[FWDN_EXTRA_RSP_MAX_SIZE]__attribute__((aligned(8)));
#else
	unsigned char hiddenInfo[FWDN_EXTRA_RSP_MAX_SIZE];
#endif
	unsigned char size;

	FWDN_DRV_DISK_Hidden_InfoRead((void*)hiddenInfo,&size);

	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_ACK;
	fwdnRsp.ExtraRspSize = size;

	FWDN_PROT_Response(&fwdnRsp);
	FWDN_PROT_ExtraResponse((void*)hiddenInfo, size);
}

static void FWDN_PROT_DISK_Hidden_Clean(void)
{
	if( FWDN_DRV_DISK_Hidden_Clean() == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_Hidden_Write(FWDN_COMMAND_T *pFwdnCmd)
{
	unsigned int size = (unsigned int)pFwdnCmd->Param0;
	unsigned int startPage = (unsigned int)pFwdnCmd->Param1;
	unsigned int index = (unsigned int)pFwdnCmd->Param2;
	if( FWDN_DRV_DISK_Hidden_Write(index, startPage, size, &_loc_RequestData) == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_MTD_Write(FWDN_COMMAND_T *pFwdnCmd)
{
	unsigned int size = (unsigned int)pFwdnCmd->DataSize;
	unsigned int startPage = (unsigned int)pFwdnCmd->Param0;
	if( FWDN_DRV_DISK_MTD_Write(startPage, size, &FWDN_PROT_Data_Receive) == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

#ifndef WITHOUT_FILESYSTEM
static void FWDN_PROT_DISK_DATA_Partition(FWDN_COMMAND_T *pFwdnCmd)
{
	int result = TRUE;
	char pMultiPartitionSizeArray[256];
	if( pFwdnCmd->ExtraCmdSize != 0 )
	{
		//pMultiPartitionSizeArray = (unsigned int *)TC_Allocate_Memory((unsigned int)pFwdnCmd->ExtraCmdSize);

		if( pMultiPartitionSizeArray != NULL )
			FWDN_PROT_ExtraCommand((void*)pMultiPartitionSizeArray, pFwdnCmd->ExtraCmdSize);
		else
			result = FALSE;
	}

	if( result == TRUE )
		result = FWDN_DRV_DISK_DATA_Partition((void*)pMultiPartitionSizeArray, pFwdnCmd->ExtraCmdSize);

	//if( pMultiPartitionSizeArray != NULL )
	//	TC_Deallocate_Memory(pMultiPartitionSizeArray);

	if( result == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_DATA_Image_Write(FWDN_COMMAND_T *pFwdnCmd)
{
	unsigned int size = pFwdnCmd->Param0;
	unsigned int nPartitionID = pFwdnCmd->Param1;
	unsigned int offset = pFwdnCmd->Param2;
	if(FWDN_DRV_DISK_DATA_Image_Write(nPartitionID,offset,size,&_loc_RequestData)==TRUE)
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_FS_Mount(FWDN_COMMAND_T *pFwdnCmd)
{
	if (FWDN_DRV_DISK_FS_Mount(pFwdnCmd->Param0) == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_FS_Format(FWDN_COMMAND_T *pFwdnCmd)
{
	int result = TRUE;
	char pLabel[256];
	if( pFwdnCmd->ExtraCmdSize != 0 )
	{
		//pMultiPartitionSizeArray = (unsigned int *)TC_Allocate_Memory((unsigned int)pFwdnCmd->ExtraCmdSize);

		if( pLabel != NULL )
			FWDN_PROT_ExtraCommand((void*)pLabel, pFwdnCmd->ExtraCmdSize);
		else
			result = FALSE;
	}

	if( result == TRUE )
		result = FWDN_DRV_DISK_FS_Format(pFwdnCmd->Param0,(void*)pLabel);

	//if( pMultiPartitionSizeArray != NULL )
	//	TC_Deallocate_Memory(pMultiPartitionSizeArray);

	if( result == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_FS_MkDir(FWDN_COMMAND_T *pFwdnCmd)
{
	int result = FALSE;
#ifdef _LINUX_
	unsigned char dirName[256]__attribute__((aligned(8)));
#else
	unsigned char dirName[256];
#endif
	
	//dirName = (unsigned char*)TC_Allocate_Memory((unsigned int)pFwdnCmd->ExtraCmdSize);

	if( dirName != NULL )
	{
		FWDN_PROT_ExtraCommand((void *)dirName, pFwdnCmd->ExtraCmdSize);

		result = FWDN_DRV_DISK_FS_MkDir(dirName);

		//TC_Deallocate_Memory(dirName);
	}

	if( result == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_FS_ChDir(FWDN_COMMAND_T *pFwdnCmd)
{
	int result = FALSE;
#ifdef _LINUX_
	unsigned char dirName[256]__attribute__((aligned(8)));
#else
	unsigned char dirName[256];
#endif
	
	//dirName = (unsigned char *)TC_Allocate_Memory((unsigned int)pFwdnCmd->ExtraCmdSize);

	if( dirName != NULL )
	{
		FWDN_PROT_ExtraCommand((void *)dirName, pFwdnCmd->ExtraCmdSize);

		result = FWDN_DRV_DISK_FS_ChDir(dirName);

		//TC_Deallocate_Memory(dirName);
	}

	if( result == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_DISK_FS_FileWrite(FWDN_COMMAND_T *pFwdnCmd)
{
	int result = FALSE;
#ifdef _LINUX_
	unsigned char fileName[256]__attribute__((aligned(8)));
#else
	unsigned char fileName[256];
#endif

	//fileName = (unsigned char *)TC_Allocate_Memory((unsigned int)pFwdnCmd->ExtraCmdSize);

	if( fileName != NULL )
	{
		FWDN_PROT_ExtraCommand((void *)fileName, pFwdnCmd->ExtraCmdSize);

		result = FWDN_DRV_DISK_FS_FileWrite(fileName, (unsigned int)pFwdnCmd->Param0, &_loc_RequestData);

		//TC_Deallocate_Memory(fileName);
	}

	if( result == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}
#endif // WITHOUT_FILESYSTEM

static void FWDN_PROT_DISK_DUMP_InfoRead(void)
{
	FWDN_RESPONSE_T fwdnRsp;
#ifdef _LINUX_
	unsigned char extraRsp[0xFF]__attribute__((aligned(8)));
#else
	unsigned char extraRsp[0xFF];
#endif

	FWDN_PROT_Response_Reset(&fwdnRsp);
	fwdnRsp.AckType = FWDN_RSP_ACK;
	fwdnRsp.ExtraRspSize = FWDN_DRV_DISK_DUMP_InfoRead(extraRsp);

	FWDN_PROT_Response(&fwdnRsp);
	if( fwdnRsp.ExtraRspSize != 0 )
		FWDN_PROT_ExtraResponse((void *)extraRsp, fwdnRsp.ExtraRspSize);
}

static void FWDN_PROT_DISK_DUMP_BlockRead(FWDN_COMMAND_T *pFwdnCmd)
{
	if( FWDN_DRV_DISK_DUMP_BlockRead(pFwdnCmd->Param0,pFwdnCmd->Param1,pFwdnCmd->Param2,&FWDN_PROT_Data_Send) == TRUE )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

static void FWDN_PROT_TEST(FWDN_COMMAND_T *pFwdnCmd)
{
#ifdef _LINUX_
	unsigned char dummy[512]__attribute__((aligned(8)));
#else
	unsigned char dummy[512];
#endif
	unsigned int dataSize = pFwdnCmd->DataSize;
	unsigned int packetSize;
	switch(pFwdnCmd->CmdType)
	{
		case FWDN_CMD_TEST_SEND:
		{
			while( dataSize > 0 )
			{
				packetSize = min(dataSize,512);
				if( FWDN_PROT_Data_Receive((void*)dummy,packetSize) != packetSize )
					break;
				dataSize -= packetSize;
			}
			break;
		}
		case FWDN_CMD_TEST_RECEIVE:
		{
			for(packetSize=0;packetSize<512;packetSize++)
				dummy[packetSize] = (unsigned char)packetSize;
			while( dataSize > 0 )
			{
				packetSize = min(dataSize,512);
				if( FWDN_PROT_Data_Send((void*)dummy,packetSize) != packetSize )
					break;
				dataSize -= packetSize;
			}
			break;
		}
	}

	if( dataSize == 0 )
		FWDN_PROT_ResponseAck();
	else
		FWDN_PROT_ResponseNack();
}

void FWDN_PROT_CheckCommand(void)
{
	FWDN_COMMAND_T fwdnCmd;

	if ( VTC_CheckIsReceivedData() == 0 )
	{
		return;
	}

	if ( VTC_ReceiveData( (void*)(&fwdnCmd), sizeof(FWDN_COMMAND_T) ) != sizeof(FWDN_COMMAND_T) )
	{
		//FWDN_PROT_Test();
		return;
	}

	//FWDN_PROT_Test();

	FWDN_DRV_ClearErrorCode();

	gFwdn_CmdType = fwdnCmd.CmdType;
	switch(fwdnCmd.CmdType)
	{
		case FWDN_CMD_PING:
			FWDN_PROT_Ping();
			break;
		case FWDN_CMD_DEVICE_RESET:
			FWDN_PROT_Device_Reset();
			break;
		case FWDN_CMD_DEVICE_SETTING:
			FWDN_PROT_DeviceSetting(&fwdnCmd);
			break;
		case FWDN_CMD_DEVICE_INFO_READ:
			FWDN_PROT_DeviceInfoRead(&fwdnCmd);
			break;
		case FWDN_CMD_SERIAL_NUMBER_WRITE:
			FWDN_PROT_SerialNumberWrite(&fwdnCmd);
			break;
		case FWDN_CMD_FIRMWARE_WRITE:
			FWDN_PROT_FirmwareWrite(&fwdnCmd);
			break;
		case FWDN_CMD_SESSION_START:
			FWDN_PROT_SessionStart();
			break;
		case FWDN_CMD_SESSION_END:
			FWDN_PROT_SessionEnd(&fwdnCmd);
			break;

		case FWDN_CMD_DISK_SELECT:
			FWDN_PROT_DISK_Select(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_INIT:
			FWDN_PROT_DISK_Init(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_INFO_READ:
			FWDN_PROT_DISK_InfoRead(&fwdnCmd);
			break;

		case FWDN_CMD_DISK_DATA_READ:
			FWDN_PROT_DISK_Read(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_DATA_WRITE:
			FWDN_PROT_DISK_Write(&fwdnCmd);
			break;

		case FWDN_CMD_DISK_HIDDEN_INFO_READ:
			FWDN_PROT_DISK_Hidden_InfoRead();
			break;
		case FWDN_CMD_DISK_HIDDEN_CLEAN:
			FWDN_PROT_DISK_Hidden_Clean();
			break;
		case FWDN_CMD_DISK_HIDDEN_WRITE:
			FWDN_PROT_DISK_Hidden_Write(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_MTD_WRITE:
			FWDN_PROT_DISK_MTD_Write(&fwdnCmd);
			break;

		#ifndef WITHOUT_FILESYSTEM
		case FWDN_CMD_DISK_DATA_PARTITION:
			FWDN_PROT_DISK_DATA_Partition(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_DATA_IMAGE_WRITE:
			FWDN_PROT_DISK_DATA_Image_Write(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_DATA_FS_MOUNT:
			FWDN_PROT_DISK_FS_Mount(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_DATA_FS_FORMAT:
			FWDN_PROT_DISK_FS_Format(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_DATA_FS_MKDIR:
			FWDN_PROT_DISK_FS_MkDir(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_DATA_FS_CHDIR:
			FWDN_PROT_DISK_FS_ChDir(&fwdnCmd);
			break;
		case FWDN_CMD_DISK_DATA_FS_FILE_WRITE:
			FWDN_PROT_DISK_FS_FileWrite(&fwdnCmd);
			break;
		#endif

		case FWDN_CMD_DISK_DUMP_INFO_READ:
			FWDN_PROT_DISK_DUMP_InfoRead();
			break;
		case FWDN_CMD_DISK_DUMP_BLOCK_READ:
			FWDN_PROT_DISK_DUMP_BlockRead(&fwdnCmd);
			break;

		case FWDN_CMD_TEST_SEND:
		case FWDN_CMD_TEST_RECEIVE:
			FWDN_PROT_TEST(&fwdnCmd);
			break;

		//case FWDN_CMD_TNFTL_V5_DEBUG:
		//	TNFTL_DEBUG_VTCParser( &fwdnCmd );

		default:
			FWDN_PROT_ResponseNack();
			break;
	}
}

#endif //FWDN_V6

/************* end of file *************************************************************/
