/****************************************************************************
 *   FileName    : fwdn_SDMMC.c
 *   Description : SDMMC F/W downloader function
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#if 0
#include "main.h"
#include "globals.h"
#include "IO_TCCXXX.h"//#include "IO_TCC7XX.h"
//#include "ui_api.h"
//#include "ui_drivers.h"
#include "TC_File.h"
#include "TC_Kernel.h"
#include "mmc_ext.h"
#include "fwupgrade.h"
#include "fwdn_drv_v3.h"
//#include "fwug_v2.h"
#else
#if defined(_LINUX_) || defined(_WINCE_)
#include "globals.h"
#include "IO_TCCXXX.h"
//#include "fwdn_protocol.h"
#if defined(FWDN_V6)
#include "fwdn_drv_v3.h"
#else
#include "fwdn_drv_v7.h"
#endif
#include "fwupgrade.h"
#include "mmc_ext.h"

#if defined (NKUSE)
	#include "windows.h"
	#include "stdlib.h"
#else
	#include "TC_File.h"
#endif
#endif
#endif
//=============================================================================
//*
//*
//*                           [ CONST DATA DEFINE ]
//*
//*
//=============================================================================
#undef	LPRINTF
#define	LPRINTF	(1) ? (void)0: printf

//=============================================================================
//*
//*
//*                     [ EXTERN VARIABLE & FUNCTIONS DEFINE ]
//*
//*
//=============================================================================
#ifdef TRIFLASH_INCLUDE
extern const unsigned int		CRC32_TABLE[256];
extern unsigned int				g_uiFWDN_OverWriteSNFlag;
extern unsigned int				g_uiFWDN_WriteSNFlag;

extern unsigned int				FWDN_FNT_SetSN(unsigned char* ucTempData, unsigned int uiSNOffset);
extern void						FWDN_FNT_InsertSN(unsigned char * pSerialNumber);
extern void						FWDN_FNT_VerifySN(unsigned char* ucTempData, unsigned int uiSNOffset);
extern void						IO_DBG_SerialPrintf_(char *format, ...);
extern unsigned					SDMMC_GetHeaderAddr(void);
extern unsigned					SDMMC_GetROMAddr(void);

#define			FWDN_WRITE_BUFFER_SIZE		(16*1024)
unsigned int	tempBuffer[FWDN_WRITE_BUFFER_SIZE/4];
#endif

int FwdnClearTriflashHiddenArea(void)
{
#if 0 //#ifdef TRIFLASH_INCLUDE
	unsigned	Param[2];
	unsigned	*pBuff;
	unsigned	uBufSize;
	int		iRemain, iUnit, iBufUnit, iLBA;

	pBuff = (unsigned char*)tempBuffer;
	uBufSize = FWDN_WRITE_BUFFER_SIZE;

	iBufUnit	= uBufSize / 512;
	if (iBufUnit > 0x7FFF)
		iBufUnit	= 0x7FFF;
	uBufSize	= iBufUnit * 512;
	memset(pBuff, 0xFF, uBufSize);

	DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_GET_HIDDEN_SIZE, Param);

	iRemain	= Param[0];
	iLBA		= 0;
	LPRINTF("Begin Erasing Hidden Area (%d sectors)\n", iRemain);
	while (iRemain > 0)
	{
		if (iRemain < iBufUnit)
			iUnit	= iRemain;
		else
			iUnit	= iBufUnit;

		if (DISK_HDWriteSector(DISK_DEVICE_TRIFLASH, iLBA, iUnit, pBuff) < 0)
		{
			LPRINTF("Erasing I/O Error.\n");
			return	-1;
		}

		iRemain	-= iUnit;
		iLBA	+= iUnit;
	}
#endif	
	LPRINTF("Erasing Hidden Area Finished.\n");
	return 0;
}

int FwdnWriteCodeTriflash(unsigned int uiROMFileSize, unsigned char *WriteBufAddr, int iBufSize)
{
#ifdef TRIFLASH_INCLUDE
	ioctl_diskinfo_t 	disk_info;
	unsigned int		loop, remain, count, sectorsPerBuffer;
	int				readsize;
	int				res;
	ioctl_diskrwpage_t	bootCodeWrite, bootCodeRead;
	unsigned char 	*pVerifyData;
	unsigned int	readRomIndex=0;
	unsigned int	percent;

	/*---------------------------------------------------------------------
		Check ROM Image Size
	----------------------------------------------------------------------*/
	if (uiROMFileSize >  gMAX_ROMSIZE_SD)
	{
		return ERR_FWUG_FAIL_ROMFILESIZEBIG;
	}

	if (DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_GET_DISKINFO, (void *)&disk_info) < 0)
		return -1;

	if (disk_info.sector_size != 512)
		return -1;

	/*---------------------------------------------------------------------
		Initialize Global Variables
	----------------------------------------------------------------------*/
	sectorsPerBuffer	= iBufSize / 512 / 2;		// Half for Write, Half for Verify
	iBufSize			= sectorsPerBuffer * 512;
	loop				= uiROMFileSize / iBufSize;
	remain			= uiROMFileSize % iBufSize;
	pVerifyData		= WriteBufAddr + iBufSize;

	initSourcePosition();

	bootCodeWrite.rw_size		= sectorsPerBuffer;
	bootCodeWrite.buff			= WriteBufAddr;
	bootCodeRead.rw_size		= sectorsPerBuffer;
	bootCodeRead.buff			= pVerifyData;

	LPRINTF("Write Code Begins\n");

	bootCodeWrite.start_page	= SDMMC_GetROMAddr();
	for (count = 0; count < loop; count++)
	{
		percent = readRomIndex / (uiROMFileSize/50);

		readsize = FWDN_DRV_FirmwareWrite_Read( WriteBufAddr, iBufSize, percent );
		readRomIndex += (unsigned int)readsize;

		if (readsize != iBufSize)
		{
			LPRINTF("Fail to Receive Image\n");
			return ERR_FWUG_FAIL_READROMFILE;
		}

		if(DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_WRITE_PAGE, (void *) & bootCodeWrite) < 0)
			return ERR_FWUG_FAIL_CODEWRITETFLASH;

		#if 0
		// Verify Data
		bootCodeRead.start_page	= bootCodeWrite.start_page;
		res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_READ_PAGE, (void *) & bootCodeRead);
		if ( res < 0)		// there is error on reading F/W
		{
			LPRINTF("Fail to Read Image\n");
			return ERR_FWUG_FAIL_CODEREADTFLASH;
		}
		if (memcmp(WriteBufAddr, pVerifyData, iBufSize) != 0)
		{
			LPRINTF("Fail to Compare Image\n");
			return ERR_FWUG_FAIL + 100;		// Verifying Error
		}
		#endif
		bootCodeWrite.start_page	+= sectorsPerBuffer;
		LPRINTF(".");
	}

	if (remain > 0)
	{
		percent = readRomIndex / (uiROMFileSize/50);

		readsize = FWDN_DRV_FirmwareWrite_Read( WriteBufAddr, remain, percent );
		readRomIndex += (unsigned int)readsize;

		if (readsize != remain)
		{
			LPRINTF("Fail to Receive Image\n");
			return ERR_FWUG_FAIL_READROMFILE;
		}

		bootCodeWrite.rw_size	= (readsize+511) / 512;
		res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_WRITE_PAGE, (void *) & bootCodeWrite);
		if ( res < 0)		// there is error on writing F/W
		{
			LPRINTF("Fail to Write Image\n");
			return ERR_FWUG_FAIL_CODEWRITETFLASH;
		}

		#if 0
		// Verify Data
		bootCodeRead.start_page	= bootCodeWrite.start_page;
		bootCodeRead.rw_size		= bootCodeWrite.rw_size;
		res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_READ_PAGE, (void *) & bootCodeRead);
		if ( res < 0)		// there is error on reading F/W
		{
			LPRINTF("Fail to Read Image\n");
			return ERR_FWUG_FAIL_CODEREADTFLASH;
		}
		if (memcmp(WriteBufAddr, pVerifyData, readsize) != 0)
		{
			LPRINTF("Fail to Compare Image\n");
			return ERR_FWUG_FAIL + 101;		// Verifying Error
		}
		LPRINTF(".");
		#endif
	}

	LPRINTF("\nWrite Code Completed\n");
#endif	
	return SUCCESS;
}

//extern unsigned long	InitRoutine_StartBase;
//extern unsigned long	InitRoutine_StartLimit;
extern unsigned long	InitRoutine_Start;
extern unsigned long	InitRoutine_End;
int FwdnWriteHeaderTFLASH(unsigned uFWSize)
{
#ifdef TRIFLASH_INCLUDE
	unsigned char		*pTempData, *pVerifyData, *pSource;
	unsigned int		uiCRC, uiSDBootHeader[4];
	int					res;
	unsigned int		uSize;	
	ioctl_diskrwpage_t	rwpage_1, rwpage_2;
	MMC_DISK_INFO_T		triflashDiskInfo;


	res			= FWDN_WRITE_BUFFER_SIZE;
	pTempData	= (unsigned char*)tempBuffer;
	pVerifyData	= pTempData + (res/2);
	
	//=====================================================================
	// Set SD Booting Header's Value ======================================
	//=====================================================================	
#if 0
	uiSDBootHeader[0] = ((unsigned)(FwdnWriteHeaderTFLASH)) & 0xF0000000;
	#if defined(TCC82XX) || defined(TCC83XX)
	uiSDBootHeader[1] = HwSDCFG;
	#elif defined(TCC81XX)
//	uiSDBootHeader[1] = 0x182C2400;
//	uiSDBootHeader[1] = 0xE7482140;  //eugeun_TCC80xx SDRAM 16bit
	uiSDBootHeader[1] = 0xA7482140;  //eugeun_TCC80xx SDRAM 32bit
//	uiSDBootHeader[1] = 0x00000000;  //eugeun_TCC80xx DDR 16bit
//	uiSDBootHeader[1] = 0xE7482000;
//	uiSDBootHeader[1] = 0xA7482000;
	#elif defined(TCC78X)
	uiSDBootHeader[1] = (uiSDBootHeader[0] == 0x20000000) ? HwSDCFG : HwVSDCFG;
	#elif defined(TCC79X)
	uiSDBootHeader[1] = HwSDCFG;	
	#endif
#else
	// TCC89x/92x ================
	uiSDBootHeader[0] = 0x40000003;
	uiSDBootHeader[1] = 0x40000000;
#endif
	uiSDBootHeader[2] = uFWSize;
#if 0
	uiSDBootHeader[3] = 0x5A45524F;	//OREZ
//#else
	// TCC80xx ===================
	uiSDBootHeader[3] = 0x400;	//eugeun_TCC80xx DDR 16bit DDR init. code�� size�� ���� �Է�.
#else
	// TCC89x/92x ================
	uiSDBootHeader[3] = 0x00000000;
#endif

	if (DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_GET_HIDDEN_SIZE, (void *) &triflashDiskInfo) < 0)
	{
		return ERR_FWUG_FAIL + 102;
	}

	//=====================================================================
	// Write DDR init. code ===============================================
	//=====================================================================
	memset(pTempData, 0x00, FWDN_WRITE_BUFFER_SIZE);
	//uSize					= 0;//(unsigned)InitRoutine_StartLimit - (unsigned)(pSource = (unsigned char *)InitRoutine_StartBase);
	uSize					= (unsigned)&InitRoutine_End - (unsigned)( pSource = (unsigned char *)&InitRoutine_Start );
	memcpy(pTempData, pSource, uSize);
	*(unsigned *)(pTempData+uSize)	= 0xE1A0F00E;	//	mov pc, lr : Return Code
	
	rwpage_1.buff			= pTempData;
	rwpage_1.rw_size		= (uSize+511)/512;
	rwpage_1.start_page		= SDMMC_GetHeaderAddr() - rwpage_1.rw_size;
	rwpage_2.buff			= pVerifyData;	
	rwpage_2.rw_size		= rwpage_1.rw_size;
	rwpage_2.start_page		= rwpage_1.start_page;
	
	res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_WRITE_PAGE, (void *) & rwpage_1);
	if (res < 0) return ERR_FWUG_FAIL_HEADERWRITETFLASH;

	res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_READ_PAGE, (void *) & rwpage_2);
	if (res < 0) return ERR_FWUG_FAIL_HEADERREADTFLASH;

	if (memcmp(pTempData, pVerifyData, uSize) != 0)
	{
		LPRINTF("Boot Header Verify Error\n");
		return ERR_FWUG_FAIL + 103;
	}
	
	//=====================================================================
	// Begin Writing Header to T-Flash ====================================
	//=====================================================================
	LPRINTF("Begin Writing Header to T-Flash\n");
	memset(pTempData, 0x00, FWDN_WRITE_BUFFER_SIZE);
	rwpage_1.start_page	= SDMMC_GetHeaderAddr();
	rwpage_1.rw_size		= 1;
	rwpage_1.buff			= pTempData;
	rwpage_2.start_page	= rwpage_1.start_page;
	rwpage_2.rw_size		= 1;
	rwpage_2.buff			= pVerifyData;

	if (g_uiFWDN_WriteSNFlag == 1)
	{
		DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_READ_PAGE, (void *) & rwpage_1);
		uiCRC = FWUG_CalcCrc8(pTempData, 512-4, CRC32_TABLE);
		if(word_of(pTempData + 512 - 4) != uiCRC)
			return (-1);
	}
	else
	{
		FWDN_FNT_InsertSN(pTempData+16);
	}

	// Set information for SD Boot (Start Addr, SDCFG, FW Size, "OREZ", MAX-ROMSIZE, HIDDEN SIZE)
	memcpy(pTempData, uiSDBootHeader, 16);
	word_of(pTempData + 128)	= gMAX_ROMSIZE_SD;							// [0x80] hidden Boot area size
	word_of(pTempData + 132)	= triflashDiskInfo.nHiddenSector[0];		// [0x84] hidden sector size
	word_of(pTempData + 136)	= 0xFFFFFFFF;								// [0x88] hidden drive size

	word_of(pTempData + 144)	= triflashDiskInfo.nHiddenSector[1];		// [0x90] hidden 02 sector size
	word_of(pTempData + 148)	= triflashDiskInfo.nHiddenSector[2];		// [0x94] hidden 03 sector size
	word_of(pTempData + 152)	= triflashDiskInfo.nHiddenSector[3];		// [0x98] hidden 04 sector size
	word_of(pTempData + 156)	= 0x54494E49;								// [0x9C] INIT (Last sector)
	
#if 1
	// TCC89x/92x ================
	word_of(pTempData + 192)	= 0x00000000;		// [0xC0] SDMMC port delay parameter..
	word_of(pTempData + 196)	= uSize;			// [0xC4] SDR Init Rom Size..	
	//word_of(pTempData + 196)	= 0x250;			// 92xx SDR Init Rom Size..	
	//word_of(pTempData + 196)	= 0x598;			// 89xx SDR Init Rom Size..		
#endif

	uiCRC = FWUG_CalcCrc8(pTempData, 512-4, CRC32_TABLE);
	word_of(pTempData + 512 - 4)	= uiCRC;
	
	//=====================================================================	
	// Write and Verify Header ============================================
	//=====================================================================		
	res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_WRITE_PAGE, (void *) & rwpage_1);
	if (res < 0) return ERR_FWUG_FAIL_HEADERWRITETFLASH;

	res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_READ_PAGE, (void *) & rwpage_2);
	if (res < 0) return ERR_FWUG_FAIL_HEADERREADTFLASH;

	if (memcmp(pTempData, pVerifyData, 512) != 0)
	{
		LPRINTF("Boot Header Verify Error\n");
		return ERR_FWUG_FAIL + 103;
	}
	
#endif
	LPRINTF("Write Header Completed\n");
	return 0;
}

int FwdnWriteTriflashFirmware(unsigned int uiROMFileSize)
{
#ifdef TRIFLASH_INCLUDE
	int				res;
	unsigned char		*buf;
	unsigned int		uiBufSize;
	ioctl_diskinfo_t 	disk_info;

	if (uiROMFileSize > gMAX_ROMSIZE_SD)
	{
		//UI_API_DrawPopUp2Line( "**ERROR**","Image Too Large");
		//TC_TimeDly(200);
		return ERR_FWUG_NOT_EXISTMEMORY;
	}

	buf = (unsigned char*)tempBuffer;
	uiBufSize = FWDN_WRITE_BUFFER_SIZE;

	if ( (res=DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_INITIALIZE, NULL)) < 0)
		return res;

	if ( (res=DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_GET_DISKINFO, (void *)&disk_info)) < 0)
		return res;

	if (disk_info.sector_size != 512)
		return -1;

	res = FwdnWriteCodeTriflash(uiROMFileSize, buf, uiBufSize);
	if(res != SUCCESS)
		return res;

	res = FwdnWriteHeaderTFLASH(uiROMFileSize);
	if(res != SUCCESS)
		return res;
#endif	
	return 0;
}

unsigned int	FwdnReadTriflashFirmware(unsigned int master)
{
	return 0;
}
#if 0
int FwdnGetTriflashSerial__(void)
{
	unsigned int	i,j;
	unsigned int	uiBootCodeHeaderAddr;
	unsigned int	uiSIDSize;
	unsigned int	uiSIDExistFlag;
	unsigned int	uiTempCrc;
	unsigned int	uiVerifyCrc;
	unsigned char	ucTempData[512];
	unsigned char	code, tmp;
	int 			iRev;

	/*----------------------------------------------------------------
					G E T	S E R I A L	N U M B E R
	----------------------------------------------------------------*/
	uiBootCodeHeaderAddr = g_mmc.size / 512 - (512*12) -2;			// Addresss of 1st Boot Code Header 
	iRev = DISK_ReadSector(DISK_DEVICE_TRIFLASH,  1, uiBootCodeHeaderAddr, 1, ucTempData);
	if ( iRev != SUCCESS )
	{
		uiBootCodeHeaderAddr = g_mmc.size / 512 - (512*6) -1;		// Addresss of 2nd Boot Code Header 
		iRev = DISK_ReadSector(DISK_DEVICE_TRIFLASH,  1, uiBootCodeHeaderAddr, 1, ucTempData);		
		if ( iRev != SUCCESS )
			return -1;
	}

	/*----------------------------------------------------------------
					V E R I F Y	S E R I A L	N U M B E R
	----------------------------------------------------------------*/
	if (!memcmp( &ucTempData[36], "ZERO", 4 ))
	{
		uiSIDSize	= 16;
		uiSIDExistFlag	= TRUE;
	}
	else if ((!memcmp( &ucTempData[36], "FWDN", 4 )) || (!memcmp( &ucTempData[36], "GANG", 4 )))
	{
		uiSIDSize	= 32;
		uiSIDExistFlag	= TRUE;
	}
	else
	{
		uiSIDSize	= 0;
		uiSIDExistFlag	= FALSE;
	}

	/* Check CRC */
	if ( uiSIDExistFlag == TRUE )
	{
		for ( j = 0; j < ( uiSIDSize >> 4 ); ++j )
		{
			/* Get CRC */
			uiVerifyCrc	= (ucTempData[(j*32)+32] << 24) ^
						  (ucTempData[(j*32)+33] << 16) ^
						  (ucTempData[(j*32)+34] << 8) ^
						  ucTempData[(j*32)+35];

			uiTempCrc = 0;
			for ( i = 0; i < 16; i++ )
			{
				code		= ucTempData[(j*32)+i+16];
				tmp			= code^uiTempCrc;
				uiTempCrc	= (uiTempCrc>>8)^CRC32_TABLE[tmp&0xFF];
			}

			/* Verify CRC */
			if ( uiVerifyCrc != uiTempCrc ) {
				if ( uiSIDSize == 16 ) {
					FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_16;			
				}else{
					FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_32;			
				}
				break;
			}
		}

		for ( i = 0; i < ( uiSIDSize >> 4 ); ++i )  {		// Copy Serial Number
			memcpy( &FWDN_DeviceInformation.DevSerialNumber[i*16], &ucTempData[i*32+16], 16 );
		}

		if ( uiSIDSize == 16 ) {
			FWDN_DeviceInformation.DevSerialNumberType = SN_VALID_16;			
		}else{
			FWDN_DeviceInformation.DevSerialNumberType = SN_VALID_32;			
		}
		return uiSIDSize;		
	}

	memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
	FWDN_DeviceInformation.DevSerialNumberType = SN_NOT_EXIST;	
	return -1;
}
#endif

int FwdnGetTriflashSerial(void)
{
#ifdef TRIFLASH_INCLUDE
	ioctl_diskinfo_t 	disk_info;
	ioctl_diskrwpage_t	bootCodeRead;
	unsigned char		readData[512];
	int				res;

	/*----------------------------------------------------------------
					G E T	S E R I A L	N U M B E R
	----------------------------------------------------------------*/
	if (DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_GET_DISKINFO, (void *)&disk_info) < 0)
	{
		return -1;
	}
	if (disk_info.sector_size != 512)
		return -1;

	bootCodeRead.start_page	= SDMMC_GetHeaderAddr();
	bootCodeRead.rw_size	= 1;
	bootCodeRead.buff		= readData;
	res = DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_READ_PAGE, (void *) &bootCodeRead);
	if ( res != 0) return res;

	/*----------------------------------------------------------------
					V E R I F Y	S E R I A L	N U M B E R
	----------------------------------------------------------------*/
	FWDN_FNT_VerifySN(readData, 16);
#endif	
	switch (FWDN_DeviceInformation.DevSerialNumberType)
	{
		case SN_VALID_16:	return 16;
		case SN_VALID_32:	return 32;
		case SN_INVALID_16:	return -16;
		case SN_INVALID_32:	return -32;
		default:	return -1;
	}
}

#if 0
int FwdnSetTriflashSerial__(unsigned char *ucData, unsigned int overwrite)
{
	unsigned int		uiSNOffset;
	unsigned int		uiBootCodeHeaderAddr;
	unsigned char		ucTempData[512];
	unsigned char		ucTempSpare[16];
	int					iRev;

	memset( FWDN_DeviceInformation.DevSerialNumber, 0x00, 32 );			
	g_uiFWDN_WriteSNFlag = 0;			
	g_uiFWDN_OverWriteSNFlag = 0;

	memcpy( FWDN_DeviceInformation.DevSerialNumber, ucData , 32 );
	g_uiFWDN_OverWriteSNFlag =  overwrite;

	if ( g_uiFWDN_OverWriteSNFlag )
	{
		g_uiFWDN_WriteSNFlag = 0;
		
		return -1;
	}
	else
	{
		uiSNOffset = 0;
		/*----------------------------------------------------------------
						G E T	S E R I A L	N U M B E R
		----------------------------------------------------------------*/
		uiBootCodeHeaderAddr = g_mmc.size / 512 - (512*12) -2;			// Addresss of 1st Boot Code Header 
		iRev = DISK_ReadSector(DISK_DEVICE_TRIFLASH,  1, uiBootCodeHeaderAddr, 1, ucTempData);
		if ( iRev != SUCCESS )
		{
			uiBootCodeHeaderAddr = g_mmc.size / 512 - (512*6) -1;		// Addresss of 2nd Boot Code Header 
			iRev = DISK_ReadSector(DISK_DEVICE_TRIFLASH,  1, uiBootCodeHeaderAddr, 1, ucTempData);		
			if ( iRev != SUCCESS )
				return -1;
		}
		iRev = FWDN_FNT_SetSN( ucTempData, uiSNOffset );
		if ( iRev != SUCCESS )
		{
			//FWDN_IO_SendResult(FWDN_FAILED_SET_SN, FAILURE);
			return -1;
		}
		else
		{
			//FWDN_IO_SendResult(FWDN_SUBFN_SET_SN, SUCCESS);
			return 0;
		}
	}
	return 0;
}
#endif

int FwdnSetTriflashSerial(unsigned char *ucData, unsigned int overwrite)
{
#ifdef TRIFLASH_INCLUDE
	ioctl_diskinfo_t 	disk_info;
	unsigned char		ucTempData[512];
	int				iRev;
	ioctl_diskrwpage_t	header;

	if (DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_GET_DISKINFO, (void *)&disk_info) < 0)
	{
		return -1;
	}
	if (disk_info.sector_size != 512)
		return -1;

	memcpy( FWDN_DeviceInformation.DevSerialNumber, ucData , 32);
	g_uiFWDN_OverWriteSNFlag	=  overwrite;
	g_uiFWDN_WriteSNFlag		= 0;

	if ( overwrite == 0 )
	{
		/*----------------------------------------------------------------
						G E T	S E R I A L	N U M B E R
		----------------------------------------------------------------*/
		header.start_page		= SDMMC_GetHeaderAddr();
		header.rw_size		= 1;
		header.buff			= ucTempData;
		iRev	=	DISK_Ioctl(DISK_DEVICE_TRIFLASH, DEV_BOOTCODE_READ_PAGE, (void *)&header);
		if(iRev != SUCCESS)
			return (-1);
		
		iRev = FWDN_FNT_SetSN(ucTempData, 16);
		#if 0
		if ( iRev != SUCCESS )
		{
			return -1;
		}
		else
		{
			return 0;
		}
		#endif
	}
#endif
	return 0;
}

