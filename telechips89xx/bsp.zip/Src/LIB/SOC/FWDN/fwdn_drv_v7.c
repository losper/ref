/****************************************************************************
 *   FileName    : Fwdn_drv_v7.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

/****************************************************************************

  Revision History

 ****************************************************************************

 ****************************************************************************/
#if defined(FWDN_V7)

#if defined(_LINUX_)
#include "common.h"
#endif

#if defined(_LINUX_) || defined(_WINCE_)
#include "fwupgrade.h"
#include "Disk.h"
#include "TC_File.h"
#include "fwdn_drv_v7.h"
#include "nand_drv.h"
#endif

#if !defined(_LINUX_)
#include "memory.h"
#endif

#if defined(_WINCE_)
extern void KITLOutputDebugString(const char* fmt, ...);
#endif

#define	byte_of(X)					( *(volatile unsigned char *)((X)) )

#ifdef TNFTL_V7_INCLUDE
#define Tbuffersize  		(264*512)
#else
#define Tbuffersize  		(128*512)
#endif
#define TbufferSectorSize	(Tbuffersize>>9)

static unsigned int fwdndBuf[Tbuffersize/4];
static unsigned int veriBuf[Tbuffersize/4];

//==============================================================
//
//		Global Variables
//
//==============================================================
static const unsigned char gFWDN_FirmwareStorage		=
	#ifdef SFLASH_INCLUDE
		FWDN_DISK_SFLASH
	#elif defined(NAND_INCLUDE)
		FWDN_DISK_NAND
	#elif defined(TRIFLASH_INCLUDE)
		FWDN_DISK_TRIFLASH
	#elif defined(HDD_INCLUDE)
		FWDN_DISK_NOR
	#else
	0//	#error	there is no device to store F/W image.
	#endif
;
static const unsigned char gFWDN_SerialNumberStorage	=
	#ifdef SFLASH_INCLUDE
		FWDN_DISK_SFLASH
	#elif defined(NAND_INCLUDE)
		FWDN_DISK_NAND
	#elif defined(TRIFLASH_INCLUDE)
		FWDN_DISK_TRIFLASH
	#elif defined(HDD_INCLUDE)
		FWDN_DISK_HDD
	#else
	0//	#error	there is no device to store F/W image.
	#endif
;
static unsigned int				gImagePosition;
static unsigned int				ResetHandler_ptr;

unsigned int					g_uiFWDN_OverWriteSNFlag;
unsigned int					g_uiFWDN_WriteSNFlag;
FWDN_DEVICE_INFORMATION			FWDN_DeviceInformation;
static NAND_DEVICE_INFO			gNAND_DEVICE_INFO;

static FXN_FWDN_DRV_FirmwareWrite_ReadFromHost		gfxnFWDN_DRV_FirmwareWrite_ReadFromHost;
static FXN_FWDN_DRV_Progress		gfxnFWDN_DRV_Progress = NULL;

unsigned int				gFWDN_DRV_ErrorCode;

#ifdef NAND_INCLUDE
// NAND's each disk's name
static const char FWDN_NAND_HD0_AREA_NAME[]	= "KERNEL";
#if defined(_WINCE_)
static const char FWDN_NAND_HD1_AREA_NAME[]	= "LOGO";
#else
static const char FWDN_NAND_HD1_AREA_NAME[]	= "NAND Hidden 1";
#endif
static const char FWDN_NAND_HD2_AREA_NAME[]	= "NAND Hidden 2";
static const char FWDN_NAND_HD3_AREA_NAME[]	= "NAND Hidden 3";
static const char FWDN_NAND_HD4_AREA_NAME[]	= "NAND Hidden 4";
static const char FWDN_NAND_HD5_AREA_NAME[]	= "NAND Hidden 5";
static const char FWDN_NAND_HD6_AREA_NAME[]	= "NAND Hidden 6";
static const char FWDN_NAND_HD7_AREA_NAME[]	= "NAND Hidden 7";
static const char FWDN_NAND_HD8_AREA_NAME[]	= "NAND Hidden 8";
static const char FWDN_NAND_HD9_AREA_NAME[]	= "NAND Hidden 9";
static const char FWDN_NAND_HD10_AREA_NAME[]	= "NAND Hidden 10";
static const char *FWDN_NAND_HD_AREA_NAME[] = {
	FWDN_NAND_HD0_AREA_NAME,
	FWDN_NAND_HD1_AREA_NAME,
	FWDN_NAND_HD2_AREA_NAME,
	FWDN_NAND_HD3_AREA_NAME,
	FWDN_NAND_HD4_AREA_NAME,
	FWDN_NAND_HD5_AREA_NAME,
	FWDN_NAND_HD6_AREA_NAME,
	FWDN_NAND_HD7_AREA_NAME,
	FWDN_NAND_HD8_AREA_NAME,
	FWDN_NAND_HD9_AREA_NAME,
	FWDN_NAND_HD10_AREA_NAME,
};
static const char FWDN_NAND_DATA_AREA_NAME[]	= "NAND Data";
#if defined(_LINUX_)
static const char FWDN_NAND_MTD_AREA_NAME[]	= "MTD";
#endif
#endif

#ifdef TRIFLASH_INCLUDE
// TRIFLASH_INCLUDE's each disk's name
static const char FWDN_SD_HD0_AREA_NAME[]	= "SD Hidden";
//static const char FWDN_SD_HD1_AREA_NAME[]	= "SD Hidden 1";
//static const char FWDN_SD_HD2_AREA_NAME[]	= "SD Hidden 2";
//static const char FWDN_SD_HD3_AREA_NAME[]	= "SD Hidden 3";
//static const char FWDN_SD_HD4_AREA_NAME[]	= "SD Hidden 4";
//static const char FWDN_SD_HD5_AREA_NAME[]	= "SD Hidden 5";
//static const char FWDN_SD_HD6_AREA_NAME[]	= "SD Hidden 6";
//static const char FWDN_SD_HD7_AREA_NAME[]	= "SD Hidden 7";
//static const char FWDN_SD_HD8_AREA_NAME[]	= "SD Hidden 8";
//static const char FWDN_SD_HD9_AREA_NAME[]	= "SD Hidden 9";
//static const char FWDN_SD_HD10_AREA_NAME[]	= "SD Hidden 10";
static const char *FWDN_SD_HD_AREA_NAME[] = {
	FWDN_SD_HD0_AREA_NAME,
	//FWDN_SD_HD1_AREA_NAME,
	//FWDN_SD_HD2_AREA_NAME,
	//FWDN_SD_HD3_AREA_NAME,
	//FWDN_SD_HD4_AREA_NAME,
	//FWDN_SD_HD5_AREA_NAME,
	//FWDN_SD_HD6_AREA_NAME,
	//FWDN_SD_HD7_AREA_NAME,
	//FWDN_SD_HD8_AREA_NAME,
	//FWDN_SD_HD9_AREA_NAME,
	//FWDN_SD_HD10_AREA_NAME,
};
static const char FWDN_SD_DATA_AREA_NAME[]	= "SD Data";
#endif

//==============================================================
//
//		External Variables
//
//==============================================================
#if defined(_LINUX_) || defined(_WINCE_)
extern unsigned long				_start;
#else
extern unsigned long				ResetHandler;
#endif
extern unsigned long				FirmwareSize;

//extern unsigned long				ImageRwBase;

//extern char							FirmwareVersion[];

extern unsigned int					gMAX_ROMSIZE;
extern const unsigned				CRC32_TABLE[];
//==============================================================
//
//		External Functionss
//
//==============================================================

void initSourcePosition(void)
{
#if defined (NKUSE)
#else
#if defined(_LINUX_) || defined(_WINCE_)
	ResetHandler_ptr	= (unsigned int ) &_start;
#else
	ResetHandler_ptr	= (unsigned int ) & ResetHandler;
#endif
	gImagePosition = ResetHandler_ptr;
#endif
}

#if 0
/**********************************************************
*	void FWDN_InitCACHE(void)
*
*	Input		: None
*	Output		:
*	Return		: None
*
*	Description	: Region setting & Cache initializing for FWDN
***********************************************************/
void FWDN_InitCACHE(void)
{
}
#endif

//void FWDN_CheckOption(void)
//{
//#if defined (NKUSE)
//#else
//	if (byte_of(FirmwareVersion) != 'V')
//	{
//		/*
//			Set Bit Field of Booting option
//			[0] : 1 = Execute Low-level format when booting
//		*/
//
//		// Restore ROM image
//		byte_of(FirmwareVersion)	= 'V';
//	}
//#endif
//}

void FWDN_DRV_Reset(void)
{
	// goto reset vector

	FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_RESET_NOT_SUPPORT);
}

int FWDN_DRV_SessionStart(void)
{
#if defined(_WINCE_)
	KITLOutputDebugString("===== FWDN Session Start! =====\n");
#endif

	return TRUE;
}

int FWDN_DRV_SessionEnd(unsigned int bSuccess)
{
	if(bSuccess)
	{
#if defined(_WINCE_)
		KITLOutputDebugString("===== FWDN Session End! =====\n");
#endif
	}
	else
	{
#if defined(_WINCE_)
		KITLOutputDebugString("===== FWDN Session is Failed!=====\n");
#endif
	}

	return TRUE;
}

static void FWDN_DRV_TNFTL_CallBackHandler( unsigned short SMC_DrvNo, unsigned short STATUS_CODE, unsigned int WParam )
{
	if( STATUS_CODE == TNFTL_CALLBACK_LCD_FORMAT_PROCESS )
	{
		if(gfxnFWDN_DRV_Progress != NULL)
		{
			(*gfxnFWDN_DRV_Progress)((unsigned int)WParam);
		}
	}
	else if ( STATUS_CODE == TNFTL_CALLBACK_LCD_MAKE_HIDDEN_PAGE_START )
	{
	}
	else if ( STATUS_CODE == TNFTL_CALLBACK_LCD_MAKE_HIDDEN_PAGE_STOP )
	{
	}
}

int FWDN_DRV_Init(unsigned int bmFlag, const FXN_FWDN_DRV_Progress fxnFwdnDrvProgress, char *message, unsigned int messageSize)
{
	gfxnFWDN_DRV_Progress = fxnFwdnDrvProgress;

	if(bmFlag & FWDN_DEVICE_INIT_BITMAP_LOW_FORMAT)
	{
#ifdef NAND_INCLUDE
		TNFTL_SetCallBackHandler( FWDN_DRV_TNFTL_CallBackHandler );
		//Low-Level Format
		NAND_LowLevelFormat(1);
#endif
	}
	if(bmFlag & FWDN_DEVICE_INIT_BITMAP_LOW_FORMAT_LEVEL2)
	{
#ifdef NAND_INCLUDE
		TNFTL_SetCallBackHandler( FWDN_DRV_TNFTL_CallBackHandler );
		//Low-Level Format
		NAND_LowLevelFormat(2);
#endif
	}
	if(bmFlag & FWDN_DEVICE_INIT_BITMAP_DUMP)
	{
#ifdef NAND_INCLUDE
		//Total-Image Dump
		NAND_LowLevelFormat(3);
#endif
	}

#ifdef NAND_INCLUDE
	TNFTL_SetCallBackHandler( FWDN_DRV_TNFTL_CallBackHandler );
	//#ifdef TNFTL_V7_INCLUDE
	//NAND_SetCallBackHandler( pCallBackHandler );
	//#else
    NAND_Init();
	//#endif

	if(bmFlag & FWDN_DEVICE_INIT_BITMAP_UPDATE)
	{
		// RomFile�� Size�� Init
		NAND_SetFlagOfChangeAreaSize( ENABLE );
		if( DISK_Ioctl( DISK_DEVICE_NAND, DEV_INITIALIZE, NULL ) != SUCCESS )
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_IOCTRL_DEV_INITIALIZE);
			return -1;
		}
	}
	else
	{
		if ( TNFTL_CheckIsExistBMP( gNAND_DrvInfo[0].NFTLDrvInfo ) != SUCCESS )	// NAND�� ������ ����ϴ� BMP�� �ִ��� Ȯ��
		{
			// BMP�� ���� ��� RomFile�� Size�� Init
			NAND_SetFlagOfChangeAreaSize( ENABLE );
			if( DISK_Ioctl( DISK_DEVICE_NAND, DEV_INITIALIZE, NULL ) != SUCCESS )
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_IOCTRL_DEV_INITIALIZE);
				return -1;
			}
		}
		else
		{
			// BMP�� �ִ� ��� NAND�� Hidden, Multi Hidden�� Seeting�� �״�� ����.
			NAND_SetFlagOfChangeAreaSize( DISABLE );
			if( DISK_Ioctl( DISK_DEVICE_NAND, DEV_INITIALIZE, NULL ) != SUCCESS )
			{
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->DrvReturnValue != ERR_TNFTL_OVERSIZE_MULTIHIDDEN_NUM )
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_IOCTRL_DEV_INITIALIZE);
					return -1;
				}
			}
		}

		// check partition difference
		{
			unsigned int i;
			NAND_PARTITION_INFO partitionRom,partitionNAND;

			memset((void*)&partitionRom,0x00,sizeof(partitionRom));
			memset((void*)&partitionNAND,0x00,sizeof(partitionNAND));

#ifdef TNFTL_V7_INCLUDE
			//================================
			// Rom File Hidden Info
			//================================
			partitionRom.HiddenNum = gTNFTL_ExtPartitionInfo[0].ExtendedPartitionNum;
			for ( i = 0 ; i < partitionRom.HiddenNum ; ++i )
				partitionRom.HiddenPageSize[i] = gTNFTL_ExtPartitionInfo[0].ExtPartitionSize[i];
			partitionRom.RO_PageSize = gTNFTL_ExtPartitionInfo[0].ROAreaSize;

			//================================
			// Current NAND Hidden Info
			//================================
			if ( gNAND_DrvInfo[0].NFTLDrvInfo->DrvReturnValue == ERR_TNFTL_OVERSIZE_MULTIHIDDEN_NUM )
			{
				partitionNAND.HiddenNum = 0xFFFFFFFF;
			}
			else
			{
				partitionNAND.HiddenNum = gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo;
				for ( i = 0 ; i < partitionNAND.HiddenNum ; ++i )
					partitionNAND.HiddenPageSize[i] = gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[i].TotalSectorSize;
			}
			partitionNAND.RO_PageSize = gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaSize >> 20;
#else
			//================================
			// Rom File Hidden Info
			//================================
			partitionRom.HiddenPageSize[0] = gTNFTL_HiddenInfo[0].HiddenPageSize;
			partitionRom.HiddenNum = gTNFTL_HiddenInfo[0].MultiHiddenAreaNum + 1;
			for ( i = 1 ; i < partitionRom.HiddenNum ; ++i )
				partitionRom.HiddenPageSize[i] = gTNFTL_HiddenInfo[0].MultiHiddenSize[i-1];
			partitionRom.RO_PageSize = gTNFTL_HiddenInfo[0].ROAreaSize;
			
			//================================
			// Current NAND Hidden Info
			//================================
			partitionNAND.HiddenPageSize[0] = gNAND_DrvInfo[0].NFTLDrvInfo->HDArea.TotalSectorSize;
			if ( gNAND_DrvInfo[0].NFTLDrvInfo->DrvReturnValue == ERR_TNFTL_OVERSIZE_MULTIHIDDEN_NUM )
			{
				partitionNAND.HiddenNum = 0xFFFFFFFF;
			}
			else
			{
				partitionNAND.HiddenNum = gNAND_DrvInfo[0].NFTLDrvInfo->MultiHiddendNums + 1;
				for ( i = 1 ; i < partitionNAND.HiddenNum ; ++i )
					partitionNAND.HiddenPageSize[i] = gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[i-1].TotalSectorSize;
			}
			partitionNAND.RO_PageSize = gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaSize >> 20;
#endif

			if(memcmp((void*)&partitionRom,(void*)&partitionNAND,sizeof(partitionRom))!=0)
			{
				memcpy(message, "NAND partition changes is detected.\nIt will erase whole NAND.", messageSize);
				message[messageSize-1] = 0;
				return 1;
			}
		}
	}
#endif

	return 0;
}

static void _loc_strncpy(char *dst, const char *src, unsigned int n)
{
	while(n--)
	{
		*dst++=*src;
		if(*src++==0)
			break;
	}
}

static int _loc_strcmp(const char *dst, const char *src)
{
	while( *dst!=0 || *src!=0 )
	{
		if( *dst++ != *src++ )
			return -1;
	}
	return 0;
}

//static int _loc_strncmp(void *dst, void *src, unsigned int n)
//{
//	while(n--)
//	{
//		if(*dst++!=*src)
//			return -1;
//		if(*src++==0)
//			break;
//	}
//	return 0;
//}

static void _loc_register_area(unsigned int index, const char *name, unsigned int nSector)
{
	memset(FWDN_DeviceInformation.area[index].name,0,16);
	_loc_strncpy(FWDN_DeviceInformation.area[index].name,name,16);
	FWDN_DeviceInformation.area[index].nSector = nSector;
}

//static void _loc_register_default_disk(unsigned int diskID)
//{
//	_loc_register_disk(0,diskID);
//}

pFWDN_DEVICE_INFORMATION FWDN_DRV_GetDeviceInfo(void)
{
#if defined (NKUSE)
#else
	unsigned int i,nDisk=0;
	switch(gFWDN_SerialNumberStorage)
	{
		//#ifndef WITHOUT_FILESYSTEM
		#ifdef NAND_INCLUDE
		case FWDN_DISK_NAND:
			FwdnGetNandSerial();
			break;
		#endif
		#ifdef 	TRIFLASH_INCLUDE
		case FWDN_DISK_TRIFLASH:
			FwdnGetTriflashSerial();
			break;
		#endif
		//#endif //WITHOUT_FILESYSTEM

		#ifdef HDD_INCLUDE
		case FWDN_DISK_HDD:
			FwdnGetNorSerial();
			break;
		#endif
		#ifdef SFLASH_INCLUDE
		case FWDN_DISK_SFLASH:
			FwdnGetSFlashSerial();
			break;
		#endif
	}

	// Reset All Area Information
	for(i=0;i<FWDN_AREA_LIST_MAX;i++)
		_loc_register_area(i,"",0);

#ifdef NAND_INCLUDE
#ifdef TNFTL_V7_INCLUDE
	for(i=0; i<gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo;i++)
	{
		_loc_register_area(
						nDisk++,
						FWDN_NAND_HD_AREA_NAME[i],
						gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[i].TotalSectorSize
		);
	}

	_loc_register_area(
					nDisk++,
					FWDN_NAND_DATA_AREA_NAME,
					gNAND_DrvInfo[0].NFTLDrvInfo->PriPartition.TotalSectorSize
	);

#if defined(_LINUX_)
	if(gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaSize)
	{
		_loc_register_area(
						nDisk++,
						FWDN_NAND_MTD_AREA_NAME,
						(gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaSize+511)>>9
		);
	}
#endif
#else
	_loc_register_area(
					nDisk++,
					FWDN_NAND_HD_AREA_NAME[0],
					gNAND_DrvInfo[0].NFTLDrvInfo->HDArea.TotalSectorSize
	);
	for(i=0;i<gNAND_DrvInfo[0].NFTLDrvInfo->MultiHiddendNums;i++)
	{
		_loc_register_area(
						nDisk++,
						FWDN_NAND_HD_AREA_NAME[i+1],
						gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[i].TotalSectorSize
		);
	}

	_loc_register_area(
					nDisk++,
					FWDN_NAND_DATA_AREA_NAME,
					gNAND_DrvInfo[0].NFTLDrvInfo->DTArea.TotalSectorSize
	);
#endif
#endif

#ifdef TRIFLASH_INCLUDE
	for(i=0; i</*SD hidden partition number*/;i++)
	{
		_loc_register_area(
						nDisk++,
						FWDN_SD_HD_AREA_NAME[i],
						/*Total size of each hidden partition*/
		);
	}

	_loc_register_area(
					nDisk++,
					FWDN_SD_DATA_AREA_NAME,
					/*SD Total Size*/
	);
#endif

#endif
	return &FWDN_DeviceInformation;
}

int	FWDN_DRV_SerialNumberWrite(unsigned char *serial, unsigned int overwrite)
{
	int	res	= -1;

	#ifndef WITHOUT_FILESYSTEM
		TC_SyncDrives(-1, 1);	// clean & flush entire cache
	#endif

	switch (gFWDN_SerialNumberStorage) {
		//#ifndef WITHOUT_FILESYSTEM
		#ifdef NAND_INCLUDE
		case FWDN_DISK_NAND:
			res = FwdnSetNandSerial( serial, overwrite);
			break;
		#endif
		#ifdef TRIFLASH_INCLUDE
		case FWDN_DISK_TRIFLASH:
			res = FwdnSetTriflashSerial( serial, overwrite);
			break;
		#endif
		//#endif

		#ifdef HDD_INCLUDE
		case FWDN_DISK_HDD:
			res = FwdnSetNorSerial( serial, overwrite);
			break;
		#endif
		#ifdef SFLASH_INCLUDE
		case FWDN_DISK_SFLASH:
			res = FwdnSetSFlashSerial( serial, overwrite);
			break;
		#endif
	}

	if ( res == 0)
		return TRUE;
	else
		return FALSE;
}

int FWDN_DRV_FirmwareWrite(unsigned int fwSize, FXN_FWDN_DRV_FirmwareWrite_ReadFromHost fxnFWDN_DRV_FirmwareWrite_ReadFromHost)
{
	gfxnFWDN_DRV_FirmwareWrite_ReadFromHost = fxnFWDN_DRV_FirmwareWrite_ReadFromHost;

	#ifndef WITHOUT_FILESYSTEM
		TC_SyncDrives(-1, 1);	// clean & flush entire cache
	#endif
	switch (gFWDN_FirmwareStorage)
	{
		//#ifndef WITHOUT_FILESYSTEM
		#ifdef NAND_INCLUDE
		case FWDN_DISK_NAND:
			return 	FwdnWriteNandFirmware(fwSize);
		#endif
		#ifdef TRIFLASH_INCLUDE
		case FWDN_DISK_TRIFLASH:
			return	FwdnWriteTriflashFirmware(fwSize);
		#endif
		//#endif //WITHOUT_FILESYSTEM

		#ifdef HDD_INCLUDE
		case FWDN_DISK_HDD:
		case FWDN_DISK_NOR:
			return	FwdnWriteNorFlashFirmware(fwSize);
		#endif

		#ifdef SFLASH_INCLUDE
		case FWDN_DISK_SFLASH:
			gMAX_ROMSIZE	= 0x400000;
			return	FwdnWriteSFlashFirmware(0, (unsigned)&FWDN_DRV_FirmwareWrite, fwSize);
		#endif
	}

	return	0;
}

int FWDN_DRV_FirmwareWrite_Read(unsigned char *buff, unsigned int size, unsigned int percent)
{
	int					res;
	unsigned int		readSize;
	//unsigned int		ImageDataBase;
	unsigned int		ImageAddr;

	readSize		= 0;
	//ImageDataBase	= ImageRwBase;
	ImageAddr		= gImagePosition - ResetHandler_ptr;

	//if( ImageAddr < ImageDataBase )
	//{
	//	if( (ImageAddr+size) <= ImageDataBase )
	//		readSize = size;
	//	else
	//		readSize = ImageDataBase - ImageAddr;
	//
	//	memcpy(buff, (void *)gImagePosition, readSize);
	//	gImagePosition += readSize;
	//	size -= readSize;
	//}

	ImageAddr		= gImagePosition - ResetHandler_ptr;
	res = (*gfxnFWDN_DRV_FirmwareWrite_ReadFromHost)( (unsigned char *)((unsigned int)buff+readSize), size, ImageAddr, percent);
	if ( res < 0)
		return res;
	gImagePosition += size;
	readSize += size;

	return readSize;
}

int _loc_AreaRead(char *name, unsigned int lba, unsigned short nSector, void *buff)
{
	unsigned int i;

#ifdef NAND_INCLUDE
#ifdef TNFTL_V7_INCLUDE
	for( i = 0; i < gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo; i++ )
	{
		if ( i == 0 )	// Hidden		--> ExtPartition [0]
		{
			if( _loc_strcmp(FWDN_NAND_HD_AREA_NAME[0],name) == 0 )
			{
				return DISK_HDReadSector( DISK_DEVICE_NAND, lba, nSector, buff );
			}
		}
		else			// Multi Hidden --> ExtPartition [1 ~ ]
		{
			if( _loc_strcmp(FWDN_NAND_HD_AREA_NAME[i],name) == 0 )
			{
				//return NAND_MHD_ReadSector( 0, i, lba, (U32)nSector, buff );
				return DISK_ReadSector(DISK_DEVICE_NAND_HD, i-1, lba, nSector, buff );
			}
		}
	}
#else
	if( _loc_strcmp(FWDN_NAND_HD_AREA_NAME[0],name) == 0 )
		return DISK_HDReadSector(DISK_DEVICE_NAND, lba, nSector, buff);
	for(i=0;i<gNAND_DrvInfo[0].NFTLDrvInfo->MultiHiddendNums;i++)
	{
		if( _loc_strcmp(FWDN_NAND_HD_AREA_NAME[i+1],name) == 0 )
			return NAND_MHD_ReadSector(0,i,lba,(U32)nSector,buff);
	}
#endif

	if( _loc_strcmp(FWDN_NAND_DATA_AREA_NAME,name) == 0 )
		return DISK_ReadSector(DISK_DEVICE_NAND, 0, lba, nSector, buff);
#endif

	return -1;
}

#if defined(_LINUX_)
extern int NAND_MTD_Init( U32* rMTDStBlk, U32* rMTDEdBlk );
extern int NAND_MTD_WritePage( U32 nPageAddr, U8* nPageBuffer );
extern int NAND_MTD_ReadPage( U32 nPageAddr, U8* nPageBuffer );
int _loc_MtdWrite(unsigned int lba, unsigned int nSector, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData)
{
	unsigned int	i;
	int				res = 0;
	unsigned int	rMTDStBlk, rMTDEdBlk;
	unsigned int	nPageAddr;

	unsigned char	*readBuf = (unsigned char *)fwdndBuf;
	unsigned char	*verifyBuf = (unsigned char *)veriBuf;

	unsigned int	readBufSize;
	unsigned int	readBytes, remain;
	unsigned int	startpageParam;

	//#define TEST_BUF

	#ifdef TEST_BUF		/* 09.05.11 */
	unsigned char	*nPageBuffer;

	nPageBuffer = 0x40100000;
	if( fxnFwdnDrvRequestData(nPageBuffer, sizebyte) != sizebyte )
		res = -1;
	#endif /* TEST_BUG */

	readBufSize	= ( 2048 + 512 );		// 1Block Size

	res = NAND_MTD_Init( &rMTDStBlk, &rMTDEdBlk );
	if ( res != 0 )
		return res;

	if (readBufSize > nSector<<9)
		readBufSize	= nSector<<9;
	
	//1 Receive Data and Hidden Write
	startpageParam	= 0;
	remain			= nSector<<9;

	while (remain > 0)
	{
		for ( i = rMTDStBlk; i < rMTDEdBlk; ++i )
		{
			nPageAddr = i << gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;
			res = NAND_IO_EraseBlock( &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0], nPageAddr, INTER_LEAVE_OFF );
			if ( res == SUCCESS )
			{
				rMTDStBlk = i + 1;
				break;
			}
		}

		if( res >= 0 )
		{
			for ( i = 0; i < gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PpB; ++i )
			{
				if( remain > readBufSize )
				{
					readBytes = readBufSize;
				}
				else
				{
					memset(readBuf, 0xFF, readBufSize);
					readBytes = remain;
				}

				#ifdef TEST_BUF		/* 09.05.11 */
				memcpy( readBuf, nPageBuffer, readBytes );
				#else
				//printf("\nRemainByte:%d, readBytes:%d", remain, readBytes);
				if( fxnFwdnDrvRequestData(readBuf, readBytes) != readBytes )
					res = -1;
				#endif /* TEST_BUF */

				if( NAND_MTD_WritePage( nPageAddr + i, readBuf ) != SUCCESS )
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_AREA_WRITE);
					res = -1;
				}
				else if( NAND_MTD_ReadPage( nPageAddr + i, verifyBuf ) != SUCCESS )
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_AREA_READ);
					res = -1;
				}
				else if (memcmp(readBuf, verifyBuf, (2048+32)) != 0)
				{
					FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_AREA_WRITE_COMPARE);
					res = -1;
				}

				#ifdef TEST_BUF		/* 09.05.11 */
				nPageBuffer += readBytes;
				#endif
				//printf("\n..");
				remain	-= readBytes;
				if ( remain == 0 )
				{
					res = 0;
					goto MTD_WRITE_COMPLETE;
				}
			}
		}
	}

MTD_WRITE_COMPLETE:

	if( res >= 0 )
		return 0;
	else
		return -1;
}
#endif

int _loc_AreaWrite(char *name, unsigned int lba, unsigned short nSector, void *buff)
{
	unsigned int i;

#ifdef NAND_INCLUDE
#ifdef TNFTL_V7_INCLUDE
	for( i = 0; i < gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo; i++ )
	{
		if ( i == 0 )
		{
			if( _loc_strcmp(FWDN_NAND_HD_AREA_NAME[0],name) == 0 )
			{
				return DISK_HDWriteSector( DISK_DEVICE_NAND, lba, nSector, buff );
			}
		}
		else
		{			
			if( _loc_strcmp(FWDN_NAND_HD_AREA_NAME[i],name) == 0 )
			{
				//return NAND_MHD_WriteSector( 0, i, lba, (U32)nSector, buff );
				return DISK_WriteSector(DISK_DEVICE_NAND_HD, i-1, lba, nSector, buff );
			}
		}
	}
#else
	if( _loc_strcmp(FWDN_NAND_HD_AREA_NAME[0],name) == 0 )
		return DISK_HDWriteSector(DISK_DEVICE_NAND, lba, nSector, buff);
	for(i=0;i<gNAND_DrvInfo[0].NFTLDrvInfo->MultiHiddendNums;i++)
	{
		if( _loc_strcmp(FWDN_NAND_HD_AREA_NAME[i+1],name) == 0 )
		{
			return NAND_MHD_WriteSector(0,i,lba,(U32)nSector,buff);
		}
	}
#endif

	if( _loc_strcmp(FWDN_NAND_DATA_AREA_NAME,name) == 0 )
		return DISK_WriteSector(DISK_DEVICE_NAND, 0, lba, nSector, buff);
#endif

	return -1;
}

#if 0//TNFTL_V7_INCLUDE
int FWDN_DRV_NAND_GANG_Format(void)
{
#ifdef NAND_INCLUDE
	return NAND_LowLevelFormat();
#endif
	return -1;
}

int FWDN_DRV_NAND_GANG_Write( NAND_PART_INFO *sNandPartInfo, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData )
{
	unsigned int 		i, j;
	unsigned int		nBlockNum;
	unsigned int		nBlockAddr, nPageAddr;
	unsigned int		nGangStBlk, nGangEdBlk;
	unsigned int		nBlockSize, nBlockSectorSize;
	unsigned int		nGoodBlockListSize, nGoodBlockIndex;
	unsigned short 		nReceiveSector, nReceiveSectorCount;
	unsigned char		bBlkArea;
	unsigned char		cSpare[32];
	unsigned char 		*receiveBuf = (unsigned char *)fwdndBuf;
	unsigned char		*nPageBuffer;
	int			 		res = -1;
	unsigned int		*pGoodBlockList;
	unsigned int 		nCRC;

	nBlockNum 		= sNandPartInfo->TotalBlockNum;
	nGangStBlk 		= sNandPartInfo->BlockUpperLimit;
	nGangEdBlk 		= sNandPartInfo->BlockLowerLimit;

	nBlockSize 			= ( gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PageSize 
						+ gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.SpareSize ) << gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;

	pGoodBlockList		= gDisplayBuff2;
	nGoodBlockListSize 	= DISPLAY_IMAGE_SIZE >> 2;
	nGoodBlockIndex		= 0;

	nBlockSectorSize  	= ((nBlockSize + 511 ) >> 9 );
	
	//==============================
	// Area Block Clear
	//==============================
	if ( sNandPartInfo->PartitionBlockMark == TNFTL_BLOCK_AREA_NANDBOOT_AREA )
	{
		for ( i = nGangStBlk; i < nGangEdBlk; ++i )
		{
			nPageAddr = i << gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;
			NAND_IO_EraseBlock( &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0], nPageAddr, INTER_LEAVE_OFF );
		}
	}
	else
	{
		for ( i = nGangStBlk; i < nGangEdBlk; ++i )
		{	
			res = TNFTL_SpareGetDataBlock( gNAND_DrvInfo[0].NFTLDrvInfo, i, 0, 1, cSpare );
		}
		
		bBlkArea = ( cSpare[2] & TNFTL_BLOCK_AREA_MASK );

		if ( bBlkArea == sNandPartInfo->PartitionBlockMark )
		{
			nPageAddr = i << gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;
			NAND_IO_EraseBlock( &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0], nPageAddr, INTER_LEAVE_OFF );
		}
	}

	while ( nBlockNum )
	{	
		if ( nGangStBlk == (nGangEdBlk + 1 ))
			return FALSE;
		
		for ( i = nGangStBlk; i < nGangEdBlk + 1; ++i )
		{
			if ( sNandPartInfo->PartitionBlockMark == TNFTL_BLOCK_AREA_NANDBOOT_AREA )
			{
				nPageAddr = i << gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;
				res = NAND_IO_EraseBlock( &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0], nPageAddr, INTER_LEAVE_OFF );
				if ( res == SUCCESS )
				{
					pGoodBlockList[nGoodBlockIndex] = i;
					++nGoodBlockIndex;
					
					//res = TRUE;
					nGangStBlk = ( i + 1 );
					break;
				}
			}
			else
			{
				res = TNFTL_SpareGetDataBlock( gNAND_DrvInfo[0].NFTLDrvInfo, i, 0, 1, cSpare );
				if (( cSpare[2] == 0xFF ) && ( cSpare[5] == 0xFF ) && ( cSpare[6] == 0xFF ) && ( cSpare[7] == 0xFF ))
				{
					nPageAddr = i << gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;
					res = NAND_IO_EraseBlock( &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0], nPageAddr, INTER_LEAVE_OFF );
					if ( res == SUCCESS )
					{
						pGoodBlockList[nGoodBlockIndex] = i;
						++nGoodBlockIndex;
						
						//res = TRUE;
						nGangStBlk = ( i + 1 );
						break;
					}
				}				
			}
		}

		nReceiveSectorCount = nBlockSectorSize;
		nPageBuffer = receiveBuf;

		while(nReceiveSectorCount)
		{
			if( nReceiveSectorCount > TbufferSectorSize )
				nReceiveSector = TbufferSectorSize;
			else
				nReceiveSector = (unsigned short)nReceiveSectorCount;

			if( fxnFwdnDrvRequestData(receiveBuf, nReceiveSector << 9 ) != 0 )
				res = -1;
			
			nReceiveSectorCount -= nReceiveSector;
		}

		if ( res == SUCCESS )
		{
			for ( j = 0; j < gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PpB; ++j )
			{
				NAND_GANG_WritePage( nPageAddr + j, nPageBuffer );
				nPageBuffer += ( gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PageSize + gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.SpareSize );
			}
		}

		nBlockNum -= 1;

		if ( nBlockNum == 0 )
		{
			res = SUCCESS;
			goto GANG_WRITE_COMPLETE;
		}
	}

GANG_WRITE_COMPLETE:

	// Check CRC
	nPageBuffer		= receiveBuf;
	nBlockNum 		= sNandPartInfo->TotalBlockNum;
	nCRC 			= 0;
	
	for ( i = 0; i < nBlockNum; ++i )
	{
		nBlockAddr	= pGoodBlockList[i];
		nPageAddr 	= nBlockAddr << gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;

		for ( j = 0; j < gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PpB; ++j )
		{
			res = NAND_GANG_ReadPage( nPageAddr + j, nPageBuffer );
			if ( res != SUCCESS )
				return FALSE;

			nCRC = FWUG_CalcCrc8I( nCRC, nPageBuffer,(unsigned int)(gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PageSize),CRC32_TABLE );				
		}
	}

	if(res==SUCCESS)
		return TRUE;
	else
		return FALSE;
}
#endif


int FWDN_DRV_AREA_Write(char *name, unsigned int lba, unsigned int nSector, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData)
{
	unsigned char *receiveBuf = (unsigned char *)fwdndBuf;
	//unsigned char *verifyBuf  = (unsigned char *)veriBuf;

	unsigned short nReceiveSector;

#if defined(_LINUX_)
	if( _loc_strcmp(FWDN_NAND_MTD_AREA_NAME,name) == 0 )
	{
		if(_loc_MtdWrite(lba, nSector, fxnFwdnDrvRequestData)!=0)
		{
			return FALSE;
		}
		return TRUE;
	}
#endif

	while(nSector)
	{
		unsigned int nBundle;
		if( nSector > (0x80000000>>9) )
			nBundle = 0x80000000>>9;
		else
			nBundle = nSector;
		nSector -= nBundle;
		//VTC_ReceiveData_SetTotalSize(nBundle<<9);
		while(nBundle)
		{
			if( nBundle > TbufferSectorSize )
				nReceiveSector = TbufferSectorSize;
			else
				nReceiveSector = (unsigned short)nBundle;

			if( fxnFwdnDrvRequestData(receiveBuf, nReceiveSector<<9) != 0 )
			{
				return FALSE;
			}

			if(_loc_AreaWrite(name,lba,nReceiveSector,receiveBuf)!=0)
			{
				FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_AREA_WRITE);
				return FALSE;
			}
			//else if(_loc_DiskRead(name,lba,nReceiveSector,verifyBuf)!=0)
			//{
			//	FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_AREA_READ);
			//	return FALSE;
			//}
			//else if (memcmp(receiveBuf, verifyBuf, nReceiveSector<<9) != 0)
			//{
			//	FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_AREA_WRITE_COMPARE);
			//	return FALSE;
			//}
			lba += nReceiveSector;

			nBundle -= nReceiveSector;
		}
	}
	return TRUE;
}

int FWDN_DRV_AREA_CalcCRC( char *name
							,unsigned int lba
							,unsigned int nSector
							,unsigned int *pCrc
							,FXN_FWDN_DRV_SendStatus fxnFwdnDrvSendStatus )
{
#define SEND_STATUS_EVERY_N_SECTOR		2048
	unsigned char *_buf  = (unsigned char *)fwdndBuf;

	unsigned short nReadSector;
	unsigned int nCalcedSector = 0;
	unsigned int nNextSendStatusSector = SEND_STATUS_EVERY_N_SECTOR;

	while(nSector)
	{
		if(nCalcedSector>nNextSendStatusSector)
		{
			nNextSendStatusSector += SEND_STATUS_EVERY_N_SECTOR;
			fxnFwdnDrvSendStatus(nCalcedSector,0,0);
		}

		if( nSector > TbufferSectorSize )
			nReadSector = TbufferSectorSize;
		else
			nReadSector = (unsigned short)nSector;

		if(_loc_AreaRead(name,lba,nReadSector,_buf)!=0)
		{
			FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_AREA_READ);
			return FALSE;
		}
		*pCrc = FWUG_CalcCrc8I(*pCrc,_buf,(unsigned int)nReadSector<<9,CRC32_TABLE);

		lba += nReadSector;
		nCalcedSector += nReadSector;
		nSector -= nReadSector;
	}

	return TRUE;
}

#if defined(NAND_INCLUDE) && defined(TNFTL_V7_INCLUDE)
#define	FWDN_DRV_BLOCKREAD_BUFFER_SIZE		(32*1024)		// because of LGE CDC
static int _loc_NAND_DUMP_BlockRead(unsigned int blockAddrParam, unsigned int nBlockParam, unsigned int mediaIndex,
													FXN_FWDN_DRV_Response_RequestData fxnFwdnDrvResponseRequestData,
													FXN_FWDN_DRV_SendToHost fxnFwdnDrvSendToHost)
{
	// nBlockAddr	: Read Block Address
	// nPageAddr	: Page Number Per Block
	// nMediaNum	: Media Num
	// nReadBuffer	: Buffer Pointer
	// �ѹ��� 1���� Physical Page�� Read�Ѵ�.  Data Size = ( Nand PageSize + Nand SpareSize ) Byte

	unsigned char *pUsbBuffer = (unsigned char *) fwdndBuf;
	unsigned int usbBufferIndex;
	unsigned int nPageAddr;
	unsigned int blockAddr = blockAddrParam;
	unsigned int nNandPhyReadSize;
	unsigned int nBlockSize;
	NAND_IO_DEVINFO *nDevInfo;
	unsigned int requestSize;

	//if( (pUsbBuffer = TC_Allocate_Memory(FWDN_DRV_BLOCKREAD_BUFFER_SIZE)) == NULL )
	//	return FALSE;

	nDevInfo = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[mediaIndex];

	nNandPhyReadSize	= nDevInfo->Feature.PageSize + nDevInfo->Feature.SpareSize;
	nBlockSize			= nNandPhyReadSize << nDevInfo->ShiftPpB;

	if( sizeof(fwdndBuf) < nBlockSize || sizeof(fwdndBuf) < FWDN_DRV_BLOCKREAD_BUFFER_SIZE )
	{
		FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_INSUFFICIENT_MEMORY);
		return FALSE;
	}

	while( nBlockParam-- )
	{
		usbBufferIndex = 0;
		nPageAddr = 0;

		while(nBlockSize>usbBufferIndex)
		{
			NAND_PhyReadPage( blockAddr, nPageAddr++, mediaIndex, &pUsbBuffer[usbBufferIndex] );
			usbBufferIndex += nNandPhyReadSize;
		}

		requestSize = nBlockSize;
		usbBufferIndex = 0;

		fxnFwdnDrvResponseRequestData(requestSize);
		while( requestSize>0 )
		{
			unsigned int packetSize = requestSize>FWDN_DRV_BLOCKREAD_BUFFER_SIZE? FWDN_DRV_BLOCKREAD_BUFFER_SIZE : requestSize;
			requestSize -= packetSize;
			fxnFwdnDrvSendToHost( &pUsbBuffer[usbBufferIndex], packetSize );
			usbBufferIndex += packetSize;
		}
		blockAddr++;
	}

	//TC_Deallocate_Memory(pUsbBuffer);
	return TRUE;
}

static int _loc_NAND_DUMP_BlockWrite(unsigned int blockAddrParam, unsigned int nBlockParam, unsigned int mediaIndex,
													FXN_FWDN_DRV_Response_RequestData fxnFwdnDrvResponseRequestData,
													FXN_FWDN_DRV_ReadFromHost fxnFwdnDrvReadFromHost)
{
#if 0
	unsigned int 	nNandPhyWriteSize;
	unsigned int	nBlockSize;
	unsigned int 	nPageAddr;
	unsigned char 	*receiveBuf = (unsigned char *)fwdndBuf;
	NAND_IO_DEVINFO *nDevInfo;
	unsigned int	usbBufferIndex=0;
	unsigned int	requestSize=0;

	nDevInfo = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[mediaIndex];

	nNandPhyWriteSize 	= nDevInfo->Feature.PageSize + nDevInfo->Feature.SpareSize;
	nBlockSize			= nNandPhyWriteSize << nDevInfo->ShiftPpB;

	if( sizeof(fwdndBuf) < nBlockSize || sizeof(fwdndBuf)<FWDN_DRV_BLOCKREAD_BUFFER_SIZE )
	{
		FWDN_DRV_SetErrorCode(ERR_FWDN_DRV_INSUFFICIENT_MEMORY);
		return FALSE;
	}

	while(nBlockParam--)
	{
		// Block Erase
		NAND_IO_EraseBlock( nDevInfo, blockAddrParam << nDevInfo->ShiftPpB, INTER_LEAVE_OFF );

		requestSize = nBlockSize;
		fxnFwdnDrvResponseRequestData(requestSize);
		usbBufferIndex=0;
		while(requestSize>0)
		{
			unsigned int packetSize = (requestSize>FWDN_DRV_BLOCKREAD_BUFFER_SIZE)? FWDN_DRV_BLOCKREAD_BUFFER_SIZE : requestSize;
			requestSize -= packetSize;
			fxnFwdnDrvReadFromHost(&receiveBuf[usbBufferIndex],packetSize);
			usbBufferIndex += packetSize;
		}

		usbBufferIndex=0;
		nPageAddr = blockAddrParam << nDevInfo->ShiftPpB;
		while(nBlockSize>usbBufferIndex)
		{
			NAND_GANG_WritePage(nPageAddr++,&receiveBuf[usbBufferIndex]);
			usbBufferIndex += nNandPhyWriteSize;
		}
		blockAddrParam++;
	}
#endif
	return TRUE;
}
#endif

unsigned char FWDN_DRV_DUMP_InfoRead(void *pBuf)
{
	unsigned int  i = 0;
	unsigned char length = 0;

	#ifndef WITHOUT_FILESYSTEM
	length = sizeof(NAND_DEVICE_INFO);
	memset( (void*)&gNAND_DEVICE_INFO, 0xFF, length );
	
	for ( i = 0; i < 6; ++i )
		gNAND_DEVICE_INFO.DevID[i] = gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.DeviceID.Code[i];
	gNAND_DEVICE_INFO.MediaNums	 			= gNAND_DrvInfo[0].NFTLDrvInfo->MediaNums;
	gNAND_DEVICE_INFO.MAX_ROMSize			= gMAX_ROMSIZE;
	gNAND_DEVICE_INFO.ExtendedPartitionNum 	= gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo;
	for ( i = 0; i < gNAND_DrvInfo[0].NFTLDrvInfo->ExtendedPartitionNo; ++i )
		gNAND_DEVICE_INFO.ExtPartitionSize[i] = 4096;
	for ( i = 0; i < 12; ++i )
		gNAND_DEVICE_INFO.ExtPartitionWCacheNum[i] = gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[i].WCacheNums;
	gNAND_DEVICE_INFO.ROAreaSize			= gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaSize;
	gNAND_DEVICE_INFO.PBpV			= gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PBpV;
	gNAND_DEVICE_INFO.PpB				= gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PpB;
	gNAND_DEVICE_INFO.PageSize		= gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.PageSize;
	gNAND_DEVICE_INFO.SpareSize		= gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0].Feature.SpareSize;
	#endif

	memcpy(pBuf, (void*)&gNAND_DEVICE_INFO, length);
 
	return length;
}

int FWDN_DRV_DUMP_BlockRead(unsigned int Param0, unsigned int Param1, unsigned int Param2, 
											FXN_FWDN_DRV_Response_RequestData fxnFwdnDrvResponseRequestData,
											FXN_FWDN_DRV_SendToHost fxnFwdnDrvSendToHost)
{
#if defined(NAND_INCLUDE) && defined(TNFTL_V7_INCLUDE)
	return _loc_NAND_DUMP_BlockRead(Param0, Param1, Param2, fxnFwdnDrvResponseRequestData, fxnFwdnDrvSendToHost);
#endif
}

int FWDN_DRV_DUMP_BlockWrite(unsigned int Param0, unsigned int Param1, unsigned int Param2, 
											FXN_FWDN_DRV_Response_RequestData fxnFwdnDrvResponseRequestData,
											FXN_FWDN_DRV_ReadFromHost fxnFwdnDrvReadFromHost)
{
#if defined(NAND_INCLUDE) && defined(TNFTL_V7_INCLUDE)
	return _loc_NAND_DUMP_BlockWrite(Param0, Param1, Param2, fxnFwdnDrvResponseRequestData, fxnFwdnDrvReadFromHost);
#endif
}

unsigned int FWDN_FNT_SetSN(unsigned char* ucTempData, unsigned int uiSNOffset)
{
	unsigned int		uiVerifyCrc;
	unsigned int		uiTempCrc;

	if (memcmp( &ucTempData[20+uiSNOffset], "ZERO", 4 ) == 0)
	{		
		uiVerifyCrc = (ucTempData[uiSNOffset + 16] <<24) ^ ( ucTempData[uiSNOffset + 17] <<16) ^ 
			( ucTempData[uiSNOffset + 18] << 8) ^ ( ucTempData[uiSNOffset + 19]); 
		uiTempCrc = FWUG_CalcCrc8((uiSNOffset + ucTempData), 16, CRC32_TABLE);

		if ( ( uiTempCrc == uiVerifyCrc ) || (uiVerifyCrc == 0x0000 )) 	//16 bytes Serial Exist
		{
			g_uiFWDN_WriteSNFlag = 1;
			return SUCCESS;
		}
	}
	else if (memcmp(&ucTempData[20+uiSNOffset], "FWDN", 4) == 0 || memcmp(&ucTempData[20+uiSNOffset], "GANG", 4) == 0)
	{
		uiVerifyCrc = ( ucTempData[uiSNOffset + 16] <<24) ^ ( ucTempData[uiSNOffset + 17] <<16) ^ 
			( ucTempData[uiSNOffset + 18] << 8) ^ ( ucTempData[uiSNOffset + 19]); 
		uiTempCrc = FWUG_CalcCrc8( (uiSNOffset + ucTempData), 16, CRC32_TABLE);
		if  (uiVerifyCrc == 0x0000 )
		{
			g_uiFWDN_WriteSNFlag = 0; 										// cleared SN
			return 1;		
		}
		else
		{
			if (memcmp(&ucTempData[52+uiSNOffset], "FWDN", 4) == 0 || memcmp(&ucTempData[52+uiSNOffset], "GANG", 4) == 0)
			{
				uiVerifyCrc = ( ucTempData[uiSNOffset + 48] <<24) ^ ( ucTempData[uiSNOffset + 49] <<16) ^ 
					( ucTempData[uiSNOffset + 50] << 8) ^ ( ucTempData[uiSNOffset + 51]); 
				uiTempCrc = FWUG_CalcCrc8((uiSNOffset + ucTempData+32), 16, CRC32_TABLE);				
				if (( uiVerifyCrc == uiTempCrc ) && ( uiVerifyCrc != 0x0000 ))
				{
					g_uiFWDN_WriteSNFlag = 1;

				#if defined (NKUSE)
				#else
					//#ifndef WITHOUT_FILESYSTEM
					if ( DISK_DefaultDriveType == DISK_DEVICE_HDD ) //for erasing NOR Flash before writing FW 
					{
						memcpy ( FWDN_DeviceInformation.DevSerialNumber, ucTempData, 16 );
						memcpy ( FWDN_DeviceInformation.DevSerialNumber+16, ucTempData+32, 16 );
					}
					//#endif
				#endif	
					return SUCCESS;
				}				
				else
					g_uiFWDN_WriteSNFlag = 0; 										// cleared SN
			}
			else
				g_uiFWDN_WriteSNFlag = 0; 										// cleared SN
		}
	}
	return 1;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void FWDN_FNT_VerifySN(unsigned char* ucTempData, unsigned int uiSNOffset);
*  
*  DESCRIPTION : Verify the validity of Serial Number format
*  
*  INPUT:
*			ucTempData	= base pointer of serial number format
*			uiSNOffset	= offset of serial number format
*  
*  OUTPUT:	void - Return Type
*			update global structure of FWDN_DeviceInformation according to verification result.
*  
**************************************************************************/
void FWDN_FNT_VerifySN(unsigned char* ucTempData, unsigned int uiSNOffset)
{
	unsigned int		uiVerifyCrc;
	unsigned int		uiTempCrc;

	/*---------------------------------------------------------------------
		Check Type for Serial Number of 16 digits
	----------------------------------------------------------------------*/
	if (memcmp(&ucTempData[20+uiSNOffset], "ZERO", 4) == 0)
	{		
		uiVerifyCrc = (ucTempData[uiSNOffset + 16] <<24) ^ ( ucTempData[uiSNOffset + 17] <<16) ^
			( ucTempData[uiSNOffset + 18] << 8) ^ ( ucTempData[uiSNOffset + 19]); 
		uiTempCrc = FWUG_CalcCrc8((uiSNOffset + ucTempData), 16, CRC32_TABLE);

		if ( ( uiTempCrc == uiVerifyCrc ) || (uiVerifyCrc == 0x0000 ))
		{
			if (uiVerifyCrc == 0x0000 ) 
			{
				memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 16);
				memset(FWDN_DeviceInformation.DevSerialNumber+16, 0x30, 16);
				FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_16;
			}
			else
			{
				memcpy(FWDN_DeviceInformation.DevSerialNumber, (uiSNOffset + ucTempData), 16);
				memset(FWDN_DeviceInformation.DevSerialNumber+16, 0x30, 16);
				FWDN_DeviceInformation.DevSerialNumberType = SN_VALID_16;
			}
		}
	}
	/*---------------------------------------------------------------------
		Check Type for Serial Number of 32 digits
	----------------------------------------------------------------------*/
	else if (memcmp(&ucTempData[20+uiSNOffset], "FWDN", 4) == 0 || memcmp(&ucTempData[20+uiSNOffset], "GANG", 4) == 0)
	{
		uiVerifyCrc = ( ucTempData[uiSNOffset + 16] <<24) ^ ( ucTempData[uiSNOffset + 17] <<16) ^ 
			( ucTempData[uiSNOffset + 18] << 8) ^ ( ucTempData[uiSNOffset + 19]); 
		uiTempCrc = FWUG_CalcCrc8(uiSNOffset + ucTempData, 16, CRC32_TABLE);
		if  (uiVerifyCrc == 0x0000 )
		{
			memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
			FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_32;			
		}
		else
		{
			if (memcmp(&ucTempData[52+uiSNOffset], "FWDN", 4) == 0 || memcmp(&ucTempData[52+uiSNOffset], "GANG", 4) == 0)
			{
				uiVerifyCrc = ( ucTempData[uiSNOffset + 48] <<24) ^ ( ucTempData[uiSNOffset + 49] <<16) ^ 
					( ucTempData[uiSNOffset + 50] << 8) ^ ( ucTempData[uiSNOffset + 51]); 
				uiTempCrc = FWUG_CalcCrc8(( uiSNOffset + ucTempData + 32), 16, CRC32_TABLE);
				if (( uiVerifyCrc == uiTempCrc ) && ( uiVerifyCrc != 0x0000 ))
				{
					memcpy(FWDN_DeviceInformation.DevSerialNumber, (uiSNOffset + ucTempData), 16);
					memcpy(FWDN_DeviceInformation.DevSerialNumber+16, (uiSNOffset + ucTempData + 32 ), 16);
					FWDN_DeviceInformation.DevSerialNumberType = SN_VALID_32;
				}				
				else
				{
					memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
					FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_32;			
				}
			}
			else
			{
				memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
				FWDN_DeviceInformation.DevSerialNumberType = SN_INVALID_32;			
			}
		}		
	}
	else
	{
		memset(FWDN_DeviceInformation.DevSerialNumber, 0x30, 32);
		FWDN_DeviceInformation.DevSerialNumberType = SN_NOT_EXIST;	
	}
}

void FWDN_FNT_InsertSN(unsigned char *pSerialNumber)
{
	unsigned	uCRC;

	memcpy (pSerialNumber, FWDN_DeviceInformation.DevSerialNumber, 16 );
	uCRC	= FWUG_CalcCrc8(pSerialNumber, 16, CRC32_TABLE);
	
	pSerialNumber[16] = (uCRC & 0xFF000000) >> 24;
	pSerialNumber[17] = (uCRC & 0x00FF0000) >> 16;
	pSerialNumber[18] = (uCRC & 0x0000FF00) >> 8;
	pSerialNumber[19] = (uCRC & 0x000000FF) ;

	memcpy(pSerialNumber+20, "FWDN", 4);
	memset(pSerialNumber+24, 0x00, 8);
	memcpy(pSerialNumber+32, FWDN_DeviceInformation.DevSerialNumber+16, 16);
	uCRC	= FWUG_CalcCrc8(pSerialNumber+32, 16, CRC32_TABLE);

	pSerialNumber[48] = (uCRC & 0xFF000000) >> 24;
	pSerialNumber[49] = (uCRC & 0x00FF0000) >> 16;
	pSerialNumber[50] = (uCRC & 0x0000FF00) >> 8;
	pSerialNumber[51] = (uCRC & 0x000000FF) ;

	memcpy(pSerialNumber+52, "FWDN", 4);
	memset(pSerialNumber+56, 0x00, 8);
}

unsigned char FWDN_DRV_FirmwareStorageID(void)
{
	return (unsigned int)gFWDN_FirmwareStorage;
}

#endif //FWDN_V7

/************* end of file *************************************************************/
