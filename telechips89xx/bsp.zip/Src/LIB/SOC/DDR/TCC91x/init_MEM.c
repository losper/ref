/****************************************************************************
 *   FileName    : fwupgrade_NAND_Init_80x_DDR1.c
 *   Description : Init code for TCC8000 DDR1 SDRAM
 ****************************************************************************
 *
 *   TCC Version 3.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include "bsp.h"

#define	repeat(n) { volatile int i; for (i=0; i<=n; i++); }

volatile void InitRoutine_Start(void)
{

}

volatile void InitRoutine_End(void)
{

}

/************* end of file *************************************************************/
