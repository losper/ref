/****************************************************************************
 *   FileName    : init_MEM.c
 *   Description : Init code for TCC8900 DDRAM
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#if defined(_WINCE_)
#include "bsp.h"
#elif defined(_LINUX_)
#include <common.h>
#include <def_tcc.h>
#endif

#if defined(DRAM_MDDR)
#define DRAM_AUTOPD_ENABLE Hw13
#define DRAM_AUTOPD_PERIOD 4<<7 // must larger than CAS latency
#define DRAM_SET_AUTOPD DRAM_AUTOPD_ENABLE|DRAM_AUTOPD_PERIOD

#define	repeat(n) { volatile int i; for (i=0; i<=n; i++); }
#define DDR_DELAY	1
/****************************************************************************************
* FUNCTION :void InitRoutine_Start(void)
* DESCRIPTION :
* ***************************************************************************************/
	/*-------------------
	   PLL0   m      p    s
	  ------------------
	   600    200   2     1
	   500    250   3     1
	   480    160   2     1
	   480	  400	3	  2
	---------------------*/
	/*-------------------
	   PLL1   m 	 p	  s
	  ------------------
	   560	  140	3	  0
	   520	  130	3	  0
	   500	  125	3	  0
	   480	  40	1	  0
	---------------------*/
#pragma optimize( "g", off )

volatile void InitRoutine_Start(void)
{
	volatile unsigned int i;
	//*(volatile unsigned long *)0xF0101000 |= 0x00800000;

	// 44.0 ms
//Enter Mode		
	*(volatile unsigned long *)0xF0301004 = 0x00000003; 		// PL340_PAUSE
	while (((*(volatile unsigned long *)0xF0301000) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)0xF0301004 = 0x00000004; 		// PL340_Configure
	while (((*(volatile unsigned long *)0xF0301000) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)0xF0304404 &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)0xF0304428 &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)0xF030302c &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
	i = 1600;
	while(i)
		i--;

	i = 100;
	while(i)
	{
		*(volatile unsigned long *)0xF0301008 = 0x00040000;
		i--;
	}		// repeat end
	// 37.7 ms
	*(volatile unsigned long *)0xF0400030 = 0x01010101;
	*(volatile unsigned long *)0xF0400034 = 0x01010101;

	*(volatile unsigned long *)0xF0400000 = 0x002ffff4; // XI - corebus
	*(volatile unsigned long *)0xF0400008 = 0x00200014; // XI - memebus
//PLL0
	*(volatile unsigned long *)0xF0400020= 0x0000fa03; // pll pwr off
	*(volatile unsigned long *)0xF0400020= 0x0100C802; // pms - pllout_600M
	*(volatile unsigned long *)0xF0400020= 0x8100C802; //	pll pwr on	
//PLL1
	*(volatile unsigned long *)0xF0400024= 0x0000fa03; // pll pwr off
	*(volatile unsigned long *)0xF0400024= 0x00008c03; // pms - pllout_560M
	*(volatile unsigned long *)0xF0400024= 0x80008c03; //	pll pwr on

//PLL2
//	*(volatile unsigned long *)0xF0400028= 0x0000fa03; // pll pwr off
//	*(volatile unsigned long *)0xF0400028= 0x00002701; // pms - pllout_468M
//	*(volatile unsigned long *)0xF0400028= 0x80002701; //	pll pwr on
	i = 3200;
	while(i)
		i--;
	*(volatile unsigned long *)0xF0400000 = 0x002AAAA0; // 300Mhz
	*(volatile unsigned long *)0xF0400008 = 0x00200030; // 150Mhz
	*(volatile unsigned long *)0xF0400010 = 0x00200022; // CKC-CLKCTRL4 - I/O BUS
	i = 3200;
	while(i)
		i--;

	i = 100;
	while(i)
	{
		*(volatile unsigned long *)0xF0301008 = 0x00040000;
		i--;
	}		// repeat end

	*(volatile unsigned long *)0xF0301004 = 0x00000004; 		// PL340_Configure
	while (((*(volatile unsigned long *)0xF0301000) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

	// MEMCFG0
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)0xF030100c = 0x0001001A|DRAM_SET_AUTOPD;
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)0xF030100c = 0x00010011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)0xF030100c = 0x00010012|DRAM_SET_AUTOPD;
	#endif
#endif

	// MEMCFG1
	// mem_width=1, mem_type=3,read_delay=1, Sync = 1
	*(volatile unsigned long *)0xF030104c = 0x000002d1;
	*(volatile unsigned long *)0xF0301010 = 0x000003e8; // refresh_prd = 1000
	*(volatile unsigned long *)0xF0301014 = 0x00000006; // cas_latency = 3
	*(volatile unsigned long *)0xF030101C = 0x00000002; // tMRD=3
	*(volatile unsigned long *)0xF0301020 = 0x00000005; // tRAS=6
	*(volatile unsigned long *)0xF0301024 = 0x00000007; // tRC=11
//	*(volatile unsigned long *)0xF0301028 = 0x00000003; // tRCD=3<<3|5<<0
	*(volatile unsigned long *)0xF0301028 = 0x0000000B; // tRCD=3<<3|5<<0
//	*(volatile unsigned long *)0xF030102c = 0x00000B0E; // tRFC=(19<<5|21<<0)
	*(volatile unsigned long *)0xF030102c = 0x0000016E; // tRFC=(B<<5|E<<0)
//	*(volatile unsigned long *)0xF0301030 = 0x00000003; // tRP=3<<3|5<<0
	*(volatile unsigned long *)0xF0301030 = 0x0000000B; // tRP=3<<3|5<<0
	*(volatile unsigned long *)0xF0301034 = 0x00000001; // tRRD=2
	*(volatile unsigned long *)0xF0301038 = 0x00000002; // tWR=5
	*(volatile unsigned long *)0xF030103c = 0x00000001; // tWTR=4
	*(volatile unsigned long *)0xF0301040 = 0x00000002; // tXP=3
	*(volatile unsigned long *)0xF0301044 = 0x00000012; // tXSR=14
	*(volatile unsigned long *)0xF0301048 = 0x00000032; // tESR=200
	// CHIP0 address_match=0x40, address_mask=0x40
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *) 0xF0301200=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *) 0xF0301200=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *) 0xF0301200=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif

/*
	i = 3200;
	while(i)
		i--;
*/
	*(volatile unsigned long *)0xF030302C = 0x3FFF;

	//HwEMCCFG->uCONFIG0.bReg.AXI_SEL = 0;
	//HwEMCCFG->uCONFIG0.bReg.IO_SEL = 1;
	*(volatile unsigned long *)0xF0303020 = 0x00010102;
	//HwEMCCFG->uPHYCTRL.bReg.PL340_SEL = 1;
	*(volatile unsigned long *)0xF0303024 = 0x00000100;
//	*(volatile unsigned long *)0xF030302C = 0x00000000;
	//SSTL_IO_Init (IO_CMOS)
	*(volatile unsigned long *) 0xF0304400=0x00000002; // DDR2PHY_PHYMODE
	*(volatile unsigned long *) 0xF0304404=0x00004d69; // DLLCTRL - DLL ON
	*(volatile unsigned long *) 0xF0304408=0x00002f2f; // DLLPDCFG (200Mhz)
	*(volatile unsigned long *) 0xF0304404=0x000047d3; // DLLCTRL - DLL ON, DLL start
	while (!((*(volatile unsigned long *)0xF0304404) & (3<<3)));	// Wait until PDFL == 1
	
	*(volatile unsigned long *) 0xF0304424=0x00000035; // DLLFORCELOCK
	*(volatile unsigned long *) 0xF030440c=0x00000003; // GATECTRL
	*(volatile unsigned long *) 0xF0304430=0x00000004; // RDDELAY - SOC
	*(volatile unsigned long *) 0xF0304428=0x0006F151; // ZQCTRL Termination Selection    : 0 for disable
	while (!((*(volatile unsigned long *)0xF030442c) & (1)));	// Wait until Calibration completion without error
	
	*(volatile unsigned long *) 0xF0304428=0x0006F153; // ZQCTRL Termination Selection    : 0 for disable
/*
	i = 3200;
	while(i)
		i--;
		*/
	*(volatile unsigned long *) 0xF0304428=0x0006F151; // ZQCTRL Termination Selection    : 0 for disable
	//i = 3200;
	//while(i)
	//	i--;

	//HwPL340->direct_cmd = 		
	*(volatile unsigned long *)0xF0301008 = 0x00000032; // ECMD : 0 , MCMD : 00 - Prechargeall 
	*(volatile unsigned long *)0xF0301008 = 0x000a0000; // ECMD : 0 , MCMD : 10 - Modereg or extended modereg access  -------EMRS
	*(volatile unsigned long *)0xF0301008 = 0x00080032; //ECMD : 0 , MCMD : 10 - Modereg or extended modereg access  --------MRS


	i = 50;
	while(i)
	{
		*(volatile unsigned long *)0xF0301008 = 0x00040032;
		i--;
		*(volatile unsigned long *)0xF0301008 = 0x00040032;
	}


	*(volatile unsigned long *) 0xF0301004=0x00000000; // PL341_GO
		while (((*(volatile unsigned long *)0xF0301000) & (0x03)) != 1);	// Wait until READY

}
#pragma optimize( "g", on )

volatile void InitRoutine_End(void)
{

}
#ifndef NKUSE
/*=========================================================================================================================
*
*										Used Boot Loader
*
==========================================================================================================================*/
void init_clock(void)
{
	PCKC		lCKC = (CKC *)&HwCLK_BASE;
	PPMU		lPMU = (PMU *)&HwPMU_BASE;
	PNTSCPAL	lNTSCPAL=(PNTSCPAL)&HwTVE_BASE;
	volatile unsigned int nCount = 0;

	
	tca_ckc_init(); 
	
	// Set PLL - default PLL: PLL1,PLL2,PLL3 Disable
	// Change PLL Value
	tca_ckc_setpll(4680000,2); // 240 *2 100hz -SDMMC
	tca_ckc_setpll(5280000,3); // 156 *2 100hz	
	
	//CLKDIVC0/1
	lCKC->CLKDIVC	= 0x01010101;
	lCKC->CLKDIVC1	= 0x01010101;
	
#if defined(TCC_R_AX)
	tca_ckc_setswreset(RESET_VIDEOBUS, ON);
	tca_ckc_setswreset(RESET_VIDEOCORE, ON);
	#if !defined(TCC_MAX_FGRP_INCLUDE)
	tca_ckc_setswreset(RESET_GRAPBUS, ON);
	#endif
#endif
	
	tca_ckc_setfbusctrl(CLKCTRL1,ENABLE,NORMAL_MD,2340000,DIRECTPLL2);/*FBUS_DDI		240 MHz */
#if defined(TCC_R_AX)
	#if defined(TCC_MAX_FGRP_INCLUDE)
		tca_ckc_setfbusctrl(CLKCTRL3,ENABLE,NORMAL_MD,2340000,DIRECTPLL2);/*FBUS_GRP		190 MHz */
	#else
		tca_ckc_setfbusctrl(CLKCTRL3,DISABLE,NORMAL_MD,60000,DIRECTXIN);/*FBUS_GRP		190 MHz */
	#endif
#else
		tca_ckc_setfbusctrl(CLKCTRL3,ENABLE,NORMAL_MD,2340000,DIRECTPLL2);/*FBUS_GRP		190 MHz */
#endif
	tca_ckc_setfbusctrl(CLKCTRL4,ENABLE,NORMAL_MD,1560000,DIRECTPLL2);/*FBUS_IOB		166 MHz */

#if defined(TCC_R_AX)
	tca_ckc_setfbusctrl(CLKCTRL5,DISABLE,NORMAL_MD,60000,DIRECTXIN);/*FBUS_VBUS		215 MHz */ //2640000 , 1760000
	tca_ckc_setfbusctrl(CLKCTRL6,DISABLE,NORMAL_MD,60000,DIRECTXIN);/*FBUS_VCODEC	160 MHz */ //2340000 , 1560000
#else
	tca_ckc_setfbusctrl(CLKCTRL5,ENABLE,NORMAL_MD,60000,DIRECTXIN);/*FBUS_VBUS		215 MHz */ //2640000 , 1760000
	tca_ckc_setfbusctrl(CLKCTRL6,ENABLE,NORMAL_MD,60000,DIRECTXIN);/*FBUS_VCODEC	160 MHz */ //2340000 , 1560000
#endif
	tca_ckc_setfbusctrl(CLKCTRL7,ENABLE,NORMAL_MD,1170000,DIRECTPLL2);/*FBUS_SMU		125 MHz */
		
	// Enable Peri.
	lPMU->CONTROL	|= Hw16;		// Touch ADC Power Enable
	nCount = 10;	
	for ( ; nCount > 0 ; nCount --);		// delay
	lNTSCPAL->DACPD |= Hw0;
	
	lPMU->PWROFF	&= ~Hw0;			// Video Dac(TVOUT)
	nCount = 500;	
	for ( ; nCount > 0 ; nCount --);		// delay

	lPMU->PWROFF	|=(Hw0			// Video Dac(TVOUT)
						|Hw1		// HDMI PHY
						|Hw2		// LVDS
						|Hw4		//SATA PHY
#if defined(TCC_R_AX)
						|Hw6		// Video Bus
						#if !defined(TCC_MAX_FGRP_INCLUDE)
						|Hw8
						#endif
#endif
	); // HDMI Phy,LVDS Phy,SATA Phy , Video Bus , Graphic Bus 
	
#if defined(TCC_R_AX)
	tca_ckc_setswreset(RESET_VIDEOCORE, OFF);
	tca_ckc_setswreset(RESET_VIDEOBUS, OFF);
	#if !defined(TCC_MAX_FGRP_INCLUDE)
	tca_ckc_setswreset(RESET_GRAPBUS, OFF);
	#endif
#endif

// init Peri. Clock
	tca_ckc_setperi(PERI_TCZ,ENABLE,120000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_ADC,ENABLE,120000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_I2C,ENABLE,40000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_UART0,ENABLE,520000,PCDIRECTPLL2); 
	tca_ckc_setperi(PERI_LCD1,ENABLE,1560000,PCDIRECTPLL2);

	tca_ckc_setperi(PERI_LCD0,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_LCDSI,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_CIFMC,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_CIFSC,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_OUT0,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_OUT1,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_HDMI,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_SDMMC0,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_MSTICK,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_UART1,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_UART2,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_UART3,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_UART4,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_UART5,DISABLE,10000,PCDIRECTXIN);

	tca_ckc_setperi(PERI_GPSB0,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_GPSB1,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_GPSB2,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_GPSB3,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_GPSB4,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_GPSB5,DISABLE,10000,PCDIRECTXIN);

//	tca_ckc_setperi(PERI_SPDIF,ENABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_EHI0,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_EHI1,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_CAN,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_SDMMC1,DISABLE,10000,PCDIRECTXIN);
	tca_ckc_setperi(PERI_DAI,DISABLE,10000,PCDIRECTXIN);
	
// init Io Bus
	tca_ckc_setiobus(RB_USB11H, DISABLE);	
	tca_ckc_setiobus(RB_IDECONTROLLER, DISABLE);	
	tca_ckc_setiobus(RB_SDMMCCONTROLLER, DISABLE);	
	tca_ckc_setiobus(RB_SATAHCONTROLLER, DISABLE);	
	tca_ckc_setiobus(RB_MEMORYSTICKCONTROLLER, DISABLE);	
	tca_ckc_setiobus(RB_EXTHCONTROLLER0, DISABLE);	
	tca_ckc_setiobus(RB_EXTHCONTROLLER1, DISABLE);	
	tca_ckc_setiobus(RB_UARTCONTROLLER1, DISABLE);	
	tca_ckc_setiobus(RB_UARTCONTROLLER2, DISABLE);	
	tca_ckc_setiobus(RB_UARTCONTROLLER3, DISABLE);	
	tca_ckc_setiobus(RB_UARTCONTROLLER4, DISABLE);	
	tca_ckc_setiobus(RB_UARTCONTROLLER5, DISABLE);	
	tca_ckc_setiobus(RB_GPSBCONTROLLER0, DISABLE);	
	tca_ckc_setiobus(RB_GPSBCONTROLLER1, DISABLE);	
	tca_ckc_setiobus(RB_GPSBCONTROLLER2, DISABLE);	
	tca_ckc_setiobus(RB_GPSBCONTROLLER3, DISABLE);	
	tca_ckc_setiobus(RB_GPSBCONTROLLER4, DISABLE);	
	tca_ckc_setiobus(RB_GPSBCONTROLLER5, DISABLE);	
	tca_ckc_setiobus(RB_SPDIFTXCONTROLLER, DISABLE);	
	tca_ckc_setiobus(RB_GPSCONTROLLER, DISABLE);	
	tca_ckc_setiobus(RB_CANCONTROLLER, DISABLE);	
	tca_ckc_setiobus(RB_MPE_FECCONTROLLER, DISABLE);	
	tca_ckc_setiobus(RB_TSIFCONTROLLER, DISABLE);	
//	tca_ckc_setiobus(RB_SRAMCONTROLLER, DISABLE);	

// init ddi Pwdn
	tca_ckc_setddipwdn(DDIPWDN_CIF, DISABLE);	
	tca_ckc_setddipwdn(DDIPWDN_VIQE, DISABLE);	
	tca_ckc_setddipwdn(DDIPWDN_LCDC0, DISABLE);	
	tca_ckc_setddipwdn(DDIPWDN_MSCL0, DISABLE);	
	tca_ckc_setddipwdn(DDIPWDN_MSCL1, DISABLE);	
	tca_ckc_setddipwdn(DDIPWDN_HDMI, DISABLE);	
	

}

/*	
*	Example 
* ------------------------------------------------------------------------------------------------------------------------------
* define HIGH_VOLTAGE_CLOCK_INCLUDE
*
*	1. Core 600Mhz, Mem 400Mhz
*		#define lpll0		800
*		#define lpll1		660
*		#define lmem_source 0	// 0 : PLL0 , 1 : PLL1
*		#define lcore_div	12	// (lpll0 * lcore_div)/16 - refer DataSheet CKC Block
*		#define lmem_div	2	// if lmem_source is 0, lpll0/lmem_div = Mem Bus /	if lmem_source is 0, lpll0/lmem_div = Mem Bus
*
*	2. Core 600Mhz, Mem 330Mhz
*		#define lpll0		600
*		#define lpll1		660
*		#define lmem_source 1	// 0 : PLL0 , 1 : PLL1
*		#define lcore_div	16	// (lpll0 * lcore_div)/16 - refer DataSheet CKC Block
*		#define lmem_div	2	// if lmem_source is 0, lpll0/lmem_div = Mem Bus /	if lmem_source is 1, lpll1/lmem_div = Mem Bus
*	3. Core 506Mhz, Mem 330Mhz
*		#define lpll0		540
*		#define lpll1		660
*		#define lmem_source 1	// 0 : PLL0 , 1 : PLL1
*		#define lcore_div	15	// (lpll0 * lcore_div)/16 - refer DataSheet CKC Block
*		#define lmem_div	2	// if lmem_source is 0, lpll0/lmem_div = Mem Bus /	if lmem_source is 1, lpll1/lmem_div = Mem Bus
* ------------------------------------------------------------------------------------------------------------------------------
*	4. Core 600Mhz, Mem 280Mhz
*		#define lpll0		600
*		#define lpll1		560
*		#define lmem_source 1	// 0 : PLL0 , 1 : PLL1
*		#define lcore_div	16	// (lpll0 * lcore_div)/16 - refer DataSheet CKC Block
*		#define lmem_div	2	// if lmem_source is 0, lpll0/lmem_div = Mem Bus /	if lmem_source is 1, lpll1/lmem_div = Mem Bus
*
*	5. Core 506Mhz, Mem 280Mhz
*		#define lpll0		540
*		#define lpll1		560
*		#define lmem_source 1	// 0 : PLL0 , 1 : PLL1
*		#define lcore_div	15	// (lpll0 * lcore_div)/16 - refer DataSheet CKC Block
*		#define lmem_div	2	// if lmem_source is 0, lpll0/lmem_div = Mem Bus /	if lmem_source is 0, lpll0/lmem_div = Mem Bus
* ------------------------------------------------------------------------------------------------------------------------------
*/
#pragma optimize( "g", off )

void init_bootddr(void)
{
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
// Core
	#if  defined(FCPU_337MHZ_INCLUDE)
		#define lpll0		540
		#define lcore_div	10 // refer DataSheet CKC Block 
	#elif  defined(FCPU_506MHZ_INCLUDE)
		#define lpll0		540
		#define lcore_div	15 // refer DataSheet CKC Block 
	#elif defined(FCPU_600MHZ_INCLUDE)
		#define lpll0		600
		#define lcore_div	16 // refer DataSheet CKC Block 
	#else
		#define lpll0		540
		#define lcore_div	15 // refer DataSheet CKC Block 
	#endif
// Mbus
	#if defined(FMBUS_180MHZ_INCLUDE)
		#define lpll1		360
	#elif defined(FMBUS_160MHZ_INCLUDE)
		#define lpll1		320
	#elif defined(FMBUS_133MHZ_INCLUDE)
		#define lpll1		266
	#else
		#define lpll1		266
	#endif


	#define lmem_div	2
	volatile unsigned int i = 0;	
	unsigned int ldiv = 0;
	unsigned int lcycle = 0;
	unsigned int lindex[17];
	lindex[0] = 0x0;
	lindex[1] = 0x8000;
	lindex[2] = 0x8008;
	lindex[3] = 0x8808;
	lindex[4] = 0x8888;
	lindex[5] = 0xA888;
	lindex[6] = 0xA8A8;
	lindex[7] = 0xAAA8;
	lindex[8] = 0xAAAA;
	lindex[9] = 0xECCC;
	lindex[10] = 0xEECC;
	lindex[11] = 0xEEEC;
	lindex[12] = 0xEEEE;
	lindex[13] = 0xFEEE;
	lindex[14] = 0xFFEE;
	lindex[15] = 0xFFFE;
	lindex[16] = 0xFFFF;	

//Enter Mode		
	*(volatile unsigned long *)0xF0301004 = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)0xF0301000) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)0xF0301004 = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)0xF0301000) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)0xF0304404 &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)0xF0304428 &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)0xF030302c &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	i = 1600;
	while(i)
		i--;

	i = 100;
	while(i)
	{
		*(volatile unsigned long *)0xF0301008 = 0x00040000;
		i--;
	}		// repeat end


//Clock Change	
	*(volatile unsigned long *)0xF0400030 = 0x01010101;
	*(volatile unsigned long *)0xF0400034 = 0x01010101;
	
	*(volatile unsigned long *)0xF0400000 = 0x002ffff4; 		// XI - corebus
	*(volatile unsigned long *)0xF0400008 = 0x00200014; 		// XI - memebus
	
	i = 2400;
	while(i)
		i--;

	//PLL0
	*(volatile unsigned long *)0xF0400020= 0x0000fa03;			// pll pwr off

	if(lpll0 == 600)
	{
		*(volatile unsigned long *)0xF0400020= 0x0100C802;		// pms - pllout_600M
		*(volatile unsigned long *)0xF0400020= 0x8100C802;		//	pll pwr on	
	}
	else if(lpll0 == 540)			
	{
		*(volatile unsigned long *)0xF0400020= 0x0100B402;		// pms - pllout_540M
		*(volatile unsigned long *)0xF0400020= 0x8100B402;		//	pll pwr on	
	}
	else if(lpll0 == 400)			
	{
		*(volatile unsigned long *)0xF0400020= 0x02019003;		// pms - pllout_400M
		*(volatile unsigned long *)0xF0400020= 0x82019003;		//	pll pwr on	
	}
	else
	{
		*(volatile unsigned long *)0xF0400020= 0x0100C802;		// pms - pllout_600M
		*(volatile unsigned long *)0xF0400020= 0x8100C802;		//	pll pwr on	
	}
	
	//PLL1
	*(volatile unsigned long *)0xF0400024= 0x0000fa03;			// pll pwr off
	if(lpll1 == 360)
	{
		*(volatile unsigned long *)0xF0400024= 0x00001E01;		// pms - pllout_360M
		*(volatile unsigned long *)0xF0400024= 0x80001E01;		//	pll pwr on
	}
	else if(lpll1 == 320)
	{
		*(volatile unsigned long *)0xF0400024= 0x00005003;		// pms - pllout_320M
		*(volatile unsigned long *)0xF0400024= 0x80005003;		//	pll pwr on
	}
	else if(lpll1 == 266)
	{
		*(volatile unsigned long *)0xF0400024= 0x01008503;		// pms - pllout_266M
		*(volatile unsigned long *)0xF0400024= 0x81008503;		//	pll pwr on
	}
	else
	{
		*(volatile unsigned long *)0xF0400024= 0x01008503;		// pms - pllout_266M
		*(volatile unsigned long *)0xF0400024= 0x81008503;		//	pll pwr on
	}

//PLL2
	*(volatile unsigned long *)0xF0400028= 0x0000fa03; // pll pwr off
	*(volatile unsigned long *)0xF0400028= 0x00002701; // pms - pllout_468M
	*(volatile unsigned long *)0xF0400028= 0x80002701; //	pll pwr on

	i = 3200;
	while(i)
		i--;
	*(volatile unsigned long *)0xF0400000 = (0x00200000 | (lindex[lcore_div] << 4));		// CKC-CLKCTRL0 - Core
	*(volatile unsigned long *)0xF0400008 = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	i = 3200;
	while(i)
		i--;


	i = 100;
	while(i)
	{
		*(volatile unsigned long *)0xF0301008 = 0x00040000;
		i--;
	}
	
//Init mDDR
// memory arb.
/*
	*(volatile unsigned long *)0xF030100C |= 0x00140000; 
	*(volatile unsigned long *) 0xF0301100=0x0000002b; // (10<<2)(1<<1)(1<<0) - video codec + jpeg encoder
	*(volatile unsigned long *) 0xF0301104=0x0000002b; // (10<<2)(1<<1)(1<<0) - video cache + jpeg decoder
	*(volatile unsigned long *) 0xF0301108=0x00000017; // (5<<2)(1<<1)(1<<0) - video codec secondary
	*(volatile unsigned long *) 0xF030110c=0x00000017; // (5<<2)(1<<1)(1<<0) - io bus
	*(volatile unsigned long *) 0xF0301110=0x0000000f; // (3<<2)(1<<1)(1<<1) - lcd
	*(volatile unsigned long *) 0xF0301114=0x0000000f; // (3<<2)(1<<1)(1<<1) - lcd_mscl
	*(volatile unsigned long *) 0xF0301118=0x00000017; // (5<<2)(1<<1)(1<<1) - VIQE
	*(volatile unsigned long *) 0xF030111c=0x00000007; // (1<<2)(1<<1)(1<<1) - ddi cache
	*(volatile unsigned long *) 0xF0301124=0x0000003f; // (15<<2)(1<<1)(1<<1) - ARM DMA bus
	*(volatile unsigned long *) 0xF0301128=0x0000003f; // (15<<2)(1<<1)(1<<1) - ARM data bus
	*(volatile unsigned long *) 0xF030112c=0x0000002b; // (10<<2)(1<<1)(1<<1) - ARM instruction
	*(volatile unsigned long *) 0xF0301130=0x0000003f; // (15<<2)(1<<1)(1<<1) - overlay mixer
	*(volatile unsigned long *) 0xF0301134=0x0000003f; // (15<<2)(1<<1)(1<<1) - overlay mixer
	*(volatile unsigned long *) 0xF0301138=0x0000003f; // (15<<2)(1<<1)(1<<1) - overlay mixer
	*(volatile unsigned long *) 0xF030113c=0x0000002b; // (10<<2)(1<<1)(1<<1) - 3d
*/
// memory arb. end	

	i = 100;
	while(i)
	{
		*(volatile unsigned long *)0xF0301008 = 0x00040000;
		i--;
	}

	*(volatile unsigned long *) 0xF0301004=0x00000004;			// PL341_CONFIGURE
	while (((*(volatile unsigned long *)0xF0301000) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)0xF030100C = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)0xF030100c = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)0xF030100c = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif


	*(volatile unsigned long *) 0xF0303000 |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *) 0xF0303010 |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)0xF030104C= 0x000002D1;
	
	*(volatile unsigned long *)0xF0301010 = 0x000003E8; // refresh_prd = 1000



#if defined(DRAM_CAS3)
	*(volatile unsigned long *)0xF0301014 = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)0xF0301014 = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)0xF030101C = 0x00000002; // tMRD 2tck 
	*(volatile unsigned long *)0xF0301020 = 0x0000000A; // tRAS 42ns
	*(volatile unsigned long *)0xF0301024 = 0x0000000F; // tRC 60ns
//	*(volatile unsigned long *)0xF0301028 = 0x00000014; // tRCD 18ns
	*(volatile unsigned long *)0xF0301028 = 0x0000000C; // tRCD 18ns
//	*(volatile unsigned long *)0xF030102c = 0x00000E11; // tRFC 72ns
	*(volatile unsigned long *)0xF030102c = 0x000001D1; // tRFC 72ns
//	*(volatile unsigned long *)0xF0301030 = 0x00000014; // tRP 18ns
	*(volatile unsigned long *)0xF0301030 = 0x0000000C; // tRP 18ns
	*(volatile unsigned long *)0xF0301034 = 0x00000001; // tRRD 12ns
	*(volatile unsigned long *)0xF0301038 = 0x00000002; // tWR 15ns
	*(volatile unsigned long *)0xF030103c = 0x00000001; // tWTR 1tck
	*(volatile unsigned long *)0xF0301040 = 0x00000002; // tXP=3
	*(volatile unsigned long *)0xF0301044 = 0x00000016; // tXSR 120ns
	*(volatile unsigned long *)0xF0301048 = 0x00000032; // tESR=200

	i = 3200;
	while(i)
		i--;

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *) 0xF0301200=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *) 0xF0301200=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *) 0xF0301200=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	i = 3200;
	while(i)
		i--;		
	
#if !defined(DRAM_TYPE9)
	*(volatile unsigned long *)0xF0301004 = 0x00000000; 		// PL341_GO
	while (((*(volatile unsigned long *)0xF0301000) & (0x03)) != 1);	// Wait until READY
	
	*(volatile unsigned long *)0xF0301004 = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)0xF0301000) & (0x03)) != 2);	// Wait until PAUSE

	*(volatile unsigned long *)0xF0301004 = 0x00000001; 		// PL341_SLEEP
	while (((*(volatile unsigned long *)0xF0301000) & (0x03)) != 3);	// Wait until SLEEP
#endif
	*(volatile unsigned long *)0xF030302c &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
	*(volatile unsigned long *)0xF0303020 &=  ~(0x00000001);		// SW ? AXI_SEL     = 0
	*(volatile unsigned long *)0xF0303020 |= 0x00000002; 		// SW ? IO_SEL      = 1;
	*(volatile unsigned long *)0xF0303024 = 0x00000100;		// Hw8 SDR/mDDR/DDR


	*(volatile unsigned long *)0xF0304400 = 0x00000002; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)0xF0304404 = 0x00000001; 		// DLLCTRL

	*(volatile unsigned long *) 0xF0304408=0x00002020; // DLLPDCFG (145 ~ 180Mhz)
	
	*(volatile unsigned long *) 0xF0304404=0x00000003; // DLLCTRL - DLL ON, DLL start
	while (!((*(volatile unsigned long *)0xF0304404) & (3<<3) == 0x18));	// Wait until PDFL == 1
	*(volatile unsigned long *)0xF0304424 = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)0xF030440C = 0x00000003; 		// GATECTRL	
	*(volatile unsigned long *)0xF0304430 = 0x00000001; 	// RDDELAY	

	*(volatile unsigned long *)0xF0304428 =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)0xF030442c) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)0xF0304428 =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)0xF0304428 =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START	
	
	i = 3200;
	while(i)
		i--;	
#if !defined(DRAM_TYPE9)
	*(volatile unsigned long *)0xF0301004 = 0x00000002; 		// PL340_WAKEUP
	while (((*(volatile unsigned long *)0xF0301000) & (0x03)) != 2);	// Wait until PAUSE

	*(volatile unsigned long *)0xF0301004 = 0x00000004; 		// PL340_CONFIGURE
	while (((*(volatile unsigned long *)0xF0301000) & (0x03)) != 0);	// Wait until CONFIGURE	
#endif 

	#if defined(DRAM_CAS3)
		*(volatile unsigned long *)0xF0301008 = 0x00000032; //MRS
	#else
		*(volatile unsigned long *)0xF0301008 = 0x00000022; //MRS
	#endif					

	*(volatile unsigned long *)0xF0301008 = 0x000a0000;//EMRS
	#if defined(DRAM_CAS3)
		*(volatile unsigned long *)0xF0301008 = 0x00080032;
	#else
		*(volatile unsigned long *)0xF0301008 = 0x00080022;
	#endif					

	// repeat 100
	i = 100;
	while(i)
	{
		#if defined(DRAM_CAS3)
			*(volatile unsigned long *)0xF0301008 = 0x00040032;
		#else
			*(volatile unsigned long *)0xF0301008 = 0x00040022;
		#endif					
		i--;
	}		// repeat end

	*(volatile unsigned long *) 0xF0301004=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)0xF0301000) & (0x03)) != 1);	// Wait until READY
	
}
#pragma optimize( "g", on )

typedef void (*lpfunc)();
lpfunc lpSelfRefresh;

void init_copybootddr(void)
{
	#define SRAM_ADDR_STANDBY		0x10000400
	#define SRAM_FUNC_SIZE			0x900
	volatile unsigned int	*fptr;
	volatile unsigned int	*p;
	int 					i;
	unsigned int lstack = 0;
				
	fptr = (volatile unsigned int*)init_bootddr;
	lpSelfRefresh = (lpfunc)(SRAM_ADDR_STANDBY);
	
	p = (volatile unsigned int*)SRAM_ADDR_STANDBY;
	
	for (i = 0;i < (SRAM_FUNC_SIZE);i++)
	{
		*p = *fptr;
		p++;
		fptr++;
	}
	
	while(--i);
	
	// Jump to Function Start Point
	lpSelfRefresh();
}

#endif // NKUSE
#endif //defined(DRAM_MDDR)

/************* end of file *************************************************************/


