//=============================================================================
//*   FileName    : Nand_io_v7.c
//*   Description : 
//=============================================================================
//*
//*   TCC Version 1.0
//*   Copyright (c) Telechips, Inc.
//*   ALL RIGHTS RESERVED
//*
//=============================================================================
#ifndef WITHOUT_FILESYSTEM

#if defined(_LINUX_) || defined(_WINCE_)
#include "IO_TCCXXX.h"
#include "nand_io_v7.h"
#else
#include "main.h"
#include "IO_TCCXXX.h"
#include "nand_io_v7.h"
#endif

#if defined(_WINCE_)
#if defined(USE_V_ADDRESS)
#include "Tcc_ckc.h"
#include "tcc_gpio.h"
#else
#include "Tca_ckc.h"
#endif
#include "bsp.h"
#include "args.h"
#elif defined(_LINUX_)
#if defined(USE_V_ADDRESS)
#include <mach/tca_ckc.h>
#include <mach/irqs.h>
#else
#include "ckc.h"
#endif
#endif

#if defined(TCC89XX) || defined(TCC92XX)
#if defined(_LINUX_) || defined(_WINCE_)
#include "TC_DRV.h"
#else
#include "TC_DRV.h"
#endif
#endif

#if defined(_WINCE_)
#include "stdlib.h"
#endif

//=============================================================================
//
// Version Signature
//
//=============================================================================
#define NAND_IO_VERSION		'V','7','0','2','2'

static const unsigned char 	NANDIO_Library_Version[] = 
{ 	
	SIGBYAHONG, 
	NAND_IO_SIGNATURE, 
	SIGN_OS, 
	SIGN_CHIPSET, 
	NAND_IO_VERSION, 
	NULL
};

#ifdef UARTCON_INCLUDE
//#define NAND_IO_ECC_ERROR_LOG
//#define NAND_IO_UART_MEASURE
#endif

#if defined(_LINUX_)
#ifdef KERNEL_DRIVER
#include <linux/kernel.h>
#include <linux/string.h>
struct dma_buf {
	void *v_addr;
	unsigned int dma_addr;
	int buf_size;
};
extern struct dma_buf dma_t;
#else
#define DMA_ADDR	(BSS_OFFSET - 0x00700000)
#endif
#else
#ifdef _BOOT_LOADER_
unsigned char *gpNandBuffer;
#else
extern unsigned char *gpNandBuffer;
#endif
#endif

#if defined(_LINUX_)
#define ASM_NOP {					\
	__asm__ __volatile__ ("nop");	\
	__asm__ __volatile__ ("nop");	\
	__asm__ __volatile__ ("nop");	\
	__asm__ __volatile__ ("nop");	\
	__asm__ __volatile__ ("nop");	\
	__asm__ __volatile__ ("nop");	\
}
#elif defined(_WINCE_)
volatile int __asm_nop_count = 0;
#define ASM_NOP { __asm_nop_count++; }
#else
#define ASM_NOP { __asm{ NOP }; __asm{ NOP };  __asm{ NOP }; __asm{ NOP }; __asm{ NOP }; __asm{ NOP };}
#endif

#if defined(_WINCE_)
#define NAND_IO_USE_DMA_ACCESS
#elif defined(_LINUX_)
	#ifdef KERNEL_DRIVER
		#define NAND_IO_USE_DMA_ACCESS
	#else
#define NAND_IO_USE_DMA_ACCESS
//#define NAND_IO_USE_MCU_ACCESS
	#endif
#else
    #ifdef _BOOT_LOADER_
   	#define NAND_IO_USE_MCU_ACCESS
    #else
#define NAND_IO_USE_DMA_ACCESS
#endif
#endif

#ifdef NAND_IO_USE_DMA_ACCESS
#define NAND_IO_USE_DMA_DOUBLE_BUF
#define NAND_IO_USE_DMA_DOUBLE_BUF_WRITE
#endif

//=============================================================================
//*
//*
//*                           [ CONST DATA DEFINE ]
//*
//*
//=============================================================================
const NAND_IO_FEATURE	TOSHIBA_NAND_DevInfo[] =
{
   //*=======================================================================================================================================================
    //*[        DEVICE CODE       ][           SIZE            ][               Cycle                     ][               		   ATTRIBUTE                 ]
    //*-------------------------------------------------------------------------------------------------------------------------------------------------------
    //* 1st, 2nd,  3rd,  4th,  5th,  6th,  PBpV,BBpZ, PpB, Page,Spare,Col,Low,Twc, Ws, Wp, Wh, Rs, Rp, Rh
    //*=======================================================================================================================================================
    // [ 32MB] TC58DVM82A1FT
    { {{0x98, 0x75, 0x00, 0x00, 0x00, 0x00}}, 2048,  20,  32,  512,   16,  1,  2, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR)			   	},
    // [ 64MB] TC58DVM92A1FT
    { {{0x98, 0x76, 0x00, 0x00, 0x00, 0x00}}, 4096,  20,  32,  512,   16,  1,  3, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR)			  	},
    // [ 64MB] TC58NWM9S3B
    { {{0x98, 0xF0, 0x00, 0x00, 0x00, 0x00}},  512,  10,  64, 2048,   64,  2,  2, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR)			   	},
    // [128MB] TC58DVG02A1FT
    { {{0x98, 0x79, 0x00, 0x00, 0x00, 0x00}}, 8192,  20,  32,  512,   16,  1,  3, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR)			   	},	
    // [128MB] TC58NVG0S3AFT
    { {{0x98, 0xF1, 0x00, 0x00, 0x00, 0x00}}, 1024,  20,  64, 2048,   64,  2,  2, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR)			   	},	
    // [256MB] TH58NVG1S3AFT
    { {{0x98, 0xDA, 0x00, 0x00, 0x00, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR)			   	},
    // [512MB] THGVN0G4D1DTG00
    { {{0x98, 0xDC, 0x00, 0x15, 0x00, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 50,	 0, 25, 15,  0, 35, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_LBA)		},
    // [512MB] TH58NYG2S8C
    { {{0x98, 0xBC, 0x91, 0xD5, 0x49, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 50,	 0, 25, 15,  0, 35, 15, (A_16BIT|A_SLC	  	|A_BIG  |S_NOR)			   	},
    // [512MB] TH58NYG2S8E
    { {{0x98, 0xBC, 0x90, 0x55, 0x76, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 50,	 0, 25, 15,  0, 35, 15, (A_16BIT|A_SLC	  	|A_BIG  |S_NOR)			   	},
    // [512MB] TH58NVG2D4CTG00
    { {{0x98, 0xDC, 0x84, 0xA5, 0x60, 0x00}}, 2048,  40, 128, 2048,   64,  2,  3, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP2)	   	},
    // [512MB] TH58NVG2D4BFT00
    { {{0x98, 0xDC, 0x84, 0xA5, 0x54, 0x00}}, 2048,  40, 128, 2048,   64,  2,  3, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR) 		   	},
    // [  1GB] TH58NVG3D4BFT00
    { {{0x98, 0xD3, 0x85, 0xA5, 0x58, 0x00}}, 4096,  40, 128, 2048,   64,  2,  3, 50,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR) 	  	    },
    // [  1GB] TC58NVG3D4CTG00
    { {{0x98, 0xD3, 0x84, 0xA5, 0x66, 0x00}}, 4096,  40, 128, 2048,   64,  2,  3, 30,	 0, 20, 10,  0, 20, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP) 		},
    // [  2GB] TH58NVG4D4CFT00	[  4GB] TH58NVG5D4CTG20
    { {{0x98, 0xD5, 0x85, 0xA5, 0x00, 0x00}}, 8192,  40, 128, 2048,   64,  2,  3, 30,	 0, 20, 10,  0, 20, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)    	},
    // [  1GB] TH58NVG3D1DTG00	// 4k Page
    { {{0x98, 0xD3, 0x94, 0xBA, 0x64, 0x00}}, 2048,  40, 128, 4096,  218,  2,  3, 30,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP)		},
	// [  2GB] TH58NVG4D1DTG00	[  4GB] TH58NVG5D1DTG20	
    { {{0x98, 0xD5, 0x94, 0x00, 0x00, 0x00}}, 4096,  40, 128, 4096,  218,  2,  3, 30,	 0, 20, 10,  0, 15, 15, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP)		},
    // [  8GB] TH58NVG6D1DTG20	// 4k Page
    { {{0x98, 0xD7, 0x00, 0x00, 0x00, 0x00}}, 8192,  40, 128, 4096,  218,  2,  3, 30,	 0, 20, 10,  0, 15, 15, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP) 		}
};

const NAND_IO_FEATURE	TOSHIBA_LBA_NAND_DevInfo[] =
{
    //*=======================================================================================================================================================
    //*[        DEVICE CODE       ][           SIZE            ][               Cycle                     ][               		   ATTRIBUTE                 ]
    //*-------------------------------------------------------------------------------------------------------------------------------------------------------
    //* 1st, 2nd,  3rd,  4th,  5th,  6th,  PBpV,BBpZ, PpB, Page,Spare,Col,Low,Twc, Ws, Wp, Wh, Rs, Rp, Rh
    //*=======================================================================================================================================================
    // [  2GB] THGVN0G4D1DTG00
    { {{0x98, 0x21, 0x01, 0x55, 0xAA, 0x00}}, 8192,  40, 128, 4096,  218,  2,  3, 30,	 0, 20, 10,  0, 15, 15, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP)		},
    // [  8GB] THGVN1G6D4ELA02
    { {{0x98, 0x21, 0x03, 0x55, 0xAA, 0x00}}, 8192,  40, 128, 4096,  218,  2,  3, 30,	 0, 20, 10,  0, 15, 15, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP)		},
    // [  16GB] THGVN1G7D8ELA09
    { {{0x98, 0x21, 0x04, 0x55, 0xAA, 0x00}}, 8192,  40, 128, 4096,  218,  2,  3, 30,	 0, 20, 10,  0, 15, 15, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP) 		}
};

const NAND_IO_FEATURE	HYNIX_NAND_DevInfo[] =
{
    //*=======================================================================================================================================================
    //*[        DEVICE CODE       ][           SIZE            ][               Cycle                     ][               		   ATTRIBUTE                 ]
    //*-------------------------------------------------------------------------------------------------------------------------------------------------------
    //* 1st, 2nd,  3rd,  4th,  5th,  6th,  PBpV,BBpZ, PpB, Page,Spare,Col,Low,Twc, Ws, Wp, Wh, Rs, Rp, Rh
    //*=======================================================================================================================================================
    // [ 32MB] HY27US08561M
    { {{0xAD, 0x75, 0x00, 0x00, 0x00, 0x00}}, 2048,  20,  32,  512,   16,  1,  2, 50,	 0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR|S_CB)       	},
    // [ 64MB] HY27US08121M
    { {{0xAD, 0x76, 0x00, 0x00, 0x00, 0x00}}, 4096,  20,  32,  512,   16,  1,  3, 60,	 0, 40, 20,  0, 40, 20, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR|S_CB)       	},
	// [ 64MB] HY27SS16122A
    { {{0xAD, 0x46, 0xAD, 0x46, 0xAD, 0x00}}, 4096,  20,  32,  512,   16,  1,  3, 60,	 0, 40, 20,  0, 50, 20, (A_16BIT|A_SLC	  	|A_SMALL|S_NOR|S_CB)       	},
    // [128MB] HY27UA081G1M
    { {{0xAD, 0x79, 0x00, 0x00, 0x00, 0x00}}, 8192,  20,  32,  512,   16,  1,  3, 60,	 0, 40, 15,  0, 40, 15, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR|S_CB)    	},
    // [128MB] HY27UF081G2M, HY27UF081G2A 
    { {{0xAD, 0xF1, 0x00, 0x00, 0x00, 0x00}}, 1024,  20,  64, 2048,   64,  2,  2, 50,	 0, 35, 20,  0, 35, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP ) 	},
	// [256MB] HY27UF082G2M, HY27UG082G2M
	{ {{0xAD, 0xDA, 0x80, 0x15, 0x00, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 50,	 0, 35, 20,  0, 35, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)  	},
	// [256MB] HY27UF082G2A
	{ {{0xAD, 0xDA, 0x80, 0x1D, 0x00, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 50,	 0, 35, 20,  0, 35, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP ) 	},
	// [256MB] HY27UF082G2B
	{ {{0xAD, 0xDA, 0x10, 0x95, 0x44, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [512MB] HY27UF084G2M
    { {{0xAD, 0xDC, 0x80, 0x95, 0x00, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 30,	 0, 20, 10,  0, 20, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)  	},
	// [512MB] HY27UF084G2B
    { {{0xAD, 0xDC, 0x10, 0x95, 0x00, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_MP)	},
    // [512MB] HY27UG084G2M, HY27UH084G2M
    { {{0xAD, 0xDC, 0x80, 0x15, 0x00, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 60,	 0, 35, 20,  0, 35, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)  	},
    // [512MB] HY27UT084G2M
    { {{0xAD, 0xDC, 0x84, 0x25, 0x00, 0x00}}, 2048,  40, 128, 2048,   64,  2,  3, 50,	 0, 35, 15,  0, 35, 15, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR)				},
    // [512MB] HY27UT084G2A
    { {{0xAD, 0xDC, 0x14, 0xA5, 0x24, 0x00}}, 2048,  25, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [512MB] H8BCS0UN0MCR
    { {{0xAD, 0xBC, 0x10, 0x55, 0x54, 0x00}}, 2048,  25, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [  1GB] HY27UH088G2M
    { {{0xAD, 0xD3, 0x80, 0x15, 0x00, 0x00}}, 8192,  20,  64, 2048,   64,  2,  3, 60,	 0, 35, 20,  0, 35, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)  	},
    // [  1GB] HY27UG088G2M  	[  2GB] HY27UH08AG5M
    { {{0xAD, 0xD3, 0xC1, 0x95, 0x00, 0x00}}, 8192,  20,  64, 2048,   64,  2,  3, 30,	 0, 20, 10,  0, 20, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP) 	},
    // [  2GB] HY27UH08AG5B
    { {{0xAD, 0xD3, 0x51, 0x95, 0x58, 0x00}}, 8192,  20,  64, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)	 	},
    // [  1GB] H27U8G8F2M
    { {{0xAD, 0xD3, 0x10, 0xA6, 0x34, 0x00}}, 4096,  20,  64, 4096,  128,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)	 	},	
    // [  1GB] HY27UU088G2M
    { {{0xAD, 0xD3, 0x85, 0x25, 0x00, 0x00}}, 4096,  40, 128, 2048,   64,  2,  3, 50,	 0, 35, 15,  0, 35, 15, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR)				},
    // [  1GB] HY27UT088G2M  	[  2GB] HY27UU08AG5M
    { {{0xAD, 0xD3, 0x14, 0xA5, 0x64, 0xAD}}, 4096,  25, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [  1GB] HY27UT088G2A
    { {{0xAD, 0xD3, 0x14, 0xA5, 0x34, 0x00}}, 4096,  25, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [  4GB] HY27UV08BG5M	 	[  8GB] HY27UW08CGFM
    { {{0xAD, 0xD5, 0x55, 0xA5, 0x68, 0x00}}, 8192,  25, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [  4GB] HY27UV08BG5A	 
    { {{0xAD, 0xD5, 0x55, 0xA5, 0x38, 0x00}}, 8192,  25, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
	// [  2GB] HY27UAG8T2MTR
    { {{0xAD, 0xD5, 0x14, 0xB6, 0x44, 0x00}}, 4096,  25, 128, 4096,  128,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)	 	},
    // [  8GB] HY27UCG8V5MTR
    { {{0xAD, 0xD7, 0x55, 0xB6, 0x48, 0x00}}, 8192,  25, 128, 4096,  128,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
	// [  4GB] HY27UBG8U5A
    { {{0xAD, 0xD5, 0x94, 0x25, 0x44, 0x41}}, 4096,  25, 128, 4096,  224,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_12BIT|A_BIG  |S_NOR|S_MCP)		},
	// [  8GB] HY27UCG8V5A
    { {{0xAD, 0xD7, 0x95, 0x25, 0x48, 0x41}}, 8192,  25, 128, 4096,  224,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_12BIT|A_BIG  |S_NOR|S_MCP)		}
};

const NAND_IO_FEATURE	ST_NAND_DevInfo[] =
{
    //*=======================================================================================================================================================
    //*[        DEVICE CODE       ][           SIZE            ][               Cycle                     ][               		   ATTRIBUTE                 ]
    //*-------------------------------------------------------------------------------------------------------------------------------------------------------
    //* 1st, 2nd,  3rd,  4th,  5th,  6th,  PBpV,BBpZ, PpB, Page,Spare,Col,Low,Twc, Ws, Wp, Wh, Rs, Rp, Rh
    //*=======================================================================================================================================================
    // [ 32MB] NAND256W3A
    { {{0x20, 0x75, 0x00, 0x00, 0x00, 0x00}}, 2048,  20,  32,  512,   16,  1,  2, 50,  	 0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR)			   	},
    // [ 64MB] NAND512W3A
    { {{0x20, 0x76, 0x00, 0x00, 0x00, 0x00}}, 4096,  20,  32,  512,   16,  1,  3, 50,	 0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR)			   	},
    // [128MB] NAND01GW3A
    { {{0x20, 0x79, 0x00, 0x00, 0x00, 0x00}}, 8192,  20,  32,  512,   16,  1,  3, 50,	 0, 35, 20,  0, 25, 20, (A_08BIT|A_SLC	  	|A_SMALL|S_NOR|S_CB|S_CP)  	},
    // [128MB] NAND01GW3B2C
    { {{0x20, 0xF1, 0x00, 0x1D, 0x00, 0x00}}, 1024,  20,  64, 2048,   64,  2,  2, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR)			 	},
    // [128MB] NAND01GW3B
    { {{0x20, 0xF1, 0x00, 0x00, 0x00, 0x00}}, 1024,  20,  64, 2048,   64,  2,  2, 50,	 0, 35, 20,  0, 35, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)  	},
	// [256MB] NAND02GW3B2D
    { {{0x20, 0xDA, 0x10, 0x95, 0x44, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 45,	 0, 25, 20,  0, 25, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)	   	},
    // [256MB] NAND02GW3B
    { {{0x20, 0xDA, 0x00, 0x00, 0x00, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 50,	 0, 35, 20,  0, 35, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)  	},
    // [256MB] NAND02GR4B2DDI6 
    { {{0x20, 0xBA, 0x10, 0x55, 0x44, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_16BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [512MB] NAND04GR4B2DDI6 
    { {{0x20, 0xBC, 0x10, 0x55, 0x54, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 45,	 0, 30, 15,  0, 30, 15, (A_16BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)		},
	// [512MB] NAND04GW3B2D
    { {{0x20, 0xDC, 0x10, 0x95, 0x54, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [512MB] NAND04GW3B
    { {{0x20, 0xDC, 0x80, 0x95, 0x00, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 50,	 0, 35, 20,  0, 35, 20, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)   },
    // [512MB] NAND04GW3C2A
    { {{0x20, 0xDC, 0x84, 0x25, 0x00, 0x00}}, 2048,  40, 128, 2048,   64,  2,  3, 60,	 0, 40, 20,  0, 40, 20, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR)				},
	// [  1GB] NAND08GW3B2CN6
    { {{0x20, 0xD3, 0x51, 0x95, 0x58, 0x00}}, 8192,  20,  64, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP	|S_IL)	},
    // [  1GB] NAND08GW3B
    { {{0x20, 0xD3, 0x85, 0x25, 0x00, 0x00}}, 8192,  20,  64, 2048,   64,  2,  3, 50,	 0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)  	},
	// [  1GB] NAND08GW3C2A,	[ 2GB] NAND16GW3C4A 
    { {{0x20, 0xD3, 0x14, 0xA5, 0x00, 0x00}}, 4096,  20, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)	  	}
};

const NAND_IO_FEATURE	SAMSUNG_NAND_DevInfo[] =
{
    //*=======================================================================================================================================================
    //*[        DEVICE CODE       ][           SIZE            ][               Cycle                     ][               		   ATTRIBUTE                 ]
	//*-------------------------------------------------------------------------------------------------------------------------------------------------------
    //* 1st, 2nd,  3rd,  4th,  5th,  6th,  PBpV,BBpZ, PpB, Page,Spare,Col,Low,Twc, Ws, Wp, Wh, Rs, Rp, Rh
    //*=======================================================================================================================================================
	// [ 32MB] K9F5608U0B/C/D ~TEST(C) ~TEST(D)   
    { {{0xEC, 0x75, 0x00, 0x00, 0x00, 0x00}}, 2048,  20,  32,  512,   16,  1,  2, 50,  	0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	 	|A_SMALL|S_NOR|S_CB)       	},
    // [ 64MB] K9F1208U0M/A/B
    { {{0xEC, 0x76, 0xA5, 0xC0, 0x00, 0x00}}, 4096,  20,  32,  512,   16,  1,  3, 50,  	0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	 	|A_SMALL|S_NOR|S_CB)   	 	},
    // [ 64MB] K9F1208U0C: ~TEST(C) WC: 42 WP: 21 WH: 15 
    { {{0xEC, 0x76, 0x5A, 0x3F, 0x00, 0x00}}, 4096,  20,  32,  512,   16,  1,  3, 50,  	0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	 	|A_SMALL|S_NOR)		   	 	},
    // [128MB] K9K1G08U0M/A/B: ~TEST(B) 
    { {{0xEC, 0x79, 0xA5, 0xC0, 0x00, 0x00}}, 8192,  20,  32,  512,   16,  1,  3, 50,  	0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	 	|A_SMALL|S_NOR|S_CB)   	 	},
    // [128MB] K9F1G08U0M,A
    { {{0xEC, 0xF1, 0x80, 0x15, 0x40, 0x00}}, 1024,  20,  64, 2048,   64,  2,  2, 50,  	0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	 	|A_BIG  |S_NOR|S_CB|S_CP)	},
    // [128MB] K9F1G08U0C	K9F1G08U0B[ Twc:50 Ws: 0 Wp: 35 Wh: 15]
    { {{0xEC, 0xF1, 0x00, 0x95, 0x40, 0x00}}, 1024,  20,  64, 2048,   64,  2,  2, 50,  	0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	 	|A_BIG  |S_NOR|S_CB) 	  	},
    // [256MB] KBE00S00AB	MCP MEMORY - Supply Voltage: Vcc 2.5 ~ 2.9 
    { {{0xEC, 0x71, 0x5A, 0x3F, 0x00, 0x00}},16384,  20,  32,  512,   16,  1,  3, 50,  	0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	 	|A_SMALL|S_NOR)     	 	},
	// [256MB] K9F2G08U0M, K9K2G08U0M/A ~TEST(A)
    { {{0xEC, 0xDA, 0x00, 0x15, 0x00, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 50,  	0, 35, 15,  0, 35, 15, (A_08BIT|A_SLC	 	|A_BIG  |S_NOR|S_CB|S_CP)	},
	// [256MB] K9F2G08U0A
    { {{0xEC, 0xDA, 0x10, 0x95, 0x44, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 25,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC     	|A_BIG  |S_NOR|S_MP)  		},
    // [512MB] K524G2GACB (mddr MCP)	YKG038QX
    { {{0xEC, 0xBC, 0x00, 0x55, 0x54, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 40,  	0, 21, 10,  0, 21, 10, (A_16BIT|A_SLC	 	|A_BIG  |S_NOR)			   	},
    // [512MB] K524G2GACB (mddr MCP)	YKG040A3
    { {{0xEC, 0xBC, 0x00, 0x55, 0x56, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 40,  	0, 21, 10,  0, 21, 10, (A_16BIT|A_SLC	 	|A_BIG  |S_NOR) 		   	},
    // [512MB] K9K4G08U0M
    { {{0xEC, 0xDC, 0xC1, 0x15, 0x00, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 30,  	0, 20, 10,  0, 20, 10, (A_08BIT|A_SLC	 	|A_BIG  |S_NOR|S_CB|S_CP)  	},
    // [512MB] K9F4G08U0M
    { {{0xEC, 0xDC, 0x10, 0x95, 0x00, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 25,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	 	|A_BIG  |S_NOR|S_CB)	    },
    // [256MB] K9G2G08U0M
	{ {{0xEC, 0xDA, 0x14, 0x25, 0x44, 0x00}}, 1024,  25, 128, 2048,   64,  2,  3, 30,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP) 		},	
    // [512MB] K9G4G08U0M/A		[  1GB] K9L8G08U1M
    { {{0xEC, 0xDC, 0x14, 0x25, 0x54, 0x00}}, 2048,  40, 128, 2048,   64,  2,  3, 30,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP)    	},
    // [512MB] K9G4G08U0B
    { {{0xEC, 0xDC, 0x14, 0xA5, 0x54, 0x00}}, 2048,  25, 128, 2048,   64,  2,  3, 25,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP)    	},
    // [  1GB] K9K8G08UOM		[  2GB] K9WAG08U1M 	
    { {{0xEC, 0xD3, 0x51, 0x95, 0x00, 0x00}}, 8192,  20,  64, 2048,   64,  2,  3, 25,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	 	|A_BIG  |S_NOR|S_CB)		},
    // [  1GB] K9L8G08UOM		[  2GB] K9HAG08U1M
    { {{0xEC, 0xD3, 0x55, 0x25, 0x00, 0x00}}, 4096,  40, 128, 2048,   64,  2,  3, 35,  	0, 25, 10,  0, 25, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP|S_IL)  	},
    // [  1GB] K9G8G08UOM		[  2GB] K9LAG08U1M 
    { {{0xEC, 0xD3, 0x14, 0x25, 0x64, 0x00}}, 4096,  40, 128, 2048,   64,  2,  3, 35,  	0, 25, 10,  0, 25, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP)		},
    // [  1GB] K9G8G08UOA/B		[  2GB] K9LAG08U1A 
    { {{0xEC, 0xD3, 0x14, 0xA5, 0x64, 0x00}}, 4096,  25, 128, 2048,   64,  2,  3, 50,  	0, 30, 20,  0, 30, 20, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP)		},	
    // [  2GB] K9LAG08UOM	  	[  4GB] K9HBG08U1M	  [  8GB] K9MCG08U5M
    { {{0xEC, 0xD5, 0x55, 0x25, 0x68, 0x00}}, 8192,  40, 128, 2048,   64,  2,  3, 30,  	0, 20, 10,  0, 20, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP|S_IL)	},
	// [  2GB] K9LAG08UOA/B	 
	{ {{0xEC, 0xD5, 0x55, 0xA5, 0x68, 0x00}}, 8192,  25, 128, 2048,   64,  2,  3, 25,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP|S_IL)	},
    // [  2GB] K9GAG08UOM	// 4K Page
    { {{0xEC, 0xD5, 0x14, 0xB6, 0x74, 0x00}}, 4096,  25, 128, 4096,  128,  2,  3, 25,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP)		},
    // [  4GB] K9LBG08UOM		[  8GB] K9HCG08U1M    [ 16G] K9MDG08U5M
    { {{0xEC, 0xD7, 0x55, 0xB6, 0x78, 0x00}}, 8192,  25, 128, 4096,  128,  2,  3, 25,  	0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	 	|A_BIG  |S_NOR|S_MP|S_IL)	},
    // [  2GB] K9GAG08UOD		[ 4GB] K9LBG08U1D	  [ 8GB] K9HCG08U5D
    { {{0xEC, 0xD5, 0x94, 0x29, 0x34, 0x41}}, 4096,  25, 128, 4096,  218,  2,  3, 30,   0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MCP)		},
    // [  4GB] K9LBG08UOD		[  8GB] K9HCG08U1D	  [ 16G] K9MDG08U5D   [ 32G] K9PDG08U5D
    { {{0xEC, 0xD7, 0xD5, 0x29, 0x38, 0x41}}, 8192,  25, 128, 4096,  218,  2,  3, 30,  	0, 20, 10,  0, 20, 10, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP|S_IL)	},
    // [  4GB] K9GBG08U0M		[  8GB] K9LCG08U1M		[ 16GB] K9HDG08U5M
    { {{0xEC, 0xD7, 0x94, 0x72, 0x54, 0x42}}, 4096,  20, 128, 8192,  436,  2,  3, 30,  	0, 20, 10,  0, 20, 10, (A_08BIT|A_MLC_16BIT |A_BIG  |S_NOR|S_MCP)		},
	// [  32GB] K9PFG08U5M
    { {{0xEC, 0xDE, 0xD5, 0x72, 0x58, 0x42}}, 8192,  15, 128, 8192,  436,  2,  3, 30,  	0, 20, 10,  0, 20, 10, (A_08BIT|A_MLC_16BIT |A_BIG  |S_NOR|S_MP|S_IL|S_EB)	}
};

const NAND_IO_FEATURE	MICRON_NAND_DevInfo[] =
{
    //*=======================================================================================================================================================
    //*[        DEVICE CODE       ][           SIZE            ][               Cycle                     ][               		   ATTRIBUTE                 ]
    //*-------------------------------------------------------------------------------------------------------------------------------------------------------
    //* 1st, 2nd,  3rd,  4th,  5th,  6th,  PBpV,BBpZ, PpB, Page,Spare,Col,Low,Twc, Ws, Wp, Wh, Rs, Rp, Rh
    //*=======================================================================================================================================================
    // [256MB] 29F2G08AAC		
    { {{0x2C, 0xDA, 0x00, 0x00, 0x00, 0x00}}, 2048,  20,  64, 2048,   64,  2,  3, 30,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CP)   	    },
    // [512MB] 29F4G08BAC,		[  1GB] 29F8G08FAC
    { {{0x2C, 0xDC, 0x80, 0x15, 0x50, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 30,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CP)	    },
    // [512MB] 29F4G08AAA/C		[  1GB] 29F8G08DAA
    { {{0x2C, 0xDC, 0x90, 0x95, 0x54, 0x00}}, 4096,  20,  64, 2048,   64,  2,  3, 30,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [  2GB] 29F16G08FAA
    { {{0x2C, 0xD3, 0xD1, 0x95, 0x58, 0x00}}, 8192,  20,  64, 2048,   64,  2,  3, 30,	 0, 25, 15,  0, 25, 15, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_CB|S_CP)	},
    // [  1GB] MT29F8G08ABA (4Bit/540Bytes)		
    { {{0x2C, 0x38, 0x00, 0x26, 0x85, 0x00}}, 2048,  20, 128, 4096,  224,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_SLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [  1GB] 29F08G08MAA   	[  2GB] 29F16G08QAA
    { {{0x2C, 0xD3, 0x94, 0xA5, 0x64, 0x00}}, 4096,  40, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [  4GB] 29F32G08TAA
    { {{0x2C, 0xD5, 0xD5, 0xA5, 0x68, 0x00}}, 8192,  40, 128, 2048,   64,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC	  	|A_BIG  |S_NOR|S_MP)		},
    // [  2GB] 29F16G08MAA		[  4GB] 29F32G08QAA 
	{ {{0x2C, 0xD5, 0x94, 0x3E, 0x74, 0x00}}, 4096,  25, 128, 4096,  218,  2,  3, 30,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP)		},
	// [  8GB] 29F64G08TAA
	{ {{0x2C, 0xD7, 0xD5, 0x3E, 0x78, 0x00}}, 8192,  25, 128, 4096,  218,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_8BIT	|A_BIG  |S_NOR|S_MP|S_IL)	},
	// [  4GB] 29F32G08CBAAA, 	[  8GB] 29F64G08CFAAA 
	{ {{0x2C, 0xD7, 0x94, 0x3E, 0x84, 0x00}}, 8192,  25, 128, 4096,  218,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_12BIT|A_BIG  |S_NOR|S_MCP)		},
	// [  4GB] 29F32G08CBABA, 	[  8GB] 29F64G08CFABA 
	{ {{0x2C, 0x68, 0x04, 0x46, 0x89, 0x00}}, 4096,  25, 256, 4096,  224,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_12BIT|A_BIG  |S_NOR|S_MCP)		},
	// [ 16GB] 29F128G08CJAA 
	{ {{0x2C, 0xD9, 0xD5, 0x3E, 0x88, 0x00}},16384,  25, 128, 4096,  218,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_12BIT|A_BIG  |S_NOR|S_MP|S_IL)	},
	// [ 16GB] 29F128G08CJBA 
	{ {{0x2C, 0x88, 0x05, 0xC6, 0x89, 0x00}}, 8192,  25, 256, 4096,  224,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_12BIT|A_BIG  |S_NOR|S_MP|S_IL)	}	
};

const NAND_IO_FEATURE	INTEL_NAND_DevInfo[] =
{
	//*=======================================================================================================================================================
    //*[        DEVICE CODE       ][           SIZE            ][               Cycle                     ][               		   ATTRIBUTE                 ]
    //*-------------------------------------------------------------------------------------------------------------------------------------------------------
    //* 1st, 2nd,  3rd,  4th,  5th,  6th,  PBpV,BBpZ, PpB, Page,Spare,Col,Low,Twc, Ws, Wp, Wh, Rs, Rp, Rh
    //*=======================================================================================================================================================
    // [  4GB] JS29F32G08AAMD1 	[  8GB] JS29F64G08CAMD1 	[ 16GB] JS29F16B08JAMD1
	{ {{0x89, 0xD7, 0x94, 0x3E, 0x84, 0x00}}, 8192,  40, 128, 4096,  218,  2,  3, 25,	 0, 15, 10,  0, 15, 10, (A_08BIT|A_MLC_12BIT|A_BIG  |S_NOR|S_MCP)		}
};

const NAND_IO_MAKERINFO	NAND_SupportMakerInfo =
 {
	// MAXIMUM SUPPORT NANDFLASH
	{MAX_SUPPORT_SAMSUNG_NAND,
	MAX_SUPPORT_TOSHIBA_NAND,
	MAX_SUPPORT_HYNIX_NAND,
	MAX_SUPPORT_ST_NAND,
	MAX_SUPPORT_MICRON_NAND,
	MAX_SUPPORT_INTEL_NAND},
	// NAND MAKER ID
	{SAMSUNG_NAND_MAKER_ID,
	TOSHIBA_NAND_MAKER_ID,
	HYNIX_NAND_MAKER_ID,
	ST_NAND_MAKER_ID,
	MICRON_NAND_MAKER_ID,
	INTEL_NAND_MAKER_ID},
	
	// POINTER OF NANDFLASH INFOMATION
	{(NAND_IO_FEATURE*)SAMSUNG_NAND_DevInfo,
	(NAND_IO_FEATURE*)TOSHIBA_NAND_DevInfo,
	(NAND_IO_FEATURE*)HYNIX_NAND_DevInfo,
	(NAND_IO_FEATURE*)ST_NAND_DevInfo,
	(NAND_IO_FEATURE*)MICRON_NAND_DevInfo,
	(NAND_IO_FEATURE*)INTEL_NAND_DevInfo}
};

const NAND_IO_LBA_MAKERINFO	LBA_NAND_SupportMakerInfo =
 {
	// MAXIMUM SUPPORT NANDFLASH
	{MAX_SUPPORT_TOSHIBA_LBA_NAND},
	// NAND MAKER ID
	{TOSHIBA_NAND_MAKER_ID},
	// POINTER OF NANDFLASH INFOMATION
	{(NAND_IO_FEATURE*)TOSHIBA_LBA_NAND_DevInfo}
};

const unsigned char NAND_LBA_VFP_AREA_Signature[] =
{
	"NANDLBASIGNATURE"
};

#define NAND_IO_MAX_SHIFT_FACTOR_FOR_MULTIPLY	16

#if defined (_LINUX_)		/* 09.07.24 */
const unsigned short int    NAND_IO_ShiftFactorForMultiplay[NAND_IO_MAX_SHIFT_FACTOR_FOR_MULTIPLY] __attribute__((aligned(8))) =
{
    1,      //     1 = 2^0
    2,      //     2 = 2^1
    4,      //     4 = 2^2
    8,      //     8 = 2^3
    16,     //    16 = 2^4
    32,     //    32 = 2^5
    64,     //    64 = 2^6
    128,    //   128 = 2^7
    256,    //   256 = 2^8
    512,    //   512 = 2^9
    1024,   //  1024 = 2^10
    2048,   //  2048 = 2^11
    4096,   //  4096 = 2^12
    8192,   //  8192 = 2^13
    16384,  // 16384 = 2^14
    32768	// 32768 = 2^15
};

const unsigned char	ALL_FF_ECC_BCH_04BIT_12[28] __attribute__((aligned(8))) =
{ 
	0x48,0xF6,0x3C,0xC9,0xAA,0x45,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00	
};

const unsigned char	ALL_FF_ECC_BCH_04BIT_16[28] __attribute__((aligned(8))) =
{ 
	0xC4,0x2A,0xDC,0xB4,0x25,0xCC,0x0F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

const unsigned char	ALL_FF_ECC_BCH_01BIT_512[28] __attribute__((aligned(8))) =
{ 
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};
// BCH 4bit Code: 6.5 Byte
const unsigned char	ALL_FF_ECC_BCH_04BIT_512[28] __attribute__((aligned(8))) =
{ 
	0xEB,0x37,0xCC,0x63,0x96,0xCA,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

// BCH 8bit Code:  13 Byte
const unsigned char	ALL_FF_ECC_BCH_08BIT_512[28] __attribute__((aligned(8))) =
{ 
	0x08,0x75,0x8B,0x6F,0x48,0x36,0xA6,0xBC,0x16,0x61,0x58,0xDB,0x52,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

// BCH 12bit Code:  19.5 Byte
const unsigned char	ALL_FF_ECC_BCH_12BIT_512[28] __attribute__((aligned(8)))= 
{ 
	0x81,0xEC,0xE8,0x4E,0xE3,0x46,0x44,0xA1,0x3F,0x8A,0x29,0x06,0xD0,0x90,
	0x06,0x76,0x21,0x32,0x3E,0x0F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

// BCH 14bit Code:  23 Byte
const unsigned char	ALL_FF_ECC_BCH_14BIT_512[28] __attribute__((aligned(8)))= 
{ 
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF
};  

// BCH 16bit Code:  26 Byte
const unsigned char	ALL_FF_ECC_BCH_16BIT_512[28] __attribute__((aligned(8)))= 
{ 
	0xA6,0x14,0x08,0x76,0xEE,0xFE,0x20,0x10,0x9F,0xA3,0xC5,0x06,0x6D,0xDB,
	0xF4,0x51,0xBF,0x38,0x65,0xF8,0xD8,0xC2,0x87,0xFB,0xF1,0x8B,0x00,0x00
};

#else

const unsigned short int    NAND_IO_ShiftFactorForMultiplay[NAND_IO_MAX_SHIFT_FACTOR_FOR_MULTIPLY] =
{
    1,      //     1 = 2^0
    2,      //     2 = 2^1
    4,      //     4 = 2^2
    8,      //     8 = 2^3
    16,     //    16 = 2^4
    32,     //    32 = 2^5
    64,     //    64 = 2^6
    128,    //   128 = 2^7
    256,    //   256 = 2^8
    512,    //   512 = 2^9
    1024,   //  1024 = 2^10
    2048,   //  2048 = 2^11
    4096,   //  4096 = 2^12
    8192,   //  8192 = 2^13
    16384,  // 16384 = 2^14
    32768	// 32768 = 2^15
};

const unsigned char	ALL_FF_ECC_BCH_04BIT_12[28] =
{ 
	0x48,0xF6,0x3C,0xC9,0xAA,0x45,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

const unsigned char	ALL_FF_ECC_BCH_04BIT_16[28] =
{ 
	0xC4,0x2A,0xDC,0xB4,0x25,0xCC,0x0F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

const unsigned char	ALL_FF_ECC_BCH_01BIT_512[28] =
{ 
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

// BCH 4bit Code: 6.5 Byte
const unsigned char	ALL_FF_ECC_BCH_04BIT_512[28] =
{ 
	0xEB,0x37,0xCC,0x63,0x96,0xCA,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

// BCH 8bit Code:  13 Byte
const unsigned char	ALL_FF_ECC_BCH_08BIT_512[28] =
{ 
	0x08,0x75,0x8B,0x6F,0x48,0x36,0xA6,0xBC,0x16,0x61,0x58,0xDB,0x52,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

// BCH 12bit Code:  19.5 Byte
const unsigned char	ALL_FF_ECC_BCH_12BIT_512[28] = 
{ 
	0x81,0xEC,0xE8,0x4E,0xE3,0x46,0x44,0xA1,0x3F,0x8A,0x29,0x06,0xD0,0x90,
	0x06,0x76,0x21,0x32,0x3E,0x0F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

// BCH 14bit Code:  23 Byte
const unsigned char	ALL_FF_ECC_BCH_14BIT_512[28] = 
{ 
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
	0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF
};  

// BCH 16bit Code:  26 Byte
const unsigned char	ALL_FF_ECC_BCH_16BIT_512[28] = 
{ 
	0xA6,0x14,0x08,0x76,0xEE,0xFE,0x20,0x10,0x9F,0xA3,0xC5,0x06,0x6D,0xDB,
	0xF4,0x51,0xBF,0x38,0x65,0xF8,0xD8,0xC2,0x87,0xFB,0xF1,0x8B,0x00,0x00
};

#endif

//=============================================================================
//*
//*
//*                           [ GLOBAL VARIABLE DEFINE ]
//*
//*
//=============================================================================
NAND_IO_CYCLE		WriteCycleTime;
NAND_IO_CYCLE		ReadCycleTime;
NAND_IO_CYCLE		CommCycleTime;
unsigned int		gMaxBusClkMHZ;
unsigned int		gCycleTick;

NAND_IO_ECC_INFO	gMLC_ECC_1Bit;
NAND_IO_ECC_INFO	gMLC_ECC_4Bit;
NAND_IO_ECC_INFO	gMLC_ECC_8Bit;
NAND_IO_ECC_INFO	gMLC_ECC_12Bit;
NAND_IO_ECC_INFO	gMLC_ECC_14Bit;
NAND_IO_ECC_INFO	gMLC_ECC_16Bit;

unsigned int		gNAND_IO_DataBusType;

PGPIO 				pGPIO;
PNFC				pNFC;
PECC				pECC;
PIOBUSCFG			pIOBUSCFG_T;
PPIC 				pPIC;
#if defined(_WINCE_)
tSYSTEM_PARAM  		*pSYS_PARAM;
#endif
PGDMANCTRL			pNAND_DMA;

unsigned int		gInterLeavePageAddr;
unsigned int		gInterLeaveCSNum;
unsigned short int	gInterLeaveIoStatus;
unsigned int		gInterLeaveWriteStatus;

/* Micron Interleaver */
unsigned int		gInterLeaveDie0BlockAddr;
unsigned int		gInterLeaveDie1BlockAddr;

unsigned int		gNANDIO_GSELReg;
unsigned int		gNANDIO_GIOCONReg;
unsigned int		gNANDIO_GDATASet;
unsigned int		gNAND_GPIO_ON_OFF = ENABLE;

unsigned int		*gpDMA_PhyBuffer0;
unsigned int		*gpDMA_WorkBuffer0;
unsigned int		*gpDMA_PhyBuffer1;
unsigned int		*gpDMA_WorkBuffer1;

NAND_IO_DEVINFO 	*gDevInfo;
NAND_IO_DEVINFO 	rDevInfo;

#if defined(TCC89XX) || defined(TCC92XX)
int					gDRV_GDMA_Handle_NAND;
sDRV_GDMA			gDRV_GDMA_NAND	=
{
	0 | DRV_GDMA_CFG_StartByHwReqLevel
	| DRV_GDMA_CFG_AckAtRead
	| DRV_GDMA_CFG_Arbitration//| DRV_GDMA_CFG_NoArbitration
	| DRV_GDMA_CFG_BufNum_1
	| DRV_GDMA_CFG_1HopUnit_16Byte
	| DRV_GDMA_CFG_ReadBW_32Bit
	| DRV_GDMA_CFG_WriteBW_32Bit
	, DRV_GDMA_HwREQ_NFC
	, 0,
};
#endif

#if defined(USE_V_ADDRESS) && defined(_WINCE_)
DWORD		gNFC_IRQ_Intr;
DWORD		gEXT_IRQ_Intr;
HANDLE 		gNFC_IRQ_Handle = NULL;
HANDLE 		gEXT_IRQ_Handle = NULL;
#endif

//#define SPEED_CHECK
#if defined(SPEED_CHECK)
//#define READ_SPEED_CHECK
//#define WRITE_SPEED_CHECK
#endif

#if defined(_WINCE_)
#pragma pack(8)
unsigned char				gNAND_IO_ShareEccBuffer[ 1024 ];
unsigned char				gNAND_IO_TempBuffer[ 32 ];
#pragma pack()
#elif defined(_LINUX_)
#if defined(USE_V_ADDRESS)
unsigned char				*gNAND_IO_ShareEccBuffer;
unsigned char				*gNAND_IO_ShareEccBuffer_w;
#else
unsigned char				gNAND_IO_ShareEccBuffer[ 1024 ] __attribute__((aligned(8)));
#endif
unsigned char				gNAND_IO_TempBuffer[ 32 ] __attribute__((aligned(8)));
#else
__align(8) unsigned char	gNAND_IO_ShareEccBuffer[ 1024 ];
__align(8) unsigned char	gNAND_IO_TempBuffer[ 32 ];
#endif

NAND_LBA_CALLBACK_HANDLER	NAND_IO_LBA_CallBackLcdDisplay;

//=============================================================================
//*
//*
//*                           [ LOCAL FUNCTIONS DEFINE ]
//*
//*
//=============================================================================
static __inline void				NAND_IO_SetDataWidth( U32 width );
static __inline void				NAND_IO_PreProcess( void );
static __inline void				NAND_IO_PostProcess( void );
static __inline void				NAND_IO_SetBasicCycleTime( void );
static __inline void				NAND_IO_SetWriteCycleTime(void);
static __inline void				NAND_IO_EnableChipSelect( U16 nChipNo );
static __inline void				NAND_IO_DisableChipSelect( void );
static __inline void				NAND_IO_EnableWriteProtect( void );
static __inline void				NAND_IO_DisableWriteProtect( void );
static __inline U32					NAND_IO_CheckReadyAndBusy( U16 nChipNo);
static __inline void				NAND_IO_WaitBusy( U16 nChipNo );
static __inline void				NAND_IO_WaitBusyForProgramAndErase( NAND_IO_DEVINFO *nDevInfo );
static __inline void				NAND_IO_WaitBusyForCacheProgram( NAND_IO_DEVINFO *nDevInfo );
static __inline void 				NAND_IO_ClearInterleaveStatus( NAND_IO_DEVINFO *nDevInfo );
static __inline void				NAND_IO_Delay( void );

static __inline NAND_IO_ERROR  		NAND_IO_WaitBusyForInterleave( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr );
static __inline NAND_IO_ERROR		NAND_IO_ReadStatus( NAND_IO_DEVINFO *nDevInfo );
static __inline NAND_IO_ERROR		NAND_IO_ReadStatusForMultiPlane( NAND_IO_DEVINFO *nDevInfo );
static __inline NAND_IO_ERROR		NAND_IO_ReadStatusForCacheProgram( NAND_IO_DEVINFO *nDevInfo );
static __inline NAND_IO_ERROR		NAND_IO_ReadStatusForInterleave( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr );
static __inline NAND_IO_ERROR		NAND_IO_ReadStatusForInterleaveClear( NAND_IO_DEVINFO *nDevInfo );

static __inline NAND_IO_ERROR		NAND_IO_GenerateRowColAddrForRead( U32 nPageAddr, U16 nColumnAddr, U32* rRowAddr, U32* rColumnAddr, NAND_IO_DEVINFO *nDevInfo );
static __inline NAND_IO_ERROR		NAND_IO_GenerateRowColAddrForWrite( U32 nPageAddr, U16 nColumnAddr, U32* rRowAddr, U32* rColumnAddr, NAND_IO_DEVINFO *nDevInfo );
static __inline NAND_IO_ERROR		NAND_IO_GenerateRowColAddrForCBandCP( U32 nPageAddr, U16 nColumnAddr, U32* rRowAddr, U32* rColumnAddr, NAND_IO_DEVINFO *nDevInfo );
static __inline void				NAND_IO_WriteRowColAddr( U32 nRowAddr, U32 nColumnAddr, NAND_IO_DEVINFO *nDevInfo );
static __inline void				NAND_IO_WriteBlockPageAddr( U32 nBlockPageAddr, NAND_IO_DEVINFO *nDevInfo );
static __inline void				NAND_IO_BusControl( NAND_IO_DEVINFO *nDevInfo );

static __inline void 				NAND_IO_SetupDMA(void * pSRC, unsigned uSrcInc, unsigned uSrcMask, void * pDST, unsigned uDstInc, unsigned uDstMask, int nMode, int nDSize );
static __inline void 				NAND_IO_SetupDMA_kernel(void * pSRC, unsigned uSrcInc, unsigned uSrcMask, void * pDST, unsigned uDstInc, unsigned uDstMask, int nMode, int nDSize );
static __inline void 				NAND_IO_SetupDMADoubleBuf(  int nMode, int nDMACh );

static __inline void				NAND_IO_SetupECC( U16 nEccOnOff, U16 nEncDec, U16 nEccType, U16 nAccessType, U32 EccBaseAddr );
static __inline NAND_IO_ERROR 		NAND_IO_EncodeECC( U16 nEccType, U8* nSpareBuffer );
static __inline NAND_IO_ERROR		NAND_IO_CorrectionSLC( U8* nPageBuffer, U8* nSpareBuffer );
static __inline NAND_IO_ERROR 		NAND_IO_CorrectionMLC_IRQ( U16 nEccType, U8* nPageBuffer, U8* nSpareBuffer, U16 nDataSize );
static __inline NAND_IO_ERROR 		NAND_IO_CorrectionMLC( U16 nEccType, U8* nPageBuffer, U8* nSpareBuffer, U16 nDataSize );
static __inline NAND_IO_ERROR 		NAND_IO_EncodeBootBinary( NAND_IO_DEVINFO *nDevInfo, U8 *nPageBuffer, int nEccOnOff );

static __inline NAND_IO_ERROR 		NAND_IO_ReadSpareData( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nPageEccOnOff );
static __inline NAND_IO_ERROR		NAND_IO_Read512DataDoubleBuf( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff, int nSpareOnOff );
static __inline NAND_IO_ERROR		NAND_IO_Read512Data( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff, int nSpareOnOff );
static __inline NAND_IO_ERROR 		NAND_IO_ReadSpareDataMTD( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nPageEccOnOff );
static __inline NAND_IO_ERROR		NAND_IO_ReadUserSizeData( NAND_IO_DEVINFO *nDevInfo, U16 nColumnAddr, U32 nReadSize, U8 *nReadBuffer );
static __inline NAND_IO_ERROR 		NAND_IO_Read512DataMTD( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff, int nSpareOnOff );

static __inline NAND_IO_ERROR		NAND_IO_Write512DataDoubleBuf( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
static __inline NAND_IO_ERROR		NAND_IO_Write512Data( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
static __inline NAND_IO_ERROR		NAND_IO_WriteUserSizeData( NAND_IO_DEVINFO *nDevInfo, U16 nColumnAddr, U32 nWriteSize, U8 *nWriteBuffer );
static __inline NAND_IO_ERROR 		NAND_IO_Write512DataMTD( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );

static __inline	void 				NAND_IO_CheckForExtendBlockAccess( NAND_IO_DEVINFO *nDevInfo, U32* nPageAddr );

static __inline NAND_IO_ERROR		NAND_IO_GetShiftValueForFastMultiPly( U16 nValue, U16* rFactor );

#if defined (NAND_LBA_INCLUDE)
static __inline void 				NAND_IO_LBA_WaitBusy( U16 nChipNo );
static __inline NAND_IO_ERROR NAND_IO_LBA_ReadData_VFP( NAND_IO_DEVINFO *nDevInfo, U16 nReadPPSize, U8 *nPageBuffer, U8 *nSpareBuffer );
static __inline NAND_IO_ERROR 		NAND_IO_LBA_ReadData( NAND_IO_DEVINFO *nDevInfo, U16 nReadPPSize, U8 *nPageBuffer, U8 *nSpareBuffer );
static __inline NAND_IO_ERROR 		NAND_IO_LBA_WriteData( NAND_IO_DEVINFO *nDevInfo, U16 nWritePPSize, U8 *nPageBuffer, U8 *nSpareBuffer );
static __inline NAND_IO_ERROR 		NAND_IO_LBA_WriteDummyData( NAND_IO_DEVINFO *nDevInfo, U16 nWritePPSize );

NAND_IO_ERROR 						NAND_IO_LBA_ConvertMPPA( NAND_IO_DEVINFO *nDevInfo, U8 nPartition, U32 nSectorAddr, U32 nSecSize, U32 *nConvertAddr, U32 *nConvertSize, U16 *rMediaOrder );
NAND_IO_ERROR 						NAND_IO_LBA_VFPInitArea( NAND_IO_DEVINFO *nDevInfo );
NAND_IO_ERROR						NAND_IO_LBA_MDPGetTotalSectorSize(NAND_IO_DEVINFO * nDevInfo, unsigned long int * rTotalSector);
NAND_IO_ERROR						NAND_IO_LBA_VFPGetTotalSectorSize(NAND_IO_DEVINFO * nDevInfo, U32 * rTotalSector);
NAND_IO_ERROR						NAND_IO_LBA_VFPChangeSectorSize(NAND_IO_DEVINFO * nDevInfo, U32 nTotalSector);
NAND_IO_ERROR						NAND_IO_LBA_SetTransferProtocol(NAND_IO_DEVINFO * nDevInfo, U8 nProtocol1, U8 nProtocol2);
NAND_IO_ERROR 						NAND_IO_LBA_SetBootModeChange( NAND_IO_DEVINFO *nDevInfo, U8 nBootMode );
NAND_IO_ERROR 						NAND_IO_LBA_SetRebootCmdChange( NAND_IO_DEVINFO *nDevInfo, U8 nRebootCmd );
NAND_IO_ERROR						NAND_IO_LBA_SetAreaPartition( NAND_IO_DEVINFO *nDevInfo, NAND_IO_FEATURE * sDevFeatureInfo );
NAND_IO_ERROR 						NAND_IO_LBA_GetPersistentFunction( NAND_IO_DEVINFO *nDevInfo, U8 *rBootMode, U8 *rRebootCmd );
NAND_IO_ERROR 						NAND_IO_LBA_GetTransferProtocol( NAND_IO_DEVINFO *nDevInfo, U8 *rProtocol1, U8 *rProtocol2 );
NAND_IO_ERROR 						NAND_IO_LBA_GetBootMode( NAND_IO_DEVINFO *nDevInfo, U8 *rBootMode );
NAND_IO_ERROR 						NAND_IO_LBA_ReadID( NAND_IO_DEVINFO *nDevInfo, NAND_IO_DEVID *nDeviceCode );
NAND_IO_ERROR 						NAND_IO_LBA_ReadUID( NAND_IO_DEVINFO *nDevInfo );
NAND_IO_ERROR 						NAND_IO_LBA_Reset( NAND_IO_DEVINFO *nDevInfo );
#endif

//=============================================================================
//*
//*
//*                     [ EXTERN VARIABLE & FUNCTIONS DEFINE ]
//*
//*
//=============================================================================
#if defined(_LINUX_) || defined(_WINCE_)
int						TCC7XX_USBDRV_WriteToQueue( void ){ return 0;}
extern unsigned int		gMAX_ROMSIZE;
#else
extern void				memcpy(void *pvDest, const void *pvSrc, unsigned long iCount);
extern void				memset(void *pvDest, char cChar, unsigned long iCount);
extern int				memcmp(const void *pvSrc1, const void *pvSrc2, unsigned long iCount);
extern int				TCC7XX_USBDRV_WriteToQueue( void );
extern unsigned int		gMAX_ROMSIZE;
#endif

extern unsigned			CRC32_TABLE[];

#ifndef _LINUX_
extern unsigned			fmemcpy16(void *dest, void *src, unsigned length);
#endif

#ifdef SPEED_CHECK
void NAND_IO_GPIO_Toggle( U32 nBitNum )
{
	if( pGPIO->GPFDAT & nBitNum )
		BITCLR(pGPIO->GPFDAT, nBitNum);
	else
		BITSET(pGPIO->GPFDAT, nBitNum);
}
#endif

#if defined(_WINCE_)
extern void B_RETAILMSG(const char * fmt, ...);
#endif

/******************************************************************************
*
*	unsigned char*	NAND_IO_TellLibraryVersion
*
*	Input	: NONE
*	Output	: NONE
*	Return	: NONE
*
*	Description :
*
*******************************************************************************/
unsigned char*	NAND_IO_TellLibraryVersion( void )
{
	return (unsigned char*)NANDIO_Library_Version;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      NAND_IO_ERROR NAND_IO_NANDGPIOControlFlag( unsigned int on_off );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			on_off	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
*  REMARK:	  by nemo
**************************************************************************/
NAND_IO_ERROR NAND_IO_NANDGPIOControlFlag( unsigned int on_off )
{
	gNAND_GPIO_ON_OFF = on_off;

	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_CallBackChangeWCtime
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_CallBackChangeWCtime( unsigned short int TotalMediaNum, NAND_IO_DEVINFO *nDevInfo )
{
	if ( nDevInfo->IoStatus == ENABLE )
	{
		//**************************************************************
		// Case on K9NBG08U5M Samsung NANDFLASH
		//**************************************************************
		if ( nDevInfo->Feature.DeviceID.Code[0] == 0xEC &&
			 nDevInfo->Feature.DeviceID.Code[1] == 0xD3 &&
			 nDevInfo->Feature.DeviceID.Code[2] == 0x51 &&
			 nDevInfo->Feature.DeviceID.Code[3] == 0x95 )
		{
			if ( TotalMediaNum == 4 )
			{
				nDevInfo->Feature.WCtime 	= 45;

				nDevInfo->Feature.WriteSTP 	= 0;
				nDevInfo->Feature.WriteWP 	= 30;
				nDevInfo->Feature.WriteHLD 	= 15;

				nDevInfo->Feature.ReadSTP	= 0;
				nDevInfo->Feature.ReadPW 	= 30;
				nDevInfo->Feature.ReadHLD 	= 15;
				
				NAND_IO_SetCycle( nDevInfo );
			}
		}
		//**************************************************************
		// Case on K9MBG08U5M Samsung NANDFLASH
		//**************************************************************
		else if ( nDevInfo->Feature.DeviceID.Code[0] == 0xEC &&
			 	  nDevInfo->Feature.DeviceID.Code[1] == 0xD3 &&
				  nDevInfo->Feature.DeviceID.Code[2] == 0x55 &&
				  nDevInfo->Feature.DeviceID.Code[3] == 0x25 )
		{
			if ( TotalMediaNum == 4 )
			{
				nDevInfo->Feature.WCtime = 45;

				nDevInfo->Feature.WriteSTP 	= 0;
				nDevInfo->Feature.WriteWP 	= 30;
				nDevInfo->Feature.WriteHLD 	= 15;

				nDevInfo->Feature.ReadSTP	= 0;
				nDevInfo->Feature.ReadPW 	= 30;
				nDevInfo->Feature.ReadHLD 	= 15;

				NAND_IO_SetCycle( nDevInfo );
			}
		}
		//**************************************************************
		// Case on K9MCG08U5M Samsung NANDFLASH
		//**************************************************************
		else if ( nDevInfo->Feature.DeviceID.Code[0] == 0xEC &&
			 	  nDevInfo->Feature.DeviceID.Code[1] == 0xD5 &&
			 	  nDevInfo->Feature.DeviceID.Code[2] == 0x55 &&
			 	  nDevInfo->Feature.DeviceID.Code[3] == 0x25 &&
			 	  nDevInfo->Feature.DeviceID.Code[4] == 0x68 )
		{
			if ( TotalMediaNum == 4 )
			{
				nDevInfo->Feature.WCtime = 45;

				nDevInfo->Feature.WriteSTP 	= 0;
				nDevInfo->Feature.WriteWP 	= 30;
				nDevInfo->Feature.WriteHLD 	= 15;

				nDevInfo->Feature.ReadSTP	= 0;
				nDevInfo->Feature.ReadPW 	= 30;
				nDevInfo->Feature.ReadHLD 	= 15;

				NAND_IO_SetCycle( nDevInfo );
			}
		}
		//**************************************************************
		// Case on K9MDG08U5M Samsung NANDFLASH
		//**************************************************************
		else if ( nDevInfo->Feature.DeviceID.Code[0] == 0xEC &&
			 	  nDevInfo->Feature.DeviceID.Code[1] == 0xD7 &&
			 	  nDevInfo->Feature.DeviceID.Code[2] == 0x55 &&
			 	  nDevInfo->Feature.DeviceID.Code[3] == 0xB6 &&
			 	  nDevInfo->Feature.DeviceID.Code[4] == 0x78 )
		{
			if ( TotalMediaNum == 4 )
			{
				nDevInfo->Feature.WCtime = 45;

				nDevInfo->Feature.WriteSTP 	= 0;
				nDevInfo->Feature.WriteWP 	= 30;
				nDevInfo->Feature.WriteHLD 	= 15;

				nDevInfo->Feature.ReadSTP	= 0;
				nDevInfo->Feature.ReadPW 	= 30;
				nDevInfo->Feature.ReadHLD 	= 15;

				NAND_IO_SetCycle( nDevInfo );
			}
		}
		//**************************************************************
		// Case on K9MDG08U5D Samsung NANDFLASH
		//**************************************************************
		else if ( nDevInfo->Feature.DeviceID.Code[0] == 0xEC &&
			 	  nDevInfo->Feature.DeviceID.Code[1] == 0xD7 &&
			 	  nDevInfo->Feature.DeviceID.Code[2] == 0xD5 &&
			 	  nDevInfo->Feature.DeviceID.Code[3] == 0x29 &&
			 	  nDevInfo->Feature.DeviceID.Code[4] == 0x38 )
		{
			if ( TotalMediaNum == 2 )
			{
				nDevInfo->Feature.WCtime = 45;

				nDevInfo->Feature.WriteSTP 	= 0;
				nDevInfo->Feature.WriteWP 	= 30;
				nDevInfo->Feature.WriteHLD 	= 15;

				nDevInfo->Feature.ReadSTP	= 0;
				nDevInfo->Feature.ReadPW 	= 30;
				nDevInfo->Feature.ReadHLD 	= 15;

				NAND_IO_SetCycle( nDevInfo );
			}
		}
		//**************************************************************
		// Case on K9MDG08U5D Samsung NANDFLASH
		//**************************************************************
		else if ( nDevInfo->Feature.DeviceID.Code[0] == 0xEC &&
			 	  nDevInfo->Feature.DeviceID.Code[1] == 0xDE &&
			 	  nDevInfo->Feature.DeviceID.Code[2] == 0xD5 &&
			 	  nDevInfo->Feature.DeviceID.Code[3] == 0x72 &&
			 	  nDevInfo->Feature.DeviceID.Code[4] == 0x58 && 
			 	  nDevInfo->Feature.DeviceID.Code[5] == 0x42)
		{
			if ( ( TotalMediaNum >= 2 ) || ( nDevInfo->Feature.MediaType & A_PARALLEL ) )
			{
				nDevInfo->Feature.WCtime = 45;

				nDevInfo->Feature.WriteSTP 	= 0;
				nDevInfo->Feature.WriteWP 	= 30;
				nDevInfo->Feature.WriteHLD 	= 15;

				nDevInfo->Feature.ReadSTP	= 0;
				nDevInfo->Feature.ReadPW 	= 30;
				nDevInfo->Feature.ReadHLD 	= 15;

				NAND_IO_SetCycle( nDevInfo );
			}
		}
		
		//**************************************************************
		// Case on TH58NVG5D4CTG20 Toshiba NANDFLASH
		//**************************************************************
		else if ( nDevInfo->Feature.DeviceID.Code[0] == 0x98 &&
			 	  nDevInfo->Feature.DeviceID.Code[1] == 0xD5 &&
			 	  nDevInfo->Feature.DeviceID.Code[2] == 0x85 &&
			 	  nDevInfo->Feature.DeviceID.Code[3] == 0xA5 )
		{
			if ( TotalMediaNum == 2 )
			{
				nDevInfo->Feature.WCtime = 30;

				nDevInfo->Feature.WriteSTP 	= 0;
				nDevInfo->Feature.WriteWP 	= 20;
				nDevInfo->Feature.WriteHLD 	= 10;

				nDevInfo->Feature.ReadSTP	= 0;
				nDevInfo->Feature.ReadPW 	= 20;
				nDevInfo->Feature.ReadHLD 	= 10;

				NAND_IO_SetCycle( nDevInfo );
			}
		}
	}

	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_SetCycle
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_SetCycle( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int	nMaxBusClk;
	unsigned int	nMaxBusClkMHZ;
	unsigned int	nCycleTick;
	unsigned int	nTickRange = 10;
	unsigned int	nDevSTP, nDevPW, nDevHLD;
	unsigned int	nMCycleSTP, nMCyclePW, nMCycleHLD;
	unsigned int	nSCycleSTP, nSCyclePW, nSCycleHLD;
	int				nRemainSTP, nRemainPW, nRemainHLD;
	int				nTempResult;
	unsigned int	nReCompRatioSTP, nReCompRatioHLD, nReCompRatioPW;
	unsigned int	nWrCompRatioSTP, nWrCompRatioHLD, nWrCompRatioPW;
	unsigned int	nCoCompRatioSTP, nCoCompRatioHLD, nCoCompRatioPW;	
	unsigned int	nReGateDelay, nWrGateDelay;

	//===================================
	// Get Max Bus CLK
	//===================================
	#ifdef FWDN_DOWNLOADER_INCLUDE
	nMaxBusClk = 1000000;	// 100MHZ
	#elif defined(TCC89XX) || defined(TCC92XX)
	{
		#if defined(_WINCE_)
			#if defined(USE_V_ADDRESS)
			nMaxBusClk = tcc_ckc_getfbusctrl(CLKCTRL4);		
			#else
			tca_ckc_init();
			nMaxBusClk = tca_ckc_getfbusctrl(CLKCTRL4);
			#endif
		#elif defined(_LINUX_)
			tca_ckc_init();
			nMaxBusClk = tca_ckc_getfbusctrl(CLKCTRL4);
		#else
		    //#ifdef CLOCK_ADJUST_ENABLE
		    //nMaxBusClk	= IO_CKC_GetCurrentBUSClock4Cycle();
		    //#else
		    //nMaxBusClk = IO_CKC_Fmaxbus;	// frequency of 100Hz unit
		    //#endif
			nMaxBusClk = 1660000;		
		#endif
	}
	#endif

	if ( nMaxBusClk  == 0 )
		nMaxBusClk = 1660000;

	/* Convert MHZ Value of Max Bus Clock */
	if (!( nMaxBusClk / 10000 ))
		return ERR_NAND_IO_WRONG_PARAMETER;
	nMaxBusClkMHZ = ( nMaxBusClk / 10000 );

	/* Get Cycke Tick */
	nCycleTick = ( 1000 * nTickRange ) / nMaxBusClkMHZ;
	if (( 1000 * nTickRange ) % nMaxBusClkMHZ )
		++nCycleTick;

	//===================================
	// Set Cycle
	//===================================

	/* Basis Setting */
	#if defined(TCC89XX) || defined(TCC92XX)	
	nReGateDelay	= 15;	
	nWrGateDelay	= 0;
	#else
	nReGateDelay	= 15;	
	nWrGateDelay	= 0;
	#endif

	nReCompRatioSTP	= 6;
	nReCompRatioHLD	= 0;
	nReCompRatioPW	= 0;
	
	nWrCompRatioSTP	= 6;
	nWrCompRatioHLD	= 0;
	nWrCompRatioPW	= 0;

	nCoCompRatioSTP	= 0;
	nCoCompRatioHLD	= 0;
	nCoCompRatioPW	= 0;

	/* Read Cycle */
	nDevSTP				= nDevInfo->Feature.ReadSTP * nTickRange;
	nDevPW				= nDevInfo->Feature.ReadPW * nTickRange;
	nDevHLD				= nDevInfo->Feature.ReadHLD * nTickRange;
	
	nMCycleSTP			= ( nDevSTP / nCycleTick ) + (( nDevSTP && !( nDevSTP / nCycleTick )) ? 1 : 0 );
	nMCycleHLD			= ( nDevHLD / nCycleTick ) + (( nDevHLD && !( nDevHLD / nCycleTick )) ? 1 : 0 );
	nRemainSTP			= ( nMCycleSTP * nCycleTick ) - nDevSTP;
	nRemainHLD			= ( nMCycleHLD * nCycleTick ) - nDevHLD;
	nSCycleSTP			= (( nRemainSTP < 0 ) && ((( nRemainSTP >= 0 ) ? nRemainSTP : -nRemainSTP ) > (int)(( nCycleTick / 10 ) * nReCompRatioSTP ))) ? 1 : 0;
	nSCycleHLD			= (( nRemainHLD < 0 ) && ((( nRemainHLD >= 0 ) ? nRemainHLD : -nRemainHLD ) > (int)(( nCycleTick / 10 ) * nReCompRatioHLD ))) ? 1 : 0;
	nTempResult			= ( nDevPW + ( nReGateDelay * nTickRange )) + (( nRemainSTP >= 0 ) ? 0 : -nRemainSTP ) + (( nRemainHLD >= 0 ) ? 0 : -nRemainHLD );
	nMCyclePW			= ( nTempResult >= (int)nCycleTick ) ? ( nTempResult / nCycleTick ) : 1;
	nRemainPW			= ( nMCyclePW * nCycleTick ) - ( nDevPW + ( nReGateDelay * nTickRange ));
	nSCyclePW			= (( nRemainPW < 0 ) && ((( nRemainPW >= 0 ) ? nRemainPW : -nRemainPW ) > (int)(( nCycleTick / 10 ) * nReCompRatioPW ))) ? 1 : 0;

	ReadCycleTime.STP	= (U8)(nMCycleSTP + nSCycleSTP);
	ReadCycleTime.HLD	= (U8)(nMCycleHLD + nSCycleHLD);
	ReadCycleTime.PW	= (U8)(nMCyclePW + nSCyclePW + (( nDevInfo->Feature.MediaType & A_PARALLEL ) ? 1: 0 ));

	/* Write Cycle */
	nDevSTP				= nDevInfo->Feature.WriteSTP * nTickRange;
	nDevPW				= nDevInfo->Feature.WriteWP * nTickRange;
	nDevHLD				= nDevInfo->Feature.WriteHLD * nTickRange;
	
	nMCycleSTP			= ( nDevSTP / nCycleTick ) + (( nDevSTP && !( nDevSTP / nCycleTick )) ? 1 : 0 );
	nMCycleHLD			= ( nDevHLD / nCycleTick ) + (( nDevHLD && !( nDevHLD / nCycleTick )) ? 1 : 0 );
	nRemainSTP			= ( nMCycleSTP * nCycleTick ) - nDevSTP;
	nRemainHLD			= ( nMCycleHLD * nCycleTick ) - nDevHLD;
	nSCycleSTP			= (( nRemainSTP < 0 ) && ((( nRemainSTP >= 0 ) ? nRemainSTP : -nRemainSTP ) > (int)(( nCycleTick / 10 ) * nWrCompRatioSTP ))) ? 1 : 0;
	nSCycleHLD			= (( nRemainHLD < 0 ) && ((( nRemainHLD >= 0 ) ? nRemainHLD : -nRemainHLD ) > (int)(( nCycleTick / 10 ) * nWrCompRatioHLD ))) ? 1 : 0;
	nTempResult			= ( nDevPW + ( nWrGateDelay * nTickRange )) + (( nRemainSTP >= 0 ) ? 0 : -nRemainSTP ) + (( nRemainHLD >= 0 ) ? 0 : -nRemainHLD );
	nMCyclePW			= ( nTempResult >= (int)nCycleTick ) ? ( nTempResult / nCycleTick ) : 1;
	nRemainPW			= ( nMCyclePW * nCycleTick ) - ( nDevPW + ( nWrGateDelay * nTickRange ));
	nSCyclePW			= (( nRemainPW < 0 ) && ((( nRemainPW >= 0 ) ? nRemainPW : -nRemainPW ) > (int)(( nCycleTick / 10 ) * nWrCompRatioPW ))) ? 1 : 0;

	WriteCycleTime.STP	= (U8)(nMCycleSTP + nSCycleSTP);
	WriteCycleTime.HLD	= (U8)(nMCycleHLD + nSCycleHLD);
	WriteCycleTime.PW	= (U8)(nMCyclePW + nSCyclePW);
	
	/* Comm Cycle */
	nDevSTP				= 10 * nTickRange;
	nDevPW				= 80 * nTickRange;
	nDevHLD				= 40 * nTickRange;
	
	nMCycleSTP			= ( nDevSTP / nCycleTick ) + (( nDevSTP && !( nDevSTP / nCycleTick )) ? 1 : 0 );
	nMCycleHLD			= ( nDevHLD / nCycleTick ) + (( nDevHLD && !( nDevHLD / nCycleTick )) ? 1 : 0 );
	nRemainSTP			= ( nMCycleSTP * nCycleTick ) - nDevSTP;
	nRemainHLD			= ( nMCycleHLD * nCycleTick ) - nDevHLD;
	nSCycleSTP			= (( nRemainSTP < 0 ) && ((( nRemainSTP >= 0 ) ? nRemainSTP : -nRemainSTP ) > (int)(( nCycleTick / 10 ) * nCoCompRatioSTP ))) ? 1 : 0;
	nSCycleHLD			= (( nRemainHLD < 0 ) && ((( nRemainHLD >= 0 ) ? nRemainHLD : -nRemainHLD ) > (int)(( nCycleTick / 10 ) * nCoCompRatioHLD ))) ? 1 : 0;
	nTempResult			= ( nDevPW + ( nReGateDelay * nTickRange )) + (( nRemainSTP >= 0 ) ? 0 : -nRemainSTP ) + (( nRemainHLD >= 0 ) ? 0 : -nRemainHLD );
	nMCyclePW			= ( nTempResult >= (int)nCycleTick ) ? ( nTempResult / nCycleTick ) : 1;
	nRemainPW			= ( nMCyclePW * nCycleTick ) - ( nDevPW + ( nReGateDelay * nTickRange ));
	nSCyclePW			= (( nRemainPW < 0 ) && ((( nRemainPW >= 0 ) ? nRemainPW : -nRemainPW ) > (int)(( nCycleTick / 10 ) * nCoCompRatioPW ))) ? 1 : 0;

	CommCycleTime.STP	= (U8)(nMCycleSTP + nSCycleSTP);
	CommCycleTime.HLD	= (U8)(nMCycleHLD + nSCycleHLD);
	CommCycleTime.PW	= (U8)(nMCyclePW + nSCyclePW);

	if (WriteCycleTime.STP >= 16)
		WriteCycleTime.STP	= 15;
	if (WriteCycleTime.PW >= 16)
		WriteCycleTime.PW	= 15;
	if (WriteCycleTime.HLD >= 16)
		WriteCycleTime.HLD	= 15;
	if (WriteCycleTime.HLD == 0)
		WriteCycleTime.HLD	= 1;	

	if (ReadCycleTime.STP >= 16)
		ReadCycleTime.STP	= 15;
	if (ReadCycleTime.PW >= 16)
		ReadCycleTime.PW	= 15;
	if (ReadCycleTime.HLD >= 16)
		ReadCycleTime.HLD	= 15;

	if (CommCycleTime.STP >= 16)
		CommCycleTime.STP	= 15;
	if (CommCycleTime.PW >= 16)
		CommCycleTime.PW	= 15;
	if (CommCycleTime.HLD >= 16)
		CommCycleTime.HLD	= 15;

	if ( ReadCycleTime.PW < 2 )
		ReadCycleTime.PW  = 2;
	if ( ReadCycleTime.HLD < 2 )
		ReadCycleTime.HLD  = 2;
		
	if ( gNAND_IO_DataBusType == NAND_IO_NFC_BUS )
	{
		WriteCycleTime.RegValue	= ( WriteCycleTime.STP << 8 ) + ( WriteCycleTime.PW << 4 ) + WriteCycleTime.HLD;
		ReadCycleTime.RegValue	= ( ReadCycleTime.STP << 8 ) + ( ReadCycleTime.PW << 4 ) + ReadCycleTime.HLD;
		CommCycleTime.RegValue	= ( CommCycleTime.STP << 8 ) + ( CommCycleTime.PW << 4 ) + CommCycleTime.HLD;
	}
	else if ( gNAND_IO_DataBusType == NAND_IO_MEM_BUS )
	{
		#if defined(TCC860x)
			WriteCycleTime.RegValue	= ( WriteCycleTime.STP << 6 ) + ( WriteCycleTime.PW << 3 ) + WriteCycleTime.HLD;
			ReadCycleTime.RegValue	= ( ReadCycleTime.STP << 6 ) + ( ReadCycleTime.PW << 3 ) + ReadCycleTime.HLD;
			CommCycleTime.RegValue	= ( CommCycleTime.STP << 6 ) + ( CommCycleTime.PW << 3 ) + CommCycleTime.HLD;
		#else
		    WriteCycleTime.RegValue	= ( WriteCycleTime.STP << 11 ) + (( WriteCycleTime.PW - 1 ) << 3 ) + WriteCycleTime.HLD;
		    ReadCycleTime.RegValue	= ( ReadCycleTime.STP << 11 ) + (( ReadCycleTime.PW - 1 ) << 3 ) + ReadCycleTime.HLD;
		    CommCycleTime.RegValue	= ( CommCycleTime.STP << 11 ) + (( CommCycleTime.PW - 1 ) << 3 ) + CommCycleTime.HLD;
		#endif
	}

	gMaxBusClkMHZ = nMaxBusClkMHZ;
	gCycleTick = nCycleTick;

	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_GetDeviceInfo
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_GetDeviceInfo( U16 nChipNo, NAND_IO_DEVINFO *nDevInfo )
{
	unsigned short int		j,k,l;
	unsigned char			bFindMedia;
	unsigned char			bFindMakerNo;
	unsigned char			bMatchCount;
	NAND_IO_DEVID			sDeviceCode1,sDeviceCode2;
	NAND_IO_FEATURE			*sTempFeatureInfo;
	NAND_IO_FEATURE			*sFindFeatureInfo;
	NAND_IO_ERROR			res;

	bFindMedia 				= FALSE;
	nDevInfo->IoStatus		= 0; 
	nDevInfo->ChipNo		= 0xFF;
	gInterLeaveCSNum 		= 0;
	gInterLeaveIoStatus		= 0;
	gInterLeaveWriteStatus	= MULTI_PLANE_GOOD_BLOCK;

	// Init Variable
	sTempFeatureInfo	= (NAND_IO_FEATURE*)NAND_SupportMakerInfo.DevInfo[0];
	sFindFeatureInfo	= (NAND_IO_FEATURE*)NAND_SupportMakerInfo.DevInfo[0];

	//=====================================================================
	// Search Matched NANDFLASH (x8 Bit Serial NAND)
	//=====================================================================
	for ( j = 0; j < 3; ++j )	/* Check Read ID during 3 turn */
	{
		//IO_CKC_EnableBUS( IO_CKC_BUS_NFC );
		// 16Bit NAND Mask Disable
		BITCLR( pNFC->NFC_CTRL, HwNFC_CTRL_MASK_EN );

		/* Read Device CODE */
		NAND_IO_ResetForReadID( nChipNo, NAND_IO_SERIAL_COMBINATION_MODE );			// x8 Bit NAND Search
		NAND_IO_ReadID( nChipNo, &sDeviceCode1, NAND_IO_SERIAL_COMBINATION_MODE );	// x8 Bit NAND Search

		/* Check Maker ID */
		bFindMakerNo = 0xFF;
		for ( k = 0; k < MAX_SUPPORT_MAKER_NAND; ++k )
		{
			if ( sDeviceCode1.Code[0] == NAND_SupportMakerInfo.MakerID[k] )
			{
				bFindMakerNo		= (unsigned char)k;
				sTempFeatureInfo	= (NAND_IO_FEATURE*)NAND_SupportMakerInfo.DevInfo[k];
				break;
			}	
		}
			
		if ( bFindMakerNo >= MAX_SUPPORT_MAKER_NAND )
			continue;

		/* Check Device ID */
		for ( k = 0; k < NAND_SupportMakerInfo.MaxSupportNAND[bFindMakerNo]; ++k )
		{
			bMatchCount = 0;
			
			for ( l = 0; l < 5; ++l )
			{
				if ( sTempFeatureInfo->DeviceID.Code[l+1] == 0x00 )
					++bMatchCount;
				else if ( sDeviceCode1.Code[l+1] == sTempFeatureInfo->DeviceID.Code[l+1] )
					++bMatchCount;
			}

			/* Found NAND Device */
			if ( bMatchCount >= 5 )
			{
				bFindMedia = TRUE;
				sFindFeatureInfo = sTempFeatureInfo;
				break;
			}
			else
				++sTempFeatureInfo;
		}

		/* Found NAND Device */
		if ( bFindMedia == TRUE )
			break;
	}

	if ( bFindMedia != TRUE )
	{
		//=====================================================================
		// Search Matched NANDFLASH (x16 Bit Serial NAND)
		//=====================================================================
		for ( j = 0; j < 3; ++j )	/* Check Read ID during 3 turn */
		{
			//IO_CKC_EnableBUS( IO_CKC_BUS_NFC );
			// 16Bit NAND Mask Enable
			BITSET( pNFC->NFC_CTRL, HwNFC_CTRL_MASK_EN );

			/* Read Device CODE */
			NAND_IO_ResetForReadID( nChipNo, NAND_IO_PARALLEL_COMBINATION_MODE );			// x16 Bit NAND Command
			NAND_IO_ReadID( nChipNo, &sDeviceCode1, NAND_IO_PARALLEL_COMBINATION_MODE );	// x16 Bit NAND Search

			/* Check Maker ID */
			bFindMakerNo = 0xFF;
			for ( k = 0; k < MAX_SUPPORT_MAKER_NAND; ++k )
			{
				if ( sDeviceCode1.Code[0] == NAND_SupportMakerInfo.MakerID[k] )
				{
					bFindMakerNo		= (unsigned char)k;
					sTempFeatureInfo	= (NAND_IO_FEATURE*)NAND_SupportMakerInfo.DevInfo[k];
					break;
				}	
			}
				
			if ( bFindMakerNo >= MAX_SUPPORT_MAKER_NAND )
			{
				BITCLR( pNFC->NFC_CTRL, HwNFC_CTRL_MASK_EN );
				continue;
			}
			/* Check Device ID */
			for ( k = 0; k < NAND_SupportMakerInfo.MaxSupportNAND[bFindMakerNo]; ++k )
			{
				bMatchCount = 0;
				
				for ( l = 0; l < 5; ++l )
				{
					if ( sTempFeatureInfo->DeviceID.Code[l+1] == 0x00 )
						++bMatchCount;
					else if ( sDeviceCode1.Code[l+1] == sTempFeatureInfo->DeviceID.Code[l+1] )
						++bMatchCount;
				}

				/* Found NAND Device */
				if ( bMatchCount >= 5 )
				{
					bFindMedia = TRUE;
					sFindFeatureInfo = sTempFeatureInfo;
					break;
				}
				else
					++sTempFeatureInfo;
			}

			/* Found NAND Device */
			if ( bFindMedia == TRUE )
				break;
			else
				BITCLR( pNFC->NFC_CTRL, HwNFC_CTRL_MASK_EN );
		}
	}

	//=====================================================================
	// If Media is founded
	//=====================================================================
	if ( bFindMedia == TRUE )
	{
		/* Get NAND Feature Info */
		memcpy( (void*)&nDevInfo->Feature,
			 	(void*)sFindFeatureInfo,
				sizeof(NAND_IO_FEATURE) );

		/* Get ECC Type Info */
		if ( nDevInfo->Feature.MediaType & A_SLC )
		{
			//nDevInfo->EccType = TYPE_ECC_FOR_1BIT_SLC_NANDFLASH;
			nDevInfo->EccType = TYPE_ECC_FOR_4BIT_MLC_NANDFLASH;
			nDevInfo->EccDataSize = 8;
		}
		else if ( nDevInfo->Feature.MediaType & A_MLC )
		{
			nDevInfo->EccType = TYPE_ECC_FOR_4BIT_MLC_NANDFLASH;
			nDevInfo->EccDataSize = 8;
		}
		else if ( nDevInfo->Feature.MediaType & A_MLC_8BIT )
		{
			nDevInfo->EccType = TYPE_ECC_FOR_8BIT_MLC_NANDFLASH;
			nDevInfo->EccDataSize = 20;
			nDevInfo->Feature.SpareSize = 192;
		}
		else if ( nDevInfo->Feature.MediaType & A_MLC_12BIT )
		{
			nDevInfo->EccType = TYPE_ECC_FOR_12BIT_MLC_NANDFLASH;
			nDevInfo->EccDataSize = 20;
			nDevInfo->Feature.SpareSize = 192;
		}
		else if ( nDevInfo->Feature.MediaType & A_MLC_16BIT )
		{
			nDevInfo->EccType = TYPE_ECC_FOR_16BIT_MLC_NANDFLASH;
			nDevInfo->EccDataSize = 26;
			nDevInfo->Feature.SpareSize = 436;
		}
			
		if ( nDevInfo->Feature.PageSize == 4096 )
			nDevInfo->DistrictNum = 1024;
		else
			nDevInfo->DistrictNum = 2048;
		
		//=====================================================================
		//EXCEPTION: TH58NVG4D1D/5D1DTG20 TH58NVG6D1DTG20
		//=====================================================================
		if ( ( nDevInfo->Feature.DeviceID.Code[0]== 0x98 ) &&  ( nDevInfo->Feature.DeviceID.Code[1] == 0xD5 ) && ( nDevInfo->Feature.DeviceID.Code[2] == 0x94 ))
			nDevInfo->DistrictNum = 2048;

		if ( ( nDevInfo->Feature.DeviceID.Code[0]== 0x98 ) &&  ( nDevInfo->Feature.DeviceID.Code[1] == 0xD7 ) )
			nDevInfo->DistrictNum = 2048;

		if ( nDevInfo->Feature.MediaType & A_08BIT )
		{
		    #ifndef NAND_8BIT_ONLY
		    /* Check if compositin of NAND is parallel or serial */
		    NAND_IO_ResetForReadID( nChipNo, NAND_IO_PARALLEL_COMBINATION_MODE );
		    NAND_IO_ReadID( nChipNo, &sDeviceCode2, NAND_IO_PARALLEL_COMBINATION_MODE );
    
		    if ( ((sDeviceCode2.Code[0] & 0xFF) == ((sDeviceCode2.Code[0] >> 8) & 0xFF)) &&
			     ((sDeviceCode2.Code[1] & 0xFF) == ((sDeviceCode2.Code[1] >> 8) & 0xFF)) &&
			     ((sDeviceCode2.Code[2] & 0xFF) == ((sDeviceCode2.Code[2] >> 8) & 0xFF)) &&
			     ((sDeviceCode2.Code[3] & 0xFF) == ((sDeviceCode2.Code[3] >> 8) & 0xFF)) &&
			     ((sDeviceCode2.Code[4] & 0xFF) == ((sDeviceCode2.Code[4] >> 8) & 0xFF)) )
		    {
			    nDevInfo->Feature.MediaType |= A_PARALLEL;
				nDevInfo->Feature.MediaType |= A_DATA_WITDH_16BIT;
			    nDevInfo->Feature.PageSize 	*= 2;
			    nDevInfo->Feature.SpareSize *= 2;			    
			    nDevInfo->CmdMask 	= 0xFFFF;
		    }
		    else
		    {
				nDevInfo->Feature.MediaType |= A_DATA_WITDH_08BIT;				
			    nDevInfo->CmdMask 	= 0x00FF;
		    }
    
		    #else
				nDevInfo->Feature.MediaType |= A_DATA_WITDH_08BIT;				
			    nDevInfo->CmdMask 	= 0x00FF;
		    #endif
		}
		else
		{
			//IO_CKC_EnableBUS( IO_CKC_BUS_NFC );
			// 16Bit NAND Mask Enable
			BITSET( pNFC->NFC_CTRL, HwNFC_CTRL_MASK_EN );
			nDevInfo->Feature.MediaType |= A_DATA_WITDH_16BIT;
			nDevInfo->CmdMask = 0x00FF;
		}
		
		/* Get Total Partial Page [512+16Bytes] */
		nDevInfo->PPages = ( nDevInfo->Feature.PageSize / 512 );
		
		/* Get Shift Factors of PBpV, PpB, PageSize, SpareSize, PPages */
		res = (NAND_IO_ERROR)SUCCESS;
		res |= NAND_IO_GetShiftValueForFastMultiPly( nDevInfo->Feature.PBpV, &nDevInfo->ShiftPBpV );
		res |= NAND_IO_GetShiftValueForFastMultiPly( nDevInfo->Feature.PpB, &nDevInfo->ShiftPpB );
		res |= NAND_IO_GetShiftValueForFastMultiPly( nDevInfo->Feature.PageSize, &nDevInfo->ShiftPageSize );
		res |= NAND_IO_GetShiftValueForFastMultiPly( nDevInfo->PPages, &nDevInfo->ShiftPPages );
		res |= NAND_IO_GetShiftValueForFastMultiPly( nDevInfo->DistrictNum, &nDevInfo->ShiftDistrictNum );

		nDevInfo->EccWholeDataSize =  ( nDevInfo->EccDataSize << nDevInfo->ShiftPPages );

		if ( res != SUCCESS )
			return res;
		
		for ( j = 0; j < 4; ++j )
		{
			nDevInfo->BadBlockInfo.BlockStatus[j] 	= MULTI_PLANE_GOOD_BLOCK;
			nDevInfo->BadBlockInfo.BadBlkPHYAddr[j] = 0xFFFFFFFF;
		}

		NAND_IO_SetCycle( nDevInfo );
	}
	//=====================================================================
	// Not Found
	//=====================================================================
	else
	{
		#if defined(USE_V_ADDRESS) && defined(_WINCE_)
		#else
		if ( nChipNo == 0 )
		{
			ND_TRACE("\n[NAND        ] No NAND device found!!! ID:");
			for ( j = 0; j < 4; ++j )
				ND_TRACE("0x%x ", ( sDeviceCode1.Code[j] & 0xFF ) );
		}
		#endif

		return ERR_NAND_IO_FAILED_GET_DEVICE_INFO;
	}

	nDevInfo->IoStatus	= NAND_IO_STATUS_ENABLE;
	nDevInfo->ChipNo	= nChipNo;

	//=====================================================================
	// gDevInfo( Global Variable ) Initialize 
	//=====================================================================
	if ( nDevInfo->ChipNo == 0 )
		gDevInfo = (NAND_IO_DEVINFO *)nDevInfo;
	
	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	U32		NAND_IO_GetBUSTypeOfDataIO( void )
*
*	Input	: NONE
*	Output	: NONE
*	Return	: NONE
*
*	Description : Initialize NAND IO Layer
*
*******************************************************************************/
U32 NAND_IO_GetBUSTypeOfDataIO( void )
{
	return gNAND_IO_DataBusType;
}

void NAND_IO_ECC_InfoInit( void )
{
	gMLC_ECC_1Bit.EccDataSize 			= 7;
	//gMLC_ECC_1Bit.EncodeFlag			= HwECC_IREQ_M1EF;
	//gMLC_ECC_1Bit.DecodeFlag			= HwECC_IREQ_M1DF;
	gMLC_ECC_1Bit.ErrorNum				= 1;
	gMLC_ECC_1Bit.All_FF_512_ECC_Code	= (U8 *)&ALL_FF_ECC_BCH_01BIT_512;
		
	gMLC_ECC_4Bit.EccDataSize 			= 7;
	gMLC_ECC_4Bit.EncodeFlag			= HwECC_IREQ_M4EF;
	gMLC_ECC_4Bit.DecodeFlag			= HwECC_IREQ_M4DF;
	gMLC_ECC_4Bit.ErrorNum				= 4;
	gMLC_ECC_4Bit.All_FF_512_ECC_Code	= (U8 *)&ALL_FF_ECC_BCH_04BIT_512;
		
	gMLC_ECC_8Bit.EccDataSize 			= 13;
	gMLC_ECC_8Bit.EncodeFlag			= HwECC_IREQ_M8EF;
	gMLC_ECC_8Bit.DecodeFlag			= HwECC_IREQ_M8DF;
	gMLC_ECC_8Bit.ErrorNum				= 8;
	gMLC_ECC_8Bit.All_FF_512_ECC_Code	= (U8 *)&ALL_FF_ECC_BCH_08BIT_512;

	gMLC_ECC_12Bit.EccDataSize 		= 20;
	gMLC_ECC_12Bit.EncodeFlag			= HwECC_IREQ_M12EF;
	gMLC_ECC_12Bit.DecodeFlag			= HwECC_IREQ_M12DF;
	gMLC_ECC_12Bit.ErrorNum 			= 12;
	gMLC_ECC_12Bit.All_FF_512_ECC_Code	= (U8 *)&ALL_FF_ECC_BCH_12BIT_512;

	gMLC_ECC_14Bit.EccDataSize 		= 23;
	gMLC_ECC_14Bit.EncodeFlag			= HwECC_IREQ_M14EF;
	gMLC_ECC_14Bit.DecodeFlag			= HwECC_IREQ_M14DF;
	gMLC_ECC_14Bit.ErrorNum 			= 14;
	gMLC_ECC_14Bit.All_FF_512_ECC_Code	= (U8 *)&ALL_FF_ECC_BCH_14BIT_512;

	gMLC_ECC_16Bit.EccDataSize 		= 26;
	gMLC_ECC_16Bit.EncodeFlag			= HwECC_IREQ_M16EF;
	gMLC_ECC_16Bit.DecodeFlag			= HwECC_IREQ_M16DF;
	gMLC_ECC_16Bit.ErrorNum 			= 16;
	gMLC_ECC_16Bit.All_FF_512_ECC_Code	= (U8 *)&ALL_FF_ECC_BCH_16BIT_512;

	memset( gNAND_IO_TempBuffer, 0xFF, 32 );
}

void NAND_IO_InitDMABuffer( void )
{
	#if defined(_WINCE_)
	tSYSTEM_PARAM	*pSYS_Work_PARAM	= (tSYSTEM_PARAM*)(SYSTEM_PARAM_BASEADDRESS);
	#endif
	
	#if defined(_WINCE_)
	gpDMA_PhyBuffer0 	= (unsigned int*)pSYS_Work_PARAM->DMA2.CH0_BUFFER;	// Working Address
	gpDMA_WorkBuffer0 	= (unsigned int*)pSYS_PARAM->DMA2.CH0_BUFFER;		// Physical Address
	gpDMA_PhyBuffer1 	= (unsigned int*)pSYS_Work_PARAM->DMA2.CH1_BUFFER;	// Working Address
	gpDMA_WorkBuffer1 	= (unsigned int*)pSYS_PARAM->DMA2.CH1_BUFFER;		// Physical Address	
	#elif defined(_LINUX_)
	#ifdef KERNEL_DRIVER
	gpDMA_PhyBuffer0 	= (unsigned int*)dma_t.dma_addr;
	gpDMA_WorkBuffer0	= (unsigned int*)dma_t.v_addr;
	gpDMA_PhyBuffer1 	= (unsigned int*)((unsigned char*)gpDMA_PhyBuffer0 + 512);
	gpDMA_WorkBuffer1	= (unsigned int*)((unsigned char*)gpDMA_WorkBuffer0 + 512);
	gNAND_IO_ShareEccBuffer_w	= (unsigned char*)gpDMA_PhyBuffer1 + 512;
	gNAND_IO_ShareEccBuffer		= (unsigned char*)gpDMA_WorkBuffer1 + 512;
	#else
	gpDMA_PhyBuffer0 	= (unsigned int*)DMA_ADDR;
	gpDMA_WorkBuffer0	= (unsigned int*)DMA_ADDR;
	gpDMA_PhyBuffer1 	= (unsigned int*)DMA_ADDR + 512;
	gpDMA_WorkBuffer1	= (unsigned int*)DMA_ADDR + 512;	
	#endif
	#else		// NU
	gpDMA_PhyBuffer0 	= (unsigned int*)gpNandBuffer;
	gpDMA_WorkBuffer0	= (unsigned int*)gpNandBuffer;
	gpDMA_PhyBuffer1 	= (unsigned char*)gpDMA_PhyBuffer0 + 512;
	gpDMA_WorkBuffer1	= (unsigned char*)gpDMA_WorkBuffer0 + 512;
	#endif

//	ND_TRACE("\nDMA_PhyBufferAddr0:0x%X", gpDMA_PhyBuffer0);
//	ND_TRACE("\nDMA_WorkBufferAddr0:0x%X", gpDMA_WorkBuffer0);
//	ND_TRACE("\nDMA_PhyBufferAddr1:0x%X", gpDMA_PhyBuffer1);
//	ND_TRACE("\nDMA_WorkBufferAdd1r:0x%X", gpDMA_WorkBuffer1);
}

/******************************************************************************
*
*	void    NAND_IO_Init( void )
*
*	Input	: NONE
*	Output	: NONE
*	Return	: NONE
*
*	Description : Initialize NAND IO Layer
*
*******************************************************************************/
void NAND_IO_Init( void )
{
	unsigned int		i;
	PEDI				pEDI;
	NAND_IO_DEVINFO		sDevInfo;
	NAND_IO_ERROR		res;
	
	memset( &sDevInfo, 0x00, sizeof(NAND_IO_DEVINFO));

#if defined(USE_V_ADDRESS)
	#if defined(_LINUX_)
	pGPIO 		= (PGPIO)(&HwGPIO_BASE);
	pEDI 		= (PEDI)(&HwEDI_BASE);
	pNFC 		= (PNFC)(&HwNFC_BASE);
	pECC 		= (PECC)(&HwECC_BASE);
	pIOBUSCFG_T = (PIOBUSCFG)(&HwIOBUSCFG_BASE);
	pNAND_DMA	= (PGDMANCTRL)(&HwGDMA2_BASE);
	#if defined(_WINCE_)
	pSYS_PARAM	= (ptSYSTEM_PARAM)(&SYSTEM_PARAM_BASEADDRESS);
	#endif
	pPIC		= (PPIC)(&HwPIC_BASE);
	#elif defined(_WINCE_)
	pGPIO 		= (PGPIO)tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	pEDI 		= (PEDI)tcc_allocbaseaddress((unsigned int)&HwEDI_BASE);
	pNFC 		= (PNFC)tcc_allocbaseaddress((unsigned int)&HwNFC_BASE);
	pECC 		= (PECC)tcc_allocbaseaddress((unsigned int)&HwECC_BASE);
	pIOBUSCFG_T = (PIOBUSCFG)tcc_allocbaseaddress((unsigned int)&HwIOBUSCFG_BASE);
	pPIC		= (PPIC)tcc_allocbaseaddress((unsigned int)&HwPIC_BASE);
	pSYS_PARAM	= (tSYSTEM_PARAM*)tcc_allocbaseaddress((unsigned int)SYSTEM_PARAM_BASEADDRESS);
	pNAND_DMA	= (PGDMANCTRL)tcc_allocbaseaddress((unsigned int)&HwGDMA2_BASE);
	#endif
#else
	pGPIO 		= (PGPIO)(&HwGPIO_BASE);
	pEDI 		= (PEDI)(&HwEDI_BASE);
	pNFC 		= (PNFC)(&HwNFC_BASE);
	pECC 		= (PECC)(&HwECC_BASE);
	pIOBUSCFG_T = (PIOBUSCFG)(&HwIOBUSCFG_BASE);
	pPIC		= (PPIC)(&HwPIC_BASE);
	#if defined(_WINCE_)
	pSYS_PARAM	= (tSYSTEM_PARAM*)(SYSTEM_PARAM_BASEADDRESS);
	#endif
	pNAND_DMA	= (PGDMANCTRL)(&HwGDMA2_BASE);
#endif

	/*************************************/
	/*Don't remove NAND_IO_Delay Function*/
	/*************************************/
	for( i = 0; i < 5000; ++i )
		NAND_IO_Delay();

	for ( i = 0; i < 2; ++i )
	{
		/***********************************/
		/* Setting NANDFLASH on Memory Bus */
		/***********************************/		
		if ( i == 0 )
		{
			ASM_NOP;
		}
		/********************************/
		/* Setting NANDFLASH on NFC Bus */
		/********************************/		
		else
		{
			pEDI->EDI_RDYCFG 	= 0x00000001;
			//pEDI->EDI_CSNCFG0	= 0x00403265;
			BITCSET(pEDI->EDI_CSNCFG0, 0xFFFF, 0x8765 );
			
			// NAND GPIO_B Port (sND_xx : shared port)
			// pGPIO->GPBFN0 = { ND_D[07], ND_D[06], ND_D[05], ND_D[04], ND_D[11], ND_D[10], ND_D[09], ND_D[08] }
			// pGPIO->GPBFN1 = { ND_D[15], ND_D[14], ND_D[13], ND_D[12], ND_D[03], ND_D[02], ND_D[01], ND_D[00] }
			// pGPIO->GPBFN2 = { ND_CS#0,  sND_WP,   ND_ALE,   ND_CLE, 	 ND_OE,    XXXXXXXX, ND_WE,    XXXXXXXX	}
			// pGPIO->GPBFN3 = { ND_WP,    XXXXXXXX, XXXXXXXX, ND_RDY, 	 XXXXXXX,  sND_CS#3, sND_CS#2, ND_CS#1  }

			// NAND Data Port setup
			#ifdef NAND_8BIT_ONLY
			BITCSET(pGPIO->GPBFN0, 0xFFFF0000, 0x11110000);
			BITCSET(pGPIO->GPBFN1, 0x0000FFFF, 0x00001111);
			#else
			BITCSET(pGPIO->GPBFN0, 0xFFFFFFFF, 0x11111111);
			BITCSET(pGPIO->GPBFN1, 0xFFFFFFFF, 0x11111111);
			#endif

			BITCSET(pGPIO->GPBFN2, 0xF0FFF0F0, 0x10111010);

			#ifdef NAND_2CS_ONLY
			BITCSET(pGPIO->GPBFN3, 0xF00F000F, 0x10010001);
			
			// For 4CS --> 2CS Test
			//BITCSET(pGPIO->GPBFN3, 0x00000FF0, 0x00000000);
			//BITSET(pGPIO->GPBEN, Hw26);
			//BITSET(pGPIO->GPBEN, Hw25);
			//BITSET(pGPIO->GPBDAT, Hw26);
			//BITSET(pGPIO->GPBDAT, Hw25);

			#else
			BITCSET(pGPIO->GPBFN3, 0xF00F0FFF, 0x10010111);
			#endif

			//=================================================
			// NAND Write protect Pin Set
			//=================================================
			#if defined(TCC_NAND_WP_B31)
			pGPIO->GPBFN3 &= ~0x10000000;		// ND_WP: GPIO_B31
			#elif defined(TCC_NAND_WP_B22)
			pGPIO->GPBFN2 &= ~0x01000000;		// ND_WP: GPIO_B22
			#else
			#Error: NAND Write Protect Pin Set
			#endif
			// Write Protect Pin: Output Mode
			BITSET( pGPIO->GPBEN, NAND_IO_NFC_nWPBit );

			//=================================================
			// TCC9200S_BOARD NAND Ready/Busy Pin Set
			/* ND_RDY: GPIO_B31 */
			//=================================================
			#if defined(TCC_NAND_RDY_B31)
			pGPIO->GPBFN3 &= ~0x10000000;		// ND_RDY: GPIO_B31			
			BITCLR(pGPIO->GPBEN, Hw31);
			#endif
	    
			#ifdef __USE_NAND_ISR__
			NAND_IO_IRQ_ReadyBusyClear();
			#endif
			
		    gNAND_IO_DataBusType	= NAND_IO_NFC_BUS;

		    /* Make Reset */
		    pNFC->NFC_RST = 0;

		    /* Set Default NFC Configuration */
			#ifdef __USE_NAND_ISR__
		    pNFC->NFC_CTRL	= HwNFC_CTRL_PROGIEN_EN |
                              HwNFC_CTRL_READIEN_EN |
                              HwNFC_CTRL_DEN_EN		|
					          HwNFC_CTRL_CFG_NOACT	|
					          HwNFC_CTRL_BSIZE_1	|
						      (4 << 4)				|		// pw = 5
					          (1 << 0);						// hold = 1

			#else
		    pNFC->NFC_CTRL	= HwNFC_CTRL_DEN_EN		|
					          HwNFC_CTRL_CFG_NOACT	|
					          HwNFC_CTRL_BSIZE_1	|
						      (4 << 4)				|		// pw = 5
					          (1 << 0);						// hold = 1
			#endif

			/* GPIO B Arbitration ENABLE */
			pNFC->NFC_CTRL1 |= Hw31;
			pNFC->NFC_CTRL1 |= Hw30;

		    /* Enable Interrupt */
			pNFC->NFC_IREQ = 0x77;				// Clear Interrupt
			BITSET( pPIC->CLR1,HwINT1_NFC );
		    BITSET( pPIC->SEL1, HwINT1_NFC);				// Set NFC as IRQ interrupt
		    BITSET( pPIC->MODE1, HwINT1_NFC );	// Level type for NFC interrupt, IO_INT_HwNFC );	// Level type for NFC interrupt

		    //IO_CKC_DisableBUS( IO_CKC_BUS_NFC );

		    /* Searching NANDFLASH */
		    res = NAND_IO_GetDeviceInfo( 0, &sDevInfo );

			#ifdef NAND_GPIO_DEBUG
			BITCSET(pGPIO->GPFFN2, 0x0FF000FF, 0x00000000);
			BITSET(pGPIO->GPFEN, Hw16);
			BITSET(pGPIO->GPFEN, Hw17);
			BITSET(pGPIO->GPFEN, Hw21);
			BITSET(pGPIO->GPFEN, Hw22);

			// Clear
			BITCLR(pGPIO->GPFDAT, Hw16);
			BITCLR(pGPIO->GPFDAT, Hw17);
			BITCLR(pGPIO->GPFDAT, Hw21);
			BITCLR(pGPIO->GPFDAT, Hw22);
			#endif

		    if ( res == SUCCESS )
	    		break;	
		}
	}

	/* Setup Variable about ECC */
	//IO_CKC_EnableBUS( IO_CKC_BUS_ECC );
	pECC->ECC_CTRL	= 0x04000000;		/* ECC Control Register */
	pECC->ECC_BASE	= pNFC->NFC_WDATA;	/* Base Address for ECC Calculation */
	pECC->ECC_MASK	= 0x00000000;		/* Address mask for ECC area */
	//IO_CKC_DisableBUS( IO_CKC_BUS_ECC );	
	
	memcpy( &rDevInfo, &sDevInfo, sizeof(NAND_IO_DEVINFO) );

	NAND_IO_ECC_InfoInit();

	#ifdef NAND_IO_USE_DMA_ACCESS
	NAND_IO_InitDMABuffer();
	#endif
}

/******************************************************************************
*
*	void    NAND_IO_Reset
*
*	Input	: Chip Select Number
*	Output	: NONE
*	Return	: NONE
*
*	Description : Reset NANDFLASH
*
*******************************************************************************/
void NAND_IO_Reset( U16 nChipNo, int nMode )
{
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nChipNo );

	/* Set Data Bus as 16Bit */
	NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	
	/* Command RESET [ 0xFF ] */
	if ( nMode == NAND_IO_PARALLEL_COMBINATION_MODE )
		pNFC->NFC_CMD = 0xFFFF;
	else
		pNFC->NFC_CMD = 0x00FF;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nChipNo );

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
}

/******************************************************************************
*
*	void    NAND_IO_ResetForReadID
*
*	Input	: Chip Select Number
*	Output	: NONE
*	Return	: NONE
*
*	Description : Reset NANDFLASH
*
*******************************************************************************/
void NAND_IO_ResetForReadID( U16 nChipNo, int nMode )
{
	unsigned int	i,j;
	
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nChipNo );

	/* Set Data Bus as 16Bit */
	NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );

	/* Command RESET [ 0xFF ] */
	if ( nMode == NAND_IO_PARALLEL_COMBINATION_MODE )
		pNFC->NFC_CMD = 0xFFFF;
	else
		pNFC->NFC_CMD = 0x00FF;

	/* Wait until it is ready */
	for ( i = 0; i < 0x100; ++i )
	{
		for ( j = 0; j < 0x80; ++j )
		{
			ASM_NOP;
		}
	}

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
}

/******************************************************************************
*
*	void    NAND_IO_ReadID
*
*	Input	: Chip Select Number
*			  Mode : 0 => Serial Composition , 1 => Parallel Composition
*	Output	: NANDFLASH Device Code
*	Return	: NONE
*
*	Description : Get Device Code of NANDFLASH
*
*******************************************************************************/
void NAND_IO_ReadID( U16 nChipNo, NAND_IO_DEVID *nDeviceCode, int nMode )
{
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nChipNo );

	/* Set Data Bus as 16Bit */
	NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	
	/* Parallel Composition */
	if ( nMode == NAND_IO_PARALLEL_COMBINATION_MODE )
	{
		pNFC->NFC_CMD	= 0x9090;	/* Command READ ID [ 0x90 ] */
		pNFC->NFC_SADDR	= 0x0000;	/* Address [ 0x00 ] */
	}
	/* Serial Composition */
	else
	{
		pNFC->NFC_CMD	= 0x0090;	/* Command READ ID [ 0x90 ] */
		pNFC->NFC_SADDR	= 0x0000;	/* Address [ 0x00 ] */
	}
	
	/* Delay : tAR1[READID] Max 200nS */
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;

	/* Parallel Composition */
	if ( nMode == NAND_IO_PARALLEL_COMBINATION_MODE )
	{
		nDeviceCode->Code[0] = (U16)pNFC->NFC_SDATA;
		nDeviceCode->Code[1] = (U16)pNFC->NFC_SDATA;
		nDeviceCode->Code[2] = (U16)pNFC->NFC_SDATA;
		nDeviceCode->Code[3] = (U16)pNFC->NFC_SDATA;
		nDeviceCode->Code[4] = (U16)pNFC->NFC_SDATA;
		nDeviceCode->Code[5] = (U16)pNFC->NFC_SDATA;
	}	
	/* Serial Composition */
	else
	{
		nDeviceCode->Code[0] = (U8)( pNFC->NFC_SDATA & 0xFF );
		nDeviceCode->Code[1] = (U8)( pNFC->NFC_SDATA & 0xFF );
		nDeviceCode->Code[2] = (U8)( pNFC->NFC_SDATA & 0xFF );
		nDeviceCode->Code[3] = (U8)( pNFC->NFC_SDATA & 0xFF );
		nDeviceCode->Code[4] = (U8)( pNFC->NFC_SDATA & 0xFF );
		nDeviceCode->Code[5] = (U8)( pNFC->NFC_SDATA & 0xFF );
	}	

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_ReadSpare
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_ReadSpare( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U8 *nSpareBuffer )
{
	unsigned int		RowAddr, ColumnAddr;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	//=============================================
	// PreProcess
	// Set Setup and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_EnableWriteProtect();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Data
	//=============================================	
	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, nDevInfo->Feature.PageSize, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorReadSpare;

	/* Write Row and Column Address	*/
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Command READ2 [ 0x30 ] for Advance NandFlash */
	if ( nDevInfo->Feature.MediaType & A_BIG )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;
	
	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Read Spare data from NANDFLASH */
	res = NAND_IO_ReadSpareData( nDevInfo, 
								 nSpareBuffer, 
								 PAGE_ECC_OFF );
	if ( res != SUCCESS )
		goto ErrorReadSpare;
							
ErrorReadSpare:
	//=============================================
	// Disable Chip Select
	// PostProcess
	//=============================================	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_ReadPage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_ReadPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
								U16 nStartPPage, U16 nReadPPSize,
								U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;
	unsigned int		nSpareOnOff;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ) )
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	if ( ( nStartPPage + nReadPPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;
	
	//=============================================
	// PreProcess
	// Set Setup and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();
	
	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );

	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_EnableWriteProtect();

	//=============================================
	// Read Data
	//=============================================	
	/* Generate Row and Column Address */
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, nDevInfo->Feature.PageSize, &RowAddr, &ColumnAddr, nDevInfo );
	else
		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorReadPage;

	/* Write Row and Column Address	*/
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Command READ2 [ 0x30 ] for Advance NandFlash */
	if ( nDevInfo->Feature.MediaType & A_BIG )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Change Cycle */
	NAND_IO_SetReadCycleTime();

	/* Read Page Size data from NANDFLASH */
	nSpareOnOff = TNFTL_READ_SPARE_ON;

	if ( nDevInfo->Feature.MediaType & A_BIG )
	{
		res = NAND_IO_ReadSpareData( nDevInfo, nSpareBuffer, PAGE_ECC_ON );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Change Cycle */
		NAND_IO_SetCommCycleTime();
		
		/* Command Random Data Output [ 0x05 ] for Advance NandFlash */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0505;
		
		ColumnAddr = ( nStartPPage << 9 );
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (ColumnAddr >> 1) : ColumnAddr;

		NAND_IO_WriteColAddr( ColumnAddr, nDevInfo );

		/* Command Random Data Output [ 0xE0 ] for Advance NandFlash */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0xE0E0;

		/* Change Cycle */
		NAND_IO_SetReadCycleTime();
	}
	else if (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL ))
	{
		res = NAND_IO_ReadSpareData( nDevInfo, nSpareBuffer, PAGE_ECC_ON );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Change Cycle */
		NAND_IO_SetCommCycleTime();

		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Write Row and Column Address	*/
		NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

		/* Wait until it is ready */
		NAND_IO_WaitBusy( nDevInfo->ChipNo );

		/* Change Cycle */
		NAND_IO_SetReadCycleTime();
	}

	#if defined(NAND_IO_USE_DMA_DOUBLE_BUF)
	res = NAND_IO_Read512DataDoubleBuf( nDevInfo,
									    nStartPPage,
									    nReadPPSize,
									    nPageBuffer,
									    nSpareBuffer,
									    nEccOnOff,
									    TNFTL_READ_SPARE_ON );
	#else	
	res = NAND_IO_Read512Data( nDevInfo,
							   nStartPPage,
							   nReadPPSize,
							   nPageBuffer,
							   nSpareBuffer,
							   nEccOnOff,
							   TNFTL_READ_SPARE_ON );		
	#endif
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();
							
ErrorReadPage:
	//=============================================
	// Disable Chip Select
	// PostProcess
	//=============================================	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();

	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_ReadPhyPage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_ReadPhyPage(	NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
									U16 nStartPPage, U16 nReadPPSize,
									U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;
	unsigned int		nSpareOnOff;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ) )
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	if ( ( nStartPPage + nReadPPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;
	
	//=============================================
	// PreProcess
	// Set Setup and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();
	
	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_EnableWriteProtect();

	//=============================================
	// Read Data
	//=============================================	
	/* Generate Row and Column Address */
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, nDevInfo->Feature.PageSize, &RowAddr, &ColumnAddr, nDevInfo );
	else
		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorReadPage;

	/* Write Row and Column Address	*/
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Command READ2 [ 0x30 ] for Advance NandFlash */
	if ( nDevInfo->Feature.MediaType & A_BIG )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Change Cycle */
	NAND_IO_SetReadCycleTime();

	/* Read Page Size data from NANDFLASH */
	nSpareOnOff = TNFTL_READ_SPARE_ON;

	if ( nDevInfo->Feature.MediaType & A_BIG )
	{
		//res = NAND_IO_ReadSpareData( nDevInfo, nSpareBuffer, PAGE_ECC_ON );
		res = NAND_IO_ReadUserSizeData( nDevInfo, ( nDevInfo->PPages << 9 ), nDevInfo->Feature.SpareSize, nSpareBuffer );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Change Cycle */
		NAND_IO_SetCommCycleTime();
		
		/* Command Random Data Output [ 0x05 ] for Advance NandFlash */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0505;
		
		ColumnAddr = ( nStartPPage << 9 );
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (ColumnAddr >> 1) : ColumnAddr;

		NAND_IO_WriteColAddr( ColumnAddr, nDevInfo );

		/* Command Random Data Output [ 0xE0 ] for Advance NandFlash */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0xE0E0;

		/* Change Cycle */
		NAND_IO_SetReadCycleTime();
	}
	else if (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL ))
	{
		res = NAND_IO_ReadUserSizeData( nDevInfo, ( nDevInfo->PPages << 9 ), nDevInfo->Feature.SpareSize, nSpareBuffer );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Change Cycle */
		NAND_IO_SetCommCycleTime();

		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Write Row and Column Address	*/
		NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

		/* Wait until it is ready */
		NAND_IO_WaitBusy( nDevInfo->ChipNo );

		/* Change Cycle */
		NAND_IO_SetReadCycleTime();
	}
	
	#if defined(NAND_IO_USE_DMA_DOUBLE_BUF)
	res = NAND_IO_Read512DataDoubleBuf( nDevInfo,
									    nStartPPage,
									    nReadPPSize,
									    nPageBuffer,
									    nSpareBuffer,
									    nEccOnOff,
									    TNFTL_READ_SPARE_ON );
	#else	
	res = NAND_IO_Read512Data( nDevInfo,
							   nStartPPage,
							   nReadPPSize,
							   nPageBuffer,
							   nSpareBuffer,
							   nEccOnOff,
							   TNFTL_READ_SPARE_ON );		
	#endif
	
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();
							
ErrorReadPage:
	//=============================================
	// Disable Chip Select
	// PostProcess
	//=============================================	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_ReadPageMTD
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_ReadPageMTD( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
								   U16 nStartPPage, U16 nReadPPSize,
								   U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;
	unsigned int		nSpareOnOff;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ) )
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	if ( ( nStartPPage + nReadPPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;
	
	//=============================================
	// PreProcess
	// Set Setup and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();
	
	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_EnableWriteProtect();

	//=============================================	
	// Read Data
	//=============================================
	/* Generate Row and Column Address */
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, nDevInfo->Feature.PageSize, &RowAddr, &ColumnAddr, nDevInfo );
	else
		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );

	if ( res != SUCCESS )
		goto ErrorReadPage;

	/* Write Row and Column Address	*/
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Command READ2 [ 0x30 ] for Advance NandFlash */
	if ( nDevInfo->Feature.MediaType & A_BIG )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Change Cycle */
	NAND_IO_SetReadCycleTime();

	/* Read Page Size data from NANDFLASH */
	nSpareOnOff = TNFTL_READ_SPARE_ON;

	if ( nDevInfo->Feature.MediaType & A_BIG )
	{
		res = NAND_IO_ReadSpareDataMTD( nDevInfo, nSpareBuffer, PAGE_ECC_ON );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Change Cycle */
		NAND_IO_SetCommCycleTime();
		
		/* Command Random Data Output [ 0x05 ] for Advance NandFlash */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0505;
		
		ColumnAddr = ( nStartPPage << 9 );
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (ColumnAddr >> 1) : ColumnAddr;

		NAND_IO_WriteColAddr( ColumnAddr, nDevInfo );

		/* Command Random Data Output [ 0xE0 ] for Advance NandFlash */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0xE0E0;

		/* Change Cycle */
		NAND_IO_SetReadCycleTime();
	}
	else if (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL ))
	{
		res = NAND_IO_ReadSpareDataMTD( nDevInfo, nSpareBuffer, PAGE_ECC_ON );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Change Cycle */
		NAND_IO_SetCommCycleTime();

		res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
		if ( res != SUCCESS )
			goto ErrorReadPage;

		/* Write Row and Column Address	*/
		NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

		/* Wait until it is ready */
		NAND_IO_WaitBusy( nDevInfo->ChipNo );

		/* Change Cycle */
		NAND_IO_SetReadCycleTime();
	}

	res = NAND_IO_Read512DataMTD( nDevInfo,
								  nStartPPage,
								  nReadPPSize,
								  nPageBuffer,
								  nSpareBuffer,
								  nEccOnOff,
								  TNFTL_READ_SPARE_ON );
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();
							
ErrorReadPage:
	//=============================================
	// Disable Chip Select
	// PostProcess
	//=============================================	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_ReadTwoPlanePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_ReadTwoPlanePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U32 nSecondPageAddr,
										U16 nStartPPage, U16 nReadPPSize,
										U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ) )
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	if ( ( nStartPPage + nReadPPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW
	//=============================================
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) &&
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_WaitBusyForInterleave( nDevInfo, nPageAddr );
	else
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_EnableWriteProtect();

	//=============================================
	// PRE-Operation
	//=============================================
	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nPageAddr, ( ( 512 + nDevInfo->EccDataSize ) * nStartPPage ), &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorReadPage;

	/* Two-Plane Page Read Command [0x60] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x6060;

	/* Write Row Address: Fixed 'Low' */
	NAND_IO_WriteBlockPageAddr( 0, nDevInfo );

	/* Two-Plane Page Read Command 2 [0x60] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x6060;

	NAND_IO_WriteBlockPageAddr( nSecondPageAddr, nDevInfo );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	//=============================================
	// Read Data
	//=============================================	
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	/* Write Col & Row Address: Fixed 'Low' */
	NAND_IO_WriteRowColAddr( 0, 0, nDevInfo );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0505;

	/* Write Col Address: Valid */
	NAND_IO_WriteColAddr( ColumnAddr, nDevInfo );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0xE0E0;

	/* Change Cycle */
	NAND_IO_SetReadCycleTime();

	/* Read Page Size data from NANDFLASH */
	#if defined(NAND_IO_USE_DMA_DOUBLE_BUF)
	res = NAND_IO_Read512DataDoubleBuf( nDevInfo,
									    nStartPPage,
									    nReadPPSize,
									    nPageBuffer,
									    nSpareBuffer,
									    nEccOnOff,
									    TNFTL_READ_SPARE_ON );
	#else
	res = NAND_IO_Read512Data( nDevInfo,
							   nStartPPage,
							   nReadPPSize,
							   nPageBuffer,
							   nSpareBuffer,
							   nEccOnOff,
							   TNFTL_READ_SPARE_ON );
	#endif

	/* Change Cycle */
	NAND_IO_SetCommCycleTime();
							
ErrorReadPage:
	//=============================================
	// Disable Chip Select
	// PostProcess
	//=============================================	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_ReadTwoPlaneLastPage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_ReadTwoPlaneLastPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
											U16 nStartPPage, U16 nReadPPSize,
											U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ) )
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	if ( ( nStartPPage + nReadPPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW
	//=============================================
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) &&
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_EnableWriteProtect();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Data
	//=============================================	
	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, ( ( 512 + nDevInfo->EccDataSize ) * nStartPPage ), &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorReadPage;

	/* Write Col & Row Address: Col Addr = Fixed 'Low' */
	NAND_IO_WriteRowColAddr( RowAddr, 0, nDevInfo );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0505;

	/* Write Col Address: Valid */
	NAND_IO_WriteColAddr( ColumnAddr, nDevInfo );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0xE0E0;

	/* Change Cycle */
	NAND_IO_SetReadCycleTime();

	/* Read Page Size data from NANDFLASH */
	#if defined(NAND_IO_USE_DMA_DOUBLE_BUF)
	res = NAND_IO_Read512DataDoubleBuf( nDevInfo,
									    nStartPPage,
									    nReadPPSize,
									    nPageBuffer,
									    nSpareBuffer,
									    nEccOnOff,
									    TNFTL_READ_SPARE_ON );
	#else
	res = NAND_IO_Read512Data( nDevInfo,
							   nStartPPage,
							   nReadPPSize,
							   nPageBuffer,
							   nSpareBuffer,
							   nEccOnOff,
							   TNFTL_READ_SPARE_ON );
	#endif
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();
							
ErrorReadPage:
	//=============================================
	// Disable Chip Select
	// PostProcess
	//=============================================	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_ReadUserSizePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_ReadUserSizePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
										U16 nColumnAddr, U32 nReadSize, U8 *nReadBuffer )
{
	unsigned int		RowAddr, ColumnAddr;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	if ( (U32)( nColumnAddr + nReadSize ) > (U16)( nDevInfo->Feature.PageSize + nDevInfo->Feature.SpareSize ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW	
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_EnableWriteProtect();
		
	//=============================================
	// Read UserSize Data
	//=============================================

	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, nColumnAddr, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorReadUserSizePage;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );
	
	/* Command READ2 [ 0x30 ] for Advance NandFlash */
	if ( nDevInfo->Feature.MediaType & A_BIG )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;
	
	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Change Cycle */
	NAND_IO_SetReadCycleTime();

	/* Read User Size data from NANDFLASH */
	res = NAND_IO_ReadUserSizeData( nDevInfo,
									nColumnAddr,
									nReadSize,
									nReadBuffer );
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();

	if ( res != SUCCESS )
		goto ErrorReadUserSizePage;
	
ErrorReadUserSizePage:
	//=============================================
	// Disable Chip Select
	// PostProcess
	//=============================================	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_WriteSpare
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_WriteSpare( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
								  U8* nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;
	NAND_IO_ERROR		res;

	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	nEccOnOff = 0;
	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
	{
		res = NAND_IO_WaitBusyForInterleave( nDevInfo, nPageAddr );
		if ( res != SUCCESS )
			goto ErrorWritePage;	 
	}
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}
	
	//=============================================
	// Write Data
	//=============================================
	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForWrite( nPageAddr, nDevInfo->Feature.PageSize, &RowAddr, &ColumnAddr, nDevInfo );	
	if ( res != SUCCESS )
		goto ErrorWritePage;

	/* Command Page Program #1 [ 0x80 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	/* Write Data to NAND FLASH */
	res = NAND_IO_WriteSpareData( nDevInfo, nSpareBuffer, PAGE_ECC_OFF );
	
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();

	if ( res != SUCCESS )
		goto ErrorWritePage;
	
	/* Command Page Program #2 [ 0x10 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) ) )
	{
	    /* Wait until it is ready */
	    NAND_IO_WaitBusyForProgramAndErase( nDevInfo );
		    
	    /* Check Status */
	    res = NAND_IO_ReadStatus( nDevInfo );
	    if ( res != SUCCESS )
		{
			nDevInfo->WriteStatus.ChipNo 			= (U8)nDevInfo->ChipNo;
			nDevInfo->WriteStatus.BlockStatus 		= MULTI_PLANE_BAD_BLOCK;
			nDevInfo->WriteStatus.ErrorPHYPageAddr 	= nPageAddr;
			res = ERR_NAND_IO_FAILED_WRITE;
			
		    goto ErrorWritePage;
		}
	}
	else
	{
		NAND_IO_SetInterleaveStatus( nDevInfo, nPageAddr );
		gInterLeavePageAddr = nPageAddr;
	}
ErrorWritePage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE  ) ) )
		NAND_IO_EnableWriteProtect();
	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_WritePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_WritePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
								 U16 nStartPPage, U16 nWritePPSize,
								 U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;	
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
		
	if ( ( nStartPPage + nWritePPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
	{
		res = NAND_IO_WaitBusyForInterleave( nDevInfo, nPageAddr );
		if ( res != SUCCESS )
			goto ErrorWritePage;
	}
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}
	
	//=============================================
	// Write Data
	//=============================================
	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForWrite( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
		
	if ( res != SUCCESS )
		goto ErrorWritePage;

	/* Command Page Program #1 [ 0x80 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	/* Write Data to NAND FLASH */
	#if defined(NAND_IO_USE_DMA_DOUBLE_BUF_WRITE)
	res = NAND_IO_Write512DataDoubleBuf( nDevInfo,
										 nStartPPage,
										 nWritePPSize,
										 nPageBuffer,
										 nSpareBuffer,
										 nEccOnOff );
	#else
	res = NAND_IO_Write512Data( nDevInfo,
								nStartPPage,
								nWritePPSize,
								nPageBuffer,
								nSpareBuffer,
								nEccOnOff );
	#endif
	
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();

	if ( res != SUCCESS )
		goto ErrorWritePage;
	
	/* Command Page Program #2 [ 0x10 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
	
	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) ) )
	{
	    /* Wait until it is ready */
	    NAND_IO_WaitBusyForProgramAndErase( nDevInfo );
		    
	    /* Check Status */
	    res = NAND_IO_ReadStatus( nDevInfo );
	    if ( res != SUCCESS )
		{
			nDevInfo->WriteStatus.ChipNo 			= (U8)nDevInfo->ChipNo;
			nDevInfo->WriteStatus.BlockStatus 		= MULTI_PLANE_BAD_BLOCK;
			nDevInfo->WriteStatus.ErrorPHYPageAddr 	= nPageAddr;
			res = ERR_NAND_IO_FAILED_WRITE;
			
		    goto ErrorWritePage;
		}
	}
	else
	{
		NAND_IO_SetInterleaveStatus( nDevInfo, nPageAddr );
		gInterLeavePageAddr = nPageAddr;		
	}

ErrorWritePage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE  ) ) )
		NAND_IO_EnableWriteProtect();
	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_WritePageMTD
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_WritePageMTD( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
								 	U16 nStartPPage, U16 nWritePPSize,
									U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;	
	NAND_IO_ERROR		res;
	
	//=============================================
	// Check Device and Parameter
	//=============================================
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
		
	if ( ( nStartPPage + nWritePPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
	{
		res = NAND_IO_WaitBusyForInterleave( nDevInfo, nPageAddr );
		if ( res != SUCCESS )
			goto ErrorWritePage;
	}
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}
	
	//=============================================
	// Write Data
	//=============================================

	/* Generate Row and Column Address */
	if ( nDevInfo->Feature.MediaType  & A_BIG )
		res = NAND_IO_GenerateRowColAddrForWrite( nPageAddr, ( ( 512 + nDevInfo->EccDataSize ) * nStartPPage ), &RowAddr, &ColumnAddr, nDevInfo );
	else
		res = NAND_IO_GenerateRowColAddrForWrite( nPageAddr, ( 528 * nStartPPage ), &RowAddr, &ColumnAddr, nDevInfo );
		
	if ( res != SUCCESS )
		goto ErrorWritePage;

	/* Command Page Program #1 [ 0x80 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	/* Write Data to NAND FLASH */
	res = NAND_IO_Write512DataMTD( nDevInfo,
								   nStartPPage,
								   nWritePPSize,
								   nPageBuffer,
								   nSpareBuffer,
								   nEccOnOff );
	
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();

	if ( res != SUCCESS )
		goto ErrorWritePage;
	
	/* Command Page Program #2 [ 0x10 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) ) )
	{
	    /* Wait until it is ready */
	    NAND_IO_WaitBusyForProgramAndErase( nDevInfo );
		    
	    /* Check Status */
	    res = NAND_IO_ReadStatus( nDevInfo );
	    if ( res != SUCCESS )
		{
			nDevInfo->WriteStatus.ChipNo 			= (U8)nDevInfo->ChipNo;
			nDevInfo->WriteStatus.BlockStatus 		= MULTI_PLANE_BAD_BLOCK;
			nDevInfo->WriteStatus.ErrorPHYPageAddr 	= nPageAddr;
			res = ERR_NAND_IO_FAILED_WRITE;
			
		    goto ErrorWritePage;
		}
	}
	else
	{
		NAND_IO_SetInterleaveStatus( nDevInfo, nPageAddr );
		gInterLeavePageAddr = nPageAddr;		
	}

ErrorWritePage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE  ) ) )
		NAND_IO_EnableWriteProtect();
	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_WriteCachePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_WriteCachePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
									  U16 nStartPPage, U16 nWritePPSize,
									  U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;	
	NAND_IO_ERROR		res;

	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
		
	if ( ( nStartPPage + nWritePPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();
	
	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}

	//=============================================
	// Write Data
	//=============================================

	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorWritePage;

	/* Command Page Program #1 [ 0x80 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	/* Write Data to NAND FLASH */
	#if defined(NAND_IO_USE_DMA_DOUBLE_BUF_WRITE)
	res = NAND_IO_Write512DataDoubleBuf( nDevInfo,
										 nStartPPage,
										 nWritePPSize,
										 nPageBuffer,
										 nSpareBuffer,
										 nEccOnOff );
	#else
	res = NAND_IO_Write512Data( nDevInfo,
								nStartPPage,
								nWritePPSize,
								nPageBuffer,
								nSpareBuffer,
								nEccOnOff );
	#endif
	
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();

	if ( res != SUCCESS )
		goto ErrorWritePage;
	
	/* Command Page Program #2 [ 0x15 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1515;

	/* Wait until it is ready */
	NAND_IO_WaitBusyForCacheProgram( nDevInfo );

	/* Check Status */
	res = NAND_IO_ReadStatusForCacheProgram( nDevInfo );
	if ( res != SUCCESS )
	{
		nDevInfo->WriteStatus.ChipNo 			= (U8)nDevInfo->ChipNo;
		nDevInfo->WriteStatus.BlockStatus 		= MULTI_PLANE_BAD_BLOCK;
		nDevInfo->WriteStatus.ErrorPHYPageAddr 	= nPageAddr;
		res = ERR_NAND_IO_FAILED_WRITE;

		goto ErrorWritePage;
	}

ErrorWritePage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	//NAND_IO_EnableWriteProtect();
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_WriteTwoPlanePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_WriteTwoPlanePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
									     U16 nStartPPage, U16 nWritePPSize,
									     U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;
	unsigned long int	dwTempPHYPageAddr;
	NAND_IO_ERROR		res;

	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
		
	if ( ( nStartPPage + nWritePPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
	{
		res = NAND_IO_WaitBusyForInterleave( nDevInfo, nPageAddr );
		if ( res != SUCCESS )
			goto ErrorWritePage;	
	}
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}

	//=============================================
	// Write Data
	//=============================================
	if ( ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == HYNIX_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID ) )
	{
		if ( ( nDevInfo->Feature.MediaType & A_MLC ) || ( nDevInfo->Feature.MediaType & A_SLC ) || ( nDevInfo->Feature.MediaType & A_MLC_12BIT ) )
		{
		    dwTempPHYPageAddr = ( ( nDevInfo->Feature.PBpV << nDevInfo->ShiftPpB ) >> 1 );
    
	 	    if ( nPageAddr & dwTempPHYPageAddr )
	 		    nPageAddr = dwTempPHYPageAddr;
		    else
			    nPageAddr = 0;
	    }
	}
		
	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorWritePage;

	/* Command Page Program #1 [ 0x80 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	/* Write Data to NAND FLASH */
	#if defined(NAND_IO_USE_DMA_DOUBLE_BUF_WRITE)
	res = NAND_IO_Write512DataDoubleBuf( nDevInfo,
										  nStartPPage,
										  nWritePPSize,
										  nPageBuffer,
										  nSpareBuffer,
										  nEccOnOff );
	#else
	res = NAND_IO_Write512Data( nDevInfo,
								nStartPPage,
								nWritePPSize,
								nPageBuffer,
								nSpareBuffer,
								nEccOnOff );
	#endif
	
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();

	if ( res != SUCCESS )
		goto ErrorWritePage;
	
	/* Command Multi Plane Page Program #2 [ 0x11 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1111;

	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) ) )
		NAND_IO_WaitBusyForCacheProgram( nDevInfo );

ErrorWritePage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_WriteTwoPlaneLastPage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_WriteTwoPlaneLastPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
									    	 U16 nStartPPage, U16 nWritePPSize,
									    	 U8 *nPageBuffer, U8* nSpareBuffer, int LastPage, int nEccOnOff )
{
	unsigned int		RowAddr, ColumnAddr;	
	NAND_IO_ERROR		res;

	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
		
	if ( ( nStartPPage + nWritePPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
	NAND_IO_DisableWriteProtect();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Write Data
	//=============================================

	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorWritePage;

	/* Command Page Program #1 [ 0x80 ] */
	if ( ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == HYNIX_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID ) )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8181;
	else if ( ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ))
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;
	
	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	/* Write Data to NAND FLASH */
	#if defined(NAND_IO_USE_DMA_DOUBLE_BUF_WRITE)
	res = NAND_IO_Write512DataDoubleBuf( nDevInfo,
										  nStartPPage,
										  nWritePPSize,
										  nPageBuffer,
										  nSpareBuffer,
										  nEccOnOff );
	#else
	res = NAND_IO_Write512Data( nDevInfo,
								nStartPPage,
								nWritePPSize,
								nPageBuffer,
								nSpareBuffer,
								nEccOnOff );
	#endif
	
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();

	if ( res != SUCCESS )
		goto ErrorWritePage;
	
	/* Command Page Program #2 [ 0x10 ] */
	if ( ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID ) )	
	{
		if ( ( LastPage == MULTI_PLANE_LAST_PAGE ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
		else if ( LastPage == MULTI_PLANE_MID_PAGE )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1515;
	}
	else	
	{
		// SAMSUNG, HYNIX, MICRON, INTEL, ST Maker TwoPlane Write Function
		if ( nDevInfo->Feature.MediaType & S_MCP )
		{
			if ( LastPage == MULTI_PLANE_LAST_PAGE )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
			else if ( LastPage == MULTI_PLANE_MID_PAGE )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1515;
		}
		else
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
	}

	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) ) )
	{
		/* Wait until it is ready */
		NAND_IO_WaitBusyForProgramAndErase( nDevInfo );
			
		/* Check Status */
		if ( LastPage == MULTI_PLANE_LAST_PAGE )
		{
		    res = NAND_IO_ReadStatusForMultiPlane( nDevInfo );
		    if ( res != SUCCESS )
		    {
			    nDevInfo->WriteStatus.ChipNo 			= (U8)nDevInfo->ChipNo;
			    nDevInfo->WriteStatus.BlockStatus 		= MULTI_PLANE_BAD_BLOCK;
			    nDevInfo->WriteStatus.ErrorPHYPageAddr 	= nPageAddr;
			    res = ERR_NAND_IO_FAILED_WRITE;
    
			    goto ErrorWritePage;
		    }
	    }
	}	
	else
	{
		NAND_IO_SetInterleaveStatus( nDevInfo, nPageAddr );
		gInterLeavePageAddr = nPageAddr;
	}

ErrorWritePage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	//NAND_IO_EnableWriteProtect();
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_WriteUserSizePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_WriteUserSizePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
										 U16 nColumnAddr, U32 nWriteSize, U8 *nWriteBuffer )
{
	unsigned int		RowAddr, ColumnAddr;	
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
		
	if ( (U32)( nColumnAddr + nWriteSize ) > (U16)( nDevInfo->Feature.PageSize + nDevInfo->Feature.SpareSize ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}

	//=============================================
	// Write UserSize Data
	//=============================================

	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForWrite( nPageAddr, nColumnAddr, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorWriteUserSizePage;

	/* Command Page Program #1 [ 0x80 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	/* Write Data to NAND FLASH */
	res = NAND_IO_WriteUserSizeData( nDevInfo,
									 nColumnAddr,
									 nWriteSize,
									 nWriteBuffer );
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();
									 
	if ( res != SUCCESS )
		goto ErrorWriteUserSizePage;
	
	/* Command Page Program #2 [ 0x10 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;

	/* Wait until it is ready */
	NAND_IO_WaitBusyForProgramAndErase( nDevInfo );

	/* Check Status */
	res = NAND_IO_ReadStatus( nDevInfo );
	if ( res != SUCCESS )
	{
		nDevInfo->WriteStatus.ChipNo 			= (U8)nDevInfo->ChipNo;
		nDevInfo->WriteStatus.BlockStatus 		= MULTI_PLANE_BAD_BLOCK;
		nDevInfo->WriteStatus.ErrorPHYPageAddr 	= nPageAddr;
		res = ERR_NAND_IO_FAILED_WRITE;
		
		goto ErrorWriteUserSizePage;
	}

ErrorWriteUserSizePage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	NAND_IO_EnableWriteProtect();
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_MakeBootBinary
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_MakeBootBinary( NAND_IO_DEVINFO *nDevInfo, U8 *nPageBuffer )
{
	NAND_IO_ERROR		res;

	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}

	//=============================================
	// ECC Encording
	//=============================================
	res = NAND_IO_EncodeBootBinary( nDevInfo, nPageBuffer, ECC_ON );

	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	NAND_IO_EnableWriteProtect();
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
	
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_CopyBackPage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_CopyBackPage( NAND_IO_DEVINFO *nDevInfo, U32 nDesPageAddr, U32 nSrcPageAddr )
{
	unsigned int		RowAddr, ColumnAddr;	
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
		
	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
	NAND_IO_DisableWriteProtect();

	//=============================================
	// Read Source Page Address
	//=============================================
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	
	/* Generate Src Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nSrcPageAddr, 0, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* CopyBack Command #1 [ 0x35 ] */
	if ( nDevInfo->Feature.MediaType & A_BIG )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3535;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	//=============================================
	// Copy Destination Page Address
	//=============================================
	/* CopyBack Command #2 */
	if ( nDevInfo->Feature.MediaType & A_SMALL )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8A8A;
	else
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8585;

	/* Generate Des Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nDesPageAddr, 0, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Waiting TADL Time 200nS */
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;

	/* CopyBack Command #3 */
	if ( nDevInfo->Feature.MediaType & A_SMALL )
	{
		// [ 32MB] K9F5608U0C, k9F5608U0B, K9F5608U0A
		// [ 32MB] K9F5608Q0C, K9F5608Q0B
		if (( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID ) &&
			(( nDevInfo->Feature.DeviceID.Code[1] == 0x75 ) || ( nDevInfo->Feature.DeviceID.Code[1] == 0x35 )))
		{
			// Nothing
		}
		else
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
	}
	else
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;

	/* Wait until it is ready */
	NAND_IO_WaitBusyForProgramAndErase( nDevInfo );
		
	/* Check Status */
	res = NAND_IO_ReadStatus( nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

ErrorCopyBackPage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	NAND_IO_EnableWriteProtect();
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
		
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_CopyBackTwoPlanePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_CopyBackTwoPlanePage( NAND_IO_DEVINFO *nDevInfo, U32 nDesPageAddr, U32 nSrcPageAddr )
{
	unsigned int		nReBlockPageAddr;
	unsigned int		RowAddr, ColumnAddr;	
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
		
	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
	NAND_IO_DisableWriteProtect();

	//=============================================
	// Read Source Page Address #1
	//=============================================
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	
	/* Generate Src Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nSrcPageAddr, 0, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* CopyBack Command #1 [ 0x35 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3535;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	//=============================================
	// Read Source Page Address #2
	//=============================================
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	
	/* Generate Src Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nSrcPageAddr + nDevInfo->Feature.PpB, 0, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* CopyBack Command #1 [ 0x35 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3535;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	//=============================================
	// Copy Destination Page Address
	//=============================================
	/* CopyBack Command #2 */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8585;

	if ( nDesPageAddr & ( nDevInfo->Feature.PBpV / 2) * nDevInfo->Feature.PpB )
		nReBlockPageAddr = (( nDevInfo->Feature.PBpV / 2) * nDevInfo->Feature.PpB);
	else
		nReBlockPageAddr = 0;
		
	/* Generate Des Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nReBlockPageAddr, 0, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Waiting TADL Time 200nS */
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;


	/* CopyBack Command #3 */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1111;

	/* Wait until it is ready */
	NAND_IO_WaitBusyForProgramAndErase( nDevInfo );
		
	/* Check Status */
	res = NAND_IO_ReadStatus( nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

	//=============================================
	// Copy Destination Page Address
	//=============================================
	/* CopyBack Command #2 */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8181;

	/* Generate Des Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForCBandCP( nDesPageAddr+ nDevInfo->Feature.PpB, 0, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Waiting TADL Time 200nS */
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;


	/* CopyBack Command #3 */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;

	/* Wait until it is ready */
	NAND_IO_WaitBusyForProgramAndErase( nDevInfo );
		
	/* Check Status */
	res = NAND_IO_ReadStatus( nDevInfo );
	if ( res != SUCCESS )
		goto ErrorCopyBackPage;

ErrorCopyBackPage:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	NAND_IO_EnableWriteProtect();
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
		
	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_EraseBlock
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_EraseBlock( NAND_IO_DEVINFO *nDevInfo, U32 nBlockPageAddr, int nFormatMode )
{
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nBlockPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_WaitBusyForInterleave( nDevInfo, nBlockPageAddr );
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}

	//=============================================
	// Erase Block
	//=============================================

	/* Command Block Erase #1 [ 0x60 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x6060;

	/* Write Block Address */
	NAND_IO_WriteBlockPageAddr( nBlockPageAddr, nDevInfo );

	/* Command Erase Block #2 [ 0xD0 ] */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0xD0D0;

	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) ) || ( nFormatMode == INTER_LEAVE_OFF ) )
	{
	    /* Wait until it is ready */
	    NAND_IO_WaitBusyForProgramAndErase( nDevInfo );
    
	    /* Check Status */
	    res = NAND_IO_ReadStatus( nDevInfo );
	    if ( res != SUCCESS )
	    {
			nDevInfo->BadBlockInfo.BlockStatus[nDevInfo->ChipNo] 	= MULTI_PLANE_BAD_BLOCK;
			nDevInfo->BadBlockInfo.BadBlkPHYAddr[nDevInfo->ChipNo]	= nBlockPageAddr;
		    goto ErrorEraseBlock;
		}
	}
	else
	{
		NAND_IO_SetInterleaveStatus( nDevInfo, nBlockPageAddr );
		if ( nDevInfo->BadBlockInfo.BlockStatus[nDevInfo->ChipNo]  != MULTI_PLANE_BAD_BLOCK )
			nDevInfo->BadBlockInfo.BadBlkPHYAddr[nDevInfo->ChipNo]	= nBlockPageAddr;
		res = (NAND_IO_ERROR)SUCCESS;
	}
ErrorEraseBlock:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE  ) ) )
		NAND_IO_EnableWriteProtect();

	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();

	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_EraseBlockForTwoPlane
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_EraseBlockForTwoPlane( NAND_IO_DEVINFO *nDevInfo, U32 nBlockPageAddr, int nFormatMode )
{
	unsigned long int	dwTempBlockPageAddr, dwAddSecondPageAddr;
	unsigned long int   nReBlockPageAddr = 0;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	res = (NAND_IO_ERROR)SUCCESS;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

    NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nBlockPageAddr );

	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_WaitBusyForInterleave( nDevInfo, nBlockPageAddr );
	else
	{
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
	}

	//=============================================
	// Erase Block
	//=============================================
    /* Command Block Erase #1 [ 0x60 ] */
    pNFC->NFC_CMD = nDevInfo->CmdMask & 0x6060;

	if ( ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == HYNIX_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID ) )
    {
	    dwTempBlockPageAddr = ( ( nDevInfo->Feature.PBpV << nDevInfo->ShiftPpB ) >> 1 );

 	    if ( ( nDevInfo->Feature.MediaType & A_SLC ) ||
 	    	 ( nDevInfo->Feature.MediaType & A_MLC ) || 
 	    	 ( nDevInfo->Feature.MediaType & A_MLC_12BIT ) )
		{	
			//---------------------------------------------
			//	SAMSUNG MLC(4BIT) ROW ADDR: FIXED LOW
			//	HYNIX MLC(4BIT, 12BIT) ROW ADDR: FIXED LOW
			//---------------------------------------------
	 	    if ( nBlockPageAddr & dwTempBlockPageAddr )
	 		    nReBlockPageAddr = dwTempBlockPageAddr;
		    else
			    nReBlockPageAddr = 0;
		}
		else if ( ( nDevInfo->Feature.MediaType & A_MLC_8BIT ) || ( nDevInfo->Feature.MediaType & A_MLC_16BIT ) )
		{
			//---------------------------------------------
			// SAMSUNG MLC(8BIT) ROW ADDR: REAL ADDR
			//---------------------------------------------
			nReBlockPageAddr = nBlockPageAddr;
		}
	    dwAddSecondPageAddr = nDevInfo->Feature.PpB;
	    
    }
    else if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID ) 
    {
	    nReBlockPageAddr = nBlockPageAddr;
		dwAddSecondPageAddr = ( nDevInfo->DistrictNum << nDevInfo->ShiftPpB );
    }
	else if ( ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ) )
	{
		nReBlockPageAddr = nBlockPageAddr;
		dwAddSecondPageAddr = nDevInfo->Feature.PpB;
	}
	else
	{
		// Local variable Init
		nReBlockPageAddr = 0;
		dwAddSecondPageAddr = 0;

		res = ERR_NAND_IO_WRONG_PARAMETER;
		goto ErrorEraseBlock;
	}
    
    /* Write Block Address */
    NAND_IO_WriteBlockPageAddr( nReBlockPageAddr, nDevInfo ); // <==  1st Block

    /* Command Block Erase #1 [ 0x60 ] */
    pNFC->NFC_CMD = nDevInfo->CmdMask & 0x6060;

    /* Write Block Address */
    NAND_IO_WriteBlockPageAddr( nBlockPageAddr + dwAddSecondPageAddr, nDevInfo );	// <==  2nd Block

    /* Command Erase Block #2 [ 0xD0 ] */
    pNFC->NFC_CMD = nDevInfo->CmdMask & 0xD0D0;

    if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) ) || ( nFormatMode == INTER_LEAVE_OFF ) )
    {
	    /* Wait until it is ready */
	    NAND_IO_WaitBusyForProgramAndErase( nDevInfo );

	    /* Check Status */
	    res = NAND_IO_ReadStatusForMultiPlane( nDevInfo );
	    if ( res != SUCCESS )
		{
			if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID )
			{
				if ( res == NAND_IO_DISTRICT_0 )
				{
					nDevInfo->BadBlockInfo.BlockStatus[0]	= MULTI_PLANE_BAD_BLOCK;
					nDevInfo->BadBlockInfo.BadBlkPHYAddr[0] = nBlockPageAddr;
				}
				else if ( res == NAND_IO_DISTRICT_1 )
				{
					nDevInfo->BadBlockInfo.BlockStatus[1] 	= MULTI_PLANE_BAD_BLOCK;
					nDevInfo->BadBlockInfo.BadBlkPHYAddr[1] = ( nBlockPageAddr + dwAddSecondPageAddr );
				}
			}
			else
			{
				nDevInfo->BadBlockInfo.BlockStatus[0]	= MULTI_PLANE_BAD_BLOCK;
				nDevInfo->BadBlockInfo.BadBlkPHYAddr[0] = nBlockPageAddr;
				nDevInfo->BadBlockInfo.BlockStatus[1] 	= MULTI_PLANE_BAD_BLOCK;
				nDevInfo->BadBlockInfo.BadBlkPHYAddr[1] = ( nBlockPageAddr + dwAddSecondPageAddr );
			}
			
			goto ErrorEraseBlock;
		}
	}
    else
    {
	    NAND_IO_SetInterleaveStatus( nDevInfo, nBlockPageAddr );

		if ( nDevInfo->Feature.MediaType & S_IL )
		{
			//=============================================	
			// Inter Leave
			//=============================================	
			if ( nBlockPageAddr < (U32)( ( nDevInfo->Feature.PBpV >> 1 ) << nDevInfo->ShiftPpB ) )
			{
				if ( nDevInfo->BadBlockInfo.BlockStatus[0] != MULTI_PLANE_BAD_BLOCK )
					nDevInfo->BadBlockInfo.BadBlkPHYAddr[0] = nBlockPageAddr;

				if ( nDevInfo->BadBlockInfo.BlockStatus[1] != MULTI_PLANE_BAD_BLOCK )
					nDevInfo->BadBlockInfo.BadBlkPHYAddr[1] = ( nBlockPageAddr + dwAddSecondPageAddr );
			}
			else
			{
				if ( nDevInfo->BadBlockInfo.BlockStatus[2] != MULTI_PLANE_BAD_BLOCK )
					nDevInfo->BadBlockInfo.BadBlkPHYAddr[2] = nBlockPageAddr;

				if ( nDevInfo->BadBlockInfo.BlockStatus[3] != MULTI_PLANE_BAD_BLOCK )
					nDevInfo->BadBlockInfo.BadBlkPHYAddr[3] = ( nBlockPageAddr + dwAddSecondPageAddr );
			}
		}
		else if ( nDevInfo->ExtInterleaveUsable == TRUE )
		{
			if ( nDevInfo->BadBlockInfo.BlockStatus[0] != MULTI_PLANE_BAD_BLOCK )
				nDevInfo->BadBlockInfo.BadBlkPHYAddr[0] = nBlockPageAddr;

			if ( nDevInfo->BadBlockInfo.BlockStatus[1] != MULTI_PLANE_BAD_BLOCK )
				nDevInfo->BadBlockInfo.BadBlkPHYAddr[1] = ( nBlockPageAddr + dwAddSecondPageAddr );
		}
    }

ErrorEraseBlock:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE  ) ) )
		NAND_IO_EnableWriteProtect();

	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();

	if ( res != SUCCESS )
		return res;

	return (NAND_IO_ERROR)SUCCESS;
	
}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_GetFactoryBadMarkOfPBlock
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_GetFactoryBadMarkOfPBlock( NAND_IO_DEVINFO *nDevInfo, U32 nBlockPageAddr )
{
    unsigned short int	i;	
	unsigned short int	wPageSize, wReadSize;
	unsigned short int	wColumnAddr;
	unsigned short int	wPageAddr;
	unsigned char		cBSA[512];
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nBlockPageAddr );
	
	//=============================================	
	// Get Factory Bad Mark Page Default 
	//=============================================	
	if ( ( nDevInfo->Feature.MediaType & A_MLC )	  || 
		 ( nDevInfo->Feature.MediaType & A_MLC_8BIT ) || 
		 ( nDevInfo->Feature.MediaType & A_MLC_12BIT )||
		 ( nDevInfo->Feature.MediaType & A_MLC_16BIT ) )
		wPageAddr = nDevInfo->Feature.PpB - 1; /*last page*/
	else
		wPageAddr = 0;  /*First Page*/ 

	//=============================================	
	// Setting ReadSize & Column Address 
	//=============================================	
	wReadSize = 1; 
	wPageSize = nDevInfo->Feature.PageSize;

	//=============================================
	// Exception: Micron  
	//=============================================
	if ( ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ) )
	{
		if ( ( nDevInfo->Feature.MediaType & A_MLC_8BIT ) || ( nDevInfo->Feature.MediaType & A_MLC_12BIT ) )
		{	
			wPageAddr = 0;
			wReadSize = nDevInfo->Feature.SpareSize;
		}
		else 
		{
			/*SLC, MLC*/
			wPageAddr = 0;
			wReadSize = 1;
		}
	}

	if ( nDevInfo->Feature.MediaType & A_PARALLEL )
	{
		wPageSize = ( wPageSize >> 1 );
		wReadSize = ( wReadSize << 1 );
	}
	
	if ( wPageSize == 512 )			/* SMALL BLOCK NANDFLASH */
		wColumnAddr = 517;
	else if ( wPageSize == 2048 )	/* BIG BLOCK NANDFLAHS */
		wColumnAddr = 2048;
	else if ( wPageSize == 4096 )	/* 4K Page BIG BLOCK NANDFLASH */
		wColumnAddr = 4096;
	else if ( wPageSize == 8192 )	/* 4K Page BIG BLOCK NANDFLASH */
		wColumnAddr = 8192;
	else
		return ERR_NAND_IO_FAILED_GET_FACTORY_BAD_MARK_OF_PBLOCK;
	
	if ( nDevInfo->Feature.MediaType & A_PARALLEL )
		wColumnAddr = ( wColumnAddr << 1 );

	/* Read BSA */
	res = NAND_IO_ReadUserSizePage( nDevInfo,
									nBlockPageAddr + wPageAddr,
									wColumnAddr,
									wReadSize,
									&cBSA[0] );
	if ( res != SUCCESS )
		return res;

	/* Check BSA */
	res = (NAND_IO_ERROR)SUCCESS;
	if ( nDevInfo->Feature.MediaType & A_PARALLEL )
	{
		//============================================
		//PARALLEL: Check Signature(00h) of BadBlock 
		//============================================
		for( i = 0 ; i < wReadSize; i += 2 )
		{
			if ( cBSA[i] != 0xFF )
				res |= NAND_IO_STATUS_FAIL_CS0_PARALLEL;
			if ( cBSA[i+1] != 0xFF )	
				res |= NAND_IO_STATUS_FAIL_CS1_PARALLEL;

            if( res != SUCCESS )
                return res; 			
		}
	}
	else
	{
		//============================================
		//SERIAL: Check Signature(00h) of BadBlock   
		//============================================
		for( i = 0 ; i < wReadSize; ++ i )
		{
			if ( cBSA[i] != 0xFF )
				res |= NAND_IO_STATUS_FAIL_CS0_SERIAL;

            if ( res != SUCCESS )
                return res;
		}
	}

	return res;

}

/******************************************************************************
*
*	NAND_IO_ERROR	NAND_IO_GetUID
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_IO_ERROR NAND_IO_GetUID( NAND_IO_DEVINFO *nDevInfo, U16 *nCmd, U8 *rReadData )
{
	unsigned int		i;
	unsigned int		RowAddr, ColumnAddr;
	unsigned char		cTempBuffer[512];
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	//=============================================
	// PreProcess
	// Set Setup and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
	NAND_IO_EnableWriteProtect();

	/* Command #1 */
	pNFC->NFC_CMD = nDevInfo->CmdMask & *nCmd;
	/* Command #2 */
	pNFC->NFC_CMD = nDevInfo->CmdMask & *(nCmd+1);

	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForRead( 0, 0, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		goto ErrorGetUID;

	/* Write Row and Column Address	*/
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Command READ2 [ 0x30 ] for Advance NandFlash */
	if ( nDevInfo->Feature.MediaType & A_BIG )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;
	
	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Read Data */
	res = NAND_IO_ReadUserSizeData( nDevInfo,
									0,
									512,
									cTempBuffer );
	if ( res != SUCCESS )
		goto ErrorGetUID;

	/* Copy Read Data */
	if ( nDevInfo->Feature.MediaType & A_PARALLEL )
	{
		for ( i = 0; i < 256; ++ i )
			rReadData[i] = cTempBuffer[i*2+0];
	}
	else
	{
		for ( i = 0; i < 256; ++ i )
			rReadData[i] = cTempBuffer[i];
	}

ErrorGetUID:
	//=============================================
	// FORCE TO SET WP LOW
	// Disable Chip Select
	// PostProcess
	//=============================================
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();

	//=============================================
	// Reset Chip
	//=============================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_Reset( nDevInfo->ChipNo, NAND_IO_PARALLEL_COMBINATION_MODE );
	else
		NAND_IO_Reset( nDevInfo->ChipNo, NAND_IO_SERIAL_COMBINATION_MODE );

	if ( res != SUCCESS )
		return res;

   	return (NAND_IO_ERROR)SUCCESS;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_CheckForExtendBlockAccess( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline	void NAND_IO_CheckForExtendBlockAccess( NAND_IO_DEVINFO *nDevInfo, U32* nPageAddr )
{
	unsigned long int		dwPhyBlkNo;
	unsigned long int		dwPhyPageNo;
	unsigned long int		dwPHYPageAddr;
	
	if ( nDevInfo->Feature.MediaType & S_EB )
	{
		dwPHYPageAddr = *nPageAddr;
		dwPhyBlkNo	  = dwPHYPageAddr >> nDevInfo->ShiftPpB;
		dwPhyPageNo   = dwPHYPageAddr - ( dwPhyBlkNo << nDevInfo->ShiftPpB );
		
		if ( dwPhyBlkNo >= ( nDevInfo->Feature.PBpV >> 1 ) )
		{
			dwPhyBlkNo   += ( nDevInfo->Feature.PBpV >> 1 );
			dwPHYPageAddr = ( dwPhyBlkNo << nDevInfo->ShiftPpB ) + dwPhyPageNo;

			*nPageAddr = dwPHYPageAddr;
		}
	}
	
}

//*****************************************************************************
//*
//*
//*					[ MISCELLANEOUS Functions of NAND IO ]
//*
//*
//*****************************************************************************
static __inline void NAND_IO_SetDataWidth( U32 width )
{
	if ( width == NAND_IO_DATA_WITDH_8BIT )
		BITCLR( pNFC->NFC_CTRL, HwNFC_CTRL_BW_16 );
	else
		BITSET( pNFC->NFC_CTRL, HwNFC_CTRL_BW_16 );
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_PortControl( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_PortControl( int nOnOff )  
{
	if ( !( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
	{
		if ( gNAND_GPIO_ON_OFF == ENABLE )
		{
			if ( nOnOff == ENABLE )
			{
				#if defined(TCC83XX)
				NAND_IO_SEL_REG = gNANDIO_GSELReg;
				#endif
				#if defined(TCC79X)
				// PORTCFG5 Configuration  ( TCC7930S B[0]~B[6] is reserved )
				// B[0] = NDXD[0]
				// B[1] = NDXD[1]
				// B[2] = NDXD[2]
				// B[3] = NDXD[3]
				// B[4] = NDXD[4]
				// B[5] = NDXD[5]
				// B[6] = NDXD[6]
				HwPORTCFG5 &= (0xF0000000);
				HwPORTCFG5 |= (0x01111111);

				// PORTCFG6 Configuration
				// B[7] = NDXD[7]				
				BITCSET( HwPORTCFG6, HwPORTCFG6_GPIOB7(15), HwPORTCFG6_GPIOB7(1));
				
		        #ifndef NAND_8BIT_ONLY
				// PORTCFG2 Configuration
				// F[15:12] = NDXD[15:12]
				BITCSET( HwPORTCFG2, HwPORTCFG2_HPXD11(15), HwPORTCFG2_HPXD11(2));
				// F[11:8]  = NDXD[11:8]
				BITCSET( HwPORTCFG2, HwPORTCFG2_HPXD15(15), HwPORTCFG2_HPXD15(2));
				#endif
				#endif
			}
			else
			{
				#if defined(TCC83XX)
				NAND_IO_SEL_REG = 0;
				NAND_IO_IOCON_REG |= gNANDIO_GIOCONReg;
				NAND_IO_GDATA 	  |= gNANDIO_GDATASet;
				#endif
				#if defined(TCC79X)
				// PORTCFG5 Configuration  ( TCC7930S B[0]~B[6] is reserved )
				// B[0] = NDXD[0]
				// B[1] = NDXD[1]
				// B[2] = NDXD[2]
				// B[3] = NDXD[3]
				// B[4] = NDXD[4]
				// B[5] = NDXD[5]
				// B[6] = NDXD[6]
				HwPORTCFG5 &= (0xF0000000);

				// PORTCFG6 Configuration
				// B[7] = NDXD[7]				
				BITCSET( HwPORTCFG6, HwPORTCFG6_GPIOB7(15), HwPORTCFG6_GPIOB7(0));
				HwGPBEN		|= 0x000000FF;
				HwGPBDAT	|= 0x000000FF;
				
		        #ifndef NAND_8BIT_ONLY
				// PORTCFG2 Configuration 
				// F[11:8]  = NDXD[11:8]
				BITCSET( HwPORTCFG2, HwPORTCFG2_HPXD11(15), HwPORTCFG2_HPXD11(1));
				// F[15:12] = NDXD[15:12]
				BITCSET( HwPORTCFG2, HwPORTCFG2_HPXD15(15), HwPORTCFG2_HPXD15(1));
				HwGPFEN		|= 0x0000FF00;
				HwGPFDAT 	|= 0x0000FF00;				
				#endif
				#endif
			}
		}
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_PreProcess( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_PreProcess( void )
{
	NAND_IO_PortControl( ENABLE );
	
	//IO_CKC_EnableBUS( IO_CKC_BUS_NFC );
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_PostProcess( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_PostProcess( void )
{
	//IO_CKC_DisableBUS( IO_CKC_BUS_NFC );
		
	NAND_IO_PortControl( DISABLE );
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_SetBasicCycleTime( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_SetBasicCycleTime( void )
{
	/* SETUP 1 PW 5 HOLD 1 */
	BITCSET( pNFC->NFC_CTRL, 0xFFF, 0xEEE );
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_SetCommCycleTime(void);
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
void NAND_IO_SetCommCycleTime(void)
{
	BITCSET( pNFC->NFC_CTRL, 0xFFF, CommCycleTime.RegValue );
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_SetWriteCycleTime(void);
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_SetWriteCycleTime(void)
{
	BITCSET( pNFC->NFC_CTRL, 0xFFF, WriteCycleTime.RegValue );
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_SetReadCycleTime(void);
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
void NAND_IO_SetReadCycleTime(void)
{
	BITCSET( pNFC->NFC_CTRL, 0xFFF, ReadCycleTime.RegValue );
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_BusControl(NAND_IO_DEVINFO *nDevInfo);
*  
*  DESCRIPTION : 
*  INPUT:
*			NAND_IO_DEVINFO Structure Variable Pointer
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_BusControl( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int	nMaxBusClk;
	unsigned int	nMaxBusClkMHZ;

	//==============================================
	// SET NAND I/O CYCLE
	//==============================================
	if ( nDevInfo->IoStatus == NAND_IO_STATUS_ENABLE )
	{
		#ifdef FWDN_DOWNLOADER_INCLUDE
		nMaxBusClk = 1000000;	// 100MHZ
		#elif defined(TCC89XX) || defined(TCC92XX)
		{
			#if defined(_WINCE_)
				#if defined(USE_V_ADDRESS)
				nMaxBusClk = tcc_ckc_getfbusctrl(CLKCTRL4);		
				#else
				tca_ckc_init();
				nMaxBusClk = tca_ckc_getfbusctrl(CLKCTRL4);
				#endif
			#elif defined(_LINUX_)
				tca_ckc_init();
				nMaxBusClk = tca_ckc_getfbusctrl(CLKCTRL4);
			#else
				nMaxBusClk = 1660000;		
			#endif
		}
		#endif

		if ( nMaxBusClk  == 0 )
			nMaxBusClk = 1660000;

		nMaxBusClkMHZ = ( nMaxBusClk / 10000 );
		
		if ( ( gMaxBusClkMHZ != 0 ) && ( nMaxBusClkMHZ != gMaxBusClkMHZ ) )
			NAND_IO_SetCycle( nDevInfo );
		}			
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_EnableChipSelect( U16 nChipNo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nChipNo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_EnableChipSelect( U16 nChipNo )
{
	if ( nChipNo == 0 )
	{
		/* NAND_IO_SUPPORT_4CS */
		#if defined(NAND_2CS_ONLY)
		BITSCLR( pNFC->NFC_CTRL, HwNFC_CTRL_CFG_nCS1, HwNFC_CTRL_CFG_nCS0 );
		#else
		BITSCLR( pNFC->NFC_CTRL, HwNFC_CTRL_CFG_NOACT, HwNFC_CTRL_CFG_nCS0 );
		#endif
	}
	else if ( nChipNo == 1 )
	{
		/* NAND_IO_SUPPORT_4CS */
		#if defined(NAND_2CS_ONLY)
		BITSCLR( pNFC->NFC_CTRL, HwNFC_CTRL_CFG_nCS0, HwNFC_CTRL_CFG_nCS1 );
		#else
		BITSCLR( pNFC->NFC_CTRL, HwNFC_CTRL_CFG_NOACT, HwNFC_CTRL_CFG_nCS1 );
		#endif
	}
	else if ( nChipNo == 2 )
	{
		/* NAND_IO_SUPPORT_4CS */
		BITSCLR( pNFC->NFC_CTRL, HwNFC_CTRL_CFG_NOACT, HwNFC_CTRL_CFG_nCS2 );
	}
	else if ( nChipNo == 3 )
	{
		/* NAND_IO_SUPPORT_4CS */
		BITSCLR( pNFC->NFC_CTRL, HwNFC_CTRL_CFG_NOACT, HwNFC_CTRL_CFG_nCS3 );
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_DisableChipSelect( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_DisableChipSelect( void )
{
	/* NAND_IO_SUPPORT_4CS */
	#if defined(NAND_2CS_ONLY)
	BITSET( pNFC->NFC_CTRL, ( HwNFC_CTRL_CFG_nCS0 | HwNFC_CTRL_CFG_nCS1 ) ); 
	#else
	BITSET( pNFC->NFC_CTRL, HwNFC_CTRL_CFG_NOACT );
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_EnableWriteProtect( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_EnableWriteProtect( void )
{
	#if defined(USE_V_ADDRESS)
		#if defined(_WINCE_)
		BITCLR( pGPIO->GPBDAT, NAND_IO_NFC_nWPBit );
        #else
        BITCLR( NAND_IO_NFC_nWP, NAND_IO_NFC_nWPBit );
		#endif
	#else
	BITCLR( NAND_IO_NFC_nWP, NAND_IO_NFC_nWPBit );
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_DisableWriteProtect( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_DisableWriteProtect( void )
{
	#if defined(USE_V_ADDRESS)
		#if defined(_WINCE_)
		BITSET( pGPIO->GPBDAT, NAND_IO_NFC_nWPBit );
        #else
	    BITSET( NAND_IO_NFC_nWP, NAND_IO_NFC_nWPBit );        
		#endif
	#else
	BITSET( NAND_IO_NFC_nWP, NAND_IO_NFC_nWPBit );
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline U32 NAND_IO_CheckReadyAndBusy( U16 nChipNo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nChipNo	= 
*  
*  OUTPUT:	U32 - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline U32 NAND_IO_CheckReadyAndBusy( U16 nChipNo )
{
	nChipNo = 0;	// Warning

	#if defined(TCC_NAND_RDY_B28)
	return ISZERO( pNFC->NFC_CTRL, HwNFC_CTRL_RDY_RDY );
	#elif defined(TCC_NAND_RDY_B31)
	return ISZERO( HwGPIOB->GPDAT, Hw31);
	#else
	#Error: NAND_IO_CheckReadyAndBusy Pin
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_WaitBusy( U16 nChipNo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nChipNo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_WaitBusy( U16 nChipNo )
{
	// Misc. Configuration Register(MCFG)
   	// 0 : represent that READY pin is low
   	// 1 :                             high
   	// Delay : 200nS

	NAND_IO_Delay();
	
	while (NAND_IO_CheckReadyAndBusy( nChipNo ));
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_WaitBusyForProgramAndErase( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_WaitBusyForProgramAndErase( NAND_IO_DEVINFO *nDevInfo )
{
	// Misc. Configuration Register(MCFG)
   	// 0 : represent that READY pin is low
   	// 1 :                             high
   	// Delay : 200nS
   	NAND_IO_Delay();

	while (NAND_IO_CheckReadyAndBusy( nDevInfo->ChipNo ))
	{
		#ifndef FWDN_DOWNLOADER_INCLUDE
		TCC7XX_USBDRV_WriteToQueue();
		#endif
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_WaitBusyForCacheProgram( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_WaitBusyForCacheProgram( NAND_IO_DEVINFO *nDevInfo )
{
	// Misc. Configuration Register(MCFG)
   	// 0 : represent that READY pin is low
   	// 1 :                             high
   	// Delay : 200nS
   	NAND_IO_Delay();

	while (NAND_IO_CheckReadyAndBusy( nDevInfo->ChipNo ))
	{
		#ifndef FWDN_DOWNLOADER_INCLUDE
		TCC7XX_USBDRV_WriteToQueue();
		#endif
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_WaitBusyForInterleave( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*			nPageAddr	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_WaitBusyForInterleave( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr )
{
	unsigned int		ChipNum = 0;
	NAND_IO_ERROR		res;

	NAND_IO_Delay();
	gInterLeaveWriteStatus = MULTI_PLANE_GOOD_BLOCK;

	if ( gDevInfo->Feature.MediaType & S_IL )
	{
		//=============================================	
		// Inter Leave
		//=============================================	
		if ( gInterLeaveCSNum != nDevInfo->ChipNo )
		{
			NAND_IO_EnableChipSelect( (U16)gInterLeaveCSNum );
			NAND_IO_DisableWriteProtect();
			nDevInfo->WriteStatus.ChipNo = (U8)gDevInfo->ChipNo;

			while ( NAND_IO_ReadStatusForInterleaveClear( gDevInfo ) )
			{
				#ifndef FWDN_DOWNLOADER_INCLUDE
				TCC7XX_USBDRV_WriteToQueue();
				#endif
			}
	  	}
		else
		{
			NAND_IO_EnableChipSelect( (U16)gInterLeaveCSNum );
			NAND_IO_DisableWriteProtect();
			nDevInfo->WriteStatus.ChipNo = (U8)nDevInfo->ChipNo;

			   	while ( NAND_IO_ReadStatusForInterleave( gDevInfo, nPageAddr ) )
			{
				#ifndef FWDN_DOWNLOADER_INCLUDE
				TCC7XX_USBDRV_WriteToQueue();
				#endif
			}
		}

		NAND_IO_DisableChipSelect();
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
	}
	else if ( nDevInfo->ExtInterleaveUsable == TRUE )
	{
		//=============================================	
		// External Inter Leave
		//=============================================	
		if ( nDevInfo->ChipNo == 0 )
			ChipNum = NAND_IO_STATUS_INTERLEAVING_CHIP1;
		else if ( nDevInfo->ChipNo == 1 )
			ChipNum = NAND_IO_STATUS_INTERLEAVING_CHIP2;
		else if ( nDevInfo->ChipNo == 2 )
			ChipNum = NAND_IO_STATUS_INTERLEAVING_CHIP3;
		else if ( nDevInfo->ChipNo == 3 )
			ChipNum = NAND_IO_STATUS_INTERLEAVING_CHIP4;

		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		NAND_IO_DisableWriteProtect();
			
		if ( gInterLeaveIoStatus & (U16)ChipNum )
		{
			NAND_IO_WaitBusyForProgramAndErase( gDevInfo );	
		    res = NAND_IO_ReadStatus( gDevInfo );
		    if ( res != SUCCESS )
			{
				nDevInfo->WriteStatus.ChipNo = (U8)gDevInfo->ChipNo;
				nDevInfo->BadBlockInfo.BlockStatus[gDevInfo->ChipNo] = MULTI_PLANE_BAD_BLOCK; 
				gInterLeaveWriteStatus = MULTI_PLANE_BAD_BLOCK;	
			}
			gInterLeaveIoStatus &= ~ChipNum;
		}
	}

	if ( gInterLeaveWriteStatus == MULTI_PLANE_BAD_BLOCK )
	{ 
		nDevInfo->WriteStatus.BlockStatus 		= MULTI_PLANE_BAD_BLOCK;
		nDevInfo->WriteStatus.ErrorPHYPageAddr 	= gInterLeavePageAddr;
		gInterLeaveWriteStatus 					= MULTI_PLANE_GOOD_BLOCK;
		res = ERR_NAND_IO_FAILED_WRITE;
	}
	else
	{
		nDevInfo->WriteStatus.BlockStatus 		= MULTI_PLANE_GOOD_BLOCK;		
		nDevInfo->WriteStatus.ErrorPHYPageAddr 	= 0xFFFFFFFF;
		res = (NAND_IO_ERROR)SUCCESS;
	}

	return res;
	
}

/**************************************************************************
*  FUNCTION NAME : 
*      NAND_IO_ERROR NAND_IO_WaitBusyCheckForWriteEnd( NAND_IO_DEVINFO *nDevInfo )
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
NAND_IO_ERROR	NAND_IO_WaitBusyCheckForWriteEnd( NAND_IO_DEVINFO *nDevInfo )
{
	NAND_IO_Delay();
	NAND_IO_PreProcess();
 
	if ( nDevInfo->Feature.MediaType & S_IL )
	{
		//=============================================	
		// Inter Leave
		//=============================================	

	   	if ( gInterLeaveCSNum != nDevInfo->ChipNo )
		{
			NAND_IO_EnableChipSelect( (U16)gInterLeaveCSNum );
			NAND_IO_DisableWriteProtect();

			while ( NAND_IO_ReadStatusForInterleaveClear( nDevInfo ) )
			{
				#ifndef FWDN_DOWNLOADER_INCLUDE
				TCC7XX_USBDRV_WriteToQueue();
				#endif
			}

			NAND_IO_DisableChipSelect();
			NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
		}
		else
		{
			NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
			NAND_IO_DisableWriteProtect();

			while ( NAND_IO_ReadStatusForInterleave( nDevInfo, gInterLeavePageAddr ) )
			{
				#ifndef FWDN_DOWNLOADER_INCLUDE
				TCC7XX_USBDRV_WriteToQueue();
				#endif
			}
		}
	}
	else if ( nDevInfo->ExtInterleaveUsable == TRUE )
	{
		//=============================================	
		// External Inter Leave
		//=============================================	

		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP1 )
		{
			NAND_IO_EnableChipSelect( 0 );
			NAND_IO_DisableWriteProtect();
			NAND_IO_WaitBusy(0);

			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP1;

			NAND_IO_DisableChipSelect();
		}

		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP2 )
		{
			NAND_IO_EnableChipSelect( 1 );
			NAND_IO_DisableWriteProtect();
			NAND_IO_WaitBusy(1);

			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP2;

			NAND_IO_DisableChipSelect();
		}

		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP3 )
		{
			NAND_IO_EnableChipSelect( 2 );
			NAND_IO_DisableWriteProtect();
			NAND_IO_WaitBusy(2);

			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP3;

			NAND_IO_DisableChipSelect();
		}
		
		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP4 )
		{
			NAND_IO_EnableChipSelect( 3 );
			NAND_IO_DisableWriteProtect();
			NAND_IO_WaitBusy(3);

			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP4;

			NAND_IO_DisableChipSelect();
		}
	}
	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();

   	return (NAND_IO_ERROR)SUCCESS;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_IO_SetInterLeavePageAddr(U32 nPageAddr );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nPageAddr	= 
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_IO_SetInterLeavePageAddr(U32 nPageAddr )
{
	gInterLeavePageAddr = nPageAddr;
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_SetInterleaveStatus( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*			nPageAddr	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
void NAND_IO_SetInterleaveStatus( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr )
{

	if ( nDevInfo->Feature.MediaType & S_IL )
	{
		//=============================================	
		// Inter Leave
		//=============================================	

		if ( nPageAddr < (U32)(( ( nDevInfo->Feature.PBpV >> 1 ) << nDevInfo->ShiftPpB ) ))
		{
			gInterLeaveIoStatus |= NAND_IO_STATUS_INTERLEAVING_CHIP1;
			gInterLeaveDie0BlockAddr = nPageAddr;
		}
		else
		{
			gInterLeaveIoStatus |= NAND_IO_STATUS_INTERLEAVING_CHIP2;
			gInterLeaveDie1BlockAddr = nPageAddr;
		}
		gInterLeaveCSNum = nDevInfo->ChipNo;
	}
	else if ( nDevInfo->ExtInterleaveUsable == TRUE )
	{
		//=============================================	
		// External Inter Leave
		//=============================================	

		if ( nDevInfo->ChipNo == 0 )
			gInterLeaveIoStatus |= NAND_IO_STATUS_INTERLEAVING_CHIP1;
		else if ( nDevInfo->ChipNo == 1 )
			gInterLeaveIoStatus |= NAND_IO_STATUS_INTERLEAVING_CHIP2;
		else if ( nDevInfo->ChipNo == 2 )
			gInterLeaveIoStatus |= NAND_IO_STATUS_INTERLEAVING_CHIP3;
		else if ( nDevInfo->ChipNo == 3 )
			gInterLeaveIoStatus |= NAND_IO_STATUS_INTERLEAVING_CHIP4;
	}

	gDevInfo = (NAND_IO_DEVINFO *)nDevInfo;
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_ClearInterleaveStatus( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_ClearInterleaveStatus( NAND_IO_DEVINFO *nDevInfo )
{
	NAND_IO_Delay();
	gInterLeaveWriteStatus = MULTI_PLANE_GOOD_BLOCK;

	if ( gDevInfo->Feature.MediaType & S_IL )
	{
		//=============================================	
		// Inter Leave
		//=============================================	
		NAND_IO_EnableChipSelect( (U16)gInterLeaveCSNum );
		NAND_IO_DisableWriteProtect();
				
		while ( NAND_IO_ReadStatusForInterleaveClear( gDevInfo ) )
		{
			#ifndef FWDN_DOWNLOADER_INCLUDE
		//	TCC7XX_USBDRV_WriteToQueue();
			#endif
		}
		
		NAND_IO_DisableChipSelect();
		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
	}
	else if ( gDevInfo->ExtInterleaveUsable == TRUE )
	{
		//=============================================	
		// External Inter Leave
		//=============================================	

		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP1 )
		{
			NAND_IO_EnableChipSelect( 0 );
			NAND_IO_DisableWriteProtect();
			NAND_IO_WaitBusyForProgramAndErase( gDevInfo );	

			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP1;

			NAND_IO_DisableChipSelect();
		}

		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP2 )
		{
			NAND_IO_EnableChipSelect( 1 );
			NAND_IO_DisableWriteProtect();
			NAND_IO_WaitBusyForProgramAndErase( gDevInfo );	

			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP2;

			NAND_IO_DisableChipSelect();
		}

		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP3 )
		{
			NAND_IO_EnableChipSelect( 2 );
			NAND_IO_DisableWriteProtect();
			NAND_IO_WaitBusyForProgramAndErase( gDevInfo );	

			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP3;

			NAND_IO_DisableChipSelect();
		}
		
		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP4 )
		{
			NAND_IO_EnableChipSelect( 3 );
			NAND_IO_DisableWriteProtect();
			NAND_IO_WaitBusyForProgramAndErase( gDevInfo );	

			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP4;

			NAND_IO_DisableChipSelect();
		}

		NAND_IO_EnableChipSelect( nDevInfo->ChipNo );
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_Delay( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_Delay( void )
{
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
 	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      NAND_IO_ERROR NAND_IO_IRQ_ReadPagePreProcess( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U32 *rEccBuffer, U16 nChipNo );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nChipNo	= 
*			nDevInfo	= 
*			nPageAddr	= 
*			nStartPPage	= 
*			rEccBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
NAND_IO_ERROR NAND_IO_IRQ_ReadPagePreProcess( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U32 *rEccBuffer, U16 nChipNo )
{
	unsigned int		i;
	unsigned int		RowAddr, ColumnAddr;
	unsigned short int	nSpareTotalSize;
	unsigned char		*pSpareB = 0;
	NAND_IO_ERROR		res;
	
	//=============================================	
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ) )
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;
	
	//=============================================
	// PreProcess
	// Set Setup and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP LOW
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) )
		NAND_IO_ClearInterleaveStatus( nDevInfo );
	else
		NAND_IO_EnableChipSelect( nChipNo );

	NAND_IO_EnableWriteProtect();

	//=============================================
	// Read Data
	//=============================================	
	// ECC Read
	if ( nDevInfo->Feature.MediaType & A_MLC_16BIT )
		nSpareTotalSize = 20;
	else
		nSpareTotalSize = 24;
	
	/* Generate Row and Column Address */
	res = NAND_IO_GenerateRowColAddrForRead( nPageAddr, nDevInfo->Feature.PageSize + nSpareTotalSize, &RowAddr, &ColumnAddr, nDevInfo );
	if ( res != SUCCESS )
		return res;

	/* Write Row and Column Address	*/
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );
	
	/* Command READ2 [ 0x30 ] for Advance NandFlash */
	if ( nDevInfo->Feature.MediaType & A_BIG )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;


	#ifdef NAND_GPIO_DEBUG
	BITSET(pGPIO->GPFDAT, Hw21);
	#endif	
	
	/* Change Cycle */
	NAND_IO_SetReadCycleTime();

	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );
	
	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	// Set SpareBuffer Pointer =>> ECCBuffer
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
	{
		pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];

		//=========================================================================
		// Empty Page ECCBuffer Pointer Increment
		//=========================================================================
		for ( i = 0; i < nStartPPage; ++i )
			pSpareB += nDevInfo->EccDataSize;

		*rEccBuffer = (unsigned int)pSpareB;
	}

	return SUCCESS;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_IO_IRQ_ReadPagePostProcess( void );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_IO_IRQ_ReadPagePostProcess( void )
{
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();
							
	//=============================================
	// Disable Chip Select
	// PostProcess
	//=============================================	
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();	
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void 	NAND_IO_IRQ_Read512DataPreProcess( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void 	NAND_IO_IRQ_Read512DataPreProcess( NAND_IO_DEVINFO *nDevInfo )
{ 
	//==========================================================
	//
	// ECC Decode Setup
	//
	//==========================================================
	pECC->ECC_CLEAR	= 0x00000000;					/* Clear ECC Block		*/
	pECC->ECC_MASK	= 0x00000000;				/* Address mask for ECC area */

	if ( nDevInfo->EccType== SLC_ECC_TYPE )
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_SLCDE;
	else if (nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
	{
		pECC->ECC_CTRL	|= HwECC_CTRL_IEN_MECC4_EN;				
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL4DE;
	}
	else if (nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
	{
		pECC->ECC_CTRL	|= HwECC_CTRL_IEN_MECC8_EN;
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL8DE;
	}
	else if (nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
	{
		pECC->ECC_CTRL	|= HwECC_CTRL_IEN_MECC12_EN;
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL12DE;
	}
	else if (nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
	{
		pECC->ECC_CTRL	|= HwECC_CTRL_IEN_MECC16_EN;
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL16DE;
	}

	pECC->ECC_CTRL		|= ( 512 << ECC_SHIFT_DATASIZE );
	pECC->ECC_CLEAR	 = 0x00000000;			/* Clear ECC Block		*/
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      NAND_IO_ERROR 	NAND_IO_IRQ_Read512DataPostProcess( NAND_IO_DEVINFO *nDevInfo, U8* nPageBuffer, U8* nSpareBuffer );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nPageBuffer	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
NAND_IO_ERROR 	NAND_IO_IRQ_Read512DataPostProcess( NAND_IO_DEVINFO *nDevInfo, U8* nPageBuffer, U8* nSpareBuffer )
{ 
	NAND_IO_ERROR	res = (NAND_IO_ERROR)SUCCESS;

	/* Check and Correct ECC code */
	if (( nDevInfo->EccType == SLC_ECC_TYPE ) && ( nDevInfo->Feature.MediaType & A_SMALL ))
	{
		//===================================
		// SLC ECC Correction
		//===================================				
		nSpareBuffer += NAND_IO_SPARE_SIZE_SMALL;
		res |= NAND_IO_CorrectionSLC( nPageBuffer, nSpareBuffer );
	}
	else
	{
		if ( nDevInfo->EccType == SLC_ECC_TYPE )
			res |= NAND_IO_CorrectionSLC( nPageBuffer, nSpareBuffer );
		else
			res |= NAND_IO_CorrectionMLC( nDevInfo->EccType, nPageBuffer, nSpareBuffer, 512 );
	}

	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      NAND_IO_ERROR NAND_IO_IRQ_WritePagePreProcess( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
*      											   U16 nStartPPage, U8 *nSpareBuffer, U32 *rEccBuffer, U16 nChipNo, U8 nWriteMode );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nChipNo	= 
*			nDevInfo	= 
*			nPageAddr	= 
*			nSpareBuffer	= 
*			nStartPPage	= 
*			nWriteMode	= 
*			rEccBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
NAND_IO_ERROR NAND_IO_IRQ_WritePagePreProcess( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr,
											   U16 nStartPPage, U8 *nSpareBuffer, U32 *rEccBuffer, U16 nChipNo, U8 nWriteMode )
{
	unsigned int		j, i;
	unsigned int		RowAddr, ColumnAddr;
	unsigned long int	dwTempPHYPageAddr;
	unsigned char 		*pSpareB, *pSpare;
	NAND_IO_ERROR		res;
	NAND_IO_ECC_INFO	*pECC_Info;

	//=============================================
	// Check Device and Parameter
	//=============================================	
	if ( !( nDevInfo->IoStatus & NAND_IO_STATUS_ENABLE ))
		return ERR_NAND_IO_NOT_READY_DEVICE_IO;

	//=============================================
	// PreProcess
	// Set Setup Time and Hold Time
	// Enable Chip Select
	// FORCE TO SET WP HIGH
	//=============================================	
	NAND_IO_PreProcess();
	NAND_IO_BusControl(nDevInfo);
	NAND_IO_SetCommCycleTime();

	NAND_IO_CheckForExtendBlockAccess( nDevInfo, &nPageAddr );
	
	//=============================================
	// Read Status
	//=============================================
	/*  Wait until it is ready */
	if ( ( ( gDevInfo->Feature.MediaType & S_IL ) || ( gDevInfo->ExtInterleaveUsable == TRUE ) ) && 
	   ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ) && 
	   ( ( nWriteMode == MULTI_PLANE_START_PAGE ) || (nWriteMode == MULTI_PLANE_NORMAL_PAGE ) || (nWriteMode == MULTI_PLANE_STUFF_PAGE)) )
	{
		res = NAND_IO_WaitBusyForInterleave( nDevInfo, nPageAddr );
		if ( res != SUCCESS )
  		 	return (NAND_IO_ERROR)res;
	}
	else
	{
		NAND_IO_EnableChipSelect( nChipNo );
		NAND_IO_DisableWriteProtect();
	}

	//=============================================
	// Write Data
	//=============================================
	if ( nWriteMode == MULTI_PLANE_START_PAGE )
	{
		if ( ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == HYNIX_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID ) )
		{
			if ( ( nDevInfo->Feature.MediaType & A_MLC ) || ( nDevInfo->Feature.MediaType & A_SLC ) || ( nDevInfo->Feature.MediaType & A_MLC_12BIT ) )
			{
			    dwTempPHYPageAddr = ( ( nDevInfo->Feature.PBpV << nDevInfo->ShiftPpB ) >> 1 );
	    
		 	    if ( nPageAddr & dwTempPHYPageAddr )
		 		    nPageAddr = dwTempPHYPageAddr;
			    else
				    nPageAddr = 0;
		    }
		}		
	}

	if ( (nWriteMode == MULTI_PLANE_NORMAL_PAGE ) || (nWriteMode == MULTI_PLANE_STUFF_PAGE) )
	{
		/* Generate Row and Column Address */
		res = NAND_IO_GenerateRowColAddrForWrite( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );				
	}
	else
	{
		/* Generate Row and Column Address */
		res = NAND_IO_GenerateRowColAddrForCBandCP( nPageAddr, ( nStartPPage << 9 ), &RowAddr, &ColumnAddr, nDevInfo );		
	}		
	if ( res != SUCCESS )
	 	return (NAND_IO_ERROR)res;

	if ( ( nWriteMode == MULTI_PLANE_MID_PAGE ) || ( nWriteMode == MULTI_PLANE_LAST_PAGE ))
	{
		if ( ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == HYNIX_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID ) )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8181;
		else if ( ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ))
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;		
	}
	else
	{
		/* Command Page Program #1 [ 0x80 ] */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;		
	}

	/* Write Row and Column Address */
	NAND_IO_WriteRowColAddr( RowAddr, ColumnAddr, nDevInfo );

	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	//=========================================================================
	// Set SpareBuffer Pointer =>> ECCBuffer
	//=========================================================================
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
	{
		memset( gNAND_IO_ShareEccBuffer, 0xFF, nDevInfo->EccWholeDataSize );		
		pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
	}
	else
	{
		pSpareB		= (unsigned char*)nSpareBuffer;
		pSpareB 	+= NAND_IO_SPARE_SIZE_SMALL;
	}
	
	//=========================================================================
	// Empty Page ECCBuffer Pointer Increment
	//=========================================================================
	for ( j = 0; j < nStartPPage; ++j )
	{
		if ( nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
			pECC_Info = &gMLC_ECC_4Bit;
		else if ( nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
			pECC_Info = &gMLC_ECC_8Bit;
		else if ( nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
			pECC_Info = &gMLC_ECC_12Bit;
		else if ( nDevInfo->EccType == MLC_ECC_14BIT_TYPE )
			pECC_Info = &gMLC_ECC_14Bit;
		else if ( nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
			pECC_Info = &gMLC_ECC_16Bit;
		else
			return ERR_NAND_IO_WRONG_PARAMETER;

		if ( nDevInfo->Feature.MediaType  & A_MLC_16BIT )
		{
			pSpare = (unsigned char*)pSpareB;
			
			for ( i = 0; i < nDevInfo->EccDataSize; ++i )
				pSpare[i] = pECC_Info->All_FF_512_ECC_Code[i];
		}
		else
		{
			memcpy(	(void*)pSpareB, (void*)pECC_Info->All_FF_512_ECC_Code, nDevInfo->EccDataSize);
		}

		pSpareB += nDevInfo->EccDataSize;
	}

	*rEccBuffer = (unsigned int)pSpareB;

   	return (NAND_IO_ERROR)SUCCESS;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void 	NAND_IO_IRQ_WritePageMidProcess( NAND_IO_DEVINFO *nDevInfo, U8 nWriteMode );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nWriteMode	= 
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void 	NAND_IO_IRQ_WritePageMidProcess( NAND_IO_DEVINFO *nDevInfo, U8 nWriteMode )
{
	/* Change Cycle */
	NAND_IO_SetCommCycleTime();

	if ( nWriteMode == MULTI_PLANE_START_PAGE )
	{
		/* Command Multi Plane Page Program #2 [ 0x11 ] */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1111;

		if ( !( ( nDevInfo->Feature.MediaType & S_IL ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) ) )
			NAND_IO_WaitBusyForCacheProgram( nDevInfo );		
	}
	else if ( ( nWriteMode == MULTI_PLANE_MID_PAGE ) || ( nWriteMode == MULTI_PLANE_LAST_PAGE ) )
	{
		if ( ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID ) )	
		{
			if ( ( nWriteMode == MULTI_PLANE_LAST_PAGE ) || ( nDevInfo->ExtInterleaveUsable == TRUE ) )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
			else if ( nWriteMode == MULTI_PLANE_MID_PAGE )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1515;
		}
		else	
		{
			// SAMSUNG, HYNIX, MICRON, INTEL, ST Maker TwoPlane Write Function
			if ( nDevInfo->Feature.MediaType & S_MCP )
			{
				if ( nWriteMode == MULTI_PLANE_LAST_PAGE )
					pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
				else if ( nWriteMode == MULTI_PLANE_MID_PAGE )
					pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1515;
			}
			else
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
		}
	}
	else // normal page
	{
		/* Command Page Program #2 [ 0x10 ] */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void 	NAND_IO_IRQ_WritePagePostProcess( void );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void 	NAND_IO_IRQ_WritePagePostProcess( void )
{
	NAND_IO_DisableChipSelect();
	NAND_IO_PostProcess();
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void 	NAND_IO_IRQ_Write512DataPreProcess( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void 	NAND_IO_IRQ_Write512DataPreProcess( NAND_IO_DEVINFO *nDevInfo )
{ 
	//==========================================================
	//
	// ECC Encode Setup
	//
	//==========================================================
	pIOBUSCFG_T->STORAGE = HwIOBUSCFG_STORAGE_NFC;
	pECC->ECC_BASE	 = (unsigned int)&NAND_IO_HwLDATA_PA;

	pECC->ECC_MASK	= 0x00000000;				/* Address mask for ECC area */

	if ( nDevInfo->EccType == SLC_ECC_TYPE )
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_SLCEN;
	else if (nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL4EN;
	else if (nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL8EN;
	else if (nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL12EN;
	else if (nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
		pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL16EN;

	pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
	pECC->ECC_CLEAR	= 0x00000000;	
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      NAND_IO_ERROR 	NAND_IO_IRQ_Write512DataPostProcess( NAND_IO_DEVINFO *nDevInfo, U8* nECCBuffer );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nECCBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
NAND_IO_ERROR 	NAND_IO_IRQ_Write512DataPostProcess( NAND_IO_DEVINFO *nDevInfo, U8* nECCBuffer )
{ 
	unsigned int		i;
	#ifdef _LINUX_
	unsigned char		nTempBuffer[30]__attribute__((aligned(8)));
	#else
	unsigned char		nTempBuffer[30];
	#endif
	unsigned char		*pSpare, *pEccB;
	NAND_IO_ERROR		res = (NAND_IO_ERROR)SUCCESS;

	//============================
	// Get ECC Code
	//============================
	if ( pNFC->NFC_CTRL1 & Hw30 )
		BITSET( pNFC->NFC_CTRL1, Hw31 );

	/*	Load ECC code from ECC block */
	if ( nDevInfo->Feature.MediaType  & A_MLC_16BIT )
	{
		pSpare = (unsigned char*)nECCBuffer;
		pEccB  = (unsigned char*)nTempBuffer;
		res = NAND_IO_EncodeECC( nDevInfo->EccType, pEccB );
		for ( i = 0; i < nDevInfo->EccDataSize; ++i )
			pSpare[i] = pEccB[i];
	}
	else
	{
		res = NAND_IO_EncodeECC( nDevInfo->EccType, nECCBuffer );
	}

	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline void NAND_IO_IRQ_Mask( void );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
static __inline void NAND_IO_IRQ_Mask( void )
{
	#ifdef __USE_NAND_ISR__
	unsigned int	irq = NAND_IRQ_NFC;
    if (irq < 32){
		BITCLR(pPIC->IEN0, (1 << irq));
        BITCLR(pPIC->INTMSK0,   (1 << irq));
    } else {
  		BITCLR(pPIC->IEN1, (1 << (irq - 32)));
        BITCLR(pPIC->INTMSK1,   (1 << (irq - 32)));
    }
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline void NAND_IO_IRQ_UnMask( void );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
static __inline void NAND_IO_IRQ_UnMask( void )
{
	#ifdef __USE_NAND_ISR__
	unsigned int	irq = NAND_IRQ_NFC;

	pNFC->NFC_IREQ		= 0x77;	// HwNFC_IREQ_FLAG1;
    if (irq < 32) {
        BITSET(pPIC->INTMSK0,   (1 << irq));
        BITSET(pPIC->CLR0,      (1 << irq));
		BITSET(pPIC->IEN0, 		(1 << irq));
    } else {
        BITSET(pPIC->INTMSK1,   (1 << (irq - 32)));
        BITSET(pPIC->CLR1,      (1 << (irq - 32)));
		BITSET(pPIC->IEN1, 		(1 << (irq - 32)));
    }
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      NAND_IO_ERROR NAND_IO_IRQ_ExtInterruptSet(unsigned int irq);
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			irq	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
NAND_IO_ERROR NAND_IO_IRQ_ExtInterruptSet(unsigned int irq)
{
	unsigned int	RegNum;
	unsigned char	nSource;
	NAND_IO_ERROR	res = (NAND_IO_ERROR)SUCCESS;

	#if defined(TCC_NAND_RDY_B31)
	nSource = 0x31;		// GPIO_B31
	#else
	nSource = 0x2E; 	// GPIO_B28
	#endif

	if (( irq < 15 ) && ( irq > 2 ))
	{
		RegNum = (( irq - 3 ) >> 2 );
		switch(RegNum)
		{
			case 0:
				BITCLR(pGPIO->EINTSEL0, 0x3F 	<< ( ( irq - 3 ) << 3 ));
				BITSET(pGPIO->EINTSEL0, nSource << ( ( irq - 3 ) << 3 ));
				break;

			case 1:
				BITCLR(pGPIO->EINTSEL1, 0x3F 	<< ( ( irq - 7 ) << 3 ));
				BITSET(pGPIO->EINTSEL1, nSource << ( ( irq - 7 ) << 3 ));
				break;

			case 2:
				BITCLR(pGPIO->EINTSEL2, 0x3F 	<< ( ( irq - 11 ) << 3 ));
				BITSET(pGPIO->EINTSEL2, nSource << ( ( irq - 11 ) << 3 ));
				break;
		}

		res = SUCCESS;
	}
	else
	{
		res = ERR_NAND_IO_WRONG_PARAMETER;		
	}

	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      NAND_IO_ERROR NAND_IO_IRQ_ExtInterruptClear(unsigned int irq);
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			irq	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
NAND_IO_ERROR NAND_IO_IRQ_ExtInterruptClear(unsigned int irq)
{
	unsigned int	RegNum;
	unsigned char	nSource;
	NAND_IO_ERROR	res = (NAND_IO_ERROR)SUCCESS;

	#if defined(TCC_NAND_RDY_B31)
	nSource = 0x31;		// GPIO_B31
	#else
	nSource = 0x2E; 	// GPIO_B28
	#endif

	if (( irq < 15 ) && ( irq > 2 ))
	{
		RegNum = (( irq - 3 ) >> 2 );
		switch(RegNum)
		{
			case 0:
				BITCLR(pGPIO->EINTSEL0, 0x3F 	<< ( ( irq - 3 ) << 3 ));
				break;

			case 1:
				BITCLR(pGPIO->EINTSEL1, 0x3F 	<< ( ( irq - 7 ) << 3 ));
				break;

			case 2:
				BITCLR(pGPIO->EINTSEL2, 0x3F 	<< ( ( irq - 11 ) << 3 ));
				break;
		}
		
        BITSET(pPIC->CLR0, (1 << irq));
		res = SUCCESS;
	}
	else
	{
		res = ERR_NAND_IO_WRONG_PARAMETER;		
	}

	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_IO_IRQ_ReadyBusySet( void );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_IO_IRQ_ReadyBusySet( void )
{
	pIOBUSCFG_T->STORAGE = HwIOBUSCFG_STORAGE_NFC;
	pECC->ECC_BASE		 = (unsigned int)&NAND_IO_HwLDATA_PA;

	#if defined(TCC_NAND_RDY_B28)
	// Externel intr GPIOB_28 config
	pGPIO->GPBFN3 &= ~0x00010000;		// GPIO_B28 --> Normal GPIO
	BITCLR(pGPIO->GPBEN, Hw28);			// Input Mode
    BITSET(pPIC->SEL0, (1 << NAND_IRQ_READY));			// Interrupt Select --> IRQ
	#endif

    BITCLR(pPIC->IEN0, (1 << NAND_IRQ_READY));			// Interrupt Disable	
    BITSET(pPIC->CLR0, (1 << NAND_IRQ_READY));			// Interrupt Status Clear

	NAND_IO_IRQ_ExtInterruptSet(NAND_IRQ_READY);

    BITSET(pPIC->MODE0, (1 << NAND_IRQ_READY));			// Set: Level-triggered, Cler: Edge-triggered
    BITCLR(pPIC->POL0,  (1 << NAND_IRQ_READY));			// Interrupt Set Active-High
    BITSET(pPIC->CLR0,  (1 << NAND_IRQ_READY));			// Interrupt Status Clear
    BITSET(pPIC->IEN0,  (1 << NAND_IRQ_READY));			// Interrupt Enable	
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_IO_IRQ_ReadyBusyClear( void );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_IO_IRQ_ReadyBusyClear( void )
{
    BITSET(pPIC->CLR0, (1 << NAND_IRQ_READY));			// Interrupt Status Clear
	NAND_IO_IRQ_ExtInterruptClear(NAND_IRQ_READY);
    BITCLR(pPIC->IEN0, (1 << NAND_IRQ_READY));			// Interrupt Disable

	#if defined(TCC_NAND_RDY_B31)
	pGPIO->GPBFN3 &= ~0x10000000;		// ND_RDY: GPIO_B31			
	BITCLR(pGPIO->GPBEN, Hw31);
	#else	
	pGPIO->GPBFN3 |= 0x00010000;		// GPIO_B28 --> EDI
	#endif	
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_IO_IRQ_SetupDMA( void *pDST, int nMode );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nMode	= 
*			pDST	= 
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_IO_IRQ_SetupDMA( void *pDST, int nMode )
{
	unsigned int	nSourceAddr, nDestAddr;
	unsigned		uCHCTRL;
	unsigned int	uTmp;	
	unsigned int	uSrcInc, uSrcMask;
	unsigned int	uDstInc, uDstMask;

	if ( nMode == NAND_IO_DMA_WRITE )
	{
		uSrcInc 	= 4;
		uSrcMask 	= 0;
		uDstInc		= 0;
		uDstMask 	= 0;
	}
	else
	{
		uSrcInc 	= 0;
		uSrcMask 	= 0;
		uDstInc		= 4;
		uDstMask 	= 0;
	}

	if ( nMode == NAND_IO_DMA_WRITE )
	{
		BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );
		// Target Physical Address- for DMA H/W Control Set
		nSourceAddr	= (unsigned int)pDST;
		nDestAddr 	= (unsigned int)&NAND_IO_HwLDATA_PA;

		//============================================================
		// DMA Control Register Set
		//============================================================
		uCHCTRL =	
	//				HwCHCTRL_SYNC_ON		|
	//				HwCHCTRL_HRD_W			|
					HwCHCTRL_BST_BURST		|
					HwCHCTRL_TYPE_SINGL		|
				   	HwCHCTRL_HRD_WR			|
	//				HwCHCTRL_BST_BURST		|
					HwCHCTRL_BSIZE_8		|
					HwCHCTRL_WSIZE_32		|
					HwCHCTRL_FLAG			|
					HwCHCTRL_EN_ON			|
					0;
	}
	else
	{
		// pSRC: NFC_LDATA
		// pDST: Buffer Address
		
		BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );
		
		nSourceAddr	= (unsigned int)&NAND_IO_HwLDATA_PA;
		nDestAddr 	= (unsigned int)pDST;

		//============================================================
		// DMA Control Register Set
		//============================================================
		uCHCTRL =	
	//				HwCHCTRL_SYNC_ON		|
	//				HwCHCTRL_HRD_W			|
					HwCHCTRL_BST_BURST		|
					HwCHCTRL_TYPE_SINGL		|
				   	HwCHCTRL_HRD_RD			|
	//				HwCHCTRL_BST_BURST		|
					HwCHCTRL_BSIZE_8		|
					HwCHCTRL_WSIZE_32		|
					HwCHCTRL_FLAG			|
					HwCHCTRL_EN_ON			|
					0;
	}
	
	//============================================================
	// Set Source Address & Source Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_SADR 	= nSourceAddr;
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->SPARAM[0] = (uSrcInc | (uSrcMask << 4));
	#else
	pNAND_DMA->SPARAM	 = (uSrcInc | (uSrcMask << 4));
	#endif
	//============================================================
	// Set Dest Address & Dest Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_DADR 	= nDestAddr;  
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->DPARAM[0] = (uDstInc | (uDstMask << 4));
	#else
	pNAND_DMA->DPARAM	 = (uDstInc | (uDstMask << 4));
	#endif
	//============================================================
	// Calculate byte size per 1 Hop transfer
	//============================================================
	uTmp	= (uCHCTRL & (Hw5+Hw4)) >> 4;			// calc log2(word size)
	uTmp	= uTmp + ( (uCHCTRL & (Hw7+Hw6)) >> 6);	// calc log2(word * burst size)

	//============================================================
	// Set External DMA Request Register
	//============================================================
	pNAND_DMA->EXTREQ = Hw18;		// NFC

	//============================================================
	// Set Hcount
	//============================================================
	pNAND_DMA->HCOUNT	= 0x10;
	
	//============================================================
	// Set & Enable DMA
	//============================================================
	pNAND_DMA->CHCTRL	= uCHCTRL;

	//============================================================
	// Set NFC DSize & IREQ Clear
	//============================================================
	pNFC->NFC_DSIZE		= 512;
	pNFC->NFC_IREQ		= 0x77;	// HwNFC_IREQ_FLAG1;

	//============================================================
	// DMA Transfer Start
	//============================================================
	#ifdef NAND_GPIO_DEBUG
	BITSET(pGPIO->GPFDAT, Hw21);
	#endif	
	if ( nMode == NAND_IO_DMA_WRITE )
	{
		if ( pNFC->NFC_CTRL1 & Hw31 )
			BITCLR( pNFC->NFC_CTRL1, Hw31 );

		pNFC->NFC_PSTART	= 0;
}
	else
		pNFC->NFC_RSTART	= 0;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_IO_IRQ_SetupDMAForSpare( int nDSize );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDSize	= 
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_IO_IRQ_SetupDMAForSpare( int nDSize )
{
	#if defined(USE_V_ADDRESS) && defined(_LINUX_)
	unsigned int	uTmp;
	unsigned int	*pDMA_PhyBuffer;
	unsigned int	nSourceAddr, nDestAddr;
	unsigned		uCHCTRL;

	pDMA_PhyBuffer 	= (unsigned int*)gNAND_IO_ShareEccBuffer_w;			// Working Address

	BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );

	#if defined(_WINCE_) || defined(_LINUX_)
	nSourceAddr = (unsigned int)&NAND_IO_HwLDATA_PA;				// NFC_LDATA Physical Address: ex_TCC89,92XX: 0XF050b0020
	#else
	nSourceAddr = (unsigned int)&pNFC->NFC_LDATA;
	#endif
	nDestAddr 	= (unsigned int)pDMA_PhyBuffer;

	//============================================================
	// DMA Control Register Set
	//============================================================
	uCHCTRL =	
//				HwCHCTRL_SYNC_ON		|
//				HwCHCTRL_HRD_W			|
				HwCHCTRL_BST_BURST		|
				HwCHCTRL_TYPE_SINGL		|
			   	HwCHCTRL_HRD_RD			|
//				HwCHCTRL_BST_BURST		|
				HwCHCTRL_BSIZE_8		|
				HwCHCTRL_WSIZE_32		|
				HwCHCTRL_FLAG			|
				HwCHCTRL_EN_ON			|
				0;

	//============================================================
	// Set Source Address & Source Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_SADR 	= nSourceAddr;
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->SPARAM[0] = 0;
	#else
	pNAND_DMA->SPARAM	 = 0;
	#endif
	//============================================================
	// Set Dest Address & Dest Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_DADR 	= nDestAddr;  
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->DPARAM[0] = 0x4;
	#else
	pNAND_DMA->DPARAM	 = 0x4;
	#endif
	//============================================================
	// Calculate byte size per 1 Hop transfer
	//============================================================
	uTmp	= (uCHCTRL & (Hw5+Hw4)) >> 4;			// calc log2(word size)
	uTmp	= uTmp + ( (uCHCTRL & (Hw7+Hw6)) >> 6);	// calc log2(word * burst size)

	//============================================================
	// Set External DMA Request Register
	//============================================================
	pNAND_DMA->EXTREQ = Hw18;		// NFC

	//============================================================
	// Set Hcount
	//============================================================
	if (uTmp)
		pNAND_DMA->HCOUNT	= (nDSize  + (1 << uTmp) - 1) >> uTmp;
	else
		pNAND_DMA->HCOUNT	= nDSize;

	//============================================================
	// Set & Enable DMA
	//============================================================
	pNAND_DMA->CHCTRL		= uCHCTRL;

	//============================================================
	// Set NFC DSize & IREQ Clear
	//============================================================
	pNFC->NFC_DSIZE		= nDSize ;
	pNFC->NFC_IREQ		= 0x77;	// HwNFC_IREQ_FLAG1;

	//============================================================
	// DMA Transfer Start
	//============================================================
	#ifdef NAND_GPIO_DEBUG
	BITSET(pGPIO->GPFDAT, Hw21);
	#endif
	pNFC->NFC_RSTART	= 0;
#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_ReadStatus( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_ReadStatus( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int		uStatus;
	unsigned int		uCheckBit;
	unsigned long int	timeout;
	NAND_IO_ERROR		res;	
	
	//================================
	//	Command READ STATUS [ 0x70 ]
	//================================
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7070;

	// Delay : more than 200nS
   	NAND_IO_Delay();
	
	//=============================================
	// DATA BUS WIDTH Setting
	//=============================================
	if ( nDevInfo->Feature.MediaType & A_PARALLEL )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//================================
	//	Read IO Status
	//================================
 	timeout = 0xFFFFF;
 	while ( timeout )
 	{
		uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
		uCheckBit	= nDevInfo->CmdMask & 0x4040;
			
		/* Check if it is ready */
		if ( ( uStatus & uCheckBit ) == uCheckBit )
			break;
	}

	if ( !timeout )
		return ERR_NAND_IO_TIME_OUT_READ_STATUS;

	//================================
	//	Check Bit Status
	//================================
	uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
	uCheckBit	= nDevInfo->CmdMask & 0x0101;

	res = (NAND_IO_ERROR)SUCCESS;
	
	if ( uStatus & uCheckBit )
	{
		if ( nDevInfo->Feature.MediaType & A_PARALLEL )
		{
			if (uStatus & ( uCheckBit & 0x0100 ) )
				res |= NAND_IO_STATUS_FAIL_CS1_PARALLEL;

			if (uStatus & ( uCheckBit & 0x0001 ) )
				res |= NAND_IO_STATUS_FAIL_CS0_PARALLEL;
		}
		else
		{
			if (uStatus & uCheckBit )
				res |= NAND_IO_STATUS_FAIL_CS0_SERIAL;
		}
	}
	
 	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_ReadStatusForMultiPlane( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_ReadStatusForMultiPlane( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int		uStatus;
	unsigned int		uCheckBit;
	unsigned long int	timeout;
	NAND_IO_ERROR		res;	
	
	//================================
	//	Command READ STATUS [ 0x70 ]
	//================================
	if ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7070;
	else if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7171;
	else if ( ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ) )
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7070;
	else
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7070;

	// Delay : more than 200nS
   	NAND_IO_Delay();
	
	//=============================================
	// DATA BUS WIDTH Setting
	//=============================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//================================
	//	Read IO Status
	//================================
 	timeout = 0xFFFFF;
 	while ( timeout )
 	{
		/* Micron MultiPlane ReadBusy Check 0x40*/
		uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
		uCheckBit = nDevInfo->CmdMask & 0x4040;

		/* Check if it is ready */
		if ( ( uStatus & uCheckBit ) == uCheckBit )
			break;
	}

	if ( !timeout )
		return ERR_NAND_IO_TIME_OUT_READ_STATUS;

	//================================
	//	Check Bit Status
	//================================
	if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID )
	{
		uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
		uCheckBit	= nDevInfo->CmdMask & 0x0101;

		res = (NAND_IO_ERROR)SUCCESS;

		if ( uStatus & uCheckBit )
		{
			if ( uStatus & ( nDevInfo->CmdMask & 0x0202 ))
				res = (NAND_IO_ERROR)NAND_IO_DISTRICT_0;
			else if ( uStatus & ( nDevInfo->CmdMask & 0x0404 ))
				res = (NAND_IO_ERROR)NAND_IO_DISTRICT_1;
		}
	}
	else
	{
	    uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
	    uCheckBit	= nDevInfo->CmdMask & 0x0101;
    
	    res = (NAND_IO_ERROR)SUCCESS;
	    
	    if ( uStatus & uCheckBit )
	    {
		    if ( nDevInfo->Feature.MediaType & A_PARALLEL )
		    {
			    if (uStatus & ( uCheckBit & 0x0100 ) )
				    res |= NAND_IO_STATUS_FAIL_CS1_PARALLEL;
    
			    if (uStatus & ( uCheckBit & 0x0001 ) )
				    res |= NAND_IO_STATUS_FAIL_CS0_PARALLEL;
		    }
		    else
		    {
			    if (uStatus & uCheckBit )
				    res |= NAND_IO_STATUS_FAIL_CS0_SERIAL;
		    }
	    }
	}
	
 	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_ReadStatusForCacheProgram( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_ReadStatusForCacheProgram( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int		uStatus;
	unsigned int		uCheckBit;
	unsigned long int	timeout;
	NAND_IO_ERROR		res;	
	
	//================================
	//	Command READ STATUS [ 0x70 ]
	//================================
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7070;
	
	// Delay : more than 200nS
   	NAND_IO_Delay();	

	//=============================================
	// DATA BUS WIDTH Setting
	//=============================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//================================
	//	Read IO Status
	//================================
 	timeout = 0xFFFFF;
 	while ( timeout )
 	{
		uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
		
		if ( ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID )  )
			uCheckBit = nDevInfo->CmdMask & 0x2020;
		else
			uCheckBit = nDevInfo->CmdMask & 0x4040;
		
		/* Check if it is ready */
		if ( ( uStatus & uCheckBit ) == uCheckBit )
			break;
	}

	if ( !timeout )
		return ERR_NAND_IO_TIME_OUT_READ_STATUS;

	//================================
	//	Check Bit Status
	//================================
	uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
	uCheckBit	= nDevInfo->CmdMask & 0x0303;

	res = (NAND_IO_ERROR)SUCCESS;
	
	if ( uStatus & uCheckBit )
	{
		if ( nDevInfo->Feature.MediaType & A_PARALLEL )
		{
			if (uStatus & ( uCheckBit & 0x0300 ) )
				res |= NAND_IO_STATUS_FAIL_CS1_PARALLEL;

			if (uStatus & ( uCheckBit & 0x0003 ) )
				res |= NAND_IO_STATUS_FAIL_CS0_PARALLEL;
		}
		else
		{
			if (uStatus & uCheckBit )
				res |= NAND_IO_STATUS_FAIL_CS0_SERIAL;
		}
	}
	
 	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_ReadStatusForInterleave( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*			nPageAddr	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_ReadStatusForInterleave( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr )
{
	unsigned int		uStatus;
	unsigned int		uCheckBit;
	unsigned int		ChipNum;
	unsigned long int	timeout;
	NAND_IO_ERROR		res;	

	// Delay : more than 200nS
   	NAND_IO_Delay();

	//=============================================
	// DATA BUS WIDTH Setting
	//=============================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//================================
	//	Command READ STATUS
	//================================
	if ( nPageAddr < (U32)( ( nDevInfo->Feature.PBpV >> 1 ) * nDevInfo->Feature.PpB ) )
	{
		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP1 )
		{
			if ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF1F1;
			else if ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF2F2;					
			else if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7171;
			else if ( ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ) )
			{
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7878;	
				NAND_IO_WriteBlockPageAddr( gInterLeaveDie0BlockAddr, nDevInfo );
			}
			
			ChipNum = NAND_IO_STATUS_INTERLEAVING_CHIP1;
		}
		else
			return (NAND_IO_ERROR)SUCCESS;
	}
	else
	{
		if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP2 )
		{
			if ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF2F2;
			else if ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF3F3;			
			else if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID )
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7171;	
			else if ( ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ) )
			{
				pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7878;
				NAND_IO_WriteBlockPageAddr( gInterLeaveDie1BlockAddr, nDevInfo );
			}
			ChipNum = NAND_IO_STATUS_INTERLEAVING_CHIP2;
		}
		else
			return (NAND_IO_ERROR)SUCCESS;
	}

	//================================
	//	Read IO Status
	//================================
 	timeout = 0xFFFFF;
 	while ( timeout )
 	{
		if ( ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID ) 	|| 
			 ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID )	 	||
			 ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID )		||
			 ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID ) )
		{
			uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
			uCheckBit = nDevInfo->CmdMask & 0x4040;
		
			/* Check if it is ready */
			if ( ( uStatus & uCheckBit ) == uCheckBit )
			{
				uCheckBit	= nDevInfo->CmdMask & 0x0101;

				/* Check if it is Fail */
				if ( uStatus & uCheckBit )
				{
					if ( ChipNum == NAND_IO_STATUS_INTERLEAVING_CHIP1 )
					{
						if ( ( nDevInfo->Feature.MediaType & S_MP ) || ( nDevInfo->Feature.MediaType & S_MCP ) )
						{
							nDevInfo->BadBlockInfo.BlockStatus[0] = MULTI_PLANE_BAD_BLOCK;
							nDevInfo->BadBlockInfo.BlockStatus[1] = MULTI_PLANE_BAD_BLOCK;
						}
						else
							nDevInfo->BadBlockInfo.BlockStatus[nDevInfo->ChipNo] = MULTI_PLANE_BAD_BLOCK;
					}
					else if ( ChipNum == NAND_IO_STATUS_INTERLEAVING_CHIP2 )
					{
						if ( ( nDevInfo->Feature.MediaType & S_MP ) || ( nDevInfo->Feature.MediaType & S_MCP ) )
						{
							nDevInfo->BadBlockInfo.BlockStatus[2] = MULTI_PLANE_BAD_BLOCK;
							nDevInfo->BadBlockInfo.BlockStatus[3] = MULTI_PLANE_BAD_BLOCK;
						}
						else
							nDevInfo->BadBlockInfo.BlockStatus[nDevInfo->ChipNo] = MULTI_PLANE_BAD_BLOCK;
					}

					gInterLeaveWriteStatus = MULTI_PLANE_BAD_BLOCK;
				}
				break;
			}
		}
		else if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID )
		{
			uStatus	= nDevInfo->CmdMask & pNFC->NFC_SDATA;
			uCheckBit = nDevInfo->CmdMask & 0x4040;

			/* Check if it is ready */
			if ( ( uStatus & uCheckBit ) == uCheckBit )
			{
				uCheckBit	= nDevInfo->CmdMask & 0x0101;

				/* Check if it is Fail */
				if ( uStatus & uCheckBit )
				{
					if ( ChipNum == NAND_IO_STATUS_INTERLEAVING_CHIP1 )
					{
				       	if ( uStatus & ( nDevInfo->CmdMask & 0x0202 ))
					        nDevInfo->BadBlockInfo.BlockStatus[0] = MULTI_PLANE_BAD_BLOCK;
				        else if ( uStatus & ( nDevInfo->CmdMask & 0x0404 ))
					        nDevInfo->BadBlockInfo.BlockStatus[1] = MULTI_PLANE_BAD_BLOCK;
					}
					else if ( ChipNum == NAND_IO_STATUS_INTERLEAVING_CHIP2 )
					{
				        if ( uStatus & ( nDevInfo->CmdMask & 0x0202 ))
					        nDevInfo->BadBlockInfo.BlockStatus[2] = MULTI_PLANE_BAD_BLOCK;
				        else if ( uStatus & ( nDevInfo->CmdMask & 0x0404 ))
					        nDevInfo->BadBlockInfo.BlockStatus[3] = MULTI_PLANE_BAD_BLOCK;
			        }

					gInterLeaveWriteStatus = MULTI_PLANE_BAD_BLOCK;
				}
				break;
			}
		}
	}

	if ( !timeout )
		return ERR_NAND_IO_TIME_OUT_READ_STATUS;

	//================================
	//	SET NAND IO Status
	//================================
	switch(ChipNum)
	{
		case NAND_IO_STATUS_INTERLEAVING_CHIP1:
			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP1;
			break;

		case NAND_IO_STATUS_INTERLEAVING_CHIP2:
			gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP2;
			break;
	}

	res = (NAND_IO_ERROR)SUCCESS;

 	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_ReadStatusForInterleaveClear( NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_ReadStatusForInterleaveClear( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int		uStatus;
	unsigned int		uCheckBit;
	unsigned long int	timeout;
	NAND_IO_ERROR		res;

	// Delay : more than 200nS
   	NAND_IO_Delay();

	res = (NAND_IO_ERROR)SUCCESS;

	//=============================================
	// DATA BUS WIDTH Setting
	//=============================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=============================================
	//	Command READ STATUS - Interleave CHIP 1
	//=============================================
	if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP1 )
	{
		if ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF1F1;
		else if ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF2F2;		
		else if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7171;
		else if ( ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ) )
		{
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7878;
			NAND_IO_WriteBlockPageAddr( gInterLeaveDie0BlockAddr, nDevInfo );
		}
		
	 	timeout = 0xFFFFF;
	 	while ( timeout )
	 	{
			uStatus	  = nDevInfo->CmdMask & pNFC->NFC_SDATA;
			uCheckBit = nDevInfo->CmdMask & 0x4040;
			
			/* Check if it is ready */
			if ( ( uStatus & uCheckBit ) == uCheckBit )
			{
				uCheckBit	= nDevInfo->CmdMask & 0x0101;

				/* Check if it is Fail */
				if ( uStatus & uCheckBit )
				{
					if ( ( nDevInfo->Feature.MediaType & S_MP ) || ( nDevInfo->Feature.MediaType & S_MCP ) )
					{
						nDevInfo->BadBlockInfo.BlockStatus[0] = MULTI_PLANE_BAD_BLOCK;
						nDevInfo->BadBlockInfo.BlockStatus[1] = MULTI_PLANE_BAD_BLOCK;
					}
					else
						nDevInfo->BadBlockInfo.BlockStatus[nDevInfo->ChipNo] = MULTI_PLANE_BAD_BLOCK;

					gInterLeaveWriteStatus = MULTI_PLANE_BAD_BLOCK;
				}
				break;
			}
		}

		if ( !timeout )
			return ERR_NAND_IO_TIME_OUT_READ_STATUS;

		gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP1;
	}

	//=============================================
	//	Command READ STATUS - Interleave CHIP 2
	//=============================================
	if ( gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_CHIP2 )
	{
		if ( nDevInfo->Feature.DeviceID.Code[0] == SAMSUNG_NAND_MAKER_ID )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF2F2;
		else if ( nDevInfo->Feature.DeviceID.Code[0] == ST_NAND_MAKER_ID )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF3F3;		
		else if ( nDevInfo->Feature.DeviceID.Code[0] == TOSHIBA_NAND_MAKER_ID )
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7171;
		else if ( ( nDevInfo->Feature.DeviceID.Code[0] == MICRON_NAND_MAKER_ID ) || ( nDevInfo->Feature.DeviceID.Code[0] == INTEL_NAND_MAKER_ID ) )
		{
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7878;
			NAND_IO_WriteBlockPageAddr( gInterLeaveDie1BlockAddr, nDevInfo );
		}

	 	timeout = 0xFFFFF;
	 	while ( timeout )
	 	{
			uStatus		= nDevInfo->CmdMask & pNFC->NFC_SDATA;
			uCheckBit = nDevInfo->CmdMask & 0x4040;
			
			/* Check if it is ready */
			if ( ( uStatus & uCheckBit ) == uCheckBit )
			{
				uCheckBit	= nDevInfo->CmdMask & 0x0101;

				/* Check if it is Fail */
				if ( uStatus & uCheckBit )
				{
					if ( ( nDevInfo->Feature.MediaType & S_MP ) || ( nDevInfo->Feature.MediaType & S_MCP ) )
					{
						nDevInfo->BadBlockInfo.BlockStatus[2] = MULTI_PLANE_BAD_BLOCK;
						nDevInfo->BadBlockInfo.BlockStatus[3] = MULTI_PLANE_BAD_BLOCK;
					}
					else
						nDevInfo->BadBlockInfo.BlockStatus[nDevInfo->ChipNo] = MULTI_PLANE_BAD_BLOCK;

					gInterLeaveWriteStatus = MULTI_PLANE_BAD_BLOCK;
				}
				break;
			}
		}

		if ( !timeout )
			return ERR_NAND_IO_TIME_OUT_READ_STATUS;

		gInterLeaveIoStatus &= ~NAND_IO_STATUS_INTERLEAVING_CHIP2;
	}

	if ( !(gInterLeaveIoStatus & NAND_IO_STATUS_INTERLEAVING_MASK ))
		res = (NAND_IO_ERROR)SUCCESS;
	
 	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_GenerateRowColAddrForRead( U32 nPageAddr, U16 nColumnAddr,
*      										  				  		 U32* rRowAddr, U32* rColumnAddr,
*      														  		 NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nColumnAddr	= 
*			nDevInfo	= 
*			nPageAddr	= 
*			rColumnAddr	= 
*			rRowAddr	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_GenerateRowColAddrForRead( U32 nPageAddr, U16 nColumnAddr,
										  				  		 U32* rRowAddr, U32* rColumnAddr,
														  		 NAND_IO_DEVINFO *nDevInfo )
{
	unsigned long int	RowAddr;
	unsigned long int	ColumnAddr;
	
	if ( nColumnAddr > ( nDevInfo->Feature.PageSize + nDevInfo->Feature.SpareSize ) )
		return ERR_NAND_IO_WRONG_PARAMETER_ROW_COL_ADDRESS;

	//==================================================
	// Generate Column & Row Address	
	//==================================================
	if ( nDevInfo->Feature.MediaType & A_SMALL )
	{
		// ColumnAddr	ADR[7:0]	==> nColumnAddr
		// RowAddr		ADR[25:9]	==> (nPageAddr)*512
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )  ? (nColumnAddr>>1) : nColumnAddr;
		RowAddr		= nPageAddr;

		if ( nDevInfo->Feature.MediaType & A_08BIT )
		{
		    /* Command READ for SMALL NAND */
		    if ( ColumnAddr < 256 )
		    {
			    pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x0000;
			    ColumnAddr	= ColumnAddr;
		    }
		    else if ( ColumnAddr < 512 )
		    {
			    pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x0101;
			    ColumnAddr  = ColumnAddr-256;
		    }
		    else
		    {
			    pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x5050;
			    ColumnAddr	= ColumnAddr-512;
		    }
		}
		else if ( nDevInfo->Feature.MediaType & A_16BIT )
		{
			/* Command READ for SMALL NAND For 16Bit */
			if ( ColumnAddr < 256 )
			{
				pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x0000;
				ColumnAddr	= ColumnAddr;
			}
			else
			{
				pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x5050;
				ColumnAddr	= ColumnAddr;
			}
		}		
	}
	else
	{
		/* Command READ [ 0x00 ] */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;	

		// ColumnAddr   ADR[11:0]   ==> nColumnAddr
		// RowAddr      ADR[31:12]  ==> nPageAddr
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (nColumnAddr>>1) : nColumnAddr;
		RowAddr		= nPageAddr;

	}			

	*rRowAddr		= RowAddr;
	*rColumnAddr	= ColumnAddr;

	return (NAND_IO_ERROR)SUCCESS;
	
}	

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_GenerateRowColAddrForWrite( U32 nPageAddr, U16 nColumnAddr,
*      										  				  		  U32* rRowAddr, U32* rColumnAddr,
*      														  		  NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nColumnAddr	= 
*			nDevInfo	= 
*			nPageAddr	= 
*			rColumnAddr	= 
*			rRowAddr	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_GenerateRowColAddrForWrite( U32 nPageAddr, U16 nColumnAddr,
										  				  		  U32* rRowAddr, U32* rColumnAddr,
														  		  NAND_IO_DEVINFO *nDevInfo )
{
	unsigned long int	RowAddr;
	unsigned long int	ColumnAddr;
	
	if ( nColumnAddr > ( nDevInfo->Feature.PageSize + nDevInfo->Feature.SpareSize ) )
		return ERR_NAND_IO_WRONG_PARAMETER_ROW_COL_ADDRESS;

	//==================================================
	// Generate Column & Row Address	
	//==================================================
	if ( nDevInfo->Feature.MediaType & A_SMALL )
	{
		// ColumnAddr	ADR[7:0]	==> nColumnAddr
		// RowAddr		ADR[25:9]	==> (nPageAddr)*512
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )  ? (nColumnAddr>>1) : nColumnAddr;
		RowAddr		= nPageAddr;

		if ( nDevInfo->Feature.MediaType & A_08BIT )
		{
		    /* Command READ for SMALL NAND */
		    if ( ColumnAddr < 256 )
		    {
			    pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x0000;
			    ColumnAddr	= ColumnAddr;
		    }
		    else if ( ColumnAddr < 512 )
		    {
			    pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x0101;
			    ColumnAddr  = ColumnAddr-256;
		    }
		    else
		    {
			    pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x5050;
			    ColumnAddr	= ColumnAddr-512;
		    }
		}
		else if ( nDevInfo->Feature.MediaType & A_16BIT )
		{
			/* Command READ for SMALL NAND */
			if ( ColumnAddr < 256 )
			{
				pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x0000;
				ColumnAddr	= ColumnAddr;
			}
			else
			{
				pNFC->NFC_CMD	= nDevInfo->CmdMask & 0x5050;
				ColumnAddr	= ColumnAddr;
			}
		}	
	}
	else
	{
		// ColumnAddr   ADR[11:0]   ==> nColumnAddr
		// RowAddr      ADR[31:12]  ==> nPageAddr
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (nColumnAddr>>1) : nColumnAddr;
		RowAddr		= nPageAddr;
	}			

	*rRowAddr		= RowAddr;
	*rColumnAddr	= ColumnAddr;

	return (NAND_IO_ERROR)SUCCESS;
	
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_GenerateRowColAddrForCBandCP( U32 nPageAddr, U16 nColumnAddr,
*      										  				  			U32* rRowAddr, U32* rColumnAddr,
*      														  			NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nColumnAddr	= 
*			nDevInfo	= 
*			nPageAddr	= 
*			rColumnAddr	= 
*			rRowAddr	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_GenerateRowColAddrForCBandCP( U32 nPageAddr, U16 nColumnAddr,
										  				  			U32* rRowAddr, U32* rColumnAddr,
														  			NAND_IO_DEVINFO *nDevInfo )
{
	unsigned long int	RowAddr;
	unsigned long int	ColumnAddr;
	
	if ( nColumnAddr > 0 )
		return ERR_NAND_IO_WRONG_PARAMETER_ROW_COL_ADDRESS;

	//==================================================
	// Generate Column & Row Address	
	//==================================================
	if ( nDevInfo->Feature.MediaType & A_SMALL )
	{
		// ColumnAddr	ADR[7:0]	==> nColumnAddr
		// RowAddr		ADR[25:9]	==> (nPageAddr)*512
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )  ? (nColumnAddr>>1) : nColumnAddr;
		RowAddr		= nPageAddr;
		ColumnAddr	= ColumnAddr;
	}
	else
	{
		// ColumnAddr   ADR[11:0]   ==> nColumnAddr
		// RowAddr      ADR[31:12]  ==> nPageAddr
		ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (nColumnAddr>>1) : nColumnAddr;
		RowAddr		= nPageAddr;
	}			

	*rRowAddr		= RowAddr;
	*rColumnAddr	= ColumnAddr;

	return (NAND_IO_ERROR)SUCCESS;
	
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_WriteRowColAddr( U32 nRowAddr, U32 nColumnAddr, NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nColumnAddr	= 
*			nDevInfo	= 
*			nRowAddr	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_WriteRowColAddr( U32 nRowAddr, U32 nColumnAddr, NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int		nTempAddr;
	unsigned int		i;
	
	//==================================================
	// Write Column Address
	//==================================================
	for ( i = 0; i < nDevInfo->Feature.ColCycle; ++i )
	{
		nTempAddr = nDevInfo->CmdMask & (((nColumnAddr<<8)&0xFF00)|(nColumnAddr&0x00FF));
		pNFC->NFC_SADDR = nTempAddr;
		
		nColumnAddr = nColumnAddr >> 8;
	}

	//==================================================
	// Write Row Address
	//==================================================	
	nRowAddr = nRowAddr;

	for ( i = 0; i < nDevInfo->Feature.RowCycle; ++i )
	{
		nTempAddr = nDevInfo->CmdMask & (((nRowAddr<<8)&0xFF00)|(nRowAddr&0x00FF));
		pNFC->NFC_SADDR = nTempAddr;

		nRowAddr = nRowAddr >> 8;
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_WriteColAddr( U32 nColumnAddr, NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nColumnAddr	= 
*			nDevInfo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
void NAND_IO_WriteColAddr( U32 nColumnAddr, NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int		i;
	
	//==================================================
	// Write Column Address
	//==================================================
	for ( i = 0; i < nDevInfo->Feature.ColCycle; ++i )
	{
		pNFC->NFC_SADDR	= nDevInfo->CmdMask & (((nColumnAddr<<8)&0xFF00)|(nColumnAddr&0x00FF));
		nColumnAddr = nColumnAddr >> 8;
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_WriteBlockPageAddr( U32 nBlockPageAddr, NAND_IO_DEVINFO *nDevInfo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nBlockPageAddr	= 
*			nDevInfo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_WriteBlockPageAddr( U32 nBlockPageAddr, NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int		i;
	
	//==================================================
	// Write Block Address
	//==================================================
	for ( i = 0; i < nDevInfo->Feature.RowCycle; ++i )
	{
		pNFC->NFC_SADDR	= nDevInfo->CmdMask & (((nBlockPageAddr<<8)&0xFF00)|(nBlockPageAddr&0x00FF));
		nBlockPageAddr = nBlockPageAddr >> 8;
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline void NAND_IO_SetupDMA( void *pSRC, unsigned uSrcInc, unsigned uSrcMask, 
*      									   void *pDST, unsigned uDstInc, unsigned uDstMask, int nMode );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nMode	= 
*			pDST	= 
*			pSRC	= 
*			uDstInc	= 
*			uDstMask	= 
*			uSrcInc	= 
*			uSrcMask	= 
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
static __inline void NAND_IO_SetupDMA( void *pSRC, unsigned uSrcInc, unsigned uSrcMask, 
									   void *pDST, unsigned uDstInc, unsigned uDstMask, int nMode, int nDSize )
{
	unsigned int	*pDMA_PhyBuffer;
	unsigned int	*pDMA_WorkBuffer;
	unsigned int	nSourceAddr, nDestAddr;
	unsigned		uCHCTRL;
	unsigned int	uTmp;

	#if defined(_WINCE_)
	tSYSTEM_PARAM	*pSYS_Work_PARAM	= (tSYSTEM_PARAM*)(SYSTEM_PARAM_BASEADDRESS);
	#endif

	#if defined(_WINCE_)
	pDMA_PhyBuffer 	= (unsigned int*)pSYS_Work_PARAM->DMA2.CH0_BUFFER;	// Working Address
	pDMA_WorkBuffer = (unsigned int*)pSYS_PARAM->DMA2.CH0_BUFFER;		// Physical Address
	#elif defined(_LINUX_)
	#ifdef KERNEL_DRIVER
	pDMA_PhyBuffer 	= (unsigned int*)dma_t.dma_addr;	
	pDMA_WorkBuffer	= (unsigned int*)dma_t.v_addr;
	#else
	pDMA_PhyBuffer 	= (unsigned int*)DMA_ADDR;	
	pDMA_WorkBuffer	= (unsigned int*)DMA_ADDR;
	#endif
	#else		// NU
	pDMA_PhyBuffer = (unsigned int*)0x10003000;
	pDMA_WorkBuffer	= (unsigned int*)0x10003000;			
	#endif
	
	if ( nMode == NAND_IO_DMA_WRITE )
	{
		// pSRC: Buffer Address
		// pDST: NFC_LDATA

		BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );

		//pSRC --> pDMA_WorkBuffer
		memcpy( pDMA_WorkBuffer, pSRC, nDSize );

		// Target Physical Address- for DMA H/W Control Set
		nSourceAddr	= (unsigned int)pDMA_PhyBuffer;
		nDestAddr 	= (unsigned int)pDST;

		//============================================================
		// DMA Control Register Set
		//============================================================
		uCHCTRL =	
	//				HwCHCTRL_SYNC_ON		|
	//				HwCHCTRL_HRD_W			|
					HwCHCTRL_BST_BURST		|
					HwCHCTRL_TYPE_SINGL		|
				   	HwCHCTRL_HRD_WR			|
	//				HwCHCTRL_BST_BURST		|
					HwCHCTRL_BSIZE_8		|
					HwCHCTRL_WSIZE_32		|
					HwCHCTRL_FLAG			|
					HwCHCTRL_EN_ON			|
					0;

	}
	else	// NAND_IO_DMA_READ
	{	
		// pSRC: NFC_LDATA
		// pDST: Buffer Address

		BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );

		nSourceAddr = (unsigned int)pSRC;				// NFC_LDATA Physical Address: ex_TCC89,92XX: 0XF050b0020
		nDestAddr 	= (unsigned int)pDMA_PhyBuffer;

//		ND_TRACE("\npDMA_WorkBuffer_Addr:0x%08X / 0x%08X", pDMA_PhyBuffer, pDMA_WorkBuffer );

		//============================================================
		// DMA Control Register Set
		//============================================================
		uCHCTRL =	
	//				HwCHCTRL_SYNC_ON		|
	//				HwCHCTRL_HRD_W			|
					HwCHCTRL_BST_BURST		|
					HwCHCTRL_TYPE_SINGL		|
				   	HwCHCTRL_HRD_RD			|
	//				HwCHCTRL_BST_BURST		|
					HwCHCTRL_BSIZE_8		|
					HwCHCTRL_WSIZE_32		|
					HwCHCTRL_FLAG			|
					HwCHCTRL_EN_ON			|
					0;
	}

	//============================================================
	// Set Source Address & Source Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_SADR 	= nSourceAddr;
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->SPARAM[0] = (uSrcInc | (uSrcMask << 4));
	#else
	pNAND_DMA->SPARAM	 = (uSrcInc | (uSrcMask << 4));
	#endif
	//============================================================
	// Set Dest Address & Dest Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_DADR 	= nDestAddr;  
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->DPARAM[0] = (uDstInc | (uDstMask << 4));
	#else
	pNAND_DMA->DPARAM	 = (uDstInc | (uDstMask << 4));
	#endif
	//============================================================
	// Calculate byte size per 1 Hop transfer
	//============================================================
	uTmp	= (uCHCTRL & (Hw5+Hw4)) >> 4;			// calc log2(word size)
	uTmp	= uTmp + ( (uCHCTRL & (Hw7+Hw6)) >> 6);	// calc log2(word * burst size)

	//============================================================
	// Set External DMA Request Register
	//============================================================
	pNAND_DMA->EXTREQ = Hw18;		// NFC

	//============================================================
	// Set Hcount
	//============================================================
	if (uTmp)
		pNAND_DMA->HCOUNT	= (nDSize + (1 << uTmp) - 1) >> uTmp;
	else
		pNAND_DMA->HCOUNT	= nDSize;

	//============================================================
	// Set & Enable DMA
	//============================================================
	pNAND_DMA->CHCTRL		= uCHCTRL;

	//============================================================
	// Set NFC DSize & IREQ Clear
	//============================================================
	pNFC->NFC_DSIZE		= nDSize;
	pNFC->NFC_IREQ		= 0x77;	// HwNFC_IREQ_FLAG1;

	//============================================================
	// DMA Transfer Start
	//============================================================
	if ( nMode == NAND_IO_DMA_WRITE )
	{
		if ( pNFC->NFC_CTRL1 & Hw31 )
			BITCLR( pNFC->NFC_CTRL1, Hw31 );

		NAND_IO_IRQ_Mask();

		pNFC->NFC_PSTART	= 0;
		while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
		
		NAND_IO_IRQ_UnMask();

		if ( pNFC->NFC_CTRL1 & Hw30 )
			BITSET( pNFC->NFC_CTRL1, Hw31 );
	}
	else
	{
		NAND_IO_IRQ_Mask();
		
		pNFC->NFC_RSTART	= 0;
		while ( ISZERO(pNFC->NFC_IREQ, HwNFC_IREQ_FLAG0) );
		
		NAND_IO_IRQ_UnMask();

		memcpy( pDST, pDMA_WorkBuffer, nDSize );
	}
}

static __inline void NAND_IO_SetupDMA_kernel( void *pSRC, unsigned uSrcInc, unsigned uSrcMask, 
										   void *pDST, unsigned uDstInc, unsigned uDstMask, int nMode, int nDSize )
{
	unsigned int	*pDMA_PhyBuffer;
	unsigned int	*pDMA_WorkBuffer;
	unsigned int	nSourceAddr, nDestAddr;
	unsigned		uCHCTRL;
	unsigned int	uTmp;

	#if defined(_WINCE_)
	tSYSTEM_PARAM	*pSYS_Work_PARAM	= (tSYSTEM_PARAM*)(SYSTEM_PARAM_BASEADDRESS);
	#endif

	#if defined(_WINCE_)
	pDMA_PhyBuffer 	= (unsigned int*)pSYS_Work_PARAM->DMA2.CH0_BUFFER;	// Working Address
	pDMA_WorkBuffer = (unsigned int*)pSYS_PARAM->DMA2.CH0_BUFFER;		// Physical Address
	#elif defined(_LINUX_)
	#ifdef KERNEL_DRIVER
	pDMA_PhyBuffer 	= (unsigned int*)dma_t.dma_addr;	
	pDMA_WorkBuffer	= (unsigned int*)dma_t.v_addr;
	#else
	pDMA_PhyBuffer 	= (unsigned int*)DMA_ADDR;	
	pDMA_WorkBuffer	= (unsigned int*)DMA_ADDR;
	#endif
	#else		// NU
	pDMA_PhyBuffer 	= (unsigned int*)0x10003000;
	pDMA_WorkBuffer	= (unsigned int*)0x10003000;			
	#endif
	
	if ( nMode == NAND_IO_DMA_WRITE )
	{
		// pSRC: Buffer Address
		// pDST: NFC_LDATA

		BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );

		//pSRC --> pDMA_WorkBuffer
		memcpy( pDMA_WorkBuffer, pSRC, nDSize );

		// Target Physical Address- for DMA H/W Control Set
		nSourceAddr	= (unsigned int)pDMA_PhyBuffer;
		nDestAddr 	= (unsigned int)pDST;

		//============================================================
		// DMA Control Register Set
		//============================================================
		uCHCTRL =	
	//				HwCHCTRL_SYNC_ON		|
	//				HwCHCTRL_HRD_W			|
					HwCHCTRL_BST_BURST		|
					HwCHCTRL_TYPE_SINGL		|
				   	HwCHCTRL_HRD_WR			|
	//				HwCHCTRL_BST_BURST		|
					HwCHCTRL_BSIZE_8		|
					HwCHCTRL_WSIZE_32		|
					HwCHCTRL_FLAG			|
					HwCHCTRL_EN_ON			|
					0;

	}
	else	// NAND_IO_DMA_READ
	{	
		// pSRC: NFC_LDATA
		// pDST: Buffer Address

		BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );

		nSourceAddr = (unsigned int)pSRC;				// NFC_LDATA Physical Address: ex_TCC89,92XX: 0XF050b0020
//		nDestAddr 	= (unsigned int)pDMA_PhyBuffer;
		nDestAddr 	= (unsigned int)pDST;

		//============================================================
		// DMA Control Register Set
		//============================================================
		uCHCTRL =	
	//				HwCHCTRL_SYNC_ON		|
	//				HwCHCTRL_HRD_W			|
					HwCHCTRL_BST_BURST		|
					HwCHCTRL_TYPE_SINGL		|
				   	HwCHCTRL_HRD_RD			|
	//				HwCHCTRL_BST_BURST		|
					HwCHCTRL_BSIZE_8		|
					HwCHCTRL_WSIZE_32		|
					HwCHCTRL_FLAG			|
					HwCHCTRL_EN_ON			|
					0;
	}

	//============================================================
	// Set Source Address & Source Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_SADR 	= nSourceAddr;
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->SPARAM[0] = (uSrcInc | (uSrcMask << 4));
	#else
	pNAND_DMA->SPARAM	 = (uSrcInc | (uSrcMask << 4));
	#endif

	//============================================================
	// Set Dest Address & Dest Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_DADR 	= nDestAddr;  
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->DPARAM[0] = (uDstInc | (uDstMask << 4));
	#else
	pNAND_DMA->DPARAM	 = (uDstInc | (uDstMask << 4));
	#endif

	//============================================================
	// Calculate byte size per 1 Hop transfer
	//============================================================
	uTmp	= (uCHCTRL & (Hw5+Hw4)) >> 4;			// calc log2(word size)
	uTmp	= uTmp + ( (uCHCTRL & (Hw7+Hw6)) >> 6);	// calc log2(word * burst size)

	//============================================================
	// Set External DMA Request Register
	//============================================================
	pNAND_DMA->EXTREQ = Hw18;		// NFC

	//============================================================
	// Set Hcount
	//============================================================
	if (uTmp)
		pNAND_DMA->HCOUNT	= (nDSize + (1 << uTmp) - 1) >> uTmp;
	else
		pNAND_DMA->HCOUNT	= nDSize;

	//============================================================
	// Set & Enable DMA
	//============================================================
	pNAND_DMA->CHCTRL		= uCHCTRL;

	//============================================================
	// Set NFC DSize & IREQ Clear
	//============================================================
	pNFC->NFC_DSIZE		= nDSize;
	pNFC->NFC_IREQ		= 0x77;	// HwNFC_IREQ_FLAG1;

	//============================================================
	// DMA Transfer Start
	//============================================================
	if ( nMode == NAND_IO_DMA_WRITE )
	{
		if ( pNFC->NFC_CTRL1 & Hw31 )
			BITCLR( pNFC->NFC_CTRL1, Hw31 );

		NAND_IO_IRQ_Mask();
	
		pNFC->NFC_PSTART	= 0;
		while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));

		NAND_IO_IRQ_UnMask();
		
		if ( pNFC->NFC_CTRL1 & Hw30 )
			BITSET( pNFC->NFC_CTRL1, Hw31 );
	}
	else
	{
		NAND_IO_IRQ_Mask();
		pNFC->NFC_RSTART	= 0;
		while ( ISZERO(pNFC->NFC_IREQ, HwNFC_IREQ_FLAG0) );
		NAND_IO_IRQ_UnMask();
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline void NAND_IO_SetupDMADoubleBuf(  int nMode, int nDMACh );
*  
*  DESCRIPTION : 
*  
*  INPUT:
*			nDMACh	= 
*			nMode	= 
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
static __inline void NAND_IO_SetupDMADoubleBuf(  int nMode, int nDMACh )
{
	unsigned int	*pDMA_PhyBuffer;
	unsigned int	*pDMA_WorkBuffer;
	unsigned int	nSourceAddr, nDestAddr;
	unsigned		uCHCTRL;
	unsigned int	uTmp;
	unsigned int	uSrcInc, uSrcMask;
	unsigned int	uDstInc, uDstMask;

	if ( nMode == NAND_IO_DMA_WRITE )
	{
		uSrcInc 	= 4;
		uSrcMask 	= 0;
		uDstInc		= 0;
		uDstMask 	= 0;
	}
	else
	{
		uSrcInc 	= 0;
		uSrcMask 	= 0;
		uDstInc		= 4;
		uDstMask 	= 0;
	}
	
	if ( nDMACh & 1 )
	{
		pDMA_PhyBuffer 	= gpDMA_PhyBuffer0;			// Working Address
		pDMA_WorkBuffer = gpDMA_WorkBuffer0;		// Physical Address
	}
	else
	{
		pDMA_PhyBuffer 	= gpDMA_PhyBuffer1;			// Working Address
		pDMA_WorkBuffer = gpDMA_WorkBuffer1;		// Physical Address
	}
	
	if ( nMode == NAND_IO_DMA_WRITE )
	{
		// pSRC: Buffer Address
		// pDST: NFC_LDATA

		BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );

		//pSRC --> pDMA_WorkBuffer
		//memcpy( pDMA_WorkBuffer, pSRC, 512 );

		// Target Physical Address- for DMA H/W Control Set
		nSourceAddr	= (unsigned int)pDMA_PhyBuffer;
		#if defined(_WINCE_) || defined(_LINUX_)
		nDestAddr 	= (unsigned int)&NAND_IO_HwLDATA_PA;
		#else
		nDestAddr 	= (unsigned int)&pNFC->NFC_LDATA;
		#endif
		
		//============================================================
		// DMA Control Register Set
		//============================================================
		uCHCTRL =	
	//				HwCHCTRL_SYNC_ON		|
	//				HwCHCTRL_HRD_W			|
					HwCHCTRL_BST_BURST		|
					HwCHCTRL_TYPE_SINGL		|
				   	HwCHCTRL_HRD_WR			|
	//				HwCHCTRL_BST_BURST		|
					HwCHCTRL_BSIZE_8		|
					HwCHCTRL_WSIZE_32		|
					HwCHCTRL_FLAG			|
					HwCHCTRL_EN_ON			|
					0;

	}
	else	// NAND_IO_DMA_READ
	{	

		BITCSET(pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_8 | HwNFC_CTRL_DEN_EN | HwNFC_CTRL_PSIZE_512 );

		#if defined(_WINCE_) || defined(_LINUX_)
		nSourceAddr = (unsigned int)&NAND_IO_HwLDATA_PA;				// NFC_LDATA Physical Address: ex_TCC89,92XX: 0XF050b0020
		#else
		nSourceAddr = (unsigned int)&pNFC->NFC_LDATA;
		#endif
		nDestAddr 	= (unsigned int)pDMA_PhyBuffer;

		//============================================================
		// DMA Control Register Set
		//============================================================
		uCHCTRL =	
	//				HwCHCTRL_SYNC_ON		|
	//				HwCHCTRL_HRD_W			|
					HwCHCTRL_BST_BURST		|
					HwCHCTRL_TYPE_SINGL		|
				   	HwCHCTRL_HRD_RD			|
	//				HwCHCTRL_BST_BURST		|
					HwCHCTRL_BSIZE_8		|
					HwCHCTRL_WSIZE_32		|
					HwCHCTRL_FLAG			|
					HwCHCTRL_EN_ON			|
					0;
	}

	//============================================================
	// Set Source Address & Source Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_SADR 	= nSourceAddr;
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->SPARAM[0] = (uSrcInc | (uSrcMask << 4));
	#else
	pNAND_DMA->SPARAM	 = (uSrcInc | (uSrcMask << 4));
	#endif
	//============================================================
	// Set Dest Address & Dest Parameter (mask + increment)
	//============================================================
	pNAND_DMA->ST_DADR 	= nDestAddr;  
	#if defined(_WINCE_) || defined(_LINUX_)
	pNAND_DMA->DPARAM[0] = (uDstInc | (uDstMask << 4));
	#else
	pNAND_DMA->DPARAM	 = (uDstInc | (uDstMask << 4));
	#endif
	//============================================================
	// Calculate byte size per 1 Hop transfer
	//============================================================
	uTmp	= (uCHCTRL & (Hw5+Hw4)) >> 4;			// calc log2(word size)
	uTmp	= uTmp + ( (uCHCTRL & (Hw7+Hw6)) >> 6);	// calc log2(word * burst size)

	//============================================================
	// Set External DMA Request Register
	//============================================================
	pNAND_DMA->EXTREQ = Hw18;		// NFC

	//============================================================
	// Set Hcount
	//============================================================
	if (uTmp)
		pNAND_DMA->HCOUNT	= (512 + (1 << uTmp) - 1) >> uTmp;
	else
		pNAND_DMA->HCOUNT	= 512;

	//============================================================
	// Set & Enable DMA
	//============================================================
	pNAND_DMA->CHCTRL		= uCHCTRL;

	//============================================================
	// Set NFC DSize & IREQ Clear
	//============================================================
	pNFC->NFC_DSIZE		= 512;
	pNFC->NFC_IREQ		= 0x77;	// HwNFC_IREQ_FLAG1;
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_SetupECC( U16 nEccOnOff, U16 nEncDec, U16 nEccType, U32 EccBaseAddr )
*  
*  DESCRIPTION : 
*  INPUT:
*			nEccOnOff	= 
*			nEccType	= 
*			nEncDec	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_SetupECC( U16 nEccOnOff, U16 nEncDec, U16 nEccType, U16 nAccessType, U32 EccBaseAddr )
{
	if ( nEccOnOff == ECC_OFF )
	{
		//IO_CKC_EnableBUS( IO_CKC_BUS_ECC );

		BITCLR(pIOBUSCFG_T->HRSTEN0, Hw24);
		BITSET(pIOBUSCFG_T->HRSTEN0, Hw24);

		pECC->ECC_BASE = 0xF05B0010;	/* Base Address for ECC Calculation */
		pECC->ECC_MASK	= 0x00000000;				/* Address mask for ECC area */
		pECC->ECC_CTRL &= HwECC_CTRL_EN_DIS;

		//IO_CKC_DisableBUS( IO_CKC_BUS_ECC );
	}
	else if ( nEccOnOff == ECC_ON )
	{
		//IO_CKC_EnableBUS( IO_CKC_BUS_ECC );

		if ( nEncDec == ECC_DECODE )
		{
			//==========================================================
			//
			// ECC Decode Setup
			//
			//==========================================================
			pECC->ECC_CLEAR	= 0x00000000;					/* Clear ECC Block		*/
			
			if ( nAccessType == NAND_MCU_ACCESS )
			{
				pIOBUSCFG_T->STORAGE = HwIOBUSCFG_STORAGE_NFC;
				pECC->ECC_BASE	= (0x000FFFFF & EccBaseAddr);
			}
			else if ( nAccessType == NAND_DMA_ACCESS )
			{
				pIOBUSCFG_T->STORAGE = HwIOBUSCFG_STORAGE_NFC;
				pECC->ECC_BASE	= EccBaseAddr;
			}
			
			pECC->ECC_MASK	= 0x00000000;				/* Address mask for ECC area */

			if ( nEccType == SLC_ECC_TYPE )
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_SLCDE;
			else if (nEccType == MLC_ECC_4BIT_TYPE )
			{
				pECC->ECC_CTRL	|= HwECC_CTRL_IEN_MECC4_EN;				
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL4DE;
			}
			else if (nEccType == MLC_ECC_8BIT_TYPE )
			{
				pECC->ECC_CTRL	|= HwECC_CTRL_IEN_MECC8_EN;
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL8DE;
			}
			else if (nEccType == MLC_ECC_12BIT_TYPE )
			{
				pECC->ECC_CTRL	|= HwECC_CTRL_IEN_MECC12_EN;
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL12DE;
			}
			else if (nEccType == MLC_ECC_16BIT_TYPE )
			{
				pECC->ECC_CTRL	|= HwECC_CTRL_IEN_MECC16_EN;
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL16DE;
			}			
		}
		else if ( nEncDec == ECC_ENCODE )
		{
			//==========================================================
			//
			// ECC Encode Setup
			//
			//==========================================================
			if ( nAccessType == NAND_MCU_ACCESS )
			{
				pIOBUSCFG_T->STORAGE = HwIOBUSCFG_STORAGE_NFC;
				pECC->ECC_BASE	= (0x000FFFFF &EccBaseAddr);
			}
			else if ( nAccessType == NAND_DMA_ACCESS )
			{
				pIOBUSCFG_T->STORAGE = HwIOBUSCFG_STORAGE_NFC;
				pECC->ECC_BASE	= EccBaseAddr;
			}

			pECC->ECC_MASK	= 0x00000000;				/* Address mask for ECC area */

			if ( nEccType == SLC_ECC_TYPE )
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_SLCEN;
			else if (nEccType == MLC_ECC_4BIT_TYPE )
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL4EN;
			else if (nEccType == MLC_ECC_8BIT_TYPE )
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL8EN;
			else if (nEccType == MLC_ECC_12BIT_TYPE )
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL12EN;
			else if (nEccType == MLC_ECC_16BIT_TYPE )
				pECC->ECC_CTRL	|= 	HwECC_CTRL_EN_MCL16EN;
			
			pECC->ECC_CLEAR	= 0x00000000;					/* Clear ECC Block		*/

		}
	}
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_EncodeECC( U16 nEccType, U8* nSpareBuffer );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nEccType	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_EncodeECC( U16 nEccType, U8* nSpareBuffer )
{
	unsigned int		nECC_CODE;
	unsigned char		*pcECC;
	unsigned int		*pSpareDW;

	if ( nEccType == SLC_ECC_TYPE )
	{
		//==================================================================
		//	[ TNFTL V1.0 ]
		//==================================================================	
		// 520th	: P64-P8		of ECC Area-1 [ DATA 256-511 ]
		// 521th	: P1024-P128	of ECC Area-1 [ DATA 256-511 ]
		// 522th	: P4-P1			of ECC Area-1 [ DATA 256-511 ]
		// 525th	: P64-P8		of ECC Area-0 [ DATA 0-255 ]
		// 526th	: P1024-P128	of ECC Area-0 [ DATA 0-255 ]
		// 527th	: P4-P1			of ECC Area-0 [ DATA 0-255 ]
		//==================================================================
		
		pcECC = (unsigned char* )&pECC->ECC_CODE0;

		/* Area-1 */
		nSpareBuffer[2]	= pcECC[0];		// P4-P1
		nSpareBuffer[1]= pcECC[1];		// P1024-P128
		nSpareBuffer[0]= pcECC[2];		// P64-P8
		
		/* Area-0 */
		nSpareBuffer[5]	= pcECC[4];		// P4-P1
		nSpareBuffer[4]	= pcECC[5];		// P1024-128
		nSpareBuffer[3]	= pcECC[6];		// P64-P8	
	}
	else
	{
		pSpareDW = (unsigned int *)nSpareBuffer;

		nECC_CODE 	= pECC->ECC_CODE0;
		*pSpareDW	= nECC_CODE; ++pSpareDW;

		nECC_CODE 	= pECC->ECC_CODE1;
		*pSpareDW	= nECC_CODE; ++pSpareDW;

		nECC_CODE 	= pECC->ECC_CODE2;
		*pSpareDW	= nECC_CODE; ++pSpareDW;

		nECC_CODE 	= pECC->ECC_CODE3;
		*pSpareDW	= nECC_CODE; ++pSpareDW;

		nECC_CODE 	= pECC->ECC_CODE4;
		*pSpareDW	= nECC_CODE; ++pSpareDW;

		nECC_CODE 	= pECC->ECC_CODE5;
		*pSpareDW	= nECC_CODE; ++pSpareDW;

		nECC_CODE 	= pECC->ECC_CODE6;
		*pSpareDW	= nECC_CODE; ++pSpareDW;
	}
	
	return (NAND_IO_ERROR)SUCCESS;	
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_CorrectionSLC( U8* nPageBuffer, U8* nSpareBuffer );
*  
*  DESCRIPTION : 
*  INPUT:
*			nPageBuffer	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_CorrectionSLC( U8* nPageBuffer, U8* nSpareBuffer )
{
	unsigned int		uErrorStatus;
	unsigned int		uSLCECC0, uSLCECC1;
	NAND_IO_ERROR		res;

	//IO_CKC_EnableBUS( IO_CKC_BUS_ECC );
	
	//==================================================================
	//	[ TNFTL V1.0 ]
	//==================================================================	
	// 520th	: P64-P8		of ECC Area-1 [ DATA 256-511 ]
	// 521th	: P1024-P128	of ECC Area-1 [ DATA 256-511 ]
	// 522th	: P4-P1			of ECC Area-1 [ DATA 256-511 ]
	// 525th	: P64-P8		of ECC Area-0 [ DATA 0-255 ]
	// 526th	: P1024-P128	of ECC Area-0 [ DATA 0-255 ]
	// 527th	: P4-P1			of ECC Area-0 [ DATA 0-255 ]
	//==================================================================

	/* Load SLC ECC Code for Area 1 */
	uSLCECC0	= ( nSpareBuffer[0] << 16 ) +
				  ( nSpareBuffer[1] <<  8 ) +
				  ( nSpareBuffer[2] );
				  
	/* Load SLC ECC Code for Area 0 */
	uSLCECC1	= ( nSpareBuffer[3] << 16 ) +
				  ( nSpareBuffer[4] <<  8 ) +
				  ( nSpareBuffer[5] );

	res = (NAND_IO_ERROR)SUCCESS;
	
	/* Correction Area 0 */
	pECC->ECC_CODE1 = uSLCECC1;
	uErrorStatus = pECC->ERRNUM & 0x7;
	
	if ( uErrorStatus == HwERR_NUM_ERR1 )
	{
		nPageBuffer[pECC->ECC_EADDR0 >> 3] ^= (1 << (pECC->ECC_EADDR0 & 0x07));
		res = (NAND_IO_ERROR)SUCCESS;
	}	
	else if ( uErrorStatus != HwERR_NUM_NOERR )
	{
		res	= ERR_NAND_IO_FAILED_CORRECTION_SLC_ECC;
		goto ErrorCorrectionSLC;
	}	

	res = (NAND_IO_ERROR)SUCCESS;
	
	/* Correction Area 1 */
	pECC->ECC_CODE0 = uSLCECC0;
	uErrorStatus = pECC->ERRNUM & 0x7;
	
	if ( uErrorStatus == HwERR_NUM_ERR1 )
	{
		nPageBuffer[pECC->ECC_EADDR0 >> 3] ^= (1 << (pECC->ECC_EADDR0 & 0x07));
		res = (NAND_IO_ERROR)SUCCESS;
	}
	else if ( uErrorStatus != HwERR_NUM_NOERR )
	{
		res = ERR_NAND_IO_FAILED_CORRECTION_SLC_ECC;
		goto ErrorCorrectionSLC;		
	}

ErrorCorrectionSLC:

	//IO_CKC_DisableBUS( IO_CKC_BUS_ECC );
	
	return res;
	
}



/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_CorrectionMLC_IRQ( U16 nEccType, U8* nPageBuffer, U8* nSpareBuffer, U16 nDataSize );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDataSize	= 
*			nEccType	= 
*			nPageBuffer	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_CorrectionMLC_IRQ( U16 nEccType, U8* nPageBuffer, U8* nSpareBuffer, U16 nDataSize )
{
	unsigned int		i;
	unsigned int		uErrAddr;
	unsigned int		uErrorStatus;
	unsigned int		*pSpareDW;
	
	NAND_IO_ECC_INFO	*pECC_Info;
	NAND_IO_ERROR		res;

	if ( nEccType == MLC_ECC_4BIT_TYPE )
		pECC_Info = &gMLC_ECC_4Bit;
	else if ( nEccType == MLC_ECC_8BIT_TYPE )
		pECC_Info = &gMLC_ECC_8Bit;
	else if ( nEccType == MLC_ECC_12BIT_TYPE )
		pECC_Info = &gMLC_ECC_12Bit;
	else if ( nEccType == MLC_ECC_14BIT_TYPE )
		pECC_Info = &gMLC_ECC_14Bit;
	else if ( nEccType == MLC_ECC_16BIT_TYPE )
		pECC_Info = &gMLC_ECC_16Bit;
	else
		return ERR_NAND_IO_WRONG_PARAMETER;

	pSpareDW	= (unsigned int *)nSpareBuffer;
	
	//IO_CKC_EnableBUS( IO_CKC_BUS_ECC );
	
	pECC->ECC_CODE0	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE1	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE2	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE3	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE4	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE5	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE6	= *pSpareDW; ++pSpareDW;

	/* Sync Delay */

	/* Wait MLC ECC Correction */
	while ( !(pECC->ECC_IREQ & pECC_Info->DecodeFlag ) );

	res = (NAND_IO_ERROR)SUCCESS;

	/* Correction */
	uErrorStatus = pECC->ERRNUM & 0x1F;

	if ( uErrorStatus > pECC_Info->ErrorNum )
	{
		if ( memcmp( nSpareBuffer, gNAND_IO_TempBuffer, pECC_Info->EccDataSize ) == 0 )
		{
			//ND_TRACE("[Ecc Decode]: %d byte 0xFF \n", nDataSize );
			return SUCCESS;
		}
		
		#ifdef NAND_IO_ECC_ERROR_LOG
		PRINTF("\n\nErrorNum[%02d],DataSize[%03d] - Correction Fail", uErrorStatus, nDataSize );
		#if defined(USE_V_ADDRESS) && defined(_WINCE_)
		RETAILMSG(1,(	TEXT("[NAND        ] [ECC Correction Fail]\n")));
		#else
		ND_TRACE("[NAND        ] [ECC Correction Fail]\n" );
		#endif
		#endif

		if ( nDataSize == 512 )
		{
			#if defined(USE_V_ADDRESS)				
			ND_TRACE("\n\nErrorNum[%02d],DataSize[%03d] - Correction Fail", uErrorStatus, nDataSize );
			ND_TRACE("\n\nISR_Data:\n");
			for ( i = 0; i < nDataSize; ++i )
			{
				ND_TRACE("%02X", nPageBuffer[i]);
			}

			ND_TRACE("\n\nISR_ECC:\n");
			for ( i = 0; i < 28; ++i )
			{
				ND_TRACE("%02X", nSpareBuffer[i]);
			}
			#else
			ND_TRACE("\n\nErrorNum[%d],DataSize[%d] - Correction Fail", uErrorStatus, nDataSize );
			ND_TRACE("\n\nData:\n");
			for ( i = 0; i < nDataSize; ++i )
			{
				ND_TRACE("%X", nPageBuffer[i]);
			}

			ND_TRACE("\n\nECC:\n");
			for ( i = 0; i < 28; ++i )
			{
				ND_TRACE("%X", nSpareBuffer[i]);
			}
			#endif

			ND_TRACE("\n\n");			
		}

		res = ERR_NAND_IO_FAILED_CORRECTION_MLC_ECC;
		goto ErrorCorrectionMLC;
	}
	else if ( uErrorStatus == HwERR_NUM_NOERR )
	{
		res = (NAND_IO_ERROR)SUCCESS;
	}
	else
	{
		for ( i = 0; i < uErrorStatus; ++i )
		{
			uErrAddr = *(unsigned long int*)(&pECC->ECC_EADDR0+i);

			if ( ( uErrAddr >> 3 ) < nDataSize )
				nPageBuffer[uErrAddr>>3] ^= (1<<(uErrAddr &0x7));
		}
	}
	
ErrorCorrectionMLC:
	/* Disable MLC ECC */
	//IO_CKC_DisableBUS( IO_CKC_BUS_ECC );
	
	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_CorrectionMLC( U16 nEccType, U8* nPageBuffer, U8* nSpareBuffer, U16 nDataSize );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDataSize	= 
*			nEccType	= 
*			nPageBuffer	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_CorrectionMLC( U16 nEccType, U8* nPageBuffer, U8* nSpareBuffer, U16 nDataSize )
{
	unsigned int		i;
	unsigned int		uErrAddr;
	unsigned int		uErrorStatus;
	unsigned int		*pSpareDW;
	#ifdef _LINUX_
	unsigned char		nECCBuffer[30]__attribute__((aligned(8)));
	#else
	unsigned char		nECCBuffer[30];
	#endif
	
	NAND_IO_ECC_INFO	*pECC_Info;
	NAND_IO_ERROR		res;

	if ( nEccType == MLC_ECC_4BIT_TYPE )
		pECC_Info = &gMLC_ECC_4Bit;
	else if ( nEccType == MLC_ECC_8BIT_TYPE )
		pECC_Info = &gMLC_ECC_8Bit;
	else if ( nEccType == MLC_ECC_12BIT_TYPE )
		pECC_Info = &gMLC_ECC_12Bit;
	else if ( nEccType == MLC_ECC_14BIT_TYPE )
		pECC_Info = &gMLC_ECC_14Bit;
	else if ( nEccType == MLC_ECC_16BIT_TYPE )
		pECC_Info = &gMLC_ECC_16Bit;
	else
		return ERR_NAND_IO_WRONG_PARAMETER;

	for ( i = 0; i < pECC_Info->EccDataSize; ++i )
		nECCBuffer[i] = nSpareBuffer[i];

	//============================================
	// Get Buffer Pointer
	//============================================
	if ( memcmp( nECCBuffer, gNAND_IO_TempBuffer, pECC_Info->EccDataSize ) == 0 )
	{
		if ( nDataSize == 512 )
			pSpareDW	= (unsigned int *)pECC_Info->All_FF_512_ECC_Code;
		else if ( nDataSize == 12 )
			pSpareDW	= (unsigned int *)&ALL_FF_ECC_BCH_04BIT_12;
		else if ( nDataSize == 16 )
			pSpareDW	= (unsigned int *)&ALL_FF_ECC_BCH_04BIT_16;
		else
			pSpareDW	= (unsigned int *)&ALL_FF_ECC_BCH_04BIT_512;
	}
	else
	{
			pSpareDW 	= ( unsigned int *)nECCBuffer;
		}
	
	//IO_CKC_EnableBUS( IO_CKC_BUS_ECC );
	
	pECC->ECC_CODE0	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE1	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE2	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE3	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE4	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE5	= *pSpareDW; ++pSpareDW;
	pECC->ECC_CODE6	= *pSpareDW; ++pSpareDW;

	/* Sync Delay */
	//ASM_NOP; ASM_NOP; ASM_NOP; ASM_NOP;

	/* Wait MLC ECC Correction */
	while ( !(pECC->ECC_IREQ & pECC_Info->DecodeFlag ) );

	res = (NAND_IO_ERROR)SUCCESS;

	/* Correction */
	uErrorStatus = pECC->ERRNUM & 0x1F;

	if ( uErrorStatus > pECC_Info->ErrorNum )
	{
		if ( nDataSize == 512 )
		{
			#if defined(USE_V_ADDRESS)
			ND_TRACE("\n\nErrorNum[%02d],DataSize[%03d] - Correction Fail", uErrorStatus, nDataSize );
			ND_TRACE("\n\nData:\n");
			for ( i = 0; i < nDataSize; ++i )
			{
				ND_TRACE("%02X", nPageBuffer[i]);
			}

			ND_TRACE("\n\nECC:\n");
			for ( i = 0; i < 28; ++i )
			{
				ND_TRACE("%02X", nSpareBuffer[i]);
			}
			#else
			ND_TRACE("\n\nErrorNum[%d],DataSize[%d] - Correction Fail", uErrorStatus, nDataSize );
			ND_TRACE("\n\nData:\n");
			for ( i = 0; i < nDataSize; ++i )
			{
				ND_TRACE("%X", nPageBuffer[i]);
			}

			ND_TRACE("\n\nECC:\n");
			for ( i = 0; i < 28; ++i )
			{
				ND_TRACE("%X", nSpareBuffer[i]);
			}
			#endif
			
			ND_TRACE("\n\n");			
		}

		res = ERR_NAND_IO_FAILED_CORRECTION_MLC_ECC;
		goto ErrorCorrectionMLC;
	}
	else if ( uErrorStatus == HwERR_NUM_NOERR )
	{
		res = (NAND_IO_ERROR)SUCCESS;
	}
	else
	{
		for ( i = 0; i < uErrorStatus; ++i )
		{
			uErrAddr = *(unsigned long int*)(&pECC->ECC_EADDR0+i);

			if ( ( uErrAddr >> 3 ) < nDataSize )
				nPageBuffer[uErrAddr>>3] ^= (1<<(uErrAddr &0x7));
		}
	}
	
ErrorCorrectionMLC:
	/* Disable MLC ECC */
	//IO_CKC_DisableBUS( IO_CKC_BUS_ECC );
	
	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_EncodeBootBinary( NAND_IO_DEVINFO *nDevInfo, U8 *nPageBuffer, int nEccOnOff );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nPageBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_EncodeBootBinary( NAND_IO_DEVINFO *nDevInfo, U8 *nPageBuffer, int nEccOnOff )
{
	unsigned int		i;
	#ifdef _LINUX_
	unsigned char		nECCBuffer[30]__attribute__((aligned(8)));
	#else
	unsigned char		nECCBuffer[30];
	#endif
	unsigned char		*pPageB;
	unsigned char		*pDataBuffer;
	unsigned char		*pEccB;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	//if ( nEccOnOff == ECC_OFF )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	res = (NAND_IO_ERROR)SUCCESS;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================
	NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	pPageB		= (unsigned char*)nPageBuffer;

	/* Get Buffer pointer */
	pDataBuffer = (unsigned char*)pPageB;

	//####################################################
	//#	Dummy Write Page Data
	//####################################################
#if 0		/* 09.07.15 */
	if (!( pNFC->NFC_CTRL1 & Hw30 ))
	{
		/* Setup ECC Block */
		if ( nEccOnOff == ECC_ON )
		{
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, MLC_ECC_16BIT_TYPE, NAND_MCU_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, MLC_ECC_16BIT_TYPE, NAND_MCU_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL	|= ( NAND_SB_BOOT_PAGE_SIZE << ECC_SHIFT_DATASIZE );		// Data Size...		
			pECC->ECC_CLEAR	 = 0x00000000;						// Clear ECC Block			
		}

		/* Write 256 Page Data */
		BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
		pNFC->NFC_DSIZE		= NAND_SB_BOOT_PAGE_SIZE;
		pNFC->NFC_IREQ 		= 0x77;	// pNFC->NFC_IREQ_FLAG1;		
		pNFC->NFC_PSTART 	= 0;

		i = ( NAND_SB_BOOT_PAGE_SIZE >> 2 );
		do {
				while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
				uDWordByte.BYTE[0] = *pDataBuffer;++pDataBuffer;
				uDWordByte.BYTE[1] = *pDataBuffer;++pDataBuffer;
				uDWordByte.BYTE[2] = *pDataBuffer;++pDataBuffer;
				uDWordByte.BYTE[3] = *pDataBuffer;++pDataBuffer;
				pNFC->NFC_LDATA	= uDWordByte.DWORD;
		}while(--i);
		
		while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
	}
	else
#endif /* 0 */
	{
		/* Setup ECC Block */
		if ( nEccOnOff == ECC_ON )
		{
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, MLC_ECC_16BIT_TYPE, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, MLC_ECC_16BIT_TYPE, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
			#endif
			pECC->ECC_CTRL	|= ( NAND_SB_BOOT_PAGE_SIZE << ECC_SHIFT_DATASIZE );		// Data Size...	
			pECC->ECC_CLEAR	= 0x00000000;			
		}

		i = ( NAND_SB_BOOT_PAGE_SIZE >> 2 );
		do {
				uDWordByte.BYTE[0] = *pDataBuffer;++pDataBuffer;
				uDWordByte.BYTE[1] = *pDataBuffer;++pDataBuffer;
				uDWordByte.BYTE[2] = *pDataBuffer;++pDataBuffer;
				uDWordByte.BYTE[3] = *pDataBuffer;++pDataBuffer;
				pNFC->NFC_WDATA	= uDWordByte.DWORD;
		}while(--i);
	}

	/* Adapt type of address */
	pEccB = (unsigned char*)nECCBuffer;
	
	/*	Load ECC code from ECC block */
	if ( nEccOnOff == ECC_ON )
	{
		res = NAND_IO_EncodeECC( MLC_ECC_16BIT_TYPE, pEccB );
		if ( res != SUCCESS )
			goto ErrorWrite512Data;

		for ( i = 0; i < 28; ++i )	// MLC_ECC_16BIT_TYPE Data Size = 26Byte
		{
			*pDataBuffer = nECCBuffer[i];
			pDataBuffer += 1;
		}
	}

	/* Disable ECC Block */
	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

ErrorWrite512Data:
	return res;
}


/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_EncodeBootBinary( NAND_IO_DEVINFO *nDevInfo, U8 *nPageBuffer, int nEccOnOff );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nPageBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
NAND_IO_ERROR NAND_IO_EncDecodeBinary( unsigned int nEncDec, unsigned int nEccType, unsigned int nDataSize, U8 *nPageBuffer, U8 *nEccBuffer )
{
	unsigned int		i;
	#ifdef _LINUX_
	unsigned char		nECCTempBuffer[30]__attribute__((aligned(8)));
	#else
	unsigned char		nECCTempBuffer[30];
	#endif
	unsigned int		nEccDataSize = 0;
	unsigned char		*pPageB;
	unsigned char		*pDataBuffer;
	unsigned char		*pEccBuffer;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	//if ( nEccOnOff == ECC_OFF )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	res = (NAND_IO_ERROR)SUCCESS;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================
	NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	pPageB		= (unsigned char*)nPageBuffer;

	/* Get Buffer pointer */
	pDataBuffer = (unsigned char*)pPageB;

	pEccBuffer = (unsigned char*)nEccBuffer;
	//####################################################
	//#	Dummy Write Page Data
	//####################################################
	/* Setup ECC Block */
	#if defined(_WINCE_) || defined(_LINUX_)
	NAND_IO_SetupECC( (U16)ECC_ON, nEncDec, nEccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
	#else
	NAND_IO_SetupECC( (U16)ECC_ON, nEncDec, nEccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
	#endif
	pECC->ECC_CTRL	|= ( nDataSize << ECC_SHIFT_DATASIZE );		// Data Size...	
	pECC->ECC_CLEAR	= 0x00000000;			

	i = ( nDataSize >> 2 );
	do {
			uDWordByte.BYTE[0] = *pDataBuffer;++pDataBuffer;
			uDWordByte.BYTE[1] = *pDataBuffer;++pDataBuffer;
			uDWordByte.BYTE[2] = *pDataBuffer;++pDataBuffer;
			uDWordByte.BYTE[3] = *pDataBuffer;++pDataBuffer;
			pNFC->NFC_WDATA	= uDWordByte.DWORD;
	}while(--i);

	/* Adapt type of address */
//	pEccB = (unsigned char*)nECCTempBuffer;

	if ( nEccType == A_SLC )
	{
		nEccDataSize = 8;
	}
	else if ( nEccType == A_MLC )
	{
		nEccDataSize = 8;
	}
	else if ( nEccType == A_MLC_8BIT )
	{
		nEccDataSize = 20;
	}
	else if ( nEccType == A_MLC_12BIT )
	{
		nEccDataSize = 20;
	}
		else if ( nEccType == A_MLC_16BIT )
	{
		nEccDataSize = 26;
	}
				
	/*	Load ECC code from ECC block */
	res = NAND_IO_EncodeECC( nEccType, nECCTempBuffer );
	if ( res != SUCCESS )
		goto ErrorWrite512Data;

	for ( i = 0; i < nEccDataSize; ++i )	// MLC_ECC_16BIT_TYPE Data Size = 26Byte
	{
		*pEccBuffer = nECCTempBuffer[i];
		pEccBuffer += 1;
	}
	

	/* Disable ECC Block */
	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

ErrorWrite512Data:
	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_ReadSpareDataECC( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nEccOnOff );
*  
*  DESCRIPTION : 
*  
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
*  REMARK:	  by nemo
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_ReadSpareData( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nPageEccOnOff )
{
	unsigned int		i;
	unsigned int		nReadSize;
	unsigned int		nSpareTotalSize;
	unsigned char		bAlignAddr;
	unsigned char		*pSpareB = 0, *pEccB;
	unsigned int		*pSpareDW = 0;
	unsigned char		*pSpareBuffer;
	#ifdef _LINUX_
	unsigned char		nECCBuffer[30]__attribute__((aligned(8)));
	#else
	unsigned char		nECCBuffer[30];
	#endif
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;
	
	if ( nDevInfo->Feature.MediaType & A_MLC_16BIT )
		nSpareTotalSize = 12;
	else
		nSpareTotalSize = 16;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr = ( (unsigned int)nSpareBuffer & 3 ) ? 0 : 1;

	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );
	
	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
		pSpareDW	= (unsigned int*)nSpareBuffer;
	else
		pSpareB		= (unsigned char*)nSpareBuffer;

	if ( nDevInfo->Feature.MediaType & A_SMALL )
	{
		//----------------------------------------------
		//	Read Small Page Spare Data: 16Byte
		//----------------------------------------------
		i = 4;
		
		do {
			if ( bAlignAddr )
			{
				*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
			}	
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pSpareB = uDWordByte.BYTE[0];++pSpareB;
				*pSpareB = uDWordByte.BYTE[1];++pSpareB;
				*pSpareB = uDWordByte.BYTE[2];++pSpareB;
				*pSpareB = uDWordByte.BYTE[3];++pSpareB;
			}
		}while(--i);

		if ( nDevInfo->Feature.MediaType & A_PARALLEL )
		{
			if ( nPageEccOnOff == PAGE_ECC_ON )
			{
				memset( gNAND_IO_ShareEccBuffer, 0xFF, 16 );
				
				//=========================================================================
				// Check Align of PageBuffer Address
				//=========================================================================
				bAlignAddr = ( (unsigned int)&gNAND_IO_ShareEccBuffer & 3 ) ? 0 : 1;
				
				//=========================================================================
				// Get Buffer Pointer
				//=========================================================================
				/* Adapt type of address */
				if ( bAlignAddr )
					pSpareDW	= (unsigned int*)&gNAND_IO_ShareEccBuffer[0];
				else
					pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
				
				//----------------------------------------------
				//	Read Spare Data
				//----------------------------------------------
				i = 4;
				do {
					if ( bAlignAddr )
					{
						*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
					}	
					else
					{
						uDWordByte.DWORD = pNFC->NFC_WDATA;
						*pSpareB = uDWordByte.BYTE[0];++pSpareB;
						*pSpareB = uDWordByte.BYTE[1];++pSpareB;
						*pSpareB = uDWordByte.BYTE[2];++pSpareB;
						*pSpareB = uDWordByte.BYTE[3];++pSpareB;
					}
				}while(--i);
			}
		}

		return (NAND_IO_ERROR)SUCCESS;
	}

	/* Setup ECC Block */
	#if defined(_WINCE_) || defined(_LINUX_)
	NAND_IO_SetupECC( ECC_ON, ECC_DECODE, MLC_ECC_4BIT_TYPE, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
	#else
	NAND_IO_SetupECC( ECC_ON, ECC_DECODE, MLC_ECC_4BIT_TYPE, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
	#endif
	pECC->ECC_CTRL	|= ( nSpareTotalSize << ECC_SHIFT_DATASIZE );
	pECC->ECC_CLEAR	= 0x00000000;		// Clear ECC Block
	
	/* Set Spare Buffer */
	pSpareBuffer = ( bAlignAddr ) ? (unsigned char*)pSpareDW : (unsigned char*)pSpareB;

	//----------------------------------------------
	//	Read Spare Data
	//----------------------------------------------
	i = ( nSpareTotalSize >> 2 );
	do {
		if ( bAlignAddr )
		{
			*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
		}	
		else
		{
			uDWordByte.DWORD = pNFC->NFC_WDATA;
			*pSpareB = uDWordByte.BYTE[0];++pSpareB;
			*pSpareB = uDWordByte.BYTE[1];++pSpareB;
			*pSpareB = uDWordByte.BYTE[2];++pSpareB;
			*pSpareB = uDWordByte.BYTE[3];++pSpareB;
		}
	}while(--i);

	/* Read 4Bit ECC data */
	nReadSize = 8;
	
	/* Adapt type of address */
	pEccB = (unsigned char*)nECCBuffer;

	//----------------------------------------------
	// Read ECC Code
	//----------------------------------------------
	while ( nReadSize )
	{
		/* Read as DWORD */
		if ( nReadSize >= 4 )
		{
			uDWordByte.DWORD = WORD_OF(pNFC->NFC_WDATA);
			*pEccB = uDWordByte.BYTE[0];++pEccB;
			*pEccB = uDWordByte.BYTE[1];++pEccB;
			*pEccB = uDWordByte.BYTE[2];++pEccB;
			*pEccB = uDWordByte.BYTE[3];++pEccB;
			nReadSize -= 4;
		}
		/* Read as WORD */
		else if ( nReadSize >= 2 )
		{
			*pEccB = (unsigned char)pNFC->NFC_SDATA; ++pEccB;
			*pEccB = (unsigned char)pNFC->NFC_SDATA; ++pEccB;			
			nReadSize -= 2;
		}
		/* Read as BYTE */
		else
		{
			*pEccB = (unsigned char)pNFC->NFC_SDATA; ++pEccB;			
			nReadSize -= 1;
		}
	}

	/* Check and Correct ECC code */
	//===================================
	// 4 Bit MLC ECC Correction
	//===================================
	if ( ( nECCBuffer[0] == 0x00 ) && ( nECCBuffer[1] == 0x00 ) &&
		 ( nECCBuffer[2] == 0x00 ) && ( nECCBuffer[3] == 0x00 ) &&
		 ( nECCBuffer[4] == 0x00 ) && ( nECCBuffer[5] == 0x00 ) &&
		 ( nECCBuffer[6] == 0x00 ) && ( nECCBuffer[7] == 0x00 ))
	{
		res |= NAND_IO_CorrectionMLC( MLC_ECC_4BIT_TYPE, pSpareBuffer, nECCBuffer, (U16)nSpareTotalSize );
	 	res |= ERR_NAND_IO_FAILED_CORRECTION_MLC_ECC;
	}
	else if ( ( nECCBuffer[0] == 0xFF ) && ( nECCBuffer[1] == 0xFF ) &&
		 	  ( nECCBuffer[2] == 0xFF ) && ( nECCBuffer[3] == 0xFF ) &&
		 	  ( nECCBuffer[4] == 0xFF ) && ( nECCBuffer[5] == 0xFF ) &&
		 	  ( nECCBuffer[6] == 0xFF ) && ( nECCBuffer[7] == 0xFF ))
 	{
		ASM_NOP;
	}
	else
	{
		res |= NAND_IO_CorrectionMLC( MLC_ECC_4BIT_TYPE, pSpareBuffer, nECCBuffer, (U16)nSpareTotalSize );
	}

	//=========================================================================
	// Ecc Clear
	//=========================================================================
	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	if ( nPageEccOnOff == PAGE_ECC_ON )
	{
		//memset( gNAND_IO_ShareEccBuffer, 0xFF, nDevInfo->EccWholeDataSize );
		
		//=========================================================================
		// Check Align of PageBuffer Address
		//=========================================================================
		bAlignAddr = ( (unsigned int)&gNAND_IO_ShareEccBuffer & 3 ) ? 0 : 1;
		
		//=========================================================================
		// Get Buffer Pointer
		//=========================================================================
		/* Adapt type of address */
		if ( bAlignAddr )
			pSpareDW	= (unsigned int*)&gNAND_IO_ShareEccBuffer[0];
		else
			pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
		
		//----------------------------------------------
		//	Read Spare Data
		//----------------------------------------------
		i = ( nDevInfo->EccWholeDataSize >> 2 );
		do {
			if ( bAlignAddr )
			{
				*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
			}	
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pSpareB = uDWordByte.BYTE[0];++pSpareB;
				*pSpareB = uDWordByte.BYTE[1];++pSpareB;
				*pSpareB = uDWordByte.BYTE[2];++pSpareB;
				*pSpareB = uDWordByte.BYTE[3];++pSpareB;
			}
		}while(--i);
	}

//	return res;
	return (NAND_IO_ERROR)SUCCESS;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_ReadSpareDataECC( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nEccOnOff );
*  
*  DESCRIPTION : 
*  
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
*  REMARK:	  by nemo
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_ReadSpareDataMTD( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nPageEccOnOff )
{
	unsigned int		i;
	unsigned int		nSpareTotalSize;
	unsigned int		nECCDataSize = 8;
	unsigned char		bAlignAddr;
	unsigned char		*pSpareB = 0;
	unsigned int		*pSpareDW = 0;
	unsigned char		*pSpareBuffer;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;

	nSpareTotalSize = 32;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr = ( (unsigned int)nSpareBuffer & 3 ) ? 0 : 1;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
		pSpareDW	= (unsigned int*)nSpareBuffer;
	else
		pSpareB		= (unsigned char*)nSpareBuffer;

	if ( nDevInfo->Feature.MediaType & A_SMALL )
	{
		//----------------------------------------------
		//	Read Small Page Spare Data: 16Byte
		//----------------------------------------------
		i = 4;
		
		do {
			if ( bAlignAddr )
			{
				*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
			}	
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pSpareB = uDWordByte.BYTE[0];++pSpareB;
				*pSpareB = uDWordByte.BYTE[1];++pSpareB;
				*pSpareB = uDWordByte.BYTE[2];++pSpareB;
				*pSpareB = uDWordByte.BYTE[3];++pSpareB;
			}
		}while(--i);

		if ( nDevInfo->Feature.MediaType & A_PARALLEL )
		{
			if ( nPageEccOnOff == PAGE_ECC_ON )
			{
				memset( gNAND_IO_ShareEccBuffer, 0xFF, 16 );
				
				//=========================================================================
				// Check Align of PageBuffer Address
				//=========================================================================
				bAlignAddr = ( (unsigned int)&gNAND_IO_ShareEccBuffer & 3 ) ? 0 : 1;
				
				//=========================================================================
				// Get Buffer Pointer
				//=========================================================================
				/* Adapt type of address */
				if ( bAlignAddr )
					pSpareDW	= (unsigned int*)&gNAND_IO_ShareEccBuffer[0];
				else
					pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
				
				//----------------------------------------------
				//	Read Spare Data
				//----------------------------------------------
				i = 4;
				do {
					if ( bAlignAddr )
					{
						*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
					}
					else
					{
						uDWordByte.DWORD = pNFC->NFC_WDATA;
						*pSpareB = uDWordByte.BYTE[0];++pSpareB;
						*pSpareB = uDWordByte.BYTE[1];++pSpareB;
						*pSpareB = uDWordByte.BYTE[2];++pSpareB;
						*pSpareB = uDWordByte.BYTE[3];++pSpareB;
					}
				}while(--i);
			}
		}

		return (NAND_IO_ERROR)SUCCESS;
	}
	
	/* Set Spare Buffer */
	pSpareBuffer = ( bAlignAddr ) ? (unsigned char*)pSpareDW : (unsigned char*)pSpareB;

	//----------------------------------------------
	//	Read Spare Data
	//----------------------------------------------
	i = ( nSpareTotalSize >> 2 );
	do {
		if ( bAlignAddr )
		{
			*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
		}	
		else
		{
			uDWordByte.DWORD = pNFC->NFC_WDATA;
			*pSpareB = uDWordByte.BYTE[0];++pSpareB;
			*pSpareB = uDWordByte.BYTE[1];++pSpareB;
			*pSpareB = uDWordByte.BYTE[2];++pSpareB;
			*pSpareB = uDWordByte.BYTE[3];++pSpareB;
		}
	}while(--i);

	if (( nDevInfo->Feature.MediaType & A_MLC ) || ( nDevInfo->Feature.MediaType & A_SLC ))
		nECCDataSize = 8;
	else if ( ( nDevInfo->Feature.MediaType & A_MLC_8BIT ) || ( nDevInfo->Feature.MediaType & A_MLC_12BIT ) )
		nECCDataSize = 20;
	else if ( nDevInfo->Feature.MediaType & A_MLC_16BIT ) 
		nECCDataSize = 26;

	if ( nPageEccOnOff == PAGE_ECC_ON )
	{
		memset( gNAND_IO_ShareEccBuffer, 0xFF, ( nECCDataSize << 2 ) );
		
		//=========================================================================
		// Check Align of PageBuffer Address
		//=========================================================================
		bAlignAddr = ( (unsigned int)&gNAND_IO_ShareEccBuffer & 3 ) ? 0 : 1;
		
		//=========================================================================
		// Get Buffer Pointer
		//=========================================================================
		/* Adapt type of address */
		if ( bAlignAddr )
			pSpareDW	= (unsigned int*)&gNAND_IO_ShareEccBuffer[0];
		else
			pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
		
		//----------------------------------------------
		//	Read Spare Data
		//----------------------------------------------
		i = ( ( nECCDataSize << 2) >> 2 );
		do {
			if ( bAlignAddr )
			{
				*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
			}	
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pSpareB = uDWordByte.BYTE[0];++pSpareB;
				*pSpareB = uDWordByte.BYTE[1];++pSpareB;
				*pSpareB = uDWordByte.BYTE[2];++pSpareB;
				*pSpareB = uDWordByte.BYTE[3];++pSpareB;
			}
		}while(--i);
	}

	return res;
}

#if defined(USE_V_ADDRESS) && defined(_WINCE_)
NAND_IO_ERROR NAND_IO_SetNFC_IRQ_Handle( int nIrq, DWORD nItrID, HANDLE hEvent )
{
	if ( nIrq == IRQ_NFC )
	{
		gNFC_IRQ_Intr	= nItrID;
		gNFC_IRQ_Handle = hEvent;
		printf("[-IRQ_NFC:EventH:0x%x]\r\n", gNFC_IRQ_Handle);
	}
	else
	{
		gEXT_IRQ_Intr	= nItrID;
		gEXT_IRQ_Handle	= hEvent;
		printf("[-IRQ_EI11:EventH:0x%x]\r\n", gEXT_IRQ_Handle);
	}
}
#endif

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_Read512DataDoubleBuf( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize,
*      												      		   U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff, int nSpareOnOff );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nPageBuffer	= 
*			nReadPPSize	= 
*			nSpareBuffer	= 
*			nStartPPage	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_Read512DataDoubleBuf( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize,
												   			U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff, int nSpareOnOff )
{
	unsigned int		i, j;
	unsigned char		bAlignAddr;
	unsigned char		*pPageB = 0, *pSpareB = 0;
	unsigned int		*pPageDW = 0, *pSpareDW = 0;
	unsigned char		*pDataBuffer, *pSpareBuffer = 0;
	unsigned char		*pPrDataBuffer = 0;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res = (NAND_IO_ERROR)SUCCESS;
	
	if ( ( nStartPPage + nReadPPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	#ifdef READ_SPEED_CHECK
	NAND_IO_GPIO_Toggle(Hw17);
	#endif

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;
	nSpareOnOff = TNFTL_READ_SPARE_ON;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr = ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	#ifdef READ_SPEED_CHECK
	NAND_IO_GPIO_Toggle(Hw17);	//----------------------->> ECC Setup
	#endif /* READ_SPEED_CHECK */

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
	{
		pPageDW		= (unsigned int*)nPageBuffer;
		pSpareDW	= (unsigned int*)nSpareBuffer;		
	}
	else
	{
		pPageB		= (unsigned char*)nPageBuffer;
		pSpareB		= (unsigned char*)nSpareBuffer;
	}

	// Set SpareBuffer Pointer =>> ECCBuffer
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
	{
		pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
		
		//=========================================================================
		// Empty Page ECCBuffer Pointer Increment
		//=========================================================================
		for ( j = 0; j < nStartPPage; ++j )
			pSpareB += nDevInfo->EccDataSize;
	}
	
	//----------------------------------------------
	//	Read Data as 512Bytes repeatly
	//----------------------------------------------
	for ( j = 0; j < nReadPPSize; ++j )
	{
		/* Set Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

		//####################################################
		//#	Read 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )
		/* Setup ECC Block */
		if ( nEccOnOff == ECC_ON )
		{
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
			#endif
			pECC->ECC_CTRL		|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	 = 0x00000000;			/* Clear ECC Block		*/
		}

		#ifdef READ_SPEED_CHECK
		NAND_IO_GPIO_Toggle(Hw21);
		#endif

		/* Read 512 Data Area */
		i = 128;
		do {
			if ( bAlignAddr )
			{
				*pPageDW = pNFC->NFC_WDATA;++pPageDW;
			}
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				*pPageB = uDWordByte.BYTE[1];++pPageB;
				*pPageB = uDWordByte.BYTE[2];++pPageB;
				*pPageB = uDWordByte.BYTE[3];++pPageB;
			}
		}while(--i);

		#ifdef READ_SPEED_CHECK
		NAND_IO_GPIO_Toggle(Hw21);
		#endif
		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )		

		#ifdef READ_SPEED_CHECK
		NAND_IO_GPIO_Toggle(Hw17);
		#endif
		
		/* Setup ECC Block */
		if ( nEccOnOff == ECC_ON )
		{
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL		|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	 = 0x00000000;			/* Clear ECC Block		*/
		}
		
		/* Disable DMA Ahead */
		/* Start DMA on NFC BUS */
		NAND_IO_SetupDMADoubleBuf( NAND_IO_DMA_READ, j );

		#if defined(USE_V_ADDRESS) && defined(_WINCE_) && defined(__USE_NAND_ISR__)

		#ifdef NAND_GPIO_DEBUG
		BITSET(pGPIO->GPFDAT, Hw16);
		#endif

	    BITSET(pPIC->CLR1, Hw9);			// Interrupt Status Clear
		InterruptDone(gNFC_IRQ_Intr);
		
		pNFC->NFC_RSTART	= 0;

        if ( pNFC->NFC_IREQ & HwNFC_IREQ_FLAG0 )		//Check Read-Done Flag
	    {
            BITSET( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG0 );		// Interrupt Clear

		    #ifdef NAND_IO_UART_DEBUG
		    ND_TRACE("[NAND]Rx-DMA already complite[%s:%d]\r\n", __FUNCTION__, __LINE__);
		    #endif
	    }
	    else
	    {
		    DWORD nTimeOut = 1;		// Unit: Milliseconds

		    #ifdef NAND_GPIO_DEBUG
		    BITSET(pGPIO->GPFDAT, Hw17);
		    #endif
	    
		    if( WaitForSingleObject( gNFC_IRQ_Handle, nTimeOut) == WAIT_OBJECT_0 )
		    {
			    #ifdef NAND_GPIO_DEBUG
			    BITSET(pGPIO->GPFDAT, Hw21);
			    BITCLR(pGPIO->GPFDAT, Hw21);
			    #endif

			    #ifdef NAND_IO_UART_DEBUG
			    ND_TRACE("[NAND]Rx-DMA complite[%s:%d]\r\n", __FUNCTION__, __LINE__);
			    #endif
		    }
		    else
		    {
			    #ifdef NAND_GPIO_DEBUG
			    BITSET(pGPIO->GPFDAT, Hw22);
			    BITCLR(pGPIO->GPFDAT, Hw22);
			    #endif
			    #ifdef NAND_IO_UART_DEBUG
			    ND_TRACE("[NAND]Rx-DMA Wait Time Out[%s:%d]\r\n", __FUNCTION__, __LINE__);
			    #endif
		    }
		    #ifdef NAND_GPIO_DEBUG
		    BITCLR(pGPIO->GPFDAT, Hw17);
		    #endif
	    }

		BITSET( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG0 );		// Interrupt Clear
        BITSET(pPIC->CLR1, Hw9);			// Interrupt Status Clear
	    InterruptDone(gNFC_IRQ_Intr);

	    #ifdef NAND_GPIO_DEBUG
	    BITCLR(pGPIO->GPFDAT, Hw16);
	    #endif
		#else
		
		NAND_IO_IRQ_Mask();
		pNFC->NFC_RSTART	= 0;
		#endif

		if ( j == 0 )
		{
//			memcpy( gNAND_IO_ShareEccBuffer, gpDMA_WorkBuffer0, nDevInfo->EccWholeDataSize );
		}
		else
		{
			if ( j & 1 )
				memcpy( pPrDataBuffer, gpDMA_WorkBuffer1, 512 );
			else
				memcpy( pPrDataBuffer, gpDMA_WorkBuffer0, 512 );
		}


		#if defined(USE_V_ADDRESS) && defined(_WINCE_) && defined(__USE_NAND_ISR__)
		// nop
		#else
		while ( ISZERO(pNFC->NFC_IREQ, HwNFC_IREQ_FLAG0) );
		NAND_IO_IRQ_UnMask();
		#endif

		if ( j == (unsigned int)( nReadPPSize - 1 ) )
		{
			if ( j & 1 )
				memcpy( pDataBuffer, gpDMA_WorkBuffer0, 512 );
			else
				memcpy( pDataBuffer, gpDMA_WorkBuffer1, 512 );
		}
		else
		{
			pPrDataBuffer = pDataBuffer;	// Buffer Pointer Backup

			if ( j & 1 )
				pDataBuffer =(unsigned char *)gpDMA_WorkBuffer0;
			else
				pDataBuffer =(unsigned char *)gpDMA_WorkBuffer1;
		}

		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;

		#endif
		//####################################################
		//####################################################
		if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
		{
			// NOP	
		}
		else if ( nDevInfo->Feature.MediaType & A_SMALL )
		{
			/* Set Spare Buffer */
			pSpareBuffer = ( bAlignAddr ) ? (unsigned char*)pSpareDW : (unsigned char*)pSpareB;

			/* Read 16Bytes spare data */
			i = 4;
			do {
				if ( bAlignAddr )
				{
					*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
				}	
				else
				{
					uDWordByte.DWORD = pNFC->NFC_WDATA;
					*pSpareB = uDWordByte.BYTE[0];++pSpareB;
					*pSpareB = uDWordByte.BYTE[1];++pSpareB;
					*pSpareB = uDWordByte.BYTE[2];++pSpareB;
					*pSpareB = uDWordByte.BYTE[3];++pSpareB;
				}
			}while(--i);


			pSpareB = (unsigned char*)pSpareBuffer;
			pSpareB +=	NAND_IO_SPARE_SIZE_SMALL;
		}

		#ifdef READ_SPEED_CHECK
		NAND_IO_GPIO_Toggle(Hw22);
		#endif
		
		/* Check and Correct ECC code */
		if ( nEccOnOff == ECC_ON )
		{
			if (( nDevInfo->EccType == SLC_ECC_TYPE ) && ( nDevInfo->Feature.MediaType & A_SMALL ))
			{
				//===================================
				// SLC ECC Correction
				//===================================				
				pSpareBuffer += NAND_IO_SPARE_SIZE_SMALL;
				res |= NAND_IO_CorrectionSLC( pDataBuffer, pSpareBuffer );
			}
			else
			{
				if ( nDevInfo->EccType == SLC_ECC_TYPE )
					res |= NAND_IO_CorrectionSLC( pDataBuffer, pSpareB );
				else
					res |= NAND_IO_CorrectionMLC( nDevInfo->EccType, pDataBuffer, pSpareB, 512 );

				pSpareB += nDevInfo->EccDataSize;
			}
		}

		#ifdef READ_SPEED_CHECK
		NAND_IO_GPIO_Toggle(Hw22);
		#endif
	}

	//=========================================================================
	// Return
	//=========================================================================
	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_Read512Data( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize,
*      												      U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff, int nSpareOnOff );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nPageBuffer	= 
*			nReadPPSize	= 
*			nSpareBuffer	= 
*			nStartPPage	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_Read512Data( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize,
												   U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff, int nSpareOnOff )
{
	unsigned int		i, j;
	unsigned char		bAlignAddr;
	unsigned char		*pPageB = 0, *pSpareB;
	unsigned int		*pPageDW = 0, *pSpareDW;
	unsigned char		*pDataBuffer, *pSpareBuffer;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res = (NAND_IO_ERROR)SUCCESS;
	
	if ( ( nStartPPage + nReadPPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;
	nSpareOnOff = TNFTL_READ_SPARE_ON;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr = ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
	{
		pPageDW		= (unsigned int*)nPageBuffer;
		pSpareDW	= (unsigned int*)nSpareBuffer;		
	}
	else
	{
		pPageB		= (unsigned char*)nPageBuffer;
		pSpareB		= (unsigned char*)nSpareBuffer;
	}

	// Set SpareBuffer Pointer =>> ECCBuffer
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
	{
		pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
		
		//=========================================================================
		// Empty Page ECCBuffer Pointer Increment
		//=========================================================================
		for ( j = 0; j < nStartPPage; ++j )
			pSpareB += nDevInfo->EccDataSize;
	}
	
	//----------------------------------------------
	//	Read Data as 512Bytes repeatly
	//----------------------------------------------
	for ( j = 0; j < nReadPPSize; ++j )
	{
		/* Set Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

		//####################################################
		//#	Read 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )
		/* Setup ECC Block */
		if ( nEccOnOff == ECC_ON )
		{
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
			#endif
			pECC->ECC_CTRL		|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	 = 0x00000000;			/* Clear ECC Block		*/
		}

		/* Read 512 Data Area */
		i = 128;
		do {
			if ( bAlignAddr )
			{
				*pPageDW = pNFC->NFC_WDATA;++pPageDW;
			}
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				*pPageB = uDWordByte.BYTE[1];++pPageB;
				*pPageB = uDWordByte.BYTE[2];++pPageB;
				*pPageB = uDWordByte.BYTE[3];++pPageB;
			}
		}while(--i);

		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )		
		/* Setup ECC Block */
		if ( nEccOnOff == ECC_ON )
		{
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL		|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	 = 0x00000000;			/* Clear ECC Block		*/
		}
		
		/* Start DMA on NFC BUS */
		#if defined(_WINCE_) || defined(_LINUX_)
		NAND_IO_SetupDMA( (void*)&NAND_IO_HwLDATA_PA, 0, 0,
						  (void*)pDataBuffer, 4, 0,
						  NAND_IO_DMA_READ, 512 );
		#else
		NAND_IO_SetupDMA( (void*)&pNFC->NFC_LDATA, 0, 0,
						  (void*)pDataBuffer, 4, 0,
						  NAND_IO_DMA_READ, 512 );
		#endif

		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;

		#endif
		//####################################################
		//####################################################

		if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
		{
			// NOP	
		}
		else if ( nDevInfo->Feature.MediaType & A_SMALL )
		{
			/* Set Spare Buffer */
			pSpareBuffer = ( bAlignAddr ) ? (unsigned char*)pSpareDW : (unsigned char*)pSpareB;

			/* Read 16Bytes spare data */
			i = 4;
			do {
				if ( bAlignAddr )
				{
					*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
				}	
				else
				{
					uDWordByte.DWORD = pNFC->NFC_WDATA;
					*pSpareB = uDWordByte.BYTE[0];++pSpareB;
					*pSpareB = uDWordByte.BYTE[1];++pSpareB;
					*pSpareB = uDWordByte.BYTE[2];++pSpareB;
					*pSpareB = uDWordByte.BYTE[3];++pSpareB;
				}
			}while(--i);


			pSpareB = (unsigned char*)pSpareBuffer;
			pSpareB +=	NAND_IO_SPARE_SIZE_SMALL;
		}

		/* Check and Correct ECC code */
		if ( nEccOnOff == ECC_ON )
		{
			if (( nDevInfo->EccType == SLC_ECC_TYPE ) && ( nDevInfo->Feature.MediaType & A_SMALL ))
			{
				//===================================
				// SLC ECC Correction
				//===================================				
				pSpareBuffer += NAND_IO_SPARE_SIZE_SMALL;
				res |= NAND_IO_CorrectionSLC( pDataBuffer, pSpareBuffer );
			}
			else
			{
				if ( nDevInfo->EccType == SLC_ECC_TYPE )
					res |= NAND_IO_CorrectionSLC( pDataBuffer, pSpareB );
				else
					res |= NAND_IO_CorrectionMLC( nDevInfo->EccType, pDataBuffer, pSpareB, 512 );

				pSpareB += nDevInfo->EccDataSize;
			}
		}
	}

	//=========================================================================
	// Return
	//=========================================================================
	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_Read512DataMTD( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize,
*      												   U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
*  
*  DESCRIPTION : 
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nPageBuffer	= 
*			nReadPPSize	= 
*			nSpareBuffer	= 
*			nStartPPage	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_Read512DataMTD( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nReadPPSize,
												  	 U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff, int nSpareOnOff )
{
	unsigned int		i, j;
	unsigned char		bAlignAddr;
	unsigned int		nECCDataSize = 8;
	unsigned char		*pPageB = 0, *pSpareB = 0;
	unsigned int		*pPageDW = 0, *pSpareDW = 0;
	unsigned char		*pDataBuffer, *pSpareBuffer = 0;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res = (NAND_IO_ERROR)SUCCESS;
	
	if ( ( nStartPPage + nReadPPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;
	nSpareOnOff = TNFTL_READ_SPARE_ON;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr = ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	if (( nDevInfo->Feature.MediaType & A_MLC ) ||( nDevInfo->Feature.MediaType & A_SLC ))
		nECCDataSize = 8;
	else if ( ( nDevInfo->Feature.MediaType & A_MLC_8BIT ) || ( nDevInfo->Feature.MediaType & A_MLC_12BIT ) )
		nECCDataSize = 20;
	else if ( nDevInfo->Feature.MediaType & A_MLC_16BIT ) 
		nECCDataSize = 26;
	
	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
	{
		pPageDW		= (unsigned int*)nPageBuffer;
		pSpareDW	= (unsigned int*)nSpareBuffer;		
	}
	else
	{
		pPageB		= (unsigned char*)nPageBuffer;
		pSpareB		= (unsigned char*)nSpareBuffer;
	}

	// Set SpareBuffer Pointer =>> ECCBuffer
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
	{
		pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
		
		//=========================================================================
		// Empty Page ECCBuffer Pointer Increment
		//=========================================================================
		for ( j = 0; j < nStartPPage; ++j )
			pSpareB += nECCDataSize;
	}
	
	//----------------------------------------------
	//	Read Data as 512Bytes repeatly
	//----------------------------------------------
	for ( j = 0; j < nReadPPSize; ++j )
	{
		/* Set Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

		//####################################################
		//#	Read 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )
		/* Setup ECC Block */
		if ( nEccOnOff == ECC_ON )
		{
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
			#endif
			pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR  = 0x00000000;					// Clear ECC Block
		}

		/* Read 512 Data Area */
		i = 128;
		do {
			if ( bAlignAddr )
			{
				*pPageDW = pNFC->NFC_WDATA;++pPageDW;
			}
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				*pPageB = uDWordByte.BYTE[1];++pPageB;
				*pPageB = uDWordByte.BYTE[2];++pPageB;
				*pPageB = uDWordByte.BYTE[3];++pPageB;
			}
		}while(--i);

		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )		
		/* Setup ECC Block */
		if ( nEccOnOff == ECC_ON )
		{
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_DECODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	 = 0x00000000;			// Clear ECC Block
		}
		

		/* Start DMA on NFC BUS */
		#if defined(_LINUX_) || defined(_WINCE_)
		NAND_IO_SetupDMA( (void*)&NAND_IO_HwLDATA_PA, 0, 0,
						  (void*)pDataBuffer, 4, 0,
						  NAND_IO_DMA_READ, 512 );
		#else
		NAND_IO_SetupDMA( (void*)&pNFC->NFC_LDATA, 0, 0,
						  (void*)pDataBuffer, 4, 0,
						  NAND_IO_DMA_READ, 512 );
		#endif

		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;


		#endif
		//####################################################
		//####################################################

		if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
		{
			// NOP	
		}
		else if ( nDevInfo->Feature.MediaType & A_SMALL )
		{
			/* Set Spare Buffer */
			pSpareBuffer = ( bAlignAddr ) ? (unsigned char*)pSpareDW : (unsigned char*)pSpareB;

			/* Read 16Bytes spare data */
			i = 4;
			do {
				if ( bAlignAddr )
				{
					*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
				}	
				else
				{
					uDWordByte.DWORD = pNFC->NFC_WDATA;
					*pSpareB = uDWordByte.BYTE[0];++pSpareB;
					*pSpareB = uDWordByte.BYTE[1];++pSpareB;
					*pSpareB = uDWordByte.BYTE[2];++pSpareB;
					*pSpareB = uDWordByte.BYTE[3];++pSpareB;
				}
			}while(--i);

			pSpareB = (unsigned char*)pSpareBuffer;
			pSpareB +=	NAND_IO_SPARE_SIZE_SMALL;
		}

		/* Check and Correct ECC code */
		if ( nEccOnOff == ECC_ON )
		{
			if (( nDevInfo->EccType == SLC_ECC_TYPE ) && ( nDevInfo->Feature.MediaType & A_SMALL ))
			{
				//===================================
				// SLC ECC Correction
				//===================================				
				pSpareBuffer += NAND_IO_SPARE_SIZE_SMALL;
				res |= NAND_IO_CorrectionSLC( pDataBuffer, pSpareBuffer );
			}
			else
			{
				if ( nDevInfo->EccType == SLC_ECC_TYPE )
					res |= NAND_IO_CorrectionSLC( pDataBuffer, pSpareB );
				else
					res |= NAND_IO_CorrectionMLC( nDevInfo->EccType, pDataBuffer, pSpareB, 512 );

				pSpareB += nECCDataSize;
			}
		}
	}

	//=========================================================================
	// Return
	//=========================================================================
	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_ReadUserSizeData( NAND_IO_DEVINFO *nDevInfo, U16 nColumnAddr, U32 nReadSize, U8 *nReadBuffer );
*  
*  DESCRIPTION : 
*  INPUT:
*			nColumnAddr	= 
*			nDevInfo	= 
*			nReadBuffer	= 
*			nReadSize	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_ReadUserSizeData( NAND_IO_DEVINFO *nDevInfo, U16 nColumnAddr, U32 nReadSize, U8 *nReadBuffer )
{
	unsigned int		*pSpareDW = 0;
	unsigned char		*pPageB = 0;
	DWORD_BYTE			uDWordByte;
	
	//=========================================================================
	// Initial Setting
	//=========================================================================
	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	//=========================================================================
	// Check Parameter
	//=========================================================================
	if ( (U32)( nColumnAddr + nReadSize ) > (U16)( nDevInfo->Feature.PageSize + nDevInfo->Feature.SpareSize ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Read UserSize Data
	//=========================================================================

	/* Adapt type of address */
	pPageB = (unsigned char*)nReadBuffer;
	pSpareDW= (unsigned int*)nReadBuffer;
	//if ( nReadSize >= 4 )
	//{
	//	#ifdef USE_NFC_LDATA		/* 08.12.17 */
	//	/* Read 512 Data Area */
	//	BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
	//	pNFC->NFC_DSIZE		= nReadSize;
	//	pNFC->NFC_IREQ	 	= 0x77;	// pNFC->NFC_IREQ_FLAG1;
	//	pNFC->NFC_PSTART 	= 0;	
	//
	//	do {
	//		while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
	//		
	//		{
	//			uDWordByte.DWORD = pNFC->NFC_LDATA;
	//			*pPageB = uDWordByte.BYTE[0];++pPageB;
	//			*pPageB = uDWordByte.BYTE[1];++pPageB;
	//			*pPageB = uDWordByte.BYTE[2];++pPageB;
	//			*pPageB = uDWordByte.BYTE[3];++pPageB;
	//		}
	//
	//		nReadSize -= 4;
	//
	//	}while(nReadSize);
	//
	//	while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
	//}
	//else
	//{
	//	#endif
		while ( nReadSize )
		{
			/* Read as DWORD */
			if ( nReadSize >= 4 )
			{
				uDWordByte.DWORD = WORD_OF(pNFC->NFC_WDATA);
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				*pPageB = uDWordByte.BYTE[1];++pPageB;
				*pPageB = uDWordByte.BYTE[2];++pPageB;
				*pPageB = uDWordByte.BYTE[3];++pPageB;
				nReadSize -= 4;
			}
			/* Read as WORD */
			else if ( nReadSize >= 2 )
			{
				uDWordByte.WORD[0] = HWORD_OF(pNFC->NFC_WDATA);
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				*pPageB = uDWordByte.BYTE[1];++pPageB;
				nReadSize -= 2;
			}
			/* Read as BYTE */
			else
			{
				uDWordByte.BYTE[0] = BYTE_OF(pNFC->NFC_WDATA);
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				nReadSize -= 1;
			}
		}
	//}

	//=========================================================================
	// Return
	//=========================================================================
	return (NAND_IO_ERROR)SUCCESS;

}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_WriteSpareData( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nEccOnOff );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
*  REMARK:	  by nemo
**************************************************************************/
NAND_IO_ERROR NAND_IO_WriteSpareData( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nPageEccOnOff )
{
	unsigned int		i;
	unsigned int		nSpareTotalSize;
	unsigned int		nWriteSize;
	unsigned char		bAlignAddr;
	unsigned char		*pSpareB = 0;
	unsigned int		*pSpareDW = 0;
	unsigned char		*pEccB;
	#ifdef _LINUX_
	unsigned char		nECCBuffer[28]__attribute__((aligned(8)));
	#else
	unsigned char		nECCBuffer[28];
	#endif
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;

	if ( nDevInfo->Feature.MediaType & A_MLC_16BIT )
		nSpareTotalSize = 12;
	else
	nSpareTotalSize = 16;
	
	//=========================================================================
	// Check Align of nSpareBuffer Address
	//=========================================================================
	bAlignAddr		= ( (unsigned int)nSpareBuffer & 3 ) ? 0 : 1;
		
	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
		pSpareDW	= (unsigned int*)nSpareBuffer;
	else
		pSpareB		= (unsigned char*)nSpareBuffer;

	//==============================================================
	// Write Spare
	//==============================================================
	if ( nDevInfo->Feature.MediaType & A_BIG )
	{
		if (!( pNFC->NFC_CTRL1 & Hw30 ))
		{
			/* Setup ECC Block */
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)ECC_ON, ECC_ENCODE, MLC_ECC_4BIT_TYPE, NAND_MCU_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)ECC_ON, ECC_ENCODE, MLC_ECC_4BIT_TYPE, NAND_MCU_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL	|= ( nSpareTotalSize << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	= 0x00000000;

			/* Write 12Bytes spare data */
			BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
			pNFC->NFC_DSIZE		= nSpareTotalSize;
			pNFC->NFC_IREQ	 	= 0x77;	// pNFC->NFC_IREQ_FLAG1;

			NAND_IO_IRQ_Mask();

			pNFC->NFC_PSTART 	= 0;

			i = ( nSpareTotalSize >> 2 );
			do {
				while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
				
				if ( bAlignAddr )
				{
					pNFC->NFC_LDATA = *pSpareDW;++pSpareDW;
				}
				else
				{
					uDWordByte.BYTE[0]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[1]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[2]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[3]	= *pSpareB;++pSpareB;
					pNFC->NFC_LDATA = uDWordByte.DWORD;
				}
			}while(--i);

			while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
			NAND_IO_IRQ_UnMask();
		}
		else
		{
			/* Setup ECC Block */
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)ECC_ON, ECC_ENCODE, MLC_ECC_4BIT_TYPE, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)ECC_ON, ECC_ENCODE, MLC_ECC_4BIT_TYPE, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
			#endif
			pECC->ECC_CTRL	|= ( nSpareTotalSize << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	= 0x00000000;

			i = ( nSpareTotalSize >> 2 );
			do {
				if ( bAlignAddr )
				{
					pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
				}
				else
				{
					uDWordByte.BYTE[0]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[1]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[2]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[3]	= *pSpareB;++pSpareB;
					pNFC->NFC_WDATA = uDWordByte.DWORD;
				}
			}while(--i);		
		}

		// Clear ECC Buffer
		memset( nECCBuffer, 0xFF, 8 );

		/* Adapt type of address */
		pEccB = (unsigned char*)nECCBuffer;
		
		/*	Load ECC code from ECC block */
		res = NAND_IO_EncodeECC( MLC_ECC_4BIT_TYPE, pEccB );
		if ( res != SUCCESS )
			goto ErrorWriteSpareData;

		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

		/* Write 4Bit ECC data */
		nWriteSize = 8;

		while ( nWriteSize )
		{
			/* Write as DWORD */
			if ( nWriteSize >= 4 )
			{
				uDWordByte.BYTE[0] = *pEccB;++pEccB;
				uDWordByte.BYTE[1] = *pEccB;++pEccB;
				uDWordByte.BYTE[2] = *pEccB;++pEccB;
				uDWordByte.BYTE[3] = *pEccB;++pEccB;
				pNFC->NFC_WDATA = uDWordByte.DWORD;
				nWriteSize -= 4;
			}
			/* Write as WORD */
			else if ( nWriteSize >= 2 )
			{
				pNFC->NFC_SDATA = *pEccB;++pEccB;
				pNFC->NFC_SDATA = *pEccB;++pEccB;
				nWriteSize -= 2;
			}
			/* Write as BYTE */
			else
			{
				pNFC->NFC_SDATA = *pEccB;++pEccB;
				nWriteSize -= 1;
			}
		}

		if ( nPageEccOnOff == PAGE_ECC_ON )
		{
			//=========================================================================
			// Check Align of PageBuffer Address
			//=========================================================================
			bAlignAddr = ( (unsigned int)&gNAND_IO_ShareEccBuffer & 3 ) ? 0 : 1;
			
			//=========================================================================
			// Get Buffer Pointer
			//=========================================================================
			/* Adapt type of address */
			if ( bAlignAddr )
				pSpareDW	= (unsigned int*)&gNAND_IO_ShareEccBuffer[0];
			else
				pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
			
			//----------------------------------------------
			//	Read Spare Data
			//----------------------------------------------
			i = ( nDevInfo->EccWholeDataSize >> 2 );
			do {
				if ( bAlignAddr )
				{
					pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
				}	
				else
				{
					uDWordByte.BYTE[0] = *pSpareB;++pSpareB;
					uDWordByte.BYTE[1] = *pSpareB;++pSpareB;
					uDWordByte.BYTE[2] = *pSpareB;++pSpareB;
					uDWordByte.BYTE[3] = *pSpareB;++pSpareB;
					pNFC->NFC_WDATA = uDWordByte.DWORD;
				}
			}while(--i);
		}
	}
	else
	{
		i = ( nSpareTotalSize >> 2 );
		do {
			if ( bAlignAddr )
			{
				pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
			}
			else
			{
				uDWordByte.BYTE[0]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[1]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[2]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[3]	= *pSpareB;++pSpareB;
				pNFC->NFC_WDATA = uDWordByte.DWORD;
			}
		}while(--i);

		if (( nDevInfo->Feature.MediaType & A_SMALL ) && ( nDevInfo->Feature.MediaType & A_PARALLEL ))
		{
			if ( nPageEccOnOff == PAGE_ECC_ON )
			{
				//=========================================================================
				// Check Align of PageBuffer Address
				//=========================================================================
				bAlignAddr = ( (unsigned int)&gNAND_IO_ShareEccBuffer & 3 ) ? 0 : 1;
				
				//=========================================================================
				// Get Buffer Pointer
				//=========================================================================
				/* Adapt type of address */
				if ( bAlignAddr )
					pSpareDW	= (unsigned int*)&gNAND_IO_ShareEccBuffer[0];
				else
					pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
				
				//----------------------------------------------
				//	Read Spare Data
				//----------------------------------------------
				i = ( nDevInfo->EccWholeDataSize >> 2 );
				do {
					if ( bAlignAddr )
					{
						pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
					}	
					else
					{
						uDWordByte.BYTE[0] = *pSpareB;++pSpareB;
						uDWordByte.BYTE[1] = *pSpareB;++pSpareB;
						uDWordByte.BYTE[2] = *pSpareB;++pSpareB;
						uDWordByte.BYTE[3] = *pSpareB;++pSpareB;
						pNFC->NFC_WDATA = uDWordByte.DWORD;
					}
				}while(--i);
			}			
		}
	}

	//=========================================================================
	// Return
	//=========================================================================

ErrorWriteSpareData:
	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_WriteSpareDataMTD( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nPageEccOnOff );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nPageEccOnOff	= 
*			nSpareBuffer	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_WriteSpareDataMTD( NAND_IO_DEVINFO *nDevInfo, U8 *nSpareBuffer, int nPageEccOnOff )
{
	unsigned int		i;
	unsigned int		nSpareTotalSize;
	unsigned int		nECCDataSize = 8;
	unsigned char		bAlignAddr;
	unsigned char		*pSpareB = 0;
	unsigned int		*pSpareDW = 0;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;
	
	nSpareTotalSize = 32;
	
	//=========================================================================
	// Check Align of nSpareBuffer Address
	//=========================================================================
	bAlignAddr		= ( (unsigned int)nSpareBuffer & 3 ) ? 0 : 1;
		
	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
		pSpareDW	= (unsigned int*)nSpareBuffer;
	else
		pSpareB		= (unsigned char*)nSpareBuffer;

	if (( nDevInfo->Feature.MediaType & A_MLC ) ||( nDevInfo->Feature.MediaType & A_SLC ))
		nECCDataSize = 8;
	else if ( ( nDevInfo->Feature.MediaType & A_MLC_8BIT ) || ( nDevInfo->Feature.MediaType & A_MLC_12BIT ) )
		nECCDataSize = 20;
	else if ( nDevInfo->Feature.MediaType & A_MLC_16BIT ) 
		nECCDataSize = 26;

	//==============================================================
	// Write Spare
	//==============================================================
	if ( nDevInfo->Feature.MediaType & A_BIG )
	{

		i = ( nSpareTotalSize >> 2 );
		do {
			if ( bAlignAddr )
			{
				pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
			}
			else
			{
				uDWordByte.BYTE[0]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[1]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[2]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[3]	= *pSpareB;++pSpareB;
				pNFC->NFC_WDATA = uDWordByte.DWORD;
			}
		}while(--i);		

		if ( nPageEccOnOff == PAGE_ECC_ON )
		{
			//=========================================================================
			// Check Align of PageBuffer Address
			//=========================================================================
			bAlignAddr = ( (unsigned int)&gNAND_IO_ShareEccBuffer & 3 ) ? 0 : 1;
			
			//=========================================================================
			// Get Buffer Pointer
			//=========================================================================
			/* Adapt type of address */
			if ( bAlignAddr )
				pSpareDW	= (unsigned int*)&gNAND_IO_ShareEccBuffer[0];
			else
				pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
			
			//----------------------------------------------
			//	Read Spare Data
			//----------------------------------------------
			i = ( ( nECCDataSize << 2 ) >> 2 );
			do {
				if ( bAlignAddr )
				{
					pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
				}	
				else
				{
					uDWordByte.BYTE[0] = *pSpareB;++pSpareB;
					uDWordByte.BYTE[1] = *pSpareB;++pSpareB;
					uDWordByte.BYTE[2] = *pSpareB;++pSpareB;
					uDWordByte.BYTE[3] = *pSpareB;++pSpareB;
					pNFC->NFC_WDATA = uDWordByte.DWORD;
				}
			}while(--i);
		}
	}
	else
	{
		i = ( nSpareTotalSize >> 2 );
		do {
			if ( bAlignAddr )
			{
				pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
			}
			else
			{
				uDWordByte.BYTE[0]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[1]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[2]	= *pSpareB;++pSpareB;
				uDWordByte.BYTE[3]	= *pSpareB;++pSpareB;
				pNFC->NFC_WDATA = uDWordByte.DWORD;
			}
		}while(--i);

		if (( nDevInfo->Feature.MediaType & A_SMALL ) && ( nDevInfo->Feature.MediaType & A_PARALLEL ))
		{
			if ( nPageEccOnOff == PAGE_ECC_ON )
			{
				//=========================================================================
				// Check Align of PageBuffer Address
				//=========================================================================
				bAlignAddr = ( (unsigned int)&gNAND_IO_ShareEccBuffer & 3 ) ? 0 : 1;
				
				//=========================================================================
				// Get Buffer Pointer
				//=========================================================================
				/* Adapt type of address */
				if ( bAlignAddr )
					pSpareDW	= (unsigned int*)&gNAND_IO_ShareEccBuffer[0];
				else
					pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
				
				//----------------------------------------------
				//	Read Spare Data
				//----------------------------------------------
				i = ( ( 8 << nDevInfo->ShiftPPages) >> 2 );
				do {
					if ( bAlignAddr )
					{
						pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
					}	
					else
					{
						uDWordByte.BYTE[0] = *pSpareB;++pSpareB;
						uDWordByte.BYTE[1] = *pSpareB;++pSpareB;
						uDWordByte.BYTE[2] = *pSpareB;++pSpareB;
						uDWordByte.BYTE[3] = *pSpareB;++pSpareB;
						pNFC->NFC_WDATA = uDWordByte.DWORD;
					}
				}while(--i);
			}			
		}
	}

	//=========================================================================
	// Return
	//=========================================================================

	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_Write512DataDoubleBuf( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize,
*      												    		 U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nPageBuffer	= 
*			nSpareBuffer	= 
*			nStartPPage	= 
*			nWritePPSize	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_Write512DataDoubleBuf( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize,
												    		 U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff )
{
	unsigned int		i, j;
	unsigned char		bAlignAddr;
	#ifdef _LINUX_
	unsigned char 		nDummyPageBuffer[512]__attribute__((aligned(8)));
	unsigned char		nECCBuffer[30]__attribute__((aligned(8)));
	#else
	unsigned char 		nDummyPageBuffer[512];
	unsigned char		nECCBuffer[30];
	#endif
	unsigned int		ColumnAddr;
	unsigned char		*pPageB = 0, *pSpareB = 0;
	unsigned int		*pPageDW = 0;
	unsigned char		*pDataBuffer;
	unsigned char		*pEccB, *pSpare;
	#ifdef NAND_IO_USE_MCU_ACCESS
	DWORD_BYTE			uDWordByte;
	#endif
	NAND_IO_ECC_INFO	*pECC_Info;	
	NAND_IO_ERROR		res;

	if ( ( nStartPPage + nWritePPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr		= ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
		pPageDW		= (unsigned int*)nPageBuffer;
	else
		pPageB		= (unsigned char*)nPageBuffer;

	// Set SpareBuffer Pointer =>> ECCBuffer
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
	{
		memset( gNAND_IO_ShareEccBuffer, 0xFF, nDevInfo->EccWholeDataSize );		
		pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
	}
	else
	{
		pSpareB		= (unsigned char*)nSpareBuffer;
		pSpareB 	+= NAND_IO_SPARE_SIZE_SMALL;
	}

	//=========================================================================
	// Empty Page ECCBuffer Pointer Increment
	//=========================================================================
	for ( j = 0; j < nStartPPage; ++j )
	{
		if ( nDevInfo->EccType == SLC_ECC_TYPE )
			pECC_Info = &gMLC_ECC_1Bit;
		else if ( nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
			pECC_Info = &gMLC_ECC_4Bit;
		else if ( nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
			pECC_Info = &gMLC_ECC_8Bit;
		else if ( nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
			pECC_Info = &gMLC_ECC_12Bit;
		else if ( nDevInfo->EccType == MLC_ECC_14BIT_TYPE )
			pECC_Info = &gMLC_ECC_14Bit;
		else if ( nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
			pECC_Info = &gMLC_ECC_16Bit;
		else
			return ERR_NAND_IO_WRONG_PARAMETER;

		if ( nDevInfo->Feature.MediaType  & A_MLC_16BIT )
		{
			pSpare = (unsigned char*)pSpareB;
			
			for ( i = 0; i < nDevInfo->EccDataSize; ++i )
				pSpare[i] = pECC_Info->All_FF_512_ECC_Code[i];
		}
		else
		{
		memcpy(	(void*)pSpareB, (void*)pECC_Info->All_FF_512_ECC_Code, nDevInfo->EccDataSize);
		}

		pSpareB += nDevInfo->EccDataSize;
	}

	//----------------------------------------------
	//	Write Data as 512Bytes repeatly
	//----------------------------------------------
	for ( j = 0; j < nWritePPSize; ++j )
	{
		/* Get Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

		//####################################################
		//#	Write 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )
		if (!( pNFC->NFC_CTRL1 & Hw30 ))
		{
			if ( nEccOnOff == ECC_ON )
			{
				/* Setup ECC Block */
				#if defined(_WINCE_) || defined(_LINUX_)
				NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
				#else
				NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_LDATA );
				#endif
				pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
				pECC->ECC_CLEAR	= 0x00000000;
			}

			/* Write 512 Data Area */
			BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
			pNFC->NFC_DSIZE		= 512;
			pNFC->NFC_IREQ 		= 0x77;	// pNFC->NFC_IREQ_FLAG1;		

			NAND_IO_IRQ_Mask();

			pNFC->NFC_PSTART 	= 0;
			
			i = 128;
			do {
				while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
				
				if ( bAlignAddr )
				{
					pNFC->NFC_LDATA = *pPageDW;++pPageDW;
				}	
				else
				{
					uDWordByte.BYTE[0] = *pPageB;++pPageB;
					uDWordByte.BYTE[1] = *pPageB;++pPageB;
					uDWordByte.BYTE[2] = *pPageB;++pPageB;
					uDWordByte.BYTE[3] = *pPageB;++pPageB;
					pNFC->NFC_LDATA	= uDWordByte.DWORD;
				}
			}while(--i);
			
			while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
			NAND_IO_IRQ_UnMask();
		}
		else
		{
			if ( nEccOnOff == ECC_ON )
			{
				/* Setup ECC Block */
				#if defined(_WINCE_) || defined(_LINUX_)
				NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
				#else
				NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
				#endif
				pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
				pECC->ECC_CLEAR	= 0x00000000;
			}
						
			i = 128;
			do {
				
				if ( bAlignAddr )
				{
					pNFC->NFC_WDATA = *pPageDW;++pPageDW;
				}	
				else
				{
					uDWordByte.BYTE[0] = *pPageB;++pPageB;
					uDWordByte.BYTE[1] = *pPageB;++pPageB;
					uDWordByte.BYTE[2] = *pPageB;++pPageB;
					uDWordByte.BYTE[3] = *pPageB;++pPageB;
					pNFC->NFC_WDATA	= uDWordByte.DWORD;
				}
			}while(--i);
		}

		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )
		if ( nEccOnOff == ECC_ON )
		{
			/* Setup ECC Block */
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	= 0x00000000;
		}

		if ( j == 0 )
			memcpy( gpDMA_WorkBuffer1, pDataBuffer, 512 );

		NAND_IO_SetupDMADoubleBuf( NAND_IO_DMA_WRITE, j );

		if ( pNFC->NFC_CTRL1 & Hw31 )
			BITCLR( pNFC->NFC_CTRL1, Hw31 );

		NAND_IO_IRQ_Mask();
		pNFC->NFC_PSTART	= 0;

		if ( j != (unsigned int)( nWritePPSize - 1 ) ) 
		{
			if ( j & 1 )
				memcpy( gpDMA_WorkBuffer1, (void *)(pDataBuffer + 512), 512 );
			else
				memcpy( gpDMA_WorkBuffer0, (void *)(pDataBuffer + 512), 512 );
		}

		while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
		NAND_IO_IRQ_UnMask();

		if ( pNFC->NFC_CTRL1 & Hw30 )
			BITSET( pNFC->NFC_CTRL1, Hw31 );
	
		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;

		#endif
		//####################################################
		//####################################################

		/*	Load ECC code from ECC block */
		if ( nEccOnOff == ECC_ON )
		{
			if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
			{
				if ( nDevInfo->Feature.MediaType  & A_MLC_16BIT )
				{
					pSpare = (unsigned char*)pSpareB;
					pEccB = (unsigned char*)nECCBuffer;
					res = NAND_IO_EncodeECC( nDevInfo->EccType, pEccB );
					for ( i = 0; i < nDevInfo->EccDataSize; ++i )
						pSpare[i] = pEccB[i];
				}
				else
				res = NAND_IO_EncodeECC( nDevInfo->EccType, pSpareB );
			}
			else
			{
				pEccB = (unsigned char*)nECCBuffer;
				res = NAND_IO_EncodeECC( nDevInfo->EccType, pEccB );
				memcpy( pSpareB, pEccB, NAND_IO_SPARE_SIZE_SMALL );
			}
			
			if ( res != SUCCESS )
				goto ErrorWrite512Data;				
		}

		pSpareB += nDevInfo->EccDataSize;
	}

	//=========================================================================
	// Empty PPage Write
	//=========================================================================
	if ( ( nStartPPage + nWritePPSize ) != ( nDevInfo->PPages ) )
	{
		if ( nDevInfo->Feature.MediaType & A_BIG )
		{
			/* Change Cycle */
			NAND_IO_SetCommCycleTime();
			
			//---------------------------------
			// Random Data Input [ 0x85 ]
			//---------------------------------
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8585;

			//---------------------------------
			// Write Column Address
			//---------------------------------
			ColumnAddr = nDevInfo->Feature.PageSize;
			ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (ColumnAddr >> 1) : ColumnAddr;
			NAND_IO_WriteColAddr( ColumnAddr, nDevInfo );

			//---------------------------------
			// ECC Data Clear
			//---------------------------------
			for ( j = 0; j < (U16)( nDevInfo->PPages - ( nStartPPage + nWritePPSize ) ); ++j )
			{
				if ( nDevInfo->EccType == SLC_ECC_TYPE )
					pECC_Info = &gMLC_ECC_1Bit;
				else if ( nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
					pECC_Info = &gMLC_ECC_4Bit;
				else if ( nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
					pECC_Info = &gMLC_ECC_8Bit;
				else if ( nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
					pECC_Info = &gMLC_ECC_12Bit;
				else if ( nDevInfo->EccType == MLC_ECC_14BIT_TYPE )
					pECC_Info = &gMLC_ECC_14Bit;
				else if ( nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
					pECC_Info = &gMLC_ECC_16Bit;
				else
					return ERR_NAND_IO_WRONG_PARAMETER;

				if ( nDevInfo->Feature.MediaType  & A_MLC_16BIT )
				{
					pSpare = (unsigned char*)pSpareB;
			
					for ( i = 0; i < nDevInfo->EccDataSize; ++i )
						pSpare[i] = pECC_Info->All_FF_512_ECC_Code[i];
				}
				else
				{
				memcpy(	(void*)pSpareB, (void*)pECC_Info->All_FF_512_ECC_Code, nDevInfo->EccDataSize);
				}
				pSpareB += nDevInfo->EccDataSize;	
			}
		}
		else
		{
			memset( nDummyPageBuffer, 0xFF, 512 );
			//Write Dummy Data
			for ( j = 0; j < (U16)( nDevInfo->PPages - ( nStartPPage + nWritePPSize ) ); ++j )
			{
				//####################################################
				//#	Write 512 Page Data
				//####################################################
				//----------------------------------------------
				//	MCU ACCESS
				//----------------------------------------------
				#if defined( NAND_IO_USE_MCU_ACCESS )
				/* Setup ECC Block */
				if ( nEccOnOff == ECC_ON )
				{
					#if defined(_WINCE_) || defined(_LINUX_)
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
					#else
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_LDATA );
					#endif
					pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );		// Data Size...
					pECC->ECC_CLEAR	= 0x00000000;
				}

				/* Write 512 Data Area */
				BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
				pNFC->NFC_DSIZE	= 512;
				pNFC->NFC_IREQ = 0x77;	// pNFC->NFC_IREQ_FLAG1;		

				NAND_IO_IRQ_Mask();
				pNFC->NFC_PSTART = 0;
				
				i = 128;
				do
				{
					while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
					pNFC->NFC_LDATA = 0xFFFFFFFF;
				}while(--i);
				
				while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
				
				NAND_IO_IRQ_UnMask();
				
				//----------------------------------------------
				//	DMA ACCESS
				//----------------------------------------------
				#elif defined( NAND_IO_USE_DMA_ACCESS )
				/* Setup ECC Block */
				if ( nEccOnOff == ECC_ON )
				{
					#if defined(_WINCE_) || defined(_LINUX_)
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
					#else
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
					#endif
					pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );		// Data Size...
					pECC->ECC_CLEAR	= 0x00000000;
				}
				
				#if defined(_LINUX_) || defined(_WINCE_)
				NAND_IO_SetupDMA( (void*)nDummyPageBuffer, 4, 0,
								  (void*)&NAND_IO_HwLDATA_PA, 0, 0,
								  NAND_IO_DMA_WRITE, 512 );
				#else
				NAND_IO_SetupDMA( (void*)nDummyPageBuffer, 4, 0,
								  (void*)&pNFC->NFC_LDATA, 0, 0,
								  NAND_IO_DMA_WRITE, 512 );
				#endif
	
				#endif
				//####################################################
				//####################################################
				/*	Load ECC code from ECC block */
				if ( nEccOnOff == ECC_ON )
				{
					res = NAND_IO_EncodeECC( nDevInfo->EccType, pSpareB );
					if ( res != SUCCESS )
						goto ErrorWrite512Data;
				}

				pSpareB += nDevInfo->EccDataSize;		
			}			
		}
	}
	
	//=========================================================================
	// Write Spare Data
	//=========================================================================
	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	NAND_IO_WriteSpareData( nDevInfo, nSpareBuffer, PAGE_ECC_ON );

	//=========================================================================
	// Return
	//=========================================================================

ErrorWrite512Data:
	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_Write512Data( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize,
*      													U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nPageBuffer	= 
*			nSpareBuffer	= 
*			nStartPPage	= 
*			nWritePPSize	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
*  REMARK:	  by nemo
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_Write512Data( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize,
												    U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff )
{
	unsigned int		i, j;
	unsigned char		bAlignAddr;
	#ifdef _LINUX_
	unsigned char 		nDummyPageBuffer[512]__attribute__((aligned(8)));
	unsigned char		nECCBuffer[30]__attribute__((aligned(8)));
	#else
	unsigned char 		nDummyPageBuffer[512];
	unsigned char		nECCBuffer[30];
	#endif
	unsigned int		ColumnAddr;
	unsigned char		*pPageB = 0, *pSpareB = 0;
	unsigned int		*pPageDW = 0;
	unsigned char		*pDataBuffer;
	unsigned char		*pEccB, *pSpare;
	#ifdef NAND_IO_USE_MCU_ACCESS
	DWORD_BYTE			uDWordByte;
	#endif
	NAND_IO_ECC_INFO	*pECC_Info;	
	NAND_IO_ERROR		res;

	if ( ( nStartPPage + nWritePPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr		= ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
		pPageDW		= (unsigned int*)nPageBuffer;
	else
		pPageB		= (unsigned char*)nPageBuffer;

	// Set SpareBuffer Pointer =>> ECCBuffer
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
	{
		memset( gNAND_IO_ShareEccBuffer, 0xFF, nDevInfo->EccWholeDataSize );		
		pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
	}
	else
	{
		pSpareB		= (unsigned char*)nSpareBuffer;
		pSpareB 	+= NAND_IO_SPARE_SIZE_SMALL;
	}

	//=========================================================================
	// Empty Page ECCBuffer Pointer Increment
	//=========================================================================
	for ( j = 0; j < nStartPPage; ++j )
	{
		if ( nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
			pECC_Info = &gMLC_ECC_4Bit;
		else if ( nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
			pECC_Info = &gMLC_ECC_8Bit;
		else if ( nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
			pECC_Info = &gMLC_ECC_12Bit;
		else if ( nDevInfo->EccType == MLC_ECC_14BIT_TYPE )
			pECC_Info = &gMLC_ECC_14Bit;
		else if ( nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
			pECC_Info = &gMLC_ECC_16Bit;
		else
			return ERR_NAND_IO_WRONG_PARAMETER;

		if ( nDevInfo->Feature.MediaType  & A_MLC_16BIT )
		{
			pSpare = (unsigned char*)pSpareB;
			
			for ( i = 0; i < nDevInfo->EccDataSize; ++i )
				pSpare[i] = pECC_Info->All_FF_512_ECC_Code[i];
		}
		else
		{
		memcpy(	(void*)pSpareB, (void*)pECC_Info->All_FF_512_ECC_Code, nDevInfo->EccDataSize);
		}

		pSpareB += nDevInfo->EccDataSize;
	}

	//----------------------------------------------
	//	Write Data as 512Bytes repeatly
	//----------------------------------------------
	for ( j = 0; j < nWritePPSize; ++j )
	{
		/* Get Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

		//####################################################
		//#	Write 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )
		if (!( pNFC->NFC_CTRL1 & Hw30 ))
		{
		    if ( nEccOnOff == ECC_ON )
		    {
			    /* Setup ECC Block */
			    #if defined(_WINCE_) || defined(_LINUX_)
			    NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			    #else
			    NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_LDATA );
			    #endif
			    pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
			    pECC->ECC_CLEAR	= 0x00000000;
		    }
    
		    /* Write 512 Data Area */
		    BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
		    pNFC->NFC_DSIZE		= 512;
		    pNFC->NFC_IREQ 		= 0x77;	// pNFC->NFC_IREQ_FLAG1;		

			NAND_IO_IRQ_Mask();
		    pNFC->NFC_PSTART 	= 0;
		    
		    i = 128;
		    do {
			    while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
			    
			    if ( bAlignAddr )
			    {
				    pNFC->NFC_LDATA = *pPageDW;++pPageDW;
			    }	
			    else
			    {
				    uDWordByte.BYTE[0] = *pPageB;++pPageB;
				    uDWordByte.BYTE[1] = *pPageB;++pPageB;
				    uDWordByte.BYTE[2] = *pPageB;++pPageB;
				    uDWordByte.BYTE[3] = *pPageB;++pPageB;
				    pNFC->NFC_LDATA	= uDWordByte.DWORD;
			    }
		    }while(--i);
		    
		    while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
			NAND_IO_IRQ_UnMask();
		}
		else
		{
			if ( nEccOnOff == ECC_ON )
			{
				/* Setup ECC Block */
				#if defined(_WINCE_) || defined(_LINUX_)
				NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwDATA_PA );
				#else
				NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_WDATA );
				#endif
				pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
				pECC->ECC_CLEAR	= 0x00000000;
			}

			i = 128;
			do {
				
				if ( bAlignAddr )
				{
					pNFC->NFC_WDATA = *pPageDW;++pPageDW;
				}	
				else
				{
					uDWordByte.BYTE[0] = *pPageB;++pPageB;
					uDWordByte.BYTE[1] = *pPageB;++pPageB;
					uDWordByte.BYTE[2] = *pPageB;++pPageB;
					uDWordByte.BYTE[3] = *pPageB;++pPageB;
					pNFC->NFC_WDATA	= uDWordByte.DWORD;
				}
			}while(--i);
		}

		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )
		if ( nEccOnOff == ECC_ON )
		{
			/* Setup ECC Block */
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	= 0x00000000;
		}

		#if defined(_LINUX_) || defined(_WINCE_)
		NAND_IO_SetupDMA( (void*)pDataBuffer, 4, 0,
						  (void*)&NAND_IO_HwLDATA_PA, 0, 0,
						  NAND_IO_DMA_WRITE, 512 );
		#else
		NAND_IO_SetupDMA( (void*)pDataBuffer, 4, 0,
						  (void*)&pNFC->NFC_LDATA, 0, 0,
						  NAND_IO_DMA_WRITE, 512 );
		#endif
	
		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;

		#endif
		//####################################################
		//####################################################

		/*	Load ECC code from ECC block */
		if ( nEccOnOff == ECC_ON )
		{
			if ( nDevInfo->Feature.MediaType  & A_MLC_16BIT )
			{
				pSpare = (unsigned char*)pSpareB;
				pEccB = (unsigned char*)nECCBuffer;
				res = NAND_IO_EncodeECC( nDevInfo->EccType, pEccB );
				for ( i = 0; i < nDevInfo->EccDataSize; ++i )
					pSpare[i] = pEccB[i];
			}
			else
			{
			res = NAND_IO_EncodeECC( nDevInfo->EccType, pSpareB );
			}
			if ( res != SUCCESS )
				goto ErrorWrite512Data;
		}
		pSpareB += nDevInfo->EccDataSize;
	}

	//=========================================================================
	// Empty PPage Write
	//=========================================================================
	if ( ( nStartPPage + nWritePPSize ) != ( nDevInfo->PPages ) )
	{
		if ( nDevInfo->Feature.MediaType & A_BIG )
		{
			/* Change Cycle */
			NAND_IO_SetCommCycleTime();
			
			//---------------------------------
			// Random Data Input [ 0x85 ]
			//---------------------------------
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8585;

			//---------------------------------
			// Write Column Address
			//---------------------------------
			ColumnAddr = nDevInfo->Feature.PageSize;
			ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (ColumnAddr >> 1) : ColumnAddr;
			NAND_IO_WriteColAddr( ColumnAddr, nDevInfo );

			//---------------------------------
			// ECC Data Clear
			//---------------------------------
			for ( j = 0; j < (U16)( nDevInfo->PPages - ( nStartPPage + nWritePPSize ) ); ++j )
			{
				if ( nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
					pECC_Info = &gMLC_ECC_4Bit;
				else if ( nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
					pECC_Info = &gMLC_ECC_8Bit;
				else if ( nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
					pECC_Info = &gMLC_ECC_12Bit;
				else if ( nDevInfo->EccType == MLC_ECC_14BIT_TYPE )
					pECC_Info = &gMLC_ECC_14Bit;
				else if ( nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
					pECC_Info = &gMLC_ECC_16Bit;
				else
					return ERR_NAND_IO_WRONG_PARAMETER;

				if ( nDevInfo->Feature.MediaType  & A_MLC_16BIT )
				{
					pSpare = (unsigned char*)pSpareB;
			
					for ( i = 0; i < nDevInfo->EccDataSize; ++i )
						pSpare[i] = pECC_Info->All_FF_512_ECC_Code[i];
				}
				else
				{
				memcpy(	(void*)pSpareB, (void*)pECC_Info->All_FF_512_ECC_Code, nDevInfo->EccDataSize);
				}

				pSpareB += nDevInfo->EccDataSize;	
			}
		}
		else
		{
			memset( nDummyPageBuffer, 0xFF, 512 );
			//Write Dummy Data
			for ( j = 0; j < (U16)( nDevInfo->PPages - ( nStartPPage + nWritePPSize ) ); ++j )
			{
				//####################################################
				//#	Write 512 Page Data
				//####################################################
				//----------------------------------------------
				//	MCU ACCESS
				//----------------------------------------------
				#if defined( NAND_IO_USE_MCU_ACCESS )
				/* Setup ECC Block */
				if ( nEccOnOff == ECC_ON )
				{
					#if defined(_WINCE_) || defined(_LINUX_)
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
					#else
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_LDATA );
					#endif
					pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );		// Data Size...
					pECC->ECC_CLEAR	= 0x00000000;
				}

				/* Write 512 Data Area */
				BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
				pNFC->NFC_DSIZE	= 512;
				pNFC->NFC_IREQ = 0x77;	// pNFC->NFC_IREQ_FLAG1;		

				NAND_IO_IRQ_Mask();
				pNFC->NFC_PSTART = 0;
				
				i = 128;
				do
				{
					while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
					pNFC->NFC_LDATA = 0xFFFFFFFF;
				}while(--i);
				
				while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
				NAND_IO_IRQ_UnMask();
				
				//----------------------------------------------
				//	DMA ACCESS
				//----------------------------------------------
				#elif defined( NAND_IO_USE_DMA_ACCESS )
				/* Setup ECC Block */
				if ( nEccOnOff == ECC_ON )
				{
					#if defined(_WINCE_) || defined(_LINUX_)
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
					#else
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
					#endif
					pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );		// Data Size...
					pECC->ECC_CLEAR	= 0x00000000;
				}
				
				#if defined(_LINUX_) || defined(_WINCE_)
				NAND_IO_SetupDMA( (void*)nDummyPageBuffer, 4, 0,
								  (void*)&NAND_IO_HwLDATA_PA, 0, 0,
								  NAND_IO_DMA_WRITE, 512 );
				#else
				NAND_IO_SetupDMA( (void*)nDummyPageBuffer, 4, 0,
								  (void*)&pNFC->NFC_LDATA, 0, 0,
								  NAND_IO_DMA_WRITE, 512 );
				#endif

				#endif
				//####################################################
				//####################################################
				/*	Load ECC code from ECC block */
				if ( nEccOnOff == ECC_ON )
				{
					res = NAND_IO_EncodeECC( nDevInfo->EccType, pSpareB );
					if ( res != SUCCESS )
						goto ErrorWrite512Data;
				}
				
				pSpareB += nDevInfo->EccDataSize;		
			}			
		}
	}
	
	//=========================================================================
	// Write Spare Data
	//=========================================================================
	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	NAND_IO_WriteSpareData( nDevInfo, nSpareBuffer, PAGE_ECC_ON );

	//=========================================================================
	// Return
	//=========================================================================

ErrorWrite512Data:
	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_Write512DataMTD( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize,
*      													U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nEccOnOff	= 
*			nPageBuffer	= 
*			nSpareBuffer	= 
*			nStartPPage	= 
*			nWritePPSize	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
*  REMARK:	  by nemo
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_Write512DataMTD( NAND_IO_DEVINFO *nDevInfo, U16 nStartPPage, U16 nWritePPSize,
												       U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff )
{
	unsigned int		j;
	unsigned char		bAlignAddr;
	unsigned int		nECCDataSize = 8;
	#ifdef _LINUX_
	unsigned char 		nDummyPageBuffer[512]__attribute__((aligned(8)));
	#else
	unsigned char 		nDummyPageBuffer[512];
	#endif
	unsigned int		ColumnAddr;
	unsigned char		*pPageB = 0, *pSpareB = 0;
	unsigned int		*pPageDW = 0;
	unsigned char		*pDataBuffer;
	#ifdef NAND_IO_USE_MCU_ACCESS
	unsigned int		i;
	DWORD_BYTE			uDWordByte;
	#endif
	NAND_IO_ECC_INFO	*pECC_Info;	
	NAND_IO_ERROR		res;

	if ( ( nStartPPage + nWritePPSize ) > ( nDevInfo->Feature.PageSize >> 9 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr		= ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nEccOnOff == ECC_ON )
		NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );

	//=========================================================================
	// Get Buffer Pointer
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
		pPageDW		= (unsigned int*)nPageBuffer;
	else
		pPageB		= (unsigned char*)nPageBuffer;

	if (( nDevInfo->Feature.MediaType & A_MLC ) ||( nDevInfo->Feature.MediaType & A_SLC ))
		nECCDataSize = 8;
	else if ( ( nDevInfo->Feature.MediaType & A_MLC_8BIT ) || ( nDevInfo->Feature.MediaType & A_MLC_12BIT ) )
		nECCDataSize = 20;
	else if ( nDevInfo->Feature.MediaType & A_MLC_16BIT )
		nECCDataSize = 26;
		
	
	// Set SpareBuffer Pointer =>> ECCBuffer
	if ( ( nDevInfo->Feature.MediaType  & A_BIG ) || (( nDevInfo->Feature.MediaType  & A_SMALL ) && ( nDevInfo->Feature.MediaType  & A_PARALLEL )))
	{
		memset( gNAND_IO_ShareEccBuffer, 0xFF, nECCDataSize << 2 );		
		pSpareB		= (unsigned char*)&gNAND_IO_ShareEccBuffer[0];
	}
	else
	{
		pSpareB		= (unsigned char*)nSpareBuffer;
		pSpareB 	+= NAND_IO_SPARE_SIZE_SMALL;
	}

	//=========================================================================
	// Empty Page ECCBuffer Pointer Increment
	//=========================================================================
	for ( j = 0; j < nStartPPage; ++j )
	{
		if ( nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
			pECC_Info = &gMLC_ECC_4Bit;
		else if ( nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
			pECC_Info = &gMLC_ECC_8Bit;
		else if ( nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
			pECC_Info = &gMLC_ECC_12Bit;
		else if ( nDevInfo->EccType == MLC_ECC_14BIT_TYPE )
			pECC_Info = &gMLC_ECC_14Bit;
		else if ( nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
			pECC_Info = &gMLC_ECC_16Bit;
		else
			return ERR_NAND_IO_WRONG_PARAMETER;

		memcpy(	(void*)pSpareB, (void*)pECC_Info->All_FF_512_ECC_Code, nECCDataSize);

		pSpareB += nECCDataSize;
	}

	//----------------------------------------------
	//	Write Data as 512Bytes repeatly
	//----------------------------------------------
	for ( j = 0; j < nWritePPSize; ++j )
	{
		/* Get Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

		//####################################################
		//#	Write 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )
		if ( nEccOnOff == ECC_ON )
		{
			/* Setup ECC Block */
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	= 0x00000000;
		}

		/* Write 512 Data Area */
		BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
		pNFC->NFC_DSIZE		= 512;
		pNFC->NFC_IREQ 		= 0x77;	// pNFC->NFC_IREQ_FLAG1;		

		NAND_IO_IRQ_Mask();
		pNFC->NFC_PSTART 	= 0;
		
		i = 128;
		do {
			while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
			
			if ( bAlignAddr )
			{
				pNFC->NFC_LDATA = *pPageDW;++pPageDW;
			}	
			else
			{
				uDWordByte.BYTE[0] = *pPageB;++pPageB;
				uDWordByte.BYTE[1] = *pPageB;++pPageB;
				uDWordByte.BYTE[2] = *pPageB;++pPageB;
				uDWordByte.BYTE[3] = *pPageB;++pPageB;
				pNFC->NFC_LDATA	= uDWordByte.DWORD;
			}
		}while(--i);
		
		while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
		NAND_IO_IRQ_UnMask();

		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )
		if ( nEccOnOff == ECC_ON )
		{
			/* Setup ECC Block */
			#if defined(_WINCE_) || defined(_LINUX_)
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
			#else
			NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
			#endif
			pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );
			pECC->ECC_CLEAR	= 0x00000000;
		}

		#if defined(_LINUX_) || defined(_WINCE_)
		NAND_IO_SetupDMA( (void*)pDataBuffer, 4, 0,
						  (void*)&NAND_IO_HwLDATA_PA, 0, 0,
						  NAND_IO_DMA_WRITE, 512 );
		#else
		NAND_IO_SetupDMA( (void*)pDataBuffer, 4, 0,
						  (void*)&pNFC->NFC_LDATA, 0, 0,
						  NAND_IO_DMA_WRITE, 512 );
		#endif
	
		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;

		#endif
		//####################################################
		//####################################################

		/*	Load ECC code from ECC block */
		if ( nEccOnOff == ECC_ON )
		{
			res = NAND_IO_EncodeECC( nDevInfo->EccType, pSpareB );
			if ( res != SUCCESS )
				goto ErrorWrite512Data;
		}

		pSpareB += nECCDataSize;
	}

	//=========================================================================
	// Empty PPage Write
	//=========================================================================
	if ( ( nStartPPage + nWritePPSize ) != ( nDevInfo->PPages ) )
	{
		if ( nDevInfo->Feature.MediaType & A_BIG )
		{
			/* Change Cycle */
			NAND_IO_SetCommCycleTime();
			
			//---------------------------------
			// Random Data Input [ 0x85 ]
			//---------------------------------
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8585;

			//---------------------------------
			// Write Column Address
			//---------------------------------
			ColumnAddr = nDevInfo->Feature.PageSize;
			ColumnAddr	= ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT ) ? (ColumnAddr >> 1) : ColumnAddr;
			NAND_IO_WriteColAddr( ColumnAddr, nDevInfo );

			//---------------------------------
			// ECC Data Clear
			//---------------------------------
			for ( j = 0; j < (U16)( nDevInfo->PPages - ( nStartPPage + nWritePPSize ) ); ++j )
			{
				if ( nDevInfo->EccType == MLC_ECC_4BIT_TYPE )
					pECC_Info = &gMLC_ECC_4Bit;
				else if ( nDevInfo->EccType == MLC_ECC_8BIT_TYPE )
					pECC_Info = &gMLC_ECC_8Bit;
				else if ( nDevInfo->EccType == MLC_ECC_12BIT_TYPE )
					pECC_Info = &gMLC_ECC_12Bit;
				else if ( nDevInfo->EccType == MLC_ECC_14BIT_TYPE )
					pECC_Info = &gMLC_ECC_14Bit;
				else if ( nDevInfo->EccType == MLC_ECC_16BIT_TYPE )
					pECC_Info = &gMLC_ECC_16Bit;
				else
					return ERR_NAND_IO_WRONG_PARAMETER;

				memcpy(	(void*)pSpareB, (void*)pECC_Info->All_FF_512_ECC_Code, nECCDataSize);

				pSpareB += nECCDataSize;	
			}
		}
		else
		{
			memset( nDummyPageBuffer, 0xFF, 512 );
			//Write Dummy Data
			for ( j = 0; j < (U16)( nDevInfo->PPages - ( nStartPPage + nWritePPSize ) ); ++j )
			{
				//####################################################
				//#	Write 512 Page Data
				//####################################################
				//----------------------------------------------
				//	MCU ACCESS
				//----------------------------------------------
				#if defined( NAND_IO_USE_MCU_ACCESS )
				/* Setup ECC Block */
				if ( nEccOnOff == ECC_ON )
				{
					#if defined(_WINCE_) || defined(_LINUX_)
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
					#else
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_MCU_ACCESS, (U32)&pNFC->NFC_LDATA );
					#endif
					pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );		// Data Size...
					pECC->ECC_CLEAR	= 0x00000000;
				}

				/* Write 512 Data Area */
				BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
				pNFC->NFC_DSIZE	= 512;
				pNFC->NFC_IREQ = 0x77;	// pNFC->NFC_IREQ_FLAG1;		

				NAND_IO_IRQ_Mask();
				pNFC->NFC_PSTART = 0;
				
				i = 128;
				do
				{
					while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
					pNFC->NFC_LDATA = 0xFFFFFFFF;
				}while(--i);
				
				while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
				NAND_IO_IRQ_UnMask();
				
				//----------------------------------------------
				//	DMA ACCESS
				//----------------------------------------------
				#elif defined( NAND_IO_USE_DMA_ACCESS )
				/* Setup ECC Block */
				if ( nEccOnOff == ECC_ON )
				{
					#if defined(_WINCE_) || defined(_LINUX_)
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&NAND_IO_HwLDATA_PA );
					#else
					NAND_IO_SetupECC( (U16)nEccOnOff, ECC_ENCODE, nDevInfo->EccType, NAND_DMA_ACCESS, (U32)&pNFC->NFC_LDATA );
					#endif
					pECC->ECC_CTRL	|= ( 512 << ECC_SHIFT_DATASIZE );		// Data Size...
					pECC->ECC_CLEAR	= 0x00000000;
				}
				
				#if defined(_LINUX_) || defined(_WINCE_)
				NAND_IO_SetupDMA( (void*)nDummyPageBuffer, 4, 0,
								  (void*)&NAND_IO_HwLDATA_PA, 0, 0,
								  NAND_IO_DMA_WRITE, 512 );
				#else
				NAND_IO_SetupDMA( (void*)nDummyPageBuffer, 4, 0,
								  (void*)&pNFC->NFC_LDATA, 0, 0,
								  NAND_IO_DMA_WRITE, 512 );
				#endif

				#endif
				//####################################################
				//####################################################
				/*	Load ECC code from ECC block */
				if ( nEccOnOff == ECC_ON )
				{
					res = NAND_IO_EncodeECC( nDevInfo->EccType, pSpareB );
					if ( res != SUCCESS )
						goto ErrorWrite512Data;
				}

				pSpareB += nECCDataSize;		
			}			
		}
	}
	
	//=========================================================================
	// Write Spare Data
	//=========================================================================
	/* Change Cycle */
	NAND_IO_SetWriteCycleTime();

	NAND_IO_WriteSpareDataMTD( nDevInfo, nSpareBuffer, PAGE_ECC_ON );

	//=========================================================================
	// Return
	//=========================================================================

ErrorWrite512Data:
	return res;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_WriteUserSizeData( NAND_IO_DEVINFO *nDevInfo, U16 nColumnAddr, U32 nWriteSize, U8 *nWriteBuffer );
*  
*  DESCRIPTION : 
*  INPUT:
*			nColumnAddr	= 
*			nDevInfo	= 
*			nWriteBuffer	= 
*			nWriteSize	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_WriteUserSizeData( NAND_IO_DEVINFO *nDevInfo, U16 nColumnAddr, U32 nWriteSize, U8 *nWriteBuffer )
{
	unsigned int		*dwPageB;
	unsigned char		*pPageB;
	DWORD_BYTE			uDWordByte;
	
	//=========================================================================
	// Initial Setting
	//=========================================================================
	NAND_IO_SetupECC( ECC_OFF, 0, 0, 0, 0 );
	
	//=========================================================================
	// Check Parameter
	//=========================================================================
	if ( (U32)( nColumnAddr + nWriteSize ) > (U32)( nDevInfo->Feature.PageSize + nDevInfo->Feature.SpareSize ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Write UserSize Data
	//=========================================================================
	pPageB = (unsigned char*)nWriteBuffer;
	dwPageB = (unsigned int*)nWriteBuffer;

	//if ( nWriteSize >= 4 )
	//{
	//	#ifdef USE_NFC_LDATA		/* 08.12.17 */
	//	BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
	//	pNFC->NFC_DSIZE		= nWriteSize;
	//	pNFC->NFC_IREQ	 	= 0x77;	// pNFC->NFC_IREQ_FLAG1;
	//	pNFC->NFC_PSTART 	= 0;		
	//
	//	do {
	//		while (!( pNFC->NFC_IREQ & HwNFC_CTRL_FS_RDY ));
	//		
	//		{
	//			uDWordByte.BYTE[0] = *pPageB;++pPageB;
	//			uDWordByte.BYTE[1] = *pPageB;++pPageB;
	//			uDWordByte.BYTE[2] = *pPageB;++pPageB;
	//			uDWordByte.BYTE[3] = *pPageB;++pPageB;
	//			pNFC->NFC_LDATA	= uDWordByte.DWORD;
	//		}
	//		nWriteSize -= 4;
	//	}while(nWriteSize);
	//	
	//	while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));		
	//}
	//else
	//{
	//	#endif
		while ( nWriteSize )
		{
			/* Write as DWORD */
			if ( nWriteSize >= 4 )
			{
				uDWordByte.BYTE[0] = *pPageB;++pPageB;
				uDWordByte.BYTE[1] = *pPageB;++pPageB;
				uDWordByte.BYTE[2] = *pPageB;++pPageB;
				uDWordByte.BYTE[3] = *pPageB;++pPageB;
				WORD_OF(pNFC->NFC_WDATA) = uDWordByte.DWORD;
				nWriteSize -= 4;
			}
			/* Write as WORD */
			else if ( nWriteSize >= 2 )
			{
				uDWordByte.BYTE[0] = *pPageB;++pPageB;
				uDWordByte.BYTE[1] = *pPageB;++pPageB;
				HWORD_OF(pNFC->NFC_WDATA) = uDWordByte.WORD[0];
				nWriteSize -= 2;
			}
			/* Write as BYTE */			
			else
			{
				uDWordByte.BYTE[0] = *pPageB;++pPageB;
				BYTE_OF(pNFC->NFC_WDATA) = uDWordByte.BYTE[0];
				nWriteSize -= 1;
			}
		}
	//}

	//=========================================================================
	// Return
	//=========================================================================
	return (NAND_IO_ERROR)SUCCESS;

}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline NAND_IO_ERROR NAND_IO_GetShiftValueForFastMultiPly( U16 nValue, U16* rFactor );
*  
*  DESCRIPTION : 
*  INPUT:
*			nValue	= 
*			rFactor	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_GetShiftValueForFastMultiPly( U16 nValue, U16* rFactor )
{
	unsigned short int	i;

	*rFactor = 0;
	
	for ( i = 0; i < NAND_IO_MAX_SHIFT_FACTOR_FOR_MULTIPLY; ++i )
	{
		if ( NAND_IO_ShiftFactorForMultiplay[i] == nValue )
		{
			*rFactor = i;
			break;
		}
	}

	if ( i >= NAND_IO_MAX_SHIFT_FACTOR_FOR_MULTIPLY )
		return ERR_NAND_IO_FAILED_GET_SHIFT_FACTOR_FOR_MULTIPLY;

	return (NAND_IO_ERROR)SUCCESS;	
}	

#if defined (NAND_LBA_INCLUDE)
NAND_IO_ERROR NAND_IO_LBA_SetCallBackHandler( NAND_LBA_CALLBACK_HANDLER pCallBackHandler )
{
	NAND_IO_LBA_CallBackLcdDisplay = pCallBackHandler;

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_GetDeviceInfo( U16 nChipNo, NAND_IO_DEVINFO *nDevInfo )
{
	unsigned short int		j,k,l;
	unsigned char			bFindMedia;
	unsigned char			bFindMakerNo;
	unsigned char			bMatchCount;
	unsigned char			rBootMode, rRebootCmd;
	NAND_IO_DEVID			sDeviceCode;
	NAND_IO_FEATURE			*sTempFeatureInfo;
	NAND_IO_FEATURE			*sFindFeatureInfo;
	NAND_IO_ERROR			res;

	bFindMedia 				= FALSE;
	sTempFeatureInfo		= (NAND_IO_FEATURE*)LBA_NAND_SupportMakerInfo.DevInfo[0];
	sFindFeatureInfo		= (NAND_IO_FEATURE*)LBA_NAND_SupportMakerInfo.DevInfo[0];

	NAND_IO_LBA_DeviceReboot( nDevInfo );
 	res = NAND_IO_GetDeviceInfo( 0, nDevInfo );
	if ( res != SUCCESS )
		return ERR_NAND_IO_FAILED_GET_DEVICE_INFO;

	if (!( nDevInfo->Feature.MediaType & S_LBA ))
		return ERR_NAND_IO_FAILED_GET_DEVICE_INFO;

	res = NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_BCM );
	if ( res != SUCCESS )
	{
		NAND_IO_LBA_DeviceReboot( nDevInfo );
		res = NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_BCM );
		if ( res != SUCCESS )
			return res;
	}
	
	NAND_IO_LBA_GetPersistentFunction( nDevInfo, &rBootMode, &rRebootCmd );

	if ( ( rBootMode != 0x22 ) || ( rRebootCmd != 0xAF ))
	{
		rBootMode = 0x22;
		rRebootCmd = 0xAF;

		NAND_IO_LBA_SetBootModeChange( nDevInfo, rBootMode );
		NAND_IO_LBA_SetRebootCmdChange( nDevInfo, rRebootCmd );		
		NAND_IO_LBA_DeviceReboot( nDevInfo );
	}

	NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_MDP );
	NAND_IO_LBA_SetTransferProtocol( nDevInfo, 0x04, 0x00 );
	
	nDevInfo->LBAInfo.Usable = DISABLE;
	//=====================================================================
	// Search Matched NANDFLASH
	//=====================================================================
	for ( j = 0; j < 3; ++j )	/* Check Read ID during 3 turn */
	{
		/* Read Device CODE */
		NAND_IO_LBA_ReadID( nDevInfo, &sDeviceCode);

		/* Check Maker ID */
		bFindMakerNo = 0xFF;
		for ( k = 0; k < MAX_SUPPORT_MAKER_LBA_NAND; ++k )
		{
			if ( sDeviceCode.Code[0] == LBA_NAND_SupportMakerInfo.MakerID[k] )
			{
				bFindMakerNo		= (unsigned char)k;
				sTempFeatureInfo	= (NAND_IO_FEATURE*)LBA_NAND_SupportMakerInfo.DevInfo[k];
				break;
			}
		}

		if ( bFindMakerNo >= MAX_SUPPORT_MAKER_NAND )
			continue;

		/* Check Device ID */
		for ( k = 0; k < LBA_NAND_SupportMakerInfo.MaxSupportNAND[bFindMakerNo]; ++k )
		{
			bMatchCount = 0;
			
			for ( l = 0; l < 4; ++l )
			{
				if ( sTempFeatureInfo->DeviceID.Code[l+1] == 0x00 )
					++bMatchCount;
				else if ( sDeviceCode.Code[l+1] == sTempFeatureInfo->DeviceID.Code[l+1] )
					++bMatchCount;
			}

			/* Found NAND Device */
			if ( bMatchCount >= 4 )
			{
				bFindMedia = TRUE;
				sFindFeatureInfo = sTempFeatureInfo;
				break;
			}
			else
				++sTempFeatureInfo;
		}

		/* Found NAND Device */
		if ( bFindMedia == TRUE )
			break;
	}

	if ( bFindMedia == TRUE )
		return (NAND_IO_ERROR)SUCCESS;
	//=====================================================================
	// Not Found
	//=====================================================================
	else
		return ERR_NAND_IO_FAILED_GET_DEVICE_INFO;
}

NAND_IO_ERROR NAND_IO_LBA_Init( U16 nChipNo, NAND_IO_DEVINFO *nDevInfo )
{
	unsigned short int		j,k,l;
	unsigned char			bFindMedia;
	unsigned char			bFindMakerNo;
	unsigned char			bMatchCount;
	unsigned char			rBootMode, rRebootCmd;
	NAND_IO_DEVID			sDeviceCode;
	NAND_IO_FEATURE			*sTempFeatureInfo;
	NAND_IO_FEATURE			*sFindFeatureInfo;
	NAND_IO_ERROR			res;
	
	bFindMedia 				= FALSE;

	nDevInfo->ChipNo = nChipNo;
	NAND_IO_LBA_DeviceReboot( nDevInfo );
 	NAND_IO_GetDeviceInfo( nChipNo, nDevInfo );

	res = NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_BCM );
	if ( res != SUCCESS )
	{
		NAND_IO_LBA_DeviceReboot( nDevInfo );
		res = NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_BCM );
		if ( res != SUCCESS )
			return res;
	}
	
	NAND_IO_LBA_GetPersistentFunction( nDevInfo, &rBootMode, &rRebootCmd );

	if ( ( rBootMode != 0x22 ) || ( rRebootCmd != 0xAF ))
	{
		rBootMode = 0x22;
		rRebootCmd = 0xAF;

		NAND_IO_LBA_SetBootModeChange( nDevInfo, rBootMode );
		NAND_IO_LBA_SetRebootCmdChange( nDevInfo, rRebootCmd );		
		NAND_IO_LBA_DeviceReboot( nDevInfo );
	}

	NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_MDP );
	NAND_IO_LBA_SetTransferProtocol( nDevInfo, NAND_PROT1_512x1, 0x00 );
	NAND_IO_LBA_GetTransferProtocol( nDevInfo, &nDevInfo->LBAInfo.TransProtocol1, &nDevInfo->LBAInfo.TransProtocol2 );

	if ( nDevInfo->LBAInfo.TransProtocol1 & NAND_PROT1_SPARE_INCLUDE )
		nDevInfo->LBAInfo.DataTransferCheck = ENABLE;
	else
		nDevInfo->LBAInfo.DataTransferCheck = DISABLE;

	nDevInfo->LBAInfo.SectorCount = ( nDevInfo->LBAInfo.TransProtocol1 & NAND_PROT1_SECTOR_COUNT_MASK );

	if ( nDevInfo->LBAInfo.SectorCount != 1 )
		nDevInfo->LBAInfo.SectorCount = nDevInfo->LBAInfo.SectorCount << 1;
	
	nDevInfo->LBAInfo.Usable = DISABLE;
	//=====================================================================
	// Search Matched NANDFLASH
	//=====================================================================
	for ( j = 0; j < 3; ++j )	/* Check Read ID during 3 turn */
	{
		/* Read Device CODE */
		NAND_IO_LBA_ReadID( nDevInfo, &sDeviceCode);

		/* Check Maker ID */
		bFindMakerNo = 0xFF;
		for ( k = 0; k < MAX_SUPPORT_MAKER_LBA_NAND; ++k )
		{
			if ( sDeviceCode.Code[0] == LBA_NAND_SupportMakerInfo.MakerID[k] )
			{
				bFindMakerNo		= (unsigned char)k;
				sTempFeatureInfo	= (NAND_IO_FEATURE*)LBA_NAND_SupportMakerInfo.DevInfo[k];
				break;
			}
		}

		if ( bFindMakerNo >= MAX_SUPPORT_MAKER_NAND )
			continue;

		/* Check Device ID */
		for ( k = 0; k < LBA_NAND_SupportMakerInfo.MaxSupportNAND[bFindMakerNo]; ++k )
		{
			bMatchCount = 0;
			
			for ( l = 0; l < 4; ++l )
			{
				if ( sTempFeatureInfo->DeviceID.Code[l+1] == 0x00 )
					++bMatchCount;
				else if ( sDeviceCode.Code[l+1] == sTempFeatureInfo->DeviceID.Code[l+1] )
					++bMatchCount;
			}

			/* Found NAND Device */
			if ( bMatchCount >= 4 )
			{
				bFindMedia = TRUE;
				sFindFeatureInfo = sTempFeatureInfo;
				break;
			}
			else
				++sTempFeatureInfo;
		}

		/* Found NAND Device */
		if ( bFindMedia == TRUE )
			break;
	}

	if ( bFindMedia == TRUE )
	{
		// Get UniqueID
		//NAND_IO_LBA_ReadUID( nDevInfo );
        
		NAND_IO_LBA_SetTransferProtocol( nDevInfo, NAND_PROT1_512x8, ( NAND_PROT2_WRITE_TYPE_B | NAND_PROT2_READ_TYPE_A ) );
		NAND_IO_LBA_GetTransferProtocol( nDevInfo, &nDevInfo->LBAInfo.TransProtocol1, &nDevInfo->LBAInfo.TransProtocol2 );

		// Data Format
		if ( nDevInfo->LBAInfo.TransProtocol1 & NAND_PROT1_SPARE_INCLUDE )
			nDevInfo->LBAInfo.DataTransferCheck = ENABLE;
		else
			nDevInfo->LBAInfo.DataTransferCheck = DISABLE;

		// Sector Count
		nDevInfo->LBAInfo.SectorCount = ( nDevInfo->LBAInfo.TransProtocol1 & NAND_PROT1_SECTOR_COUNT_MASK );

		if ( nDevInfo->LBAInfo.SectorCount != 1 )
			nDevInfo->LBAInfo.SectorCount = nDevInfo->LBAInfo.SectorCount << 1;
		
		NAND_IO_LBA_VFPGetTotalSectorSize( nDevInfo, &nDevInfo->LBAInfo.VFPSectorSize );
		if ( ( nDevInfo->LBAInfo.VFPSectorSize << 9 ) < gMAX_ROMSIZE )
		{
			// LBA Factory Setting values : 8 Mbyte
			res = NAND_IO_LBA_VFPChangeSectorSize( nDevInfo, gMAX_ROMSIZE >> 9 );
			if ( res != SUCCESS )
				return res;

			NAND_IO_LBA_VFPGetTotalSectorSize( nDevInfo, (U32 *)&nDevInfo->LBAInfo.VFPSectorSize );		
		}

		// Get Size Info
		NAND_IO_LBA_MDPGetTotalSectorSize( nDevInfo, (unsigned long int *)&nDevInfo->LBAInfo.MDPSectorSize );

		res = NAND_IO_LBA_VFPInitArea( nDevInfo );
		if ( res != SUCCESS )
			return res;

		nDevInfo->LBAInfo.Usable = ENABLE;		
		
		NAND_IO_LBA_SetAreaPartition( nDevInfo, sFindFeatureInfo );
		NAND_IO_LBA_PowerSaveMode( nDevInfo, ENABLE );
	}
	//=====================================================================
	// Not Found
	//=====================================================================
	else
	{
		return ERR_NAND_IO_FAILED_GET_DEVICE_INFO;
	}

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_InitDrive( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int 		i;

	gLBACSNums = 0;

	for( i  = NAND_IO_DRV0_START_CS; i < NAND_IO_DRV0_END_CS + 1; ++i )
	{
		if ( NAND_IO_LBA_Init( i, &nDevInfo[i] ) == SUCCESS )
		{
			++gLBACSNums;
			NAND_IO_LBA_PowerSaveMode( &nDevInfo[i], DISABLE );
			NAND_IO_LBA_HighSpeedMode( &nDevInfo[i], ENABLE );
		}
        else
		{
			if ( i == 0 )
				return ERR_LBA_NOT_EXIST_NANDFLASH;
		}
	}	
	
	if ( gLBACSNums > LBA_MAX_SUPPORT_MULTI_NANDFLASH )
		return ERR_LBA_NOT_EXIST_MEDIA_NUM_INFO;
	
	return SUCCESS;
}

U32 NAND_IO_LBA_GetSerialNumber( NAND_IO_DEVINFO *nDevInfo, U8* nPageBuffer, U8* rSerialNumber, U16 nSize )
{
	unsigned int		i;
	unsigned short int	wSizeOfSID;
	unsigned char		ucPage[512];
	unsigned char		*cPageBuffer;
	unsigned char		*cSpareBuffer;
	
	NAND_IO_ERROR		res;

	cPageBuffer		= &nPageBuffer[0];
	cSpareBuffer	= &nPageBuffer[nDevInfo->Feature.PageSize];

	res = NAND_IO_LBA_ModeChange( &nDevInfo[0], NAND_LBA_BCM );	
	if ( res != SUCCESS )
	{
		NAND_IO_LBA_DeviceReboot( nDevInfo );
		res = NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_BCM );
		if ( res != SUCCESS )
			return res;
	}

	res = NAND_IO_ReadPage( nDevInfo, 0, 0, 4, cPageBuffer, cSpareBuffer, ECC_OFF );
	if ( res != SUCCESS)
		return ERR_NAND_IO_WRONG_PARAMETER;
	
	if (  nDevInfo[0].Feature.MediaType & A_PARALLEL )
		memcpy( ucPage, &cPageBuffer[ ( 512 + 16 ) * ( nDevInfo[0].PPages - 2 ) ], 512 );
	else
		memcpy( ucPage, &cPageBuffer[ ( 512 + 16 ) * ( nDevInfo[0].PPages - 1 ) ], 512 );

	//=====================================================
	// Check and Get Serial Number ID
	//=====================================================
	/* Get Signature to get sizes of serial number ID */
	if (!memcmp( &ucPage[20], "ZERO", 4 ))
		wSizeOfSID		= 16;
	else if ((!memcmp( &ucPage[20], "FWDN", 4 )) || (!memcmp( &ucPage[20], "GANG", 4 )))
		wSizeOfSID		= 32;
	else
		wSizeOfSID		= 0;
	
	for ( i = 0; i < ( wSizeOfSID >> 4 ); ++i )
		memcpy( &rSerialNumber[i*16], &ucPage[i*32], 16 );

	return wSizeOfSID;		
}

NAND_IO_ERROR NAND_IO_LBA_GetTotalSecAndCHS( NAND_IO_DEVINFO *nDevInfo, int nPartition, U32 *rTotalSec, U16 *rCylinder, U16 *rHead, U8 *rSector )
{
	unsigned short int		i;
	unsigned short int		wCurrHead;
	unsigned short int		wCurrCylinder;
	unsigned long int		nTotalSectorSize;

	nTotalSectorSize = 0;

	if ( nPartition == NAND_LBA_DATA_AREA )
	{
		for ( i = 0; i < gLBACSNums; ++i )
			nTotalSectorSize += nDevInfo[i].LBAInfo.DTAreaSectorSize;
	}
	else if ( nPartition == NAND_LBA_HIDDEN_AREA )
	{
		for ( i = 0; i < gLBACSNums; ++i )
			nTotalSectorSize += nDevInfo[i].LBAInfo.HDAreaSectorSize;
	}
	else if ( nPartition == NAND_LBA_MULTI_HIDDEN_AREA_0 )
	{
		nTotalSectorSize = nDevInfo[0].LBAInfo.MHDAreaSectorSize[0];
	}
	else if ( nPartition == NAND_LBA_MDP )
	{
		for ( i = 0; i < gLBACSNums; ++i )
			nTotalSectorSize += nDevInfo[i].LBAInfo.MDPSectorSize;
	}
	else if ( nPartition == NAND_LBA_VFP )
	{
		for ( i = 0; i < gLBACSNums; ++i )
			nTotalSectorSize += nDevInfo[i].LBAInfo.VFPSectorSize;
	}

	if ( nTotalSectorSize == 0 )
	{
	    *rTotalSec	= 0;
	    *rCylinder	= 0;
	    *rHead		= 0;
	    *rSector	= 0;
		
		return (NAND_IO_ERROR)SUCCESS;
	}
		
	if  ( nTotalSectorSize >= (U32)( 1024 * 256 * 64 ) )
	{
	    *rTotalSec	= nTotalSectorSize;
	    *rCylinder	= (U16)(nTotalSectorSize / ( 256 * 64 ));
	    *rHead		= 256;
	    *rSector	= 64;
	}
	else
	{
		for ( wCurrHead = 2; wCurrHead <= 256; wCurrHead *= 2 )
		{
			wCurrCylinder = (U16)(nTotalSectorSize / ( wCurrHead * 64 ));

			if ( wCurrCylinder > 1024 )
				continue;

			*rTotalSec	= (U32)( wCurrCylinder * wCurrHead * 64 );
			*rCylinder	= wCurrCylinder;
			*rHead		= wCurrHead;
			*rSector	= 64;

			break;
		}
	}

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_ReadSectorBy4Byte( NAND_IO_DEVINFO *nDevInfo, U8 nPartition, U32 nSectorAddr, U16 nOffset, U16 nReadSize, U8 *nReadBuffer )
{
	unsigned short int		wCSorder;
	unsigned short int		wCurrPPSize, rConvertSize;
	unsigned short int		wFlagFirstSector;
	unsigned long int 		dwSectorAddr, rConvertAddr;
	unsigned long int		dwTotalReadSecSize;
	unsigned char			cReadBuffer[512];
	unsigned char			cSpareBuffer[16];
	unsigned char			*pReadBuffer;
	unsigned char			cPartition;	
	NAND_IO_ERROR			res;

	//######################################################
	//# Get Info of Parameter
	//######################################################
	dwSectorAddr		= nSectorAddr;
	dwTotalReadSecSize  = 1;

	res = NAND_IO_LBA_ConvertMPPA( nDevInfo, nPartition, dwSectorAddr, dwTotalReadSecSize, &rConvertAddr, &rConvertSize, &wCSorder );
	if ( res != SUCCESS )
			return res;

	cPartition = nPartition & 0x0F;

	if ( nDevInfo[wCSorder].LBAInfo.CurrentMode != cPartition )
		NAND_IO_LBA_ModeChange( &nDevInfo[wCSorder], cPartition );
	
	if (( !nReadSize ) || (( nOffset + nReadSize ) > 128 ))
		return ERR_NAND_IO_WRONG_PARAMETER;
	
	//######################################################
	//# Set High Speed Mode 
	//######################################################
	NAND_IO_LBA_PowerSaveMode( &nDevInfo[wCSorder], DISABLE );
	NAND_IO_LBA_HighSpeedMode( &nDevInfo[wCSorder], ENABLE );

	pReadBuffer			= nReadBuffer;

	wFlagFirstSector = TRUE;
	
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetCommCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo[wCSorder].ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo[wCSorder].Feature.MediaType & A_PARALLEL )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( dwTotalReadSecSize < nDevInfo[wCSorder].LBAInfo.SectorCount )
		wCurrPPSize = dwTotalReadSecSize;
	else
		wCurrPPSize = nDevInfo[wCSorder].LBAInfo.SectorCount;
	
	//######################################################
	//# Write Total Sector
	//######################################################
	pNFC->NFC_CMD = nDevInfo[wCSorder].CmdMask & 0x0000;

		if ( wFlagFirstSector == TRUE )
		{
			/* Write Sector Size & Sector Address */
		pNFC->NFC_SADDR= ( (	wCurrPPSize		   ) & 0xFF );	// Write Sector Num : SC0
		pNFC->NFC_SADDR= ( ( wCurrPPSize  >> 8  ) & 0xFF );	// Write Sector Num : SC1
		pNFC->NFC_SADDR= ( ( rConvertAddr 	   ) & 0xFF );	// Write Sector Addr: AD0
		pNFC->NFC_SADDR= ( ( rConvertAddr >> 8  ) & 0xFF );	// Write Sector Addr: AD1
		pNFC->NFC_SADDR= ( ( rConvertAddr >> 16 ) & 0xFF );	// Write Sector Addr: AD2
		pNFC->NFC_SADDR= ( ( rConvertAddr >> 24 ) & 0xFF );	// Write Sector Addr: AD3
		}

		/* Command Page Program #2 [ 0x10 ] */
		pNFC->NFC_CMD = nDevInfo[wCSorder].CmdMask & 0x3030;
		/* Wait until it is ready */
		NAND_IO_WaitBusy( nDevInfo[wCSorder].ChipNo );

		NAND_IO_SetReadCycleTime();
		/* Write Data to NAND FLASH */
	res = NAND_IO_LBA_ReadData( &nDevInfo[wCSorder], wCurrPPSize, cReadBuffer, cSpareBuffer );
		if ( res != SUCCESS )
			return res;

		NAND_IO_SetCommCycleTime();

	memcpy( pReadBuffer, &cReadBuffer[nOffset << 2], nReadSize << 2 );

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
	//######################################################
	//# Set Power Save Mode 
	//######################################################
	NAND_IO_LBA_PowerSaveMode( &nDevInfo[wCSorder], ENABLE );
	
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_ReadSector( NAND_IO_DEVINFO *nDevInfo, U8 nPartition, U32 nSectorAddr, U16 nSecSize, U8 *nReadBuffer )
{
	unsigned short int		wCSorder;
	unsigned short int		wCurrPPSize, rConvertSize;
	unsigned short int		wFlagFirstSector;
	unsigned long int 		dwSectorAddr, rConvertAddr;
	unsigned long int		dwTotalReadSecSize;
	unsigned char			cPartition;
	unsigned char			cSpareBuffer[16];
	NAND_IO_ERROR			res;

	//######################################################
	//# Get Info of Parameter
	//######################################################
	dwSectorAddr		= nSectorAddr;
	dwTotalReadSecSize  = nSecSize;

	while ( dwTotalReadSecSize )
	{	
		res = NAND_IO_LBA_ConvertMPPA( nDevInfo, nPartition, dwSectorAddr, dwTotalReadSecSize, &rConvertAddr, &rConvertSize, &wCSorder );
		if ( res != SUCCESS )
			return res;
		
		rConvertSize = dwTotalReadSecSize;	// nemo
		
		//######################################################
	//# Check Parameter
	//######################################################
		if ( nDevInfo[wCSorder].LBAInfo.Usable != ENABLE )
		return ERR_NAND_IO_WRONG_PARAMETER;

	cPartition = nPartition & 0x0F;

		if ( nDevInfo[wCSorder].LBAInfo.CurrentMode != cPartition )
	{
			res = NAND_IO_LBA_ModeChange( &nDevInfo[wCSorder], cPartition );
			if ( res != SUCCESS )
	{
				NAND_IO_LBA_DeviceReboot( &nDevInfo[wCSorder]);
				NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_MDP );
				NAND_IO_LBA_SetTransferProtocol( &nDevInfo[wCSorder], NAND_PROT1_512x8, ( NAND_PROT2_WRITE_TYPE_B | NAND_PROT2_READ_TYPE_A ) );				
				res = NAND_IO_LBA_ModeChange( &nDevInfo[wCSorder], cPartition );
				if ( res != SUCCESS )
					return res;
	}
	}
	
		//######################################################
		//# Set High Speed Mode 
		//######################################################		
		//NAND_IO_LBA_PowerSaveMode( &nDevInfo[wCSorder], DISABLE );
		//NAND_IO_LBA_HighSpeedMode( &nDevInfo[wCSorder], ENABLE );

	wFlagFirstSector = TRUE;
	
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetCommCycleTime();

	/* Enable Chip Select */
		NAND_IO_EnableChipSelect( nDevInfo[wCSorder].ChipNo );

	/* Set Data Bus as 16Bit */
		if ( nDevInfo[wCSorder].Feature.MediaType & A_PARALLEL )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

		if ( rConvertSize < nDevInfo[wCSorder].LBAInfo.SectorCount )
			wCurrPPSize = rConvertSize;
		else
			wCurrPPSize = nDevInfo[wCSorder].LBAInfo.SectorCount;

		/* Decrease Write Size */
		dwSectorAddr		+= rConvertSize;
		dwTotalReadSecSize  -= rConvertSize;
	
	//######################################################
	//# Write Total Sector
	//######################################################
		while ( rConvertSize )
	{	
		/* Command Page Program #1 [ 0x80 ] */
			pNFC->NFC_CMD = nDevInfo[wCSorder].CmdMask & 0x0000;

		if ( wFlagFirstSector == TRUE )
		{
			/* Write Sector Size & Sector Address */
				pNFC->NFC_SADDR= ( ( rConvertSize 	    ) & 0xFF );		// Write Sector Num : SC0
				pNFC->NFC_SADDR= ( ( rConvertSize >> 8   ) & 0xFF );		// Write Sector Num : SC1
				pNFC->NFC_SADDR= ( ( rConvertAddr 		) & 0xFF );		// Write Sector Addr: AD0
				pNFC->NFC_SADDR= ( ( rConvertAddr >> 8 	) & 0xFF );		// Write Sector Addr: AD1
				pNFC->NFC_SADDR= ( ( rConvertAddr >> 16 	) & 0xFF );		// Write Sector Addr: AD2
				pNFC->NFC_SADDR= ( ( rConvertAddr >> 24 	) & 0xFF );		// Write Sector Addr: AD3

				if ( nDevInfo[wCSorder].LBAInfo.TransProtocol2 & NAND_PROT2_READ_TYPE_B )				
					wFlagFirstSector = FALSE;
		}

		/* Command Page Program #2 [ 0x10 ] */
			pNFC->NFC_CMD = nDevInfo[wCSorder].CmdMask & 0x3030;
		
		/* Wait until it is ready */
			NAND_IO_LBA_WaitBusy( nDevInfo[wCSorder].ChipNo );

		NAND_IO_SetReadCycleTime();
		/* Write Data to NAND FLASH */
			res = NAND_IO_LBA_ReadData( &nDevInfo[wCSorder], wCurrPPSize, nReadBuffer, cSpareBuffer );
		if ( res != SUCCESS )
			return res;

		NAND_IO_SetCommCycleTime();

			rConvertAddr		+= wCurrPPSize;
			rConvertSize		-= wCurrPPSize;

		/* Increase Buffer Address */
			nReadBuffer			+= ( wCurrPPSize << 9 );
		
		/* Count Next Page Size */
			if ( rConvertSize < nDevInfo[wCSorder].LBAInfo.SectorCount )
				wCurrPPSize = rConvertSize;
		else
				wCurrPPSize = nDevInfo[wCSorder].LBAInfo.SectorCount;
	}

		pNFC->NFC_CMD = nDevInfo[wCSorder].CmdMask & 0xFBFB;
		NAND_IO_WaitBusy( nDevInfo[wCSorder].ChipNo );

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

		//######################################################
		//# Set Power Save Mode 
		//######################################################
		//NAND_IO_LBA_PowerSaveMode( &nDevInfo[wCSorder], ENABLE );
	}
	
	return SUCCESS;
}

	
NAND_IO_ERROR NAND_IO_LBA_AREAClear( NAND_IO_DEVINFO *nDevInfo, U8 nPartition )
{
	unsigned short int 		i;
	unsigned int			nSectorAddr;
	unsigned short int		wCurrPPSize;
	unsigned short int		wFlagFirstSector;

	unsigned short int		wOldProcessRate;		
	unsigned short int		wProcessRate;
	unsigned long int		nProCessWriteSectorSize;

	unsigned long int 		dwSectorAddr;
	unsigned long int		dwSectorAddrOffSet;
	unsigned short int		wOnceWriteSectorCount;
	unsigned long int		dwTotalWriteSecSize;
	unsigned long int		nTotalSectorSize;
	unsigned long int		nWriteSectorSize;
	unsigned char			cPartition;
	NAND_IO_ERROR			res;

	for ( i = 0; i < gLBACSNums; ++i )
	{
		NAND_IO_LBA_Init( i, &nDevInfo[i] );
		
	//######################################################
	//# Check Parameter
	//######################################################
		if ( nDevInfo[i].LBAInfo.Usable != ENABLE )
		return ERR_NAND_IO_WRONG_PARAMETER;

	cPartition = nPartition & 0x0F;

		if ( nDevInfo[i].LBAInfo.CurrentMode != cPartition )
			NAND_IO_LBA_ModeChange( &nDevInfo[i], cPartition );

		//######################################################
		//# Set High Speed Mode 
		//######################################################
		NAND_IO_LBA_PowerSaveMode( &nDevInfo[i], DISABLE );
		NAND_IO_LBA_HighSpeedMode( &nDevInfo[i], ENABLE );

	if ( nPartition == NAND_LBA_DATA_AREA )
	{
			nTotalSectorSize 	= nDevInfo[i].LBAInfo.DTAreaSectorSize;
			dwSectorAddrOffSet 	= nDevInfo[i].LBAInfo.DTAreaAddrOffSet;
	}
	else if ( nPartition == NAND_LBA_HIDDEN_AREA )
	{
			nTotalSectorSize 	= nDevInfo[i].LBAInfo.HDAreaSectorSize;
			dwSectorAddrOffSet 	= nDevInfo[i].LBAInfo.HDAreaAddrOffSet;
	}
	else if ( nPartition == NAND_LBA_MULTI_HIDDEN_AREA_0 )
	{
			nTotalSectorSize 	= nDevInfo[i].LBAInfo.MHDAreaSectorSize[0];
			dwSectorAddrOffSet 	= nDevInfo[i].LBAInfo.MHDAreaAddrOffSet[0];
	}
	else if ( nPartition == NAND_LBA_MDP )
	{
			nTotalSectorSize 	= nDevInfo[i].LBAInfo.MDPSectorSize;
		dwSectorAddrOffSet 	= 0;
	}
	else if ( nPartition == NAND_LBA_VFP )
	{
			nTotalSectorSize 	= nDevInfo[i].LBAInfo.VFPSectorSize;
			dwSectorAddrOffSet 	= NAND_LBA_SYS_SECTION;
	}

	// Set Area Clear Sector Address, Size
	nSectorAddr = 0;

	wFlagFirstSector = TRUE;
	
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetCommCycleTime();

	/* Enable Chip Select */
		NAND_IO_EnableChipSelect( nDevInfo[i].ChipNo );

	//NAND_IO_DisableWriteProtect();

	/* Set Data Bus as 16Bit */
	if ( nDevInfo[i].Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//######################################################
	//# Get Info of Parameter
	//######################################################
	dwSectorAddr		= nSectorAddr;
	dwSectorAddr 		+= dwSectorAddrOffSet;
	dwTotalWriteSecSize = nTotalSectorSize;

	if ( dwTotalWriteSecSize < nDevInfo[i].LBAInfo.SectorCount )
		wCurrPPSize = (U16)dwTotalWriteSecSize;
	else
		wCurrPPSize = nDevInfo[i].LBAInfo.SectorCount;
	
	//######################################################
	//# Write Total Sector
	//######################################################
	wOldProcessRate = 0xFFFF;
	nWriteSectorSize = 0;
	nProCessWriteSectorSize = 0;
	// [ LCD ROUTINE ] ---------------------------------------------------------------------------------------
	if ( NAND_IO_LBA_CallBackLcdDisplay )
		NAND_IO_LBA_CallBackLcdDisplay( 0, 0x03, nTotalSectorSize );
	//--------------------------------------------------------------------------------------------------------

	if ( dwTotalWriteSecSize >= 0x10000 )
		wOnceWriteSectorCount = 0; // 0x10000
	else
		wOnceWriteSectorCount = (U16)dwTotalWriteSecSize;
	
	while ( dwTotalWriteSecSize )
	{
		if ( nWriteSectorSize == 0x10000 )
		{			
			if ( dwTotalWriteSecSize >= 0x10000 )
				wOnceWriteSectorCount = 0;
			else
				wOnceWriteSectorCount = (U16)dwTotalWriteSecSize;			

			nWriteSectorSize = 0;
			wFlagFirstSector = TRUE;
		}
			
		/* Command Page Program #1 [ 0x80 ] */
		pNFC->NFC_CMD = nDevInfo[i].CmdMask & 0x8080;

		if ( wFlagFirstSector == TRUE )
		{
			/* Write Sector Size & Sector Address */
			pNFC->NFC_SADDR= ( wOnceWriteSectorCount & 0xFF );					// Write Sector Num : SC0
			pNFC->NFC_SADDR= ( ( wOnceWriteSectorCount >> 8 ) & 0xFF );			// Write Sector Num : SC1
			pNFC->NFC_SADDR= ( dwSectorAddr & 0xFF );							// Write Sector Addr: AD0
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 8 ) & 0xFF );					// Write Sector Addr: AD1
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 16 ) & 0xFF );					// Write Sector Addr: AD2
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 24 ) & 0xFF );					// Write Sector Addr: AD2
		}

		NAND_IO_SetWriteCycleTime();
		/* Write Data to NAND FLASH */
		
			res = NAND_IO_LBA_WriteDummyData( &nDevInfo[i], wCurrPPSize );
		if ( res != SUCCESS )
			return res;

		NAND_IO_SetCommCycleTime();
		
		/* Command Page Program #2 [ 0x10 ] */
		pNFC->NFC_CMD = nDevInfo[i].CmdMask & 0x1010;

		/* Wait until it is ready */
		NAND_IO_WaitBusy( nDevInfo[i].ChipNo );

		/* Decrease Write Size */
		dwTotalWriteSecSize -= wCurrPPSize;

		/* Increase Buffer Address */
		//nWriteBuffer		+= ( nDevInfo->LBAInfo.SectorCount << 9 );
		dwSectorAddr		+= wCurrPPSize;
		nWriteSectorSize	+= wCurrPPSize;
		
		/* Count Next Page Size */
		if ( dwTotalWriteSecSize < nDevInfo[i].LBAInfo.SectorCount )
			wCurrPPSize = (U16)dwTotalWriteSecSize;
		else
			wCurrPPSize = nDevInfo[i].LBAInfo.SectorCount;

		if ( nDevInfo[i].LBAInfo.TransProtocol2 & NAND_PROT2_WRITE_TYPE_B )
			wFlagFirstSector = FALSE;

		wProcessRate = (U16)(( ( nProCessWriteSectorSize + 1 ) * 100 ) / ( nTotalSectorSize + 1 ));

		if ( wOldProcessRate != wProcessRate )
		{
			// [ LCD ROUTINE ] ---------------------------------------------------------------------------------------
			if ( NAND_IO_LBA_CallBackLcdDisplay )
				NAND_IO_LBA_CallBackLcdDisplay( 0, NAND_LBA_CALLBACK_LCD_FORMAT_PROCESS, wProcessRate );
			//--------------------------------------------------------------------------------------------------------

			wOldProcessRate = wProcessRate;
		}

		nProCessWriteSectorSize += wCurrPPSize;
	}

	// [ LCD ROUTINE ] ---------------------------------------------------------------------------------------
	if ( NAND_IO_LBA_CallBackLcdDisplay )
		NAND_IO_LBA_CallBackLcdDisplay( 0, 0x05, 0 );
	//--------------------------------------------------------------------------------------------------------
	
	pNFC->NFC_CMD = nDevInfo[i].CmdMask & 0xFBFB;
	NAND_IO_WaitBusy( nDevInfo[i].ChipNo );
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	/* Cache Flush */
	NAND_IO_LBA_CacheFlush( &nDevInfo[i] );

		//######################################################
		//# Set Power Save Mode 
		//######################################################
	NAND_IO_LBA_PowerSaveMode( &nDevInfo[i], ENABLE );
	}

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_WriteSector( NAND_IO_DEVINFO *nDevInfo, U8 nPartition, U32 nSectorAddr, U16 nSecSize, U8 *nWriteBuffer )
{
	unsigned short int		wCSorder;
	unsigned short int		wCurrPPSize;
	unsigned short int		wFlagFirstSector;
	unsigned long int 		dwSectorAddr, rConvertAddr;
	unsigned long int		dwTotalWriteSecSize, rConvertSize;
	unsigned char			cPartition;
	unsigned char			cSpareBuffer[16];
	NAND_IO_ERROR			res;

	//######################################################
	//# Get Info of Parameter
	//######################################################
	dwSectorAddr		= nSectorAddr;
	dwTotalWriteSecSize = nSecSize;
		
	while ( dwTotalWriteSecSize )
	{
		res = NAND_IO_LBA_ConvertMPPA( nDevInfo, nPartition, dwSectorAddr, dwTotalWriteSecSize, &rConvertAddr, &rConvertSize, &wCSorder );
		if ( res != SUCCESS )
			return res;

		//######################################################
	//# Check Parameter
	//######################################################
		if ( nDevInfo[wCSorder].LBAInfo.Usable != ENABLE )
		return ERR_NAND_IO_WRONG_PARAMETER;

	cPartition = nPartition & 0x0F;

		if ( nDevInfo[wCSorder].LBAInfo.CurrentMode != cPartition )
	{
			res = NAND_IO_LBA_ModeChange( &nDevInfo[wCSorder], cPartition );
			if ( res != SUCCESS )
	{
				NAND_IO_LBA_DeviceReboot( &nDevInfo[wCSorder]);
				NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_MDP );
				NAND_IO_LBA_SetTransferProtocol( &nDevInfo[wCSorder], NAND_PROT1_512x8, ( NAND_PROT2_WRITE_TYPE_B | NAND_PROT2_READ_TYPE_A ) );
				res = NAND_IO_LBA_ModeChange( &nDevInfo[wCSorder], cPartition );
				if ( res != SUCCESS )
					return res;
	}
	}

		//######################################################
		//# Set High Speed Mode 
		//######################################################
		NAND_IO_LBA_PowerSaveMode( &nDevInfo[wCSorder], DISABLE );
		NAND_IO_LBA_HighSpeedMode( &nDevInfo[wCSorder], ENABLE );

	wFlagFirstSector = TRUE;
	
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetCommCycleTime();

	/* Enable Chip Select */
		NAND_IO_EnableChipSelect( nDevInfo[wCSorder].ChipNo );

	/* Set Data Bus as 16Bit */
		if ( nDevInfo[wCSorder].Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

		if ( rConvertSize < nDevInfo[wCSorder].LBAInfo.SectorCount )
			wCurrPPSize = rConvertSize;
		else
			wCurrPPSize = nDevInfo[wCSorder].LBAInfo.SectorCount;

		/* Decrease Write Size */
		dwSectorAddr		+= rConvertSize;
		dwTotalWriteSecSize -= rConvertSize;
	
	//######################################################
	//# Write Total Sector
	//######################################################
		while ( rConvertSize )
	{
		/* Command Page Program #1 [ 0x80 ] */
			pNFC->NFC_CMD = nDevInfo[wCSorder].CmdMask & 0x8080;

		if ( wFlagFirstSector == TRUE )
		{
			/* Write Sector Size & Sector Address */
			  pNFC->NFC_SADDR= ( rConvertSize & 0xFF );					// Write Sector Num : SC0
			  pNFC->NFC_SADDR= ( ( rConvertSize >> 8 ) & 0xFF );			// Write Sector Num : SC1
			  pNFC->NFC_SADDR= ( rConvertAddr & 0xFF );				// Write Sector Addr: AD0
			  pNFC->NFC_SADDR= ( ( rConvertAddr >> 8 ) & 0xFF );		// Write Sector Addr: AD1
			  pNFC->NFC_SADDR= ( ( rConvertAddr >> 16 ) & 0xFF );		// Write Sector Addr: AD2
			  pNFC->NFC_SADDR= ( ( rConvertAddr >> 24 ) & 0xFF );		// Write Sector Addr: AD2
  
			  if ( nDevInfo[wCSorder].LBAInfo.TransProtocol2 & NAND_PROT2_WRITE_TYPE_B )
				  wFlagFirstSector = FALSE;
		}

		NAND_IO_SetWriteCycleTime();
		/* Write Data to NAND FLASH */
		  res = NAND_IO_LBA_WriteData( &nDevInfo[wCSorder], wCurrPPSize, nWriteBuffer, cSpareBuffer );
		if ( res != SUCCESS )
			return res;
		
		NAND_IO_SetCommCycleTime();
		
		/* Command Page Program #2 [ 0x10 ] */
		  pNFC->NFC_CMD = nDevInfo[wCSorder].CmdMask & 0x1010;

		  rConvertAddr		+= wCurrPPSize;
		  rConvertSize		-= wCurrPPSize;

		/* Increase Buffer Address */
		  nWriteBuffer		+= ( wCurrPPSize << 9 );
		
		/* Count Next Page Size */
		    if ( rConvertSize < nDevInfo[wCSorder].LBAInfo.SectorCount )
			    wCurrPPSize = rConvertSize;
		else
			    wCurrPPSize = nDevInfo[wCSorder].LBAInfo.SectorCount;

		/* Wait until it is ready */
		  NAND_IO_LBA_WaitBusy( nDevInfo[wCSorder].ChipNo );
	}
	
	  pNFC->NFC_CMD = nDevInfo[wCSorder].CmdMask & 0xFBFB;
	  NAND_IO_WaitBusy( nDevInfo[wCSorder].ChipNo );
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	  //######################################################
	  //# Set Power Save Mode 
	  //######################################################
	  //NAND_IO_LBA_PowerSaveMode( &nDevInfo[wCSorder], ENABLE );
	}
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_VFPInitArea( NAND_IO_DEVINFO *nDevInfo )
{
	NAND_IO_ERROR	res;
	
	res = NAND_IO_LBA_ScanHeaderOfVFP( nDevInfo );
	if ( res != SUCCESS )
	{
		res = NAND_IO_LBA_MakeHeaderOfVFP( nDevInfo );
		if ( res != SUCCESS )
			return res;

		res = NAND_IO_LBA_ScanHeaderOfVFP( nDevInfo );
		if ( res != SUCCESS )
			return res;
	}
	
	return res;
}

NAND_IO_ERROR NAND_IO_LBA_ScanHeaderOfVFP( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int			i;
	unsigned short int		wCurrPPSize;
	unsigned short int		wFlagCheckSize;
	unsigned short int		wFlagFirstSector;
	unsigned long int		nHeaderInfoSize;
	unsigned long int		nHeaderAddress;
	unsigned long int 		dwSectorAddr;
	unsigned long int		nTotalSectorSize;
	unsigned short int		nInfoOffSet;
	unsigned int			*pPageDW;
	unsigned char			cPageBuffer[512];
	unsigned char			cSpareBuffer[16];
	unsigned long int		dwTotalSectorSize;
	NAND_IO_ERROR			res;

	//######################################################
	//# Check Parameter
	//######################################################
	NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_VFP );

	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetCommCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_DisableWriteProtect();

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	wFlagFirstSector = TRUE;
	nInfoOffSet 		= 32;
	nHeaderInfoSize 	= 1;
	nHeaderAddress		= 0;
	
	//######################################################
	//# Get Info of Parameter
	//######################################################
	dwSectorAddr		= nHeaderAddress;
	nTotalSectorSize  	= nHeaderInfoSize;

	if ( nTotalSectorSize < nDevInfo->LBAInfo.SectorCount )
		wCurrPPSize = (U16)nTotalSectorSize;
	else
		wCurrPPSize = nDevInfo->LBAInfo.SectorCount ;
	
	//######################################################
	//# Write Total Sector
	//######################################################
	while ( nTotalSectorSize )
	{	
		/* Command Page Program #1 [ 0x80 ] */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

		if ( wFlagFirstSector == TRUE )
		{
			/* Write Sector Size & Sector Address */
			pNFC->NFC_SADDR= ( nHeaderInfoSize & 0xFF );					// Write Sector Num : SC0
			pNFC->NFC_SADDR= ( ( nHeaderInfoSize >> 8 ) & 0xFF );			// Write Sector Num : SC1
			pNFC->NFC_SADDR= ( dwSectorAddr & 0xFF );				// Write Sector Addr: AD0
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 8 ) & 0xFF );		// Write Sector Addr: AD1
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 16 ) & 0xFF );		// Write Sector Addr: AD2
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 24 ) & 0xFF );		// Write Sector Addr: AD2
		}

		/* Command Page Program #2 [ 0x10 ] */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;
		
		/* Wait until it is ready */
		NAND_IO_WaitBusy( nDevInfo->ChipNo );

		NAND_IO_SetReadCycleTime();
		/* Write Data to NAND FLASH */
		res = NAND_IO_LBA_ReadData_VFP( nDevInfo, wCurrPPSize, cPageBuffer, cSpareBuffer );
		if ( res != SUCCESS )
			return res;

		NAND_IO_SetCommCycleTime();

		/* Decrease Write Size */
		nTotalSectorSize 	-= wCurrPPSize;

		/* Increase Buffer Address */
		//cPageBuffer			+= ( nDevInfo->LBAInfo.SectorCount << 9 );
		
		/* Count Next Page Size */
		if ( nTotalSectorSize < nDevInfo->LBAInfo.SectorCount )
			wCurrPPSize = (U16)nTotalSectorSize;
		else
			wCurrPPSize = nDevInfo->LBAInfo.SectorCount;

		if ( nDevInfo->LBAInfo.TransProtocol2 & NAND_PROT2_WRITE_TYPE_B )
			wFlagFirstSector = FALSE;
	}

	/* FORCE TO SET WP LOW */
	NAND_IO_EnableWriteProtect();
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	wFlagCheckSize = FALSE;

	// Signature
	if ( !memcmp( cPageBuffer, (void *)NAND_LBA_VFP_AREA_Signature, sizeof(NAND_LBA_VFP_AREA_Signature) ) )
	{
		pPageDW		= (U32 *)&cPageBuffer[nInfoOffSet];
		//==============================================		
		// VFP Size			[  4Byte ]	0
		// MDP Size			[  4Byte ]	1
		// Hidden Size		[  4Byte ]	2
		// Multi-Hidden Num [  4Byte ]	3
		// Multi-Hidden Size[  4Byte ]	4~10
		//==============================================
		dwTotalSectorSize = 0;

		if ( nDevInfo->LBAInfo.VFPSectorSize == pPageDW[ENUM_LBA_VFP_SECTOR_SIZE] )
		{
			if ( nDevInfo->LBAInfo.FlagOfChangeTotalSectorSize == ENABLE )
			{
				if ( ( nDevInfo->LBAInfo.MDPSectorSize == pPageDW[ENUM_LBA_MDP_SECTOR_SIZE] ) &&
					 ( nDevInfo->LBAInfo.HDAreaSectorSize == pPageDW[ENUM_LBA_HIDDEN_SECTOR_SIZE] ) &&
					 ( nDevInfo->LBAInfo.MHDAreaNums == pPageDW[ENUM_LBA_MULTI_HIDDEN_NUM] ) )
				{
 					wFlagCheckSize = TRUE;

					if ( nDevInfo->LBAInfo.MHDAreaNums > NAND_LBA_MAX_SUPPORT_MHD_AREA_NUM )
						return ERR_NAND_IO_WRONG_PARAMETER;

					for ( i = 0; i < nDevInfo->LBAInfo.MHDAreaNums; ++i )
					{
						if ( nDevInfo->LBAInfo.MHDAreaSectorSize[i] != pPageDW[ENUM_LBA_MULTI_HIDDEN_SIZE_0 + i] )
							wFlagCheckSize = FALSE;				
					}
				}
				else
					wFlagCheckSize = FALSE;
			}
			else		// NAND VFP Info Read Only
			{
				nDevInfo->LBAInfo.HDAreaSectorSize 	= pPageDW[ENUM_LBA_HIDDEN_SECTOR_SIZE];
				nDevInfo->LBAInfo.MHDAreaNums 		= pPageDW[ENUM_LBA_MULTI_HIDDEN_NUM];

				if ( nDevInfo->LBAInfo.MHDAreaNums > NAND_LBA_MAX_SUPPORT_MHD_AREA_NUM )
					return ERR_NAND_IO_WRONG_PARAMETER;

				for ( i = 0; i < nDevInfo->LBAInfo.MHDAreaNums; ++i )
					nDevInfo->LBAInfo.MHDAreaSectorSize[i] = pPageDW[ENUM_LBA_MULTI_HIDDEN_SIZE_0 + i];

				wFlagCheckSize = TRUE;
			}
		}
		else
		{
			NAND_IO_LBA_VFPChangeSectorSize( nDevInfo, nDevInfo->LBAInfo.VFPSectorSize );
		}
	}

	dwTotalSectorSize  = nDevInfo->LBAInfo.HDAreaSectorSize;
	for ( i = 0; i < nDevInfo->LBAInfo.MHDAreaNums; ++i )
		dwTotalSectorSize += nDevInfo->LBAInfo.MHDAreaSectorSize[i];

	if ( dwTotalSectorSize > nDevInfo->LBAInfo.MDPSectorSize )
		return ERR_NAND_IO_WRONG_PARAMETER;

	if ( wFlagCheckSize == FALSE )
		return ERR_NAND_IO_NOT_EXIST_LBA_HEADBLOCK;


	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_MakeHeaderOfVFP( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int			i;
	unsigned short int		wCurrPPSize;
	unsigned short int		wFlagFirstSector;
	unsigned long int		nHeaderInfoSize;
	unsigned long int		nHeaderAddress;
	unsigned long int 		dwSectorAddr;
	unsigned long int		nTotalSectorSize;
	unsigned short int		nInfoOffSet;
	unsigned int			*pPageDW;
	unsigned char			cPageBuffer[512];
	unsigned char			cSpareBuffer[16];
	NAND_IO_ERROR			res;

	//######################################################
	//# Check Parameter
	//######################################################
	NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_VFP );
		
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetCommCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	NAND_IO_DisableWriteProtect();

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );
	wFlagFirstSector = TRUE;
	nInfoOffSet 		= 32;
	nHeaderInfoSize 	= 1;
	nHeaderAddress		= 0;

	//==============================================
	// Hidden Signature [ 32Byte ]
	// VFP Size			[  4Byte ]	0
	// MDP Size			[  4Byte ]	1
	// Hidden Size		[  4Byte ]	2
	// Multi-Hidden Num [  4Byte ]	3
	// Multi-Hidden Size[  4Byte ]	4~10
	//==============================================
	
	// Page Clear
	memset( (void*)cPageBuffer, 0xFF, 512 );

	// Signature
	memcpy( (void*)cPageBuffer, (void*)NAND_LBA_VFP_AREA_Signature, sizeof(NAND_LBA_VFP_AREA_Signature) );

	pPageDW		= (U32 *)&cPageBuffer[nInfoOffSet];

	// VFP Size
	pPageDW[ENUM_LBA_VFP_SECTOR_SIZE] 	= nDevInfo->LBAInfo.VFPSectorSize;

	// MDP Size
	pPageDW[ENUM_LBA_MDP_SECTOR_SIZE] 	= nDevInfo->LBAInfo.MDPSectorSize;

	// Hidden Size
	pPageDW[ENUM_LBA_HIDDEN_SECTOR_SIZE]= nDevInfo->LBAInfo.HDAreaSectorSize;

	// Multi-Hidden Area Num
	pPageDW[ENUM_LBA_MULTI_HIDDEN_NUM] 	= nDevInfo->LBAInfo.MHDAreaNums;

	if ( nDevInfo->LBAInfo.MHDAreaNums > NAND_LBA_MAX_SUPPORT_MHD_AREA_NUM )
		return ERR_NAND_IO_WRONG_PARAMETER;

	// Multi-Hidden Area Size
	for ( i = 0; i < nDevInfo->LBAInfo.MHDAreaNums; ++i )
		pPageDW[ENUM_LBA_MULTI_HIDDEN_SIZE_0 + i] 	= nDevInfo->LBAInfo.MHDAreaSectorSize[i];

	//######################################################
	//# Get Info of Parameter
	//######################################################
	dwSectorAddr		= nHeaderAddress;
	nTotalSectorSize	= nHeaderInfoSize;
	wFlagFirstSector = TRUE;

	if ( nTotalSectorSize < nDevInfo->LBAInfo.SectorCount )
		wCurrPPSize = (U16)nTotalSectorSize;
	else
		wCurrPPSize = nDevInfo->LBAInfo.SectorCount ;
	
	while ( nTotalSectorSize )
	{
		/* Command Page Program #1 [ 0x80 ] */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;

		if ( wFlagFirstSector == TRUE )
		{
			/* Write Sector Size & Sector Address */
			pNFC->NFC_SADDR= ( nHeaderInfoSize & 0xFF );					// Write Sector Num : SC0
			pNFC->NFC_SADDR= ( ( nHeaderInfoSize >> 8 ) & 0xFF );			// Write Sector Num : SC1
			pNFC->NFC_SADDR= ( dwSectorAddr & 0xFF );				// Write Sector Addr: AD0
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 8 ) & 0xFF );		// Write Sector Addr: AD1
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 16 ) & 0xFF );		// Write Sector Addr: AD2
			pNFC->NFC_SADDR= ( ( dwSectorAddr >> 24 ) & 0xFF );		// Write Sector Addr: AD2
		}

		NAND_IO_SetWriteCycleTime();
		/* Write Data to NAND FLASH */
		res = NAND_IO_LBA_WriteData( nDevInfo, wCurrPPSize, cPageBuffer, cSpareBuffer );
		if ( res != SUCCESS )
			return res;
		
		NAND_IO_SetCommCycleTime();
		
		/* Command Page Program #2 [ 0x10 ] */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;

		/* Decrease Write Size */
		nTotalSectorSize -= wCurrPPSize;

		/* Increase Buffer Address */
		//cPageBuffer		+= ( nDevInfo->LBAInfo.SectorCount << 9 );
		
		/* Count Next Page Size */
		if ( nTotalSectorSize < nDevInfo->LBAInfo.SectorCount )
			wCurrPPSize = (U16)nTotalSectorSize;
		else
			wCurrPPSize = nDevInfo->LBAInfo.SectorCount;

		if ( nDevInfo->LBAInfo.TransProtocol2 & NAND_PROT2_WRITE_TYPE_B )
			wFlagFirstSector = FALSE;

		/* Wait until it is ready */
		NAND_IO_WaitBusy( nDevInfo->ChipNo );
	}
	
	//nDevInfo->LBAInfo.HDAreaAddrOffSet = nDevInfo->LBAInfo.MDPSectorSize - nDevInfo->LBAInfo.HDAreaSectorSize;
	//nDevInfo->LBAInfo.DTAreaSectorSize = nDevInfo->LBAInfo.MDPSectorSize - nDevInfo->LBAInfo.HDAreaSectorSize;

	/* FORCE TO SET WP LOW */
	NAND_IO_EnableWriteProtect();
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	NAND_IO_LBA_CacheFlush( nDevInfo );

	return (NAND_IO_ERROR)SUCCESS;	
}

NAND_IO_ERROR NAND_IO_LBA_MDPGetTotalSectorSize( NAND_IO_DEVINFO *nDevInfo, unsigned long int *rTotalSector )
{
	unsigned long int	wTotalSector;
	unsigned char		nTemp;
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	pNFC->NFC_SADDR= 0xB0;
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Parallel Composition */
	wTotalSector = (U8)( pNFC->NFC_SDATA & 0xFF );
	wTotalSector |= ((U8)( pNFC->NFC_SDATA & 0xFF ) << 8 );
	wTotalSector |= ((U8)( pNFC->NFC_SDATA & 0xFF ) << 16 );
	wTotalSector |= ((U8)( pNFC->NFC_SDATA & 0xFF ) << 24 );
//	wTotalSector |= ((U8)( pNFC->NFC_SDATA & 0xFF ) << 32 );
	nTemp = (U8)( pNFC->NFC_SDATA & 0xFF );
	
	*rTotalSector = wTotalSector;
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_VFPGetTotalSectorSize( NAND_IO_DEVINFO *nDevInfo, U32 *rTotalSector )
{
	unsigned int	dwTotalSector;

	dwTotalSector  = 0;
	*rTotalSector  = 0;
	
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	pNFC->NFC_SADDR= 0xB5;
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Parallel Composition */
	dwTotalSector = (U8)( pNFC->NFC_SDATA & 0xFF );
	dwTotalSector |= ((U8)( pNFC->NFC_SDATA & 0xFF ) << 8 );

	if ( dwTotalSector == 0 ) 
		dwTotalSector = 0x10000;
	
	*rTotalSector = dwTotalSector;
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_VFPChangeSectorSize( NAND_IO_DEVINFO *nDevInfo, U32 nTotalSector )
{
	unsigned int	dwTotalSector;

	//======================================================================================
	//
	// The available rage for the VFP size: [40][00]h(8 Mbyte) ~ [01][00][00]h(32 Mbyte)
	// VFP AreaSize Min: 16,384 ~ Max: 65,536 sector / 512 sector resolution
	//
	// "VFP/MDP ratio = (+1)/(-2)" VFP increases by 1MB, the DMP decreases by 2MB.
	//
	//======================================================================================
	if ( ( nTotalSector < 0x4000 ) || ( nTotalSector > 0x10000 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;
	
	/* VFP Size Change Command can only be executed in the VFP mode */
	NAND_IO_LBA_ModeChange( nDevInfo, NAND_LBA_VFP );
	
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus Witdh */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );
	
	//==============================================
	// Arrange Sector Resolution
	//==============================================
	dwTotalSector = ( ( nTotalSector + 511 ) >> 9 );
	dwTotalSector = dwTotalSector << 9;

	if ( ( dwTotalSector < 0x4000 ) || ( dwTotalSector > 0x10000 ) )
		return ERR_NAND_IO_WRONG_PARAMETER;
	
	//==============================================
	// Set VFP Size
	//==============================================
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	pNFC->NFC_SADDR= 0x22;
	
	pNFC->NFC_SADDR= ( dwTotalSector & 0xFF );						// VFP_Size0: LSB
	pNFC->NFC_SADDR= ( ( dwTotalSector >> 8 ) & 0xFF );				// VFP_Size1: MSB
	pNFC->NFC_SADDR= ( 0xFF - ( dwTotalSector & 0xFF ) );			// Inversion of [VFP_Size0] for verification
	pNFC->NFC_SADDR= ( 0xFF - ( ( dwTotalSector >> 8 ) & 0xFF ) );	// Inversion of [VFP_Size1] fot verification
	
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_SetTransferProtocol( NAND_IO_DEVINFO *nDevInfo, U8 nProtocol1, U8 nProtocol2 )
{
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//==============================================
	// Get Protocol 1
	//==============================================
	/* Command Partition Change to PNP */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	pNFC->NFC_SADDR= 0xA2;		// cmd
	pNFC->NFC_SADDR= nProtocol1;	// Parameter
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	//==============================================
	// Get Protocol 2
	//==============================================
	/* Command Partition Change to PNP */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	pNFC->NFC_SADDR= 0xA3;		// cmd
	pNFC->NFC_SADDR= nProtocol2;	// Parameter
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_SetBootModeChange( NAND_IO_DEVINFO *nDevInfo, U8 nBootMode )
{
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//==============================================
	// Get Protocol 1
	//==============================================
	/* Command Partition Change to PNP */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= nBootMode;	// Parameter
	pNFC->NFC_SADDR= 0x00;		// Dummy Write

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_SetRebootCmdChange( NAND_IO_DEVINFO *nDevInfo, U8 nRebootCmd )
{
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//==============================================
	// Get Protocol 1
	//==============================================
	/* Command Partition Change to PNP */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= nRebootCmd;	// Parameter
	pNFC->NFC_SADDR= 0x00;		// Dummy Write

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_SetAreaPartition( NAND_IO_DEVINFO *nDevInfo, NAND_IO_FEATURE *sDevFeatureInfo )
{
	unsigned int i;
	unsigned int nBlockOffset;

	//==================================
	// Area Address Offset Setting
	//==================================
	// Data Area Address Offset = 0
	// 0 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MDP Size
	// [ Multi Hidden[n], Multi Hidden[n-1], Multi Hidden[0] | Hidden Area | Data Area ]
	nDevInfo->LBAInfo.DTAreaAddrOffSet = 0;
	nDevInfo->LBAInfo.DTAreaSectorSize = nDevInfo->LBAInfo.MDPSectorSize;

	for ( i = 0; i < nDevInfo->LBAInfo.MHDAreaNums; ++i )
	{
		nDevInfo->LBAInfo.DTAreaSectorSize -= nDevInfo->LBAInfo.MHDAreaSectorSize[i];
		nDevInfo->LBAInfo.MHDAreaAddrOffSet[i] = 0;
		nDevInfo->LBAInfo.DTAreaAddrOffSet += nDevInfo->LBAInfo.MHDAreaSectorSize[i];
		if ( i > 0 )
			nDevInfo->LBAInfo.MHDAreaAddrOffSet[i] = ( nDevInfo->LBAInfo.MHDAreaSectorSize[i-1] + nDevInfo->LBAInfo.MHDAreaAddrOffSet[i-1] );
	}
	nDevInfo->LBAInfo.HDAreaAddrOffSet = nDevInfo->LBAInfo.MDPSectorSize - nDevInfo->LBAInfo.DTAreaSectorSize;
	nDevInfo->LBAInfo.DTAreaSectorSize -= nDevInfo->LBAInfo.HDAreaSectorSize;
	nDevInfo->LBAInfo.DTAreaAddrOffSet += nDevInfo->LBAInfo.HDAreaSectorSize;

	nBlockOffset = ( nDevInfo->LBAInfo.DTAreaAddrOffSet /  ( ( sDevFeatureInfo->PageSize * sDevFeatureInfo->PpB ) >> 9 ) );
	if ( nDevInfo->LBAInfo.DTAreaAddrOffSet %  ( ( sDevFeatureInfo->PageSize * sDevFeatureInfo->PpB ) >> 9 ) )
		++nBlockOffset;

	nDevInfo->LBAInfo.DTAreaAddrOffSet += ( ( nBlockOffset * ( ( sDevFeatureInfo->PageSize * sDevFeatureInfo->PpB ) >> 9 ) ) - nDevInfo->LBAInfo.DTAreaAddrOffSet  );
	nDevInfo->LBAInfo.DTAreaSectorSize -= ( ( nBlockOffset * ( ( sDevFeatureInfo->PageSize * sDevFeatureInfo->PpB ) >> 9 ) ) - nDevInfo->LBAInfo.DTAreaAddrOffSet  );

	return SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_GetPersistentFunction( NAND_IO_DEVINFO *nDevInfo, U8 *rBootMode, U8 *rRebootCmd )
{
	unsigned char	nParameter;

	*rBootMode = 0;
	*rRebootCmd = 0;
	
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//==============================================
	// Get Protocol 1
	//==============================================
	/* Command Partition Change to PNP */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x99;		// CMD
	pNFC->NFC_SADDR= 0x00;		// Dummy Write

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	nParameter = (U8)( pNFC->NFC_SDATA & 0xFF );

	*rBootMode = nParameter;

	nParameter = (U8)( pNFC->NFC_SDATA & 0xFF );

	*rRebootCmd = nParameter;

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_GetTransferProtocol( NAND_IO_DEVINFO *nDevInfo, U8 *rProtocol1, U8 *rProtocol2 )
{
	unsigned char	nParameter;

	*rProtocol1 = 0;
	*rProtocol2 = 0;
	
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//==============================================
	// Get Protocol 1
	//==============================================
	/* Command Partition Change to PNP */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	pNFC->NFC_SADDR= 0xB2;		// cmd
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	nParameter = (U8)( pNFC->NFC_SDATA & 0xFF );

	*rProtocol1 = nParameter;

	//==============================================
	// Get Protocol 2
	//==============================================
	/* Command Partition Change to PNP */
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	pNFC->NFC_SADDR= 0xB3;		// cmd
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	nParameter = (U8)( pNFC->NFC_SDATA & 0xFF );

	*rProtocol2 = nParameter;

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_GetDeviceMDPSectorSize( NAND_IO_DEVINFO *nDevInfo, unsigned long int *rTotalSector )
{
	unsigned int 		i;
	unsigned long int	nTotalSecSize;
		
	NAND_IO_ERROR	res;

	nTotalSecSize = 0;
	
	for ( i = NAND_IO_DRV0_START_CS; i < NAND_IO_DRV0_END_CS + 1; ++i )
	{
		nDevInfo[i].LBAInfo.MDPSectorSize = 0;
		
		res = NAND_IO_LBA_GetDeviceInfo( i, &nDevInfo[i] );
		if ( res == SUCCESS )
		{
			NAND_IO_LBA_MDPGetTotalSectorSize( nDevInfo, &nDevInfo[i].LBAInfo.MDPSectorSize );
			nTotalSecSize += nDevInfo[i].LBAInfo.MDPSectorSize;
		}
	}

	*rTotalSector = nTotalSecSize;

	return SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_GetBusyTime( NAND_IO_DEVINFO *nDevInfo, U8 *rBusyTime )
{
	unsigned char	dwBusyTime;

	dwBusyTime  = 0;
	*rBusyTime	= 0;
	
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	pNFC->NFC_SADDR= 0xB4;
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Parallel Composition */
	dwBusyTime = (U8)( pNFC->NFC_SDATA & 0xFF );

	*rBusyTime = dwBusyTime;
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_SetBusyTime( NAND_IO_DEVINFO *nDevInfo, U8 nBusyTime )
{
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	pNFC->NFC_SADDR= nBusyTime;
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
		
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_GetBootMode( NAND_IO_DEVINFO *nDevInfo, U8 *rBootMode )
{
	unsigned char	dwBootMode;

	dwBootMode  = 0;
	*rBootMode	= 0;
	
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
	pNFC->NFC_SADDR= 0x00;
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x99;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Parallel Composition */
	dwBootMode = (U8)( pNFC->NFC_SDATA & 0xFF );

	*rBootMode = dwBootMode;
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_PowerSaveMode( NAND_IO_DEVINFO *nDevInfo, int nOnOff )
{
	//Power Save Mode En,Disable	
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	if ( nOnOff == ENABLE )
		pNFC->NFC_SADDR= 0xBA;
	else
		pNFC->NFC_SADDR= 0xBB;
		
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}
	
NAND_IO_ERROR NAND_IO_LBA_HighSpeedMode( NAND_IO_DEVINFO *nDevInfo, int nOnOff )
{
	// High Speed Write Mode En,Disable
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

	if ( nOnOff == ENABLE )
		pNFC->NFC_SADDR= 0xBC;
	else
		pNFC->NFC_SADDR= 0xBD;
		
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_SADDR= 0x00;		// Dummy Write
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	if ( nOnOff == ENABLE )
		nDevInfo->LBAInfo.HighSpeedMode	= ENABLE;
	else
		nDevInfo->LBAInfo.HighSpeedMode	= DISABLE;
			
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_CacheFlush( NAND_IO_DEVINFO *nDevInfo )
{ 
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nDevInfo->LBAInfo.CurrentMode == NAND_LBA_BCM )
	{
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;			
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0xF9;		// Dummy Write
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;
	}
	else
	{
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0xF9F9;
	}

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_GetDeviceMediaNums( U16 *rMediaOrder )
{
	*rMediaOrder = gLBACSNums;

	return SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_ConvertMPPA( NAND_IO_DEVINFO *nDevInfo, U8 nPartition, U32 nSectorAddr, U32 nSecSize, U32 *nConvertAddr, U32 *nConvertSize, U16 *rMediaOrder )
{
	unsigned short int		i;
	unsigned short int		wOrder;
	unsigned long int       dwBound;
	unsigned long int		dwSectorAddr;
	unsigned long int		nTotalSectorSize[4];
	unsigned long int		nPartitionOffSet[4];
		
	dwBound = 0;
	dwSectorAddr = nSectorAddr;

	for ( wOrder = 0; wOrder < gLBACSNums; ++wOrder )
	{	
		if ( nPartition == NAND_LBA_DATA_AREA )
		{
			nTotalSectorSize[wOrder] = nDevInfo[wOrder].LBAInfo.DTAreaSectorSize;
			nPartitionOffSet[wOrder] = nDevInfo[wOrder].LBAInfo.DTAreaAddrOffSet;
		}	
		else if ( nPartition == NAND_LBA_HIDDEN_AREA )
		{
			nTotalSectorSize[wOrder] = nDevInfo[wOrder].LBAInfo.HDAreaSectorSize;
			nPartitionOffSet[wOrder] = nDevInfo[wOrder].LBAInfo.HDAreaAddrOffSet;
		}
		else if ( nPartition == NAND_LBA_MULTI_HIDDEN_AREA_0 )
		{
			nTotalSectorSize[wOrder] = nDevInfo[wOrder].LBAInfo.MHDAreaSectorSize[0];
			nPartitionOffSet[wOrder] = nDevInfo[wOrder].LBAInfo.MHDAreaAddrOffSet[0];
		}
		else if ( nPartition == NAND_LBA_MDP )
		{
			nTotalSectorSize[wOrder] = nDevInfo[wOrder].LBAInfo.MDPSectorSize;
			nPartitionOffSet[wOrder] = 0;			
		}
		else if ( nPartition == NAND_LBA_VFP )
		{
			nTotalSectorSize[wOrder] = nDevInfo[wOrder].LBAInfo.VFPSectorSize;
			nPartitionOffSet[wOrder] = NAND_LBA_SYS_SECTION;
		}
	
		dwBound 	 += nDevInfo[wOrder].LBAInfo.MDPSectorSize;
		dwSectorAddr += nPartitionOffSet[wOrder];
		
		if ( dwSectorAddr < dwBound )
		{
			*rMediaOrder = wOrder;
			break;
		}		
	}

	for ( i = 0; i < wOrder; ++i )
		dwSectorAddr -= nDevInfo[i].LBAInfo.MDPSectorSize;
	
	if ( ( nDevInfo[wOrder].LBAInfo.MDPSectorSize - dwSectorAddr ) >= nSecSize )
		*nConvertSize = nSecSize;
	else
		*nConvertSize = ( nDevInfo[wOrder].LBAInfo.MDPSectorSize - dwSectorAddr );

	*nConvertAddr = dwSectorAddr;
	
	if ( ( dwSectorAddr + *nConvertSize ) > ( nTotalSectorSize[wOrder] + nPartitionOffSet[wOrder] ) )
		return ERR_NAND_IO_WRONG_PARAMETER;

	return SUCCESS;
}	

NAND_IO_ERROR NAND_IO_LBA_DeviceReboot( NAND_IO_DEVINFO *nDevInfo )
{
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nDevInfo->LBAInfo.CurrentMode == NAND_LBA_BCM )
	{
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;			
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0xFD;		// CMD
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
	}
	else
	{
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0xFDFD;
	}

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	nDevInfo->LBAInfo.CurrentMode = NAND_LBA_PNP;
	
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_ReadID( NAND_IO_DEVINFO *nDevInfo, NAND_IO_DEVID *nDeviceCode )
{
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );


	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x9292;
	pNFC->NFC_SADDR	= 0x0000;	/* Address [ 0x00 ] */
	
	/* Delay : tAR1[READID] Max 200nS */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	//ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;

	/* Parallel Composition */
	nDeviceCode->Code[0] = (U16)( pNFC->NFC_SDATA & nDevInfo->CmdMask );
	nDeviceCode->Code[1] = (U16)( pNFC->NFC_SDATA & nDevInfo->CmdMask );
	nDeviceCode->Code[2] = (U16)( pNFC->NFC_SDATA & nDevInfo->CmdMask );
	nDeviceCode->Code[3] = (U16)( pNFC->NFC_SDATA & nDevInfo->CmdMask );
	nDeviceCode->Code[4] = (U16)( pNFC->NFC_SDATA & nDevInfo->CmdMask );

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_Reset( NAND_IO_DEVINFO *nDevInfo )
{
	/* Pre Process */
	NAND_IO_PreProcess();

	/* Set Setup Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	pNFC->NFC_CMD = nDevInfo->CmdMask & 0xFFFF;
	/* Delay : tAR1[READID] Max 200nS */
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;

	NAND_IO_WaitBusy( nDevInfo->ChipNo );


	pNFC->NFC_CMD = nDevInfo->CmdMask & 0xFDFD;
	/* Delay : tAR1[READID] Max 200nS */
	ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;ASM_NOP;

	NAND_IO_WaitBusy( nDevInfo->ChipNo );
	
	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	nDevInfo->LBAInfo.CurrentMode = NAND_LBA_PNP;
	
	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_ModeChange( NAND_IO_DEVINFO *nDevInfo, int nMode )
{
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	if ( nMode == NAND_LBA_PNP )
	{
		// Change to BCM 
		if ( ( nDevInfo->LBAInfo.CurrentMode == NAND_LBA_PNP ) || ( nDevInfo->LBAInfo.CurrentMode == NAND_LBA_BCM ) )
		{
			//==============================================
			// Directly Enter BCM (Boot Code Maintenance)
			//==============================================
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

			pNFC->NFC_SADDR= 0x00;		// Dummy Write 
			pNFC->NFC_SADDR= 0x00;		// Dummy Write
			pNFC->NFC_SADDR= 0x00;		// Dummy Write
			pNFC->NFC_SADDR= 0xFC;		// cmd
			pNFC->NFC_SADDR= 0x00;		// Dummy Write

			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;			
		}
		else
		{
			/* Command Partition Change to BCM */
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
			
			pNFC->NFC_SADDR= 0xBF;		// cmd
			pNFC->NFC_SADDR= 0x00;		// PassWord 0
			pNFC->NFC_SADDR= 0x00;		// PassWord 1
			pNFC->NFC_SADDR= 0x00;		// Dummy Write
			pNFC->NFC_SADDR= 0x00;		// Dummy Write

			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;			
		}
		/* Wait until it is ready */
		NAND_IO_WaitBusy( nDevInfo->ChipNo );

		// Exit from BCM
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x8080;

		pNFC->NFC_SADDR= 0x00;		// Dummy Write 
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0xFD;		// cmd
		pNFC->NFC_SADDR= 0x00;		// Dummy Write

		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x1010;
	}
	else if ( nMode == NAND_LBA_BCM )
	{
		if ( ( nDevInfo->LBAInfo.CurrentMode == NAND_LBA_PNP ) || ( nDevInfo->LBAInfo.CurrentMode == NAND_LBA_BCM ) )
		{
			//==============================================
			// Directly Enter BCM (Boot Code Maintenance)
			//==============================================
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;

			pNFC->NFC_SADDR= 0x00;		// Dummy Write 
			pNFC->NFC_SADDR= 0x00;		// Dummy Write
			pNFC->NFC_SADDR= 0x00;		// Dummy Write
			pNFC->NFC_SADDR= 0xFC;		// cmd
			pNFC->NFC_SADDR= 0x00;		// Dummy Write

			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x3030;			
		}
		else
		{
			/* Command Partition Change to BCM */
			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
			
			pNFC->NFC_SADDR= 0xBF;		// cmd
			pNFC->NFC_SADDR= 0x00;		// PassWord 0
			pNFC->NFC_SADDR= 0x00;		// PassWord 1
			pNFC->NFC_SADDR= 0x00;		// Dummy Write
			pNFC->NFC_SADDR= 0x00;		// Dummy Write

			pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;			
		}
	}
	else if ( nMode == NAND_LBA_MDP )
	{
		/* Command Partition Change to MDP */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0xFCFC;
	}
	else if ( nMode == NAND_LBA_VFP )
	{
		/* Command Partition Change to VFP */
		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x0000;
		
		pNFC->NFC_SADDR= 0xBE;		// cmd
		pNFC->NFC_SADDR= 0xFF;		// PassWord 0
		pNFC->NFC_SADDR= 0xFF;		// PassWord 1
		pNFC->NFC_SADDR= 0x00;		// Dummy Write
		pNFC->NFC_SADDR= 0x00;		// Dummy Write

		pNFC->NFC_CMD = nDevInfo->CmdMask & 0x5757;
	}

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );


	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();

	/* Read Status */
	NAND_IO_LBA_Read2Status( nDevInfo );
	if ( nDevInfo->LBAInfo.CurrentMode != nMode )
		return ERR_NAND_IO_FAILED_LBA_PARTITION_CHANGE;

	if ( nMode == NAND_LBA_MDP )
	{
		nDevInfo->LBAInfo.CurrentMode = NAND_LBA_MDP;
		NAND_IO_LBA_MDPGetTotalSectorSize( nDevInfo, &nDevInfo->LBAInfo.CurrentSectorSize );
	}
	else if ( nMode == NAND_LBA_VFP )
	{		
		nDevInfo->LBAInfo.CurrentMode = NAND_LBA_VFP;
		NAND_IO_LBA_VFPGetTotalSectorSize( nDevInfo, (U32 *)&nDevInfo->LBAInfo.CurrentSectorSize );
	}

	return (NAND_IO_ERROR)SUCCESS;
}

NAND_IO_ERROR NAND_IO_LBA_Read2Status( NAND_IO_DEVINFO *nDevInfo )
{
	unsigned int		uStatus;
	NAND_IO_ERROR		res;

	res = (NAND_IO_ERROR)SUCCESS;
	
	/* Pre Process */
	NAND_IO_PreProcess();
	
	/* Set Setuo Time and Hold Time */
	NAND_IO_SetBasicCycleTime();

	/* Enable Chip Select */
	NAND_IO_EnableChipSelect( nDevInfo->ChipNo );

	/* Set Data Bus as 16Bit */
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );
	
	//================================
	//	Command READ STATUS [ 0x70 ]
	//================================
	pNFC->NFC_CMD = nDevInfo->CmdMask & 0x7171;

	// Delay : more than 200nS
   	NAND_IO_Delay();
	
	//=============================================
	// DATA BUS WIDTH Setting
	//=============================================
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//================================
	//	Read IO Status
	//================================
	uStatus	= nDevInfo->CmdMask & pNFC->NFC_SDATA;
	uStatus = uStatus & 0x0F;
	
	if ( ( uStatus & 0x06 ) == NAND_LBA_PNP )
		nDevInfo->LBAInfo.CurrentMode = NAND_LBA_PNP;
	else if ( ( uStatus & 0x06 ) == NAND_LBA_BCM )
		nDevInfo->LBAInfo.CurrentMode = NAND_LBA_BCM;
	else if ( ( uStatus & 0x06 ) == NAND_LBA_VFP )
		nDevInfo->LBAInfo.CurrentMode = NAND_LBA_VFP;
	else if ( ( uStatus & 0x06 ) == NAND_LBA_MDP )
		nDevInfo->LBAInfo.CurrentMode = NAND_LBA_MDP;
	else
		res = ERR_NAND_IO_FAILED_LBA_PARTITION_CHANGE;

	if ( nDevInfo->LBAInfo.CurrentMode != NAND_LBA_PNP )
	{
		if ( uStatus & NAND_POWER_SAVE_ENABLE )
			nDevInfo->LBAInfo.PowerSaveMode = ENABLE;
		else
			nDevInfo->LBAInfo.PowerSaveMode = DISABLE;

		if ( uStatus & NAND_HIGH_SPEED_ENABLE )
			nDevInfo->LBAInfo.HighSpeedMode = ENABLE;
		else
			nDevInfo->LBAInfo.HighSpeedMode = DISABLE;		
	}

	/* Wait until it is ready */
	NAND_IO_WaitBusy( nDevInfo->ChipNo );

	/* Disable Chip Select */
	NAND_IO_DisableChipSelect();

	/* Post Process */
	NAND_IO_PostProcess();
	
	return res;
}

static __inline NAND_IO_ERROR NAND_IO_LBA_ReadData_VFP( NAND_IO_DEVINFO *nDevInfo, U16 nReadPPSize,
												    U8 *nPageBuffer, U8 *nSpareBuffer )
{
	unsigned int		i, j;
	unsigned char		bAlignAddr;
	unsigned char		*pPageB = 0, *pSpareB = 0;
	unsigned int		*pPageDW = 0, *pSpareDW = 0;
	unsigned char		*pDataBuffer, *pPrDataBuffer;
	unsigned char		*pPhy_Buffer;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;
	
	if ( nReadPPSize > nDevInfo->LBAInfo.SectorCount )
		return ERR_NAND_IO_WRONG_PARAMETER;
		
	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr = ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;
	
	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Read Data as 512+16Bytes
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
	{
		pPageDW		= (unsigned int*)nPageBuffer;
		pSpareDW	= (unsigned int*)nSpareBuffer;
	}	
	else
	{
		pPageB		= (unsigned char*)nPageBuffer;
		pSpareB		= (unsigned char*)nSpareBuffer;
	}	

	//----------------------------------------------
	//	Read Data as 512Bytes repeatly
	//----------------------------------------------		
	for ( j = 0; j < nReadPPSize; ++j )
	{
		/* Set Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;


#if 1		/* 09.12.21 */
		/* Read 512 Data Area */
		i = 128;
		do {
			if ( bAlignAddr )
			{
				*pPageDW = pNFC->NFC_WDATA;++pPageDW;
			}	
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				*pPageB = uDWordByte.BYTE[1];++pPageB;
				*pPageB = uDWordByte.BYTE[2];++pPageB;
				*pPageB = uDWordByte.BYTE[3];++pPageB;
			}
		}while(--i);
#else
		//####################################################
		//#	Read 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )
		
		/* Read 512 Data Area */
		i = 128;
		do {
			if ( bAlignAddr )
			{
				*pPageDW = pNFC->NFC_WDATA;++pPageDW;
			}	
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				*pPageB = uDWordByte.BYTE[1];++pPageB;
				*pPageB = uDWordByte.BYTE[2];++pPageB;
				*pPageB = uDWordByte.BYTE[3];++pPageB;
			}
		}while(--i);
		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )
		//
		///* Disable DMA Ahead */
		////IO_DMA_SetCTRL( IO_DMA_CH2, 0 );
		////IO_INT_HwICLR = IO_INT_HwDMA_CH2;
		//
		///* Start DMA on NFC BUS */
#if 1		/* 09.12.08 */
		#if defined(_LINUX_) || defined(_WINCE_)

		//if ( nEccOnOff == ECC_ON_NON_CACHE_BUF )
		//{
		//	pPhy_Buffer = virt_to_phys(pDataBuffer);
		//
		//	NAND_IO_SetupDMA_kernel( (void*)&NAND_IO_HwLDATA_PA, 0, 0,
		//							  (void*)pPhy_Buffer, 4, 0,
		//							  NAND_IO_DMA_READ, 512 );
		//}
		//else
		NAND_IO_SetupDMA( (void*)&NAND_IO_HwLDATA_PA, 0, 0,
						  (void*)pDataBuffer, 4, 0,
						  NAND_IO_DMA_READ, 512 );
		#else
		NAND_IO_SetupDMA( (void*)&pNFC->NFC_LDATA, 0, 0,
						  (void*)pDataBuffer, 4, 0,
						  NAND_IO_DMA_READ, 512 );
		#endif

		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;
#else


		/* Disable DMA Ahead */
		/* Start DMA on NFC BUS */
		NAND_IO_SetupDMADoubleBuf( NAND_IO_DMA_READ, j );

		pNFC->NFC_RSTART	= 0;
		
		if ( j != 0 )
		{
			if ( j & 1 )
				memcpy( pPrDataBuffer, gpDMA_WorkBuffer1, 512 );
			else
				memcpy( pPrDataBuffer, gpDMA_WorkBuffer0, 512 );
		}

		while ( ISZERO(pNFC->NFC_IREQ, HwNFC_IREQ_FLAG0) );


		if ( j == (unsigned int)( nReadPPSize - 1 ) )
		{
			if ( j & 1 )
				memcpy( pDataBuffer, gpDMA_WorkBuffer0, 512 );
			else
				memcpy( pDataBuffer, gpDMA_WorkBuffer1, 512 );
		}
		else
		{
			pPrDataBuffer = pDataBuffer;	// Buffer Pointer Backup

			if ( j & 1 )
				pDataBuffer =(unsigned char *)gpDMA_WorkBuffer0;			
			else
				pDataBuffer =(unsigned char *)gpDMA_WorkBuffer1;
		}
		
		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;
#endif		
		#endif
#endif		
		//####################################################
		//####################################################
		if ( nDevInfo->LBAInfo.DataTransferCheck == ENABLE )
		{
			/* Read 16Bytes spare data */
			i = 4;
			do {
				if ( bAlignAddr )
				{
					*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
				}	
				else
				{
					uDWordByte.DWORD = pNFC->NFC_WDATA;
					*pSpareB = uDWordByte.BYTE[0];++pSpareB;
					*pSpareB = uDWordByte.BYTE[1];++pSpareB;
					*pSpareB = uDWordByte.BYTE[2];++pSpareB;
					*pSpareB = uDWordByte.BYTE[3];++pSpareB;
				}
			}while(--i);

			/* Adapt type of address */
			if ( bAlignAddr )
				pSpareDW	= (unsigned int*)nSpareBuffer;
			else
				pSpareB		= (unsigned char*)nSpareBuffer;				
		}
	}

	//=========================================================================
	// Return
	//=========================================================================
	return res;
}

static __inline NAND_IO_ERROR NAND_IO_LBA_ReadData( NAND_IO_DEVINFO *nDevInfo, U16 nReadPPSize,
												    U8 *nPageBuffer, U8 *nSpareBuffer )
{
	unsigned int		i, j;
	unsigned char		bAlignAddr;
	unsigned char		*pPageB = 0, *pSpareB = 0;
	unsigned int		*pPageDW = 0, *pSpareDW = 0;
	unsigned char		*pDataBuffer, *pPrDataBuffer;
	unsigned char		*pPhy_Buffer;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;
	
	if ( nReadPPSize > nDevInfo->LBAInfo.SectorCount )
		return ERR_NAND_IO_WRONG_PARAMETER;
		
	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;

	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr = ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;
	
	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Read Data as 512+16Bytes
	//=========================================================================
	/* Adapt type of address */
	if ( bAlignAddr )
	{
		pPageDW		= (unsigned int*)nPageBuffer;
		pSpareDW	= (unsigned int*)nSpareBuffer;
	}	
	else
	{
		pPageB		= (unsigned char*)nPageBuffer;
		pSpareB		= (unsigned char*)nSpareBuffer;
	}	

	//----------------------------------------------
	//	Read Data as 512Bytes repeatly
	//----------------------------------------------		
#ifdef __USE_NAND_ISR__
	pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

	pPhy_Buffer = virt_to_phys(pDataBuffer);
	NAND_IO_SetupDMA_kernel( (void*)&NAND_IO_HwLDATA_PA, 0, 0,
					  (void*)pPhy_Buffer, 4, 0,
					  NAND_IO_DMA_READ, 512 * nReadPPSize );
#else
	for ( j = 0; j < nReadPPSize; ++j )
	{
		/* Set Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

		//####################################################
		//#	Read 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )
		
		/* Read 512 Data Area */
		i = 128;
		do {
			if ( bAlignAddr )
			{
				*pPageDW = pNFC->NFC_WDATA;++pPageDW;
			}	
			else
			{
				uDWordByte.DWORD = pNFC->NFC_WDATA;
				*pPageB = uDWordByte.BYTE[0];++pPageB;
				*pPageB = uDWordByte.BYTE[1];++pPageB;
				*pPageB = uDWordByte.BYTE[2];++pPageB;
				*pPageB = uDWordByte.BYTE[3];++pPageB;
			}
		}while(--i);
		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )
		//
		///* Disable DMA Ahead */
		////IO_DMA_SetCTRL( IO_DMA_CH2, 0 );
		////IO_INT_HwICLR = IO_INT_HwDMA_CH2;
		//
		///* Start DMA on NFC BUS */
		/* Disable DMA Ahead */
		/* Start DMA on NFC BUS */
		NAND_IO_SetupDMADoubleBuf( NAND_IO_DMA_READ, j );

		pNFC->NFC_RSTART	= 0;
		
		if ( j != 0 )
		{
			if ( j & 1 )
				memcpy( pPrDataBuffer, gpDMA_WorkBuffer1, 512 );
			else
				memcpy( pPrDataBuffer, gpDMA_WorkBuffer0, 512 );
		}

		while ( ISZERO(pNFC->NFC_IREQ, HwNFC_IREQ_FLAG0) );


		if ( j == (unsigned int)( nReadPPSize - 1 ) )
		{
			if ( j & 1 )
				memcpy( pDataBuffer, gpDMA_WorkBuffer0, 512 );
			else
				memcpy( pDataBuffer, gpDMA_WorkBuffer1, 512 );
		}
		else
		{
			pPrDataBuffer = pDataBuffer;	// Buffer Pointer Backup

			if ( j & 1 )
				pDataBuffer =(unsigned char *)gpDMA_WorkBuffer0;			
			else
				pDataBuffer =(unsigned char *)gpDMA_WorkBuffer1;
		}

		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;
#endif		
		//####################################################
		//####################################################
		if ( nDevInfo->LBAInfo.DataTransferCheck == ENABLE )
		{
			/* Read 16Bytes spare data */
			i = 4;
			do {
				if ( bAlignAddr )
				{
					*pSpareDW = pNFC->NFC_WDATA;++pSpareDW;
				}	
				else
				{
					uDWordByte.DWORD = pNFC->NFC_WDATA;
					*pSpareB = uDWordByte.BYTE[0];++pSpareB;
					*pSpareB = uDWordByte.BYTE[1];++pSpareB;
					*pSpareB = uDWordByte.BYTE[2];++pSpareB;
					*pSpareB = uDWordByte.BYTE[3];++pSpareB;
				}
			}while(--i);

			/* Adapt type of address */
			if ( bAlignAddr )
				pSpareDW	= (unsigned int*)nSpareBuffer;
			else
				pSpareB		= (unsigned char*)nSpareBuffer;				
		}
	}
#endif

	//=========================================================================
	// Return
	//=========================================================================
	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*      static __inline void NAND_IO_LBA_WaitBusy( U16 nChipNo );
*  
*  DESCRIPTION : 
*  INPUT:
*			nChipNo	= 
*  
*  OUTPUT:	void - Return Type
*  REMARK  :	
**************************************************************************/
static __inline void NAND_IO_LBA_WaitBusy( U16 nChipNo )
{
	// Misc. Configuration Register(MCFG)
   	// 0 : represent that READY pin is low
   	// 1 :                             high
   	// Delay : 200nS

	while (NAND_IO_CheckReadyAndBusy( nChipNo ))
	{
		#ifndef FWDN_DOWNLOADER_INCLUDE
		TCC7XX_USBDRV_WriteToQueue();
		#endif
	}
}

static __inline NAND_IO_ERROR NAND_IO_LBA_WriteData( NAND_IO_DEVINFO *nDevInfo, U16 nWritePPSize,
													 U8 *nPageBuffer, U8 *nSpareBuffer )
{
	unsigned int		i, j;
	unsigned char		bAlignAddr;
	unsigned char		*pPageB = 0, *pSpareB = 0;
	unsigned int		*pPageDW = 0, *pSpareDW = 0;
	unsigned char		*pDataBuffer;
	DWORD_BYTE			uDWordByte;
	NAND_IO_ERROR		res;
	
	if ( nWritePPSize > nDevInfo->LBAInfo.SectorCount )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;
	
	//=========================================================================
	// Check Align of PageBuffer Address
	//=========================================================================
	bAlignAddr		= ( (unsigned int)nPageBuffer & 3 ) ? 0 : 1;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	//=========================================================================
	// Write Data as 528Bytes
	//=========================================================================

	/* Adapt type of address */
	if ( bAlignAddr )
	{
		pPageDW		= (unsigned int*)nPageBuffer;
		pSpareDW	= (unsigned int*)nSpareBuffer;
	}	
	else
	{
		pPageB		= (unsigned char*)nPageBuffer;
		pSpareB		= (unsigned char*)nSpareBuffer;
	}	

	//----------------------------------------------
	//	Write Data as 512Bytes repeatly
	//----------------------------------------------		
	for ( j = 0; j < nWritePPSize; ++j )
	{
		/* Get Data Buffer */
		pDataBuffer = ( bAlignAddr ) ? (unsigned char*)pPageDW : (unsigned char*)pPageB;

		//####################################################
		//#	Write 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )

		/* Write 512 Data Area */	
		//BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
		//pNFC->NFC_DSIZE	= 512;
		//pNFC->NFC_IREQ = 0x77;	// pNFC->NFC_IREQ_FLAG1;
		//pNFC->NFC_PSTART = 0;
		
		i = 128;
		do {
			if ( bAlignAddr )
			{
				pNFC->NFC_WDATA = *pPageDW;++pPageDW;
			}	
			else
			{
				uDWordByte.BYTE[0] = *pPageB;++pPageB;
				uDWordByte.BYTE[1] = *pPageB;++pPageB;
				uDWordByte.BYTE[2] = *pPageB;++pPageB;
				uDWordByte.BYTE[3] = *pPageB;++pPageB;
				pNFC->NFC_WDATA	= uDWordByte.DWORD;					
			}
		}while(--i);

		//while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
		
		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )
			
#if 1		/* 09.12.08 */
		#if defined(_LINUX_) || defined(_WINCE_)
		NAND_IO_SetupDMA( (void*)pDataBuffer, 4, 0,
						  (void*)&NAND_IO_HwLDATA_PA, 0, 0,
						  NAND_IO_DMA_WRITE, 512 );
		#else
		NAND_IO_SetupDMA( (void*)pDataBufferE, 4, 0,
						  (void*)&pNFC->NFC_LDATA, 0, 0,
						  NAND_IO_DMA_WRITE, 512 );
		#endif

		if ( bAlignAddr ) 
			pPageDW += 128;
		else
			pPageB += 512;


#else


		if ( j == 0 )
			memcpy( gpDMA_WorkBuffer1, pDataBuffer, 512 );

		NAND_IO_SetupDMADoubleBuf( NAND_IO_DMA_WRITE, j );

		if ( pNFC->NFC_CTRL1 & Hw31 )
			BITCLR( pNFC->NFC_CTRL1, Hw31 );

		pNFC->NFC_PSTART	= 0;

		if ( j != (unsigned int)( nWritePPSize - 1 ) ) 
		{
			if ( j & 1 )
				memcpy( gpDMA_WorkBuffer1, (void *)(pDataBuffer + 512), 512 );
			else
				memcpy( gpDMA_WorkBuffer0, (void *)(pDataBuffer + 512), 512 );
		}
		
		while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));

		if ( pNFC->NFC_CTRL1 & Hw30 )
			BITSET( pNFC->NFC_CTRL1, Hw31 );
	
		if ( bAlignAddr )
			pPageDW += 128;
		else
			pPageB += 512;
#endif

		#endif
		//####################################################
		//####################################################
		if ( nDevInfo->LBAInfo.DataTransferCheck == ENABLE )
		{
			/* Write 16Bytes spare data */
			i = 4;
			do {
				if ( bAlignAddr )
				{
					pNFC->NFC_WDATA = *pSpareDW;++pSpareDW;
				}	
				else
				{
					uDWordByte.BYTE[0]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[1]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[2]	= *pSpareB;++pSpareB;
					uDWordByte.BYTE[3]	= *pSpareB;++pSpareB;
					pNFC->NFC_WDATA = uDWordByte.DWORD;
				}
			}while(--i);

			/* Adapt type of address */
			if ( bAlignAddr )
				pSpareDW	= (unsigned int*)nSpareBuffer;
			else
				pSpareB		= (unsigned char*)nSpareBuffer;			
		}
	}

	//=========================================================================
	// Return
	//=========================================================================
	return res;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      static __inline NAND_IO_ERROR NAND_IO_LBA_WriteDummyData( NAND_IO_DEVINFO *nDevInfo, U16 nWritePPSize );
*  
*  DESCRIPTION : You can add file description here.
*  
*  INPUT:
*			nDevInfo	= 
*			nWritePPSize	= 
*  
*  OUTPUT:	NAND_IO_ERROR - Return Type
*  			= 
*  
**************************************************************************/
static __inline NAND_IO_ERROR NAND_IO_LBA_WriteDummyData( NAND_IO_DEVINFO *nDevInfo, U16 nWritePPSize )
{
	unsigned int		i, j;
	unsigned char		nTempBuffer[512];
	NAND_IO_ERROR		res;
	
	if ( nWritePPSize > nDevInfo->LBAInfo.SectorCount )
		return ERR_NAND_IO_WRONG_PARAMETER;

	//=========================================================================
	// Initial Setting
	//=========================================================================
	res = (NAND_IO_ERROR)SUCCESS;

	//=========================================================================
	// DATA BUS WIDTH Setting
	//=========================================================================	
	if ( nDevInfo->Feature.MediaType & A_DATA_WITDH_16BIT )
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_16BIT );
	else
		NAND_IO_SetDataWidth( NAND_IO_DATA_WITDH_8BIT );

	/* Prepare data */
	#if defined(_WINCE_)
		memset( nTempBuffer, 0xFF, 512 );
	#elif defined(_LINUX_)
	    #ifndef KERNEL_DRIVER
	    memset( nTempBuffer, 0xFF, 512 );
	    #else
	    memset( nTempBuffer, 0xFF, 512 );
	    #endif
	#else
	memset( nTempBuffer, 0xFF, 512 );
	#endif
	
	//----------------------------------------------
	//	Write Data as 512Bytes repeatly
	//----------------------------------------------		
	for ( j = 0; j < nWritePPSize; ++j )
	{
		//####################################################
		//#	Write 512 Page Data
		//####################################################
		//----------------------------------------------
		//	MCU ACCESS
		//----------------------------------------------
		#if defined( NAND_IO_USE_MCU_ACCESS )

		/* Write 512 Data Area */	
		BITCSET( pNFC->NFC_CTRL, HwNFC_CTRL_BSIZE_8, HwNFC_CTRL_BSIZE_1 );	// 1R/W Burst Size
		pNFC->NFC_DSIZE	= 512;
		pNFC->NFC_IREQ = 0x77;	// pNFC->NFC_IREQ_FLAG1;

		NAND_IO_IRQ_Mask();
		pNFC->NFC_PSTART = 0;
		
		i = 128;
		do {
			while (!( pNFC->NFC_CTRL & HwNFC_CTRL_FS_RDY ));
			pNFC->NFC_LDATA = 0xFFFFFFFF;
		}while(--i);

		while (ISZERO( pNFC->NFC_IREQ, HwNFC_IREQ_FLAG1 ));
		NAND_IO_IRQ_UnMask();
		
		//----------------------------------------------
		//	DMA ACCESS
		//----------------------------------------------
		#elif defined( NAND_IO_USE_DMA_ACCESS )
		/* Disable DMA Ahead */
		//IO_DMA_SetCTRL( IO_DMA_CH2, 0 );
		//IO_INT_HwICLR = IO_INT_HwDMA_CH2;

		#if defined(_LINUX_) || defined(_WINCE_)
		NAND_IO_SetupDMA( (void*)nTempBuffer, 4, 0,
						  (void*)&NAND_IO_HwLDATA_PA, 0, 0,
						  NAND_IO_DMA_WRITE, 512 );
		#else
		NAND_IO_SetupDMA( (void*)nTempBuffer, 4, 0,
						  (void*)&pNFC->NFC_LDATA, 0, 0,
						  NAND_IO_DMA_WRITE, 512 );
		#endif

		#endif
		//####################################################
		//####################################################
		if ( nDevInfo->LBAInfo.DataTransferCheck == ENABLE )
		{
			/* Write 16Bytes spare data */
			i = 4;
			do {
				pNFC->NFC_WDATA = 0xFFFFFFFF;
			}while(--i);
		}
	}

	//=========================================================================
	// Return
	//=========================================================================
	return res;
}
#endif	// NAND_LBA_INCLUDE

#endif	// WITHOUT_FILESYSTEM

/* end of file */

