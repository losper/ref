/****************************************************************************
 *   FileName    : nand_drv.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#if defined(_LINUX_)
#include "common.h"
#if defined(USE_V_ADDRESS)
#include <linux/kernel.h>
#include <linux/string.h>
#endif
#endif

#if defined(_LINUX_) || defined(_WINCE_)
//#include "IO_TCC7XX.h"
#include "nand_drv.h"
//#include "Disk.h"
#include "TC_File.h"
#else
#include "Globals.h"
#include "IO_TCCXXX.h"
#include "nand_drv.h"
#include "disk.h"
#include "FileBufferCtrl.h"
#include "Assert.h"
#endif

#ifdef _WINCE_
#include "bsp.h"
#include "args.h"
#endif

#if defined(__NUCLEUS_KERNEL__)
#include "TC_Kernel.h"
#endif

#ifdef AUDIOUI_INCLUDE	
#include "AudioUI.H"
#endif


//#define NAND_DRV_PORT_DEBUG

#ifdef BOOTCRCCHEK
	typedef struct _BootCRC
	{
		unsigned int crc128kchk;
		unsigned int crcfullchk;
		unsigned int bootfilesize;
	}BootCRC; 
#endif

#ifndef WITHOUT_FILESYSTEM

#if defined( FWDN_DOWNLOADER_INCLUDE )
const unsigned char	NANDDRV_Library_Version[] = { "SIGBYAHONG_NANDDRV_FWDN_V001000" };
#elif defined(TCC92XX)
const unsigned char	NANDDRV_Library_Version[] = { "SIGBYAHONG_NANDDRV_TCC92XX_V001000" };
#elif defined(TCC89XX)
const unsigned char	NANDDRV_Library_Version[] = { "SIGBYAHONG_NANDDRV_TCC89XX_V001000" };
#endif

//=============================================================================
//*
//*
//*                           [ CONST DATA DEFINE ]
//*
//*
//=============================================================================
#define NAND_DRV_HIDDEN_INFO_SIZE	( 19 + 8 + 1*4 )

const unsigned char gNAND_HiddenInfoSignature[ NAND_DRV_HIDDEN_INFO_SIZE ] =
{
	'T','N','F','T','L','H','I','D','D','E','N','S','I','Z','E','I','N','F','O',
    
    #ifndef NU_FILE_INCLUDE
	#ifdef AUDIOUI_INCLUDE	
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE+AUI_HD_OCCPAGE) >>  0) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE+AUI_HD_OCCPAGE) >>  8) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE+AUI_HD_OCCPAGE) >> 16) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE+AUI_HD_OCCPAGE) >> 24) & 0xFF,
	#else
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE) >>  0) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE) >>  8) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE) >> 16) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE)>> 24) & 0xFF,
    #endif
    #else
    ((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE) >>  0) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE) >>  8) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE) >> 16) & 0xFF,
	((unsigned long int)(NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE) >> 24) & 0xFF,
	#endif

	((unsigned long int)TNFTL_MULTI_HIDDEN_AREA_NUM >>  0) & 0xFF,
	((unsigned long int)TNFTL_MULTI_HIDDEN_AREA_NUM >>  8) & 0xFF,
	((unsigned long int)TNFTL_MULTI_HIDDEN_AREA_NUM >> 16) & 0xFF,
	((unsigned long int)TNFTL_MULTI_HIDDEN_AREA_NUM >> 24) & 0xFF,

	((unsigned long int)NAND_HIDDEN_DRIVE_DEFAULT_TOTAL_SECTOR_SIZE >>  0) & 0xFF,
	((unsigned long int)NAND_HIDDEN_DRIVE_DEFAULT_TOTAL_SECTOR_SIZE >>  8) & 0xFF,
	((unsigned long int)NAND_HIDDEN_DRIVE_DEFAULT_TOTAL_SECTOR_SIZE >> 16) & 0xFF,
	((unsigned long int)NAND_HIDDEN_DRIVE_DEFAULT_TOTAL_SECTOR_SIZE >> 24) & 0xFF
};

//=============================================================================
//*
//*
//*                           [ GLOBAL VARIABLE DEFINE ]
//*
//*
//=============================================================================
NAND_DRVINFO		gNAND_DrvInfo[MAX_NAND_DRIVE];
TNFTL_HIDDEN_INFO	gTNFTL_HiddenInfo[MAX_NAND_DRIVE];

TNFTL_DRVINFO		gTNFTL_DrvInfo[MAX_NAND_DRIVE];
TNFTL_RW_AREA		gTNFTL_MULTIHDAreaInfo[MAX_NAND_DRIVE][TNFTL_MULTI_HIDDEN_AREA_MAX_NUM];
TNFTL_LPT_BLOCK		gTNFTL_DTAreaLPTBlk[MAX_NAND_DRIVE][TNFTL_LPT_BLK_NUM_For_DATA_AREA];
TNFTL_LPT_BLOCK		gTNFTL_HDAreaLPTBlk[MAX_NAND_DRIVE][TNFTL_LPT_BLK_NUM_For_HIDDEN_AREA];
TNFTL_LPT_BLOCK		gTNFTL_MULTIHDAreaLPTBlk[MAX_NAND_DRIVE][TNFTL_MULTI_HIDDEN_AREA_MAX_NUM][TNFTL_LPT_BLK_NUM_For_DATA_AREA];
TNFTL_WCACHE		gTNFTL_DTAreaWCache[MAX_NAND_DRIVE][TNFTL_WCACHE_NUM_For_DATA_AREA];
TNFTL_WCACHE		gTNFTL_HDAreaWCache[MAX_NAND_DRIVE][TNFTL_WCACHE_NUM_For_HIDDEN_AREA];
TNFTL_WCACHE		gTNFTL_MULTIHDAreaWCache[MAX_NAND_DRIVE][TNFTL_MULTI_HIDDEN_AREA_MAX_NUM][TNFTL_WCACHE_NUM_For_DATA_AREA];

#if defined( TNFTL_V5_INCLUDE ) || defined(TNFTL_V6_INCLUDE)
TNFTL_RCACHE_SLOT 	gTNFTL_DTAreaRCache[MAX_NAND_DRIVE][TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE>>9];
TNFTL_RCACHE_SLOT	gTNFTL_HDAreaRCache[MAX_NAND_DRIVE][TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE>>9];
TNFTL_RCACHE_SLOT	gTNFTL_MULTIHDAreaRCache[MAX_NAND_DRIVE][TNFTL_MULTI_HIDDEN_AREA_MAX_NUM][TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE>>9];
#endif

TNFTL_MAINPB_INFO 	gTNFTL_DTAreaMainPBInfo[MAX_NAND_DRIVE][TNFTL_WCACHE_NUM_For_DATA_AREA];
TNFTL_MAINPB_INFO 	gTNFTL_HDAreaMainPBInfo[MAX_NAND_DRIVE][TNFTL_WCACHE_NUM_For_HIDDEN_AREA];
TNFTL_MAINPB_INFO 	gTNFTL_MULTIHDAreaMainPBInfo[MAX_NAND_DRIVE][TNFTL_MULTI_HIDDEN_AREA_MAX_NUM][TNFTL_WCACHE_NUM_For_DATA_AREA];

NAND_IO_DEVINFO		*gLBA_DevInfo;

unsigned char		gNAND_UARTDebugFlag = DISABLE;
unsigned char		gNAND_HiddenInfoLoadFlag = DISABLE;
#if defined(_LINUX_) || defined(_WINCE_)
unsigned char		gNAND_SetFlagOfChangeAreaSize = DISABLE;
unsigned char		gFormatType	= TC_LOWLEVEL_YES;
unsigned int		gMAX_ROMSIZE = MAX_ROMSIZE_NAND;
#else
unsigned char		gNAND_SetFlagOfChangeAreaSize = ENABLE;
#endif

//=============================================================================
//*
//*
//*                           [ LOCAL FUNCTIONS DEFINE ]
//*
//*
//=============================================================================

//=============================================================================
//*
//*
//*                     [ EXTERN VARIABLE & FUNCTIONS DEFINE ]
//*
//*
//=============================================================================
extern unsigned char	NANDBUF_Library_Version[];
#if defined(_LINUX_)
unsigned char gNAND_PageBuffer[TNFTL_MAX_SUPPORT_NAND_IO_PAGE_SIZE + TNFTL_MAX_SUPPORT_NAND_IO_SPARE_SIZE] __attribute__((aligned(8)));
unsigned char gNAND_RCacheDTAreaBuffer[TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE] __attribute__((aligned(8)));
unsigned char gNAND_AlignBuffer[TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE] __attribute__((aligned(8)));
#else
extern unsigned char	gNAND_PageBuffer[TNFTL_MAX_SUPPORT_NAND_IO_PAGE_SIZE + TNFTL_MAX_SUPPORT_NAND_IO_SPARE_SIZE];
extern unsigned char 	gNAND_RCacheDTAreaBuffer[TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE];
extern unsigned char	gNAND_AlignBuffer[TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE];
#endif

extern NAND_IO_CYCLE		WriteCycleTime;
extern NAND_IO_CYCLE		ReadCycleTime;
extern NAND_IO_CYCLE		CommCycleTime;
extern unsigned int			gMaxBusClkMHZ;
extern unsigned int			gCycleTick;

#if !defined(NU_FILE_INCLUDE) && !defined(_LINUX_) && !defined(_WINCE_)
extern unsigned int		fat_cbuffer[];
#else
extern unsigned char	gFormatType;
#endif

extern unsigned short		usbFirmwareDownloadMode;

#if !defined(FWDN_DOWNLOADER_INCLUDE) && !defined(_LINUX_) && !defined(_WINCE_)
	#ifdef MTP_INCLUDE
	extern void*			MTPMEM_AllocNandInitBuffer( void );
	extern unsigned int		MTPMEM_GetNandIintBufferSize( void );
	#else
	extern char	gFileBuffer[RAW_BUFFERSIZE];
	#endif
#endif

/******************************************************************************
*
*	unsigned char*	NAND_TellLibraryVersion
*
*	Input	: NONE
*	Output	: NONE
*	Return	: NONE
*
*	Description :
*
*******************************************************************************/
unsigned char*	NAND_TellLibraryVersion( void )
{
	return (unsigned char*)gNAND_HiddenInfoSignature;
}	

/******************************************************************************
*
*	unsigned char*	NAND_DRV_TellLibraryVersion
*
*	Input	: NONE
*	Output	: NONE
*	Return	: NONE
*
*	Description :
*
*******************************************************************************/
unsigned char*	NAND_DRV_TellLibraryVersion( void )
{
	unsigned short int 	i = 0;

	if ( i )
		return (unsigned char*)NANDBUF_Library_Version;
	else
		return (unsigned char*)NANDDRV_Library_Version;
}

/*************************************************************************************
 *          NAND_Init
 *
 * Description  :
 * Argument     :
 * Return       :   if it is successed then return 0
 *                  if it is failed then return Error Code
 *
 *************************************************************************************/
void NAND_Init( void )
{
	#ifdef NAND_LBA_INCLUDE
	NAND_ERROR	res;
	#endif
		
	#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
	unsigned int 	i;
	#endif
	
	#if !defined(NU_FILE_INCLUDE) && !defined(FWDN_DOWNLOADER_INCLUDE) && !defined(_LINUX_) & !defined(_WINCE_)
	unsigned int	BufferSize;
	#endif

    //=====================================================
    // Initialize NAND IO & TNFTL Variable
    //=====================================================
	NAND_IO_Init();

    //=================================================================
    // Initialize TNFTL Driver
    //=================================================================
	/* Drive #0 */
	TNFTL_AllocMemAndLinkForDriver( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0], &gNAND_DrvInfo[NAND_DRV_0].NFTLDrvInfo );
	TNFTL_AllocMemAndLinkForLPT( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].DTArea, &gTNFTL_DTAreaLPTBlk[NAND_DRV_0][0], TNFTL_LPT_BLK_NUM_For_DATA_AREA );
	TNFTL_AllocMemAndLinkForLPT( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].HDArea, &gTNFTL_HDAreaLPTBlk[NAND_DRV_0][0], TNFTL_LPT_BLK_NUM_For_HIDDEN_AREA );
	TNFTL_AllocMemAndLinkForWCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].DTArea, &gTNFTL_DTAreaWCache[NAND_DRV_0][0], TNFTL_WCACHE_NUM_For_DATA_AREA );
	TNFTL_AllocMemAndLinkForWCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].HDArea, &gTNFTL_HDAreaWCache[NAND_DRV_0][0], TNFTL_WCACHE_NUM_For_HIDDEN_AREA );
	#if defined( TNFTL_V5_INCLUDE ) || defined(TNFTL_V6_INCLUDE)
	TNFTL_AllocMemAndLinkForRCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].DTArea, &gTNFTL_DTAreaRCache[NAND_DRV_0][0] );
	TNFTL_AllocMemAndLinkForRCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].HDArea, &gTNFTL_HDAreaRCache[NAND_DRV_0][0] );
	#endif
    TNFTL_AllocMemAndLinkForMainPBInfo( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].DTArea, &gTNFTL_DTAreaMainPBInfo[NAND_DRV_0][0], 2 );
	TNFTL_AllocMemAndLinkForMainPBInfo( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].HDArea, &gTNFTL_HDAreaMainPBInfo[NAND_DRV_0][0], TNFTL_WCACHE_NUM_For_HIDDEN_AREA );
	TNFTL_AllocMemAndLinkForMultiHidden( NAND_DRV_0, &gTNFTL_MULTIHDAreaInfo[NAND_DRV_0][0] );
	TNFTL_SetMultiHiddenNums( NAND_DRV_0, TNFTL_MULTI_HIDDEN_AREA_NUM );

	#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
	for ( i = 0; i < TNFTL_MULTI_HIDDEN_AREA_NUM; ++i )
	{
		TNFTL_AllocMemAndLinkForLPT( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].MultiHDArea[i], &gTNFTL_MULTIHDAreaLPTBlk[NAND_DRV_0][i][0], TNFTL_LPT_BLK_NUM_For_DATA_AREA );
		TNFTL_AllocMemAndLinkForWCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].MultiHDArea[i], &gTNFTL_MULTIHDAreaWCache[NAND_DRV_0][i][0], TNFTL_WCACHE_NUM_For_DATA_AREA );
		TNFTL_AllocMemAndLinkForMainPBInfo( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].MultiHDArea[i], &gTNFTL_MULTIHDAreaMainPBInfo[NAND_DRV_0][i][0], TNFTL_WCACHE_NUM_For_DATA_AREA );
		#if defined( TNFTL_V5_INCLUDE ) || defined(TNFTL_V6_INCLUDE)
		TNFTL_AllocMemAndLinkForRCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].MultiHDArea[i], &gTNFTL_MULTIHDAreaRCache[NAND_DRV_0][i][0] );
		#endif	
	}
	#endif

	TNFTL_Init( NAND_DRV_0 );
	TNFTL_SetStEdOfCS( NAND_DRV_0, NAND_IO_DRV0_START_CS, NAND_IO_DRV0_END_CS );

	TNFTL_AllocMemAndLinkForPageBuffer( NAND_DRV_0, gNAND_PageBuffer );
	#if defined( TNFTL_V5_INCLUDE ) || defined(TNFTL_V6_INCLUDE)
	/* RCACHE & ALIGN Cache Buffer Memory Allocation( TNFTL V5 ) */
	TNFTL_AllocMemAndLinkForRCacheBuffer( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].DTArea, gNAND_RCacheDTAreaBuffer, TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE );
	TNFTL_SetUseAreaReadCacheMode( gNAND_DrvInfo[NAND_DRV_0].NFTLDrvInfo, &gTNFTL_DrvInfo[NAND_DRV_0].DTArea, ENABLE );
	TNFTL_AllocMemAndLinkForAlignCacheBuffer( NAND_DRV_0, gNAND_AlignBuffer, TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE );
	#endif

	#if !defined(NU_FILE_INCLUDE) && !defined(_LINUX_) && !defined(_WINCE_)
	#ifndef FWDN_DOWNLOADER_INCLUDE
		#ifdef MTP_INCLUDE
		BufferSize = MTPMEM_GetNandIintBufferSize() / 4;
		#else
		BufferSize = RAW_BUFFERSIZE / 4;
		#endif

		if ( BufferSize > 65536 / 4 )
		{
			#ifdef MTP_INCLUDE
			TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, (unsigned char*)MTPMEM_AllocNandInitBuffer(), MTPMEM_GetNandIintBufferSize() / 4 );
			#else
			TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, gFileBuffer, RAW_BUFFERSIZE / 4 );
			#endif
		}
		else
		{
			TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, fat_cbuffer, 65536 / 4 );
		}
	#else	
		TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, fat_cbuffer, 65536 / 4 );
	#endif
	#endif

	#ifdef NAND_LBA_INCLUDE
	gLBA_DevInfo = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0];
	
	gLBA_DevInfo->LBAInfo.FlagOfChangeTotalSectorSize = DISABLE;
	res = NAND_IO_LBA_GetDeviceInfo( gLBA_DevInfo );
	if ( ( res == SUCCESS ) || ( gLBA_DevInfo->Feature.MediaType & S_LBA ) )
		gNAND_DrvInfo[0].NFTLDrvInfo->NANDType = NAND_TYPE_LBA_NAND;
	else
		gNAND_DrvInfo[0].NFTLDrvInfo->NANDType = NAND_TYPE_PURE_NAND;
	#else
		gNAND_DrvInfo[0].NFTLDrvInfo->NANDType = NAND_TYPE_PURE_NAND;	
	#endif

	/* Init TNFTL MSC Debug Monitor */
	#if !defined(FWDN_DOWNLOADER_INCLUDE) && !defined(_LINUX_) && !defined(_WINCE_)
	#ifdef TNFTL_DEBUG_INCLUDE
	TNFTL_DEBUG_Init_Function(  MASS_SCSI_InitMSCDebugMonitor,
								VTC_SendData,
								VTC_ReceiveData,
								MASS_BulkOnly_SendData,
								MASS_BulkOnly_ReceiveData,
								MASS_SCSI_SetMSCDebugMonitorHandler,
								FWDN_PROT_ResponseAck,
								FWDN_PROT_ResponseNack);
	TNFTL_DEBUG_Init();
	#endif
	#endif

	return;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_InitHiddenInfo( void );
*  
*  DESCRIPTION : 
*  
*  INPUT :	NONE
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_InitHiddenInfo( void )
{
	unsigned int i;
	
    #if defined(_LINUX_) || defined(_WINCE_)
	gTNFTL_HiddenInfo[NAND_DRV_0].HiddenPageSize = 4096;
	gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenAreaNum = 0;
	gTNFTL_HiddenInfo[NAND_DRV_0].ROAreaSize = 0;
	#else	
	gTNFTL_HiddenInfo[NAND_DRV_0].HiddenPageSize = NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE;
	gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenAreaNum = TNFTL_MULTI_HIDDEN_AREA_NUM;
	#endif

	for ( i = 0; i < TNFTL_MULTI_HIDDEN_AREA_MAX_NUM; ++i )
		gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenSize[i] = NAND_HIDDEN_DRIVE_DEFAULT_TOTAL_SECTOR_SIZE;

	gTNFTL_HiddenInfo[NAND_DRV_0].ROAreaSize = 0;
	
	return;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_SetFlagOfChangeAreaSize( unsigned char On_Off );
*  
*  DESCRIPTION :
*  
*  INPUT :
*			On_Off	= ENABLE/DISABLE
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_SetFlagOfChangeAreaSize( unsigned char On_Off )
{
	gNAND_SetFlagOfChangeAreaSize = On_Off;
	return;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_SetHiddenInfoLoagFlag( unsigned char On_Off );
*  
*  DESCRIPTION : 
*  
*  INPUT:
*			On_Off	= ENABLE/DISABLE
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_SetHiddenInfoLoagFlag( unsigned char On_Off )
{
	gNAND_HiddenInfoLoadFlag = On_Off;
	return;
}
	
/******************************************************************************
*
*	NAND_ERROR		NAND_InitDrive
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_ERROR NAND_InitDrive( int nDrvNo )
{
	unsigned int	i;

	TNFTL_ERROR res;
	#if defined(NU_FILE_INCLUDE) || defined(_LINUX_) || defined(_WINCE_)
	void		*pointer;
		#if defined(_LINUX_)
		unsigned				bufSize	= 64*1024;
		static unsigned int		Tempbuffer[64*1024];
		#else
		unsigned				bufSize	= 256*1024;
		static unsigned char	Tempbuffer[256*1024];
		#endif
	#endif

	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
	{
	    //===============================================================
	    // Check Drive I/O in the FTL Layer
	    //===============================================================	
	    gNAND_DrvInfo[nDrvNo].DrvStatus = DISABLE;
    
		#if defined(NU_FILE_INCLUDE)
	    pointer	= TC_Allocate_Memory(bufSize);
	    if (pointer == NULL)
			return	-1;
		#elif defined(_LINUX_) || defined(_WINCE_)
		pointer	= Tempbuffer;
		if (pointer == NULL)
			return	-1;
		#endif
    
		#if defined(NU_FILE_INCLUDE)|| defined(_LINUX_) || defined(_WINCE_)
			#if defined(_LINUX_)
			TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, pointer, bufSize );	/* [1193] */
			#else
	  	  	TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, pointer, bufSize/4 );	/* [1193] */
			#endif
		#endif
    
	    if ( gNAND_SetFlagOfChangeAreaSize == DISABLE )
		    TNFTL_SetFlagOfChangeTotalSecSize( gNAND_DrvInfo[0].NFTLDrvInfo, &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea, DISABLE );
	    else
		    TNFTL_SetFlagOfChangeTotalSecSize( gNAND_DrvInfo[0].NFTLDrvInfo, &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea, ENABLE );
	    
	    // Check if low-level format option is enabled.	/*	[1255]  */
	    if (usbFirmwareDownloadMode & Hw8)
	    {
		    BITCLR(usbFirmwareDownloadMode, Hw8);
		    TNFTL_BMPRefresh( gNAND_DrvInfo[0].NFTLDrvInfo);
	    }

		//=========================================================
		// Linux MTD Include
		//=========================================================
		TNFTL_SetROAreaSize( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo, gTNFTL_HiddenInfo[NAND_DRV_0].ROAreaSize << 20 );
		//=========================================================

	    res = TNFTL_InitDrive( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo );
		#ifdef NU_FILE_INCLUDE
		TC_Deallocate_Memory(pointer);
		#endif
 
		#if defined(USE_V_ADDRESS) && defined(_WINCE_)
		RETAILMSG(1, (TEXT("[NAND        ] [BClk %dMHZ][1Tick %d][RE-S:%d,P:%d,H:%d][WR-S:%d,P:%d,H:%d][COM-S:%d,P:%d,H:%d]\n"),
		gMaxBusClkMHZ,gCycleTick,ReadCycleTime.STP,ReadCycleTime.PW,ReadCycleTime.HLD,
		WriteCycleTime.STP,WriteCycleTime.PW,WriteCycleTime.HLD,CommCycleTime.STP,CommCycleTime.PW,CommCycleTime.HLD));
		RETAILMSG(1, (TEXT("[NAND        ] [NB Area:%dMB][DT Area:%dMB][HD Area:%dMB]"), 
		//gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->NBArea.PBpV << gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MediaRatioShiftBSize[0],
		( gMAX_ROMSIZE * 2 ) >> 20,
		gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->DTArea.TotalSectorSize >> 11, 
		gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->HDArea.TotalSectorSize >> 11 ));
		for ( i = 0; i < gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MultiHiddendNums; ++i )
			RETAILMSG(1, (TEXT( "[MH Area%d:%dMB]"), i, gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MultiHDArea[i].TotalSectorSize >> 11 ));
		if ( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ROAreaSize != 0 )
			RETAILMSG(1, (TEXT( "[MTD Size:%dMB]"), gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ROAreaSize >> 20 ));
		RETAILMSG(1, (TEXT("\n")));
		#else
		ND_TRACE( "[NAND        ] [BClk %dMHZ][1Tick %d][RE-S:%d,P:%d,H:%d][WR-S:%d,P:%d,H:%d][COM-S:%d,P:%d,H:%d]\n",
		gMaxBusClkMHZ,gCycleTick,ReadCycleTime.STP,ReadCycleTime.PW,ReadCycleTime.HLD,
		WriteCycleTime.STP,WriteCycleTime.PW,WriteCycleTime.HLD,CommCycleTime.STP,CommCycleTime.PW,CommCycleTime.HLD );		
		ND_TRACE( "[NAND        ] [NB Area:%dMB][DT Area:%dMB][HD Area:%dMB]", 
		//gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->NBArea.PBpV << gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MediaRatioShiftBSize[0],
		(gMAX_ROMSIZE * 2) >> 20,
		gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->DTArea.TotalSectorSize >> 11, 
		gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->HDArea.TotalSectorSize >> 11);
		for ( i = 0; i < gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MultiHiddendNums; ++i )
			ND_TRACE( "[MH Area%d:%dMB]", i, gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MultiHDArea[i].TotalSectorSize >> 11 );
		if ( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ROAreaSize != 0 )
			ND_TRACE("[MTD Size:%dMB]", gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ROAreaSize >> 20 );
		ND_TRACE("\n");
		#endif
		
	    if ( res != SUCCESS )
		{
			#if defined(USE_V_ADDRESS)
				#if defined(_LINUX_)
				if ( res == ERR_TNFTL_OVERSIZE_MTD_AREA_SIZE )
					printk("\nError: MTD Area Size is too big...\n");
				else
					printk("\nTNFTL_Init_Fail:0x%X", res );
				#endif			
			#else
				#if defined(_LINUX_)
				if ( res == ERR_TNFTL_OVERSIZE_MTD_AREA_SIZE )
					printf("\nError: MTD Area Size is too big...\n");
				else
					printf("\nTNFTL_Init_Fail:0x%X", res );
				#endif
			#endif
		    return ERR_NAND_INIT_FAILED;
		    //return res; //original
		}
    	
	    TNFTL_AREAGetTotalSecAndCHS( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								     &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->DTArea,
								     (U32 *)&gNAND_DrvInfo[nDrvNo].TotalDiskSector,
								     &gNAND_DrvInfo[nDrvNo].Cylinder,
								     &gNAND_DrvInfo[nDrvNo].Head,
								     &gNAND_DrvInfo[nDrvNo].Sector );
    
	    gNAND_DrvInfo[nDrvNo].DrvStatus = ENABLE;
	}
	else
	{
		#ifdef NAND_LBA_INCLUDE

		gNAND_DrvInfo[nDrvNo].DrvStatus = DISABLE;
		
		if ( gNAND_SetFlagOfChangeAreaSize == DISABLE )
			gLBA_DevInfo->LBAInfo.FlagOfChangeTotalSectorSize = DISABLE;
		else
			gLBA_DevInfo->LBAInfo.FlagOfChangeTotalSectorSize = ENABLE;

		res = NAND_IO_LBA_Init( gLBA_DevInfo );
		if ( res != SUCCESS )
			return ERR_NAND_INIT_FAILED;

		NAND_IO_LBA_GetTotalSecAndCHS( gLBA_DevInfo,
									   NAND_LBA_DATA_AREA,
									   (U32)&gNAND_DrvInfo[nDrvNo].TotalDiskSector,
									   &gNAND_DrvInfo[nDrvNo].Cylinder,
									   &gNAND_DrvInfo[nDrvNo].Head,
									   &gNAND_DrvInfo[nDrvNo].Sector );

		gNAND_DrvInfo[nDrvNo].DrvStatus = ENABLE;
		#endif
	}

	return (NAND_ERROR)SUCCESS;
}

/******************************************************************************
*
*	int				NAND_ReadSector
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_ReadSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nReadBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		unsigned long int	count;
		HwTCNT4 = 0;
		#endif
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\n\nNAND_ReadSector( %08d, %08d ) -------------------------- ", LBA, nSecSize );
		#endif

		#ifdef NAND_DRV_UART_DEBUG
			#if defined(USE_V_ADDRESS)
				#if defined(_WINCE_)
				if ( gNAND_UARTDebugFlag == ENABLE )
				RETAILMSG(1,(TEXT( "\n\nNAND_ReadSector( %08d, %08d ) -------------------------- "), LBA, nSecSize ));
				#endif
			#endif
		#endif
		//==============================================================================
		
		if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		{
	        res = TNFTL_AREAReadSector( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								        &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->DTArea,
								        LBA, nSecSize, nReadBuffer );
		}
		else
		{
			#ifdef NAND_LBA_INCLUDE
			res = NAND_IO_LBA_ReadSector( gLBA_DevInfo,
										  NAND_LBA_DATA_AREA, 
										  LBA, nSecSize, nReadBuffer);
			#endif
		}

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		count = HwTCNT4;
		PRINTF( "\n[NAND_READ Sector %08d - %05d ] ( %d uS ) -------------------------- ",
		LBA,
		nSecSize,
		(count*267)/100);
		#endif
		//==============================================================================		

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( " FAIL %08X", res );
		#endif

		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	int				NAND_WriteSector
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_WriteSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nWriteBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		unsigned long int	count;
		HwTCNT4 = 0;
		#endif
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\n\nNAND_WriteSector( %08d, %08d ) -----------------------------------", LBA, nSecSize );
		#endif

		#ifdef NAND_DRV_UART_DEBUG
			#if defined(USE_V_ADDRESS)
				#if defined(_WINCE_)
				if ( gNAND_UARTDebugFlag == ENABLE )			
				RETAILMSG(1,(TEXT( "\n\nNAND_WriteSector( %08d, %08d ) -------------------------- "), LBA, nSecSize ));
				#endif
			#endif
		#endif
		
		//==============================================================================
		if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		{
	        res = TNFTL_AREAWriteSector( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								         &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->DTArea,
								         LBA, nSecSize, nWriteBuffer );
		}
		else
		{
			#ifdef NAND_LBA_INCLUDE
			res = NAND_IO_LBA_WriteSector( gLBA_DevInfo,
										  NAND_LBA_DATA_AREA, 
										  LBA, nSecSize, nWriteBuffer );
			#endif
		}

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		count = HwTCNT4;
		PRINTF( "\n[NAND_WRITE Sector %08d - %05d ] ( %d uS ) -------------------------- ",
		LBA,
		nSecSize,
		(count*267)/100);
		#endif
		//==============================================================================

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\nFAIL : %08X ", res );
		#endif

		return -1;
	}	

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	int				NAND_HDReadSector
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDReadSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nReadBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;
		
	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
	{
	    #if defined(_LINUX_) || defined(_WINCE_)
		res = TNFTL_AREAReadSector( gNAND_DrvInfo[0].NFTLDrvInfo,
									&gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[nDrvNo],
									LBA, nSecSize, nReadBuffer );
		#else
	    res = TNFTL_AREAReadSector( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								    &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MultiHDArea[0],
								    LBA, nSecSize, nReadBuffer );
		#endif
	}
	else
	{
		#ifdef NAND_LBA_INCLUDE
	
		res = NAND_IO_LBA_ReadSector( gLBA_DevInfo,
									  NAND_LBA_MULTI_HIDDEN_AREA_0, 
									  LBA, nSecSize, nReadBuffer);
		#endif
	}

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( " FAIL %08X", res );
		#endif

		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	int				NAND_HDWriteSector
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDWriteSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nWriteBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;

	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
	{
		#if defined(_LINUX_) || defined(_WINCE_)
		res = TNFTL_AREAWriteSector( gNAND_DrvInfo[0].NFTLDrvInfo,
									 &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[nDrvNo],
									 LBA, nSecSize, nWriteBuffer );
		#else
	    res = TNFTL_AREAWriteSector( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								     &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MultiHDArea[0],
								     LBA, nSecSize, nWriteBuffer );
		#endif
	}
	else
	{
		#ifdef NAND_LBA_INCLUDE	
		res = NAND_IO_LBA_WriteSector( gLBA_DevInfo,
									  NAND_LBA_MULTI_HIDDEN_AREA_0, 
									  LBA, nSecSize, nWriteBuffer );
		#endif
	}

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\nFAIL : %08X ", res );
		#endif

		return -1;
	}	

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	int				NAND_HDReadPage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDReadPage( U32 nHDPageAddr, U32 nPageSize, void* nReadBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		unsigned long int	count;
		HwTCNT4 = 0;
		#endif
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\n\nNAND_HDReadPage( %08d, %08d ) -----", nHDPageAddr, nPageSize );
		#endif
		//==============================================================================

		if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		{
	        res = TNFTL_AREAReadSector( gNAND_DrvInfo[0].NFTLDrvInfo,
								        &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea,
								        nHDPageAddr, nPageSize, nReadBuffer );
		}
		else
		{
			#ifdef NAND_LBA_INCLUDE
			res = NAND_IO_LBA_ReadSector( gLBA_DevInfo,
										  NAND_LBA_HIDDEN_AREA, 
										  nHDPageAddr, nPageSize, nReadBuffer );
			#endif
		}

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		count = HwTCNT4;
		PRINTF( "\n[NAND_HDReadPage %08d - %05d ] ( %d uS ) ---- ",
		LBA,
		nSecSize,
		(count*267)/100);
		#endif
		//==============================================================================

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\nFAIL : %08X ", res );
		#endif

		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/******************************************************************************
*
*	int				NAND_HDWritePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDWritePage( U32 nHDPageAddr, U32 nPageSize, void* nWriteBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;
	
		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		unsigned long int	count;
		HwTCNT4 = 0;
		#endif
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\n\nNAND_HDWritePage( %08d, %08d ) ----", nHDPageAddr, nPageSize );
		#endif
		//==============================================================================

		if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		{
	        res = TNFTL_AREAWriteSector( gNAND_DrvInfo[0].NFTLDrvInfo, 
								         &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea,
								         nHDPageAddr, nPageSize, nWriteBuffer );
		}
		else
		{
			#ifdef NAND_LBA_INCLUDE
			res = NAND_IO_LBA_WriteSector( gLBA_DevInfo,
										  NAND_LBA_HIDDEN_AREA, 
										  nHDPageAddr, nPageSize, nWriteBuffer );
			#endif
		}

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		count = HwTCNT4;
		PRINTF( "\n[NAND_HDWritePage %08d - %05d ] ( %d uS ) ---- ",
		LBA,
		nSecSize,
		(count*267)/100);
		#endif
		//==============================================================================

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\nFAIL : %08X ", res );
		#endif
	
		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/**************************************************************************
*  FUNCTION NAME : 
*  
*      int NAND_PhyReadPage( U32 nBlkAddr, U16 nPageAddr, U16 nCSorder, void* nReadBuffer );
*  
*  DESCRIPTION : 
*  
*  INPUT:
*			nBlkAddr	= 
*			nCSorder	= 
*			nPageAddr	= 
*			nReadBuffer	= 
*  
*  OUTPUT:	int - Return Type
*  			= 
*  
*  REMARK:	  by nemo
**************************************************************************/
int NAND_PhyReadPage( U32 nBlkAddr, U16 nPageAddr, U16 nCSorder, void* nReadBuffer )
{
	TNFTL_ERROR		res = SUCCESS;
	#if defined(NAND_INCLUDE)

	#ifdef NAND_DRV_UART_DEBUG
	if ( gNAND_UARTDebugFlag == ENABLE )
		PRINTF( "\nNAND_PhyReadPage( %08d, %08d ) ----", nBlkAddr, nPageAddr );
	#endif

	#if defined( TNFTL_V5_INCLUDE ) || defined(TNFTL_V6_INCLUDE)
	res = TNFTL_IOReadPhyPage( gNAND_DrvInfo[0].NFTLDrvInfo,
							   nBlkAddr, nPageAddr,
							   nCSorder, nReadBuffer );
	#endif
	
	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			PRINTF( "\nFAIL : %08X ", res );
		#endif
	
		return -1;
	}
	#endif

	return 0;
}

int NAND_MTD_Init( U32* rMTDStBlk, U32* rMTDEdBlk )
{  
	unsigned int 		i;
	unsigned int		nBlockPageAddr;
	unsigned int		nMTDStBlk, nMTDEdBlk;
	NAND_IO_DEVINFO		sDevInfo;
	NAND_IO_DEVINFO 	*nDevInfo;

	NAND_IO_GetDeviceInfo( 0, &sDevInfo);
	nDevInfo = &sDevInfo;

	if ( gNAND_DrvInfo[0].NFTLDrvInfo->IoStatus == DISABLE )
		return -1;	

	nMTDStBlk = nDevInfo->Feature.PBpV - gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaBlkNum;
	nMTDEdBlk = nDevInfo->Feature.PBpV - 1;

	for ( i = nMTDStBlk; i < nMTDEdBlk; ++i )
	{
		nBlockPageAddr = i << nDevInfo->ShiftPpB;
		
		NAND_IO_EraseBlock( nDevInfo, nBlockPageAddr, INTER_LEAVE_OFF );
	}
	
	*rMTDStBlk = nMTDStBlk;
	*rMTDEdBlk = nMTDEdBlk;

	return 0;
}

int NAND_MTD_WritePage( U32 nPageAddr, U8* nPageBuffer )
{
	unsigned char	*nSpareBuffer;
	NAND_IO_DEVINFO *nDevInfo;
	NAND_IO_ERROR	res;

	nDevInfo = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0];

	nSpareBuffer = (unsigned char *)nPageBuffer;
	//nSpareBuffer += nDevInfo->Feature.PageSize;
	nSpareBuffer += 2048;
	
	res = NAND_IO_WritePageMTD( nDevInfo, 
							  nPageAddr, 0, 4/*nDevInfo->PPages*/, 
							  nPageBuffer,
							  nSpareBuffer, ECC_ON );
	return res;
}

int NAND_MTD_ReadPage( U32 nPageAddr, U8* nPageBuffer )
{
	unsigned char	*nSpareBuffer;
	NAND_IO_DEVINFO *nDevInfo;
	NAND_IO_ERROR	res;
	
	nDevInfo = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0];

	nSpareBuffer = (unsigned char *)nPageBuffer;
	//nSpareBuffer += nDevInfo->Feature.PageSize;
	nSpareBuffer += 2048;
		
	res = NAND_IO_ReadPageMTD( nDevInfo, 
							  nPageAddr, 0, 4/*nDevInfo->PPages*/,
							  nPageBuffer,
							  nSpareBuffer, ECC_ON );
	return res;	
}


/******************************************************************************
*
*	int				NAND_Ioctl
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_Ioctl( int function, void *param )
{
	#if defined(_LINUX_) || defined(_WINCE_) || defined (NAND_LBA_INCLUDE)
	unsigned int	 i = 0;
	#endif
	
	switch( function )
	{
		case	DEV_INITIALIZE:
			{
				NAND_Init();
				
				#if defined(_LINUX_) || defined(_WINCE_)
				if ( gNAND_HiddenInfoLoadFlag == DISABLE )
					NAND_InitHiddenInfo();
				else
					TNFTL_SetMultiHiddenNums( NAND_DRV_0, (U16)gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenAreaNum );
				#else
				NAND_InitHiddenInfo();
				#endif

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    #ifdef BRWS_STR_NAND_INCLUDE
				    TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
											      &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea,
										  	      gTNFTL_HiddenInfo[NAND_DRV_0].HiddenPageSize
											      + BRWS_NAME_AREA_SIZE
											    #ifndef NU_FILE_INCLUDE
											    #ifdef AUDIOUI_INCLUDE
											      + AUI_HD_OCCPAGE
											    #endif
											    #endif
											    );
				    #else
				    TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
											      &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea,
											      gTNFTL_HiddenInfo[NAND_DRV_0].HiddenPageSize
											    #ifndef NU_FILE_INCLUDE
											    #ifdef AUDIOUI_INCLUDE
											      + AUI_HD_OCCPAGE
											    #endif
											    #endif
											    );
				    #endif

					#if defined(_LINUX_) || defined(_WINCE_)
					for ( i = 0; i < gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenAreaNum; ++i )
					{
						TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
													  &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[i],
													  gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenSize[i] );
					}
					#else
				    TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
											      &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0],
											      gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenSize[0] );
    
					#endif

				    gNAND_DrvInfo[0].DrvStatus = DISABLE;


				    if ( NAND_InitDrive(0) != SUCCESS )
					    return EINITFAIL;
    
				    TNFTL_AREAGetTotalSecAndCHS( gNAND_DrvInfo[0].NFTLDrvInfo,
								 			     &gNAND_DrvInfo[0].NFTLDrvInfo->DTArea,
								 			     (U32 *)&gNAND_DrvInfo[0].TotalDiskSector,
								 			     &gNAND_DrvInfo[0].Cylinder,
								 			     &gNAND_DrvInfo[0].Head,
								 			     &gNAND_DrvInfo[0].Sector );
    
				    gNAND_DrvInfo[0].DrvStatus = ENABLE;
				}
				else
				{
					#ifdef NAND_LBA_INCLUDE
				
					#ifdef BRWS_STR_NAND_INCLUDE
					gLBA_DevInfo->LBAInfo.HDAreaSectorSize = ( gTNFTL_HiddenInfo[NAND_DRV_0].HiddenPageSize
																						  + BRWS_NAME_AREA_SIZE
																						#ifndef NU_FILE_INCLUDE
																						#ifdef AUDIOUI_INCLUDE
																						  + AUI_HD_OCCPAGE
																						#endif
																						#endif
																						);
					#else
					gLBA_DevInfo->LBAInfo.HDAreaSectorSize = ( gTNFTL_HiddenInfo[NAND_DRV_0].HiddenPageSize
																						#ifndef NU_FILE_INCLUDE
																						#ifdef AUDIOUI_INCLUDE
																						  + AUI_HD_OCCPAGE
																						#endif
																						#endif
																						);
					#endif
					
					gLBA_DevInfo->LBAInfo.MHDAreaNums = TNFTL_MULTI_HIDDEN_AREA_NUM;			
					
					#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE					
					for ( i = 0; i < TNFTL_MULTI_HIDDEN_AREA_NUM; ++i )
						gLBA_DevInfo->LBAInfo.MHDAreaSectorSize[i] = gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenSize[i];
					#endif
					
					gNAND_DrvInfo[0].DrvStatus = DISABLE;
					
					if ( NAND_InitDrive(0) != SUCCESS )
						return EINITFAIL;
					
					gNAND_DrvInfo[0].DrvStatus = ENABLE;
					#endif
				}					
			}
			break;
			
		case	DEV_GET_DISKINFO:
			{
				ioctl_diskinfo_t	*info = (ioctl_diskinfo_t *) param;

				#ifdef NU_FILE_INCLUDE
				gFormatType	= TC_LOWLEVEL_NO;
				#endif
				info->cylinder		= gNAND_DrvInfo[0].Cylinder;
				info->head			= gNAND_DrvInfo[0].Head;
				info->sector		= gNAND_DrvInfo[0].Sector;
				info->sector_size	= 512;
				info->Total_sectors	= gNAND_DrvInfo[0].TotalDiskSector;				
			}
			break;
			
		case	DEV_FORMAT_DISK:
			{
				unsigned short	mode = *((unsigned short *)param);

				#ifdef NU_FILE_INCLUDE
				gFormatType	= TC_LOWLEVEL_NO;
				#endif

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    TNFTL_AREAFormat( gNAND_DrvInfo[0].NFTLDrvInfo,
								      &gNAND_DrvInfo[0].NFTLDrvInfo->DTArea,
								      mode );
				}
				#ifdef NAND_LBA_INCLUDE
				else
				{
				//	NAND_IO_LBA_AREAClear( gLBA_DevInfo, NAND_LBA_DATA_AREA );
				}
				#endif

				return NAND_InitDrive(0);
			}
			break;
			
		case	DEV_ERASE_INIT:
			{
				ioctl_diskeraseinit_t	*erase = (ioctl_diskeraseinit_t *) param;
				erase = erase;
			}
			break;
			
		case	DEV_ERASE_BLOCK:
			{
				ioctl_diskerase_t	*erase = (ioctl_diskerase_t *) param;
				erase = erase;				
			}
			break;
			
		case	DEV_WRITEBACK_ON_IDLE:
			{

			}
			break;
			
		case	DEV_ERASE_CLOSE:
			{

			}
			break;
			
		case	DEV_HIDDEN_READ_PAGE_4:
			{
				ioctl_diskhdread4_t	*hd_r = (ioctl_diskhdread4_t *) param;

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    TNFTL_AREAReadSectorBy4Byte( gNAND_DrvInfo[0].NFTLDrvInfo,
											     &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea,
												 (U32)hd_r->start_page,
												 (U16)hd_r->page_offset,
												 (U16)hd_r->read_size,
											     hd_r->buff );
			    }
				else
				{
					#ifdef NAND_LBA_INCLUDE
					NAND_IO_LBA_ReadSectorBy4Byte( gLBA_DevInfo,
												   NAND_LBA_VFP,
												   (U32)hd_r->start_page,
												   (U16)hd_r->page_offset,
												   (U16)hd_r->read_size,
												   hd_r->buff );
					#endif
				}

			}
			break;
		case	DEV_SET_POWER:
			{
				#ifdef NAND_LBA_INCLUDE			
				unsigned short	mode = *((unsigned short *)param);
				#endif
				
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
					// NOP
				}
				else
				{
					#ifdef NAND_LBA_INCLUDE

					if ( mode == DISK_STATE_STANDBY )
					{
						NAND_IO_LBA_PowerSaveMode( gLBA_DevInfo, DISABLE );
					}
					else if ( mode == DISK_STATE_IDLE )
					{
						NAND_IO_LBA_PowerSaveMode( gLBA_DevInfo, ENABLE );						
					}
					#endif
				}					
			}
			break;
		case	DEV_GET_MAX_SECTOR_PER_BLOCK:
			{
				unsigned short *value = (unsigned short *)param;
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    if ( gNAND_DrvInfo[0].DrvStatus == ENABLE )
					    *value = ( gNAND_DrvInfo[0].NFTLDrvInfo->PpB << gNAND_DrvInfo[0].NFTLDrvInfo->ShiftPPages );
				    else
					    *value = TNFTL_MAX_SUPPORT_NAND_IO_SECTOR_SIZE_PER_1PAGE;
				}
				else
				{
					*value = 2048; // PpB: 128 *  PPage: 16
				}
			}
			break;

		case	DEV_TELL_DATASTARTSECTOR:
			{
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    TNFTL_WCacheSetDataStartSector( gNAND_DrvInfo[0].NFTLDrvInfo,
												    &gNAND_DrvInfo[0].NFTLDrvInfo->DTArea,
												    *(unsigned int*)param );
				}
				
				break;
			}

		case	DEV_CHECK_CRC_NANDBOOT_IMAGE_ROM:
		#if defined (BOOTCRCCHEK)
			{
				BootCRC *pbootcrc;

				pbootcrc = (BootCRC*)param;
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
					return TNFTL_NBGetCRCValueOfImageFile(gNAND_DrvInfo[0].NFTLDrvInfo, &pbootcrc->crc128kchk, &pbootcrc->crcfullchk, &pbootcrc->bootfilesize);
				}
				else
					return 0;
			}
		#else
			{
				unsigned int	nOrgCRCcode1;
				unsigned int	nOrgCRCcode2;
				unsigned int	nRomFileSize;
				unsigned int	rRstCRCcode1;
				unsigned int	rRstCRCcode2;
		
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    return TNFTL_NBGetCRCOfImageFile( gNAND_DrvInfo[0].NFTLDrvInfo, 1,
												      &nOrgCRCcode1, &nOrgCRCcode2, &nRomFileSize,
												      &rRstCRCcode1, &rRstCRCcode2 );
			}
				else
					return 0;
		 	}
		#endif
			break;
		#ifdef TNFTL_V4_INCLUDE
		case	DEV_FORCE_FLUSH_CACHE_DATA:
			{
				return 	TNFTL_WCacheFourceFlushCache_DATA( gNAND_DrvInfo[0].NFTLDrvInfo,
											 		 	   &gNAND_DrvInfo[0].NFTLDrvInfo->DTArea );				
			}
			break;
		#endif
		#if defined( TNFTL_V5_INCLUDE ) || defined(TNFTL_V6_INCLUDE)
		case	DEV_SET_ALIGEN_CACHE:
			{
				unsigned short	mode = *((unsigned short *)param);
				return TNFTL_SetUseAlignCacheMode( gNAND_DrvInfo[0].NFTLDrvInfo, mode );
			}
			break;
		#endif
		case	DEV_GET_WRITE_PROTECT:
			return  0;
			break;
		case	DEV_GET_INSERTED:
			return 1;
		#ifdef NU_FILE_INCLUDE
		case	DEV_GET_HIDDEN_SIZE:
			if (gNAND_DrvInfo[0].DrvStatus == ENABLE)
				*(int *)param	= NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE;
			else
				*(int *)param	= -1;
			break;
        #endif
		case	DEV_GET_INITED:
			return 1;
		case DEV_GET_PLAYABLE_STATUS:
			return 1;			
		default:
			return	ENOTSUPPORT;
	}
	#endif
	return 0;	/* SUCCESS */
}

/******************************************************************************
*
*	int				NAND_HDIoctl
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDIoctl( int function, void *param )
{
	#if defined(_LINUX_) || defined(_WINCE_)
	unsigned int	 i;
	#endif

	switch( function )
	{
		case	DEV_INITIALIZE:
			{
				NAND_Init();
				
				#if defined(_LINUX_) || defined(_WINCE_)
				if ( gNAND_HiddenInfoLoadFlag == DISABLE )
					NAND_InitHiddenInfo();
				else
					TNFTL_SetMultiHiddenNums( NAND_DRV_0, (U16)gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenAreaNum );
				#endif

				#ifdef BRWS_STR_NAND_INCLUDE
				TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
											  &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea,
										  	  gTNFTL_HiddenInfo[NAND_DRV_0].HiddenPageSize
											  + BRWS_NAME_AREA_SIZE 
											#ifndef NU_FILE_INCLUDE
											#ifdef AUDIOUI_INCLUDE
											  + AUI_HD_OCCPAGE
											#endif
											#endif
											);
				#else
				TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
											  &gNAND_DrvInfo[0].NFTLDrvInfo->HDArea,
											  gTNFTL_HiddenInfo[NAND_DRV_0].HiddenPageSize
											#ifndef NU_FILE_INCLUDE
											#ifdef AUDIOUI_INCLUDE
											  + AUI_HD_OCCPAGE
											#endif
											#endif
											);
				#endif

				#if defined(_LINUX_) || defined(_WINCE_)
				for ( i = 0; i < gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenAreaNum; ++i )
				{
					TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
												  &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[i],
												  gTNFTL_HiddenInfo[NAND_DRV_0].MultiHiddenSize[i] );
				}
				#else
				TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
											  &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0],
											  NAND_HIDDEN_DRIVE_DEFAULT_TOTAL_SECTOR_SIZE );
				#endif

				gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].DrvStatus = DISABLE;
				
				if ( NAND_InitDrive(0) != SUCCESS )
					return EINITFAIL;

				TNFTL_AREAGetTotalSecAndCHS( gNAND_DrvInfo[0].NFTLDrvInfo,
								 			 &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0],
								 			 (U32 *)&gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].TotalDiskSector,
								 			 &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].Cylinder,
								 			 &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].Head,
								 			 &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].Sector );

				gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].DrvStatus = ENABLE;
			}
			break;
			
		case	DEV_GET_DISKINFO:
			{
				ioctl_diskinfo_t	*info = (ioctl_diskinfo_t *) param;

				info->cylinder		= gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].Cylinder;
				info->head			= gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].Head;
				info->sector		= gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].Sector;
				info->sector_size	= 512;
			}
			break;
			
		case	DEV_FORMAT_DISK:
			{
				unsigned short	mode = *((unsigned short *)param);

				TNFTL_AREAFormat( gNAND_DrvInfo[0].NFTLDrvInfo,
								  &gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0],
								  mode );

				return NAND_InitDrive(0);
			}
			break;
			
		case	DEV_ERASE_INIT:
			{
				ioctl_diskeraseinit_t	*erase = (ioctl_diskeraseinit_t *) param;
				erase = erase;
			}
			break;
			
		case	DEV_ERASE_BLOCK:
			{
				ioctl_diskerase_t	*erase = (ioctl_diskerase_t *) param;
				erase = erase;				
			}
			break;
			
		case	DEV_WRITEBACK_ON_IDLE:
			{

			}
			break;
			
		case	DEV_ERASE_CLOSE:
			{

			}
			break;
			
		case	DEV_HIDDEN_READ_PAGE_4:
			{

			}
			break;

		case	DEV_GET_MAX_SECTOR_PER_BLOCK:
			{
				unsigned short *value = (unsigned short *)param;

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].DrvStatus == ENABLE )
				{
					if ( gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0].TotalDiskSector >
					    (U32)( gNAND_DrvInfo[0].NFTLDrvInfo->PpB << gNAND_DrvInfo[0].NFTLDrvInfo->ShiftPPages ) * 2 )
						*value = ( gNAND_DrvInfo[0].NFTLDrvInfo->PpB << gNAND_DrvInfo[0].NFTLDrvInfo->ShiftPPages );
					else
						*value = TNFTL_MAX_SUPPORT_NAND_IO_SECTOR_SIZE_PER_1PAGE;
				}
				else
					*value = TNFTL_MAX_SUPPORT_NAND_IO_SECTOR_SIZE_PER_1PAGE;
			}
			break;

		case	DEV_TELL_DATASTARTSECTOR:
			{
				TNFTL_WCacheSetDataStartSector( gNAND_DrvInfo[0].NFTLDrvInfo,
												&gNAND_DrvInfo[0].NFTLDrvInfo->MultiHDArea[0],
												*(unsigned int*)param );
				break;
			}

		case	DEV_GET_WRITE_PROTECT:
			return  0;
			break;
		case	DEV_GET_INSERTED:
			return 1;
		case	DEV_GET_INITED:
			return 1;
		case DEV_GET_PLAYABLE_STATUS:
			return 1;			
		default:
			return	ENOTSUPPORT;
	}
	
	return 0;	/* SUCCESS */
}

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_ReadMultiSectorStart( U32 LBA, U16 nSecSize );
*  
*  DESCRIPTION : 
*  INPUT:
*			LBA	= 
*			nSecSize	= 
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_ReadMultiSectorStart( U32 LBA, U32 nSecSize )
{
	#ifdef NAND_INCLUDE
	LBA = 0;
	nSecSize = 0;
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_ReadMultiSectorStop( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_ReadMultiSectorStop( void )
{
	#ifdef NAND_INCLUDE
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_WriteMultiSectorStart( U32 LBA, U16 nSecSize );
*  
*  DESCRIPTION : 
*  INPUT:
*			LBA	= 
*			nSecSize	= 
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_WriteMultiSectorStart( U32 LBA, U32 nSecSize )
{
	#ifdef NAND_INCLUDE
	LBA = 0;
	nSecSize = 0;
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_WriteMultiSectorStop( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_WriteMultiSectorStop( void )
{
	#ifdef NAND_INCLUDE
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_HDClearPages( U32 nHDStPageAddr, U32 nHDEdPageAddr );
*  
*  DESCRIPTION : 
*  INPUT:
*			nHDEdPageAddr	= 
*			nHDStPageAddr	= 
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_HDClearPages( U32 nHDStPageAddr, U32 nHDEdPageAddr )
{
	#ifdef NAND_INCLUDE
	nHDStPageAddr = 0;
	nHDEdPageAddr = 0;
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	U16				NAND_GetSerialNumber
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
U16 NAND_GetSerialNumber( U8* rSerialNumber, U16 nSize )
{
	#ifdef NAND_INCLUDE
	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		return TNFTL_GetSerialNumber( gNAND_DrvInfo[0].NFTLDrvInfo, rSerialNumber, nSize );
	else
	{
		#ifdef NAND_LBA_INCLUDE
		return NAND_IO_LBA_GetSerialNumber( gLBA_DevInfo, gNAND_PageBuffer, rSerialNumber, nSize );
		#else
		return 0;
		#endif
	}
	#else
	return 0;
	#endif
}

/******************************************************************************
*
*	U16				NAND_GetUniqueID
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
U16 NAND_GetUniqueID( U8* rSerialNumber, U16 nSize )
{
	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
	{
		#if defined(NAND_INCLUDE) && !defined(_SDRAMONLY1_)
		unsigned int uiIDSize;

		uiIDSize = ( nSize < gNAND_DrvInfo[0].NFTLDrvInfo->MediaSizeOfUniqueID ) ? nSize : gNAND_DrvInfo[0].NFTLDrvInfo->MediaSizeOfUniqueID;
		memcpy((void*)rSerialNumber, (void*)gNAND_DrvInfo[0].NFTLDrvInfo->MediaUniqueID, uiIDSize);

		return (U16)uiIDSize;
		#else
		return 0;
		#endif
	}
	else
		return 0;
}

/******************************************************************************
*
*	TNFTL_ERROR		NAND_SetUartDebug
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
TNFTL_ERROR	NAND_SetUartDebug( unsigned int on_off )
{
	gNAND_UARTDebugFlag = (U8)on_off;

	return (TNFTL_ERROR)SUCCESS;
}	

#ifdef NU_FILE_INCLUDE
/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_Open                                                      
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function prepares the NAND Flash for usage by allocating the 
*       pages necessary for usage.                                       
*                                                                       
* INPUTS                                                                
*                                                                       
*       driveno                             The number assigned to the NAND Flash. 
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       YES                                 Successful Completion.      
*       NO                                  Couldn't allocate all of the
*                                            pages.                     
*                                                                       
*************************************************************************/
INT NAND_IO_Open(UINT16 driveno)
{
	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	NAND_Ioctl(DEV_INITIALIZE, NULL);
	NU_Release_Semaphore(&CAPP_SEM);
    	return(YES);
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_Open(UINT16 driveno);
*  
*  DESCRIPTION : 
*  INPUT:
*			driveno	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_Open(UINT16 driveno)
{
	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	NAND_HDIoctl(DEV_INITIALIZE, NULL);
	NU_Release_Semaphore(&CAPP_SEM);
    	return(YES);
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_RAW_Open                                                  
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function doesn't do anything for the NAND Flash.  It is      
*       included for devtable consistency.                              
*                                                                       
* INPUTS                                                                
*                                                                       
*       None.                                                           
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       None.                                                           
*                                                                       
*************************************************************************/
INT NAND_IO_RAW_Open(UINT16 driveno)
{
    return(NO);
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_RAW_Open(UINT16 driveno);
*  
*  DESCRIPTION : 
*  INPUT:
*			driveno	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_RAW_Open(UINT16 driveno)
{
    return(NO);
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_Close                                                     
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function deallocates all of the pages associated with the  
*       NAND Flash. The actual code here is commented out since we        
*       probably don't want to loose the data on a close.               
*                                                                       
* INPUTS                                                                
*                                                                       
*       driveno                             The number assigned to the NAND Flash.
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       YES                                 Successful Completion.      
*       NO                                  Couldn't allocate all of the
*                                            pages.                     
*                                                                       
*************************************************************************/
INT NAND_IO_Close(UINT16 driveno) 
{
    return(YES);
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_Close(UINT16 driveno) ;
*  
*  DESCRIPTION : 
*  INPUT:
*			driveno	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_Close(UINT16 driveno) 
{
    return(YES);
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_ReadWrite                                                        
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function reads or writes data from and to the NAND Flash     
*       based on the 'reading' parameter.                               
*                                                                       
* INPUTS                                                                
*                                                                       
*       driveno                             The number assigned to the  
*                                            RAM Disk (not used)        
*       block                               The block number to read or 
*                                            write                      
*       buffer                              Pointer to the data to be   
*                                            placed from a read or      
*                                            stored on a write          
*       count                               Number of bytes to be read  
*                                            or written                 
*       reading                             Indicates whether or not we 
*                                            are reading or writing     
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       YES                                 Successful Completion.      
*       NO                                  Block number is out of range.
*                                                                       
*************************************************************************/
INT NAND_IO_ReadWrite(UINT16 driveno, UINT32 block, VOID *buffer, UINT16 count, INT reading) 
{
	int result;

	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	
	if(reading)
		result = NAND_ReadSector(driveno, block, count, buffer);
	else
		result = NAND_WriteSector(driveno, block, count, buffer);

	NU_Release_Semaphore(&CAPP_SEM);

	if(!result)
		return (YES);
	else
		return (NO);
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_ReadWrite(UINT16 driveno, UINT32 block, VOID *buffer, UINT16 count, INT reading) ;
*  
*  DESCRIPTION : 
*  INPUT:
*			block	= 
*			buffer	= 
*			count	= 
*			driveno	= 
*			reading	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_ReadWrite(UINT16 driveno, UINT32 block, VOID *buffer, UINT16 count, INT reading) 
{
	int result;

	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);

	driveno	-= INTERNAL_HIDDEN_STORAGE_START_NO;
	if(reading)
		result = NAND_HDReadSector(driveno, block, count, buffer);
	else
		result = NAND_HDWriteSector(driveno, block, count, buffer);

	NU_Release_Semaphore(&CAPP_SEM);

	if(!result)
		return (YES);
	else
		return (NO);
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_Ioctl                                                     
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function doesn't do anything for the NAND Flash.  It is      
*       included for devtable consistency.                              
*                                                                       
* INPUTS                                                                
*                                                                       
*       None.                                                           
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       None.                                                           
*                                                                       
*************************************************************************/
INT NAND_IO_Ioctl(UINT16 driveno, UINT16 command, VOID *buffer)
{
	int result;

	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	result	= NAND_Ioctl(command, buffer);
	NU_Release_Semaphore(&CAPP_SEM);

	return result;
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_Ioctl(UINT16 driveno, UINT16 command, VOID *buffer);
*  
*  DESCRIPTION : 
*  INPUT:
*			buffer	= 
*			command	= 
*			driveno	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_Ioctl(UINT16 driveno, UINT16 command, VOID *buffer)
{
	int result;

	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	result	= NAND_HDIoctl(command, buffer);
	NU_Release_Semaphore(&CAPP_SEM);

	return result;
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

#endif	// NU_FILE_INCLUDE

//#endif	// WITHOUT_FILESYSTEM

/* end of file */
