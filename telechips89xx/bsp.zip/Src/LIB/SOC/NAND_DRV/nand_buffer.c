/****************************************************************************
 *   FileName    : nand_buffer.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include "nand_drv.h"


#if defined( FWDN_DOWNLOADER_INCLUDE )
const unsigned char	NANDBUF_Library_Version[] = { "SIGBYAHONG_NANDBUF_FWDN_V001000" };
#elif defined(TCC92XX)
const unsigned char	NANDBUF_Library_Version[] = { "SIGBYAHONG_NANDBUF_TCC92XX_V001000" };
#elif defined(TCC89XX)
const unsigned char	NANDBUF_Library_Version[] = { "SIGBYAHONG_NANDBUF_TCC89XX_V001000" };
#endif

//**********************************************************
//*
//*		Global Variables
//*
//**********************************************************
#if defined(_WINCE_)
#pragma pack(8)
unsigned char	gNAND_PageBuffer[TNFTL_MAX_SUPPORT_NAND_IO_PAGE_SIZE + TNFTL_MAX_SUPPORT_NAND_IO_SPARE_SIZE];
unsigned char	gNAND_RCacheDTAreaBuffer[TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE];
unsigned char	gNAND_AlignBuffer[TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE];
#pragma pack()
#elif defined(_LINUX_)
	//NOTE: In the case of LINUX, gNAND_PageBuffer is defined nand_drv.c
#else
__align(8) unsigned char	gNAND_PageBuffer[TNFTL_MAX_SUPPORT_NAND_IO_PAGE_SIZE + TNFTL_MAX_SUPPORT_NAND_IO_SPARE_SIZE];
__align(8) unsigned char 	gNAND_RCacheDTAreaBuffer[TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE];
__align(8) unsigned char	gNAND_AlignBuffer[TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE];
#endif

