/****************************************************************************
 *   FileName    : nand_drv_v7.c
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#if defined(_LINUX_)
#include "common.h"
#if defined(USE_V_ADDRESS)
#include <linux/kernel.h>
#include <linux/string.h>
#endif
#endif

#if defined(_LINUX_) || defined(_WINCE_)
//#include "IO_TCC7XX.h"
#include "nand_drv.h"
//#include "Disk.h"
#include "TC_File.h"
#else
#include "Globals.h"
#include "IO_TCCXXX.h"
#include "nand_drv.h"
#include "disk.h"
#include "FileBufferCtrl.h"
#include "Assert.h"
#endif

#ifdef _WINCE_
#include "bsp.h"
#include "args.h"
#endif

#if defined(__NUCLEUS_KERNEL__)
#include "TC_Kernel.h"
#endif

#ifdef AUDIOUI_INCLUDE	
#include "AudioUI.H"
#endif

//#define NAND_DRV_PORT_DEBUG

//#define TNFTL_READ_CACHE_INCLUDE
#define TNFTL_ALIGN_CACHE_INCLUDE

#ifdef BOOTCRCCHEK
	typedef struct _BootCRC
	{
		unsigned int crc128kchk;
		unsigned int crcfullchk;
		unsigned int bootfilesize;
	}BootCRC; 
#endif

#ifndef WITHOUT_FILESYSTEM

#if defined( FWDN_DOWNLOADER_INCLUDE )
const unsigned char	NANDDRV_Library_Version[] = { "SIGBYAHONG_NANDDRV_FWDN_V007014" };
#elif defined(TCC92XX)
const unsigned char	NANDDRV_Library_Version[] = { "SIGBYAHONG_NANDDRV_TCC92XX_V007014" };
#elif defined(TCC89XX)
const unsigned char	NANDDRV_Library_Version[] = { "SIGBYAHONG_NANDDRV_TCC89XX_V007014" };
#endif

//=============================================================================
//*
//*
//*                           [ DEFINITIONS ]
//*
//*
//=============================================================================
#if defined(_WINCE_)
#define TNFTL_EXTENDED_PARTITION_MAX_NUM			4
#define TNFTL_EXTENDED_PARTITION_NUM				2

#define NAND_HIDDEN_0_PAGESIZE						(33/*MB*/*1024*2)
#define NAND_HIDDEN_1_PAGESIZE						(3/*MB*/*1024*2)	// for LOGO
#define NAND_HIDDEN_2_PAGESIZE						(2/*MB*/*1024*2)
#define NAND_HIDDEN_3_PAGESIZE						(3/*MB*/*1024*2)

#define NAND_RO_AREA_SIZE_MB						0
#elif defined(_LINUX_)
#define TNFTL_EXTENDED_PARTITION_MAX_NUM			4
#define TNFTL_EXTENDED_PARTITION_NUM				1

#define NAND_HIDDEN_0_PAGESIZE						(32*1024*2)
#define NAND_HIDDEN_1_PAGESIZE						(1*1024*2)
#define NAND_HIDDEN_2_PAGESIZE						(2*1024*2)
#define NAND_HIDDEN_3_PAGESIZE						(3*1024*2)

#define NAND_RO_AREA_SIZE_MB						0	// MTD Area
#else
#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
#define TNFTL_EXTENDED_PARTITION_MAX_NUM			1
#define TNFTL_EXTENDED_PARTITION_NUM				1

#define NAND_HIDDEN_0_PAGESIZE						(4096)
#else
#define TNFTL_EXTENDED_PARTITION_MAX_NUM			1
#define TNFTL_EXTENDED_PARTITION_NUM				0

#define NAND_RO_AREA_SIZE_MB						0
#endif
#endif

//=============================================================================
//*
//*
//*                           [ CONST DATA DEFINE ]
//*
//*
//=============================================================================

//=============================================================================
//*
//*
//*                           [ GLOBAL VARIABLE DEFINE ]
//*
//*
//=============================================================================
NAND_DRVINFO		gNAND_DrvInfo[MAX_NAND_DRIVE];
TNFTL_EXT_PART_INFO	gTNFTL_ExtPartitionInfo[MAX_NAND_DRIVE];
TNFTL_DRVINFO		gTNFTL_DrvInfo[MAX_NAND_DRIVE];

TNFTL_RW_AREA		gTNFTL_ExtPartitionDrvInfo[MAX_NAND_DRIVE][TNFTL_EXTENDED_PARTITION_MAX_NUM];

TNFTL_LPT_BLOCK		gTNFTL_PriPartitionLPTBlk[MAX_NAND_DRIVE][TNFTL_LPT_BLK_NUM_For_PRIMARY_PARTITION];
TNFTL_LPT_BLOCK		gTNFTL_ExtPartitionLPTBlk[MAX_NAND_DRIVE][TNFTL_EXTENDED_PARTITION_MAX_NUM][TNFTL_LPT_BLK_NUM_For_EXTENDED_PARTITION];

TNFTL_WCACHE		gTNFTL_PriPartitionWCache[MAX_NAND_DRIVE][TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION];
TNFTL_WCACHE		gTNFTL_ExtPartitionWCache[MAX_NAND_DRIVE][TNFTL_EXTENDED_PARTITION_MAX_NUM][TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION];

#if defined( TNFTL_READ_CACHE_INCLUDE )
TNFTL_RCACHE_SLOT 	gTNFTL_PriPartitionRCache[MAX_NAND_DRIVE][TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE>>9];
TNFTL_RCACHE_SLOT	gTNFTL_ExtPartitionRCache[MAX_NAND_DRIVE][TNFTL_EXTENDED_PARTITION_MAX_NUM][TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE>>9];
#endif

TNFTL_MAINPB_INFO 	gTNFTL_PriPartitionMainPBInfo[MAX_NAND_DRIVE][TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION];
TNFTL_MAINPB_INFO 	gTNFTL_ExtPartitionMainPBInfo[MAX_NAND_DRIVE][TNFTL_EXTENDED_PARTITION_MAX_NUM][TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION];

NAND_IO_DEVINFO*	gLBA_DevInfo[LBA_MAX_SUPPORT_MULTI_NANDFLASH];

unsigned char		gNAND_UARTDebugFlag = TCC_NAND_TRACE_OFF;
unsigned char		gNAND_PartitionInfoLoadFlag = DISABLE;
#if defined(_LINUX_) || defined(_WINCE_)
unsigned char		gNAND_SetFlagOfChangeAreaSize = DISABLE;
unsigned char		gFormatType	= TC_LOWLEVEL_YES;
unsigned int		gMAX_ROMSIZE = MAX_ROMSIZE_NAND;
#else
unsigned char		gNAND_SetFlagOfChangeAreaSize = ENABLE;
#endif

#if defined(_WINCE_)
tSYSTEM_PARAM  		*pSYS_PARAM_NAND_DRV;
#endif

//=============================================================================
//*
//*
//*                           [ LOCAL FUNCTIONS DEFINE ]
//*
//*
//=============================================================================

//=============================================================================
//*
//*
//*                     [ EXTERN VARIABLE & FUNCTIONS DEFINE ]
//*
//*
//=============================================================================
extern unsigned char	NANDBUF_Library_Version[];
#if defined(_LINUX_)
unsigned char 			gNAND_PageBuffer[TNFTL_MAX_SUPPORT_NAND_IO_PAGE_SIZE + TNFTL_MAX_SUPPORT_NAND_IO_SPARE_SIZE] __attribute__((aligned(8)));
unsigned char 			gNAND_RCacheDTAreaBuffer[TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE] __attribute__((aligned(8)));
unsigned char 			gNAND_AlignBuffer[TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE] __attribute__((aligned(8)));
#else
extern unsigned char	gNAND_PageBuffer[TNFTL_MAX_SUPPORT_NAND_IO_PAGE_SIZE + TNFTL_MAX_SUPPORT_NAND_IO_SPARE_SIZE];
extern unsigned char 	gNAND_RCacheDTAreaBuffer[TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE];
extern unsigned char	gNAND_AlignBuffer[TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE];
#endif

extern NAND_IO_CYCLE	WriteCycleTime;
extern NAND_IO_CYCLE	ReadCycleTime;
extern NAND_IO_CYCLE	CommCycleTime;
extern unsigned int		gMaxBusClkMHZ;
extern unsigned int		gCycleTick;

#if !defined(NU_FILE_INCLUDE) && !defined(_LINUX_) && !defined(_WINCE_)
extern unsigned int		fat_cbuffer[];
#else
extern unsigned char	gFormatType;
#endif
	

#if !defined(FWDN_DOWNLOADER_INCLUDE) && !defined(_LINUX_) && !defined(_WINCE_)
	#ifdef MTP_INCLUDE
	extern void*		MTPMEM_AllocNandInitBuffer( void );
	extern unsigned int	MTPMEM_GetNandIintBufferSize( void );
	#else
	extern char			gFileBuffer[RAW_BUFFERSIZE];
	#endif
#endif

#if defined(_WINCE_)
extern void B_RETAILMSG(const char * fmt, ...);
#endif

/******************************************************************************
*
*	unsigned char*	NAND_TellLibraryVersion
*
*	Input	: NONE
*	Output	: NONE
*	Return	: NONE
*
*	Description :
*
*******************************************************************************/
//unsigned char*	NAND_TellLibraryVersion( void )
//{
//	return (unsigned char*)gNAND_HiddenInfoSignature;
//}	

/******************************************************************************
*
*	unsigned char*	NAND_DRV_TellLibraryVersion
*
*	Input	: NONE
*	Output	: NONE
*	Return	: NONE
*
*	Description :
*
*******************************************************************************/
unsigned char*	NAND_DRV_TellLibraryVersion( void )
{
	unsigned short int 	i = 0;

	if ( i )
		return (unsigned char*)NANDBUF_Library_Version;
	else
		return (unsigned char*)NANDDRV_Library_Version;
}

/*************************************************************************************
 *          NAND_Init
 *
 * Description  :
 * Argument     :
 * Return       :   if it is successed then return 0
 *                  if it is failed then return Error Code
 *
 *************************************************************************************/
void NAND_Init( void )
{
	#ifdef NAND_LBA_INCLUDE
	NAND_ERROR	res;
	#endif
		
	#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
	unsigned int 	i;
	#endif
	
	#if !defined(NU_FILE_INCLUDE) && !defined(FWDN_DOWNLOADER_INCLUDE) && !defined(_LINUX_) & !defined(_WINCE_)
	unsigned int	BufferSize;
	#endif

    //=====================================================
    // Initialize NAND IO & TNFTL Variable
    //=====================================================
	NAND_IO_Init();

    //=================================================================
    // Initialize TNFTL Driver
    //=================================================================
	/* Drive #0 */
	TNFTL_AllocMemAndLinkForDriver( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0], &gNAND_DrvInfo[NAND_DRV_0].NFTLDrvInfo );
	
	TNFTL_AllocMemAndLinkForLPT( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].PriPartition, &gTNFTL_PriPartitionLPTBlk[NAND_DRV_0][0], TNFTL_LPT_BLK_NUM_For_PRIMARY_PARTITION );
	TNFTL_AllocMemAndLinkForWCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].PriPartition, &gTNFTL_PriPartitionWCache[NAND_DRV_0][0], TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION );
	#if defined( TNFTL_READ_CACHE_INCLUDE )
	TNFTL_AllocMemAndLinkForRCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].PriPartition, &gTNFTL_PriPartitionRCache[NAND_DRV_0][0] );
	#endif
    TNFTL_AllocMemAndLinkForMainPBInfo( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].PriPartition, &gTNFTL_PriPartitionMainPBInfo[NAND_DRV_0][0], 2 );

	TNFTL_AllocMemAndLinkForExtendedPartition( NAND_DRV_0, &gTNFTL_ExtPartitionDrvInfo[NAND_DRV_0][0] );
	TNFTL_SetExtendedPartitionNums( NAND_DRV_0, TNFTL_EXTENDED_PARTITION_NUM );

	#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
	for ( i = 0; i < TNFTL_EXTENDED_PARTITION_MAX_NUM; ++i )
	{
		TNFTL_AllocMemAndLinkForLPT( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].ExtPartition[i], &gTNFTL_ExtPartitionLPTBlk[NAND_DRV_0][i][0], TNFTL_LPT_BLK_NUM_For_EXTENDED_PARTITION );
		TNFTL_AllocMemAndLinkForWCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].ExtPartition[i], &gTNFTL_ExtPartitionWCache[NAND_DRV_0][i][0], TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION );
		TNFTL_AllocMemAndLinkForMainPBInfo( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].ExtPartition[i], &gTNFTL_ExtPartitionMainPBInfo[NAND_DRV_0][i][0], TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION );
		#if defined( TNFTL_V5_INCLUDE ) || defined(TNFTL_V6_INCLUDE)
		TNFTL_AllocMemAndLinkForRCACHE( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].ExtPartition[i], &gTNFTL_ExtPartitionRCache[NAND_DRV_0][i][0] );
		#endif	
	}
	#endif

	TNFTL_Init( NAND_DRV_0 );
	TNFTL_SetStEdOfCS( NAND_DRV_0, NAND_IO_DRV0_START_CS, NAND_IO_DRV0_END_CS );

	TNFTL_AllocMemAndLinkForPageBuffer( NAND_DRV_0, gNAND_PageBuffer );

	#if defined( TNFTL_READ_CACHE_INCLUDE )
	TNFTL_AllocMemAndLinkForRCacheBuffer( NAND_DRV_0, &gTNFTL_DrvInfo[NAND_DRV_0].PriPartition, gNAND_RCacheDTAreaBuffer, TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE );
	TNFTL_SetUseAreaReadCacheMode( gNAND_DrvInfo[NAND_DRV_0].NFTLDrvInfo, &gTNFTL_DrvInfo[NAND_DRV_0].PriPartition, ENABLE );
	#endif
	
	#if defined( TNFTL_ALIGN_CACHE_INCLUDE )
	TNFTL_AllocMemAndLinkForAlignCacheBuffer( NAND_DRV_0, gNAND_AlignBuffer, TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE );
	#endif

	#if !defined(NU_FILE_INCLUDE) && !defined(_LINUX_) && !defined(_WINCE_)
	#ifndef FWDN_DOWNLOADER_INCLUDE
		#ifdef MTP_INCLUDE
		BufferSize = MTPMEM_GetNandIintBufferSize() / 4;
		#else
		BufferSize = RAW_BUFFERSIZE / 4;
		#endif

		if ( BufferSize > 65536 / 4 )
		{
			#ifdef MTP_INCLUDE
			TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, (unsigned char*)MTPMEM_AllocNandInitBuffer(), MTPMEM_GetNandIintBufferSize() / 4 );
			#else
			TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, gFileBuffer, RAW_BUFFERSIZE / 4 );
			#endif
		}
		else
		{
			TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, fat_cbuffer, 65536 / 4 );
		}
	#else	
		TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, fat_cbuffer, 65536 / 4 );
	#endif
	#endif

	#ifdef NAND_LBA_INCLUDE
	gLBA_DevInfo[0] = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0];
	gLBA_DevInfo[1] = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[1];
	gLBA_DevInfo[2] = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[2];
	gLBA_DevInfo[3] = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[3];
	
	gLBA_DevInfo[0]->LBAInfo.FlagOfChangeTotalSectorSize = DISABLE;
	res = NAND_IO_LBA_GetDeviceInfo( 0, gLBA_DevInfo[0] );
	if ( ( res == SUCCESS ) || ( gLBA_DevInfo[0]->Feature.MediaType & S_LBA ) )
		gNAND_DrvInfo[0].NFTLDrvInfo->NANDType = NAND_TYPE_LBA_NAND;
	else
		gNAND_DrvInfo[0].NFTLDrvInfo->NANDType = NAND_TYPE_PURE_NAND;
	#else
		gNAND_DrvInfo[0].NFTLDrvInfo->NANDType = NAND_TYPE_PURE_NAND;	
	#endif

	/* Init TNFTL MSC Debug Monitor */
	#if !defined(FWDN_DOWNLOADER_INCLUDE) && !defined(_LINUX_) && !defined(_WINCE_)
	#ifdef TNFTL_DEBUG_INCLUDE
	TNFTL_DEBUG_Init_Function(  MASS_SCSI_InitMSCDebugMonitor,
								VTC_SendData,
								VTC_ReceiveData,
								MASS_BulkOnly_SendData,
								MASS_BulkOnly_ReceiveData,
								MASS_SCSI_SetMSCDebugMonitorHandler,
								FWDN_PROT_ResponseAck,
								FWDN_PROT_ResponseNack);
	TNFTL_DEBUG_Init();
	#endif
	#endif

	return;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_InitExtPartitionInfo( void );
*  
*  DESCRIPTION : 
*  
*  INPUT :	NONE
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_InitExtPartitionInfo( void )
{
	gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtendedPartitionNum = TNFTL_EXTENDED_PARTITION_NUM;

#if (TNFTL_EXTENDED_PARTITION_NUM>0)
	gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[0] =  NAND_HIDDEN_0_PAGESIZE;
#endif
#if (TNFTL_EXTENDED_PARTITION_NUM>1)
	gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[1] =  NAND_HIDDEN_1_PAGESIZE;
#endif
#if (TNFTL_EXTENDED_PARTITION_NUM>2)
	gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[2] =  NAND_HIDDEN_2_PAGESIZE;
#endif
#if (TNFTL_EXTENDED_PARTITION_NUM>3)
	gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[3] =  NAND_HIDDEN_3_PAGESIZE;
#endif

	gTNFTL_ExtPartitionInfo[NAND_DRV_0].ROAreaSize = NAND_RO_AREA_SIZE_MB;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_SetFlagOfChangeAreaSize( unsigned char On_Off );
*  
*  DESCRIPTION :
*  
*  INPUT :
*			On_Off	= ENABLE/DISABLE
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_SetFlagOfChangeAreaSize( unsigned char On_Off )
{
	gNAND_SetFlagOfChangeAreaSize = On_Off;
	return;
}

/**************************************************************************
*  FUNCTION NAME : 
*  
*      void NAND_SetExtPartitionInfoLoagFlag( unsigned char On_Off );
*  
*  DESCRIPTION : 
*  
*  INPUT:
*			On_Off	= ENABLE/DISABLE
*  
*  OUTPUT:	void - Return Type
*  
**************************************************************************/
void NAND_SetExtPartitionInfoLoagFlag( unsigned char On_Off )
{
	gNAND_PartitionInfoLoadFlag = On_Off;
	return;
}
	
/******************************************************************************
*
*	NAND_ERROR		NAND_InitDrive
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
NAND_ERROR NAND_InitDrive( int nDrvNo )
{
	unsigned int	i = 0;
	TNFTL_ERROR res;
	#if defined(NU_FILE_INCLUDE) || defined(_LINUX_) || defined(_WINCE_)
	void		*pointer;
		#if defined(_LINUX_)
		unsigned				bufSize	= 64*1024;
		static unsigned int		Tempbuffer[64*1024];
		#else
		unsigned				bufSize	= 256*1024;
		static unsigned char	Tempbuffer[256*1024];
		#endif
	#endif

	unsigned int	 nTemp;
	
	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
	{
	    //===============================================================
	    // Check Drive I/O in the FTL Layer
	    //===============================================================	
	    gNAND_DrvInfo[nDrvNo].DrvStatus = DISABLE;
    
		#if defined(NU_FILE_INCLUDE)
	    pointer	= TC_Allocate_Memory(bufSize);
	    if (pointer == NULL)
			return	-1;
		#elif defined(_LINUX_) || defined(_WINCE_)
		pointer	= Tempbuffer;
		if (pointer == NULL)
			return	-1;
		#endif
    
		#if defined(NU_FILE_INCLUDE)|| defined(_LINUX_) || defined(_WINCE_)
			#if defined(_LINUX_)
			TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, pointer, bufSize );	/* [1193] */
			#else
	  	  	TNFTL_AllocMemAndLinkForMakeLPT( NAND_DRV_0, pointer, bufSize/4 );	/* [1193] */
			#endif
		#endif
    
	    if ( gNAND_SetFlagOfChangeAreaSize == DISABLE )
			TNFTL_SetFlagOfChangePartition( gNAND_DrvInfo[0].NFTLDrvInfo, DISABLE );
	    else	
		{
			TNFTL_SetFlagOfChangePartition( gNAND_DrvInfo[0].NFTLDrvInfo, ENABLE );
			TNFTL_SetAreaProtectFlag(DISABLE);		// Set Flag Only FWDN_MODE
		}
	    
		//=========================================================
		// Linux MTD Include
		//=========================================================
		#if defined(_LINUX_) //&& defined(_MTD_IO_INCLUDE_)
		TNFTL_SetROAreaSize( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo, gTNFTL_ExtPartitionInfo[NAND_DRV_0].ROAreaSize << 20, ENABLE );
		#else
		TNFTL_SetROAreaSize( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo, 0, DISABLE );
		#endif
		
		#if defined(_WINCE_)
		#if defined(USE_V_ADDRESS)
		// Boot Loader - Init Info Restoration
		if ( pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitStatus == ENABLE )
		{
			pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitStatus = DISABLE;
			return SUCCESS;
		}
		#endif
		#endif
		
		NAND_IO_GetDeviceInfo( 0, &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0] );
		nTemp 	= gMAX_ROMSIZE >> gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MediaDevInfo[0].ShiftPageSize;
		nTemp 	= nTemp >> gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->MediaDevInfo[0].ShiftPpB;
		nTemp 	= nTemp << 2;
		nTemp 	+= 20;
		TNFTL_SetNBAreaEndPBAddr(nTemp);		// 1 ~ n Block No...
				
	    res = TNFTL_InitDrive( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo );

		#if defined(USE_V_ADDRESS) && defined(_WINCE_)
			//--------------------------
			// NAND Cycle Info
			//--------------------------
			#if 1
			RETAILMSG(1, (TEXT("[NAND        ] [BClk %dMHZ][1Tick %d][RE-S:%d,P:%d,H:%d][WR-S:%d,P:%d,H:%d][COM-S:%d,P:%d,H:%d]\n"),
			gMaxBusClkMHZ,gCycleTick,ReadCycleTime.STP,ReadCycleTime.PW,ReadCycleTime.HLD,
			WriteCycleTime.STP,WriteCycleTime.PW,WriteCycleTime.HLD,CommCycleTime.STP,CommCycleTime.PW,CommCycleTime.HLD));
			#endif

			//--------------------------
			// NAND Area Size Info
			//--------------------------
			#if 0
			RETAILMSG(1, (TEXT("[NAND        ] [NB Area:%dMB][DT Area:%dMB]"), 
			( gMAX_ROMSIZE * 2 ) >> 20,	gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->PriPartition.TotalSectorSize >> 11 ));
			for ( i = 0; i < gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ExtendedPartitionNo; ++i )
				RETAILMSG(1, (TEXT( "[HD Area%d:%dMB]"), i, gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ExtPartition[i].TotalSectorSize >> 11 ));
			RETAILMSG(1, (TEXT("\n")));
			#endif

			//--------------------------
			// NAND Area Bad Block Info
			//--------------------------
			#if 0
			RETAILMSG(1, (TEXT( "[NAND        ] [BadBlockNum: %d]\n"),gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->FTLBadBlockNum ));
			RETAILMSG(1, (TEXT( "[NAND        ] [Blk:")));
			for ( i = 0; i < gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->FTLBadBlockNum; ++i )
				RETAILMSG(1, (TEXT( "%d "), ( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->FTLBadBlock[i] & 0x0000FFFF)));
			RETAILMSG(1, (TEXT("\n")));
			#endif

		    if ( res != SUCCESS )
				RETAILMSG(1, (TEXT( "\n[NAND        ] [NAND_Init_Error:0x%x]\n"), res ));
		#else
			//--------------------------
			// NAND Cycle Info
			//--------------------------
			#if 1
			ND_TRACE( "[NAND        ] [BClk %dMHZ][1Tick %d][RE-S:%d,P:%d,H:%d][WR-S:%d,P:%d,H:%d][COM-S:%d,P:%d,H:%d]\n",
			gMaxBusClkMHZ,gCycleTick,ReadCycleTime.STP,ReadCycleTime.PW,ReadCycleTime.HLD,
			WriteCycleTime.STP,WriteCycleTime.PW,WriteCycleTime.HLD,CommCycleTime.STP,CommCycleTime.PW,CommCycleTime.HLD );
			#endif

			//--------------------------
			// NAND Area Size Info
			//--------------------------			
			#if 1
			ND_TRACE( "[NAND        ] [NB Area:%dMB][DT Area:%dMB]", 
			(int)(gMAX_ROMSIZE * 2) >> 20,
			(int)(gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->PriPartition.TotalSectorSize >> 11));
			for ( i = 0; i < gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ExtendedPartitionNo; ++i )
				ND_TRACE( "[HD Area%d:%dMB]", i, (int)gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ExtPartition[i].TotalSectorSize >> 11 );
			#if defined(_LINUX_)
			if ( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ROAreaSize != 0 )
				ND_TRACE("[MTD Size:%dMB]", (int)gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ROAreaSize >> 20 );
			#endif
			ND_TRACE("\n");
			#endif

			//--------------------------
			// NAND Area Bad Block Info
			//--------------------------			
			#if 0
			ND_TRACE( "[NAND        ] [BadBlockNum: %d]\n",gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->FTLBadBlockNum );
			ND_TRACE( "[NAND        ] [Blk:");
			for ( i = 0; i < gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->FTLBadBlockNum; ++i )
				ND_TRACE( "%d ", ( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->FTLBadBlock[i] & 0x0000FFFF));
			ND_TRACE("]\n");
			#endif

		    if ( res != SUCCESS )
				ND_TRACE("\n[NAND        ] [NAND_Init_Error:0x%x]\n", res );

		#endif
	    
		#ifdef NU_FILE_INCLUDE
		TC_Deallocate_Memory(pointer);
		#endif
    
	    if ( res != SUCCESS )
		    return ERR_NAND_INIT_FAILED;
		    //return res; //original
    
	    TNFTL_AREAGetTotalSecAndCHS( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								     &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->PriPartition,
								     (U32 *)&gNAND_DrvInfo[nDrvNo].TotalDiskSector,
								     &gNAND_DrvInfo[nDrvNo].Cylinder,
								     &gNAND_DrvInfo[nDrvNo].Head,
								     &gNAND_DrvInfo[nDrvNo].Sector );
    
	    gNAND_DrvInfo[nDrvNo].DrvStatus = ENABLE;
	}
	else
	{
		#ifdef NAND_LBA_INCLUDE

		gNAND_DrvInfo[nDrvNo].DrvStatus = DISABLE;
		
		if ( gNAND_SetFlagOfChangeAreaSize == DISABLE )
			gLBA_DevInfo[0]->LBAInfo.FlagOfChangeTotalSectorSize = DISABLE;
		else
			gLBA_DevInfo[0]->LBAInfo.FlagOfChangeTotalSectorSize = ENABLE;

		res = NAND_IO_LBA_InitDrive( *gLBA_DevInfo );
		if ( res != SUCCESS )
			return ERR_NAND_INIT_FAILED;

		NAND_IO_LBA_GetTotalSecAndCHS( *gLBA_DevInfo,
									   NAND_LBA_DATA_AREA,
									   (U32)&gNAND_DrvInfo[nDrvNo].TotalDiskSector,
									   &gNAND_DrvInfo[nDrvNo].Cylinder,
									   &gNAND_DrvInfo[nDrvNo].Head,
									   &gNAND_DrvInfo[nDrvNo].Sector );

		gNAND_DrvInfo[nDrvNo].DrvStatus = ENABLE;
		#endif
	}

	return (NAND_ERROR)SUCCESS;
}

/******************************************************************************
*
*	int				NAND_ReadSector
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_ReadSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nReadBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		unsigned long int	count;
		HwTCNT4 = 0;
		#endif
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag & TCC_NAND_TRACE_DRV_READ )
			ND_TRACE( "\nNAND_ReadSector( %08d, %08d ) ---------------\n ", LBA, nSecSize );
		#endif

		#ifdef NAND_DRV_UART_DEBUG
			#if defined(USE_V_ADDRESS)
				#if defined(_WINCE_)
				if ( gNAND_UARTDebugFlag == ENABLE )
				RETAILMSG(1,(TEXT( "\n\nNAND_ReadSector( %08d, %08d ) -------------------------- "), LBA, nSecSize ));
				#endif
			#endif
		#endif
		//==============================================================================

		if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		{
	        res = TNFTL_AREAReadSector( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								        &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->PriPartition,
								        LBA, nSecSize, nReadBuffer );
		}
		else
		{
			#ifdef NAND_LBA_INCLUDE
			res = NAND_IO_LBA_ReadSector( *gLBA_DevInfo,
										  NAND_LBA_DATA_AREA, 
										  LBA, nSecSize, nReadBuffer);
			#endif
		}

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		count = HwTCNT4;
		ND_TRACE( "\n[NAND_READ Sector %08d - %05d ] ( %d uS ) -------------------------- ",
		LBA,
		nSecSize,
		(count*267)/100);
		#endif
		//==============================================================================		

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( " FAIL %08X", res );
		#endif

		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	int				NAND_ReadSectorIRQ
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_ReadSectorIRQ( int nDrvNo, ndd_work_info* nand_work_info )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;

	//=================[ For DEBUG ]================================================
	#ifdef NAND_DRV_UART_DEBUG
		#if defined(USE_V_ADDRESS)
			#if define(LINUX)
			printk("\nSectorNum:%d ---------------------------------", nand_work_info->SectorNum);
			for ( i = 0; i < nand_work_info->SectorNum; ++i )
				printk("\nBuf:0x%X", nand_work_info->BufferAddr[i]);

			printk("\n");
			#endif
		#endif
	#endif
	//==============================================================================
	res = TNFTL_AREAReadSectorIRQ( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
									   &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->PriPartition, 
									   nand_work_info );

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( " FAIL %08X", res );
		#endif

		ND_TRACE( " FAIL %08X", res );

		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/******************************************************************************
*
*	int				NAND_WriteSector
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_WriteSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nWriteBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;
	
		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		unsigned long int	count;
		HwTCNT4 = 0;
		#endif
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag & TCC_NAND_TRACE_DRV_WRITE )
			ND_TRACE( "\n\nNAND_WriteSector( %08d, %08d ) -----------------------------------", LBA, nSecSize );
		#endif

		#ifdef NAND_DRV_UART_DEBUG
			#if defined(USE_V_ADDRESS)
				#if defined(_WINCE_)
				if ( gNAND_UARTDebugFlag == ENABLE )			
				RETAILMSG(1,(TEXT( "\n\nNAND_WriteSector( %08d, %08d ) -------------------------- "), LBA, nSecSize ));
				#endif
			#endif
		#endif

		//==============================================================================
		if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		{
	        res = TNFTL_AREAWriteSector( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								         &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->PriPartition,
								         LBA, nSecSize, nWriteBuffer );
		}
		else
		{
			#ifdef NAND_LBA_INCLUDE
			res = NAND_IO_LBA_WriteSector( *gLBA_DevInfo,
										  NAND_LBA_DATA_AREA, 
										  LBA, nSecSize, nWriteBuffer );
			#endif
		}
			
		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		count = HwTCNT4;
		ND_TRACE( "\n[NAND_WRITE Sector %08d - %05d ] ( %d uS ) -------------------------- ",
		LBA,
		nSecSize,
		(count*267)/100);
		#endif
		//==============================================================================

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( "\nFAIL : %08X ", res );
		#endif

		return -1;
	}	

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/******************************************************************************
*
*	int				NAND_WriteSectorIRQ
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_WriteSectorIRQ( int nDrvNo, ndd_work_info* nand_work_info )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;
	
	//=================[ For DEBUG ]================================================
	#ifdef NAND_DRV_UART_DEBUG
		#if defined(USE_V_ADDRESS)
			#if define(LINUX)
			printk("\nSectorNum:%d ---------------------------------", nand_work_info->SectorNum);
			for ( i = 0; i < nand_work_info->SectorNum; ++i )
				printk("\nBuf:0x%X", nand_work_info->BufferAddr[i]);

			printk("\n");
			#endif
		#endif
	#endif
	//==============================================================================
	res = TNFTL_AREAWriteSectorIRQ( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
							 		&gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->PriPartition, 
							 		nand_work_info );

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( "\nFAIL : %08X ", res );
		#endif

		return -1;
	}	

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/******************************************************************************
*
*	int				NAND_HDReadSector
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDReadSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nReadBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;
		
	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
	{
	    #if defined(_LINUX_) || defined(_WINCE_)
		res = TNFTL_AREAReadSector( gNAND_DrvInfo[0].NFTLDrvInfo,
									&gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[nDrvNo + 1],
									LBA, nSecSize, nReadBuffer );
		#else
	    res = TNFTL_AREAReadSector( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								    &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ExtPartition[1],
								    LBA, nSecSize, nReadBuffer );
		#endif
	}
	else
	{
		#ifdef NAND_LBA_INCLUDE
		res = NAND_IO_LBA_ReadSector( *gLBA_DevInfo,
									  NAND_LBA_MULTI_HIDDEN_AREA_0, 
									  LBA, nSecSize, nReadBuffer);
		#endif
	}

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( " FAIL %08X", res );
		#endif

		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	int				NAND_HDWriteSector
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDWriteSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nWriteBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;

	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
	{
		#if defined(_LINUX_) || defined(_WINCE_)
		res = TNFTL_AREAWriteSector( gNAND_DrvInfo[0].NFTLDrvInfo,
									 &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[nDrvNo+1],
									 LBA, nSecSize, nWriteBuffer );
		#else
	    res = TNFTL_AREAWriteSector( gNAND_DrvInfo[nDrvNo].NFTLDrvInfo,
								     &gNAND_DrvInfo[nDrvNo].NFTLDrvInfo->ExtPartition[1],
								     LBA, nSecSize, nWriteBuffer );
		#endif
	}
	else
	{
		#ifdef NAND_LBA_INCLUDE	
		res = NAND_IO_LBA_WriteSector( *gLBA_DevInfo,
									  NAND_LBA_MULTI_HIDDEN_AREA_0, 
									  LBA, nSecSize, nWriteBuffer );
		#endif
	}

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( "\nFAIL : %08X ", res );
		#endif

		return -1;
	}	

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	int				NAND_HDReadPage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDReadPage( U32 nHDPageAddr, U32 nPageSize, void* nReadBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		unsigned long int	count;
		HwTCNT4 = 0;
		#endif
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( "\n\nNAND_HDReadPage( %08d, %08d ) -----", nHDPageAddr, nPageSize );
		#endif
		//==============================================================================

		if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		{
	        res = TNFTL_AREAReadSector( gNAND_DrvInfo[0].NFTLDrvInfo,
								        &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[0],
								        nHDPageAddr, nPageSize, nReadBuffer );
		}
		else
		{
			#ifdef NAND_LBA_INCLUDE
			res = NAND_IO_LBA_ReadSector( *gLBA_DevInfo,
										  NAND_LBA_HIDDEN_AREA, 
										  nHDPageAddr, nPageSize, nReadBuffer );
			#endif
		}

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		count = HwTCNT4;
		ND_TRACE( "\n[NAND_HDReadPage %08d - %05d ] ( %d uS ) ---- ",
		LBA,
		nSecSize,
		(count*267)/100);
		#endif
		//==============================================================================

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( "\nFAIL : %08X ", res );
		#endif

		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/******************************************************************************
*
*	int				NAND_HDWritePage
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDWritePage( U32 nHDPageAddr, U32 nPageSize, void* nWriteBuffer )
{
	#ifdef NAND_INCLUDE
	TNFTL_ERROR		res = SUCCESS;
	
		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		unsigned long int	count;
		HwTCNT4 = 0;
		#endif
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag & TCC_NAND_TRACE_DRV_WRITE )
			ND_TRACE( "\n\nNAND_HDWritePage( %08d, %08d ) ----", nHDPageAddr, nPageSize );
		#endif
		//==============================================================================

		if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		{
	        res = TNFTL_AREAWriteSector( gNAND_DrvInfo[0].NFTLDrvInfo, 
								         &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[0],
								         nHDPageAddr, nPageSize, nWriteBuffer );
		}
		else
		{
			#ifdef NAND_LBA_INCLUDE
			res = NAND_IO_LBA_WriteSector( *gLBA_DevInfo,
										  NAND_LBA_HIDDEN_AREA, 
										  nHDPageAddr, nPageSize, nWriteBuffer );
			#endif
		}

		//=================[ For DEBUG ]================================================
		#ifdef NAND_DRV_UART_MEASURE
		count = HwTCNT4;
		ND_TRACE( "\n[NAND_HDWritePage %08d - %05d ] ( %d uS ) ---- ",
		LBA,
		nSecSize,
		(count*267)/100);
		#endif
		//==============================================================================

	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( "\nFAIL : %08X ", res );
		#endif
	
		return -1;
	}

	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/**************************************************************************
*  FUNCTION NAME : 
*  
*      int NAND_PhyReadPage( U32 nBlkAddr, U16 nPageAddr, U16 nCSorder, void* nReadBuffer );
*  
*  DESCRIPTION : 
*  
*  INPUT:
*			nBlkAddr	= 
*			nCSorder	= 
*			nPageAddr	= 
*			nReadBuffer	= 
*  
*  OUTPUT:	int - Return Type
*  			= 
*  
*  REMARK:	  by nemo
**************************************************************************/
int NAND_PhyReadPage( U32 nBlkAddr, U16 nPageAddr, U16 nCSorder, void* nReadBuffer )
{
	TNFTL_ERROR		res = SUCCESS;
	#if defined(NAND_INCLUDE)
	#ifdef NAND_DRV_UART_DEBUG
	if ( gNAND_UARTDebugFlag == ENABLE )
		ND_TRACE( "\nNAND_PhyReadPage( %08d, %08d ) ----", nBlkAddr, nPageAddr );
	#endif

	res = TNFTL_IOReadPhyPage( gNAND_DrvInfo[0].NFTLDrvInfo,
							   nBlkAddr, nPageAddr,
							   nCSorder, nReadBuffer );	
	if ( res != SUCCESS )
	{
		#ifdef NAND_DRV_UART_DEBUG
		if ( gNAND_UARTDebugFlag == ENABLE )
			ND_TRACE( "\nFAIL : %08X ", res );
		#endif
	
		return -1;
	}
	#endif

	return 0;
}

int NAND_MTD_Init( U32* rMTDStBlk, U32* rMTDEdBlk )
{  
	unsigned int 		i;
	unsigned int		nBlockPageAddr;
	unsigned int		nMTDStBlk, nMTDEdBlk;
	NAND_IO_DEVINFO		sDevInfo;
	NAND_IO_DEVINFO 	*nDevInfo;
	NAND_IO_ERROR	res;

	NAND_IO_GetDeviceInfo( 0, &sDevInfo);
	nDevInfo = &sDevInfo;

	if ( gNAND_DrvInfo[0].NFTLDrvInfo->IoStatus == DISABLE )
		return -1;	

	nMTDStBlk = gNAND_DrvInfo[0].NFTLDrvInfo->NBArea.EdPBAddr - gNAND_DrvInfo[0].NFTLDrvInfo->ROAreaBlkNum;
	nMTDEdBlk = gNAND_DrvInfo[0].NFTLDrvInfo->NBArea.EdPBAddr;

	for ( i = nMTDStBlk; i < nMTDEdBlk; ++i )
	{
		nBlockPageAddr = i << nDevInfo->ShiftPpB;

		res = NAND_IO_EraseBlock( nDevInfo, nBlockPageAddr, INTER_LEAVE_OFF );
		if (res != SUCCESS)
			ND_TRACE("\nBadBlock:%d", i);
	}
	
	*rMTDStBlk = nMTDStBlk;
	*rMTDEdBlk = nMTDEdBlk;

	return 0;
}

int NAND_MTD_WritePage( U32 nPageAddr, U8* nPageBuffer )
{
	unsigned char	*nSpareBuffer;
	NAND_IO_DEVINFO *nDevInfo;
	NAND_IO_ERROR	res;

	nDevInfo = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0];

	nSpareBuffer = (unsigned char *)nPageBuffer;
	nSpareBuffer += 2048;
	
	res = NAND_IO_WritePageMTD( nDevInfo, 
							  nPageAddr, 0, 4/*nDevInfo->PPages*/, 
							  nPageBuffer,
							  nSpareBuffer, ECC_ON );
	return res;
}

int NAND_MTD_ReadPage( U32 nPageAddr, U8* nPageBuffer )
{
	unsigned char	*nSpareBuffer;
	NAND_IO_DEVINFO *nDevInfo;
	NAND_IO_ERROR	res;
	
	nDevInfo = &gNAND_DrvInfo[0].NFTLDrvInfo->MediaDevInfo[0];

	nSpareBuffer = (unsigned char *)nPageBuffer;
	nSpareBuffer += 2048;

	res = NAND_IO_ReadPageMTD( nDevInfo, 
							  nPageAddr, 0, 4/*nDevInfo->PPages*/,
							  nPageBuffer,
							  nSpareBuffer, ECC_ON );
	return res;	
}

int NAND_LowLevelFormat( int mode )
{
	unsigned int		i;
	unsigned int		nMediaNum;
	NAND_IO_DEVINFO		sDevInfo[NAND_IO_DRV0_END_CS+1];
	NAND_IO_DEVINFO		*nDevInfo;

	TNFTL_ERROR	res;

	NAND_Init();

	if ( ( mode == 1 ) || ( mode == 2 ) )
	{
		for ( i = NAND_IO_DRV0_START_CS; i < (unsigned int)( NAND_IO_DRV0_END_CS + 1 ); ++i )
		{
			if ( NAND_IO_GetDeviceInfo( i, &sDevInfo[nMediaNum] ) == SUCCESS )
			{
				++nMediaNum;
			}
			else
			{
				if ( i == 0 )
					return ERR_TNFTL_NOT_EXIST_NANDFLASH;
			}
		}

		for ( i = 0; i < nMediaNum; ++i )
		{
			nDevInfo = &sDevInfo[i];
			
			NAND_IO_EraseBlock( nDevInfo, 0, INTER_LEAVE_OFF );
		}

		if ( mode == 2 )
			TNFTL_SetUseCheckPattern( ENABLE );

		res = TNFTL_BMPRefresh( gNAND_DrvInfo[0].NFTLDrvInfo );
			if ( res != SUCCESS )
			return res;

		TNFTL_SetUseCheckPattern( DISABLE );	
	}
	else if ( mode == 3 )
	{
		res = TNFTL_ScanDevice( gNAND_DrvInfo[0].NFTLDrvInfo );
		if ( res != SUCCESS )
			return res;
	}

	return SUCCESS;
}

#if defined(_WINCE_)
NAND_ERROR NAND_DriveStatusControl( int nMode )
{
	unsigned int 		nStructureIndex = 0;
	NAND_ERROR			res;
	
	if ( nMode == NAND_DRVINFO_SAVE )
	{
		nStructureIndex = 0;
		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(void*)gNAND_DrvInfo,
			    ( sizeof(NAND_DRVINFO) * MAX_NAND_DRIVE ) );
		nStructureIndex += ( sizeof(NAND_DRVINFO) * MAX_NAND_DRIVE );
		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex],
				(void*)gTNFTL_DrvInfo,
			    ( sizeof(TNFTL_DRVINFO) * MAX_NAND_DRIVE ) );
		nStructureIndex	+= ( sizeof(TNFTL_DRVINFO) * MAX_NAND_DRIVE );

		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
			 	(void*)gTNFTL_ExtPartitionDrvInfo, 						
			    (( sizeof(TNFTL_RW_AREA) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM ) );
		nStructureIndex += (( sizeof(TNFTL_RW_AREA) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM );

		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(void*)gTNFTL_PriPartitionLPTBlk, 
				(( sizeof(TNFTL_LPT_BLOCK) * MAX_NAND_DRIVE ) * TNFTL_LPT_BLK_NUM_For_PRIMARY_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_LPT_BLOCK) * MAX_NAND_DRIVE ) * TNFTL_LPT_BLK_NUM_For_PRIMARY_PARTITION );

		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(void*)gTNFTL_ExtPartitionLPTBlk, 
			  	(( sizeof(TNFTL_LPT_BLOCK) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_LPT_BLK_NUM_For_EXTENDED_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_LPT_BLOCK) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_LPT_BLK_NUM_For_EXTENDED_PARTITION );

		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(void*)gTNFTL_PriPartitionWCache, 
				(( sizeof(TNFTL_WCACHE) * MAX_NAND_DRIVE ) * TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_WCACHE) * MAX_NAND_DRIVE ) * TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION );

		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(void*)gTNFTL_ExtPartitionWCache,
				(( sizeof(TNFTL_WCACHE) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_WCACHE) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION );

		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex],
				(void*)gTNFTL_PriPartitionMainPBInfo, 
				(( sizeof(TNFTL_MAINPB_INFO) * MAX_NAND_DRIVE ) * TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_MAINPB_INFO) * MAX_NAND_DRIVE ) * TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION );

		
		memcpy( (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(void*)gTNFTL_ExtPartitionMainPBInfo, 
				(( sizeof(TNFTL_MAINPB_INFO) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION ) );

		res = (NAND_ERROR)SUCCESS;
	}
	else if ( nMode == NAND_DRVINFO_LOAD )
	{
		// Boot Loader - Init Info Restoration
		nStructureIndex = 0;

		memcpy( (void*)gNAND_DrvInfo, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
			    ( sizeof(NAND_DRVINFO) * MAX_NAND_DRIVE ) );
		nStructureIndex += ( sizeof(NAND_DRVINFO) * MAX_NAND_DRIVE );

		memcpy( (void*)gTNFTL_DrvInfo, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
			    ( sizeof(TNFTL_DRVINFO) * MAX_NAND_DRIVE ) );
		nStructureIndex	+= ( sizeof(TNFTL_DRVINFO) * MAX_NAND_DRIVE );

		memcpy( (void*)gTNFTL_ExtPartitionDrvInfo, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
			    (( sizeof(TNFTL_RW_AREA) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM ) );
		nStructureIndex += (( sizeof(TNFTL_RW_AREA) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM );

		memcpy( (void*)gTNFTL_PriPartitionLPTBlk, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(( sizeof(TNFTL_LPT_BLOCK) * MAX_NAND_DRIVE ) * TNFTL_LPT_BLK_NUM_For_PRIMARY_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_LPT_BLOCK) * MAX_NAND_DRIVE ) * TNFTL_LPT_BLK_NUM_For_PRIMARY_PARTITION );
		
		memcpy( (void*)gTNFTL_ExtPartitionLPTBlk, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
			  	(( sizeof(TNFTL_LPT_BLOCK) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_LPT_BLK_NUM_For_EXTENDED_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_LPT_BLOCK) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_LPT_BLK_NUM_For_EXTENDED_PARTITION );

		memcpy( (void*)gTNFTL_PriPartitionWCache, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(( sizeof(TNFTL_WCACHE) * MAX_NAND_DRIVE ) * TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_WCACHE) * MAX_NAND_DRIVE ) * TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION );

		memcpy( (void*)gTNFTL_ExtPartitionWCache, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(( sizeof(TNFTL_WCACHE) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_WCACHE) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION );
		
		memcpy( (void*)gTNFTL_PriPartitionMainPBInfo, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(( sizeof(TNFTL_MAINPB_INFO) * MAX_NAND_DRIVE ) * TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION ) );
		nStructureIndex += (( sizeof(TNFTL_MAINPB_INFO) * MAX_NAND_DRIVE ) * TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION );

		memcpy( (void*)gTNFTL_ExtPartitionMainPBInfo, 
			    (void*)&pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitInfo[nStructureIndex], 
				(( sizeof(TNFTL_MAINPB_INFO) * MAX_NAND_DRIVE ) * TNFTL_EXTENDED_PARTITION_MAX_NUM * TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION ) );
		res = (NAND_ERROR)SUCCESS;		
	}
	else
	{		
		res = ERR_NAND_WRONG_PARAMETER;
	}

	return res;
}
#endif

/******************************************************************************
*
*	int				NAND_Ioctl
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_Ioctl( int function, void *param )
{
	#if defined(_LINUX_) || defined(_WINCE_) || defined (NAND_LBA_INCLUDE)
	unsigned int	 i = 0;
	#endif

	switch( function )
	{
		case	DEV_INITIALIZE:
			{
				#if defined(_WINCE_)
				#if defined(USE_V_ADDRESS)
				pSYS_PARAM_NAND_DRV	= (tSYSTEM_PARAM*)tcc_allocbaseaddress((unsigned int)SYSTEM_PARAM_BASEADDRESS);
				#else
				pSYS_PARAM_NAND_DRV	= (tSYSTEM_PARAM*)(SYSTEM_PARAM_BASEADDRESS);
				#endif
				#endif
								
				#if defined(_WINCE_)
				#if defined(USE_V_ADDRESS)
				if ( pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitStatus == ENABLE )
				{
					NAND_DriveStatusControl( NAND_DRVINFO_LOAD );
				}
				#endif
				#endif

				NAND_Init();
					
				#if defined(_LINUX_) || defined(_WINCE_)
				if ( gNAND_PartitionInfoLoadFlag == DISABLE )
					NAND_InitExtPartitionInfo();
				else
					TNFTL_SetExtendedPartitionNums( NAND_DRV_0, (U16)gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtendedPartitionNum );
				#else
				NAND_InitExtPartitionInfo();
				#endif

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
					#if defined(_WINCE_)
					#if defined(USE_V_ADDRESS)
					if ( pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitStatus != ENABLE )
					#endif
					#endif
					{
					for ( i = 0; i < gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtendedPartitionNum; ++i )
					{
						TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
													  &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[i],
													  gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[i] );
					}


					}
	    
				    gNAND_DrvInfo[0].DrvStatus = DISABLE;

				    if ( NAND_InitDrive(0) != SUCCESS )
					    return EINITFAIL;
    
				    TNFTL_AREAGetTotalSecAndCHS( gNAND_DrvInfo[0].NFTLDrvInfo,
								 			     &gNAND_DrvInfo[0].NFTLDrvInfo->PriPartition,
								 			     (U32 *)&gNAND_DrvInfo[0].TotalDiskSector,
								 			     &gNAND_DrvInfo[0].Cylinder,
								 			     &gNAND_DrvInfo[0].Head,
								 			     &gNAND_DrvInfo[0].Sector );
    
				    gNAND_DrvInfo[0].DrvStatus = ENABLE;

					#if defined(_WINCE_)
					#if defined(USE_V_ADDRESS)
					// Boot Loader - Init Info Restoration
					pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitStatus = DISABLE;
					#else
					pSYS_PARAM_NAND_DRV->NAND_INFO.sNandInitStatus = ENABLE;
					NAND_DriveStatusControl( NAND_DRVINFO_SAVE );
					#endif
					#endif
				}
				else
				{
					#ifdef NAND_LBA_INCLUDE
				
					#ifdef BRWS_STR_NAND_INCLUDE
					gLBA_DevInfo[0]->LBAInfo.HDAreaSectorSize = ( gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[0] + BRWS_NAME_AREA_SIZE
																						#ifndef NU_FILE_INCLUDE
																						#ifdef AUDIOUI_INCLUDE
																						  + AUI_HD_OCCPAGE
																						#endif
																						#endif
																						);
					#else
					gLBA_DevInfo[0]->LBAInfo.HDAreaSectorSize = ( gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[0]
																						#ifndef NU_FILE_INCLUDE
																						#ifdef AUDIOUI_INCLUDE
																						  + AUI_HD_OCCPAGE
																						#endif
																						#endif
																						);
					#endif
					
					gLBA_DevInfo[0]->LBAInfo.MHDAreaNums = TNFTL_EXTENDED_PARTITION_NUM;			
					
					#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE					
					for ( i = 0; i < TNFTL_EXTENDED_PARTITION_NUM - 1; ++i )
						gLBA_DevInfo[0]->LBAInfo.MHDAreaSectorSize[i+1] = gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[i+1];
					#endif
					
					gNAND_DrvInfo[0].DrvStatus = DISABLE;
					
					if ( NAND_InitDrive(0) != SUCCESS )
						return EINITFAIL;
					
					gNAND_DrvInfo[0].DrvStatus = ENABLE;
					#endif
				}					
			}
			break;
			
		case	DEV_GET_DISKINFO:
			{
				ioctl_diskinfo_t	*info = (ioctl_diskinfo_t *) param;

				#ifdef NU_FILE_INCLUDE
				gFormatType	= TC_LOWLEVEL_NO;
				#endif
				info->cylinder		= gNAND_DrvInfo[0].Cylinder;
				info->head			= gNAND_DrvInfo[0].Head;
				info->sector		= gNAND_DrvInfo[0].Sector;
				info->sector_size	= 512;
				info->Total_sectors	= gNAND_DrvInfo[0].TotalDiskSector;				
			}
			break;
			
		case	DEV_FORMAT_DISK:
			{
				unsigned short	mode = *((unsigned short *)param);

				#ifdef NU_FILE_INCLUDE
				gFormatType	= TC_LOWLEVEL_NO;
				#endif

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    TNFTL_AREAFormat( gNAND_DrvInfo[0].NFTLDrvInfo,
								      &gNAND_DrvInfo[0].NFTLDrvInfo->PriPartition,
								      mode );
				}
				#ifdef NAND_LBA_INCLUDE
				else
				{
				//	NAND_IO_LBA_AREAClear( gLBA_DevInfo, NAND_LBA_DATA_AREA );
				}
				#endif

				return NAND_InitDrive(0);
			}
			break;
			
		case	DEV_ERASE_INIT:
			{
				ioctl_diskeraseinit_t	*erase = (ioctl_diskeraseinit_t *) param;
				erase = erase;
			}
			break;
			
		case	DEV_ERASE_BLOCK:
			{
				ioctl_diskerase_t	*erase = (ioctl_diskerase_t *) param;
				erase = erase;				
			}
			break;
			
		case	DEV_WRITEBACK_ON_IDLE:
			{

			}
			break;
			
		case	DEV_ERASE_CLOSE:
			{

			}
			break;
			
		case	DEV_HIDDEN_READ_PAGE_4:
			{
				ioctl_diskhdread4_t	*hd_r = (ioctl_diskhdread4_t *) param;

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    TNFTL_AREAReadSectorBy4Byte( gNAND_DrvInfo[0].NFTLDrvInfo,
											     &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[0],
												 (U32)hd_r->start_page,
												 (U16)hd_r->page_offset,
												 (U16)hd_r->read_size,
											     hd_r->buff );
			    }
				else
				{
					#ifdef NAND_LBA_INCLUDE
					NAND_IO_LBA_ReadSectorBy4Byte( *gLBA_DevInfo,
												   NAND_LBA_VFP,
												   (U32)hd_r->start_page,
												   (U16)hd_r->page_offset,
												   (U16)hd_r->read_size,
												   hd_r->buff );
					#endif
				}

			}
			break;
		case	DEV_SET_POWER:
			{
				#ifdef NAND_LBA_INCLUDE			
				unsigned short	mode = *((unsigned short *)param);
				unsigned short int	wCSorder;
				unsigned short int	wMediaNums;
				#endif
				
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
					// NOP
				}
				else
				{
					#ifdef NAND_LBA_INCLUDE
					NAND_IO_LBA_GetDeviceMediaNums( &wMediaNums );

					if ( mode == DISK_STATE_STANDBY )
					{
						for ( wCSorder = 0; wCSorder < wMediaNums; ++wCSorder )
						{
							NAND_IO_LBA_PowerSaveMode( gLBA_DevInfo[wCSorder], DISABLE );
							NAND_IO_LBA_HighSpeedMode( gLBA_DevInfo[wCSorder], ENABLE );
						}
					}
					else if ( mode == DISK_STATE_IDLE )
					{
						for ( wCSorder = 0; wCSorder < wMediaNums; ++wCSorder )
						{
							NAND_IO_LBA_PowerSaveMode( gLBA_DevInfo[wCSorder], ENABLE );	
							NAND_IO_LBA_HighSpeedMode( gLBA_DevInfo[wCSorder], DISABLE );
						}
					}
					#endif
				}					
			}
			break;
		case	DEV_GET_MAX_SECTOR_PER_BLOCK:
			{
				unsigned short *value = (unsigned short *)param;
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    if ( gNAND_DrvInfo[0].DrvStatus == ENABLE )
					    *value = ( gNAND_DrvInfo[0].NFTLDrvInfo->PpB << gNAND_DrvInfo[0].NFTLDrvInfo->ShiftPPages );
				    else
					    *value = TNFTL_MAX_SUPPORT_NAND_IO_SECTOR_SIZE_PER_1PAGE;
				}
				else
				{
					*value = 2048; // PpB: 128 *  PPage: 16
				}
			}
			break;

		case	DEV_TELL_DATASTARTSECTOR:
			{
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    TNFTL_WCacheSetDataStartSector( gNAND_DrvInfo[0].NFTLDrvInfo,
												    &gNAND_DrvInfo[0].NFTLDrvInfo->PriPartition,
												    *(unsigned int*)param );
				}
				
				break;
			}

		case	DEV_CHECK_CRC_NANDBOOT_IMAGE_ROM:
#ifdef TODO_NEMO		/* 09.04.13 */
		#if defined (BOOTCRCCHEK)
			{
				BootCRC *pbootcrc;

				pbootcrc = (BootCRC*)param;
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
					return TNFTL_NBGetCRCValueOfImageFile(gNAND_DrvInfo[0].NFTLDrvInfo, &pbootcrc->crc128kchk, &pbootcrc->crcfullchk, &pbootcrc->bootfilesize);
				}
				else
					return 0;
			}
		#else
			{
				unsigned int	nOrgCRCcode1;
				unsigned int	nOrgCRCcode2;
				unsigned int	nRomFileSize;
				unsigned int	rRstCRCcode1;
				unsigned int	rRstCRCcode2;
		
				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				    return TNFTL_NBGetCRCOfImageFile( gNAND_DrvInfo[0].NFTLDrvInfo, 1,
												      &nOrgCRCcode1, &nOrgCRCcode2, &nRomFileSize,
												      &rRstCRCcode1, &rRstCRCcode2 );
			}
				else
					return 0;
		 	}
		#endif
#endif /* TODO_NEMO */
			break;
		#ifdef TNFTL_V4_INCLUDE
		case	DEV_FORCE_FLUSH_CACHE_DATA:
			{
				return 	TNFTL_WCacheFourceFlushCache_DATA( gNAND_DrvInfo[0].NFTLDrvInfo,
											 		 	   &gNAND_DrvInfo[0].NFTLDrvInfo->PriPartition );				
			}
			break;
		#endif
		#if defined( TNFTL_ALIGN_CACHE_INCLUDE )
		case	DEV_SET_ALIGEN_CACHE:
			{
				unsigned short	mode = *((unsigned short *)param);

				#if defined(USE_V_ADDRESS)				
				#if defined(_WINCE_)
				if ( mode == ENABLE )
		 			RETAILMSG(0, (TEXT("[NAND        ]Align Cache Turn On\r\n")));
				else
		 			RETAILMSG(0, (TEXT("[NAND        ]Align Cache Turn Off\r\n")));
				#else
				if ( mode == ENABLE )
					ND_TRACE("\n[NAND        ]Align Cache Turn On");
				else
					ND_TRACE("\n[NAND        ]Align Cache Turn Off");					
				#endif
				#endif
				
				return TNFTL_SetUseAlignCacheMode( gNAND_DrvInfo[0].NFTLDrvInfo, mode );
			}
			break;
		#endif
		case	DEV_GET_WRITE_PROTECT:
			return  0;
			break;
		case	DEV_GET_INSERTED:
			return 1;
		#ifdef NU_FILE_INCLUDE
		case	DEV_GET_HIDDEN_SIZE:
			if (gNAND_DrvInfo[0].DrvStatus == ENABLE)
				*(int *)param	= NAND_HIDDEN_0_PAGESIZE;
			else
				*(int *)param	= -1;
			break;
        #endif
		case	DEV_GET_INITED:
			return 1;
		case DEV_GET_PLAYABLE_STATUS:
			return 1;			
		default:
			return	ENOTSUPPORT;
	}
	#endif
	return 0;	/* SUCCESS */
}

/******************************************************************************
*
*	int				NAND_HDIoctl
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
int NAND_HDIoctl( int function, void *param )
{
	#if defined(_LINUX_) || defined(_WINCE_)
	unsigned int	 i;
	#endif

	switch( function )
	{
		case	DEV_INITIALIZE:
			{
				NAND_Init();
				
				#if defined(_LINUX_) || defined(_WINCE_)
				if ( gNAND_PartitionInfoLoadFlag == DISABLE )
					NAND_InitExtPartitionInfo();
				else
					TNFTL_SetExtendedPartitionNums( NAND_DRV_0, (U16)gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtendedPartitionNum );
				#endif


				for ( i = 0; i < gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtendedPartitionNum; ++i )
				{
					TNFTL_AREASetTotalSectorSize( gNAND_DrvInfo[0].NFTLDrvInfo,
												  &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[i],
												  gTNFTL_ExtPartitionInfo[NAND_DRV_0].ExtPartitionSize[i] );
				}

				gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].DrvStatus = DISABLE;
				
				if ( NAND_InitDrive(0) != SUCCESS )
					return EINITFAIL;

				TNFTL_AREAGetTotalSecAndCHS( gNAND_DrvInfo[0].NFTLDrvInfo,
								 			 &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1],
								 			 (U32 *)&gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].TotalDiskSector,
								 			 &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].Cylinder,
								 			 &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].Head,
								 			 &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].Sector );

				gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].DrvStatus = ENABLE;
			}
			break;
			
		case	DEV_GET_DISKINFO:
			{
				ioctl_diskinfo_t	*info = (ioctl_diskinfo_t *) param;

				info->cylinder		= gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].Cylinder;
				info->head			= gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].Head;
				info->sector		= gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].Sector;
				info->sector_size	= 512;
			}
			break;
			
		case	DEV_FORMAT_DISK:
			{
				unsigned short	mode = *((unsigned short *)param);

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
				{
				TNFTL_AREAFormat( gNAND_DrvInfo[0].NFTLDrvInfo,
								  &gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1],
								  mode );
				}

				return NAND_InitDrive(0);
			}
			break;
			
		case	DEV_ERASE_INIT:
			{
				ioctl_diskeraseinit_t	*erase = (ioctl_diskeraseinit_t *) param;
				erase = erase;
			}
			break;
			
		case	DEV_ERASE_BLOCK:
			{
				ioctl_diskerase_t	*erase = (ioctl_diskerase_t *) param;
				erase = erase;				
			}
			break;
			
		case	DEV_WRITEBACK_ON_IDLE:
			{

			}
			break;
			
		case	DEV_ERASE_CLOSE:
			{

			}
			break;
			
		case	DEV_HIDDEN_READ_PAGE_4:
			{

			}
			break;

		case	DEV_GET_MAX_SECTOR_PER_BLOCK:
			{
				unsigned short *value = (unsigned short *)param;

				if ( gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].DrvStatus == ENABLE )
				{
					if ( gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1].TotalDiskSector >
					    (U32)( gNAND_DrvInfo[0].NFTLDrvInfo->PpB << gNAND_DrvInfo[0].NFTLDrvInfo->ShiftPPages ) * 2 )
						*value = ( gNAND_DrvInfo[0].NFTLDrvInfo->PpB << gNAND_DrvInfo[0].NFTLDrvInfo->ShiftPPages );
					else
						*value = TNFTL_MAX_SUPPORT_NAND_IO_SECTOR_SIZE_PER_1PAGE;
				}
				else
					*value = TNFTL_MAX_SUPPORT_NAND_IO_SECTOR_SIZE_PER_1PAGE;
			}
			break;

		case	DEV_TELL_DATASTARTSECTOR:
			{
				TNFTL_WCacheSetDataStartSector( gNAND_DrvInfo[0].NFTLDrvInfo,
												&gNAND_DrvInfo[0].NFTLDrvInfo->ExtPartition[1],
												*(unsigned int*)param );
				break;
			}

		case	DEV_GET_WRITE_PROTECT:
			return  0;
			break;
		case	DEV_GET_INSERTED:
			return 1;
		case	DEV_GET_INITED:
			return 1;
		case DEV_GET_PLAYABLE_STATUS:
			return 1;			
		default:
			return	ENOTSUPPORT;
	}
	
	return 0;	/* SUCCESS */
}

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_ReadMultiSectorStart( U32 LBA, U16 nSecSize );
*  
*  DESCRIPTION : 
*  INPUT:
*			LBA	= 
*			nSecSize	= 
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_ReadMultiSectorStart( U32 LBA, U32 nSecSize )
{
	#ifdef NAND_INCLUDE
	LBA = 0;
	nSecSize = 0;
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_ReadMultiSectorStop( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_ReadMultiSectorStop( void )
{
	#ifdef NAND_INCLUDE
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_WriteMultiSectorStart( U32 LBA, U16 nSecSize );
*  
*  DESCRIPTION : 
*  INPUT:
*			LBA	= 
*			nSecSize	= 
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_WriteMultiSectorStart( U32 LBA, U32 nSecSize )
{
	#ifdef NAND_INCLUDE
	LBA = 0;
	nSecSize = 0;
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_WriteMultiSectorStop( void );
*  
*  DESCRIPTION : 
*  INPUT:
*			None
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_WriteMultiSectorStop( void )
{
	#ifdef NAND_INCLUDE
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/**************************************************************************
*  FUNCTION NAME : 
*      int NAND_HDClearPages( U32 nHDStPageAddr, U32 nHDEdPageAddr );
*  
*  DESCRIPTION : 
*  INPUT:
*			nHDEdPageAddr	= 
*			nHDStPageAddr	= 
*  
*  OUTPUT:	int - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
int NAND_HDClearPages( U32 nHDStPageAddr, U32 nHDEdPageAddr )
{
	#ifdef NAND_INCLUDE
	nHDStPageAddr = 0;
	nHDEdPageAddr = 0;
	return 0;
	#else
	return NOT_SUPPORT_NAND;
	#endif
}	

/******************************************************************************
*
*	U16				NAND_GetSerialNumber
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
U16 NAND_GetSerialNumber( U8* rSerialNumber, U16 nSize )
{
	#ifdef NAND_INCLUDE
	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
		return TNFTL_GetSerialNumber( gNAND_DrvInfo[0].NFTLDrvInfo, rSerialNumber, nSize );
	else
	{
		#ifdef NAND_LBA_INCLUDE
		return NAND_IO_LBA_GetSerialNumber( gLBA_DevInfo, gNAND_PageBuffer, rSerialNumber, nSize );
		#else
		return 0;
		#endif
	}
	#else
	return 0;
	#endif
}

/******************************************************************************
*
*	U16				NAND_GetUniqueID
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
U16 NAND_GetUniqueID( U8* rSerialNumber, U16 nSize )
{
	if ( gNAND_DrvInfo[0].NFTLDrvInfo->NANDType == NAND_TYPE_PURE_NAND )
	{
		#if defined(NAND_INCLUDE) && !defined(_SDRAMONLY1_)
		unsigned int uiIDSize;

		uiIDSize = ( nSize < gNAND_DrvInfo[0].NFTLDrvInfo->MediaSizeOfUniqueID ) ? nSize : gNAND_DrvInfo[0].NFTLDrvInfo->MediaSizeOfUniqueID;
		memcpy((void*)rSerialNumber, (void*)gNAND_DrvInfo[0].NFTLDrvInfo->MediaUniqueID, uiIDSize);

		return (U16)uiIDSize;
		#else
		return 0;
		#endif
	}
	else
		return 0;
}

/******************************************************************************
*
*	TNFTL_ERROR		NAND_SetUartDebug
*
*	Input	:
*	Output	:
*	Return	:
*
*	Description :
*
*******************************************************************************/
TNFTL_ERROR	NAND_SetUartDebug( unsigned int on_off )
{
	gNAND_UARTDebugFlag = (U8)on_off;

	return (TNFTL_ERROR)SUCCESS;
}	

#ifdef NU_FILE_INCLUDE
/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_Open                                                      
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function prepares the NAND Flash for usage by allocating the 
*       pages necessary for usage.                                       
*                                                                       
* INPUTS                                                                
*                                                                       
*       driveno                             The number assigned to the NAND Flash. 
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       YES                                 Successful Completion.      
*       NO                                  Couldn't allocate all of the
*                                            pages.                     
*                                                                       
*************************************************************************/
INT NAND_IO_Open(UINT16 driveno)
{
	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	NAND_Ioctl(DEV_INITIALIZE, NULL);
	NU_Release_Semaphore(&CAPP_SEM);
    	return(YES);
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_Open(UINT16 driveno);
*  
*  DESCRIPTION : 
*  INPUT:
*			driveno	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_Open(UINT16 driveno)
{
	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	NAND_HDIoctl(DEV_INITIALIZE, NULL);
	NU_Release_Semaphore(&CAPP_SEM);
    	return(YES);
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_RAW_Open                                                  
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function doesn't do anything for the NAND Flash.  It is      
*       included for devtable consistency.                              
*                                                                       
* INPUTS                                                                
*                                                                       
*       None.                                                           
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       None.                                                           
*                                                                       
*************************************************************************/
INT NAND_IO_RAW_Open(UINT16 driveno)
{
    return(NO);
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_RAW_Open(UINT16 driveno);
*  
*  DESCRIPTION : 
*  INPUT:
*			driveno	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_RAW_Open(UINT16 driveno)
{
    return(NO);
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_Close                                                     
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function deallocates all of the pages associated with the  
*       NAND Flash. The actual code here is commented out since we        
*       probably don't want to loose the data on a close.               
*                                                                       
* INPUTS                                                                
*                                                                       
*       driveno                             The number assigned to the NAND Flash.
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       YES                                 Successful Completion.      
*       NO                                  Couldn't allocate all of the
*                                            pages.                     
*                                                                       
*************************************************************************/
INT NAND_IO_Close(UINT16 driveno) 
{
    return(YES);
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_Close(UINT16 driveno) ;
*  
*  DESCRIPTION : 
*  INPUT:
*			driveno	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_Close(UINT16 driveno) 
{
    return(YES);
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_ReadWrite                                                        
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function reads or writes data from and to the NAND Flash     
*       based on the 'reading' parameter.                               
*                                                                       
* INPUTS                                                                
*                                                                       
*       driveno                             The number assigned to the  
*                                            RAM Disk (not used)        
*       block                               The block number to read or 
*                                            write                      
*       buffer                              Pointer to the data to be   
*                                            placed from a read or      
*                                            stored on a write          
*       count                               Number of bytes to be read  
*                                            or written                 
*       reading                             Indicates whether or not we 
*                                            are reading or writing     
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       YES                                 Successful Completion.      
*       NO                                  Block number is out of range.
*                                                                       
*************************************************************************/
INT NAND_IO_ReadWrite(UINT16 driveno, UINT32 block, VOID *buffer, UINT16 count, INT reading) 
{
	int result;

	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	
	if(reading)
		result = NAND_ReadSector(driveno, block, count, buffer);
	else
		result = NAND_WriteSector(driveno, block, count, buffer);

	NU_Release_Semaphore(&CAPP_SEM);

	if(!result)
		return (YES);
	else
		return (NO);
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_ReadWrite(UINT16 driveno, UINT32 block, VOID *buffer, UINT16 count, INT reading) ;
*  
*  DESCRIPTION : 
*  INPUT:
*			block	= 
*			buffer	= 
*			count	= 
*			driveno	= 
*			reading	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_ReadWrite(UINT16 driveno, UINT32 block, VOID *buffer, UINT16 count, INT reading) 
{
	int result;

	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);

	driveno	-= INTERNAL_HIDDEN_STORAGE_START_NO;
	if(reading)
		result = NAND_HDReadSector(driveno, block, count, buffer);
	else
		result = NAND_HDWriteSector(driveno, block, count, buffer);

	NU_Release_Semaphore(&CAPP_SEM);

	if(!result)
		return (YES);
	else
		return (NO);
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

/************************************************************************
* FUNCTION                                                              
*                                                                       
*       NAND_IO_Ioctl                                                     
*                                                                       
* DESCRIPTION                                                           
*                                                                       
*       This function doesn't do anything for the NAND Flash.  It is      
*       included for devtable consistency.                              
*                                                                       
* INPUTS                                                                
*                                                                       
*       None.                                                           
*                                                                       
* OUTPUTS                                                               
*                                                                       
*       None.                                                           
*                                                                       
*************************************************************************/
INT NAND_IO_Ioctl(UINT16 driveno, UINT16 command, VOID *buffer)
{
	int result;

	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	result	= NAND_Ioctl(command, buffer);
	NU_Release_Semaphore(&CAPP_SEM);

	return result;
}

#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
/**************************************************************************
*  FUNCTION NAME : 
*      INT NAND_HD_IO_Ioctl(UINT16 driveno, UINT16 command, VOID *buffer);
*  
*  DESCRIPTION : 
*  INPUT:
*			buffer	= 
*			command	= 
*			driveno	= 
*  
*  OUTPUT:	INT - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
INT NAND_HD_IO_Ioctl(UINT16 driveno, UINT16 command, VOID *buffer)
{
	int result;

	NU_Obtain_Semaphore(&CAPP_SEM, NU_SUSPEND);
	result	= NAND_HDIoctl(command, buffer);
	NU_Release_Semaphore(&CAPP_SEM);

	return result;
}
#endif	//INTERNAL_HIDDEN_STORAGE_INCLUDE

#endif	// NU_FILE_INCLUDE

//#endif	// WITHOUT_FILESYSTEM

/* end of file */
