/************************************************************************
*	TCC7xx Digital Audio Player
*	------------------------------------------------
*
*	FUNCTION	: TCC7xx DMA Management Functions
*	CPU NAME	: TCC77x, TCC82xx
*	SOURCE		: IO_DMA.c
*
*	START DATE	: 2004 DEC. 28
*	MODIFY DATE : 2005. 6. 6
*	DEVISION	: DEPT. SYSTEM BT 3 TEAM
*				: TELECHIPS, INC.
************************************************************************/

#if defined(_LINUX_) || defined(_WINCE_)
#include "IO_TCCXXX.h"
#include "TC_DRV.h"
#endif
#if 0		/* 09.03.16 */	//// nemo
#ifdef ARM_ADS_V12
#include <stdarg.h>
#else
#include "uart_util.h"
#endif
#endif /* 0 */

/*********************************************************
	External Functions
*********************************************************/
#if !defined(_LINUX_)
extern void *memcpy(void * pvDest, const void * pvSrc, unsigned long iCount);
#endif


/*********************************************************
	Pre Define Static Functions
*********************************************************/
#if defined(TCC89XX)
PGDMANCTRL	IO_DMA_GetBASEADDR(unsigned uCH);
void			IO_DMA_StartDMA(PGDMANCTRL	pHwDMA,
						void *pSRC, unsigned uSrcInc, unsigned uSrcMask,
						void *pDST, unsigned uDstInc, unsigned uDstMask, unsigned uHCount, 
						unsigned uCHCTRL, unsigned uReqSel
				);
#else
sHwDMA	*IO_DMA_GetBASEADDR(unsigned uCH);
void		IO_DMA_StartDMA(sHwDMA *pHwDMA,
					void *pSRC, unsigned uSrcInc, unsigned uSrcMask,
					void *pDST, unsigned uDstInc, unsigned uDstMask, unsigned uHCount, 
					unsigned uCHCTRL, unsigned uReqSel
				);
#endif
U32		IO_DMA_GetREQSEL(U32 uReqSelection);
void	DRVI_TimeDelay(unsigned uDelay);


sDRV_GDMA	*gDRV_GDMA_Handle[DRV_GDMA_MAX_HANDLE];
U8			gDRV_GDMA_IntChannel[DRV_GDMA_MAX_HANDLE];
ICallBack		gDRV_GDMA_IntCallBack[HwGDMA_MAX_CH];



/*********************************************************
	Function Define
*********************************************************/

void DRVI_TimeDelay(unsigned uDelay)
{
	unsigned	uTimeLimit;

	uTimeLimit	= IO_TMR_Get32bitValue() + uDelay;
	if (uTimeLimit < IO_TMR_Get32bitValue())
		while ((int)IO_TMR_Get32bitValue() < (int)uTimeLimit);
	else
		while (IO_TMR_Get32bitValue() < uTimeLimit);
}

S32	DRV_GDMA(U32 Func, U32 ArgN, ...)
{
	S32	iHandle, iCH;
	U32	*pArg;
	#ifdef ARM_RVDS_V22
	va_list pArgTmp;
	#endif
	U32	uCHCTRL, uHCOUNT;
	U32	uConfigValue, uConfigRBW, uConfigWBW, uConfigBSize, uHopUnit, uShiftUnit, uReqSelection;
	ICallBack	OldCallBack;
	U32	uTimeLimit, uSignedComp, uTimeOut;
	sDRV_GDMA	*pDRV_GDMA;
#if defined(TCC89XX)
	PGDMANCTRL	pHwDMA;
#else
	sHwDMA		*pHwDMA;
#endif

#if 0		/* 09.03.16 */		// nemo
#ifdef ARM_ADS_V12
	va_start(&pArg, ArgN);
#else
	va_start(pArgTmp, ArgN);
	pArg = (U32*)pArgTmp;
#endif
#endif /* 0 */

	switch (Func)
	{
	/**********************************
		1. Non-Argument Functions
	**********************************/
	case DRV_GDMA_FUNC_INIT:
		// Disable GDMA Channel
		for (iCH = 0; iCH < HwGDMA_MAX_CH; iCH ++)
		{
			pHwDMA	= IO_DMA_GetBASEADDR(iCH);
			pHwDMA->CHCTRL	= 0;
		}

		// Initialize Internal Variables
		for (iHandle = 0; iHandle < DRV_GDMA_MAX_HANDLE; iHandle ++)
		{
			gDRV_GDMA_IntChannel[iHandle]	= 0xFF;
			if (gDRV_GDMA_Handle[iHandle] != NULL)
			{
				gDRV_GDMA_Handle[iHandle]->CHSTS	= DRV_GDMA_STATUS_INVALID;
				gDRV_GDMA_Handle[iHandle]			= NULL;
			}
		}
		return	DRV_GDMA_ERROR_OK;

	case DRV_GDMA_FUNC_PROCESS_INTERRUPT:
		for (iHandle = 0; iHandle < DRV_GDMA_MAX_HANDLE; iHandle ++)
		{
			if ((iCH = gDRV_GDMA_IntChannel[iHandle]) != 0xFF)
			{
				pHwDMA	= IO_DMA_GetBASEADDR(iCH);

				#ifdef TCC89XX
				if (ISALLONE(pHwDMA->CHCTRL, HwCHCTRL_FLAG|HwCHCTRL_IEN_ON))
				#else
				if (ISALLONE(pHwDMA->CHCTRL, HwCHCTRL_FLAG|HwCHCTRL_IEN_EN))
				#endif
				{
					if (gDRV_GDMA_IntCallBack[iCH])
						(*gDRV_GDMA_IntCallBack[iCH])(iCH);

					pHwDMA->CHCTRL = pHwDMA->CHCTRL;
				}
			}
			else
				break;
		}
		return	DRV_GDMA_ERROR_OK;

	/*******************************************
		2. Channel Based Functions
	********************************************/
	case DRV_GDMA_FUNC_OPEN:	// Open Handle (Channel Number, sDRV_GDMA structure pointer)
		if (ArgN != 2)
			return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

		/* Get Channel */
		iCH	= pArg[0];
		if (iCH >= HwGDMA_MAX_CH)
			return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

		if (pArg[1] != 0)
		{
			for (iHandle = 0; iHandle < DRV_GDMA_MAX_HANDLE; iHandle ++)
				if (gDRV_GDMA_Handle[iHandle] == NULL)
				{
					pDRV_GDMA	= gDRV_GDMA_Handle[iHandle]	= (sDRV_GDMA *)pArg[1];
					break;
				}
			if (iHandle >= DRV_GDMA_MAX_HANDLE)
				return	DRV_GDMA_ERROR_NOTAVAILABLE_HANDLE;
		}
		else
			return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

		if (pDRV_GDMA->CHSTS == DRV_GDMA_STATUS_INVALID)
		{
			pDRV_GDMA->CHSTS		= DRV_GDMA_STATUS_IDLE;
			pDRV_GDMA->pHwDMA		= IO_DMA_GetBASEADDR(iCH);
		}
		return	iHandle;

	case DRV_GDMA_FUNC_INSTALL_HANDLER:	// Install Handler : Argument = (Channel, NewHandler, [* OldHandler])
		if ((ArgN != 2 && ArgN != 3) || (ArgN == 3 && pArg[2] == 0))
			return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

		/* Get Channel */
		iCH	= pArg[0];

		// Save Old Handler & Install New Handler
		OldCallBack	= gDRV_GDMA_IntCallBack[iCH];
		gDRV_GDMA_IntCallBack[iCH]	= (ICallBack)pArg[1];

		// Return Old Handler
		if (ArgN == 3 && pArg[2] != NULL)
			*(ICallBack *)pArg[2]	= OldCallBack;

		// Search IntHandle Table for Same Channel
		for (iHandle = 0; iHandle < DRV_GDMA_MAX_HANDLE; iHandle ++)
			if (gDRV_GDMA_IntChannel[iHandle] == iCH || gDRV_GDMA_IntChannel[iHandle] == 0xFF)
				break;
		if (iHandle >= DRV_GDMA_MAX_HANDLE)
			return	DRV_GDMA_ERROR_NOTAVAILABLE_HANDLE;

		gDRV_GDMA_IntChannel[iHandle]	= iCH;

		return	DRV_GDMA_ERROR_OK;

	case DRV_GDMA_FUNC_UNINSTALL_HANDLER:	// Install Handler : Argument = (Channel, NewHandler, [* OldHandler])
		if (ArgN != 1)
			return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

		/* Get Channel */
		iCH	= pArg[0];

		// Search IntHandle Table for Same Channel
		for (iHandle = 0; iHandle < DRV_GDMA_MAX_HANDLE; iHandle ++)
			if (gDRV_GDMA_IntChannel[iHandle] == iCH)
				break;
		if (iHandle >= DRV_GDMA_MAX_HANDLE)
			return	DRV_GDMA_ERROR_INVALID_CH;

		// Remove Channel from IntHandle Table
		memcpy(&gDRV_GDMA_IntChannel[iHandle], &gDRV_GDMA_IntChannel[iHandle+1], DRV_GDMA_MAX_HANDLE - iHandle - 1);
		gDRV_GDMA_IntChannel[DRV_GDMA_MAX_HANDLE - 1]	= 0xFF;
		gDRV_GDMA_IntCallBack[iCH]	= NULL;

		return	DRV_GDMA_ERROR_OK;

	/*******************************************
		3. Handle-Based Functions
	********************************************/
	default:
		// Check Handle
		iHandle	= pArg[0];
		if (iHandle >= DRV_GDMA_MAX_HANDLE || iHandle < 0)
			return	DRV_GDMA_ERROR_INVALID_HANDLE;

		// Get Channel
		pDRV_GDMA	= gDRV_GDMA_Handle[iHandle];
		pHwDMA		= pDRV_GDMA->pHwDMA;

		switch (Func)
		{
		case DRV_GDMA_FUNC_GETHwDMA:	// Get HwDMA Register : Argument (Handle, *sHwDMA)
			if ((ArgN != 2) || (pArg[1] == 0))
				return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

			*(U32 *)pArg[1]	= (U32)pHwDMA;
			return	DRV_GDMA_ERROR_OK;

		case DRV_GDMA_FUNC_ISACTIVE:
			#ifdef TCC89XX
			if (ISONE(pHwDMA->CHCTRL, HwCHCTRL_EN_ON))
			#else
			if (ISONE(pHwDMA->CHCTRL, HwCHCTRL_EN_EN))
			#endif
				return	DRV_GDMA_ERROR_YES;
			else
				return	DRV_GDMA_ERROR_NO;

		case DRV_GDMA_FUNC_PARSECFG:	// Configurate DMA : Argument = (Handle)
		case DRV_GDMA_FUNC_SETCFG:	// Configurate DMA : Argument = (Handle, ConfigValue, ReqSel)
			if (ArgN != 3 && ArgN != 1)
				return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

			if (ArgN == 3)
			{
				pDRV_GDMA->CHCFG	= pArg[1];
				pDRV_GDMA->REQSEL	= pArg[2];
			}
			uConfigValue	= pDRV_GDMA->CHCFG;
			uReqSelection	= pDRV_GDMA->REQSEL;

			uConfigRBW	= (uConfigValue & (Hw8-Hw6)) >> 6;
			uConfigWBW	= (uConfigValue & (Hw6-Hw4)) >> 4;

			// Check for Validity of Configuration Value
			#if defined(TCC79XX)
				if ((uConfigRBW != uConfigWBW) && ISZERO(uConfigValue, DRV_GDMA_CFG_1HopUnit_Auto))
					return	DRV_GDMA_ERROR_INVALID_ARGUMENT;
			#elif defined(TCC89XX)
				if ((uConfigRBW != uConfigWBW) && ISZERO(uConfigValue, DRV_GDMA_CFG_1HopUnit_Auto))
					return	DRV_GDMA_ERROR_INVALID_ARGUMENT;
			#else
				if (uConfigRBW != uConfigWBW)
					return	DRV_GDMA_ERROR_INVALID_ARGUMENT;
			#endif

			// Setup DMA.CHCTRL Register
			uCHCTRL	= 0
			#ifdef TCC89XX
				| ((uConfigValue & DRV_GDMA_CFG_SyncHwReq) ? HwCHCTRL_SYNC_ON : 0)
				| ((uConfigValue & DRV_GDMA_CFG_AckAtWrite) ? HwCHCTRL_HRD_WR : HwCHCTRL_HRD_RD)
				| ((uConfigValue & DRV_GDMA_CFG_LockTransfer) ? HwCHCTRL_LOCK_ON : 0)
				| ((uConfigValue & DRV_GDMA_CFG_NoArbitration) ? HwCHCTRL_BST_BURST : 0)
				| ((uConfigValue & DRV_GDMA_CFG_InterruptEnable) ? HwCHCTRL_IEN_ON : 0)
			#else
				| ((uConfigValue & DRV_GDMA_CFG_SyncHwReq) ? HwCHCTRL_SYNC_EN : 0)
				| ((uConfigValue & DRV_GDMA_CFG_AckAtWrite) ? HwCHCTRL_HRD_W : HwCHCTRL_HRD_RD)
				| ((uConfigValue & DRV_GDMA_CFG_LockTransfer) ? HwCHCTRL_LOCK_EN : 0)
				| ((uConfigValue & DRV_GDMA_CFG_NoArbitration) ? HwCHCTRL_BST_BURST : 0)
				| ((uConfigValue & DRV_GDMA_CFG_InterruptEnable) ? HwCHCTRL_IEN_EN : 0)
			#endif
				;

			// Add TYPE at CHCTRL
			BITSET(uCHCTRL, (uConfigValue & DRV_GDMA_CFG_StartBy_MASK));

			// Add BSIZE & WSIZE at CHCTRL
			if (uConfigRBW == uConfigWBW)
			{
				if (ISONE(uConfigValue, DRV_GDMA_CFG_1HopUnit_Auto))
				{
					return	DRV_GDMA_ERROR_INVALID_ARGUMENT;
				}
				else
				{
					uHopUnit	= (uConfigValue & DRV_GDMA_CFG_1HopUnit_MASK) >> DRV_GDMA_CFG_1HopUnit_SHIFT;
					if (uHopUnit < uConfigRBW)
						return	DRV_GDMA_ERROR_INVALID_ARGUMENT;
					uConfigBSize	= uHopUnit - uConfigRBW;
				}
				BITSET(uCHCTRL, HwCHCTRL_BSIZE(uConfigBSize) | HwCHCTRL_WSIZE(uConfigRBW));
			}
			else
			{
				return	DRV_GDMA_ERROR_INVALID_ARGUMENT;
			}

			// Setup H/W Request Selection
			if (uReqSelection)
			{
				uReqSelection	= IO_DMA_GetREQSEL(uReqSelection);
			}

			// Repeat Setup
			if (ISONE(uConfigValue, DRV_GDMA_CFG_RepeatEver))
			{
				BITSET(uCHCTRL, HwCHCTRL_CONT_C | HwCHCTRL_REP_EN);
			}

			uShiftUnit		= uHopUnit + ((uConfigValue & DRV_GDMA_CFG_BufNum_MASK) >> DRV_GDMA_CFG_BufNum_SHIFT);
			pDRV_GDMA->CHCFG		= uConfigValue;
			pDRV_GDMA->BufShiftFactor	= uShiftUnit;
			pDRV_GDMA->HwCHCTRL	= uCHCTRL;
			pDRV_GDMA->HwREQSEL	= uReqSelection;

			return DRV_GDMA_ERROR_OK;

		case DRV_GDMA_FUNC_SETREG:	// Setup DMA : Argument = (Handle, SrcBase, SrcInc, SrcMask, DstBase, DstInc, DstMask, DataSize)
		case DRV_GDMA_FUNC_START:		// Start DMA : Argument = (Handle, SrcBase, SrcInc, SrcMask, DstBase, DstInc, DstMask, DataSize)
			if (ArgN != 8)
				return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

			if (pDRV_GDMA->CHSTS == DRV_GDMA_STATUS_INVALID)
				return	DRV_GDMA_ERROR_NOT_READY;

			pHwDMA->CHCTRL		= 0;
			pDRV_GDMA->CHSTS	= DRV_GDMA_STATUS_ACTIVE;
			uHCOUNT	= pArg[7] >> pDRV_GDMA->BufShiftFactor;
			if (Func == DRV_GDMA_FUNC_START)
				IO_DMA_StartDMA(pHwDMA, 
					pArg[1], pArg[2], pArg[3], pArg[4], pArg[5], pArg[6], // SrcBase, SrcInc, SrcMask, DstBase, DstInc, DstMask
				#ifdef TCC89XX
					uHCOUNT, pDRV_GDMA->HwCHCTRL | HwCHCTRL_EN_ON | HwCHCTRL_FLAG, pDRV_GDMA->HwREQSEL);
				#else
					uHCOUNT, pDRV_GDMA->HwCHCTRL | HwCHCTRL_EN_EN | HwCHCTRL_FLAG, pDRV_GDMA->HwREQSEL);
				#endif
			else
				IO_DMA_StartDMA(pHwDMA, 
					pArg[1], pArg[2], pArg[3], pArg[4], pArg[5], pArg[6], // SrcBase, SrcInc, SrcMask, DstBase, DstInc, DstMask
					uHCOUNT, pDRV_GDMA->HwCHCTRL | HwCHCTRL_FLAG, pDRV_GDMA->HwREQSEL);

			if (ISONE(pDRV_GDMA->CHCFG, DRV_GDMA_CFG_InterruptEnable))
#if defined (TCC89XX)
				BITSET(HwPIC->IEN0, HwINT0_DMA);
#else
				BITSET(IO_INT_HwIEN, IO_INT_HwDMA);
#endif

			return	DRV_GDMA_ERROR_OK;

		case DRV_GDMA_FUNC_WAITDONE:	// Wait DMA Done : Argument = (Handle, [TimeOut Value], [TimeDelay(), TimeDelayFactor])
		case DRV_GDMA_FUNC_WAITDONE_STOP:	// Wait DMA Done with Stop : Argument = (Handle, [TimeOut Value], [TimeDelay(), TimeDelayFactor])
			if (ArgN != 1 && ArgN != 2 && ArgN != 4)
				return	DRV_GDMA_ERROR_INVALID_ARGUMENT;

			if (pDRV_GDMA->CHSTS != DRV_GDMA_STATUS_ACTIVE)
				return	DRV_GDMA_ERROR_NOT_ACTIVE;

			if (ArgN == 1)	// Wait Done without TimeOut
			{
				uSignedComp	= 0;
			}
			else
			{
				uTimeOut		= pArg[1];

				if (uTimeOut > 0x1FFF0000)		// TimeOut Value should be less than Half of TC32MCNT Maximum Range.
					uTimeOut	= 0x1FFF0000;

				uTimeLimit	= IO_TMR_Get32bitValue() + uTimeOut;
				uSignedComp	= (uTimeLimit < IO_TMR_Get32bitValue()) ? 2 : 1;
			}

			while (ISZERO(pHwDMA->CHCTRL, HwCHCTRL_FLAG))
			{
				if (	(uSignedComp == 2 && (int)IO_TMR_Get32bitValue() > (int)uTimeLimit) ||
					(uSignedComp == 1 && IO_TMR_Get32bitValue() > uTimeLimit) )
				{
					return	DRV_GDMA_ERROR_TIMEOUT;
				}
				if ((ArgN == 4) && (pArg[2] != 0) && (pArg[3] != 0))
					(*(ICallBack)pArg[2])(pArg[3]);
			}

			if (Func == DRV_GDMA_FUNC_WAITDONE_STOP)
				#if defined (TCC89XX)
				BITSCLR(pHwDMA->CHCTRL, HwCHCTRL_FLAG, HwCHCTRL_EN_ON);
				#else
				BITSCLR(pHwDMA->CHCTRL, HwCHCTRL_FLAG, HwCHCTRL_EN_EN);
				#endif
			else
				BITSET(pHwDMA->CHCTRL, HwCHCTRL_FLAG);

			return	DRV_GDMA_ERROR_OK;

		case DRV_GDMA_FUNC_PAUSE:				// Pause DMA Operation : Argument = (Handle)
			if (pDRV_GDMA->CHSTS != DRV_GDMA_STATUS_ACTIVE)
				return	DRV_GDMA_ERROR_NOT_ACTIVE;

			if (pDRV_GDMA->HwREQSEL)
			{
				#ifdef TCC79XX
					pHwDMA->EXTREQ	= 0;
				#elif defined(TCC89XX)
					pHwDMA->EXTREQ	= 0;
				#else
					BITCLR(pHwDMA->CHCTRL, 0xFFFF0000);
				#endif
				DRVI_TimeDelay(1000);
			}
			#if defined (TCC89XX)
			BITSCLR(pHwDMA->CHCTRL, HwCHCTRL_FLAG, HwCHCTRL_EN_ON | HwCHCTRL_IEN_ON);
			#else
			BITSCLR(pHwDMA->CHCTRL, HwCHCTRL_FLAG, HwCHCTRL_EN_EN | HwCHCTRL_IEN_EN);
			#endif
			pDRV_GDMA->CHSTS	= DRV_GDMA_STATUS_PAUSE;
			return	DRV_GDMA_ERROR_OK;

		case DRV_GDMA_FUNC_CONTINUE:			// Continue DMA Operation : Argument = (Handle)
			if (pDRV_GDMA->CHSTS == DRV_GDMA_STATUS_IDLE)
				return	DRV_GDMA_ERROR_NOT_READY;

			pDRV_GDMA->CHSTS	= DRV_GDMA_STATUS_ACTIVE;

			if (ISONE(pDRV_GDMA->CHCFG, DRV_GDMA_CFG_InterruptEnable))
			{
#if defined(TCC89XX)
				BITSET(pHwDMA->CHCTRL, HwCHCTRL_IEN_ON | HwCHCTRL_EN_ON | HwCHCTRL_FLAG);
				BITSET(HwPIC->IEN0, HwINT0_DMA);
#else
				BITSET(pHwDMA->CHCTRL, HwCHCTRL_IEN_EN | HwCHCTRL_EN_EN | HwCHCTRL_FLAG);
				BITSET(IO_INT_HwIEN, IO_INT_HwDMA);
#endif
			}
			else
#if defined(TCC89XX)
				BITSET(pHwDMA->CHCTRL, HwCHCTRL_EN_ON | HwCHCTRL_FLAG);
#else
				BITSET(pHwDMA->CHCTRL, HwCHCTRL_EN_EN | HwCHCTRL_FLAG);
#endif

			DRVI_TimeDelay(1000);

			if (pDRV_GDMA->HwREQSEL)
			{
				#ifdef TCC79XX
					pHwDMA->EXTREQ	= pDRV_GDMA->HwREQSEL;
				#elif defined(TCC89XX)
					pHwDMA->EXTREQ	= pDRV_GDMA->HwREQSEL;
				#else
					BITSET(pHwDMA->CHCTRL, pDRV_GDMA->HwREQSEL);
				#endif
			}

			return	DRV_GDMA_ERROR_OK;

		case DRV_GDMA_FUNC_STOP:				// Stop DMA Operation -> This channel goes to IDLE state : Argument = (Handle)
			if (pDRV_GDMA->CHSTS == DRV_GDMA_STATUS_IDLE)
				return DRV_GDMA_ERROR_OK;

			if (pDRV_GDMA->HwREQSEL)
			{
				#ifdef TCC79XX
					pHwDMA->EXTREQ	= 0;
				#elif defined(TCC89XX)
					pHwDMA->EXTREQ	= 0;
				#else
					BITCLR(pHwDMA->CHCTRL, 0xFFFF0000);
				#endif
				DRVI_TimeDelay(1000);
			}

#if defined(TCC89XX)
			BITSCLR(pHwDMA->CHCTRL, HwCHCTRL_FLAG, HwCHCTRL_EN_ON);
#else
			BITSCLR(pHwDMA->CHCTRL, HwCHCTRL_FLAG, HwCHCTRL_EN_EN);
#endif
			pHwDMA->HCOUNT		= 0;
			pDRV_GDMA->CHSTS	= DRV_GDMA_STATUS_IDLE;

			return	DRV_GDMA_ERROR_OK;

		case DRV_GDMA_FUNC_CLOSE:				// Close DMA Channel from User : Argument = (Handle)
			if (pDRV_GDMA->CHSTS == DRV_GDMA_STATUS_INVALID)
				return DRV_GDMA_ERROR_OK;

			if (pDRV_GDMA->HwREQSEL)
			{
				#ifdef TCC79XX
					pHwDMA->EXTREQ	= 0;
				#elif defined(TCC89XX)
					pHwDMA->EXTREQ	= 0;
				#else
					BITCLR(pHwDMA->CHCTRL, 0xFFFF0000);
				#endif
				DRVI_TimeDelay(1000);
			}

			pHwDMA->CHCTRL		= HwCHCTRL_FLAG;
			pHwDMA->HCOUNT		= 0;
			pDRV_GDMA->CHSTS	= DRV_GDMA_STATUS_INVALID;
			gDRV_GDMA_Handle[iHandle] = NULL;
			return	DRV_GDMA_ERROR_OK;

		default:
			return	DRV_GDMA_ERROR_INVALID_FUNC;
		}
	}

//	return	DRV_GDMA_ERROR_INTERNAL;
}

/**************************************************************************
*  FUNCTION NAME : 
*      sHwDMA *IO_DMA_SetCTRL(unsigned uCH, unsigned	uCHCTRL);
*  
*  DESCRIPTION : 
*  INPUT:
*			uCH	= 
*			uCHCTRL	= 
*  
*  OUTPUT:	sHwDMA - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
#if defined (TCC89XX)
PGDMANCTRL IO_DMA_SetCTRL(unsigned uCH, unsigned uCHCTRL)
{
	PGDMANCTRL pHwDMA	= IO_DMA_GetBASEADDR(uCH);

	pHwDMA->CHCTRL	= uCHCTRL;
	return	pHwDMA;
}
#else
sHwDMA *IO_DMA_SetCTRL(unsigned uCH, unsigned uCHCTRL)
{
	sHwDMA *pHwDMA	= IO_DMA_GetBASEADDR(uCH);

	pHwDMA->CHCTRL	= uCHCTRL;
	return	pHwDMA;
}
#endif

/**************************************************************************
*  FUNCTION NAME : 
*      sHwDMA *IO_DMA_SetDMA(
*      	unsigned uCH,
*      	void *pSRC, unsigned uSPARAM,
*      	void *pDST, unsigned uDPARAM,
*      	unsigned	uCHCTRL,
*      	unsigned uSize;
*  
*  DESCRIPTION : 
*  INPUT:
*			pDST	= 
*			pSRC	= 
*			uCH	= 
*			uCHCTRL	= 
*			uDPARAM	= 
*			uSize	= 
*			uSPARAM	= 
*  
*  OUTPUT:	sHwDMA - Return Type
*  			= 
*  REMARK  :	
**************************************************************************/
#if defined(TCC89XX)
PGDMANCTRL	IO_DMA_SetDMA(
	unsigned uCH,
	void *pSRC, unsigned uSPARAM,
	void *pDST, unsigned uDPARAM,
	unsigned	uCHCTRL,
	unsigned 	uREQSRC,
	unsigned uSize
)
#else
sHwDMA *IO_DMA_SetDMA(
	unsigned uCH,
	void *pSRC, unsigned uSPARAM,
	void *pDST, unsigned uDPARAM,
	unsigned	uCHCTRL,
	unsigned 	uREQSRC,
	unsigned uSize
)
#endif
{
	unsigned	uTmp;
#if defined(TCC89XX)
	PGDMANCTRL	pHwDMA	= IO_DMA_GetBASEADDR(uCH);
#else
	sHwDMA *pHwDMA	= IO_DMA_GetBASEADDR(uCH);
#endif

	if (uSize)
	{
		// Set Source Address & Source Parameter (mask + increment)
		pHwDMA->ST_SADR	= pSRC;
		pHwDMA->SPARAM		= uSPARAM;

		// Set Dest Address & Dest Parameter (mask + increment)
		pHwDMA->ST_DADR	= pDST;
		pHwDMA->DPARAM		= uDPARAM;

		// Calculate byte size per 1 Hop transfer
		uTmp	= (uCHCTRL & (Hw5+Hw4)) >> 4;			// calc log2(word size)
		uTmp	= uTmp + ( (uCHCTRL & (Hw7+Hw6)) >> 6);	// calc log2(word * burst size)

		// Set Hcount
		if (uTmp)
			pHwDMA->HCOUNT	= (uSize + (1 << uTmp) - 1) >> uTmp;
		else
			pHwDMA->HCOUNT	= uSize;
	}

	// Set & Enable DMA
	pHwDMA->EXTREQ		= uREQSRC;  // only TCC83XX
	pHwDMA->CHCTRL		= uCHCTRL;
	return	pHwDMA;
}

void IO_DMA_StartDMA(
#if defined(TCC89XX)
	PGDMANCTRL	pHwDMA,
#else
	sHwDMA *pHwDMA,
#endif
	void *pSRC, unsigned uSrcInc, unsigned uSrcMask,
	void *pDST, unsigned uDstInc, unsigned uDstMask, unsigned uHCount, 
	unsigned uCHCTRL, unsigned uReqSel
)
{
	// Set Source Address & Source Parameter (mask + increment)
	pHwDMA->ST_SADR	= pSRC;
	pHwDMA->SPARAM	= (uSrcInc | (uSrcMask << 4));

	// Set Dest Address & Dest Parameter (mask + increment)
	pHwDMA->ST_DADR	= pDST;
	pHwDMA->DPARAM	= (uDstInc | (uDstMask << 4));

	if (uHCount)
	{
		pHwDMA->HCOUNT	= uHCount;
	}

	// Set DMA
	#ifdef TCC79XX
		pHwDMA->EXTREQ	= uReqSel;
		pHwDMA->CHCTRL	= uCHCTRL;
	#elif defined(TCC89XX)
		pHwDMA->EXTREQ	= uReqSel;
		pHwDMA->CHCTRL	= uCHCTRL;
	#else
		pHwDMA->CHCTRL	= uCHCTRL | uReqSel;
	#endif
}

#if defined(TCC89XX)
PGDMANCTRL IO_DMA_GetBASEADDR(unsigned uCH)
{
	switch (uCH) {
		case 0:
			return &HwGDMA0CH0_BASE;
			break;
		case 1:
			return &HwGDMA0CH1_BASE;
			break;
		case 2:
			return &HwGDMA0CH2_BASE;
			break;
		case 3:
			return &HwGDMA1CH0_BASE;
			break;
		case 4:
			return &HwGDMA1CH1_BASE;
			break;
		case 5:
			return &HwGDMA1CH2_BASE;
			break;
		case 6:
			return &HwGDMA2CH0_BASE;
			break;
		case 7:
			return &HwGDMA2CH1_BASE;
			break;
		case 8:
			return &HwGDMA2CH2_BASE;
			break;
		case 9:
			return &HwGDMA3CH0_BASE;
			break;
		case 10:
			return &HwGDMA3CH1_BASE;
			break;
		case 11:
			return &HwGDMA3CH2_BASE;
			break;
	}
	return (NULL);
}
#else
sHwDMA	*IO_DMA_GetBASEADDR(unsigned uCH)
{
	return &HwGDMA_CH_BASE(uCH);
}
#endif

U32	IO_DMA_GetREQSEL(U32 uReqSelection)
{
	U32	uReqSel;
	#ifdef TCC79XX
		uReqSel	= 0
			| ((uReqSelection & DRV_GDMA_HwREQ_ECC) ? HwEXTREQ_ECC : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_NFC) ? HwEXTREQ_NFC : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_DAI_TX) ? HwEXTREQ_I2S_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_DAI_RX) ? HwEXTREQ_I2S_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_CDIF_RX) ? HwEXTREQ_CD_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART0_TX) ? HwEXTREQ_UT0_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART0_RX) ? HwEXTREQ_UT0_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART1_TX) ? HwEXTREQ_UT1_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART1_RX) ? HwEXTREQ_UT1_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART2_TX) ? HwEXTREQ_UT2_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART2_RX) ? HwEXTREQ_UT2_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART3_TX) ? HwEXTREQ_UT3_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART3_RX) ? HwEXTREQ_UT3_RX : 0)
			;
	#elif defined(TCC89XX)
		uReqSel	= 0
//			| ((uReqSelection & DRV_GDMA_HwREQ_ECC) ? HwEXTREQ_ECC : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_NFC) ? HwEXTREQ_NFC : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_DAI_TX) ? HwEXTREQ_I2S_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_DAI_RX) ? HwEXTREQ_I2S_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_CDIF_RX) ? HwEXTREQ_CD_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART0_TX) ? HwEXTREQ_UT0_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART0_RX) ? HwEXTREQ_UT0_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART1_TX) ? HwEXTREQ_UT1_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART1_RX) ? HwEXTREQ_UT1_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART2_TX) ? HwEXTREQ_UT2_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART2_RX) ? HwEXTREQ_UT2_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART3_TX) ? HwEXTREQ_UT3_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART3_RX) ? HwEXTREQ_UT3_RX : 0)
			;
	#else
		uReqSel	= 0
			| ((uReqSelection & DRV_GDMA_HwREQ_ECC) ? HwCHCTRL_DMASEL_NFC : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_NFC) ? HwCHCTRL_DMASEL_NFC : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_DAI_TX) ? HwCHCTRL_DMASEL_DAIT : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_DAI_RX) ? HwCHCTRL_DMASEL_DAIR : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_CDIF_RX) ? HwCHCTRL_DMASEL_CDIF : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART0_TX) ? HwCHCTRL_DMASEL_UART0_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART0_RX) ? HwCHCTRL_DMASEL_UART0_RX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART1_TX) ? HwCHCTRL_DMASEL_UART1_TX : 0)
			| ((uReqSelection & DRV_GDMA_HwREQ_UART1_RX) ? HwCHCTRL_DMASEL_UART1_RX : 0)
			;
	#endif

	return	uReqSel;
}


