/****************************************************************************
*   FileName    : i2c.cpp
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/
#include <bsp.h>
#include "tcc_ckc.h"
#include "tcc_gpio.h"
#include "i2c.h"
#include "tca_i2c.h"

CPddI2C::CPddI2C(DWORD Virtual_DevBaseAddress, DWORD DevIndex, DWORD DevSpeed)
{
	mHwBaseVirtualAddress = Virtual_DevBaseAddress;
	//kerneliocontrol
	DWORD I2CClock=0;
	//bus enable
	tcc_ckc_setiobus(RB_I2CCONTROLLER,ENABLE);
	
	//clock get info
	I2CClock = tcc_ckc_getperi(PERI_I2C);
	
	
	//port init
	dwGpioVirtualBaseaddress = tcc_allocbaseaddress((unsigned int)&HwGPIO_BASE);
	pGPIO = (PGPIO)dwGpioVirtualBaseaddress;
	switch(DevIndex)
	{
	case 0:
		//SCL0-GPIOA0, SDA0-GPIOA1
		BITCSET(pGPIO->GPAFN0, (Hw5-Hw0), Hw0); //GPIOA[0] function set 1
		BITCSET(pGPIO->GPAFN0, (Hw8-Hw4), Hw4); //GPIOA[1] function set 1
		break;
	case 1:
		//SCL1-GPIOA8, SDA1-GPIOA9
		BITCSET(pGPIO->GPAFN1, (Hw5-Hw0), Hw0); //GPIOA[8] function set 1
		BITCSET(pGPIO->GPAFN1, (Hw8-Hw4), Hw4); //GPIOA[9] function set 1
		break;
	default:
		break;

	}

	// kerneliocontrol, driver, function call
	tca_i2c_hwinit(mHwBaseVirtualAddress, DevIndex, I2CClock, DevSpeed);

}


CPddI2C::~CPddI2C()
{
	//bus disable
	//
	//tca_i2c_hwdeinit();

}


BOOL CPddI2C::TCCI2C_Read(char *pBuffer, unsigned int isize)
{
	//tca_i2c_read();
	return TRUE;
}


BOOL CPddI2C::TCCI2C_Write(char *pBuffer, unsigned int isize)
{
	//tca_i2c_write();
	return TRUE;
}