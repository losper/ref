/****************************************************************************
*   FileName    : tca_i2c.h
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/

#ifndef __TCA_I2C_H__
#define __TCA_I2C_H__
//
#ifdef __cplusplus 
extern "C" {
#endif
//
#define DEVICE_NOT_FOUND   -1
#define COMMAND_NOT_FOUND  -2
//
int tca_i2c_hwinit(unsigned int devbaseaddresss, unsigned int devindex, unsigned int i2cclock, unsigned int devspeedvalue);
int tca_i2c_hwdeinit(unsigned int devbaseaddresss, unsigned int devindex);
int tca_i2c_write(unsigned int devbaseaddresss, unsigned int destaddress, char size, char *pdata, char mode);
int tca_i2c_read(unsigned int devbaseaddresss, unsigned int destaddress, char size, char *pdata, char mode);

#ifdef __cplusplus 
}
#endif

#endif  /* __TCA_I2C_H__ */