/****************************************************************************
*   FileName    : tcc_i2c.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/
#include <bsp.h>
#include "tca_i2c.h"

/************************************************************************************************
* Global Handle
************************************************************************************************/

/************************************************************************************************
* Global Variable define
************************************************************************************************/


/************************************************************************************************
* Global Defines
************************************************************************************************/
#define DEVICE_NOT_FOUND   -1
#define COMMAND_NOT_FOUND  -2

/************************************************************************************************
* FUNCTION		: int tca_i2c_hwinit(unsigned int devbaseaddresss, unsigned int devindex, unsigned int i2cblockclock, unsigned int devspeedvalue){
*
* DESCRIPTION	: 
*
************************************************************************************************/
int tca_i2c_hwinit(unsigned int devbaseaddresss, unsigned int devindex, unsigned int i2cclock, unsigned int devspeed)
{
	unsigned int devspeedvalue=0;
	PI2CMASTER pI2CMASTER = (PI2CMASTER)(devbaseaddresss);

	//peri init
	devspeedvalue = i2cclock / (devspeed*5) -1; //(PeriClock/(WantSpeed*5))-1
	pI2CMASTER->PRES = devspeedvalue; 
	pI2CMASTER->CTRL = Hw7|Hw6|HwZERO; //Start Enable, Stop Enable, 8Bit Mode
	BITSET( pI2CMASTER->CMD, Hw0); //clear a pending interrupt

	return -1;
}

/************************************************************************************************
* FUNCTION		: unsigned int tca_i2c_hwdeinit(unsigned int devbaseaddresss, unsigned int devindex )
*
* DESCRIPTION	: 
*
************************************************************************************************/
int tca_i2c_hwdeinit(unsigned int devbaseaddresss, unsigned int devindex)
{

	return TRUE;
}

/************************************************************************************************
* FUNCTION		: unsigned int tca_i2c_hwdeinit(unsigned int devbaseaddresss, unsigned int devindex )
*
* DESCRIPTION	: 
*
************************************************************************************************/
int tca_i2c_write(unsigned int devbaseaddresss, unsigned int destaddress, char size, char *pdata, char mode)
{
	int i=0;
	PI2CMASTER pI2CMASTER = (PI2CMASTER)(devbaseaddresss);

	if(!size)
		return FALSE;

	pI2CMASTER->TXR	= destaddress | 0; //write 0, read 1
	pI2CMASTER->CMD	= Hw7 | Hw4; //Send to Start
	//need to check IRQ status
	//tea_waitforirqstatus(,1000); //until wait timeout

	BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt
	
	for( i=0; i< size; i++) {
		pI2CMASTER->TXR = pdata[i];
		pI2CMASTER->CMD = Hw4; //Write 
		
		//need to check IRQ status
		//tea_waitforirqstatus(,1000); //until wait timeout
	
		BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt
	}
	if(mode) // none stop Mode
	{	
		pI2CMASTER->CMD = Hw6; //Send Stop
		//tea_waitforirqstatus(,1000); //until wait timeout
	}	
	BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt
	
	return TRUE;
}

/************************************************************************************************
* FUNCTION		: unsigned int tca_i2c_hwdeinit(unsigned int devbaseaddresss, unsigned int devindex )
*
* DESCRIPTION	: 
*
************************************************************************************************/
int tca_i2c_read(unsigned int devbaseaddresss, unsigned int destaddress, char size, char *pdata, char mode)
{
	int i=0;
	PI2CMASTER pI2CMASTER = (PI2CMASTER)(devbaseaddresss);

	if(!size)
		return FALSE;

	pI2CMASTER->TXR	= destaddress | 1; //write 0, read 1
	pI2CMASTER->CMD	= Hw7 | Hw4; //start enable, write
	//tea_waitforirqstatus(,1000); //until wait timeout

	BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt
	for( i=0; i< size; i++) {
		if(mode)
		{
			if(i==size-1) 
				pI2CMASTER->CMD = Hw5 |Hw3;	 //Read Enable, Ack ckech enable
			else 			
				pI2CMASTER->CMD = Hw5 ; //Read Enable
		}
		else
			pI2CMASTER->CMD = Hw5 |Hw3; //Read, Ack Enable

		//tea_waitforirqstatus(,1000); //until wait timeout

		BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt
		pdata[i] =(BYTE)pI2CMASTER->RXR;
	}
	if(mode)
	{
		pI2CMASTER->CMD = Hw6; //stop send
		//tea_waitforirqstatus(,1000); //until wait timeout
	}
	BITSET( pI2CMASTER->CMD, Hw0); //Clear a pending interrupt

	return TRUE;
}