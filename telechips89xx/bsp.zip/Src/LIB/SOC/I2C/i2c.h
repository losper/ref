/****************************************************************************
*   FileName    : i2c.h
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/

#ifndef __I2C_H__
#define __I2C_H__
#include <bsp.h>

class CPddI2C {
public:
	CPddI2C(DWORD Virtual_DevBaseAddress, DWORD DevIndex, DWORD DevSpeed);
	~CPddI2C();

	BOOL TCCI2C_Init(void);
	BOOL TCCI2C_DeInit(void);
	BOOL TCCI2C_Open(void);
	BOOL TCCI2C_Close(void);
	BOOL TCCI2C_Read(char *pBuffer, unsigned int isize);
	BOOL TCCI2C_Write(char *pBuffer, unsigned int isize);

public:
	
	BOOL  bInit;
	DWORD dwOpenCount;
	DWORD mHwBaseVirtualAddress;
	DWORD dwGpioVirtualBaseaddress;
	PGPIO pGPIO;

};
#endif  /* __I2C_H__ */