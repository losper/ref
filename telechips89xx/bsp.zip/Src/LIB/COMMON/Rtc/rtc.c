/****************************************************************************
*   FileName    : rtc.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/
#include <bsp.h>
#include "tcc_rtc.h"
#include "tcc_alarm.h"

#define FROM_BCD(n) 	((((n) >> 4) * 10) + ((n) & 0xf))
#define TO_BCD(n)		((((n) / 10) << 4) | ((n) % 10))


//define to use wince-notification with RTC
#define USING_RTC_NOTIFICATION_MODE

BOOL RTCBlockInit(){
	PRTC pRTC =  (PRTC)(OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE));//(PRTC)(((unsigned int)&HwRTC_BASE)&0xBFFFFFFF);
	PIOBUSCFG pIOBUSCFG=  (PIOBUSCFG)(OALPAtoVA((unsigned int)&HwIOBUSCFG_BASE,FALSE));//;(PIOBUSCFG)(((unsigned int)&HwIOBUSCFG_BASE)&0xBFFFFFFF);

	// SW Reset
	pIOBUSCFG->HRSTEN0 &= ~Hw26;
	pIOBUSCFG->HRSTEN0 |= Hw26;
	
	// BUS Enable
	pIOBUSCFG->HCLKEN0 |= Hw26;

	pRTC->RTCCON	= Hw1; // Write Enable
	pRTC->INTCON	= Hw0; // Interrupt Write Enable
	pRTC->RTCCON	|= Hw0; // Start Disable
	pRTC->RTCCON	&= ~Hw15; // Protection Disable
	pRTC->INTCON    &= ~(Hw13 | Hw12 | Hw10 | Hw9 | Hw8); // Clock 32.768Mhz
	pRTC->INTCON	|= Hw12; // 0 1 Driver 2 32kHz (@3.3V) 
	pRTC->INTCON	|= Hw15; // Protection Enable


	pRTC->RTCCON	&= ~Hw0; // Start Enable
	pRTC->RTCIM     &= ~(Hw3 | Hw0); // Interrupt Mode
	pRTC->RTCIM     |= Hw2;

	pRTC->RTCALM 	&= ~(Hw7 - Hw0); // Alarm Disable
	pRTC->INTCON	&= ~Hw0; // Interrupt Write Disable
	pRTC->RTCCON	&= ~Hw1; // Write Disable
}


/****************************************************************************
*
*  Function:  OALIoCtlHalInitRTC
*
*  This function is called by WinCE OS to initialize the time after boot.
*  Input buffer contains SYSTEMTIME structure with default time value.
*  If hardware has persistent real time clock it will ignore this value
*  (or all call).
****************************************************************************/
BOOL OALIoCtlHalInitRTC(
    UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
	UINT32 irq;
	BOOL lret = TRUE;
	SYSTEMTIME *pTime = (SYSTEMTIME*)pInpBuffer;
	SYSTEMTIME st;	
	//	 PRTC pRTC = (PRTC)(((unsigned int)&HwRTC_BASE)&0xBFFFFFFF);
	 PRTC pRTC = (PRTC)(OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE));

	
 	// Validate inputs
	if (pInpBuffer == NULL || inpSize < sizeof(SYSTEMTIME)) {
		NKSetLastError(ERROR_INVALID_PARAMETER);
		lret = FALSE;
		goto cleanUp;
	}

#ifdef	USING_RTC_NOTIFICATION_MODE
	OALIntrStaticTranslate(SYSINTR_RTC_ALARM, IRQ_RTC);
	irq = IRQ_RTC;
	OALIntrEnableIrqs(1, &irq);
#endif	
	if(tcc_rtc_checkvalidtime((unsigned int)pRTC))
	{
		
		OALMSG(0, (L"tcc_rtc_checkvalidtime return 1\n"));
		
		RTCBlockInit();


		//Telechips Company foundation day
		st.wYear = 1999;
		st.wMonth = 10;
		st.wDay = 29;
		st.wDayOfWeek = 0; // SunDay
		st.wHour = 2;
		st.wMinute = 30;
		st.wSecond = 0;
		lret = OEMSetRealTime(&st);
		if(lret == FALSE){
			OEMSetRealTime(&st);
		}
	}
	else{
		OEMGetRealTime(&st);
		OALMSG(0,  (L"st %x, %x, %x %x %x \n",st.wYear, st.wMonth, st.wHour,st.wMinute,st.wSecond));
		OALMSG(0, (L"tcc_rtc_checkvalidtime return 0\n"));
	}
	
cleanUp:
	return lret;

}
/****************************************************************************
*  Function:  OEMGetRealTime
*  Reads the current RTC value and returns a system time.
****************************************************************************/
	
BOOL OEMGetRealTime(SYSTEMTIME *pTime)
{
	rtctime lpTime;

	BOOL lret = TRUE;
	PRTC pRTC = (PRTC)(OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE));;//(PRTC)(((unsigned int)&HwRTC_BASE)&0xBFFFFFFF);

	if (pTime == NULL) 
	{
		lret = FALSE;
		goto cleanUp;
	}
	
	tcc_rtc_gettime((unsigned int)pRTC,&lpTime);

	//OALMSG(1,  (L"OEMGetRealTime %d, %d, %d \r\n",lpTime.wHour,lpTime.wMinute,lpTime.wSecond));

	pTime->wSecond		=	lpTime.wSecond;
	pTime->wMinute		=	lpTime.wMinute;
	pTime->wHour		=	lpTime.wHour;
	pTime->wDayOfWeek	=	lpTime.wDayOfWeek;
	pTime->wDay 		=	lpTime.wDay;
	pTime->wMonth		=	lpTime.wMonth;
	pTime->wYear		=	lpTime.wYear;
	pTime->wMilliseconds = 0;

	cleanUp:
		return lret;
}


/****************************************************************************
*  Function:  OEMSetRealTime
*  Updates the RTC with the specified system time.
****************************************************************************/
BOOL OEMSetRealTime(LPSYSTEMTIME pTime)
{
//	SYSTEMTIME lpTime;
	BOOL lret = TRUE;
	rtctime lpTime;
	
	PRTC pRTC = (PRTC)(OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE));//(PRTC)(((unsigned int)&HwRTC_BASE)&0xBFFFFFFF);
	
	if (pTime == NULL)
	{
		lret = FALSE;
		goto cleanUp;
	}
	
	// The RTC will only support a BCD year value of 0 - 9999.	
	if ( (pTime->wYear) > 3000) {
		lret = FALSE;
		goto cleanUp;
	}

	//OALMSG(1,  (L"OEMSetRealTime %x, %x, %x \r\n",lpTime.wHour,lpTime.wMinute,lpTime.wSecond));
	lpTime.wSecond		= pTime->wSecond;
	lpTime.wMinute		=pTime->wMinute;
	lpTime.wHour		=pTime->wHour;
	lpTime.wDayOfWeek	=pTime->wDayOfWeek;
	lpTime.wDay 		=pTime->wDay;
	lpTime.wMonth		=pTime->wMonth;
	lpTime.wYear		=pTime->wYear;

	tcc_rtc_settime((unsigned int)pRTC,&lpTime);

cleanUp:
	return lret;
}


/****************************************************************************
*  Function:  OEMSetAlarmTime
*  Set the RTC alarm time.
****************************************************************************/
BOOL OEMSetAlarmTime(SYSTEMTIME *pTime)
{
//	SYSTEMTIME lpTime;
	UINT32 irq;
	BOOL lret = TRUE;
	rtctime lpTime;
	
	PRTC pRTC = (PRTC)(OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE));;//(PRTC)(((unsigned int)&HwRTC_BASE)&0xBFFFFFFF);
	
	if (!pTime)
	{
		lret = FALSE;
		goto cleanUp;
	}
	
	//return FALSE;


	lpTime.wSecond		= pTime->wSecond;
	lpTime.wMinute		=pTime->wMinute;
	lpTime.wHour		=pTime->wHour;
	lpTime.wDayOfWeek	=pTime->wDayOfWeek;
	lpTime.wDay 		=pTime->wDay;
	lpTime.wMonth		=pTime->wMonth;
	lpTime.wYear		=pTime->wYear;


	

#ifdef	USING_RTC_NOTIFICATION_MODE
	//OALMSG(1,  (L"OEMSetAlarmTime %d, %d, %d \r\n",lpTime.wHour,lpTime.wMinute,lpTime.wSecond));
	tcc_alarm_settime((unsigned int)pRTC, &lpTime);

	// Enable/clear RTC interrupt
	irq = IRQ_RTC;
	OALIntrDoneIrqs(1, &irq);
#endif

cleanUp:
	return TRUE;
}

