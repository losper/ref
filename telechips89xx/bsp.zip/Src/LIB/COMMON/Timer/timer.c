/****************************************************************************
*   FileName    : timer.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#include <bsp.h>
#include "TCC_OEMIDLE.H"

#ifdef ENABLE_WATCH_DOG
extern void OALInitWatchDogTimer(void);
#endif

PTIMER pTIMER;

//------------------------------------------------------------------------------
//
//  Function:     OEMIdle
//
//  This function is called by the kernel when there are no threads ready to
//  run. The CPU should be put into a reduced power mode if possible and halted.
//  It is important to be able to resume execution quickly upon receiving an
//  interrupt.
//
//  Interrupts are disabled when OEMIdle is called and when it returns.
//
//  This implementation doesn't change system tick. It is intend to be used
//  with variable tick implementation. However it should work with fixed
//  variable tick implementation also (with lower efficiency because maximal
//  idle time is 1 ms).
//
extern void arm_waitforinterrupt(void);

#define ENABLE_TCC_IDLE

VOID OEMIdle(DWORD idleParam)
{
	//arm_waitforinterrupt();
	#ifdef ENABLE_TCC_IDLE
	TCC_OEMIDLE_ON();
	#endif
}
//------------------------------------------------------------------------------
//
//  Function: OALTimerInit
//
//  This function is typically called from the OEMInit to initialize
//  Windows CE system timer. The tickMSec parameter determine timer
//  period in milliseconds. On most platform timer period will be
//  1 ms, but it can be usefull to use higher value for some
//  specific (low-power) devices.
//
//
BOOL OALTimerInit(UINT32 msecPerSysTick, UINT32 countsPerMSec, UINT32 countsMargin)
{
	BOOL rc = FALSE;
	UINT32 countsPerSysTick;
	UINT32 Intrnum;
	//UINT32 SysIntr;
	
	#ifdef ENABLE_TCC_IDLE
	PCKC pCKC = (PCKC)(OALPAtoVA((unsigned int)&HwCLK_BASE,FALSE));
	TCC_OEMIDLE_CLKBASE((unsigned int)pCKC);
	#endif
	
	pTIMER= (PTIMER)(OALPAtoVA((unsigned int)&HwTMR_BASE,FALSE));
	OALMSG(TC_LOG_LEVEL(TC_DEBUG), 
		(L"[KERNEL      ]+OALTimerInit( %d, %d, %d (%08x))\r\n",
		msecPerSysTick, countsPerMSec, countsMargin, pTIMER	));

	

	// Initialize High Resolution Timer function pointers
	//pQueryPerformanceFrequency  = OALTimerQueryPerformanceFrequency;
	//pQueryPerformanceCounter	= OALTimerQueryPerformanceCounter;

	countsPerSysTick = countsPerMSec * msecPerSysTick;

	// Validate Input parameters
	if ((msecPerSysTick < 1)
		||(msecPerSysTick > 1000)
		||(countsPerSysTick < 1)
		||(countsPerSysTick > 0xFFFF) )
	{
		OALMSG(TC_LOG_LEVEL(TC_ERROR), (L"[KERNEL      ] OALTimerInit: System tick period out of range..."));
		goto cleanUp;
	}

	// Initialize Timer State Global variable (OAL_TIMER_STATE)
	g_oalTimer.msecPerSysTick   = msecPerSysTick;
	g_oalTimer.countsPerMSec    = countsPerMSec;
	g_oalTimer.countsMargin		= countsMargin;
	g_oalTimer.countsPerSysTick = countsPerSysTick;
	g_oalTimer.curCounts		= 0;
	g_oalTimer.maxPeriodMSec	= 0xFFFF/g_oalTimer.countsPerMSec;

	g_oalTimer.actualMSecPerSysTick   = g_oalTimer.msecPerSysTick;
	g_oalTimer.actualCountsPerSysTick = g_oalTimer.countsPerSysTick;

	// Set Kernel Exported Globals to Initial values
	idleconv	 = countsPerMSec;
	curridlehigh = 0;
	curridlelow	 = 0;

	//---------------------
	// Initialize System Timer
	// setting T32 Interrupt
	BITCLR(pTIMER->TC32EN,	Hw24); 
	pTIMER->TC32EN	= 12*1000; 
	pTIMER->TC32LDV	= 0;
	BITSET(pTIMER->TC32IRQ,	Hw19);	
	BITSET(pTIMER->TC32EN,	Hw24);

	//System Timer Interrupt On
	Intrnum = 1; // TC1 Interrupt
	OALIntrEnableIrqs(1, &Intrnum);

	// Enable System Tick Interrupt
	//if (!OEMInterruptEnable(SysIntr, NULL, 0))
	{
	//	OALMSG(OAL_ERROR, (L"ERROR: OALTimerInit: Interrupt enable for system timer failed"));
	//	goto cleanUp;
	}

#ifdef DVS_EN
	InitializeDVS();
#endif

	//
	// Define ENABLE_WATCH_DOG to enable watchdog timer support.
	// NOTE: When watchdog is enabled, the device will reset itself if watchdog timer is not refreshed within ~4.5 second.
	//       Therefore it should not be enabled when kernel debugger is connected, as the watchdog timer will not be refreshed.
	//
#ifdef ENABLE_WATCH_DOG
	OALInitWatchDogTimer ();
#endif

	// Done
	rc = TRUE;

cleanUp:

	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]-OALTimerInit(rc = %d)\r\n", rc));

	return rc;
}

//------------------------------------------------------------------------------
//
//  Function: OALTimerIntrHandler
//
//  This function implement timer interrupt handler. It is called from common
//  ARM interrupt handler.
//
UINT32 OALTimerIntrHandler()
{
	UINT32 SysIntr = SYSINTR_NOP;
	
	#ifdef ENABLE_TCC_IDLE
	//TCC_OEMIDLE_OFF();
	#endif

	//Clear Timer32 Interrupt Value
	if(pTIMER->TC32IRQ)
		BITSET(pTIMER->TC32IRQ, Hw31);

	// Update high resolution counter
	g_oalTimer.curCounts += g_oalTimer.countsPerSysTick;

	// Update the millisecond counter
	CurMSec += g_oalTimer.msecPerSysTick;

	// Reschedule?
	if ((int)(CurMSec - dwReschedTime) >= 0) SysIntr = SYSINTR_RESCHED;

	return SysIntr;
}

/************************************************************************************************
* FUNCTION		:  OALTimerCountsSinceSysTick
*
* DESCRIPTION	: This function return count of hi res ticks since system tick.
*
*				  Timer 4 counts down, so we should substract actual value from 
*				  system tick period.
*
************************************************************************************************/
INT32 OALTimerCountsSinceSysTick()
{
	return (INT32)g_oalTimer.curCounts/g_oalTimer.countsPerSysTick;
}
