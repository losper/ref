/****************************************************************************
*   FileName    : timer.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#include <bsp.h>

//
// function to refresh watchdog timer
//
void RefreshWatchdogTimer (void)
{
	
}

//------------------------------------------------------------------------------
//
//  Function:  OALInitWatchDogTimer
//
//  This is the function to enable hardware watchdog timer support by kernel.
//
void OALInitWatchDogTimer (void)
{
	
}

//------------------------------------------------------------------------------
