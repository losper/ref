/****************************************************************************
*   FileName    : args.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/
#include <bsp.h>

//------------------------------------------------------------------------------
//
//  Function:  OALArgsInit
//
//  This function is called by other OAL modules to intialize value of argument
//  structure.
//
VOID OALArgsInit(DWORD BASEADDRESS)
{
	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]+OALArgsInit()\r\n"));
	
	//setting UUID on Bootloader(read from NAND ID + Chip ID)
	//setting here
	
	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]-OALArgsInit()\r\n"));

	return;
}

//------------------------------------------------------------------------------
//
//  Function:  OALArgsQuery
//
//  This function is called from other OAL modules to return boot arguments.
//  Boot arguments are typically placed in fixed memory location and they are
//  filled by boot loader. In case that boot arguments can't be located
//  the function should return NULL. The OAL module then must use default
//  values.
//
VOID* OALArgsQuery(UINT32 type)
{	
	tSYSTEM_PARAM *pArgs;
	VOID *pData = NULL;
	int i=0;


	OALMSG(TC_LOG_LEVEL(TC_LOG), (L"[KERNEL      ]+OALArgsQuery(%d)\r\n",type));

	// Get pointer to expected boot args location
	pArgs = (tSYSTEM_PARAM *)OALPAtoVA(SYSTEM_PARAM_BASEADDRESS,FALSE);
	
	// Depending on required args
	switch (type)
	{
	case OAL_ARGS_QUERY_DEVID:
		pData = &pArgs->SYSTEM_ARGS.mSystemParam.CHIPID;
		break;
	case OAL_ARGS_QUERY_UUID:
		{
		pData = &pArgs->SYSTEM_ARGS.mSystemParam.NANDUUID;
		}
		break;
	case OAL_ARGS_QUERY_KITL:
		pData = &pArgs->SYSTEM_ARGS.mKitl.nKITLMode;
		break;
	default:
		break;
	}

	OALMSG(TC_LOG_LEVEL(TC_LOG), (L"[KERNEL      ]-OALArgsQuery(%d)\r\n",type));

	
	return pData;
}

//------------------------------------------------------------------------------

