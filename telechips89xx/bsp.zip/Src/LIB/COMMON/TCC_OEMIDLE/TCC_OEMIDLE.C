/****************************************************************************
 *   FileName    : TCC_IOCTL.cpp
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include <bsp.h>

#include "TCC_OEMIDLE.H"
volatile static PCKC pCKC = 0;
volatile static unsigned int bCLK0CTRL = 0;
volatile unsigned int g_idle_expired = 0;

void TCC_OEMIDLE_CLKBASE(unsigned int VirtualAddr)
{
	pCKC = (PCKC)(VirtualAddr);	
}

void TCC_OEMIDLE_ON(void)
{
	g_idle_expired = 1;
    INTERRUPTS_ON();
	bCLK0CTRL =  pCKC->CLK0CTRL;
    pCKC->CLK0CTRL |= (Hw20|0xFF00);
    
	while (g_idle_expired);   
		pCKC->CLK0CTRL  = bCLK0CTRL;
    
	INTERRUPTS_OFF();  
}

void TCC_OEMIDLE_OFF(void)
{
	g_idle_expired = 0;
}