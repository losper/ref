#include "tcc_ckcmddr_20to90.h"


#define MDDR_SETRP(x)  (x>3? (((x-3)<<3)| x ) : ((0<<3) | x))
#define MDDR_SETRCD(x) (x>3? (((x-3)<<3)| x ) : ((0<<3) | x))
#define MDDR_SETRFC(x) (x>3? (((x-3)<<5)| x ) : ((0<<5) | x))

#if defined(DRAM_MDDR)
#define DRAM_AUTOPD_ENABLE Hw13
#define DRAM_AUTOPD_PERIOD 4<<7 // must larger than CAS latency
#define DRAM_SET_AUTOPD DRAM_AUTOPD_ENABLE|DRAM_AUTOPD_PERIOD
#if defined(_LINUX_)
	#define addr(b) (0xF0000000+b)
#else
	#if defined(DRAM_SIZE_512)
		#define addr(b) (0xBF000000+b)
	#else
		#define addr(b) (0xB0000000+b)
	#endif
#endif

void init_clockchange7Mhz(void)//7.2
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 14

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x03006502;		// pms - pllout_72M
    *(volatile unsigned long *)addr(0x400024)= 0x83006502;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 1; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 1; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(1); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}





void init_clockchange8Mhz(void)//8.4
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 12

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x03006502;		// pms - pllout_72M
    *(volatile unsigned long *)addr(0x400024)= 0x83006502;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 1; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 1; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(1); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}


void init_clockchange9Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x03003001;		// pms - pllout_72M
    *(volatile unsigned long *)addr(0x400024)= 0x83003001;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 1; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 1; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(1); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}



void init_clockchange10Mhz(void) //10.42
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 14

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x02009203;		// pms - pllout_146M
    *(volatile unsigned long *)addr(0x400024)= 0x82009203;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 1; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 1; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(1); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}


void init_clockchange11Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 12

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x02002c01;		// pms - pllout_132M
    *(volatile unsigned long *)addr(0x400024)= 0x82002c01;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 1; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 1; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(2); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}



void init_clockchange12Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 6

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x03003001;		// pms - pllout_72M
    *(volatile unsigned long *)addr(0x400024)= 0x83003001;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 1; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 1; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(2); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange14Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 6

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x02005603;		// pms - pllout_86M
    *(volatile unsigned long *)addr(0x400024)= 0x82005603;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 2; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(3); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange18Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x02009203;		// pms - pllout_146M
    *(volatile unsigned long *)addr(0x400024)= 0x82009203;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 2; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(3); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange20Mhz(void)
{
#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
  	#define lmem_div 10

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x01006803;		// pms - pllout_208M
    *(volatile unsigned long *)addr(0x400024)= 0x81006803;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 2; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(3); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange22Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
    #define lmem_div 6

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	
    *(volatile unsigned long *)addr(0x400024)= 0x02002c01;		// pms - pllout_132M
    *(volatile unsigned long *)addr(0x400024)= 0x82002c01;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 2; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(3); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}


void init_clockchange25Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x02006503;		// pms - pllout_101M
	*(volatile unsigned long *)addr(0x400024)= 0x82006503;		//	pll pwr on
	
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 2; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(3); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

//30.5Mhz
void init_clockchange30Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x01007A03;		// pms - pllout_244M
	*(volatile unsigned long *)addr(0x400024)= 0x81007A03;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 2; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(3); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

//35.25Mhz
void init_clockchange35Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x01002F01;		// pms - pllout_282M
	*(volatile unsigned long *)addr(0x400024)= 0x81002F01;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

		
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 3; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(4); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404 &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
	
}
void init_clockchange40Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00005003;		// pms - pllout_320M
	*(volatile unsigned long *)addr(0x400024)= 0x80005003;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 3; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(4); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange45Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x01001E01;		// pms - pllout_180M
	*(volatile unsigned long *)addr(0x400024)= 0x81001E01;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 


	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 2; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 3; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(5); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 0x1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 0x1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 0x2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange50Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00006403;		// pms - pllout_400M
	*(volatile unsigned long *)addr(0x400024)= 0x80006403;		//	pll pwr on

//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 3; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 3; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(5); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
//	*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}


void init_clockchange55Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00006E03;		// pms - pllout_440M
	*(volatile unsigned long *)addr(0x400024)= 0x80006E03;		//	pll pwr on
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem


//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 3; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 4; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(1); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(6); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(1); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428)=  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange60Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00002801;		// pms - pllout_480M
	*(volatile unsigned long *)addr(0x400024)= 0x80002801;		//	pll pwr on

//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 3; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 4; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(6); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange65Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00008203;		// pms - pllout_520M
	*(volatile unsigned long *)addr(0x400024)= 0x80008203;		//	pll pwr on
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 3; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 4; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(7); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 1; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
	//*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange70Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x01002F01;		// pms - pllout_282M
	*(volatile unsigned long *)addr(0x400024)= 0x81002F01;		//	pll pwr on

//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 3; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 5; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(7); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange75Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	8

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00003201;		// pms - pllout_600M
	*(volatile unsigned long *)addr(0x400024)= 0x80003201;		//	pll pwr on
//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif
	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 4; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 5; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(8); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif
	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange80Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00005003;		// pms - pllout_320M
	*(volatile unsigned long *)addr(0x400024)= 0x80005003;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 2
	#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
	#endif

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 4; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 5; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(8); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
//	*(volatile unsigned long *)addr(0x304404) &= ~(0x00000003); // DLLCTRL - DLL OFF, Not Useing DLL 
	#if defined(DRAM_TYPE9)
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	#else
	*(volatile unsigned long *)addr(0x301008) = 0x00000022; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	*(volatile unsigned long *)addr(0x301008) = 0x00040022;
	#endif


	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
}

void init_clockchange85Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00005503;		// pms - pllout_340M
	*(volatile unsigned long *)addr(0x400024)= 0x80005503;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 4; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 6; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(9); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
	
}

//190Mhz
void init_clockchange90Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00001E01;		// pms - pllout_360M
	*(volatile unsigned long *)addr(0x400024)= 0x80001E01;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 4; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 6; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(9); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 1; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
	
}

void init_clockchange95Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00005F03;		// pms - pllout_380M
	*(volatile unsigned long *)addr(0x400024)= 0x80005F03;		//	pll pwr on

	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 4; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 6; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(10); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	


	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}


#endif
