
/****************************************************************************
 *	 FileName	 : TCC_Ioctl.c
 *	 Description : 
 ****************************************************************************
 *
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include "windows.h"

#include "ioctl_code.h"
#include "ioctl_gpiostr.h"
#include "tca_gpio.h"

/****************************************************************************************
* FUNCTION :
* INPUT :
* OUTPUT :
*
* DESCRIPTION :
* ***************************************************************************************/
BOOL gpio_ioctl( UINT32 code, VOID* pInBuffer, UINT32 inSize, VOID* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
{
	stgpioioctl *pGPIOIOCTL = (stgpioioctl*)pInBuffer;
	stgpioinfo *pGPIOINFO = (stgpioinfo*)pOutBuffer;
	static int CurrentOperatingMode;
	
	switch(pGPIOIOCTL->ioctlcode)
	{
		case IOCTL_GPIO_PATOVA: 
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[KERNEL      ]IOCTL_GPIO_PATOVA : 0x%x\n"),pGPIOIOCTL->iphysicalbaseaddress ));
			//pGPIOINFO->returnaddress = tca_allocbaseaddress( pGPIOIOCTL->iphysicalbaseaddress, pGPIOIOCTL->isize);
			pGPIOINFO->returnaddress = OALPAtoVA(pGPIOIOCTL->iphysicalbaseaddress,FALSE);
			break;

		/*
		case IOCTL_GPIO_FREEBASE:// Get Peri Clock
			OALMSG(1, (TEXT("[KERNEL      ]+ IOCTL_GPIO_FREEBASE\n")));
			//pGPIOINFO->returnstatus = tca_freebaseaddress(pGPIOIOCTL->ivirtualbaseaddress, pGPIOIOCTL->isize);
			break;
			*/
		default :		
			  OALMSG(TC_LOG_LEVEL(TC_DEBUG), (TEXT("[KERNEL      ]IOCTL_CKC_default\n")));
			  break;
			
	}
	
	return TRUE;
}



