#if defined(_LINUX_)
    #include "../../../../../../bootloader/tcboot/include/ddr.h"
    #include <bsp.h>
#else
    #include "windows.h"

    #include "bsp.h"
    #include "tca_ckc.h"
#endif


#if !defined(DRAM_MDDR)
extern void init_clockchange125Mhz(void);
extern void init_clockchange130Mhz(void);
extern void init_clockchange135Mhz(void);
extern void init_clockchange141Mhz(void);
extern void init_clockchange145Mhz(void);
extern void init_clockchange150Mhz(void);
extern void init_clockchange160Mhz(void);
extern void init_clockchange170Mhz(void);
extern void init_clockchange180Mhz(void);
extern void init_clockchange190Mhz(void);
#endif

