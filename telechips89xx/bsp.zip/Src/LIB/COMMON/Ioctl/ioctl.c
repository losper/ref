/****************************************************************************
*   FileName    : args.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/
#include <bsp.h>
#include <oal_ioctl.h> 

//extern
extern BOOL OALIoCtlHalReboot(UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer, UINT32 outSize, UINT32 *pOutSize);

//  Global:  g_ioctlState;
//
//  This state variable contains critical section used to serialize IOCTL
//  calls.
//
static struct {
    BOOL postInit;
    CRITICAL_SECTION cs;
} g_ioctlState = { FALSE };


/************************************************************************************************
* FUNCTION		:  OEMIoControl
*
* DESCRIPTION	: The function is called by kernel a device driver or application calls 
*				  KernelIoControl. The system is fully preemtible when this function is 
*				  called. The kernel does no processing of this API. It is provided to 
*				  allow an OEM device driver to communicate with kernel mode code.
*
************************************************************************************************/
BOOL OEMIoControl(
    DWORD code, VOID *pInBuffer, DWORD inSize, VOID *pOutBuffer, DWORD outSize,
    DWORD *pOutSize
) {
    BOOL rc = FALSE;
    UINT32 i;

	switch (code) {
	
	case IOCTL_HAL_REBOOT:
		{
			OALIoCtlHalReboot(code, NULL, 0,  NULL, 0, NULL);
		}	
		break;
	}

    i = (code&0x3FFC)>>2;
    OALMSG(OAL_IOCTL&&OAL_FUNC, (
        L"+OEMIoControl(0x%x(FUNC:0x%x), 0x%x, %d, 0x%x, %d, 0x%x)\r\n", 
        code,i, pInBuffer, inSize, pOutBuffer, outSize, pOutSize
    ));
    // Search the IOCTL table for the requested code.
    for (i = 0; g_oalIoCtlTable[i].pfnHandler != NULL; i++) {
        if (g_oalIoCtlTable[i].code == code) break;
    }

    // Indicate unsupported code
    if (g_oalIoCtlTable[i].pfnHandler == NULL) {
#ifdef OAL_HAL_INTERNAL_TESTING
        rc = InternalHalTesting(
            code, pInBuffer, inSize, pOutBuffer, outSize, pOutSize
        );
#else
        NKSetLastError(ERROR_NOT_SUPPORTED);
        OALMSG(0,( //OAL_WARN, (
            L"OEMIoControl: Unsupported Code 0x%x - device 0x%04x func %d\r\n", 
            code, code >> 16, (code >> 2)&0x0FFF
        ));
#endif
        goto cleanUp;
    }        

    // Take critical section if required (after postinit & no flag)
    if (
        g_ioctlState.postInit && 
        (g_oalIoCtlTable[i].flags & OAL_IOCTL_FLAG_NOCS) == 0
    ) {
        // Take critical section            
        EnterCriticalSection(&g_ioctlState.cs);
    }

    // Execute the handler
    rc = g_oalIoCtlTable[i].pfnHandler(
        code, pInBuffer, inSize, pOutBuffer, outSize, pOutSize
    );

    // Release critical section if it was taken above
    if (
        g_ioctlState.postInit && 
        (g_oalIoCtlTable[i].flags & OAL_IOCTL_FLAG_NOCS) == 0
    ) {
        // Take critical section            
        LeaveCriticalSection(&g_ioctlState.cs);
    } else if (!g_ioctlState.postInit && code == IOCTL_HAL_POSTINIT) {
        // Initialize critical section
        InitializeCriticalSection(&g_ioctlState.cs);
        g_ioctlState.postInit = TRUE;
    }                

cleanUp:
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"-OEMIoControl(rc = %d)\r\n", rc ));
    return rc;
}

//------------------------------------------------------------------------------
