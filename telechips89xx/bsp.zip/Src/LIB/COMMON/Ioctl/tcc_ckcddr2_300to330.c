#include "tcc_ckcddr2_300to330.h"

#if !defined(DRAM_MDDR)
#define DDR2_SETRCD(x) (x>3? (((x-3)<<8)| x ) : ((1<<8) | x))
#define DDR2_SETRFC(x) (x>3? (((x-3)<<8)| x ) : ((0<<8) | x))
#define DDR2_SETRP(x)  (x>3? (((x-3)<<8)| x ) : ((1<<8) | x))

#define DRAM_AUTOPD_ENABLE Hw13
#define DRAM_AUTOPD_PERIOD 7<<7 // must larger than CAS latency
#define DRAM_SET_AUTOPD DRAM_AUTOPD_ENABLE|DRAM_AUTOPD_PERIOD

#if defined(_LINUX_)
	#define addr(b) (0xF0000000+b)
#else
	#if defined(DRAM_SIZE_512)
		#define addr(b) (0xBF000000+b)
	#else
		#define addr(b) (0xB0000000+b)
	#endif
#endif


//300Mhz
void init_clockchange300Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		

	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00003201;		// pms - pllout_600M
	*(volatile unsigned long *)addr(0x400024)= 0x80003201;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 2340; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x0000041A; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 14; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 18; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(5); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(32); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(39); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(5); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 5; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 3; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 35; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 42; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW

	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
	*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif


	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080962; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080952; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080862; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008)= 0x00080852; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//312Mhz
void init_clockchange312Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00006802;		// pms - pllout_624M
	*(volatile unsigned long *)addr(0x400024)= 0x80006802;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 2433; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x00000443; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 15; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 19; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(5); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(33); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(40); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(5); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 4; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 5; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 3; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 36; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 43; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW

	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif


	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080962; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080952; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080862; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080852; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008)= 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//320Mhz
void init_clockchange320Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		

	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x0000A003;		// pms - pllout_640M
	*(volatile unsigned long *)addr(0x400024)= 0x8000A003;		//	pll pwr on

	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 2496; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x00000460; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 15; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 20; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(5); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(34); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(41); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(5); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 4; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 5; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 3; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 37; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 44; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW
	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif


	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080962; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080952; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080862; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008)= 0x00080852; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//330Mhz
void init_clockchange330Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00006E02;		// pms - pllout_660M
	*(volatile unsigned long *)addr(0x400024)= 0x80006E02;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 2574; 	// refresh 
	//*(volatile unsigned long *)addr(0x302010) = 0x00000482; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		

	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 15; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 20; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(5); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(35); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(42); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(5); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 4; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 5; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 3; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 38; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 46; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW

	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif


	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080962; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080952; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080862; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080852; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO

}

#endif
