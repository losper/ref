
/****************************************************************************
 *	 FileName	 : TCC_Ioctl.c
 *	 Description : 
 ****************************************************************************
 *
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include "windows.h"
#include "bsp.h"
#include "tca_ckc.h"
#if defined(DRAM_DDR2)
#include "tcc_ckcddr2_141to190.h"
#include "tcc_ckcddr2_200to290.h"
#include "tcc_ckcddr2_300to330.h"
#endif

#if defined(DRAM_MDDR)
#include "tcc_ckcmddr_100to160.h"
#include "tcc_ckcmddr_20to90.h"
#endif

extern int arm_changestack(void);
extern void arm_restorestack(unsigned int rst);
extern int arm_disableInt(void);
extern void arm_restoreInt(int rint);

volatile unsigned int retstack = 0;
volatile unsigned int busvalue = 0;
static unsigned int _gCPSRInt = 0;
volatile unsigned int retint = 0;
#define FCORE_STEP_NUM 60
//#define FBUS_STEP_NUM 32
#define FBUS_STEP_NUM 33
unsigned int FbusStepValue[FBUS_STEP_NUM] = {
	2640000, // PLL3
	2340000,
	1760000, // PLL3
	1560000,
	1320000, // PLL3
	1170000,
	1056000, // PLL3
	936000,
	880000, // PLL3
	780000,
	754285, // PLL3
	668571,
	660000, // PLL3
	586666, // PLL3
	585000,
	528000, // PLL3
	520000,
	480000, // PLL3
	468000,
	440000, // PLL3
	425454,
	406153, // PLL3
	390000,
	377142, // PLL3
	360000,
	352000, // PLL3
	334285,
	330000, // PLL3
	312000,
	292500, 
	60000, // XIN
	30000, // XIN
	10000, // XIN
};

/*
unsigned int FcoreStepValue[FCORE_STEP_NUM] = {
	6000000,
	5062500,4860000,4725000,4556250,	4387500,4252500,4050000,3948750,	3780000,3712500,
	3645000,3510000,3375000,3240000,	3037500,2970000,2835000,2700000,	2632500,2430000,
	2362500,2227500,2160000,2025000,	1890000,1822500,1750000,1687500,	1620000,1485000,
//	1417500,1350000,1215000,1015000,	945000 ,810000 ,675000 ,607500     ,540000  ,405000,
	1417500,1350000,1215000,1080000,	945000 ,825000 ,742500 ,718750     ,540000  ,405000
};

unsigned int FcorePllValue[FCORE_STEP_NUM] = {
	6000000,
	5400000,	4860000,	5400000,	4860000,	5400000,	4860000,	4320000,	4860000,	4320000,	5400000,
	4860000,	4320000,	5400000,	3240000,	3240000,	4320000,	3240000,	5400000,	3240000,	3240000,
	5400000,	3240000,	2160000,	2160000,	2160000,	3240000,	2160000,	5400000,	2160000,	2160000,
//	3240000,	2160000,	2160000,	2160000,	2160000,	2160000,	2160000,	3240000,	2160000,	2160000,
	3240000,	2160000,	2160000,	2160000,	2160000,	1320000,	1320000,	2300000,	2160000,	2160000
};

unsigned int FcoreDividerValue[FCORE_STEP_NUM] = {
	16,
	15,	16,	14,	15,	13,	14,	15,	13,	14,	11,
	12,	13,	10,	16,	15,	11,	14,	8,	13,	12,
	7,	11,	16,	15,	14,	9,	13,	5,	12,	11,
//	7,	10,	9,	8,	7,	6,	5,	3,	4,	3,
	7,	10,	9,	8,	7,	10,	9,	5,	4,	3

};
*/
unsigned int FcoreStepValue[FCORE_STEP_NUM] = {
	6000000,
	5062500,4860000,4725000,4556250,4387500,4252500,4050000,3948750,3780000,3712500,
	3645000,3510000,3375000,3240000,3037500,2970000,2835000,2700000,2632500,2430000,
	2362500,2227500,2160000,2025000,1890000,1822500,1750000,1687500,1620000,1518750,
	1485000,1417500,1350000 ,1215000,1125000,1080000,1012500, 960000 ,945000, 907500 ,
	883750 ,840000  , 810000  ,787500  ,757500 ,730000  ,712500  ,660000  ,631250,607500  ,
	577500 ,540000  , 495000  ,450000  ,405000 ,378750  ,360000  ,330000 ,270000
};

unsigned int FcorePllValue[FCORE_STEP_NUM] = {
	6000000,
	5400000,	4860000,	5400000,	4860000,	5400000,	4860000,	4320000,	4860000,	4320000,	5400000,
	4860000,	4320000,	5400000,	3240000,	3240000,	4320000,	3240000,	5400000,	3240000,	3240000,
	5400000,	3240000,	2160000,	2160000,	2160000,	3240000,	2160000,	5400000,	2160000,	4860000,
	2160000,3240000,	2160000,	2160000,	1800000,	2160000,	3240000,	1920000,	2160000,	1320000,
	2020000,	1920000,	2160000,	1800000,	2020000,	1460000,	1900000,	1320000,	2020000,	3240000,
	1320000,	1440000,	1320000,	1440000,	2160000, 2020000, 1440000,1320000,1440000,
};

unsigned int FcoreDividerValue[FCORE_STEP_NUM] = {
	16,
	15,	16,	14,	15,	13,	14,	15,	13,	14,	11,
	12,	13,	10,	16,	15,	11,	14,	8,	13,	12,
	7,	11,	16,	15,	14,	9,	13,	5,	12 ,  5, 
	11,	7,	10,	9,	10,	8,	5,	8,	7,	11,
	7,	7,	6,	7,	6,	8,	6,	8,	5,	3,
	7,	6,	6,	5,	3,    3,     4,     4,   3

};

typedef void (*lpfunc)();
lpfunc lpSelfRefresh;


#if defined(DRAM_SIZE_512)
#define SRAM_COPY_ADDR				0xBFA00000
#else
#define SRAM_COPY_ADDR				0xB0A00000
#endif
#define SRAM_COPY_FUNC_SIZE			0x600

static void init_copychangeclock(unsigned int lbusvalue)
{

	volatile unsigned int	*fptr;
	volatile unsigned int	*p;
	int 					i;
	
#if defined(DRAM_DDR2)
	if(lbusvalue == 1250000) 
		fptr = (volatile unsigned int*)init_clockchange125Mhz;
	else if(lbusvalue == 1300000) 
		fptr = (volatile unsigned int*)init_clockchange130Mhz;
	else if(lbusvalue == 1350000) 
		fptr = (volatile unsigned int*)init_clockchange135Mhz;
	else if(lbusvalue == 1410000) 
		fptr = (volatile unsigned int*)init_clockchange141Mhz;
	else if(lbusvalue == 1450000) 
		fptr = (volatile unsigned int*)init_clockchange145Mhz;
	else if(lbusvalue == 1500000) 
		fptr = (volatile unsigned int*)init_clockchange150Mhz;
	else if(lbusvalue == 1600000) 
		fptr = (volatile unsigned int*)init_clockchange160Mhz;
	else if(lbusvalue == 1700000) 
		fptr = (volatile unsigned int*)init_clockchange170Mhz;
	else if(lbusvalue == 1800000) 
		fptr = (volatile unsigned int*)init_clockchange180Mhz;
	else if(lbusvalue == 1900000) 
		fptr = (volatile unsigned int*)init_clockchange190Mhz;
	else if(lbusvalue == 2000000) 
		fptr = (volatile unsigned int*)init_clockchange200Mhz;
	else if(lbusvalue == 2100000) 
		fptr = (volatile unsigned int*)init_clockchange210Mhz;
	else if(lbusvalue == 2200000) 
		fptr = (volatile unsigned int*)init_clockchange220Mhz;
	else if(lbusvalue == 2300000) 
		fptr = (volatile unsigned int*)init_clockchange230Mhz;
	else if(lbusvalue == 2400000) 
		fptr = (volatile unsigned int*)init_clockchange240Mhz;
	else if(lbusvalue == 2500000) 
		fptr = (volatile unsigned int*)init_clockchange250Mhz;
	else if(lbusvalue == 2600000) 
		fptr = (volatile unsigned int*)init_clockchange260Mhz;
	else if(lbusvalue == 2700000) 
		fptr = (volatile unsigned int*)init_clockchange270Mhz;
	else if(lbusvalue == 2800000) 
		fptr = (volatile unsigned int*)init_clockchange280Mhz;
	else if(lbusvalue == 2900000) 
		fptr = (volatile unsigned int*)init_clockchange290Mhz;
	else if(lbusvalue == 3000000) 
		fptr = (volatile unsigned int*)init_clockchange300Mhz;
	else if(lbusvalue == 3120000) 
		fptr = (volatile unsigned int*)init_clockchange312Mhz;
	else if(lbusvalue == 3200000) 
		fptr = (volatile unsigned int*)init_clockchange320Mhz;
	else if(lbusvalue == 3300000) 
		fptr = (volatile unsigned int*)init_clockchange330Mhz;
	else
		fptr = (volatile unsigned int*)init_clockchange190Mhz;	
#endif

#if defined(DRAM_MDDR)
	if(lbusvalue == 70000) // idle
		fptr = (volatile unsigned int*)init_clockchange7Mhz;
	else if(lbusvalue == 80000) // idle
		fptr = (volatile unsigned int*)init_clockchange8Mhz;
	else if(lbusvalue == 90000) // idle
		fptr = (volatile unsigned int*)init_clockchange9Mhz;
	else if(lbusvalue == 100000) // idle
		fptr = (volatile unsigned int*)init_clockchange10Mhz;
	else if(lbusvalue == 110000) // idle
		fptr = (volatile unsigned int*)init_clockchange11Mhz;
	else if(lbusvalue == 120000) // idle
		fptr = (volatile unsigned int*)init_clockchange12Mhz;
	else if(lbusvalue == 140000) // idle
		fptr = (volatile unsigned int*)init_clockchange14Mhz;
	else if(lbusvalue == 180000) // idle
		fptr = (volatile unsigned int*)init_clockchange18Mhz;
	else if(lbusvalue == 200000) // idle
		fptr = (volatile unsigned int*)init_clockchange20Mhz;
	else if(lbusvalue == 220000) // idle
		fptr = (volatile unsigned int*)init_clockchange22Mhz;
	else if(lbusvalue == 250000) // idle
		fptr = (volatile unsigned int*)init_clockchange25Mhz;
	else if(lbusvalue == 305000) 
		fptr = (volatile unsigned int*)init_clockchange30Mhz;
	else if(lbusvalue == 352500) 
		fptr = (volatile unsigned int*)init_clockchange35Mhz;
	else if(lbusvalue == 400000) 
		fptr = (volatile unsigned int*)init_clockchange40Mhz;
	else if(lbusvalue == 450000) 
		fptr = (volatile unsigned int*)init_clockchange45Mhz;
	else if(lbusvalue == 500000) 
		fptr = (volatile unsigned int*)init_clockchange50Mhz;
	else if(lbusvalue == 550000) 
		fptr = (volatile unsigned int*)init_clockchange55Mhz;
	else if(lbusvalue == 600000) 
		fptr = (volatile unsigned int*)init_clockchange60Mhz;
	else if(lbusvalue == 650000) 
		fptr = (volatile unsigned int*)init_clockchange65Mhz;
	else if(lbusvalue == 705000) 
		fptr = (volatile unsigned int*)init_clockchange70Mhz;
	else if(lbusvalue == 750000) 
		fptr = (volatile unsigned int*)init_clockchange75Mhz;
	else if(lbusvalue == 800000) 
		fptr = (volatile unsigned int*)init_clockchange80Mhz;
	else if(lbusvalue == 850000) 
		fptr = (volatile unsigned int*)init_clockchange85Mhz;
	else if(lbusvalue == 900000) 
		fptr = (volatile unsigned int*)init_clockchange90Mhz;
	else if(lbusvalue == 950000) 
		fptr = (volatile unsigned int*)init_clockchange95Mhz;
	else if(lbusvalue == 1000000) 
		fptr = (volatile unsigned int*)init_clockchange100Mhz;
	else if(lbusvalue == 1050000) 
		fptr = (volatile unsigned int*)init_clockchange105Mhz;
	else if(lbusvalue == 1100000) 
		fptr = (volatile unsigned int*)init_clockchange110Mhz;
	else if(lbusvalue == 1150000) 
		fptr = (volatile unsigned int*)init_clockchange115Mhz;
	else if(lbusvalue == 1200000) 
		fptr = (volatile unsigned int*)init_clockchange120Mhz;
	else if(lbusvalue == 1250000) 
		fptr = (volatile unsigned int*)init_clockchange125Mhz;
	else if(lbusvalue == 1300000) 
		fptr = (volatile unsigned int*)init_clockchange130Mhz;
	else if(lbusvalue == 1350000) 
		fptr = (volatile unsigned int*)init_clockchange135Mhz;
	else if(lbusvalue == 1400000) 
		fptr = (volatile unsigned int*)init_clockchange140Mhz;
	else if(lbusvalue == 1450000) 
		fptr = (volatile unsigned int*)init_clockchange145Mhz;
	else if(lbusvalue == 1500000) 
		fptr = (volatile unsigned int*)init_clockchange150Mhz;
	else if(lbusvalue == 1560000) 
		fptr = (volatile unsigned int*)init_clockchange156Mhz;
	else if(lbusvalue == 1600000) 
		fptr = (volatile unsigned int*)init_clockchange160Mhz;
	else if(lbusvalue == 1650000) // jykim
		fptr = (volatile unsigned int*)init_clockchange165Mhz;
	else if(lbusvalue == 1700000) // jykim
		fptr = (volatile unsigned int*)init_clockchange170Mhz;
	else if(lbusvalue == 1760000) // jykim
		fptr = (volatile unsigned int*)init_clockchange176Mhz;
	else if(lbusvalue == 1800000) // jykim
		fptr = (volatile unsigned int*)init_clockchange180Mhz;
	else if(lbusvalue == 1850000) // jykim
		fptr = (volatile unsigned int*)init_clockchange185Mhz;
	else
		fptr = (volatile unsigned int*)init_clockchange185Mhz;
#endif
		
	lpSelfRefresh = (lpfunc)(SRAM_COPY_ADDR);
	
	p = (volatile unsigned int*)SRAM_COPY_ADDR;
	for (i = 0;i < (SRAM_COPY_FUNC_SIZE);i++)
	{
		*p = *fptr;
		p++;
		fptr++;
	}
	
	while(--i);
	
	// Jump to Function Start Point
	lpSelfRefresh();
}

void int_alldisable(void)
{
/*
	volatile unsigned int count;
	count = 1;
	while(count--);
	*/
	_gCPSRInt = arm_disableInt();

}

void int_restore(void)
{
/*
	volatile unsigned int count;
	count = 1;
	while(count--);
	*/
	arm_restoreInt(_gCPSRInt);

}

void ioctl_delay(unsigned int cnt)
{
	volatile unsigned int count;
	count = cnt*10000;
	while(count--);
}


void ckc_etcblock(unsigned int lMask)
{
	PUSBOTGCFG  pOTGCFG  = (PUSBOTGCFG)(OALPAtoVA((unsigned int)&HwUSBOTGCFG_BASE,FALSE));
	PGPUGRPBUSCONFIG  pGPUGRPBUSCONFIG  = (PGPUGRPBUSCONFIG)(OALPAtoVA((unsigned int)&HwGRPBUS_BASE,FALSE));

	
// Disable
	if(lMask & ETCMASK_USBPHYOFF)
	{
		OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]ETCMASK_USBPHYOFF\r\n"));
		BITCSET(pOTGCFG->UPCR2,Hw10|Hw9,Hw9);
		pOTGCFG->UPCR0 = 0x4840;
		pOTGCFG->UPCR0 = 0x6940;
	}
#if !defined(MAX_FGRP_EN)
	if(lMask & ETCMASK_3DGPUOFF)
	{
		OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]ETCMASK_3DGPUOFF\r\n"));
		pGPUGRPBUSCONFIG->GRPBUS_PWRDOWN |= Hw0;
	}
	
	if(lMask & ETCMASK_OVERLAYMIXEROFF)
	{
		OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]ETCMASK_OVERLAYMIXEROFF\r\n"));
		pGPUGRPBUSCONFIG->GRPBUS_PWRDOWN |= Hw1;
	}
#endif
//Enable 
	if(lMask & ETCMASK_OVERLAYMIXERON)
	{
		OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]ETCMASK_OVERLAYMIXEROFF\r\n"));
		pGPUGRPBUSCONFIG->GRPBUS_PWRDOWN  &= ~Hw1;
	}
	if(lMask & ETCMASK_3DGPUON)
	{
		OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]ETCMASK_3DGPUON\r\n"));
		pGPUGRPBUSCONFIG->GRPBUS_PWRDOWN &= ~Hw0;
	}
	
	if(lMask & ETCMASK_USBPHYON)
	{
		OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]ETC_USBPHYON\r\n"));
		BITCSET(pOTGCFG->UPCR2,Hw10|Hw9,0);
		pOTGCFG->UPCR0 = 0x2842;
	}

}
/****************************************************************************************
* FUNCTION :
* INPUT :
* OUTPUT :
*
* DESCRIPTION :
* ***************************************************************************************/
BOOL ckc_ioctl( UINT32 code, VOID* pInBuffer, UINT32 inSize, VOID* pOutBuffer, UINT32 outSize, UINT32* pOutSize)
{
	stckcioctl *pCKCIOCTL = (stckcioctl*)pInBuffer;
	stckcinfo *pCKCINFO = (stckcinfo*)pOutBuffer;
	static int CurrentOperatingMode;
	unsigned int i = 0; 
	unsigned int validFlag = 0;
	
	switch(pCKCIOCTL->ioctlcode)
	{
		case IOCTL_CKC_SET_PERI: // Set Peri Clock
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_PERI\r\n"));
			int_alldisable();
			tca_ckc_setperi(pCKCIOCTL->pckcname,pCKCIOCTL->pckcenable, pCKCIOCTL->pckcfreq, pCKCIOCTL->pckcsource);
			int_restore();
			break;
		case IOCTL_CKC_GET_PERI:// Get Peri Clock
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_PERI\r\n"));
			pCKCINFO->pckcfreq= tca_ckc_getperi( pCKCIOCTL->pckcname);
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_PERI: %d \r\n",pCKCINFO->pckcfreq));
			break;
			
		case IOCTL_CKC_SET_PERIBUS: // Set io Bus on/off
			// Use Control Bit as Periselection...
			 OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_PERIBUS\r\n"));
			pCKCINFO->retVal = tca_ckc_setiobus(pCKCIOCTL->prbname, pCKCIOCTL->mode); // Enable or Disable
			break;
			
		case IOCTL_CKC_GET_PERIBUS:// Get io Bus State
			pCKCINFO->retVal = tca_ckc_getiobus(pCKCIOCTL->prbname);
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_PERIBUS: %d\r\n", pCKCINFO->retVal));
			break;
			
		case IOCTL_CKC_SET_PERISWRESET:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_PERISWRESET: %d\r\n",pCKCIOCTL->prbname));
			tca_ckc_set_iobus_swreset(pCKCIOCTL->prbname, OFF);
			tca_ckc_set_iobus_swreset(pCKCIOCTL->prbname, ON);
			break;
		case IOCTL_CKC_SET_FBUSSWRESET:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_FBUSSWRESET: %d\r\n",pCKCIOCTL->prbname));
			tca_ckc_setswreset(pCKCIOCTL->fbusname,ON);
			ioctl_delay(100);
			tca_ckc_setswreset(pCKCIOCTL->fbusname,OFF);
			break;
			
		case IOCTL_CKC_SET_CPU:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_CPU : %d divider\r\n",pCKCIOCTL->cpudivider));
			int_alldisable();

			//pCKCINFO->retVal = -1;
			tca_ckc_setcpu(pCKCIOCTL->cpudivider);

			pCKCINFO->currentsysfreq = tca_ckc_getpll(0);
			pCKCINFO->currentcpufreq = tca_ckc_getcpu();
			pCKCINFO->currentbusfreq = tca_ckc_getbus();
			int_restore();
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_CPU : PLL-%d, CPU-%d, BUS-%d\\r\n",pCKCINFO->currentsysfreq,pCKCINFO->currentcpufreq,pCKCINFO->currentbusfreq));
			break;

		case IOCTL_CKC_SET_SMUI2C:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_SMUI2C :Set SMUI2C-%d\r\n",pCKCIOCTL->pckcfreq));
			tca_ckc_setsmui2c(pCKCIOCTL->pckcfreq);
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_SMUI2C :Get SMUI2C-%d\r\n",tca_ckc_getsmui2c()));
			break;

		case IOCTL_CKC_GET_CPU:
			pCKCINFO->currentcpufreq = tca_ckc_getcpu();
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_CPU :%d\r\n",pCKCINFO->currentcpufreq));
			break;
			
		case IOCTL_CKC_GET_BUS:
			pCKCINFO->currentbusfreq = tca_ckc_getbus();
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_BUS :%d\r\n",pCKCINFO->currentbusfreq));
			break;

		case IOCTL_CKC_GET_VALIDPLLINFO:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_VALIDPLLINFO: \r\n"));
			tca_ckc_validpll(pCKCINFO->validpll);	
			break;
			
		case IOCTL_CKC_GET_CLOCKINFO:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_CLOCKINFO\r\n"));
			pCKCINFO->currentsysfreq = tca_ckc_getpll(0);
			pCKCINFO->currentcpufreq = tca_ckc_getcpu();
			pCKCINFO->currentbusfreq = tca_ckc_getbus();

			pCKCINFO->pll1freq = tca_ckc_getpll(1);
			pCKCINFO->pll2freq = tca_ckc_getpll(2);
			pCKCINFO->pll3freq= tca_ckc_getpll(3);

			pCKCINFO->ddifreq = tca_ckc_getfbusctrl(CLKCTRL1);//FBUS_DDI
			pCKCINFO->grpfreq = tca_ckc_getfbusctrl(CLKCTRL3);//FBUS_GRP
			pCKCINFO->iofreq = tca_ckc_getfbusctrl(CLKCTRL4);//FBUS_IOB
			pCKCINFO->vbusfreq = tca_ckc_getfbusctrl(CLKCTRL5);//FBUS_VBUS
			pCKCINFO->vpufreq = tca_ckc_getfbusctrl(CLKCTRL6);//FBUS_VCODEC
			pCKCINFO->smufreq = tca_ckc_getfbusctrl(CLKCTRL7);//FBUS_SMU
		
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_MAINCLOCKCFG1 : PLL-%d, CPU-%d, BUS-%d\r\n",pCKCINFO->currentsysfreq,pCKCINFO->currentcpufreq,pCKCINFO->currentbusfreq));
			*pOutSize = sizeof(stckcinfo);
			break;

		case IOCTL_CKC_SET_FBUS:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_FBUS:Name:%d,Enable:%d,Mode:%d,Freq:%d,Source:%d ,bspmax:%d\r\n",pCKCIOCTL->fbusname,pCKCIOCTL->fbusenable,pCKCIOCTL->mode,pCKCIOCTL->fbusfreq,pCKCIOCTL->fbussource,pCKCIOCTL->bspmax));

			if( pCKCIOCTL->fbusenable == ENABLE)
			{
				for(i = 0; i < FBUS_STEP_NUM; i++)
				{
					if(pCKCIOCTL->fbusfreq == FbusStepValue[i] ||  pCKCIOCTL->fbusfreq == 3300000)
					{
						validFlag = 1;
						break;
					}
				}
				
				if( validFlag == 1)
				{
					if(i <= 12)
					{
						if((i%2) == 1)
							pCKCIOCTL->fbussource = DIRECTPLL2;
						else
							pCKCIOCTL->fbussource = DIRECTPLL3;
					}
					else
					{
						if(i >= FBUS_STEP_NUM-3)
						{
							pCKCIOCTL->fbussource = DIRECTXIN;
						}
						else if(i == (FBUS_STEP_NUM-4))
						{
							pCKCIOCTL->fbussource = DIRECTPLL2;
						}
						else
						{
							if((i%2) == 1)
								pCKCIOCTL->fbussource = DIRECTPLL3;
							else
								pCKCIOCTL->fbussource = DIRECTPLL2;
						}
					}		
				}
			
				if( validFlag == 1)
				{
					pCKCIOCTL->fbusenable = ENABLE;
					pCKCIOCTL->mode = NORMAL_MD;
					tca_ckc_setfbusctrl(pCKCIOCTL->fbusname,pCKCIOCTL->fbusenable,pCKCIOCTL->mode,pCKCIOCTL->fbusfreq,pCKCIOCTL->fbussource);					
				}		
			}
			else
			{
				pCKCIOCTL->fbusenable = DISABLE;
				pCKCIOCTL->mode = NORMAL_MD;
				tca_ckc_setfbusctrl(pCKCIOCTL->fbusname,pCKCIOCTL->fbusenable,pCKCIOCTL->mode,pCKCIOCTL->fbusfreq,pCKCIOCTL->fbussource);					
			}

			break;

		case IOCTL_CKC_GET_FBUS:
			pCKCINFO->fbusfreq = tca_ckc_getfbusctrl(pCKCIOCTL->fbusname);
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]+IOCTL_CKC_GET_FBUS:%d\r\n",pCKCINFO->fbusfreq));
			break;
		case IOCTL_CKC_SET_PMUPOWER:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_PMUPOWER: Name- %d , Mode- %d\n",pCKCIOCTL->pmuoffname,pCKCIOCTL->mode));
				if( pCKCIOCTL->mode == 0)
				{
					if(pCKCIOCTL->pmuoffname < PMU_MEMORYBUS)
					{
						validFlag = 1;
					}
					else 
						validFlag = 0; // if ( pCKCIOCTL->pmuoffname >= PMU_MEMORYBUS) used  IOCTL_CKC_SET_CHANGEFBUS IOCTL

					if(validFlag == 1)
					{
						tca_ckc_setpmupwroff(pCKCIOCTL->pmuoffname,DISABLE);	

					}

				}
				else
				{
					if(pCKCIOCTL->pmuoffname < PMU_MEMORYBUS)
					{
						validFlag = 1;
					}
					else 
						validFlag = 0; // if ( pCKCIOCTL->pmuoffname >= PMU_MEMORYBUS) used  IOCTL_CKC_SET_CHANGEFBUS IOCTL

					if(validFlag == 1)
					{
						tca_ckc_setpmupwroff(pCKCIOCTL->pmuoffname,ENABLE);	

					}
				}
			break;

		case IOCTL_CKC_GET_PMUPOWER:
			pCKCINFO->state = tca_ckc_getpmupwroff(pCKCIOCTL->pmuoffname);
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_PMUPOWER : %d\r\n",pCKCINFO->state));
			break;
		case IOCTL_CKC_SET_CHANGEFBUS:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_CHANGEFBUS\r\n"));
			#if defined(MAX_FGRP_EN)
//			if(pCKCIOCTL->fbusname != CLKCTRL3 || ((pCKCIOCTL->fbusname == CLKCTRL3) && (pCKCIOCTL->fbusfreq != 0)) )
			if(pCKCIOCTL->fbusname != CLKCTRL3 )
			{
			#endif
			int_alldisable();
			OALCleanDCache();
			OALFlushICache();

			// Except : FCORE_CPU, FMEM_BUS, FBUS_IOB
			// Change Fbus : FBUS_DDI, FBUS_GRP, FBUS_VBUS, FBUS_VCODEC, FBUS_SMU
			if(pCKCIOCTL->mode == DYNAMIC_MD)
			{
				tca_ckc_setfbusdynamicctrl(pCKCIOCTL->fbusname,pCKCIOCTL->dynamicmax,pCKCIOCTL->dynamicmin,pCKCIOCTL->dynamiccycle);
			}
			else
			{

				//if(pCKCIOCTL->fbusname != CLKCTRL0 && pCKCIOCTL->fbusname != CLKCTRL2 && pCKCIOCTL->fbusname != CLKCTRL4 )
					if(pCKCIOCTL->fbusname != CLKCTRL0 && pCKCIOCTL->fbusname != CLKCTRL2 )
					{
						//if(pCKCIOCTL->fbusfreq == 60000 || pCKCIOCTL->fbusfreq == 0)
						if( pCKCIOCTL->fbusfreq == 0)
						{
						#if defined(TCC_R_AX)
							pCKCIOCTL->fbusenable = DISABLE;
							pCKCIOCTL->mode = NORMAL_MD;		
							
								if(pCKCIOCTL->fbusname == CLKCTRL1)
								{
									pCKCIOCTL->pmuoffname = PMU_DDIBUS;
									validFlag = 0;
								}
								else if(pCKCIOCTL->fbusname == CLKCTRL5)
								{
									pCKCIOCTL->pmuoffname = PMU_VIDEOBUS;
									validFlag = 1;
								}
								else if(pCKCIOCTL->fbusname == CLKCTRL3)
								{
									pCKCIOCTL->pmuoffname = PMU_GRAPHICBUS;
									validFlag = 1;
								}			
								else 
									validFlag = 0;

								if(validFlag == 1)
								{
									if(pCKCIOCTL->fbusname == CLKCTRL5)
									{
										tca_ckc_setswreset(CLKCTRL5,ON);							
										tca_ckc_setswreset(CLKCTRL6,ON);		

										ioctl_delay(10);
										tca_ckc_setfbusctrl(pCKCIOCTL->fbusname,pCKCIOCTL->fbusenable,pCKCIOCTL->mode,pCKCIOCTL->fbusfreq,pCKCIOCTL->fbussource);

										tca_ckc_setpmupwroff(PMU_VIDEOBUS,DISABLE);	
									}
									else
									{
										tca_ckc_setswreset(pCKCIOCTL->fbusname,ON);							
										ioctl_delay(10);
										tca_ckc_setfbusctrl(pCKCIOCTL->fbusname,pCKCIOCTL->fbusenable,pCKCIOCTL->mode,pCKCIOCTL->fbusfreq,pCKCIOCTL->fbussource);
										tca_ckc_setpmupwroff(pCKCIOCTL->pmuoffname,DISABLE);	
									}

									if(pCKCIOCTL->fbusname == CLKCTRL5)
									{
										tca_ckc_setswreset(CLKCTRL6,OFF);							
										tca_ckc_setswreset(CLKCTRL5,OFF);							
									}
									else
										tca_ckc_setswreset(pCKCIOCTL->fbusname,OFF);							

								}
								else
								{
								//	tca_ckc_setswreset(pCKCIOCTL->fbusname,ON);							
								//	ioctl_delay(10);
									tca_ckc_setfbusctrl(pCKCIOCTL->fbusname,pCKCIOCTL->fbusenable,pCKCIOCTL->mode,pCKCIOCTL->fbusfreq,pCKCIOCTL->fbussource);
								//	tca_ckc_setswreset(pCKCIOCTL->fbusname,OFF);							
								}
						#else
							//tca_ckc_setswreset(pCKCIOCTL->fbusname);
							validFlag = 1;
							tca_ckc_setfbusctrl(pCKCIOCTL->fbusname,ENABLE,NORMAL_MD,60000,DIRECTXIN);
						#endif
						}
						else
						{
						#if defined(TCC_R_AX)	
							if(pCKCIOCTL->fbusname == CLKCTRL1)
							{
								pCKCIOCTL->pmuoffname = PMU_DDIBUS;
								validFlag = 0;
							}
							else if(pCKCIOCTL->fbusname == CLKCTRL5)
							{
								pCKCIOCTL->pmuoffname = PMU_VIDEOBUS;
								validFlag = 1;
							}
							else if(pCKCIOCTL->fbusname == CLKCTRL3)
							{
								pCKCIOCTL->pmuoffname = PMU_GRAPHICBUS;
								validFlag = 1;
							}			
							else 
								validFlag = 0;

							if(validFlag == 1)
							{
								if(pCKCIOCTL->fbusname == CLKCTRL5)
								{
									tca_ckc_setswreset(CLKCTRL5,ON);							
									tca_ckc_setswreset(CLKCTRL6,ON);							
									tca_ckc_setpmupwroff(PMU_VIDEOBUS,ENABLE);			
								}
								else
								{
									tca_ckc_setswreset(pCKCIOCTL->fbusname,ON);	
									tca_ckc_setpmupwroff(pCKCIOCTL->pmuoffname,ENABLE);			
								}
								
								ioctl_delay(100);
								if(pCKCIOCTL->fbusname == CLKCTRL5)
								{
									tca_ckc_setswreset(CLKCTRL6,OFF);							
									tca_ckc_setswreset(CLKCTRL5,OFF);							
								}
								else
									tca_ckc_setswreset(pCKCIOCTL->fbusname,OFF);							
							}
						#endif
							{
								//validFlag = 0;
								for(i = 0; i < FBUS_STEP_NUM; i++)
								{
									if(pCKCIOCTL->fbusfreq == FbusStepValue[i] ||  pCKCIOCTL->fbusfreq == 3300000)
									{
										validFlag = 1;
										break;
									}
								}
								
								if( validFlag == 1)
								{
									if(i <= 12)
									{
										if((i%2) == 1)
											pCKCIOCTL->fbussource = DIRECTPLL2;
										else
											pCKCIOCTL->fbussource = DIRECTPLL3;
									}
									else
									{
										if(i >= FBUS_STEP_NUM-3)
										{
											pCKCIOCTL->fbussource = DIRECTXIN;
										}
										else if(i == (FBUS_STEP_NUM-4))
										{
											pCKCIOCTL->fbussource = DIRECTPLL2;
										}
										else
										{
											if((i%2) == 1)
												pCKCIOCTL->fbussource = DIRECTPLL3;
											else
												pCKCIOCTL->fbussource = DIRECTPLL2;
										}
									}		
								}
							}
							
							if( validFlag == 1)
							{
								pCKCIOCTL->fbusenable = ENABLE;
								pCKCIOCTL->mode = NORMAL_MD;
								tca_ckc_setfbusctrl(pCKCIOCTL->fbusname,pCKCIOCTL->fbusenable,pCKCIOCTL->mode,pCKCIOCTL->fbusfreq,pCKCIOCTL->fbussource);					
							}	
						
						}
					}
				}
			int_restore();			
			#if defined(MAX_FGRP_EN)
				}
			#endif			
			break;
		case IOCTL_CKC_SET_CHANGEMEM:
		{
				PLCDC	pLCDC_BASE0 = (PLCDC)(OALPAtoVA((unsigned int)&HwLCDC0_BASE,FALSE));
				PLCDC	pLCDC_BASE1 = (PLCDC)(OALPAtoVA((unsigned int)&HwLCDC1_BASE,FALSE));
				
				PTIMER	pTIMER	= (PTIMER)(OALPAtoVA((unsigned int)&HwTMR_BASE,FALSE));
				
				OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_CHANGEMEM\r\n"));
				busvalue = pCKCIOCTL->busvalue;
				
			int_alldisable();
				// Off LCD
				pLCDC_BASE1->LCTRL &= ~Hw0;
				pLCDC_BASE0->LCTRL &= ~Hw0;
				
				pTIMER->TC32EN &= ~Hw24;

				retstack = arm_changestack();

				OALCleanDCache();
				OALFlushICache();

				//init_copychangeclock(pCKCIOCTL->busvalue);
				init_copychangeclock(busvalue);
				arm_restorestack(retstack);
				pTIMER->TC32EN |= Hw24;

				//	LCDC Power Up
				pLCDC_BASE0->LCTRL |= Hw0;
				pLCDC_BASE1->LCTRL |= Hw0;
			int_restore();	
			}						
			break;
		case IOCTL_CKC_SET_CHANGECPU:
			{
				OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_CHANGECPU\r\n"));
			int_alldisable();
			OALCleanDCache();
			OALFlushICache();
			
				for(i = 0; i < FCORE_STEP_NUM; i++)
				{
					if(pCKCIOCTL->cpuvalue == FcoreStepValue[i])
					{
						validFlag = 1;
						break;
					}
				}
				
				if( validFlag == 1)
				{
					// Change pll
					if(tca_ckc_getpll(0) != FcorePllValue[i])
						tca_ckc_setpll(FcorePllValue[i],0);
					
					tca_ckc_setcpu(FcoreDividerValue[i]);
				}

			int_restore();				
			}
		
			break;
			
		case IOCTL_CKC_SET_DDIPWDN:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_DDIPWDN\r\n"));
			tca_ckc_setddipwdn(pCKCIOCTL->ddipdname, pCKCIOCTL->mode);
			break;

		case IOCTL_CKC_GET_DDIPWDN:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_DDIPWDN\r\n"));
			pCKCINFO->retVal = tca_ckc_getddipwdn(pCKCIOCTL->ddipdname);
			break;

		case IOCTL_CKC_SET_ETCBLOCK:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_ETCBLOCK\r\n"));
			ckc_etcblock(pCKCIOCTL->etcblock);
			break;
		case IOCTL_CKC_SET_VIDEOCFGPWDN:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_VIDEOCFGPWDN\r\n"));
			tca_ckc_setvideobuscfgpwdn(pCKCIOCTL->videobuscfgname,pCKCIOCTL->mode );
			break;
		case IOCTL_CKC_GET_VIDEOCFGPWDN:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_GET_VIDEOCFGPWDN\r\n"));
			pCKCINFO->state = tca_ckc_getvideobuscfgpwdn(pCKCIOCTL->videobuscfgname);
			break;

		case IOCTL_CKC_SET_VIDEOCFGSWRESET:
			OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_SET_VIDEOCFGSWRESET\r\n"));
			  tca_ckc_setvideobuscfgswreset(pCKCIOCTL->videobuscfgname,pCKCIOCTL->mode );
			break;

		default :		
			  OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]IOCTL_CKC_default\r\n"));
			  break;
			
	}
	
	return TRUE;
}
