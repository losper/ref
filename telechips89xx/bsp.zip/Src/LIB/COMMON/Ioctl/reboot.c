/****************************************************************************
*   FileName    : intr.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/
#include <bsp.h>


PPMU pPMU;
PIOBUSCFG pIOBUSCFG;

/************************************************************************************************
* FUNCTION		:  OALIoCtlHalReboot
*
* DESCRIPTION	: Implements the OALIoCtlHalReboot handler.
*
************************************************************************************************/
BOOL OALIoCtlHalReboot(UINT32 code, VOID *pInpBuffer, 
                       UINT32 inpSize, VOID *pOutBuffer, 
                       UINT32 outSize, UINT32 *pOutSize)
{
	pPMU= (PPMU)(OALPAtoVA((unsigned int)&HwPMU_BASE,FALSE));
	pIOBUSCFG= (PIOBUSCFG)(OALPAtoVA((unsigned int)&HwIOBUSCFG_BASE,FALSE));
//	pPMU = (PPMU)(((unsigned int)&HwPMU_BASE)&0xBFFFFFFF);
//	pIOBUSCFG = (PIOBUSCFG)(((unsigned int)&HwIOBUSCFG_BASE)&0xBFFFFFFF);

	pIOBUSCFG->HCLKEN0 = -1;
	pIOBUSCFG->HCLKEN1 = -1;
	
	 while(1)
	 {
	 	pPMU->WATCHDOG = (Hw31+0x1);
	 };  
	

    return(TRUE);
}
