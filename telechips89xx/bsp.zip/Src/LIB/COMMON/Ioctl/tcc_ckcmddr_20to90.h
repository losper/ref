
#if defined(_LINUX_)
    #include <bsp.h>
    #include "../../../../../../bootloader/tcboot/include/ddr.h"
#else
#include "windows.h"

#include "bsp.h"
#include "tca_ckc.h"
#endif

#if defined(DRAM_MDDR)
extern void init_clockchange7Mhz(void);
extern void init_clockchange8Mhz(void);
extern void init_clockchange9Mhz(void);
extern void init_clockchange10Mhz(void);
extern void init_clockchange11Mhz(void);
extern void init_clockchange12Mhz(void);
extern void init_clockchange14Mhz(void);
extern void init_clockchange18Mhz(void);
extern void init_clockchange20Mhz(void);
extern void init_clockchange22Mhz(void);
extern void init_clockchange25Mhz(void);
extern void init_clockchange30Mhz(void);
extern void init_clockchange35Mhz(void);
extern void  init_clockchange40Mhz(void);
extern void init_clockchange45Mhz(void);
extern void init_clockchange50Mhz(void);
extern void init_clockchange55Mhz(void);
extern void init_clockchange60Mhz(void);
extern void init_clockchange65Mhz(void);
extern void init_clockchange70Mhz(void);
extern void init_clockchange75Mhz(void);
extern void init_clockchange80Mhz(void);
extern void init_clockchange85Mhz(void);
extern void init_clockchange90Mhz(void);
extern void init_clockchange95Mhz(void);
#endif

