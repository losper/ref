#include "tcc_ckcmddr_100to160.h"


#define MDDR_SETRP(x)  (x>3? (((x-3)<<3)| x ) : ((0<<3) | x))
#define MDDR_SETRCD(x) (x>3? (((x-3)<<3)| x ) : ((0<<3) | x))
#define MDDR_SETRFC(x) (x>3? (((x-3)<<5)| x ) : ((0<<5) | x))

#if defined(DRAM_MDDR)
#define DRAM_AUTOPD_ENABLE Hw13
#define DRAM_AUTOPD_PERIOD 4<<7 // must larger than CAS latency
#define DRAM_SET_AUTOPD DRAM_AUTOPD_ENABLE|DRAM_AUTOPD_PERIOD
#if defined(_LINUX_)
	#define addr(b) (0xF0000000+b)
#else
	#if defined(DRAM_SIZE_512)
		#define addr(b) (0xBF000000+b)
	#else
		#define addr(b) (0xB0000000+b)
	#endif
#endif

//141Mhz
void init_clockchange100Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00006403;		// pms - pllout_400M
	*(volatile unsigned long *)addr(0x400024)= 0x80006403;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 5; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 6; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(10); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange105Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00002301;		// pms - pllout_420M
	*(volatile unsigned long *)addr(0x400024)= 0x80002301;		//	pll pwr on
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 5; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 7; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(11); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
}

//145Mhz
void init_clockchange110Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00006E03;		// pms - pllout_440M
	*(volatile unsigned long *)addr(0x400024)= 0x80006E03;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 5; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 7; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(11); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange115Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00007303;		// pms - pllout_460M
	*(volatile unsigned long *)addr(0x400024)= 0x80007303;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 5; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 7; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(2); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(12); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(2); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428)=  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
						
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}
//150Mhz
void init_clockchange120Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00002801;		// pms - pllout_480M
	*(volatile unsigned long *)addr(0x400024)= 0x80002801;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 6; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 8; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(12); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange125Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00007D03;		// pms - pllout_500M
	*(volatile unsigned long *)addr(0x400024)= 0x80007D03;		//	pll pwr on
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 6; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 8; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(12); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}
//160Mhz

void init_clockchange130Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	2

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x01008203;		// pms - pllout_260M
	*(volatile unsigned long *)addr(0x400024)= 0x81008203;		//	pll pwr on
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 
	
	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 6; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 8; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(13); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 2; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange135Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00002D01;		// pms - pllout_540M
	*(volatile unsigned long *)addr(0x400024)= 0x80002D01;		//	pll pwr on
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 6; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 9; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(13); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	
	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
}


//170Mhz
void init_clockchange140Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00008C03;		// pms - pllout_560M
	*(volatile unsigned long *)addr(0x400024)= 0x80008C03;		//	pll pwr on
	
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem


//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 6; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 9; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(14); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock
	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange145Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00009103;		// pms - pllout_580M
	*(volatile unsigned long *)addr(0x400024)= 0x80009103;		//	pll pwr on
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 7; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 9; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(14); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
	
}
//150Mhz
void init_clockchange150Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	4

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00003201;		// pms - pllout_600M
	*(volatile unsigned long *)addr(0x400024)= 0x80003201;		//	pll pwr on
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 7; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 9; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(15); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
}
void init_clockchange156Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	2

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00001A01;		// pms - pllout_312M
	*(volatile unsigned long *)addr(0x400024)= 0x80001A01;		//	pll pwr on
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif					

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 7; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 10; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(15); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	


	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
	
}

void init_clockchange160Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	2

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00005003;		// pms - pllout_320M
	*(volatile unsigned long *)addr(0x400024)= 0x80005003;		// pms - pllout_320M
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif						

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 7; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 10; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(16); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}


void init_clockchange165Mhz(void)
{
		#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	2

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00003702;		// pms - pllout_330M
	*(volatile unsigned long *)addr(0x400024)= 0x80003702;		// pms - pllout_330M
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif						

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 7; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 10; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(3); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(16); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(3); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
}

void init_clockchange170Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	2

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00005503;		// pms - pllout_340M
	*(volatile unsigned long *)addr(0x400024)= 0x80005503;		// pms - pllout_340M
	//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem

	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// bit23 enable -synopt enable
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1;
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 1000

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif						

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	*(volatile unsigned long *)addr(0x301020) = 8; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 11; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(4); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(17); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(4); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 8; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
}


void init_clockchange176Mhz(void)
{
	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	2

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00005803;		// pms - pllout_352M
	*(volatile unsigned long *)addr(0x400024)= 0x80005803;		// pms - pllout_352M
	
		//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// why slow??
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1; // why pad is 3??
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 64 why 1000??

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif						

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	
	*(volatile unsigned long *)addr(0x301020) = 8; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 11; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(4); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(17); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(4); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
		*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 23; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	
	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	

	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY

}

void init_clockchange180Mhz(void)
{

	#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	2

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00001E01;		// pms - pllout_360M
	*(volatile unsigned long *)addr(0x400024)= 0x80001E01;		// pms - pllout_360M
	
		//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// why slow??
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1; // why pad is 3??
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 64 why 1000??

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif						

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	
	*(volatile unsigned long *)addr(0x301020) = 8; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 11; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(4); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(18); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(4); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 2; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
		*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 23; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	

	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif

	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
}

void init_clockchange185Mhz(void)
{

#define lchange_source 2
	#define lchange_div 4
	
	#define lmem_source 1 // 0 : PLL0 , 1 : PLL1	
	#define lmem_div	2

	
	*(volatile unsigned long *)addr(0x301004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x301004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x301000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down

	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lchange_div-1) << 4)|lchange_source); // CKC-CLKCTRL2 - Mem

	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x0000B906;		// pms - pllout_370M
	*(volatile unsigned long *)addr(0x400024)= 0x8000B906;		// pms - pllout_370M

	
		//Change MEM Source 
	*(volatile unsigned long *)addr(0x400008) = (0x00200000 | ((lmem_div-1) << 4)|lmem_source); // CKC-CLKCTRL2 - Mem
	
//Init DDR2 
#if defined(DRAM_ROW14)
	// clumn_bits=3, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x0021001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit , AP bit 10, Burst 4, 2chips
#else
	#if defined(DRAM_COL9)
	// clumn_bits=1, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210011|DRAM_SET_AUTOPD;
	#else
	// clumn_bits=2, row_bits=2, ap_bit=0, mem_burst=2,active.chips=0
	*(volatile unsigned long *)addr(0x30100C) = 0x00210012|DRAM_SET_AUTOPD;
	#endif
#endif

	*(volatile unsigned long *)addr(0x303000) |= 0x00800000;		// why slow??
	*(volatile unsigned long *)addr(0x303010) |= 0x00800000;		// bit23 enable -synopt enable

	*(volatile unsigned long *)addr(0x30104C)= 0x000002D1; // why pad is 3??
	*(volatile unsigned long *)addr(0x301010) = 0x000003E8; // refresh_prd = 64 why 1000??

#if defined(DRAM_CAS3)
	*(volatile unsigned long *)addr(0x301014) = 0x00000006; // cas_latency = 3
#else
	*(volatile unsigned long *)addr(0x301014) = 0x00000004; // cas_latency = 2
#endif						

	*(volatile unsigned long *)addr(0x30101C) = 0x00000002; // tMRD 2tck 

	//20091216-jykim
	
	*(volatile unsigned long *)addr(0x301020) = 8; // tRAS 42ns
	*(volatile unsigned long *)addr(0x301024) = 12; // tRC 60ns
	*(volatile unsigned long *)addr(0x301028) = MDDR_SETRCD(4); // tRCD 18ns
	*(volatile unsigned long *)addr(0x30102c) = MDDR_SETRFC(18); // tRFC 72ns
	*(volatile unsigned long *)addr(0x301030) = MDDR_SETRP(4); // tRP 17ns
	*(volatile unsigned long *)addr(0x301034) = 3; // tRRD 11ns
	*(volatile unsigned long *)addr(0x301038) = 3; // tWR 15ns
	*(volatile unsigned long *)addr(0x30103c) = 2; // tWTR 2tck
	
	//no data on sheet
	*(volatile unsigned long *)addr(0x301040) = 0x2; // tXP=3
	*(volatile unsigned long *)addr(0x301044) = 23; // tXSR 120ns
	*(volatile unsigned long *)addr(0x301048) = 0x00000032; // tESR=200	
	



	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	

	// 1CS
	#if defined(DRAM_SIZE_64)
	*(volatile unsigned long *)addr(0x301200)=0x000040FC; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x301200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x301200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	
		
	
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (1 << 1)	// UPDATE
						| (1 << 0);	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  (3 << 17)	// PRD_CAL
						| (0 << 16)	// PRD_CEN
						| (7 << 13)	// DRV_STR
						| (1 << 12)	// TERM_DIS
						| (2 << 9)	// ODT(PHY) value
						| (5 << 6)	// PULL UP
						| (2 << 3)	// PULL DOWN
						| (0 << 2)	// ZQ
						| (0 << 1)	// UPDATE
						| (1 << 0);	// CAL_START

	*(volatile unsigned long *)addr(0x301008) = 0x00000032; //MRS
	*(volatile unsigned long *)addr(0x301008) = 0x000a0000;//EMRS
	*(volatile unsigned long *)addr(0x301008) = 0x00080032;
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	
	*(volatile unsigned long *)addr(0x301008) = 0x00040032;	

	
	*(volatile unsigned long *)addr(0x301004)=0x00000000; // PL341_GO
	while (((*(volatile unsigned long *)addr(0x301000)) & (0x03)) != 1);	// Wait until READY
}



#endif

