#include "tcc_ckcddr2_200to290.h"

#if !defined(DRAM_MDDR)
#define DDR2_SETRCD(x) (x>3? (((x-3)<<8)| x ) : ((1<<8) | x))
#define DDR2_SETRFC(x) (x>3? (((x-3)<<8)| x ) : ((0<<8) | x))
#define DDR2_SETRP(x)  (x>3? (((x-3)<<8)| x ) : ((1<<8) | x))

#define DRAM_AUTOPD_ENABLE Hw13
#define DRAM_AUTOPD_PERIOD 7<<7 // must larger than CAS latency
#define DRAM_SET_AUTOPD DRAM_AUTOPD_ENABLE|DRAM_AUTOPD_PERIOD
#if defined(_LINUX_)
	#define addr(b) (0xF0000000+b)
#else
	#if defined(DRAM_SIZE_512)
		#define addr(b) (0xBF000000+b)
	#else
		#define addr(b) (0xB0000000+b)
	#endif
#endif

//200Mhz
void init_clockchange200Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		

	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00006403;		// pms - pllout_400M
	*(volatile unsigned long *)addr(0x400024)= 0x80006403;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 1560; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x000002BC; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 9; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 12; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(4); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(21); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(26); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(4); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 2; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 3; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 2; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 23; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 28; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif
	
	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008)= 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080562; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080552; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080462; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008)= 0x00080452; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//210Mhz
void init_clockchange210Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00002301;		// pms - pllout_420M
	*(volatile unsigned long *)addr(0x400024)= 0x80002301;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 1638; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x00000325; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 10; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 13; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(4); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(23); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(27); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(4); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 4; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 2; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 25; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 29; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW
	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428)=  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428)=  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428)=  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428)=  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080762; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080752; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080662; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080652; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//220Mhz
void init_clockchange220Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00006E03;		// pms - pllout_440M
	*(volatile unsigned long *)addr(0x400024)= 0x80006E03;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 1716; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x00000325; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 10; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 14; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(4); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(24); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(28); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(4); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 4; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 2; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 26; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 31; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW
	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080762; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080752; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080662; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080652; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//230Mhz
void init_clockchange230Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00007303;		// pms - pllout_460M
	*(volatile unsigned long *)addr(0x400024)= 0x80007303;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 1794; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x00000325; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 11; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 14; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(4); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(25); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(30); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(4); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 4; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 2; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 27; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 32; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW
	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080762; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080752; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080662; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080652; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//240Mhz
void init_clockchange240Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00002801;		// pms - pllout_480M
	*(volatile unsigned long *)addr(0x400024)= 0x80002801;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 1872; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x00000348; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 11; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 15; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(4); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(26); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(31); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(4); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 4; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 2; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 28; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 33; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW
	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080762; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080752; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6) // MRS
	*(volatile unsigned long *)addr(0x302008) = 0x00080662; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080652; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF) // EMRS1

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//250Mhz
void init_clockchange250Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00007D03;		// pms - pllout_500M
	*(volatile unsigned long *)addr(0x400024)= 0x80007D03;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 1950; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x0000036B; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 12; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 15; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(4); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(27); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(32); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(4); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 4; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 2; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 29; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 35; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW
	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080762; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080752; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080662; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080652; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

//260Mhz
void init_clockchange260Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00008203;		// pms - pllout_520M
	*(volatile unsigned long *)addr(0x400024)= 0x80008203;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 0x00000445; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x0000038E; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 12; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 16; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(4); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(28); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(34); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(4); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 4; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 2; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 30; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 36; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW

	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080762; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080752; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080662; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008)= 0x00080652; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}


//270Mhz
void init_clockchange270Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00002D01;		// pms - pllout_540M
	*(volatile unsigned long *)addr(0x400024)= 0x80002D01;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 2106; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x000003B0; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 13; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 17; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(5); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(29); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(35); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(5); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 5; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 3; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 32; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 37; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW

	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080962; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080952; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}

#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x302008) = 0x00080862; 	// Direct COmmnad Register 
#else
		*(volatile unsigned long *)addr(0x302008) = 0x00080852; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}


//280Mhz
void init_clockchange280Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00008C03;		// pms - pllout_560M
	*(volatile unsigned long *)addr(0x400024)= 0x80008C03;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem
//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 2184; 	// refresh 
//	*(volatile unsigned long *)addr(0x302010) = 0x000003D4; 	// refresh 
	
#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 13; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 17; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(5); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(30); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(36); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(5); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 5; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 3; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 33; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 39; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW

	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
		*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
		*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080962; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080952; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 

	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080862; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080852; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}



//290Mhz
void init_clockchange290Mhz(void)
{
	volatile unsigned int i = 0;	

//Enter Mode		
	*(volatile unsigned long *)addr(0x302004) = 0x00000003; 		// PL341_PAUSE
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=2); //Wait PL34X_STATUS_PAUSED

	*(volatile unsigned long *)addr(0x302004) = 0x00000004; 		// PL341_Configure
	while (((*(volatile unsigned long *)addr(0x302000)) & 0x3)!=0); //Wait PL34X_STATUS_CONFIG

// DLL OFF
	*(volatile unsigned long *)addr(0x304404) &=  ~(0x00000003);	// DLL-0FF,DLL-Stop running
	*(volatile unsigned long *)addr(0x304428) &= ~(0x00000003); 	// Calibration Start,Update Calibration
	*(volatile unsigned long *)addr(0x30302C) &=  ~(0x00004000);	//SDRAM IO Control Register Gatein Signal Power Down
		
	*(volatile unsigned long *)addr(0x400030) = 0x01010101;
	*(volatile unsigned long *)addr(0x400034) = 0x01010101;
	
	*(volatile unsigned long *)addr(0x400008) = 0x00200014; 		// XI - memebus
	
	//PLL1
	*(volatile unsigned long *)addr(0x400024)= 0x0000fa03;		// pll pwr off
	*(volatile unsigned long *)addr(0x400024)= 0x00009103;		// pms - pllout_580M
	*(volatile unsigned long *)addr(0x400024)= 0x80009103;		//	pll pwr on
	*(volatile unsigned long *)addr(0x400008) = 0x00200011; // CKC-CLKCTRL2 - Mem

	//Init DDR2 
// memory arb.
	*(volatile unsigned long *)addr(0x30200C) |= 0x00140000|DRAM_SET_AUTOPD; 
// memory arb. end
	
#if defined(DRAM_ROW14)
	// ELPIDA
	*(volatile unsigned long *)addr(0x30200C) = 0x0015001A|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#else
	// Samsung/ Hynix	
	*(volatile unsigned long *)addr(0x30200C) = 0x00150012|DRAM_SET_AUTOPD; 		// config0 cas 10bit, ras 13bit
#endif
	*(volatile unsigned long *)addr(0x302010) = 2262; 	// refresh 
	//*(volatile unsigned long *)addr(0x302010) = 0x000003F7; 	// refresh 

#if defined(DRAM_BANK3)
	*(volatile unsigned long *)addr(0x30204c)=0x00000571; // config2 - SOC
#else
	*(volatile unsigned long *)addr(0x30204c)=0x00000541; // config2 - SOC
#endif		
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302014) = 0x0000000C; 	// cas_latency - 5
#else
	*(volatile unsigned long *)addr(0x302014) = 0x0000000A; 	// cas_latency - 5
#endif		
			
	*(volatile unsigned long *)addr(0x30201c) = 0x00000003; 		// tMRD

	*(volatile unsigned long *)addr(0x302020) = 14; 			// tRAS - 45ns
	*(volatile unsigned long *)addr(0x302024) = 18; 			// tRC	- 60ns
	*(volatile unsigned long *)addr(0x302028) = DDR2_SETRCD(5); // tRCD - 15ns
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(31); // tRFC - 105ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x30202c) = DDR2_SETRFC(37); // tRFC - 127.5ns
	#endif	
	*(volatile unsigned long *)addr(0x302030) = DDR2_SETRP(5); // tRP	- 15ns
	*(volatile unsigned long *)addr(0x302034) = 3; 			// tRRD - 10ns
	*(volatile unsigned long *)addr(0x302038) = 5; 			// tWR - 15ns
	*(volatile unsigned long *)addr(0x30203c) = 3; 			// tWTR - 7.5ns
	*(volatile unsigned long *)addr(0x302040) = 3; 		// tXP - min 2tCK
	#if defined(DRAM_TYPE1) || defined(DRAM_TYPE2) || defined(DRAM_TYPE6)
	*(volatile unsigned long *)addr(0x302044) = 34; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	#if defined(DRAM_TYPE3) || defined(DRAM_TYPE4) || defined(DRAM_TYPE10)
	*(volatile unsigned long *)addr(0x302044) = 40; 	// tXSR - tXSNR : tRFC+10ns
	#endif
	*(volatile unsigned long *)addr(0x302048) = 200; 	// tESR - tXSRD (200 tCK)
	*(volatile unsigned long *)addr(0x302054) = 0x00001619; 	// tFAW

	// 1CS
	#if defined(DRAM_SIZE_128)
	*(volatile unsigned long *)addr(0x302200)=0x000040F8; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_256)
	*(volatile unsigned long *)addr(0x302200)=0x000040F0; // config_chip0 - CS0 - 0x40000000~0x47ffffff
	#endif
	#if defined(DRAM_SIZE_512)
	*(volatile unsigned long *)addr(0x302200)=0x000040E0; // config_chip0 -
	#endif

	*(volatile unsigned long *)addr(0x30302C) |= 0x00004000; 		// SSTL SDRAM IO Control Register 
	
#if defined(DRAM_ROW14)
	*(volatile unsigned long *)addr(0x303020)=0x00010107; // emccfg_config0
#else
	*(volatile unsigned long *)addr(0x303020)=0x00010103; // emccfg_config0
#endif
	*(volatile unsigned long *)addr(0x303024) = 0x00000000; 		// SDRAM PHY Control Register 
	*(volatile unsigned long *)addr(0x304400) = 0x00000000; 		// DDR2PHY_PHYMODE
	*(volatile unsigned long *)addr(0x304404) = 0x00000001; 		// DLLCTRL
	
	*(volatile unsigned long *)addr(0x304408) = 0x00001717; 	// DLLPDCFG
		
	*(volatile unsigned long *)addr(0x304404) = 0x00000003; 		// DLLCTRL
	while (((*(volatile unsigned long *)addr(0x304404)) & (0x00000018)) != (0x00000018)); // Wait DLL Lock

	*(volatile unsigned long *)addr(0x304424) = 0x00000035; 		// DLLFORCELOCK
	*(volatile unsigned long *)addr(0x30440C) = 0x00000006; 		// GATECTRL
	#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x304430)=0x00000006; // RDDELAY - SOC
	#else
	*(volatile unsigned long *)addr(0x304430)=0x00000005; // RDDELAY - SOC
	#endif
	
	
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif
	
	while (!((*(volatile unsigned long *)addr(0x30442c)) & (1)));	// Wait until Calibration completion without error
	#if defined(DRAM_ODTOFF)
	*(volatile unsigned long *)addr(0x304428) =  0x0006f553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006f551;	// CAL_START
	#else
	*(volatile unsigned long *)addr(0x304428) =  0x0006E553;	// CAL_START
	*(volatile unsigned long *)addr(0x304428) =  0x0006E551;	// CAL_START
	#endif

	*(volatile unsigned long *)addr(0x302008) = 0x000c0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00040000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000a0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x000b0000; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090000; 		// Direct COmmnad Register	  
	
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080962; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080952; 	// Direct COmmnad Register 
#endif
		
	*(volatile unsigned long *)addr(0x302008) = 0x00000000; 		// Direct COmmnad Register 
	i = 4;
	while(i)
	{
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		*(volatile unsigned long *)addr(0x302008)=0x00040000; // dir_cmd
		i--;
	}
#if defined(DRAM_CAS6)
	*(volatile unsigned long *)addr(0x302008) = 0x00080862; 	// Direct COmmnad Register 
#else
	*(volatile unsigned long *)addr(0x302008) = 0x00080852; 	// Direct COmmnad Register 
#endif

#if defined(DRAM_ODTOFF)

#else
	*(volatile unsigned long *)addr(0x302008) = 0x00090380; 		// Direct COmmnad Register 
	*(volatile unsigned long *)addr(0x302008) = 0x00090004; 		// Direct COmmnad Register //soc1-3
#endif


	*(volatile unsigned long *)addr(0x302004) = 0x00000000; 		// PL341_GO
}

#endif
