#if defined(_LINUX_)
    #include <bsp.h>
    #include "../../../../../../bootloader/tcboot/include/ddr.h"
#else
    #include "windows.h"
    
    #include "bsp.h"
    #include "tca_ckc.h"
#endif


#if !defined(DRAM_MDDR)

extern void init_clockchange200Mhz(void);
extern void init_clockchange210Mhz(void);
extern void init_clockchange220Mhz(void);
extern void init_clockchange230Mhz(void);
extern void init_clockchange240Mhz(void);
extern void init_clockchange250Mhz(void);
extern void init_clockchange260Mhz(void);
extern void init_clockchange270Mhz(void);
extern void init_clockchange280Mhz(void);
extern void init_clockchange290Mhz(void);
#endif
