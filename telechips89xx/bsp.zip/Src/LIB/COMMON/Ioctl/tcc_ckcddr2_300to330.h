#if defined(_LINUX_)
    #include <bsp.h>
    #include "../../../../../../bootloader/tcboot/include/ddr.h"
#else
    #include "windows.h"
    
    #include "bsp.h"
    #include "tca_ckc.h"
#endif


#if !defined(DRAM_MDDR)

extern void init_clockchange300Mhz(void);
extern void init_clockchange312Mhz(void);
extern void init_clockchange320Mhz(void);
extern void init_clockchange330Mhz(void);
#endif

