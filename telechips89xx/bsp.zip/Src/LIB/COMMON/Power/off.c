/****************************************************************************
*   FileName    : intr.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/
#include <bsp.h>
#include "tcc_off.h"


static void OEMInitializeSystemTimer(UINT32 msecPerSysTick, UINT32 countsPerMSec, UINT32 countsMargin)
{
	
}


//------------------------------------------------------------------------------
//
// Function:     OEMPowerOff
//
// Description:  Called when the system is to transition to it's lowest  power mode (off)
//
//

BOOL Init_PMWKUP(void)
{
	PGPIO gpio_vaddr;
	PRTC rtc_vaddr; 
	PPIC pic_vaddr;

	OALMSG(1 , (L"Set_PMWKUP\r\n"));	
	rtc_vaddr = (PRTC)OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE);
	pic_vaddr = (PPIC)OALPAtoVA((unsigned int)&HwPIC_BASE,FALSE);
	gpio_vaddr = (PGPIO)OALPAtoVA((unsigned int)&HwGPIO_BASE,FALSE);
	tcc_alarm_setpmwkup(rtc_vaddr,pic_vaddr);
	return TRUE;
}

BOOL Exit_PMWKUP(void)
{
	PGPIO gpio_vaddr;
	PRTC rtc_vaddr; 
	PPIC pic_vaddr;

	OALMSG(1 , (L"Clear_PMWKUP\r\n"));	
	rtc_vaddr = (PRTC)OALPAtoVA((unsigned int)&HwRTC_BASE,FALSE);
	pic_vaddr = (PPIC)OALPAtoVA((unsigned int)&HwPIC_BASE,FALSE);
	gpio_vaddr = (PGPIO)OALPAtoVA((unsigned int)&HwGPIO_BASE,FALSE);
	tcc_alarm_clrpmwkup(rtc_vaddr,pic_vaddr);
	return TRUE;
}

void OEMPowerOff()
{
	PGPIO pGpio = (PGPIO)OALPAtoVA((unsigned int)&HwGPIO_BASE,FALSE);
	ptSYSTEM_PARAM pSysparam = (unsigned long*)OALPAtoVA(SYSTEM_PARAM_BASEADDRESS,FALSE);
	if(pSysparam->POWER_KEY ==PWRCTL_SUSPEND ){
		//Init_PMWKUP();//	rtc pmwakeup test
		OALMSG(1, (L"tcc_off_entersuspend\r\n"));
		tcc_off_entersuspend((unsigned int)pGpio);
		OALMSG(1, (L"tcc_off_exitsuspend\r\n"));		
		//Exit_PMWKUP();
	}
	else if(pSysparam->POWER_KEY ==PWRCTL_SLEEP ){
		OALMSG(1, (L"tcc_off_entersleep \r\n"));		
		tcc_off_entersleep((unsigned int)pGpio);
	}
	else{
		OALMSG(1, (L"Invalid Operation\r\n"));
	}
}

