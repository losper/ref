/****************************************************************************
*   FileName    : intr.c
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/
#include <bsp.h>
#include <intr.h>

#define ENABLE_TCC_IDLE

// Global Handle
PPIC pPIC;
PVIC pVIC;

//------------------------------------------------------------------------------
//
//  Function:  OALIntrInit
//
//  This function initialize interrupt mapping, hardware and call platform
//  specific initialization.
//
BOOL OALIntrInit()
{

	BOOL rc = FALSE;

	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]+OALIntrInit()\r\n"));

	//reset interrupt 
	pPIC = (PPIC)(OALPAtoVA((unsigned int)&HwPIC_BASE,FALSE));
	pVIC = (PVIC)(OALPAtoVA((unsigned int)&HwVIC_BASE,FALSE));
	
	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]PIC:%x, VIC:%x (%x)\r\n", pPIC, pVIC));

	//clear IEN Field
	BITCLR(pPIC->IEN0 , 0xFFFFFFFF); // All Interrupt Disable
	BITCLR(pPIC->IEN1 , 0xFFFFFFFF); // All Interrupt Disable

	//clear SEL Field
	BITSET(pPIC->SEL0 , 0xFFFFFFFF); //using IRQ
	BITSET(pPIC->SEL1 , 0xFFFFFFFF); //using IRQ

	//clear TIG Field
	BITCLR(pPIC->TIG0 , 0xFFFFFFFF); //Test Interrupt Disable
	BITCLR(pPIC->TIG1 , 0xFFFFFFFF); //Test Interrupt Disable

	//clear POL Field
	BITCLR(pPIC->POL0 , 0xFFFFFFFF); //Default ACTIVE Low
	BITCLR(pPIC->POL1 , 0xFFFFFFFF); //Default ACTIVE Low

	//clear MODE Field
	BITSET(pPIC->MODE0 , 0xFFFFFFFF); //Trigger Mode - Level Trigger Mode
	BITSET(pPIC->MODE1 , 0xFFFFFFFF); //Trigger Mode - Level Trigger Mode

	//clear SYNC Field
	BITSET(pPIC->SYNC0 , 0xFFFFFFFF); //SYNC Enable
	BITSET(pPIC->SYNC1 , 0xFFFFFFFF); //SYNC Enable

	//clear WKEN Field
	BITCLR(pPIC->WKEN0 , 0xFFFFFFFF); //Wakeup all disable
	BITCLR(pPIC->WKEN1 , 0xFFFFFFFF); //Wakeup all disable

	//celar MODEA Field
	BITCLR(pPIC->MODEA0 , 0xFFFFFFFF); //both edge - all disable
	BITCLR(pPIC->MODEA1 , 0xFFFFFFFF); //both edge - all disable

	//clear INTMSK Field
	BITCLR(pPIC->INTMSK0 , 0xFFFFFFFF); //not using INTMSK
	BITCLR(pPIC->INTMSK1 , 0xFFFFFFFF); //not using INTMSK

	//clear ALLMSK Field
	BITCSET(pPIC->ALLMSK , 0xFFFFFFFF, 0x1); //using only IRQ
#ifndef _USING_POLLING_
	BITCSET(pVIC->PRIO0, Hw16-Hw0, Hw0); // Using TC1(Hw1) Top Priority 
#endif
	OALIntrMapInit();
#ifdef OAL_BSP_CALLBACKS
	// Give BSP change to initialize subordinate controller
	rc = BSPIntrInit();
#else
	rc = TRUE;
#endif

	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]-OALIntrInit()\r\n"));
	return rc;
}


//------------------------------------------------------------------------------
//
//  Function:  OALIntrRequestIrqs
//
//  This function returns IRQs for CPU/SoC devices based on their
//  physical address.
//
BOOL OALIntrRequestIrqs(DEVICE_LOCATION *pDevLoc, UINT32 *pCount, UINT32 *pIrqs)
{
	BOOL rc = FALSE;

	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]+OALIntrRequestIrqs(0x%08x->%d/%d/0x%08x/%d, 0x%08x, 0x%08x)\r\n",
				pDevLoc, pDevLoc->IfcType, pDevLoc->BusNumber, pDevLoc->LogicalLoc,
				pDevLoc->Pin, pCount, pIrqs));

	// This shouldn't happen
	if (*pCount < 1) goto cleanUp;

#ifdef OAL_BSP_CALLBACKS
	rc = BSPIntrRequestIrqs(pDevLoc, pCount, pIrqs);
#endif

cleanUp:

	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]-OALIntrRequestIrqs(rc = %d)\r\n", rc));
	return rc;
}


//------------------------------------------------------------------------------
//
//  Function:  OALIntrEnableIrqs
//
BOOL OALIntrEnableIrqs(UINT32 count, const UINT32 *pIrqs)
{
	DWORD VirtualIRQ;
	BOOL bRet = TRUE;
	UINT32 i;

	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]+OALIntrEnableIrqs(%d, 0x%08x)\r\n", count, pIrqs));

	for (i = 0; i < count; i++)
	{
#ifndef OAL_BSP_CALLBACKS
		VirtualIRQ = pIrqs[i];
#else
		// Give BSP chance to enable irq on subordinate interrupt controller
		VirtualIRQ = BSPIntrEnableIrq(pIrqs[i]);
#endif

		if (VirtualIRQ == OAL_INTR_IRQ_UNDEFINED) continue;
		
	    OALMSG(TC_LOG_LEVEL(TC_DEBUG),(L"[KERNEL      ]irq:%d\r\n",pIrqs[i]));

        // Use interrupt mask register
		if(pIrqs[i] < 32)
		{
			BITSET(pPIC->IEN0 ,		1 << pIrqs[i]);
			BITSET(pPIC->INTMSK0 ,  1 << pIrqs[i]);
			BITSET(pPIC->CLR0 ,		1 << pIrqs[i]);
		}
		else
		{
			BITSET(pPIC->IEN1 ,		1 << (pIrqs[i]-32));
			BITSET(pPIC->INTMSK1 ,  1 << (pIrqs[i]-32));
			if ((pIrqs[i]-32) != (IRQ_GPSB-32)) {
				BITSET(pPIC->CLR1 ,	1 << (pIrqs[i]-32));
			}
		}
	}

	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]-OALIntrEnableIrqs(rc = %d)\r\n", bRet));

	return bRet;
}

//------------------------------------------------------------------------------
//
//  Function:  OALIntrDisableIrqs
//
VOID OALIntrDisableIrqs(UINT32 count, const UINT32 *pIrqs)
{
	UINT32 VirtualIRQ;
	UINT32 i;

	OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]+OALIntrDisableIrqs(%d, 0x%08x)\r\n", count, pIrqs));

	for (i = 0; i < count; i++)
	{
#ifndef OAL_BSP_CALLBACKS
		VirtualIRQ = pIrqs[i];
#else
		// Give BSP chance to disable irq on subordinate interrupt controller
		VirtualIRQ = BSPIntrDisableIrq(pIrqs[i]);
#endif
		if (VirtualIRQ == OAL_INTR_IRQ_UNDEFINED) continue;

		if(pIrqs[i] < 32)
		{
			BITCLR(pPIC->IEN0 ,		1 << pIrqs[i]);
			BITCLR(pPIC->INTMSK0 ,  1 << pIrqs[i]);		
		}
		else
		{
			if ((pIrqs[i]-32) != (IRQ_GPSB-32)) {
				BITCLR(pPIC->IEN1 ,		1 << (pIrqs[i]-32));
				BITCLR(pPIC->INTMSK1 ,  1 << (pIrqs[i]-32));
			}
		}
	}

	OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]-OALIntrDisableIrqs\r\n"));
}

//------------------------------------------------------------------------------
//
//  Function:  OALIntrDoneIrqs
//
VOID OALIntrDoneIrqs(UINT32 count, const UINT32 *pIrqs)
{
	UINT32 VirtualIRQ;
	UINT32 i;

	OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]+OALIntrDoneIrqs(%d, 0x%08x)\r\n", count, pIrqs));

	for (i = 0; i < count; i++)
	{
#ifndef OAL_BSP_CALLBACKS
		VirtualIRQ = pIrqs[i];
#else
		// Give BSP chance to finish irq on subordinate interrupt controller
		VirtualIRQ = BSPIntrDoneIrq(pIrqs[i]);
#endif

		if(pIrqs[i] < 32)
		{
			BITSET(pPIC->INTMSK0 ,  1 << pIrqs[i]);		
		}
		else
		{
			BITSET(pPIC->INTMSK1 ,  1 << (pIrqs[i]-32));
		}
	}

	OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]-OALIntrDoneIrqs\r\n"));
}

//------------------------------------------------------------------------------
//
//  Function:  OEMInterruptHandler
//
ULONG OEMInterruptHandler(ULONG ra)
{
	UINT32 SysIntr = SYSINTR_NOP;
	DWORD i=0;
	volatile DWORD dwVNIRQ = pVIC->VNIRQ;
	OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]Intr Occur\r\n"));

				
	#ifdef ENABLE_TCC_IDLE
	TCC_OEMIDLE_OFF();
	#endif


	if(dwVNIRQ & Hw31)
	{ //invalid Interrupt Occur
		OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]Invalid Interrupt Occur (%x) \r\n",pVIC->VNIRQ &0x7F));
		return SysIntr;
	}
	else
	{ 
#ifdef _USING_POLLING_
		UINT32 dwMasked;
		// valid Interrupt Occur
		//check Timer Interrupt - Timer Interrupt TOP MOST Priority

		if(pPIC->MIRQ0 & (Hw1)) //Timer1 Interrupt using Timer Interrupt
		{
			OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]Timer Interrupt\r\n"));
			BITSET(pPIC->CLR0, Hw1);
			SysIntr = OALTimerIntrHandler();
	
		}
		else
		{
			for( i=0; i < 64; i++)
			{
				if(i < 32)
				{
					if(1 == i) //Timer Interrupt must be not set control
						continue;

					dwMasked = pPIC->MIRQ0 & (1<<i);
					if( dwMasked)
					{
						OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]==========%d==========\r\n",i));
						
						if(i != 29){
							BITCLR(pPIC->INTMSK0 ,  1 << i);
						}
						BITSET(pPIC->CLR0,		1 << i);
						
						SysIntr = NKCallIntChain((UCHAR)i);
						OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]SysIntr %d\r\n",SysIntr));
		
						if (SysIntr == SYSINTR_CHAIN || !NKIsSysIntrValid(SysIntr)) {
							SysIntr = OALIntrTranslateIrq(i);
							
						}
						break;
					}
				}
				else
				{
					dwMasked = pPIC->MIRQ1 & (1<<(i-32));
					if( dwMasked)
					{
						OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]==========%d==========\r\n",i));
						BITCLR(pPIC->INTMSK1 ,  1 << (i-32));
						BITSET(pPIC->CLR1,		1 << (i-32));
						SysIntr = NKCallIntChain((UCHAR)i);
						if (SysIntr == SYSINTR_CHAIN || !NKIsSysIntrValid(SysIntr)) {
							SysIntr = OALIntrTranslateIrq(i);
						}
						break;
					}
				}

				
			}//end for
		}
#else

	{ //Intr Occur
	
		switch(dwVNIRQ & 0x7F)
		{
		case 1:
			{
				BITSET(pPIC->CLR0, Hw1);
				SysIntr = OALTimerIntrHandler();
			}
			break;
		default:
			{
				OALMSG(TC_LOG_LEVEL(TC_DEBUG), (L"[KERNEL      ]Intr Occur[%x]\r\n",(dwVNIRQ & 0x7F)));
				if (((dwVNIRQ & 0x7F)<32) && ( pPIC->MIRQ0 & (1<<(dwVNIRQ & 0x7F))))
				{
					if (((dwVNIRQ & 0x7F) != 29) && ((dwVNIRQ & 0x7F) != 0))
					{
						BITCLR(pPIC->INTMSK0 ,  1 << (dwVNIRQ & 0x7F));
					}
					BITSET(pPIC->CLR0,	1 <<(dwVNIRQ & 0x7F));
				}
				else if (((dwVNIRQ & 0x7F)>=32) && ( pPIC->MIRQ1 & (1<<((dwVNIRQ & 0x7F)-32))))
				{
					if (((dwVNIRQ & 0x7F)-32) != (IRQ_GPSB-32))
					{
						BITCLR(pPIC->INTMSK1, 1 << ((dwVNIRQ & 0x7F)-32));
					}
					BITSET(pPIC->CLR1, 1 << ((dwVNIRQ & 0x7F)-32));
				}
				else
				{
					OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]Invalid Interrupt %d\r\n",(dwVNIRQ & 0x7F)));
					return SysIntr;
				}
				{
					SysIntr = NKCallIntChain((UCHAR)(dwVNIRQ & 0x7F));
					OALMSG(TC_LOG_LEVEL(TC_DEBUG),  (L"[KERNEL      ]SysIntr %d\r\n",SysIntr));

					if (SysIntr == SYSINTR_CHAIN || !NKIsSysIntrValid(SysIntr)) {
						SysIntr = OALIntrTranslateIrq((dwVNIRQ & 0x7F));

					}
				}

			}
			break;
		}
	}
#endif
	}

	return SysIntr;	
}
