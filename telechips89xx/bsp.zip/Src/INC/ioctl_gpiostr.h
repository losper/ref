/****************************************************************************
 *	 FileName	 : ioctl_gpiostr.h
 *	 Description : 
 ****************************************************************************
*
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
*
 ****************************************************************************/


/************************************************************************************************
*									 Revision History											*
*																								*
* Version : 1.0    : 2009, 2, 04																*
************************************************************************************************/

#ifndef __IOCTL_GPIOSTR_H__
#define __IOCTL_GPIOSTR_H__


#include "bsp.h"

// For CKC Controller
typedef struct _stgpioioctl{
	unsigned int ioctlcode;
	unsigned int iphysicalbaseaddress;
	unsigned int ivirtualbaseaddress;
//	unsigned int isize;
}stgpioioctl;


typedef struct _stgpioinfo{
	unsigned int returnaddress;
	unsigned int returnstatus;
}stgpioinfo;

#endif /* __IOCTL_STR_H__ */

