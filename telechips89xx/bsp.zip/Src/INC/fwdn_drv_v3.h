/****************************************************************************
 *   FileName    : Fwdn_drv_v3.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#ifndef _FWDN_DRV_V3_H_
#define _FWDN_DRV_V3_H_

#if defined(_LINUX_)
#include <tnftl/nand_drv.h>
#elif defined(_WINCE_)
#include "nand_drv.h"
#endif

enum
{
	ERR_FWDN_DRV_WRONG_PARAMETER = 0x10000000,
	ERR_FWDN_DRV_DISK_IOCTRL_DEV_INITIALIZE,
	ERR_FWDN_DRV_DISK_COMPARE,
	ERR_FWDN_DRV_DISK_WRITE,
	ERR_FWDN_DRV_DISK_READ,
};

enum
{
	FWDN_DRV_TARGET_NAND = 1,
	FWDN_DRV_TARGET_NOR,
	FWDN_DRV_TARGET_TRIFLASH,
	FWDN_DRV_TARGET_EEPROM,
	FWDN_DRV_TARGET_SFLASH,
	FWDN_DRV_TARGET_HDD
};

enum
{
	FWDN_DISK_NONE,
	FWDN_DISK_HDD,
	FWDN_DISK_MMC,
	FWDN_DISK_UHP,
	FWDN_DISK_NAND,
	FWDN_DISK_TRIFLASH,
	FWDN_DISK_NOR,
	FWDN_DISK_SFLASH,
	FWDN_DISK_MAX
};

enum
{
	SN_NOT_EXIST = 0,
	SN_VALID_16,
	SN_INVALID_16,
	SN_VALID_32,
	SN_INVALID_32
};


typedef int (*fpFWDN_DRV_FirmwareWrite_ReadFromHost)(unsigned char *buff, unsigned int size, unsigned int srcAddr, unsigned int percent);
typedef int (*FXN_FWDN_DRV_RquestData)(unsigned char *buff, unsigned int size);
typedef unsigned int (*FXN_FWDN_DRV_ReadFromHost)(void *buff, unsigned int size);
typedef unsigned int (*FXN_FWDN_DRV_SendToHost)(void *buff, unsigned int size);

typedef struct	 _tag_DeviceInfoType {
	unsigned int		DefaultDiskType;		// Default Disk Type. nand, tri-flash, hdd ...
	unsigned int		DevSerialNumberType;	// Device Serial Number type SN_NOT_EXIST..
	unsigned char		DevSerialNumber[32];
} FWDN_DEVICE_INFORMATION, *pFWDN_DEVICE_INFORMATION;

typedef struct	 _tag_NAND_HiddenSizeInfo {
	unsigned int				HiddenPageSize;			// Default Hidden Area Pages
	unsigned int				MultiHiddenAreaNum;		// Multi Hidden Num	
	unsigned int 				MultiHiddenSize[8];		// Multi Hidden Configuration
	unsigned int				ROAreaSize;
} NAND_HIDDEN_INFO, *pNAND_HIDDEN_INFO;

typedef struct _tag_NAND_DISK_INFO_T {
	unsigned int	bootSize_MB;
	unsigned int	totalSize_MB;
	unsigned int	multiHiddenSystemSize_MB;
} NAND_DISK_INFO_T;

typedef	struct	__NAND_DeviceInfo {
	unsigned short int	DevID[8];
	unsigned int		MediaNums;			// Media Number of NANDFLASH
	unsigned int		MAX_ROMSize;
	unsigned int		ExtendedPartitionNum;
	unsigned int		ExtPartitionSize[12];
	unsigned int		ExtPartitionWCacheNum[12];
	unsigned int		ROAreaSize;
	unsigned short int  		PBpV;				// Physical all Block Number
	unsigned short int  		PpB;				// Page Number Per Block
	unsigned short int  		PageSize;			// Page Size
	unsigned short int  SpareSize;		
} NAND_DEVICE_INFO, *pNAND_DEVICE_INFO;

#ifdef TRIFLASH_INCLUDE
#define MMC_DISK_MAX_HIDDEN_NUMBER		4

typedef struct _tag_MMC_DISK_INFO_T {
        unsigned int    nTotalSector;
        unsigned int    nBootSector;
        unsigned int    nHiddenNum;
        unsigned int    nHiddenSector[MMC_DISK_MAX_HIDDEN_NUMBER];
        unsigned int    nBytePerSector;
} MMC_DISK_INFO_T;
#endif
//==============================================================
//
//		Global Variables
//
//==============================================================
extern FWDN_DEVICE_INFORMATION		FWDN_DeviceInformation;
extern unsigned int					gFWDN_DRV_ErrorCode;

#define FWDN_DRV_GetErrorCode()		gFWDN_DRV_ErrorCode
#define FWDN_DRV_ClearErrorCode()	gFWDN_DRV_ErrorCode = 0
#define FWDN_DRV_SetErrorCode(a)	gFWDN_DRV_ErrorCode = a

//==============================================================
//
//		Function Prototypes
//
//==============================================================
void						initSourcePosition(void);
int							setSourcePosition(int offset);

void						FWDN_InitCACHE(void);
void						FWDN_SetRWSize(unsigned long uSize);

void						FWDN_DRV_SaveSdCfg(unsigned int sdCfg);
unsigned int				FWDN_DRV_GetSdCfg(void);
pFWDN_DEVICE_INFORMATION	FWDN_DRV_GetDeviceInfo(void);
int							FWDN_DRV_SerialNumberWrite(unsigned char *serial, unsigned int overwrite);
int							FWDN_DRV_FirmwareWrite(unsigned int fwSize, unsigned int TargetMemType, fpFWDN_DRV_FirmwareWrite_ReadFromHost fFWDN_DRV_FirmwareWrite_ReadFromHost);
int							FWDN_DRV_FirmwareWrite_Read(unsigned char *buff, unsigned int size, unsigned int percent);

void						FWDN_DRV_DISK_Select(unsigned char fwdnDiskType);
int							FWDN_DRV_DISK_Init(TNFTL_CALLBACK_HANDLER pCallBackHandler, unsigned int stage, void *pInfo, unsigned short infoSize);
void						FWDN_DRV_DISK_InfoRead(void *pDiskInfo, unsigned char *pSize);

int							FWDN_DRV_DISK_Read(unsigned int lba, unsigned int size, FXN_FWDN_DRV_SendToHost fxnFwdnDrvSendToHost);
int							FWDN_DRV_DISK_Write(unsigned int lba, unsigned int size, FXN_FWDN_DRV_ReadFromHost fxnFwdnDrvReadFromHost);

void						FWDN_DRV_DISK_Hidden_InfoRead(void *pInfo, unsigned char *pSize);
int							FWDN_DRV_DISK_Hidden_Clean(void);
int							FWDN_DRV_DISK_Hidden_Write(unsigned int index, unsigned int startpage, unsigned int sizebyte, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData);
int							FWDN_DRV_DISK_MTD_Write(unsigned int startpage, unsigned int sizebyte, FXN_FWDN_DRV_ReadFromHost fxnFwdnDrvReadFromHost);

int							FWDN_DRV_DISK_DATA_Partition(void *pMultiPartitionSizeArray, unsigned int length);
int							FWDN_DRV_DISK_DATA_Image_Write(unsigned int nPartitionID, unsigned int offset, unsigned int size, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData);
int							FWDN_DRV_DISK_FS_Mount(unsigned int partID);
int							FWDN_DRV_DISK_FS_Format(unsigned int partID, char *volumeParam);
int							FWDN_DRV_DISK_FS_MkDir(unsigned char *name);
int							FWDN_DRV_DISK_FS_ChDir(unsigned char *name);
int							FWDN_DRV_DISK_FS_FileWrite(unsigned char *name, unsigned int size, FXN_FWDN_DRV_RquestData fxnFwdnDrvRequestData);

unsigned char				FWDN_DRV_DISK_DUMP_InfoRead(unsigned char *pBuf);
int							FWDN_DRV_DISK_DUMP_BlockRead(unsigned int Param0, unsigned int Param1, unsigned int Param2, FXN_FWDN_DRV_SendToHost fxnFwdnDrvSendToHost);

unsigned int				FWDN_FNT_SetSN(unsigned char* ucTempData, unsigned int uiSNOffset);
void						FWDN_FNT_VerifySN(unsigned char* ucTempData, unsigned int uiSNOffset);
void						FWDN_FNT_InsertSN(unsigned char *pSerialNumber);
unsigned char				FWDN_DRV_FirmwareMemoryType(void);
#endif	// _FWDN_DRV_H_

/* end of file */

