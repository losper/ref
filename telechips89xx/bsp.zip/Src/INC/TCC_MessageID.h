/****************************************************************************
 *   FileName    : TCC_MessageID.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCC_MESSAGEID_H__
#define __TCC_MESSAGEID_H__

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

//WM_APP through 0xBFFF Messages available for use by applications. 
//0xC000 through 0xFFFF String messages for use by applications. 

/*******************************************
         Message ID For User Application
********************************************/
// Power Button
#define	WM_TCC_SLEEP			(WM_APP+ 1)
#define	WM_TCC_SUSPEND			(WM_APP+ 2)
/*
// SD/MMC
#define	WM_TCC_SD_INSERT		(WM_APP+11)
#define	WM_TCC_SD_REMOVE		(WM_APP+12)

// UMS
#define	WM_TCC_UMS_WORKING		(WM_APP+21)
#define	WM_TCC_UMS_IDLE			(WM_APP+22)
#define	WM_TCC_USB_CONNECTED	(WM_APP+23)
#define	WM_TCC_USB_DISCONNECTED	(WM_APP+24)
*/
#ifdef __cplusplus
}
#endif

#endif /* __TCC_MESSAGEID_H__ */