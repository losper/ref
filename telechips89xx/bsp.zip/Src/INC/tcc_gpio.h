/****************************************************************************
*   FileName    : tcc_gpio.h
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/

/****************************************************************************
*	FileName	: tca_gpio.c
*	Description : 
****************************************************************************
*
*	TCC Version : 1.0
*	Copyright (c) Telechips, Inc.
*	ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/
#ifndef __TCC_GPIO_H__
#define __TCC_GPIO_H__

#include <bsp.h>

/************************************************************************************************
* Global Defines
************************************************************************************************/

/************************************************************************************************
* FUNCTION		: int tcc_getvirtualaddress()
*
* DESCRIPTION	: 
*
************************************************************************************************/
//unsigned int tcc_allocbaseaddress(unsigned int iphysicalbaseaddress, unsigned int isize)
unsigned int tcc_allocbaseaddress(unsigned int iphysicalbaseaddress)
{
	int retVal = -1;

	stgpioioctl stGPIO;
	stgpioinfo	stGPIOInfo;
	unsigned long	returnedbyte;

	stGPIO.ioctlcode = IOCTL_GPIO_PATOVA;
	stGPIO.iphysicalbaseaddress = iphysicalbaseaddress;
//	stGPIO.isize = isize;

	retVal = KernelIoControl(IOCTL_HAL_TCCGPIO, &stGPIO, sizeof(stgpioioctl), &stGPIOInfo, sizeof(stgpioinfo), &returnedbyte);

	return stGPIOInfo.returnaddress;
}

/************************************************************************************************
* FUNCTION		: int tca_getvirtualaddress()
*
* DESCRIPTION	: 
*
************************************************************************************************/
#if 0
unsigned int tcc_freebaseaddress(unsigned int ivirtualbaseaddress, unsigned int  isize)
{
	/*
	int retVal = -1;
	
	stgpioioctl stGPIO;
	stgpioinfo	stGPIOInfo;
	unsigned long	returnedbyte;
	
	stGPIO.ioctlcode = IOCTL_GPIO_FREEBASE;
	stGPIO.ivirtualbaseaddress = ivirtualbaseaddress;
	stGPIO.isize = isize;
	
	retVal = KernelIoControl(IOCTL_HAL_TCCGPIO, &stGPIO, sizeof(stgpioioctl), &stGPIOInfo, sizeof(stgpioinfo), &returnedbyte);
	
	return stGPIOInfo.returnstatus;
	*/
	return TRUE;
}
#endif

/************************************************************************************************
* FUNCTION		: int tca_getvirtualaddress()
*
* DESCRIPTION	: 
*
************************************************************************************************/
unsigned int tcc_setchangemode(void * devhandle, char * pbuffer, unsigned int isize)
{
	
	//return tca_setchangemode( devhandle, pbuffer, isize);
	//TO DO
	return TRUE;
}

#endif // __TCC_GPIO_H__