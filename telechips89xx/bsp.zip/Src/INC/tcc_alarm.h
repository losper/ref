
/****************************************************************************
 *	 FileName	 : tcc_alarm.h
 *	 Description : 
 ****************************************************************************
 *
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#ifndef __TCC_ALARAM_H__
#define __TCC_ALARAM_H__

#ifdef __cplusplus
extern 
"C" { 
#endif

/*****************************************************************************
* Function Name : tcc_alarm_settime()
******************************************************************************/
void tcc_alarm_settime(unsigned int devbaseaddresss, void *pTime);
/************************************************************************************************
* FUNCTION		:  tcc_alarm_setint
* DESCRIPTION	: 
************************************************************************************************/
void tcc_alarm_setint(unsigned int devbaseaddresss);
/************************************************************************************************
* FUNCTION		:  tca_alarm_setpmwkup
* DESCRIPTION	: 
************************************************************************************************/
void tcc_alarm_setpmwkup(unsigned int rtcbaseaddresss,unsigned int vicbaseaddresss);
#ifdef __cplusplus
 } 
#endif

#endif //__TCC_ALARAM_H__

