/****************************************************************************
 *	 FileName	 : tcc_cifdriver.h
 *	 Description : 
 ****************************************************************************
 *
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef _TCCCIFDRIVER_H_
#define _TCCCIFDRIVER_H_

#ifdef __cplusplus
extern "C" {
#endif
void tcc_cif_portopen(void *pCIFRegAddr, void *pGPIORegAddr, void *pCKCRegAddr, void *pDDICONFIGRegAddr);
void tcc_cif_portclose(void *pGPIORegAddr, void *pCKCRegAddr, void *pDDICONFIGRegAddr);
void tcc_cif_onoff_new(void *pCIFRegAddr, void *pCKCRegAddr, void *pGPIORegAddr, void *pDDICONFIGRegAddr, unsigned int uiControl);
int	tcc_cif_opstart(void *pCIFRegAddr, void *pGPIORegAddr , unsigned int mode, unsigned int cam_mod);
void tcc_cif_opstop(void *pCIFRegAddr, void *pGPIORegAddr);
void tcc_cif_opresume(void *pCIFRegAddr, void *pGPIORegAddr, unsigned int cam_mod);
void tcc_cif_getcapturedframe(void *pCIFRegAddr, void *pGPIORegAddr);
void tcc_cif_set_info(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiBypass, unsigned int uiBypassBusSel, unsigned int uiColorPattern, unsigned int uiPatternFormat, unsigned int uiRGBMode, unsigned int uiRGBBitMode, unsigned int uiColorSequence, unsigned int uiBusOrder);
void tcc_cif_set_ctrl(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiSkipFrame, unsigned int uiM420);
void tcc_cif_set_transfer(void *pCIFRegAddr, unsigned int uiFlag, unsigned int uiTransMode, unsigned int uiBurst, unsigned int uiLock);
void tcc_cif_sync_pol(void *pCIFRegAddr, unsigned int uiHPolarity, unsigned int uiVpolarity);
void tcc_cif_set_img(void *pCIFRegAddr, unsigned int uiType, unsigned int uiHsize, unsigned int uiVsize, unsigned int uiHorWindowingStart, unsigned int uiHorWindowingEnd, unsigned int uiVerWindowingStart, unsigned int uiVerWindowingEnd);
void tcc_cif_set_addr(void *pCIFRegAddr, unsigned int uiType, unsigned int uiBaseAddr0, unsigned int uiBaseAddr1, unsigned int uiBaseAddr2);
void tcc_cif_set_offset(void *pCIFRegAddr, unsigned int uiOffsetY, unsigned int uiOffsetUV);
void tcc_cif_scale(void *pCIFRegAddr, unsigned int uiScaleEnable, unsigned int uiXScale, unsigned int uiYScale);
void tcc_cif_setinterrupt(void *pCIFRegAddr, unsigned int uiFlag);
void tcc_cif_set656formatconfig(void *pCIFRegAddr, unsigned int uiType, unsigned int uiPsl, unsigned int uiFpv, unsigned int uiSpv, unsigned int uiTpv, unsigned int uiHb, unsigned int uiVb);
unsigned int tcc_cif_readfifostate(void *pCIFRegAddr, unsigned int uiType);
void tcc_cif_setencrolskipnum(void *pCIFRegAddr, unsigned int uiType, unsigned int uiEncNum, unsigned int uiRolNumV, unsigned int uiRolNumU, unsigned int uiRolNumY, unsigned int uiSkipNum, unsigned int uiVCnt);
unsigned int tcc_cif_setcapturectrl(void *pCIFRegAddr, unsigned int uiType);
void tcc_cif_seteffectinimgsize(void *pEFFECTRegAddr, unsigned int uiHSize, unsigned int uiVSize);
void tcc_cif_seteffectmode(void *pEFFECTRegAddr, unsigned int uiFlag);
void tcc_cif_setscalerctrl(void *pCIFSCALERRegAddr, unsigned int uiType);
void tcc_cif_seteffectsepiauv(void *pEFFECTRegAddr, unsigned int uiSepiaU, unsigned int uiSepiaV);
void tcc_cif_seteffectsketchclampth(void *pEFFECTRegAddr, unsigned int uiType, unsigned int uiSketch, unsigned int uiClamp);
void tcc_cif_setscalerimgsizeoffsetscale(void *pCIFSCALERRegAddr, unsigned int uiType, unsigned int uiSrcHSize, unsigned int uiSrcVSize, unsigned int uiOffH, unsigned int uiOffV, unsigned int uiDstHSize, unsigned int uiDstVSize, unsigned int uiHScale, unsigned int uiVScale);
void tcc_cif_powerupdown(void *pCKCRegAddr, int iCIFPowerOn);
#ifdef __cplusplus
	}
#endif
#endif
