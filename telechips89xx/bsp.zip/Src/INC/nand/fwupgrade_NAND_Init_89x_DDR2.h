/****************************************************************************
 *   FileName    : fwupgrade_NAND_Init_80x_DDR1.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef _FWUPGRADE_NAND_INIT_DDR_H_
#define _FWUPGRADE_NAND_INIT_DDR_H_

#if defined(_LINUX_)
#include <tnftl/tnftl_v6.h>
#elif defined(_WINCE_)
#include "tnftl_v6.h"
#else
#include "tnftl_v6.h"
#endif

#if defined(TCC89XX)||defined(TCC92XX)
#ifndef TNFTL_V6_INCLUDE
#define TNFTL_V6_INCLUDE
#endif
#endif

//*****************************************************************************
//*
//*
//*                       [ General DEFINE & TYPEDEF ]
//*
//*
//*****************************************************************************
#ifndef ON
#define ON									0x01
#endif
#ifndef OFF
#define OFF 								0x00
#endif
#ifndef DISABLE
#define DISABLE								0
#endif
#ifndef ENABLE
#define	ENABLE								1
#endif
#ifndef FALSE
#define FALSE 	          					0
#endif
#ifndef TRUE
#define TRUE            					1
#endif

//*****************************************************************************
//*
//*
//*                       [ EXTERNAL GLOBAL VARIABLE DEFINE ]
//*
//*
//*****************************************************************************




//*****************************************************************************
//*
//*
//*                         [ ERROR CODE ENUMERATION ]
//*
//*
//*****************************************************************************
#ifndef SUCCESS
#define	SUCCESS  0
#endif


//*****************************************************************************
//*
//*
//*                       [ EXTERNAL FUCTIONS DEFINE ]
//*
//*
//*****************************************************************************
extern void				InitRoutine_Start(void);
extern void 			InitRoutine_End(void);

#endif	// _FWUPGRADE_NAND_H_

/* end of file */


