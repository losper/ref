/****************************************************************************
 *   FileName    : nand_drv.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 * 
 ****************************************************************************/
#ifndef __NAND_H
#define __NAND_H

//#include "main.h"

//**********************************************************************
//*		Define NAND Driver version for ChipSet
//**********************************************************************
#if defined(NAND_BOOT_REV)
#define TNFTL_V7_INCLUDE
#else	// K-FILESYSTEM
#define TNFTL_V6_INCLUDE
#endif

//**********************************************************************
//*		Include Header
//**********************************************************************
#if defined(_LINUX_) || defined(_WINCE_)
#if defined(TNFTL_V7_INCLUDE)
#include "tnftl_v7.h"
#include "fwupgrade_NAND_v6.h"
#elif defined(TNFTL_V6_INCLUDE)
#include "tnftl_v6.h"
#include "fwupgrade_NAND_v6.h"
#endif
#endif

#if defined(USB_INCLUDE) && defined(FWDN_INCLUDE)
#ifdef TNFTL_V5_INCLUDE
#include "MASS_SCSI.h"
#include "VTC.h"
#include "Fwdn_protocol_v2.h"
#define	TNFTL_DEBUG_INCLUDE
#else
#include "fwdn_protocol.h"
#endif
#endif

//*****************************************************************************
//*
//*
//*                       [ General DEFINE & TYPEDEF ]
//*
//*
//*****************************************************************************
#ifndef DISABLE
#define DISABLE					0
#endif
#ifndef ENABLE
#define	ENABLE					1
#endif
#ifndef FALSE
#define FALSE           		0
#endif
#ifndef TRUE
#define TRUE            		1
#endif

#ifndef _U8_
#define _U8_
typedef unsigned char			U8;
#endif
#ifndef _U16_
#define _U16_
typedef unsigned short int		U16;
#endif
#ifndef _U32_
#define _U32_
typedef unsigned int			U32;
#endif
#ifndef _BOOL_
#define _BOOL_
typedef unsigned int			BOOL;
#endif

#ifndef NOT_SUPPORT_NAND
#define NOT_SUPPORT_NAND		0xFFFF
#endif

//*****************************************************************************
//*
//*
//*                         [ ERROR CODE ENUMERATION ]
//*
//*
//*****************************************************************************
#ifndef SUCCESS
#define SUCCESS		0
#endif

typedef enum
{
	ERR_NAND_FAILED_GET_DEVICE_INFO = 0xA300000,
	ERR_NAND_INIT_FAILED,
	ERR_NAND_WRONG_PARAMETER
} NAND_ERROR;
 
//*****************************************************************************
//*
//*
//*                          [ INTERNAL DEFINATION ]
//*
//*
//*****************************************************************************
#define MAX_NAND_DRIVE								1
#define NAND_DRV_0									0

#if defined( TNFTL_V7_INCLUDE )
	#define TNFTL_ZONE_NUM_FOR_PRIMARY_PARTITION		32
	#if defined(_LINUX_) || defined(_WINCE_)
	#define TNFTL_ZONE_NUM_FOR_EXTENDED_PARTITION		32
	#else
	#define TNFTL_ZONE_NUM_FOR_EXTENDED_PARTITION		1
	#endif
	
	#define TNFTL_WCACHE_NUM_For_PRIMARY_PARTITION		12
	#define TNFTL_WCACHE_NUM_For_EXTENDED_PARTITION		2
	
	#define TNFTL_LPT_BLK_NUM_For_PRIMARY_PARTITION		TNFTL_ZONE_NUM_FOR_PRIMARY_PARTITION
	#define TNFTL_LPT_BLK_NUM_For_EXTENDED_PARTITION	TNFTL_ZONE_NUM_FOR_EXTENDED_PARTITION
	
	#if defined(_LINUX_) || defined(_WINCE_)
	#define TNFTL_EXTENDED_PARTITION_MAX_NUM			4
	#define TNFTL_EXTENDED_PARTITION_NUM				1
	#define TNFTL_EXTENDED_PARTITION_SIZE_MB			1
	#else
	#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
	#define TNFTL_EXTENDED_PARTITION_MAX_NUM			1
	#define TNFTL_EXTENDED_PARTITION_NUM				1
	#else
	#define TNFTL_EXTENDED_PARTITION_MAX_NUM			1
	#define TNFTL_EXTENDED_PARTITION_NUM				0
	#endif
	#endif
#else 
	#define TNFTL_ZONE_NUM_FOR_DATA_AREA				32
	#if defined(_LINUX_) || defined(_WINCE_)
	#define TNFTL_ZONE_NUM_FOR_HIDDEN_AREA				32
	#else
	#define TNFTL_ZONE_NUM_FOR_HIDDEN_AREA				1
	#endif
	
	#if defined( TNFTL_V5_INCLUDE ) || defined(TNFTL_V6_INCLUDE)
	#define TNFTL_WCACHE_NUM_For_DATA_AREA				12
	#else
	#define TNFTL_WCACHE_NUM_For_DATA_AREA				8
	#endif
	#define TNFTL_WCACHE_NUM_For_HIDDEN_AREA			2
	
	#define TNFTL_LPT_BLK_NUM_For_DATA_AREA				TNFTL_ZONE_NUM_FOR_DATA_AREA
	#define TNFTL_LPT_BLK_NUM_For_HIDDEN_AREA			TNFTL_ZONE_NUM_FOR_HIDDEN_AREA
	
	#if defined(_LINUX_) || defined(_WINCE_)
	#define TNFTL_MULTI_HIDDEN_AREA_MAX_NUM				3
	#define TNFTL_MULTI_HIDDEN_AREA_NUM					3
	#define INTERNAL_HIDDEN_STORAGE_SIZE_MB				1
	#else
	#ifdef INTERNAL_HIDDEN_STORAGE_INCLUDE
	#define TNFTL_MULTI_HIDDEN_AREA_MAX_NUM				1
	#define TNFTL_MULTI_HIDDEN_AREA_NUM					1
	#else
	#define TNFTL_MULTI_HIDDEN_AREA_MAX_NUM				1
	#define TNFTL_MULTI_HIDDEN_AREA_NUM					0
	#endif
	#endif
#endif

#define NAND_DRVINFO_SAVE								0
#define NAND_DRVINFO_LOAD								1

//===========================================================
//
//	Common
//
//===========================================================
#define NAND_TYPE_PURE_NAND							0
#define NAND_TYPE_LBA_NAND							1

#define TNFTL_MAX_SUPPORT_RCACHE_MEMORY_SIZE		32768
#define TNFTL_MAX_SUPPORT_ALIGNCACHE_MEMORY_SIZE	32768					

#define	MAX_ROMSIZE_NAND							0x200000

#define NAND_HIDDEN_DEFAULT_TOTAL_PAGESIZE			4096
#define NAND_HIDDEN_DRIVE_DEFAULT_TOTAL_SECTOR_SIZE	((2*1024*1024UL)/512UL)

#define	MAX_ROMSIZE_NAND							0x200000

#define TCC_NAND_TRACE_ALL           0x0F
#define TCC_NAND_TRACE_DRV_WRITE     0x01
#define TCC_NAND_TRACE_DRV_READ      0x02
#define TCC_NAND_TRACE_DRV_ALL       0x03
#define TCC_NAND_TRACE_TNFTL_ALL     0x07
#define TCC_NAND_TRACE_OFF           0x00

//*****************************************************************************
//*
//*
//*                       [ INTERNAL STRUCT DEFINE ]
//*
//*
//*****************************************************************************
typedef struct __tag_NAND_DrvInfo
{
	unsigned short int			DrvStatus;			// Status of Drive
	
	unsigned long int			TotalDiskSector;	// Total Disk Sector
	unsigned short int			Cylinder;
	unsigned short int			Head;
	unsigned char				Sector;

	TNFTL_DRVINFO				*NFTLDrvInfo;		// NFTL Driver
} NAND_DRVINFO;

#if defined( TNFTL_V7_INCLUDE )
typedef	struct	__tag_TNFTL_ExtPartitionSizeInfo
{
	unsigned int				ExtendedPartitionNum;
	unsigned int				ExtPartitionSize[12];
	unsigned int				ROAreaSize;						
} TNFTL_EXT_PART_INFO;
#else
typedef	struct	__tag_TNFTL_HiddenSizeInfo
{
	unsigned int				HiddenPageSize;	// Default Hidden Area Pages
	unsigned int				MultiHiddenAreaNum;		// Multi Hidden Num	
	unsigned int 				MultiHiddenSize[8];	// Multi Hidden Configuration
	unsigned int				ROAreaSize;
} TNFTL_HIDDEN_INFO;
#endif					

#if defined( TNFTL_V7_INCLUDE )
//*****************************************************************************
//*
//*
//*                       [ EXTERNAL VARIABLE DEFINE ]
//*
//*
//*****************************************************************************
extern NAND_DRVINFO				gNAND_DrvInfo[MAX_NAND_DRIVE];
extern TNFTL_EXT_PART_INFO		gTNFTL_ExtPartitionInfo[MAX_NAND_DRIVE];
extern NAND_IO_DEVINFO*  gLBA_DevInfo[4];
#else
extern NAND_DRVINFO				gNAND_DrvInfo[MAX_NAND_DRIVE];
extern TNFTL_HIDDEN_INFO		gTNFTL_HiddenInfo[MAX_NAND_DRIVE];
extern NAND_IO_DEVINFO*  gLBA_DevInfo[4];
#endif

//*****************************************************************************
//*
//*
//*                       [ EXTERNAL FUCTIONS DEFINE ]
//*
//*
//*****************************************************************************
extern void			NAND_Init( void );
extern void 		NAND_InitHiddenInfo( void );
extern void 		NAND_SetFlagOfChangeAreaSize( unsigned char On_Off );
extern int			NAND_LowLevelFormat( int mode );

extern NAND_ERROR	NAND_InitDrive( int nDrvNo );

extern int			NAND_ReadSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nReadBuffer );
extern int			NAND_WriteSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nWriteBuffer );
extern int			NAND_HDReadPage( U32 nHDPageAddr, U32 nPageSize, void* nReadBuffer );
extern int			NAND_HDWritePage( U32 nHDPageAddr, U32 nPageSize, void* nWriteBuffer );
extern int 			NAND_PhyReadPage( U32 nBlkAddr, U16 nPageAddr, U16 nCSorder, void* nReadBuffer );
extern int			NAND_Ioctl( int function, void *param );

extern int			NAND_ReadMultiSectorStart( U32 LBA, U32 nSecSize );
extern int			NAND_ReadMultiSectorStop( void );
extern int			NAND_WriteMultiSectorStart( U32 LBA, U32 nSecSize );
extern int			NAND_WriteMultiSectorStop( void );
extern int			NAND_HDClearPages( U32 nHDStPageAddr, U32 nHDEdPageAddr );

extern int 			NAND_ReadSectorIRQ( int nDrvNo, ndd_work_info* nand_work_info );
extern int 			NAND_WriteSectorIRQ( int nDrvNo, ndd_work_info* nand_work_info );
extern int			NAND_HDReadSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nReadBuffer );
extern int			NAND_HDWriteSector( int nDrvNo, U32 LBA, U32 nSecSize, void* nWriteBuffer );
extern int			NAND_HDIoctl( int function, void *param );

extern U16			NAND_GetSerialNumber( U8* rSerialNumber, U16 nSize );
extern U16			NAND_GetUniqueID( U8* rSerialNumber, U16 nSize );
extern TNFTL_ERROR	NAND_SetUartDebug( unsigned int on_off );
#endif

