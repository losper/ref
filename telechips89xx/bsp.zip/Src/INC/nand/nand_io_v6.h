/**************************************************************************************
 *
 * TELECHIPS Co.
 * 
 * 6th floor Corad Bldg 1000-12 Daechi-dong, KangNam-ku, Seoul, Korea
 * ====================================================================================
 *
 * Name:        Hyun-Chul Hong
 * Phone:       82-2-3443-6792
 * E-mail:      hchong@telechips.com
 *
 * FILE NAME:   NAND_IO.H
 *
 * DESCRIPTION:
 *       This is a Header File for NANDFLASH IO Interface 
 *
 *
 * FILE HISTORY:
 * 	Date: 2005.04.19	Start source coding		By Hyunchul Hong
 *
 **************************************************************************************/
#ifndef __NAND_IO_H
#define __NAND_IO_H

//*****************************************************************************
//*
//*
//*                       [ Specific DEFINE ]
//*
//*
//*****************************************************************************
#if defined(TCC83XX) && defined(_WINCE_)
// In the case of LINUX, it is defined config.h
#define NAND_2CS_ONLY
#define NAND_8BIT_ONLY
#else
//#define NAND_2CS_ONLY
//#define NAND_8BIT_ONLY
#endif

//**********************************************************************
//*		Define Dev Board
//**********************************************************************
//#define TCC9200S_BOARD			// TCC9200S ND_RDY: GPIO_B31
#define TCC89_92_BOARD			// TCC89/91/9200 ND_RDY: GPIO_B28 - EDI - NFC_CTRL

//**********************************************************************
//*		Define ECC Algorithm for ChipSet
//**********************************************************************
#if defined(TCC77X) || defined(TCC87XX) || defined(TCC82XX) || defined(TCC78X) || defined(TCC83XX) || defined(TCC79XX)
#define ECC_TYPE_RS
#elif defined(TCC81XX) || defined(TCC80XX) || defined(TCC92XX) || defined(TCC89XX)
#define ECC_TYPE_BCH
#endif

#if defined(USE_V_ADDRESS)
	#if defined(_LINUX_)
	#define  ND_TRACE	printk
	#elif defined(_WINCE_)
	//#define  ND_TRACE(a)		RETAILMSG(1, a)
	//#define  ND_TRACE2(a)		NKDbgPrintfW(a)
	#endif
#else
	#if defined(_LINUX_)
		#define  ND_TRACE	printf
	#elif defined(_WINCE_)
		#define  ND_TRACE	B_RETAILMSG
	#endif
#endif

//*****************************************************************************
//*
//*
//*                       [ General DEFINE & TYPEDEF ]
//*
//*
//*****************************************************************************
//===================================================================
//
//		DRIVER SIGNATURE
//
//===================================================================
#define SIGBYAHONG				'S','I','G','B','Y','A','H','O','N','G','_'

#define NAND_IO_SIGNATURE		'N','A','N','D','_','I','O','_'
#define TNFTL_SIGNATURE			'T','N','F','T','L','_'

#if defined(_WINCE_)
#define SIGN_OS					'W','I','N','C','E','_'
#elif defined(_LINUX_)
#define SIGN_OS					'L','I','N','U','X','_'
#else
#define SIGN_OS					'N','U','_'
#endif

#if defined(TCC77X)
#define SIGN_CHIPSET			'T','C','C','7','7','X','X','_'
#elif defined(TCC78X)
#define SIGN_CHIPSET			'T','C','C','7','8','X','X','_'
#elif defined(TCC79X)
#define SIGN_CHIPSET			'T','C','C','7','9','X','X','_'
#elif defined(TCC81XX)
#define SIGN_CHIPSET			'T','C','C','8','1','X','X','_'
#elif defined(TCC82XX)
#define SIGN_CHIPSET			'T','C','C','8','2','X','X','_'
#elif defined(TCC83XX)
#define SIGN_CHIPSET			'T','C','C','8','3','X','X','_'
#elif defined(TCC87XX)
#define SIGN_CHIPSET			'T','C','C','8','7','X','X','_'
#elif defined(TCC89XX)
#define SIGN_CHIPSET			'T','C','C','8','9','X','X','_'
#elif defined(TCC91XX)
#define SIGN_CHIPSET			'T','C','C','9','1','X','X','_'
#elif defined(TCC92XX)
#define SIGN_CHIPSET			'T','C','C','9','2','X','X','_'
#else
#error
#endif

#ifndef DISABLE
#define DISABLE					0
#endif
#ifndef ENABLE
#define	ENABLE					1
#endif
#ifndef FALSE
#define FALSE           		0
#endif
#ifndef TRUE
#define TRUE            		1
#endif
#ifndef NULL
#define NULL            		0
#endif

#if defined(_LINUX_)
#ifndef _U8_
#define _U8_
typedef unsigned char			U8;
#endif
#ifndef _U16_
#define _U16_
typedef unsigned short int		U16;
#endif
#ifndef _U32_
#define _U32_
typedef unsigned int			U32;
#endif
#ifndef _BOOL_
#define _BOOL_
typedef unsigned int			BOOL;
#endif
#else
#ifndef U8
typedef unsigned char			U8;
#endif
#ifndef U16
typedef unsigned short int		U16;
#endif
#ifndef U32
typedef unsigned int			U32;
#endif
#ifndef _BOOL_
typedef unsigned int			BOOL;
#endif
#endif

#ifndef DWORD_BYTE
typedef	union {
	unsigned long		DWORD;
	unsigned short int	WORD[2];
	unsigned char		BYTE[4];
} DWORD_BYTE;
#endif

#ifndef BITSET
#define	BITSET(X, MASK)				( (X) |= (U32)(MASK) )
#endif
#ifndef BITSCLR
#define	BITSCLR(X, SMASK, CMASK)	( (X) = ((((U32)(X)) | ((U32)(SMASK))) & ~((U32)(CMASK))) )
#endif
#ifndef BITCSET
#define	BITCSET(X, CMASK, SMASK)	( (X) = ((((U32)(X)) & ~((U32)(CMASK))) | ((U32)(SMASK))) )
#endif
#ifndef BITCLR
#define	BITCLR(X, MASK)				( (X) &= ~((U32)(MASK)) )
#endif
#ifndef BITXOR
#define	BITXOR(X, MASK)				( (X) ^= (U32)(MASK) )
#endif
#ifndef ISZERO
#define	ISZERO(X, MASK)				(  ! (((U32)(X)) & ((U32)(MASK))) )
#endif
#ifndef BYTE_OF
#define	BYTE_OF(X)					( *(volatile unsigned char *)(&(X)) )
#endif
#ifndef HWORD_OF
#define	HWORD_OF(X)					( *(volatile unsigned short *)(&(X)) )
#endif
#ifndef WORD_OF
#define	WORD_OF(X)					( *(volatile unsigned int *)(&(X)) )
#endif

//*****************************************************************************
//*
//*
//*                         [ ERROR CODE ENUMERATION ]
//*
//*
//*****************************************************************************
#ifndef SUCCESS
#define SUCCESS		0
#endif

typedef enum
{
	ERR_NAND_IO_FAILED_GET_DEVICE_INFO = 0xA100000,
	ERR_NAND_IO_FAILED_CORRECTION_SLC_ECC,
	ERR_NAND_IO_FAILED_CORRECTION_MLC_ECC,
	ERR_NAND_IO_FAILED_GET_SHIFT_FACTOR_FOR_MULTIPLY,
	ERR_NAND_IO_FAILED_GET_FACTORY_BAD_MARK_OF_PBLOCK,
	ERR_NAND_IO_READ_STATUS_GENERAL_FAIL,
	ERR_NAND_IO_TIME_OUT_READ_STATUS,
	ERR_NAND_IO_WRONG_PARAMETER,
	ERR_NAND_IO_WRONG_PARAMETER_ROW_COL_ADDRESS,
	ERR_NAND_IO_NOT_READY_DEVICE_IO,
	ERR_NAND_IO_FAILED_WRITE,
	ERR_NAND_IO_NOT_EXIST_LBA_HEADBLOCK,
	ERR_NAND_IO_FAILED_LBA_PARTITION_CHANGE
} NAND_IO_ERROR;
 
//*****************************************************************************
//*
//*
//*                          [ INTERNAL DEFINATION ]
//*
//*
//*****************************************************************************

/* Maker Information of supported NANDFLASH */
enum SUPPORT_MAKER_NAND
{
	SAMSUNG = 0,
	TOSHIBA,
	HYNIX,
	ST,
	MICRON,
	MAX_SUPPORT_MAKER_NAND
};

enum SUPPORT_MAKER_LBA_NAND
{
	TOSHIBA_LBA = 0,
	MAX_SUPPORT_MAKER_LBA_NAND
};

enum LBA_NAND_HIDDEN_INFO
{
		//==============================================		
		// VFP Size			[  4Byte ]	0
		// MDP Size			[  4Byte ]	1
		// Hidden Size		[  4Byte ]	2
		// Multi-Hidden Num [  4Byte ]	3
		// Multi-Hidden Size[  4Byte ]	4~10
		//==============================================
	ENUM_LBA_VFP_SECTOR_SIZE = 0,
	ENUM_LBA_MDP_SECTOR_SIZE,
	ENUM_LBA_HIDDEN_SECTOR_SIZE,
	ENUM_LBA_MULTI_HIDDEN_NUM,
	ENUM_LBA_MULTI_HIDDEN_SIZE_0,
	ENUM_LBA_MULTI_HIDDEN_SIZE_1,
	ENUM_LBA_MULTI_HIDDEN_SIZE_2,
	ENUM_LBA_MULTI_HIDDEN_SIZE_3,
	ENUM_LBA_MULTI_HIDDEN_SIZE_4,
	ENUM_LBA_MULTI_HIDDEN_SIZE_5,
	ENUM_LBA_MULTI_HIDDEN_SIZE_6,
	ENUM_LBA_MULTI_HIDDEN_SIZE_7,
	ENUM_LBA_MULTI_HIDDEN_SIZE_8,
	ENUM_LBA_MULTI_HIDDEN_SIZE_9
};

#define SAMSUNG_NAND_MAKER_ID					0xEC
#define TOSHIBA_NAND_MAKER_ID					0x98
#define HYNIX_NAND_MAKER_ID						0xAD
#define ST_NAND_MAKER_ID						0x20
#define MICRON_NAND_MAKER_ID					0x2C

#define MAX_SUPPORT_SAMSUNG_NAND				24
#define MAX_SUPPORT_TOSHIBA_NAND				16
#define MAX_SUPPORT_HYNIX_NAND					23
#define MAX_SUPPORT_ST_NAND						13
#define MAX_SUPPORT_MICRON_NAND					10
	
/* LBA NAND FLASH */
#define MAX_SUPPORT_TOSHIBA_LBA_NAND			3

/* Media Attribute */
#define A_08BIT									0x00000001		// 8Bit BUS
#define A_BIG									0x00000002		// Big Page Size
#define A_SMALL									0x00000004		// Small Page Size
#define A_16BIT									0x00000008		// 16Bit BUS
#define A_SLC									0x00000010		// Single Layer Cell
#define A_MLC									0x00000020		// Multi Layer Cell
#define A_MLC_8BIT								0x00000040		// 8Bit MLC ECC
#define A_MLC_12BIT								0x00000080		// 12Bit MLC ECC

#define A_PARALLEL								0x00000100		// Parallel Composition
#define A_DATA_WITDH_08BIT						0x00000200		// Data 8Bit Bus
#define A_DATA_WITDH_16BIT						0x00000400		// Data 16Bit Bus

#define S_NOR									0x00010000		// NORMAL [ ReadID, Reset, Read, Page Program, Block Erase, Read Status ]
#define S_CB									0x00020000		// COPY BACK
#define S_CP									0x00040000 		// CACHE PROGRAM
#define S_MP									0x00080000		// MULTI PLANE
#define S_MP2									0x00100000		// MULTI PLANE
#define S_MCP									0x00200000		// MULTI PLANE CACHE 
#define S_IL									0x00400000		// INTER LEAVE
#define S_EIL									0x00800000		// EXTERNAL INTER LEAVE 
#define S_EPW									0x01000000		// EXCEPT PARTIAL WRITE
#define S_NPW									0x02000000		// Not-Support PARTIAL WRITE
#define S_MP_READ								0x04000000		// MULTI PLANE READ
#define S_LBA									0x08000000		// LBA NAND

#define NAND_IO_MAX_SUPPORT_DRIVER				2

#define NAND_IO_SERIAL_COMBINATION_MODE			0x00
#define NAND_IO_PARALLEL_COMBINATION_MODE		0x01

#if defined(NAND_2CS_ONLY)
#define NAND_IO_DRV0_START_CS					0
#define NAND_IO_DRV0_END_CS						1
#else
#define NAND_IO_DRV0_START_CS					0
#define NAND_IO_DRV0_END_CS						3
#endif

#define	ECC_OFF                     			0
#define	ECC_ON                      			1
#define SLC_ECC_TYPE							0x0001			// 10 Byte
#define MLC_ECC_4BIT_TYPE						0x0002			// BCH: 7 Byte( 52 bit)	turn: 2, byte remain: 3, register mask: 0x0F
#define MLC_ECC_8BIT_TYPE						0x0004			// BCH:13 Byte (104 bit)	turn: 4, byte remain: 1, register mask: 0xFF
#define MLC_ECC_12BIT_TYPE						0x0010			// BCH:20 Byte (156 bit)	turn: 5, byte remain: 4, register mask: 0x0F
#define MLC_ECC_14BIT_TYPE						0x0020			// BCH:23 Byte (184 bit)	turn: 6, byte remain: 3, register mask: 0xFF
#define MLC_ECC_16BIT_TYPE						0x0040			// BCH:26 Byte (207 bit)turn: 7, byte remain: 2, register mask: 0x7F

//----------------------------------------------------------------------
// TNFTL R/W Area Spare Date
//----------------------------------------------------------------------
// Block Area & Type		1Byte :  0xFF
// Block Parameter			2Byte
// Logical Block Address	3Byte :  0x0 ~ 0xFFFFFE
//----------------------------------------------------------------------
// Spare Data Total 		6Byte
//----------------------------------------------------------------------

//----------------------------------------------------------------------
// TNFTL R/O Area Spare Date
//----------------------------------------------------------------------
// Block Area & Type		1Byte :  0xFF
// Rom Image Num			2Byte
// Rom Image LBA			3Byte :  0x0 ~ 0xFFFFFE
//----------------------------------------------------------------------
// Spare Data Total 		6Byte
//----------------------------------------------------------------------


// 512 Page + 16 Spare : SLC / 4 Bit ECC
typedef struct {
	U8		SpareData0[4];		//  4 Bytes Spare data
	U8		Temp;				//  1 Bytes Temp
	U8		BadMark;			//  1 Bytes bad mark
	U8		SpareData1[2];		//  2 Bytes Spare data
	U8		PageECC[8];			//  8 Bytes Spare ECC --> 4Bit ECC
} SLC_512Page_4BitECC_Spare;

// 2048 Page + 64 Spare : 4 Bit ECC
typedef struct {
	U8		BadMark;			//  1 Bytes bad mark
	U8		Temp;				//  1 Bytes Temp
	U8		SpareECC[10];		//  8 Bytes Spare ECC --> 4Bit ECC
	U8 		SpareData[12];		// 12 bytes Spare data
	U8 		PageECC[4][10];		// 40 Bytes Page ECC
} MLC_2KPage_4BitECC_Spare;

// 4096 Page + 128 Spare : 4 Bit ECC
typedef struct {
	U8		BadMark;			//  1 Bytes bad mark
	U8		Temp;				//  1 Bytes Temp
	U8		SpareECC[10];		// 10 Bytes Spare ECC --> 4Bit ECC 
	U8 		SpareData[20];		// 20 bytes Spare data
	U8 		PageECC[8][10];		// 80 Bytes Page ECC
} MLC_4KPage_4BitECC_Spare;

// 4096 Page + 218 Spare : 8/12 Bit ECC
typedef struct {
	U8		BadMark;			//  1 Bytes bad mark
	U8		Temp;				//  1 Bytes Temp
	U8		SpareECC[20];		// 20 Bytes Spare ECC --> 8 / 12 Bit ECC
	U8 		SpareData[36];		// 36 bytes Spare data
	U8 		PageECC[8][20];		//160 Bytes Page ECC
} MLC_4KPage_8_12BitECC_Spare;

// 8192 Page + 436 Spare : 16 Bit ECC
typedef struct {
	U8		BadMark;			//  1 Bytes bad mark
	U8		Temp;				//  1 Bytes Temp
	U8		SpareECC[8];		//  8 Bytes Spare ECC --> 4 bit ECC
	U8 		SpareData[10];		// 10 bytes Spare data
	U8 		PageECC[16][26];	//416 Bytes Page ECC
} MLC_4KPage_16BitECC_Spare;

#ifdef ECC_TYPE_RS
#define TYPE_ECC_FOR_1BIT_SLC_NANDFLASH			MLC_ECC_4BIT_TYPE
#define TYPE_ECC_FOR_4BIT_MLC_NANDFLASH			MLC_ECC_4BIT_TYPE
#define TYPE_ECC_FOR_8BIT_MLC_NANDFLASH			MLC_ECC_8BIT_TYPE
#define ECC_SHIFT_DATASIZE						16
#else
#define TYPE_ECC_FOR_1BIT_SLC_NANDFLASH			MLC_ECC_4BIT_TYPE
#define TYPE_ECC_FOR_4BIT_MLC_NANDFLASH			MLC_ECC_4BIT_TYPE
#define TYPE_ECC_FOR_8BIT_MLC_NANDFLASH			MLC_ECC_12BIT_TYPE
#define TYPE_ECC_FOR_12BIT_MLC_NANDFLASH		MLC_ECC_12BIT_TYPE
#define TYPE_ECC_FOR_14BIT_MLC_NANDFLASH		MLC_ECC_14BIT_TYPE
#define TYPE_ECC_FOR_16BIT_MLC_NANDFLASH		MLC_ECC_16BIT_TYPE
#define ECC_SHIFT_DATASIZE						4
#endif

#define TNFTL_READ_SPARE_ON						0
#define TNFTL_READ_SPARE_OFF					1

#define NAND_MCU_ACCESS							0
#define NAND_DMA_ACCESS							1

#define NAND_NORMAL_BUFFER						0
#define NAND_SERIAL_CHAIN_BUFFER				1


#define ECC_DECODE								0
#define ECC_ENCODE								1
#define	INTER_LEAVE_OFF                			0
#define	INTER_LEAVE_ON                			1
#define MULTI_PLANE_MID_PAGE					0
#define MULTI_PLANE_LAST_PAGE					1
#define MULTI_PLANE_GOOD_BLOCK					0
#define MULTI_PLANE_BAD_BLOCK					1

#define NAND_IO_BSA_OK							0x0000
#define NAND_IO_BSA_BAD_SERIAL					0x0001
#define NAND_IO_BSA_BAD_BLOCK1_PARALLEL			0x0010
#define NAND_IO_BSA_BAD_BLOCK2_PARALLEL			0x0100
#define NAND_IO_BSA_FAIL_OTHER_REASON			0x1000

#define NAND_IO_STATUS_FAIL_CS0_SERIAL			0x0001
#define NAND_IO_STATUS_FAIL_CS0_PARALLEL		0x0010
#define NAND_IO_STATUS_FAIL_CS1_PARALLEL		0x0100

#define NAND_IO_LOG_COLUMN_IN_PAGE				0
#define NAND_IO_LOG_COLUMN_IN_SPARE				1

/* LBA NAND DEFINATION : [STATUS READ 2] */
#define NAND_LBA_PNP							0x00
#define NAND_LBA_BCM							0x02
#define NAND_LBA_VFP							0x04
#define NAND_LBA_MDP							0x06

#define NAND_LBA_DATA_AREA						0x16
#define NAND_LBA_HIDDEN_AREA					0x26
#define NAND_LBA_MULTI_HIDDEN_AREA_0			0x36
#define NAND_LBA_MULTI_HIDDEN_AREA_1			0x46
#define NAND_LBA_MULTI_HIDDEN_AREA_2			0x56

#define NAND_POWER_SAVE_ENABLE					0x01
#define NAND_HIGH_SPEED_ENABLE					0x08

#define NAND_ADDRESS_OUT_OF_RANGE_ERROR			0x10
#define NAND_COMMAND_PARAMETER_ERROR			0x40

/* LBA NAND Transfer Protocol 1 */
#define NAND_PROT1_512x1						0x01
#define NAND_PROT1_512x4						0x02
#define NAND_PROT1_512x8						0x04

#define NAND_PROT1_528x1						0x21
#define NAND_PROT1_528x4						0x22
#define NAND_PROT1_528x8						0x24

#define NAND_PROT1_SPARE_INCLUDE				0x20
#define NAND_PROT1_SECTOR_COUNT_MASK			0x07

#define NAND_PROT1_NoCRC_NoECC					0x00
#define NAND_PROT1_CRC							0x40
#define NAND_PROT1_ECC_CHECK_ONLY				0x80
#define NAND_PROT1_ECC_CORRECT					0xC0

/* LBA NAND Transfer Protocol 2 */
#define NAND_PROT2_READ_TYPE_A					0x00
#define NAND_PROT2_READ_TYPE_B					0x02
#define NAND_PROT2_READ_TYPE_C					0x03

#define NAND_PROT2_WRITE_TYPE_A					0x00
#define NAND_PROT2_WRITE_TYPE_B					0x04

#define NAND_LBA_MAX_SUPPORT_MHD_AREA_NUM		10

typedef void (*NAND_LBA_CALLBACK_HANDLER) ( U16 nDrvNo, U16 nStatusCode, U32 wParam );
#define NAND_LBA_CALLBACK_LCD_FORMAT_PROCESS	0x04


/* HardWare relevant variables */
#define PAGE_ECC_OFF							0
#define PAGE_ECC_ON								1

#define NAND_IO_SPARE_SIZE_BIG					32
#define NAND_IO_SPARE_SIZE_SMALL				8

#define NAND_IO_NFC_BUS							0
#define NAND_IO_MEM_BUS							1

#define NAND_IO_DATA_WITDH_8BIT					0
#define NAND_IO_DATA_WITDH_16BIT				1

#if 0		/* 09.03.16 */
#if defined(_LINUX_) || defined(_WINCE_)
    #ifdef USE_V_ADDRESS
		#if defined(_LINUX_)
        #define	NAND_IO_HwCMD							*(volatile unsigned long*)0xF00B0000	//( gNAND_IO_pHwND->CMD )
        #define	NAND_IO_HwLADR							*(volatile unsigned long*)0xF00B0004	//( gNAND_IO_pHwND->LADR )
        #define	NAND_IO_HwDATA							*(volatile unsigned long*)0xF00B0010	//( gNAND_IO_pHwND->WDATA.D32 )
        #define	NAND_IO_HwSDATA							*(volatile unsigned long*)0xF00B0040	//(/*( gNAND_IO_DataBusType == NAND_IO_MEM_BUS ) ? gNAND_IO_pHwND->WDATA.D8 : */gNAND_IO_pHwND->SDATA.D32 )
        #define	NAND_IO_HwSADR							*(volatile unsigned long*)0xF00B000C	//( gNAND_IO_pHwND->SADR )
        #define	NAND_IO_HwECCBASEPAGE					0xF00B0010								//((unsigned)&NAND_IO_HwDATA)
		#elif defined(_WINCE_)
        #define	NAND_IO_HwCMD							*(volatile unsigned long*)0xB00B0000	//( gNAND_IO_pHwND->CMD )
        #define	NAND_IO_HwLADR							*(volatile unsigned long*)0xB00B0004	//( gNAND_IO_pHwND->LADR )
        #define	NAND_IO_HwDATA							*(volatile unsigned long*)0xB00B0010	//( gNAND_IO_pHwND->WDATA.D32 )
        #define	NAND_IO_HwSDATA							*(volatile unsigned long*)0xB00B0040	//(/*( gNAND_IO_DataBusType == NAND_IO_MEM_BUS ) ? gNAND_IO_pHwND->WDATA.D8 : */gNAND_IO_pHwND->SDATA.D32 )
        #define	NAND_IO_HwSADR							*(volatile unsigned long*)0xB00B000C	//( gNAND_IO_pHwND->SADR )
        #define	NAND_IO_HwECCBASEPAGE					0xF00B0010								//((unsigned)&NAND_IO_HwDATA)
		#endif
    #else	 // MAKEBOOTLOADER
        #define	NAND_IO_HwCMD							*(volatile unsigned long*)0xF00B0000	//( gNAND_IO_pHwND->CMD )
        #define	NAND_IO_HwLADR							*(volatile unsigned long*)0xF00B0004	//( gNAND_IO_pHwND->LADR )
        #define	NAND_IO_HwDATA							*(volatile unsigned long*)0xF00B0010	//( gNAND_IO_pHwND->WDATA.D32 )
        #define	NAND_IO_HwSDATA							*(volatile unsigned long*)0xF00B0040	//(/*( gNAND_IO_DataBusType == NAND_IO_MEM_BUS ) ? gNAND_IO_pHwND->WDATA.D8 : */gNAND_IO_pHwND->SDATA.D32 )
        #define	NAND_IO_HwSADR							*(volatile unsigned long*)0xF00B000C	//( gNAND_IO_pHwND->SADR )
        #define	NAND_IO_HwECCBASEPAGE					0xF00B0010								//((unsigned)&NAND_IO_HwDATA)
    #endif
#else
	#define	NAND_IO_HwNFC_CMD						( gNAND_IO_pHwNFC->NFC_CMD )			// 0x000  W  	NAND Flash Command Register
	#define	NAND_IO_HwNFC_LADDR						( gNAND_IO_pHwNFC->NFC_LADDR )			// 0x004  W  	NAND Flash Linear Address Register
	#define	NAND_IO_HwNFC_BADDR						( gNAND_IO_pHwNFC->NFC_BADDR )			// 0x008  W  	NAND Flash Block Address Register
	#define	NAND_IO_HwNFC_SADDR						( gNAND_IO_pHwNFC->NFC_SADDR )			// 0x00C  W  	NAND Flash Signal Address Register
	#define	NAND_IO_HwNFC_WDATA						( gNAND_IO_pHwNFC->NFC_WDATA[0] )		// 0x01x  R/W	NAND Flash Word Data Register
	#define	NAND_IO_HwNFC_LDATA						( gNAND_IO_pHwNFC->NFC_LDATA[0] )		// 0x02x/3x R/W	NAND Flash Linear Data Register
	#define	NAND_IO_HwNFC_SDATA						( gNAND_IO_pHwNFC->NFC_SDATA )			// 0x040  R/W	NAND Flash Single Data Register
	#define	NAND_IO_HwNFC_CTRL						( gNAND_IO_pHwNFC->NFC_CTRL )			// 0x050  R/W	NAND Flash Control Register
	#define	NAND_IO_HwNFC_PSTART					( gNAND_IO_pHwNFC->NFC_PSTART )			// 0x054  W  	NAND Flash Program Start Register
	#define	NAND_IO_HwNFC_RSTART 					( gNAND_IO_pHwNFC->NFC_RSTART )			// 0x058  W  	NAND Flash Read Start Register
	#define	NAND_IO_HwNFC_DSIZE						( gNAND_IO_pHwNFC->NFC_DSIZE )			// 0x05C  R/W	NAND Flash Data Size Register
	#define	NAND_IO_HwNFC_IREQ						( gNAND_IO_pHwNFC->NFC_IREQ )			// 0x060  R/W	NAND Flash Interrupt Request Register
	#define	NAND_IO_HwNFC_RST						( gNAND_IO_pHwNFC->NFC_RST )			// 0x064  W  	NAND Flash Controller Reset Register
	#define	NAND_IO_HwNFC_CTRL1						( gNAND_IO_pHwNFC->NFC_CTRL1 )			// 0x068  R/W	NAND Flash Control Register 1
	#define	NAND_IO_HwNFC_MDATA						( gNAND_IO_pHwNFC->NFC_MDATA[0] )		// 0x07x  R/W	NAND Flash Multiple Data Register	
	#define	NAND_IO_HwECCBASEPAGE					((unsigned)&NAND_IO_HwNFC_WDATA)
#endif
#endif /* 0 */


#if defined(_LINUX_) || defined(_WINCE_)
#if defined(TCC89XX) || defined(TCC92XX)
#define	NAND_IO_HwCMD_PA							*(volatile unsigned long*)0xF05B0000		//( gNAND_IO_pHwND->CMD )
#define	NAND_IO_HwLADR_PA							*(volatile unsigned long*)0xF05B0004		//( gNAND_IO_pHwND->LADR )
#define	NAND_IO_HwDATA_PA							*(volatile unsigned long*)0xF05B0010		//( gNAND_IO_pHwND->WDATA.D32 )
#define	NAND_IO_HwLDATA_PA							*(volatile unsigned long*)0xF05B0020		//( gNAND_IO_pHwND->LDATA )
#define	NAND_IO_HwSDATA_PA							*(volatile unsigned long*)0xF05B0040		//(/*( gNAND_IO_DataBusType == NAND_IO_MEM_BUS ) ? gNAND_IO_pHwND->WDATA.D8 : */gNAND_IO_pHwND->SDATA.D32 )
#define	NAND_IO_HwSADR_PA							*(volatile unsigned long*)0xF05B000C		//( gNAND_IO_pHwND->SADR )
#endif
#endif

#if defined(TCC92XX)
#define	NAND_IO_NFC_nWP							HwGPIOB->GPDAT
#define	NAND_IO_NFC_nWPBit						Hw22
#elif defined(TCC89XX)
#define	NAND_IO_NFC_nWP							HwGPIOB->GPDAT
#define	NAND_IO_NFC_nWPBit						Hw31
#endif
#define NAND_IO_STATUS_ENABLE					0x0001
#define NAND_IO_STATUS_INTERLEAVING_MASK		0x00F0
#define NAND_IO_STATUS_INTERLEAVING_CHIP1		0x0010
#define NAND_IO_STATUS_INTERLEAVING_CHIP2		0x0020
#define NAND_IO_STATUS_INTERLEAVING_CHIP3		0x0040
#define NAND_IO_STATUS_INTERLEAVING_CHIP4		0x0080

#define NAND_IO_DISTRICT_0						0x0001
#define NAND_IO_DISTRICT_1						0x0002

#define NAND_IO_DMA_WRITE						0x0001
#define NAND_IO_DMA_READ						0x0002
//*****************************************************************************
//*
//*
//*                       [ INTERNAL STRUCT DEFINE ]
//*
//*
//*****************************************************************************
typedef struct __tag_NAND_IO_ECCSizeInfo
{
	unsigned int				EncodeFlag;
	unsigned int				DecodeFlag;
	unsigned int				ErrorNum;
	unsigned char				ErrorCodeNum;		// Register Num
	unsigned char				*All_FF_512_ECC_Code;
} NAND_IO_ECC_INFO;

typedef struct __tag_NAND_IO_WriteStatus
{
	unsigned char				ChipNo;
	unsigned char				BlockStatus;
	unsigned int				ErrorPHYPageAddr;
} NAND_IO_WRITESTATUS;

typedef struct __tag_NAND_IO_BadBlockAddr
{
	unsigned char				BlockStatus[4];
	unsigned int				BadBlkPHYAddr[4];
} NAND_IO_BADBLOCK;

typedef struct __tag_NAND_IO_Cycle
{
	unsigned char				STP;
	unsigned char				PW;
	unsigned char				HLD;
	unsigned int				RegValue;
} NAND_IO_CYCLE;

typedef struct __tag_NAND_IO_DeviceCode
{
	unsigned short int			Code[6];			// Factory ID code
} NAND_IO_DEVID;

typedef struct __tag_NAND_IO_LBADevInfo
{
	unsigned char				Usable;
	
	unsigned char				CurrentMode;
	unsigned long int			CurrentSectorSize;
	
	unsigned char				HighSpeedMode;
	unsigned char				PowerSaveMode;
	unsigned char				TransProtocol1;
	unsigned char				TransProtocol2;
	unsigned char				SectorCount;
	unsigned char 				DataTransferCheck;
	unsigned char 				FlagOfChangeTotalSectorSize;

	unsigned long int			VFPSectorSize;		// NBArea
	
	unsigned long int			MDPSectorSize;		// RWArea Totla Sector Size
	unsigned long int			DTAreaSectorSize;	// RWArea
	unsigned long int			HDAreaSectorSize;	// RWArea
	unsigned long int			HDAreaAddrOffSet;

	unsigned long int 			MHDAreaNums;	// Multi Hidden Area Num
	unsigned long int			MHDAreaSectorSize[NAND_LBA_MAX_SUPPORT_MHD_AREA_NUM];
	unsigned long int			MHDAreaAddrOffSet[NAND_LBA_MAX_SUPPORT_MHD_AREA_NUM];
	
} NAND_IO_LBADEVINFO;

typedef struct __tag_NAND_IO_Feature
{
	NAND_IO_DEVID				DeviceID;			// Maker & Device ID Code
	unsigned short int  		PBpV;				// Physical all Block Number
	unsigned short int			BBpZ;				// Total Bad Block in one ZONE
	unsigned short int  		PpB;				// Page Number Per Block
	unsigned short int  		PageSize;			// Page Size
	unsigned short int  		SpareSize;			// Spare Size
	unsigned short int			ColCycle;			// Column Address Cycle
	unsigned short int			RowCycle;			// Row Address Cycle
	unsigned short int			WCtime;				// Write Cyclte time
	unsigned short int			WriteSTP;
	unsigned short int			WriteWP;
	unsigned short int			WriteHLD;
	unsigned short int			ReadSTP;
	unsigned short int			ReadPW;
	unsigned short int			ReadHLD;
	unsigned long int			MediaType;			// Chracters of NANDFLASH
} NAND_IO_FEATURE;

typedef struct __tag_NAND_IO_DevInfo
{
	NAND_IO_FEATURE				Feature;			// Feature of NANDFLASH
	unsigned short int			IoStatus;			// IO Status
	unsigned short int			ChipNo;				// ChipSelect Number
	unsigned short int			CmdMask;			// Command Mask Bit
	unsigned short int			EccType;			// Type of ECC [ SLC , MLC4 ]
	unsigned short int			EccDataSize;

	unsigned short int			PPages;				// Total Partial Page [512+16Bytes]

	unsigned short int			DistrictNum;
	unsigned short int			ShiftDistrictNum;

	unsigned short int			ExtInterleaveUsable;

	unsigned short int			ShiftPBpV;
	unsigned short int			ShiftPpB;
	unsigned short int			ShiftPageSize;
	unsigned short int			ShiftPPages;
	
	unsigned short int			PageUniteMode;
	unsigned short int			RemapPpB;			// Physical Page Number Per FTL 1Block
	unsigned short int			RemapPageOffset;	// Next FTL Block Page Offset
	unsigned short int			RemapRatioBSize;	// Physical Block Number Per FTL 1Block
	unsigned long int			RemapRatioPSize;	// Physical Block Number Per FTL 1Block
	
	unsigned short int			ShiftRemapPpB;
	unsigned short int			ShiftRemapPageOffset;
	unsigned short int			ShiftRemapRatioBSize;
	unsigned short int			ShiftRemapRatioPSize;

	unsigned long int			RemapPageWeight[4];

	NAND_IO_WRITESTATUS			WriteStatus;
		
	NAND_IO_BADBLOCK			BadBlockInfo;
	NAND_IO_LBADEVINFO			LBAInfo;
} NAND_IO_DEVINFO;

typedef struct __tag_NAND_IO_MakerInfo
{
	unsigned short int			MaxSupportNAND[MAX_SUPPORT_MAKER_NAND];
	unsigned short int			MakerID[MAX_SUPPORT_MAKER_NAND];
	NAND_IO_FEATURE*			DevInfo[MAX_SUPPORT_MAKER_NAND];
} NAND_IO_MAKERINFO;


typedef struct __tag_NAND_IO_LBAMakerInfo
{
	unsigned short int			MaxSupportNAND[MAX_SUPPORT_MAKER_LBA_NAND];
	unsigned short int			MakerID[MAX_SUPPORT_MAKER_LBA_NAND];
	NAND_IO_FEATURE*			DevInfo[MAX_SUPPORT_MAKER_LBA_NAND];
} NAND_IO_LBA_MAKERINFO;

//*****************************************************************************
//*
//*
//*                       [ EXTERNAL VARIABLE DEFINE ]
//*
//*
//*****************************************************************************
extern const NAND_IO_MAKERINFO		NAND_SupportMakerInfo;
extern const NAND_IO_LBA_MAKERINFO	LBA_NAND_SupportMakerInfo;

extern const NAND_IO_FEATURE		SAMSUNG_NAND_DevInfo[MAX_SUPPORT_SAMSUNG_NAND];
extern const NAND_IO_FEATURE		TOSHIBA_NAND_DevInfo[MAX_SUPPORT_TOSHIBA_NAND];
extern const NAND_IO_FEATURE		HYNIX_NAND_DevInfo[MAX_SUPPORT_HYNIX_NAND];
extern const NAND_IO_FEATURE		ST_NAND_DevInfo[MAX_SUPPORT_ST_NAND];
extern const NAND_IO_FEATURE		MICRON_NAND_DevInfo[MAX_SUPPORT_MICRON_NAND];

extern const NAND_IO_FEATURE		TOSHIBA_LBA_NAND_DevInfo[MAX_SUPPORT_TOSHIBA_LBA_NAND];

//*****************************************************************************
//*
//*
//*                       [ EXTERNAL FUCTIONS DEFINE ]
//*
//*
//*****************************************************************************
extern NAND_IO_ERROR		NAND_IO_CallBackChangeWCtime( unsigned short int TotalMediaNum, NAND_IO_DEVINFO *nDevInfo );
extern NAND_IO_ERROR		NAND_IO_SetCycle( NAND_IO_DEVINFO *nDevInfo );
extern NAND_IO_ERROR		NAND_IO_GetDeviceInfo( U16 nChipNo, NAND_IO_DEVINFO *nDevInfo );
extern U32					NAND_IO_GetBUSTypeOfDataIO( void );
extern void					NAND_IO_Init( void );
extern void					NAND_IO_Reset( U16 nChipNo, int nMode );
extern void					NAND_IO_ResetForReadID( U16 nChipNo, int nMode );
extern void					NAND_IO_ReadID( U16 nChipNo, NAND_IO_DEVID *nDeviceCode, int nMode );

extern NAND_IO_ERROR		NAND_IO_ReadSpare( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U8 *nSpareBuffer );
extern NAND_IO_ERROR		NAND_IO_ReadPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nReadPPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_ReadPageMTD( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nReadPPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_ReadNBPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nReadPPSize, U8 *nPageBuffer, U8 *nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_ReadTwoPlanePage(NAND_IO_DEVINFO * nDevInfo, U32 nPageAddr, U32 nSecondPageAddr, U16 nStartPPage, U16 nReadPPSize, U8 * nPageBuffer, U8 * nSpareBuffer, int nEccOnOff);
extern NAND_IO_ERROR		NAND_IO_ReadTwoPlaneLastPage(NAND_IO_DEVINFO * nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nReadPPSize, U8 * nPageBuffer, U8 * nSpareBuffer, int nEccOnOff);
extern NAND_IO_ERROR		NAND_IO_ReadUserSizePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nColumnAddr, U32 nReadSize, U8 *nReadBuffer );
extern NAND_IO_ERROR	 	NAND_IO_ReadChainPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U8 *nPageBuffer, U8 *nSpareBuffer, int nMode );
extern NAND_IO_ERROR 		NAND_IO_ReadGoldenPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U8 *nPageBuffer, U8 *nSpareBuffer );

extern NAND_IO_ERROR 		NAND_IO_WriteSpare( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U8* nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_WritePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_WritePageMTD( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR 		NAND_IO_WriteNBPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_WriteCachePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_WriteTwoPlanePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8* nSpareBuffer, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_WriteTwoPlaneLastPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nStartPPage, U16 nWritePPSize, U8 *nPageBuffer, U8* nSpareBuffer, int LastPage, int nEccOnOff );
extern NAND_IO_ERROR		NAND_IO_WriteUserSizePage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U16 nColumnAddr, U32 nWriteSize, U8 *nWriteBuffer );

extern NAND_IO_ERROR 		NAND_IO_WriteChainPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U8 *nPageBuffer, U8 *nSpareBuffer, int nMode );
extern NAND_IO_ERROR 		NAND_IO_WriteGoldenPage( NAND_IO_DEVINFO *nDevInfo, U32 nPageAddr, U8 *nPageBuffer, U8 *nSpareBuffer );

extern NAND_IO_ERROR		NAND_IO_CopyBackPage( NAND_IO_DEVINFO *nDevInfo, U32 nDesPageAddr, U32 nSrcPageAddr );
extern NAND_IO_ERROR		NAND_IO_CopyBackTwoPlanePage( NAND_IO_DEVINFO *nDevInfo, U32 nDesPageAddr, U32 nSrcPageAddr );

extern NAND_IO_ERROR		NAND_IO_EraseBlock( NAND_IO_DEVINFO *nDevInfo, U32 nBlockPageAddr, int nFormatMode );
extern NAND_IO_ERROR		NAND_IO_EraseBlockForTwoPlane( NAND_IO_DEVINFO *nDevInfo, U32 nBlockPageAddr, int nFormatMode );

extern NAND_IO_ERROR		NAND_IO_GetFactoryBadMarkOfPBlock( NAND_IO_DEVINFO *nDevInfo, U32 nBlockPageAddr );
extern NAND_IO_ERROR		NAND_IO_GetUID( NAND_IO_DEVINFO *nDevInfo, U16 *nCmd, U8 *rReadData );
extern NAND_IO_ERROR		NAND_IO_WaitBusyCheckForWriteEnd( NAND_IO_DEVINFO *nDevInfo );

extern NAND_IO_ERROR 		NAND_IO_LBA_SetCallBackHandler( NAND_LBA_CALLBACK_HANDLER pCallBackHandler );
extern U32  			    NAND_IO_LBA_GetSerialNumber( NAND_IO_DEVINFO *nDevInfo, U8* nPageBuffer, U8* rSerialNumber, U16 nSize );
extern NAND_IO_ERROR		NAND_IO_LBA_PowerSaveMode( NAND_IO_DEVINFO *nDevInfo, int nOnOff );
extern NAND_IO_ERROR 		NAND_IO_LBA_DeviceReboot( NAND_IO_DEVINFO *nDevInfo );

extern NAND_IO_ERROR 		NAND_IO_LBA_GetDeviceInfo( NAND_IO_DEVINFO *nDevInfo );
extern NAND_IO_ERROR 		NAND_IO_LBA_Init( NAND_IO_DEVINFO *nDevInfo );
extern NAND_IO_ERROR 		NAND_IO_LBA_ReadSectorBy4Byte( NAND_IO_DEVINFO *nDevInfo, U8 nPartition, U32 nSectorAddr, U16 nOffset, U16 nReadSize, U8 *nReadBuffer );
extern NAND_IO_ERROR 		NAND_IO_LBA_ReadSector( NAND_IO_DEVINFO *nDevInfo, U8 nPartition, U32 nSectorAddr, U16 nSecSize, U8 *nReadBuffer );
extern NAND_IO_ERROR 		NAND_IO_LBA_WriteSector( NAND_IO_DEVINFO *nDevInfo,U8 nPartition, U32 nSectorAddr, U16 nSecSize, U8 *nWriteBuffer );
extern NAND_IO_ERROR 		NAND_IO_LBA_AREAClear( NAND_IO_DEVINFO *nDevInfo, U8 nPartition );
extern NAND_IO_ERROR 		NAND_IO_LBA_ModeChange( NAND_IO_DEVINFO *nDevInfo, int nMode );
extern NAND_IO_ERROR 		NAND_IO_LBA_ScanHeaderOfVFP( NAND_IO_DEVINFO *nDevInfo );
extern NAND_IO_ERROR 		NAND_IO_LBA_MakeHeaderOfVFP( NAND_IO_DEVINFO *nDevInfo );
extern NAND_IO_ERROR 		NAND_IO_LBA_Read2Status( NAND_IO_DEVINFO *nDevInfo );
extern NAND_IO_ERROR 		NAND_IO_LBA_GetTotalSecAndCHS( NAND_IO_DEVINFO *nDevInfo, int nPartition, U32 *rTotalSec, U16 *rCylinder, U16 *rHead, U8 *rSector );
extern NAND_IO_ERROR 		NAND_IO_LBA_CacheFlush( NAND_IO_DEVINFO *nDevInfo );

#endif

