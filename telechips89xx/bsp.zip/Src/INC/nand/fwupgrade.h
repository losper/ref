/****************************************************************************
 *   FileName    : fwupgrade.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef _FWUPGRADE_H_
#define _FWUPGRADE_H_

//#include "main.h"
//**********************************************************************
//*		Define FWUG Library version for ChipSet
//**********************************************************************
#if defined(NU_FILE_INCLUDE)
	#if defined(TCC78X)
	#define FWUG_V1_INCLUDE
	#else
	#define FWUG_V2_INCLUDE
	#endif
#else	/* K-FILESYSTEM */
	#define FWUG_V2_INCLUDE
#endif

//*****************************************************************************
//*
//*
//*                       [ General DEFINE & TYPEDEF ]
//*
//*
//*****************************************************************************
#ifndef ON
#define ON							0x01
#endif
#ifndef OFF
#define OFF 						0x00
#endif
#ifndef DISABLE
#define DISABLE						0
#endif
#ifndef ENABLE
#define	ENABLE						1
#endif


#ifndef U8
typedef unsigned char				U8;
#endif
#ifndef U16
typedef unsigned short int			U16;
#endif
#ifndef U32
typedef unsigned int				U32;
#endif

enum
{
	FIRST = 0,
	SECOND,
	REPETITIONNUM	
};

//*****************************************************************************
//*
//*
//*                         [ ERROR CODE ENUMERATION ]
//*
//*
//*****************************************************************************
#ifndef SUCCESS
#define	SUCCESS  0
#endif

typedef enum
{
	ERR_FWUG_NOT_EXISTMEMORY = 0x1000,
	ERR_FWUG_FAIL_OPENROMFILE,
	ERR_FWUG_FAIL_CLOSEROMFILE,	
	ERR_FWUG_FAIL_READROMFILE,
	ERR_FWUG_CANCEL_FWUPGRADE,
	ERR_FWUG_FAIL_BATCHECK,
	ERR_FWUG_FAIL_ROMFILESIZEBIG,
	ERR_FWUG_FAIL_GETGOODBLOCKLIST,
	ERR_FWUG_NOT_EXISTSERIALNUM,
	ERR_FWUG_FAIL_GMCDATAWRITE,
	ERR_FWUG_FAIL_GMCSPAREWRITE,
	ERR_FWUG_FAIL_CODEDATAWRITE,
	ERR_FWUG_FAIL_CODESPAREWRITE,
	ERR_FWUG_FAIL_MCDATAWRITE,
	ERR_FWUG_FAIL_MCSPAREWRITE,
	ERR_FWUG_FAIL_FWUPGRADE,
	ERR_FWUG_FAIL_CHECK_TFLASH,
	ERR_FWUG_FAIL_SCAN_TFLASH,
	ERR_FWUG_FAIL_CODEWRITETFLASH,
	ERR_FWUG_FAIL_CODEREADTFLASH,
	ERR_FWUG_FAIL_HEADERWRITETFLASH,
	ERR_FWUG_FAIL_HEADERREADTFLASH,
	ERR_FWUG_FAIL
} FWUG_ERROR;

#if defined(TCC78X)
typedef	int (*fFWUG_ReadDATA)(unsigned uDest, unsigned uSize, unsigned uTotalSize, unsigned uIdx);
#elif defined(TCC79XX)
typedef	int (*fFWUG_ReadDATA)(unsigned int uDest, unsigned int uSize, unsigned int percent);
#elif defined(TCC92XX)
#warning Add TCC92x code.
#elif defined(TCC89XX)
typedef	int (*fFWUG_ReadDATA)(unsigned int uDest, unsigned int uSize, unsigned int percent);	//nemo
#else
#error
#endif

extern const unsigned int CRC32_TABLE[];

//*****************************************************************************
//*
//*
//*                       [ EXTERNAL FUCTIONS DEFINE ]
//*
//*
//*****************************************************************************
extern unsigned char			gFW_FirmwareDevice, gFW_SerialNumberDevice;

extern char						*FWUG_GetTempBuffer(unsigned int *uiBufSize);
#if defined(TCC78X)
extern int						FWUG_ReadDATA(unsigned uDest, void *uHandler, unsigned uSize, unsigned uTotalSize, unsigned uIdx);
#elif defined(TCC79XX)
extern int						FWUG_ReadDATA(unsigned int uDest, void *uHandler, unsigned int uSize, unsigned int percent);
#elif defined(TCC92XX)
#warning Add TCC92x code.
#else
extern int						FWUG_ReadDATA(unsigned int uDest, void *uHandler, unsigned int uSize, unsigned int percent);	// nemo
#endif
extern unsigned int				CalCRC_ROMFile(unsigned int *pBuffer,unsigned int size,unsigned int crcout, unsigned int mode);
extern int						FWUG_VerifySerialNumber(unsigned char* ucBuf, unsigned int uiOffset);

extern unsigned int				FWUG_CalcCrc(unsigned int *base, unsigned int length, const unsigned int *crctable);
extern unsigned int				FWUG_CalcCrc8(unsigned char *base, unsigned int length, const unsigned int *crctable);
extern unsigned int				FWUG_CalcCrcI(unsigned uCRCIN, unsigned *base, unsigned int length, const unsigned int *crctable);
extern unsigned int				FWUG_CalcCrc8I(unsigned uCRCIN, unsigned char *base, unsigned int length, const unsigned int *crctable);

/* TFLASH */
extern unsigned int				FwdnReadTriflashFirmware(unsigned int master);
extern int						FwdnWriteTriflashFirmware(unsigned uFWSize);
extern int						FwdnGetTriflashSerial(void);
extern int						FwdnSetTriflashSerial(unsigned char *ucData, unsigned int overwrite);
extern int						FwdnClearTriflashHiddenArea(void);
/* HDD */
extern int						FwdnClearHddHiddenArea(void);
/* NOR */
extern unsigned int				FwdnReadNorFlashFirmware(unsigned int master);
extern int						FwdnWriteNorFlashFirmware(unsigned uFWSize);
extern int						FwdnGetNorSerial(void);
extern int						FwdnSetNorSerial(unsigned char *ucData, unsigned int overwrite);
/* NAND */
extern unsigned int 			FwdnReadNandFirmware(unsigned int master);
extern int						FwdnWriteNandFirmware(unsigned uFWSize);
extern int						FwdnGetNandSerial(void);
extern int 						FwdnSetNandSerial(unsigned char *ucData, unsigned int overwrite);
extern int						FwdnClearNandHiddenArea(unsigned int start, unsigned int pagesize);
extern void 					FWDN_FNT_VerifySN(unsigned char* ucTempData, unsigned int uiSNOffset);
/* SFLASH */
extern unsigned int				FwdnReadSFlashFirmware(unsigned int master);
extern int						FwdnWriteSFlashFirmware(unsigned uSFBase, unsigned uFWBase, unsigned int uiROMFileSize);
extern int						FwdnGetSFlashSerial(void);
extern int						FwdnSetSFlashSerial(unsigned char *ucData, unsigned int overwrite);
/* EEPROM */
extern int						FwdnWriteEEPROMFirmware(unsigned uFWSize);

#endif	// _FWUPGRADE_H_

/* end of file */

