
/****************************************************************************
 *   FileName    : fwupdateboot.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include <windows.h>

// For Wince ROM, NK.rom update
typedef struct _HIDDENINFO_{
	unsigned int	HiddenAddress;
	unsigned int	SectorNum;
	unsigned char*	DataBuffer;
}HIDDENINFO;

// For Wince ROM, NK.rom update
typedef struct _MULTI_HIDDENINFO_{
	unsigned int	DriveNum;
	unsigned int	HiddenAddress;
	unsigned int 	SectorNum;
	unsigned char*	DataBuffer;
}MULTIHIDDENINFO;

// For Bootloader update
typedef struct _FWINFO
{
	HANDLE hFile;
	unsigned int Filesize;
}FirmwareInfo;

typedef struct _BOOTCRCCODE
{
	unsigned int	uiCRC128KChk;
	unsigned int 	uiCRCFullChk;
	unsigned int	uiBootFileSize;
}BootCRCCode;


extern int FWUG_MainFunc(HANDLE iFilehandle, unsigned int uiFilesize);