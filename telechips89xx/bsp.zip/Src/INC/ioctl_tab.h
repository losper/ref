// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// File       : ioctl_tab.h
// Description: 
// Assumptions:
// ----------------------------------------------------------------------------

#include <oal_ioctl_tab.h>
#include "TCC_IoctlTable.h"

{IOCTL_HAL_POSTINIT, 0, OALIoCtlHALPostInit},
#if defined(SET_PAGINGPOOLPARAM)
{IOCTL_HAL_GET_POOL_PARAMETERS, 0, OALIoCtlHalGetPoolParameters},
#endif//SET_PAGINGPOOLPARAM
// Termination
{0,                  0, NULL}

