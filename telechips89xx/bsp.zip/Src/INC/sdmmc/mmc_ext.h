/****************************************************************************
 *   FileName    : mmc_ext.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#ifndef _MMC_EXT_H_
#define _MMC_EXT_H_

#ifndef _MMC_BASIC_H_
#include "mmc_basic.h"
#endif

#define		HARP_PUN				1
#define		SD_PUN					0
#define		INVALID_PUN				2
#define		gMAX_ROMSIZE_SD		0x200000	// 4096 sec.

extern const unsigned char SDMMC_Library_Version[];

extern int MMC_writepage(sMMCrecord *pMMC,unsigned long addr,unsigned char *buf);
extern int MMC_writemultipage_start(sMMCrecord *pMMC,unsigned long addr, unsigned long size);
extern int MMC_writemultipage(sMMCrecord *pMMC, unsigned short nSector, unsigned	char *ucBuf);
extern int MMC_writemultipage_stop(sMMCrecord *pMMC);
extern int MMC_readpage(sMMCrecord *pMMC,unsigned long addr,unsigned char *buf);

extern void MMC_StopTransfer(sMMCrecord *pMMC);
//Kitty0308
extern int MMC_readmultipage_start(sMMCrecord *pMMC,unsigned long addr, unsigned long size);
extern int MMC_readmultipage(sMMCrecord *pMMC, unsigned short nSector, unsigned char *buf);
extern int MMC_readmultipage_stop(sMMCrecord *pMMC);

//extern int MMC_readpage_stop(sMMCrecord *pMMC);
//extern int MMC_GetID(int drv_num,unsigned char *buf);
//extern long MMC_GetSize(int drv_num,unsigned char *buf);
//extern void MMC_WaitMAXDelay(void);
//extern int MMC_REReadMultiStart(int drv_num,unsigned long ulAddr, unsigned long size);

extern int MMC_Read(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int MMC_ReadMultiStart(int drv_num, unsigned long ulAddr, unsigned long size);
extern int MMC_ReadMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int MMC_ReadMultiStop(int drv_num);
extern int MMC_Write(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int MMC_WriteMultiStart(int drv_num, unsigned long ulAddr, unsigned long size);
extern int MMC_WriteMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int MMC_WriteMultiStop(int drv_num);
extern int MMC_HDReadPage(int drv_num,  unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int MMC_HDWritePage(int drv_num,  unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int MMC_HDClearPages(int drv_num, unsigned long start_sector, unsigned long end_sector);
extern int MMC_Ioctl(int drv_num, int function, void *param);
extern void MMC_SetBurstAccess(int drv_num);
extern void MMC_ClrBurstAccess(int drv_num);

extern int HARP_Read(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_ReadMultiStart(unsigned long ulAddr, unsigned long size);
extern int HARP_ReadMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_ReadMultiStop(void);
extern int HARP_Write(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_WriteMultiStart(unsigned long ulAddr, unsigned long size);
extern int HARP_WriteMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_WriteMultiStop(void);
extern int HARP_HDReadPage( unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HDWritePage( unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HDClearPages(unsigned long start_sector, unsigned long end_sector);
extern int HARP_Ioctl(int function, void *param);

extern int HARP_HD_Read(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HD_ReadMultiStart(unsigned long ulAddr, unsigned long size);
extern int HARP_HD_ReadMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HD_ReadMultiStop(void);
extern int HARP_HD_Write(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HD_WriteMultiStart(unsigned long ulAddr, unsigned long size);
extern int HARP_HD_WriteMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HD_WriteMultiStop(void);
extern int HARP_HD_Ioctl(int function, void *param);

extern int SD_Read(int drv_num, unsigned int LBA_addr, unsigned short nSector, void *buff);
extern int SD_ReadMultiStart(unsigned int ulAddr, unsigned int size);
extern int SD_ReadMulti(int drv_num, unsigned int LBA_addr, unsigned short nSector, void *buff);
extern int SD_ReadMultiStop(void);
extern int SD_Write(int drv_num, unsigned int LBA_addr, unsigned short nSector, void *buff);
extern int SD_WriteMultiStart(unsigned int ulAddr, unsigned int size);
extern int SD_WriteMulti(int drv_num, unsigned int LBA_addr, unsigned short nSector, void *buff);
extern int SD_WriteMultiStop(void);
extern int SD_Ioctl(int function, void *param);

extern int SD_HD_Read(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int SD_HD_ReadMultiStart(unsigned long ulAddr, unsigned long size);
extern int SD_HD_ReadMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int SD_HD_ReadMultiStop(void);
extern int SD_HD_Write(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int SD_HD_WriteMultiStart(unsigned long ulAddr, unsigned long size);
extern int SD_HD_WriteMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int SD_HD_WriteMultiStop(void);
extern int SD_HD_Ioctl(int function, void *param);

#endif
