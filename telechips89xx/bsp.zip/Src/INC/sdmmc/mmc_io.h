/****************************************************************************
 *   FileName    : mmc_io.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#include "Main.h"
#ifndef _MMC_H_
#define _MMC_H_

//struct MMCrecord 
//{
//   unsigned char id;
//   unsigned long size;
//   int head,sect,cyl;
//   unsigned int nb_blocks;		/* number of physical blocks */
//   unsigned int nb_hd_blocks; // 2MB ���� Ư�� �뵵�� ������ ���� ũ�� ��� 
//};

// ����� ��Ʈ �ʱ�ȭ �ϱ� 
void  _MMC_IO_SendByte(unsigned char b );
int  _MMC_IO_ReadByte(void );
void _MMC_SendCommand(unsigned char *buf);
int  _MMC_GetResponse(void);
int  MMC_readpage(int drv_num,unsigned long addr,unsigned char *buf);
int  MMC_writepage(int drv_num,unsigned long addr,unsigned char *buf);
int  _MMC_ResetCMD(void);
int  _MMC_GetCSD(unsigned char *buf);
long  MMC_GetSize(int drv_num,unsigned char *buf);
int _MMC_GetCID(unsigned char *buf);
int MMC_GetID(unsigned char *buf);
 
//extern struct MMCrecord g_mmc;
#endif

