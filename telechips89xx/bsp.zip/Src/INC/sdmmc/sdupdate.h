#define	HwCKC_SD			*(volatile unsigned long *)0xF0400108//*(volatile unsigned long *)0xF04000B0		//  R/W  0x00000000  SD Host 0 Clock Register 
#define HwGDATA_A			*(volatile unsigned long *)0xF0102000

#define	HwSDMMC_CH0_BASE						*(volatile unsigned long *)0xF05A0000	// R/W, SDMMC Channel 0 Base Register
#define	HwSDMMC_CH1_BASE						*(volatile unsigned long *)0xF05A0100	// R/W, SDMMC Channel 1 Base Register
#define	HwSDMMC_BASE(X)						*(volatile unsigned long *)(0xF05A0000+(X)*0x200)	// R/W, SDMMC Channel Base Register



#define	HwSD_TCMD_CMDIDX(X)				((X)*Hw24)						// Command Index
#define	HwSD_TCMD_CMDIDX_MASK			HwSD_TCMD_CMDIDX(63)
#define	HwSD_TCMD_CTYPE(X)					((X)*Hw22)						// Suspend, Resume, Abort, Normal
#define	HwSD_TCMD_CTYPE_ABORT				HwSD_TCMD_CTYPE(3)
#define	HwSD_TCMD_CTYPE_RESUME			HwSD_TCMD_CTYPE(2)
#define	HwSD_TCMD_CTYPE_SUSPEND			HwSD_TCMD_CTYPE(1)
#define	HwSD_TCMD_CTYPE_NORMAL			HwSD_TCMD_CTYPE(0)
#define	HwSD_TCMD_CTYPE_MASK				HwSD_TCMD_CTYPE(3)
#define	HwSD_TCMD_DATSEL_PRESENT			Hw21							// Data is present and shall be transferred
#define	HwSD_TCMD_DATSEL_NODATA			HwZERO
#define	HwSD_TCMD_CICHK_EN				Hw20							// Check the Index field in the response
#define	HwSD_TCMD_CRCHK_EN				Hw19							// Check the CRC field in the response
#define	HwSD_TCMD_RTYPE_HC				Hw18							// Response with 48 bytes (HC)
#define	HwSD_TCMD_RTYPE(X)					((X)*Hw16)						// Response Type
#define	HwSD_TCMD_RTYPE_NORESP			HwSD_TCMD_RTYPE(0)			// No Response
#define	HwSD_TCMD_RTYPE_R136				HwSD_TCMD_RTYPE(1)			// Response with 136 bytes
#define	HwSD_TCMD_RTYPE_R48				HwSD_TCMD_RTYPE(2)			// Response with 48 bytes
#define	HwSD_TCMD_RTYPE_R48CHK			HwSD_TCMD_RTYPE(3)			// Response with 48 bytes - check Busy after response
#define	HwSD_TCMD_SPI_MODE				Hw7								// SPI Mode
#define	HwSD_TCMD_SD_MODE				HwZERO							// SD Mode
#define	HwSD_TCMD_ATACMD					Hw6								// CE-ATA Mode (Device will send Command Completion Signal)
#define	HwSD_TCMD_MS_MULTI				Hw5								// Multiple Block Mode
#define	HwSD_TCMD_MS_SINGLE				HwZERO							// Single Block Mode
#define	HwSD_TCMD_DIR_READ				Hw4								// Read Mode (Transfer from Card to Host)
#define	HwSD_TCMD_DIR_WRITE				HwZERO							// Write Mode (Transfer from Host to Card)
#define	HwSD_TCMD_ACMD12_EN				Hw2								// CMD12 is issued automatically after last block transfer is completed.
#define	HwSD_TCMD_BCNTEN_EN				Hw1								// Enable Block Count Register (BCNT). only relevant for multiple block transfers
#define	HwSD_TCMD_DMAEN_EN				Hw0								// DMA Enabled (can be enabled only if CA register tells it support DMA)


#define	HwSD_CTRL_WKOUT_EN				Hw26							// Enable Wakeup event on Card Removal
#define	HwSD_CTRL_WKIN_EN					Hw25							// Enable Wakeup event on Card Insertion
#define	HwSD_CTRL_WKINT_EN					Hw24							// Enable Wakeup event on Card Interrupt
#define	HwSD_CTRL_BGINT_EN					Hw19							// Enable interrupt detection at the block gap for multiple block transfer (valid only 4bit SDIO mode)
#define	HwSD_CTRL_RDWAIT_EN				Hw18							// Enable use of read-wait protocol to stop read data using DAT2 line
#define	HwSD_CTRL_CONREQ_EN				Hw17							// Restart a transaction that was stopped by BGSTOP request
#define	HwSD_CTRL_BGSTOP_EN				Hw16							// Executing transaction stops at the next block gap for non-DMA, SDMA, ADMA transfers.
#define	HwSD_CTRL_VOLTSEL(X)				((X)*Hw9)						// Selects voltage level for the SD Card
#define	HwSD_CTRL_VOLTSEL_V33				HwSD_CTRL_VOLTSEL(7)			// 3.3V Flattop
#define	HwSD_CTRL_VOLTSEL_V30				HwSD_CTRL_VOLTSEL(6)			// 3.0V (typical)
#define	HwSD_CTRL_VOLTSEL_V18				HwSD_CTRL_VOLTSEL(5)			// 1.8V (typical)
#define	HwSD_CTRL_VOLTSEL_MASK			HwSD_CTRL_VOLTSEL(7)
#define	HwSD_CTRL_POW_ON					Hw8								// SD Bus Power On (VOLTSEL should be set ahead)
#define	HwSD_CTRL_DETSEL_TST				Hw7								// Card detect test level is selected (test purpose only)
#define	HwSD_CTRL_DETSEL_SDCD				HwZERO							// SDCD# line is selected (normal case)
#define	HwSD_CTRL_SD8_EN					Hw5								// SD 8bit mode is selected
#define	HwSD_CTRL_SELDMA(X)				((X)*Hw3)						// SD DMA Selection
#define	HwSD_CTRL_SELDMA_SDMA				HwSD_CTRL_SELDMA(0)			// SDMA is selected
#define	HwSD_CTRL_SELDMA_ADMA1			HwSD_CTRL_SELDMA(1)			// ADMA1 (32bit address) is selected
#define	HwSD_CTRL_SELDMA_ADMA2_32			HwSD_CTRL_SELDMA(2)			// ADMA2 (32bit address) is selected
#define	HwSD_CTRL_SELDMA_ADMA2_64			HwSD_CTRL_SELDMA(3)			// ADMA2 (64bit address) is selected
#define	HwSD_CTRL_SELDMA_MASK				HwSD_CTRL_SELDMA(3)
#define	HwSD_CTRL_HS_EN					Hw2								// Enable High Speed
#define	HwSD_CTRL_SD4_EN					Hw1								// SD 4bit mode is selected
#define	HwSD_CTRL_SD1_EN					HwZERO							// SD 1bit mode is selected
#define	HwSD_CTRL_LED_ON					Hw0								// LED ON

#define	HwSD_CLK_RSTDAT_EN				Hw26							// SW Reset for DAT line
													// DATA, STATE(RDEN, WREN, RDACT, WRACT, DATACT, NODAT) are cleared
													// CTRL(CONREQ, BGSTOP), STS(RDRDY,WRRDY,BLKGAP,TDONE) are cleared
#define	HwSD_CLK_RSTCMD_EN				Hw25							// SW Reset for CMD line
													// STATE(NOCMD), STS(CDONE) are cleared
#define	HwSD_CLK_RSTALL_EN					Hw24							// SW Reset for All (except Card Detection Circuit)
#define	HwSD_CLK_TIMEOUT(X)				((X)*Hw16)						// Time Out Selection
#define	HwSD_CLK_TIMEOUT_TM8K				HwSD_CLK_TIMEOUT(0)			// Timeout = TMCLK * 8K
#define	HwSD_CLK_TIMEOUT_TM16K			HwSD_CLK_TIMEOUT(1)			// Timeout = TMCLK * 16K
#define	HwSD_CLK_TIMEOUT_TM32K			HwSD_CLK_TIMEOUT(2)			// Timeout = TMCLK * 32K
#define	HwSD_CLK_TIMEOUT_TM64K			HwSD_CLK_TIMEOUT(3)			// Timeout = TMCLK * 64K
#define	HwSD_CLK_TIMEOUT_TM128K			HwSD_CLK_TIMEOUT(4)			// Timeout = TMCLK * 128K
#define	HwSD_CLK_TIMEOUT_TM256K			HwSD_CLK_TIMEOUT(5)			// Timeout = TMCLK * 256K
#define	HwSD_CLK_TIMEOUT_TM512K			HwSD_CLK_TIMEOUT(6)			// Timeout = TMCLK * 512K
#define	HwSD_CLK_TIMEOUT_TM1M				HwSD_CLK_TIMEOUT(7)			// Timeout = TMCLK * 1M
#define	HwSD_CLK_TIMEOUT_TM2M				HwSD_CLK_TIMEOUT(8)			// Timeout = TMCLK * 2M
#define	HwSD_CLK_TIMEOUT_TM4M				HwSD_CLK_TIMEOUT(9)			// Timeout = TMCLK * 4M
#define	HwSD_CLK_TIMEOUT_TM8M				HwSD_CLK_TIMEOUT(10)			// Timeout = TMCLK * 8M
#define	HwSD_CLK_TIMEOUT_TM16M			HwSD_CLK_TIMEOUT(11)			// Timeout = TMCLK * 16M
#define	HwSD_CLK_TIMEOUT_TM32M			HwSD_CLK_TIMEOUT(12)			// Timeout = TMCLK * 32M
#define	HwSD_CLK_TIMEOUT_TM64M			HwSD_CLK_TIMEOUT(13)			// Timeout = TMCLK * 64M
#define	HwSD_CLK_TIMEOUT_TM128M			HwSD_CLK_TIMEOUT(14)			// Timeout = TMCLK * 128M
#define	HwSD_CLK_TIMEOUT_MASK				HwSD_CLK_TIMEOUT(15)
#define	HwSD_CLK_SDCLKSEL(X)				((X)*Hw8)						// SDCLK Frequency Selection
#define	HwSD_CLK_SDCLKSEL_D256			HwSD_CLK_SDCLKSEL(128)		// SDCLK = base clock / 256
#define	HwSD_CLK_SDCLKSEL_D128			HwSD_CLK_SDCLKSEL(64)			// SDCLK = base clock / 128
#define	HwSD_CLK_SDCLKSEL_D64				HwSD_CLK_SDCLKSEL(32)			// SDCLK = base clock / 64
#define	HwSD_CLK_SDCLKSEL_D32				HwSD_CLK_SDCLKSEL(16)			// SDCLK = base clock / 32
#define	HwSD_CLK_SDCLKSEL_D16				HwSD_CLK_SDCLKSEL(8)			// SDCLK = base clock / 16
#define	HwSD_CLK_SDCLKSEL_D8				HwSD_CLK_SDCLKSEL(4)			// SDCLK = base clock / 8
#define	HwSD_CLK_SDCLKSEL_D4				HwSD_CLK_SDCLKSEL(2)			// SDCLK = base clock / 4
#define	HwSD_CLK_SDCLKSEL_D2				HwSD_CLK_SDCLKSEL(1)			// SDCLK = base clock / 2
#define	HwSD_CLK_SDCLKSEL_D1				HwSD_CLK_SDCLKSEL(0)			// SDCLK = base clock (10MHz ~ 63MHz)
#define	HwSD_CLK_SDCLKSEL_MASK			HwSD_CLK_SDCLKSEL(255)
#define	HwSD_CLK_SCKEN_EN					Hw2								// SDCLK Enable
#define	HwSD_CLK_CLKRDY_STABLE			Hw1								// R, Internal base clock is stable
#define	HwSD_CLK_CLKEN_EN					Hw0								// Internal base clock Enable

#define	HwSD_STS_VENDOR3_ERR				Hw31							// Vendor specific error status3
#define	HwSD_STS_VENDOR2_ERR				Hw30							// Vendor specific error status2
#define	HwSD_STS_VENDOR1_ERR				Hw29							// Vendor specific error status1
#define	HwSD_STS_VENDOR0_ERR				Hw28							// Vendor specific error status0
#define	HwSD_STS_ADMA_ERR					Hw25							// Error detected when ADMA Transfers
#define	HwSD_STS_ACMD12_ERR				Hw24							// One of CMD12ERR register has been set to 1
#define	HwSD_STS_CLIMIT_ERR				Hw23							// Exceeding Current limit
#define	HwSD_STS_DATEND_ERR				Hw22							// 0 detected at the end bit position of read
#define	HwSD_STS_DATCRC_ERR				Hw21							// CRC error detected
#define	HwSD_STS_DATTIME_ERR				Hw20							// Data Timeout error detected
#define	HwSD_STS_CINDEX_ERR				Hw19							// Command Index error detected in the command response
#define	HwSD_STS_CMDEND_ERR				Hw18							// 0 deteced at the end bit position of a command response
#define	HwSD_STS_CMDCRC_ERR				Hw17							// Command CRC error detected
#define	HwSD_STS_CMDTIME_ERR				Hw16							// Command Timeout error detected (no response returned within 64 SDCLKs)
#define	HwSD_STS_ERR						Hw15							// Error detected (One of above flags is set)
#define	HwSD_STS_CDINT						Hw8								// Card Interrupt is generated
#define	HwSD_STS_CDOUT					Hw7								// Card Removed (STATE.CDIN changes from 1 to 0)
#define	HwSD_STS_CDIN						Hw6								// Card Inserted (STATE.CDIN changes from 0 to 1)
#define	HwSD_STS_RDRDY					Hw5								// Buffer Read Ready (STATE.RDEN changes from 0 to 1, and ready to read)
#define	HwSD_STS_WRRDY					Hw4								// Buffer Write Ready (STATE.WREN changes from 0 to 1, and ready to read)
#define	HwSD_STS_DMAINT					Hw3								// DMA Interrupt
#define	HwSD_STS_BLKGAP					Hw2								// Block Gap Event (STATE.DATACT falling in read transfer, STATE.WRACT falling in write transfer)
#define	HwSD_STS_TDONE						Hw1								// Transfer Complete
#define	HwSD_STS_CDONE					Hw0								// The end bit of the command response acquired (except Auto CMD12)


#define	HwSD_STATE_DAT7_HIGH				Hw28							// State of DAT7 line
#define	HwSD_STATE_DAT6_HIGH				Hw27							// State of DAT6 line
#define	HwSD_STATE_DAT5_HIGH				Hw26							// State of DAT5 line
#define	HwSD_STATE_DAT4_HIGH				Hw25							// State of DAT4 line
#define	HwSD_STATE_CMD_HIGH				Hw24							// State of CMD line
#define	HwSD_STATE_DAT3_HIGH				Hw23							// State of DAT3 line
#define	HwSD_STATE_DAT2_HIGH				Hw22							// State of DAT2 line
#define	HwSD_STATE_DAT1_HIGH				Hw21							// State of DAT1 line
#define	HwSD_STATE_DAT0_HIGH				Hw20							// State of DAT0 line
#define	HwSD_STATE_SDWP_HIGH				Hw19							// State of WP line
#define	HwSD_STATE_SDCD_DET				Hw18							// Inverse State of CD# line (Card Detected State)
#define	HwSD_STATE_CDST_STABLE			Hw17							// Card Detect Pin level is stable
#define	HwSD_STATE_CDIN_INSERT				Hw16							// Card has been inserted
#define	HwSD_STATE_RDEN_EN					Hw11							// Buffer Read Enable (Readable data exist in the buffer)
#define	HwSD_STATE_WREN_EN				Hw10							// Buffer Write Enable (Data can be written to the buffer)
#define	HwSD_STATE_RDACT_ACTIVE			Hw9								// Read transfer is active
#define	HwSD_STATE_WRACT_ACTIVE			Hw8								// Write transfer is active
#define	HwSD_STATE_DATACT_ACTIVE			Hw2								// DAT[7:0] line on SD bus is in use
#define	HwSD_STATE_NODAT_INHIBIT			Hw1								// DAT line or Read Transfer is active (No Command using DAT is allowed)
#define	HwSD_STATE_NOCMD_INHIBIT			Hw0								// CMD line is in use (No Command is allowed)
    

typedef volatile struct
{
	unsigned	SDMA;				// R/W, SDMA System Address
	unsigned	BPARAM;				// R/W, Block Size & Count

	unsigned	ARG;				// R/W, Argument (specified as bit39~8 of Command Format)
	unsigned	TCMD;				// R/W, Command & Transfer Mode

	unsigned	RESP[4];				// R, Response Words [127:0]
	unsigned	DATA;				// R/W, Buffer Data Port
	unsigned	STATE;				// R, Present State

	unsigned	CTRL;				// R/W, (Power, Host, Wakeup, Block Gap) Control

	unsigned	CLK;				// R/W, Clock control / Reset & TimeOut Control

	unsigned	STS;				// R, Normal Interrupt Status

	unsigned	STSEN;				// R/W, Normal Interrupt Status Enable
	unsigned	INTEN;				// R/W, Normal Interrupt Signal Enable

	unsigned	CMD12ERR;			// R, Auto CMD12 Error Status

	unsigned	CA;					// R, Capabilities

	unsigned	_RSV0;
	unsigned	CUR;				// R, Maximum Current Capabilities
	unsigned	_RSV1;
	unsigned	FORCE;				// W, Force Event for Error

	unsigned	ADMAERR;			// R/W, ADMA Error Status

	unsigned	ADDR[2];			// R/W, ADMA Address
	unsigned	_RSV2[(0xF0-0x60)/4];
	unsigned	SPIINT;				// R, SPI Interrupt Support
	unsigned	_RSV3[2];
	unsigned short	VERSION;	// R, Host Controller Version
	unsigned short	SLOTINT;		// R, Slot Interrupt Status
} sHwSDMMC;


extern int SDUpdate(void);