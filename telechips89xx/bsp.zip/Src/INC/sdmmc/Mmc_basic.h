/****************************************************************************
 *   FileName    : mmc_basic.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#ifndef _MMC_BASIC_H_
#define _MMC_BASIC_H_

//#if defined(MMC_INCLUDE) || defined(_TRIFLASH_DEVICE_CONFIG_)
	#define	MMCPLUS_BUS_WIDTH	4	// 1, 4, 8
//#endif

/**********************  Host Controller Option for Each Platform **********************/
#if defined(TCC79X) || defined(TCC83XX) || defined(TCC80X) || defined(TCC89XX)
	#define	SDMMC_CTRL_V3
#elif defined(TCC82XX) || defined(TCC78X)
#else
#endif

///////////////////////////////////////////////////////////////////////////////

#ifdef	CD_HOST_INCLUDE
	#undef	MMCPLUS_BUS_WIDTH
	#define	MMCPLUS_BUS_WIDTH	1	// 1, 4, 8
#endif

#ifdef _USE_PORT_A_
	#define	HwGSEL_SD		HwGSEL_A
	#define	HwGSEL_SD1		HwGSEL_A_SD1_SD1
	#define	HwGSEL_SD4		HwGSEL_A_SD4_SD4
	#define	HwGSEL_SD8		HwGSEL_A_SD8_SD8
#endif
#ifdef _USE_PORT_D_
	#define	HwGSEL_SD		HwGSEL_D
	#define	HwGSEL_SD1		HwGSEL_D_SD1_SD1
	#define	HwGSEL_SD4		HwGSEL_D_SD4_SD4
	#define	HwGSEL_SD8		HwGSEL_D_SD8_SD8
#endif

///////////////////////////////////////////////////////////////////////////////
#define	BLOCKLEN	512

#define	CMD0		0		// Go Idle State
#define	CMD1		1		// Send Operating Condition
#define	CMD2		2		// All Send CID
#define	CMD3		3		// Set RCA(Relative Card Address)
#define	CMD4		4		// Set DSR(Driver Stage/Strength Register)
#define	CMD6		6		// Switch Mode
#define	CMD7		7		// Select/Deselect Card (Go Transfer State or Go Standby state if RCA == 0)
#define	CMD8		8		// Send Extended CSD (Card Specifiec Data)
#define	CMD9		9		// Send CSD (Card Specific Data)
#define	CMD10		10		// Send CID
#define	CMD11		11		// Stream Read (Read Data Until Stop)
#define	CMD12		12		// Stop
#define	CMD13		13		// Send Status
#define	CMD15		15		// Go Inactive State

#define	CMD16		16		// Set Block Length
#define	CMD17		17		// Block Read
#define	CMD18		18		// Multiple Block Read

#define	CMD20		20		// Stream Write (Write Data Until Stop)

#define	CMD23		23		// Set Block Count
#define	CMD24		24		// Block Write
#define	CMD25		25		// Multiple Block Write
#define	CMD26		26		// Write CID (OTP type, Normally Reserved by Manufacturer)
#define	CMD27		27		// Write CSD (OTP type, Normally Reserved by Manufacturer)

#define	CMD28		28		// Set Write Protect
#define	CMD29		29		// Clear Write Protect
#define	CMD30		30		// Send Write Protect

#define	CMD32		32
#define	CMD33		33
#define	CMD35		35		// Set Start of Erase Group
#define	CMD36		36		// Set End of Erase Group
#define	CMD38		38		// Start Erase

#define	CMD39		39		// FAST IO (Read/Write Card Register)
#define	CMD40		40		// Go IRQ State

#define	CMD42		42		// Lock, Unlock

#define	CMD55		55		// ACMD Start
#define	CMD56		56		// General Purpose Read or Write Command

#define	ACMD6		6
#define	ACMD13		13
#define	ACMD18		18
#define	ACMD22		22
#define	ACMD23		23
#define	ACMD25		25
#define	ACMD26		26
#define	ACMD38		38
#define	ACMD41		41
#define	ACMD42		42
#define	ACMD43		43
#define	ACMD49		49
#define	ACMD51		51

#define	NoRsp		0
#define	RspType1	1
#define	RspType1b	2
#define	RspType2	3
#define	RspType3	4
#define	RspType4	5
#define	RspType5	6
#define	RspType6	7
#define	RspType7	8

#define	CMD_NW		Hw10	// CMD with no-waiting
#define	CMD_WD		Hw8		// CMD with DATA
#define	CMD_HC		Hw9		// CMD for HC

///////////////////////////////////////////////////////////////////////////////
// Set Default Hidden Size
#define HIDDEN_DEFAULT_TOTAL_PAGESIZE	61440	// 30MB
///////////////////////////////////////////////////////////////////////////////

enum
{
	MMC_RESPONSE_NONE = 0,
	MMC_RESPONSE_R1,
	MMC_RESPONSE_R1B,
	MMC_RESPONSE_R2,
	MMC_RESPONSE_R3,
	MMC_RESPONSE_R6,
	MMC_RESPONSE_COUNT
};

enum __MMC_CardType
{
	MMC_CARD_UNKNOWN = 0,
	MMC_CARD_MMC,
	MMC_CARD_SD,
	MMC_CARD_MMCPLUS,
	MMC_CARD_COUNT
};

enum __MMC_CardVersion
{
	MMC_CARD_Ver1xx = 1,
	MMC_CARD_Ver200
};

#define MMC_NO_ERROR		0
#define MMC_ERR_TIMEOUT		-1
#define MMC_ERR_CRCRSP		-2
#define MMC_ERR_NODETECT	-3
#define MMC_ERR_WRPROTECT	-4
#define MMC_ERR_NOTRAN		-5

#define MMC_STATUS_IDLE		0x00000000
#define MMC_STATUS_READY	0x00000200
#define MMC_STATUS_STANDBY	0x00000600
#define MMC_STATUS_TRAN		0x00000800
#define MMC_STATUS_DATA		0x00000A00

#pragma pack(1)
typedef struct _tag_mmc_Command
{
	unsigned char	bCommand;
	unsigned char	bParameters[4];
	unsigned char	bCRC;
} MMC_COMMAND;

#pragma pack()

typedef struct mmc_hidden_t
{
	unsigned int	start;		// In Sector Address
	unsigned int	size;		// Sector Count
} sMMC_hidden;

typedef struct mmc_filesys_t
{
	unsigned long		start;		// In Sector Address
	unsigned long		size;
	unsigned short		head;
	unsigned short		sect;
	unsigned long		cyl;
} sMMC_filesys;

typedef struct CIDREG_t
{
	int MID;		//Manufacture ID		08bits	[127:120] 
	int OID;		//Application ID		16bits	[119:104]
	int PNM_U;	//Product Name			40bits	[103:64]
	int PNM_L;
	int PRV;		//Product Version		08bits	[63:56]
	int PSN;		//Product Serial number	32bits	[55:24]
	int MDT;		//Manufacture Date		12bits	[19:8]
	int CRC;		//CRC7 CheckSum		07bits	[7:1]
} sCIDREG;

typedef struct CSDREG_t
{
	unsigned	char CSDS;					//CSD Structure								02bits	[127:126]
	unsigned	char SPEC_VERS;				// System Specification Version						04bits	[125:122]
	unsigned	char TAAC;					//Data Read Access Time-1						08bits	[119:112]
	unsigned	char NSAC;					//Data Read Access Time-2 in CLK cycles(NSAC*100) 	08bits	[111:104]
	unsigned	char TRAN_SPEED;				//Max Data Transfer Rate							08bits	[103:96]
	unsigned	short CCC;					//Card Command Classes							12bits	[95:84]
	unsigned	char READ_BL_LEN;			//Max Read Data Block Length						04bits	[83:80]
	unsigned	char READ_BL_PARTIAL;		//Partial blocks for read allowed						01bits	[79:79]
	unsigned	char WRITE_BL_MISALIGN;		//											01bits	[78:78]
	unsigned	char READ_BL_MISALIGN;		//											01bits	[77:77]
	unsigned	char DSR_IMP;				//											01bits	[76:76]
	unsigned	long C_SIZE;					//Device Size									12bits	[73:62]
	unsigned	char VDD_R_CURR_MIN;		//											03bits	[61:59]
	unsigned	char VDD_R_CURR_MAX;		//											03bits	[58:56]
	unsigned	char VDD_W_CURR_MIN;		//											03bits	[55:53]
	unsigned	char VDD_W_CURR_MAX;		//											03bits	[52:50]
	unsigned	char C_SIZE_MULT;			//Device Size Multiplier							03bits	[49:47]
	unsigned	char ERASE_BL_EN;			//											01bits	[46:46]
	unsigned	char SECTOR_SIZE;			//											07bits	[45:39]
	unsigned	char WP_GRP_SIZE;			//											07bits	[38:32]
	unsigned	char WP_GRP_ENABLE;			//											01bits	[31:31]
	unsigned	char R2W_FACTOR;			//Write Speed Factor								03bits	[28:26]
	unsigned	char WRITE_BL_LEN;			//											04bits	[25:22]
	unsigned	char WRITE_BL_PARTIAL;		//											01bits	[21:21]
	unsigned	char FILE_FORMAT_GRP;		//											01bits	[15:15]
	unsigned	char COPY;					//											01bits	[14:14]
	unsigned	char PERM_WRITE_PROTECT;	//											01bits	[13:13]
	unsigned	char TMP_WRITE_PROTECT;		//											01bits	[12:12]
	unsigned	char FILE_FORMAT;			//											02bits	[11:10]
	unsigned	char CRC;					//											07bits	[7:1]

	unsigned	RealTAAC;					// Taac with 2.67 us unit
	unsigned	TranFreq;					// Transfer Freq with 100 Hz unit
} sCSDREG;

typedef struct EXTCSDREG_t		//structure of Extended CSD register
{
	unsigned char Reserved180[181];
	unsigned char ErasedMemCont;	// initial value after erase operation
	unsigned char Reserved182;
	unsigned char BusWidth;			// bus width
	unsigned char Reserved184;
	unsigned char HSTiming;			// high speed timing
	unsigned char Reserved186;
	unsigned char PowClass;			// power class 
	unsigned char Reserved188;
	unsigned char CmdSetRev;		// command set revision
	unsigned char Reserved190;
	unsigned char CmdSet;			// currently active command in the card
	unsigned char EXTCSDRev;		// EXT_CSD revision
	unsigned char Reserved193;
	unsigned char CSDStruct;		// CSD Structure field in CSD registe
	unsigned char Reserved195;
	unsigned char CardType;			// MMC card type
	unsigned char Reserved197[3];
	unsigned char PwrCl52195;
	unsigned char PwrCl26195;
	unsigned char PwrCl52360;
	unsigned char PwrCl26360;		//supported power class by the card
	unsigned char Reserved204;
	unsigned char MinPerfR0426;		//min Read performance  at 4bit bus width & 26MHz	
	unsigned char MinPerfW0426;		//min Write performance  at 4bit bus width & 26MHz	
	unsigned char MinPerfR08260452;	//min Read performance  at 8bit bus width & 26MHz host clock or 4bit bus width & 52MHz
	unsigned char MinPerfW08260452;	//min Write performance  at 8bit bus width & 26MHz host clock or 4bit bus width & 52MHz
	unsigned char MinPerfR0852;		//min Read performance  at 8bit bus width & 52MHz host clock
	unsigned char MinPerfW0852;		//min write performance  at 8bit bus width & 52MHz host clock
	unsigned char Reserved211;
	unsigned long Sec_Count;		//sector count
	unsigned char Reserved216[288];
	unsigned char sCmdSet;			//command sets are supported by the card
	unsigned char Reserved505[7];
} sEXTCSDREG;

typedef struct SCRREG_t
{
	int SCRS;						//SCR Structure					04bits	[63:60]
	int SD_SPEC;						//SD Memory Card-spec.Version	04bits	[59:56]
	int DATA_STAT_AFTER_ERASE;		//							01bits	[55:55]
	int SD_SECURITY;					//							03bits	[54:52]
	int SD_BUS_WIDTH;				//							04bits	[51:48]
} sSCRREG;

typedef struct SCR_Register_t
{
	unsigned int sd_bus_widths :4;
	unsigned int sd_security : 3;
	unsigned int data_stat_after_erase : 1;
	unsigned int sd_spec : 4;
	unsigned int scr_structure : 4;
} sSCR_Register;

#define	SDMMC_AREA_BOOTROM		(1 << 0)
#define	SDMMC_AREA_HIDDEN		(1 << 1)
#define	SDMMC_AREA_HIDDEN_FS		(1 << 2)
#define	SDMMC_AREA_REINIT		(1 << 7)

#define	SDMMC_STAT_INSERT				(1 << 0)
#define	SDMMC_STAT_CLOCK_ON			(1 << 1)
#define	SDMMC_STAT_TRANS				(1 << 2)
#define	SDMMC_STAT_WRITE_PROTECT		(1 << 3)

#define	SDMMC_PROP_VER20				(1 << 0)
#define	SDMMC_PROP_INTERNAL			(1 << 1)
#define	SDMMC_PROP_MUTATION_CARD		(1 << 2)

#define	SDMMC_CTRL_CHKTRAN_MASK		(0xF)
#define	SDMMC_CTRL_AUTOSTOP			(1 << 4)
#define	SDMMC_CTRL_DMA				(1 << 5)
#define	SDMMC_CTRL_BY_MSC			(1 << 6)

typedef struct MMCrecord 
{
	unsigned char		id;
	unsigned char		card_prop;			// SDMMC_PROP_VER20, SDMMC_PROP_INTERNAL, SDMMC_PROP_MUTATION_CARD
	unsigned char		area_en;			// SDMMC_AREA_BOOTROM, SDMMC_AREA_HIDDEN, SDMMC_AREA_HIDDEN_FS
	unsigned char		ctrl_prop;			// SDMMC_CTRL_CHK_TRAN, SDMMC_CTRL_AUTOSTOP, SDMMC_CTRL_DMA, SDMMC_CTRL_BY_MSC
	unsigned long		size;				// sector count
	unsigned long		cyl;
	unsigned char		head;
	unsigned char		sect;
	unsigned char		bw;					// bus-width (1, 4, 8)
	unsigned char		longtimeout;
	unsigned short		sect_per_block;
	unsigned char		drv_num;
	unsigned char		card_state;			// SDMMC_STAT_TRANS, SDMMC_STAT_INSERT, SDMMC_STAT_CLOCK_ON, SDMMC_STAT_WRITE_PROTECT
	unsigned long		rca;
	unsigned long		buf_addr;
	unsigned long		dma_addr;
	unsigned short		remain_sectors;
	unsigned long		bootingFlag;		// 0x74696E49 (Init)

	sCIDREG				stCID;
	sCSDREG				stCSD;
	sEXTCSDREG			stEXTCSD;
	sSCR_Register		stSCR;

	sMMC_filesys		filesys;
	sMMC_filesys		filesys_hd;

	sMMC_hidden			hidden_p0;
	sMMC_hidden			hidden_p1;
	sMMC_hidden			hidden_p2;
	sMMC_hidden			hidden_p3;
	sMMC_hidden			bootcode;

	void				*pHwSDMMC;
} sMMCrecord;

/////////////////////////////////////////////////////////////////////////////
extern struct MMCrecord g_mmc[];
extern unsigned int	currentPUN;

// ========================================================================= //
extern int SDMMC_SD_ResetCMD(sMMCrecord *pMMC, int *iResBuf, char *cPNMBuf, int * iRCABuf);
extern int SDMMC_SD_WPStatus(sMMCrecord *pMMC);
extern int SDMMC_MMC_ResetCMD(sMMCrecord *pMMC,int *iResBuf, char *cPNMBuf, int * iRCABuf);
extern void SDMMC_IdFrequency(sMMCrecord *pMMC);
extern void SDMMC_TransFrequency(sMMCrecord *pMMC);
extern void SDMMC_GoIdle(sMMCrecord *pMMC);
extern int SDMMC_GetOCR(sMMCrecord *pMMC);
extern int SDMMC_GetIFCOND(sMMCrecord *pMMC);
extern int SDMMC_GetSCR(sMMCrecord *pMMC, int iRCA,unsigned int *buf);
extern void SDMMC_GetAllCID(sMMCrecord *pMMC, int *iResBuf);
extern void SDMMC_GetRCA(sMMCrecord *pMMC, int *iRCABuf);
extern void SDMMC_SetRCA(sMMCrecord *pMMC, int *iRCABuf, int iRCAVal);
extern void SDMMC_GetCSD(sMMCrecord *pMMC, int iRCA, int *iResBuf);
extern void SDMMC_GetCID(sMMCrecord *pMMC, int iRCA, int *iResBuf);
extern void SDMMC_KillClock(sMMCrecord *pMMC);
extern void SDMMC_SetClock(void);
extern int SDMMC_SendCommand(sMMCrecord *pMMC, int iRspType, int iIndex, int iArgument);
extern int SDMMC_SelectBWCommand(sMMCrecord *pMMC, int mmcplus_buswidth);
extern int SDMMC_WaitCmdReady(sMMCrecord *pMMC);
extern int SDMMC_WaitDataReady(sMMCrecord *pMMC);
extern int SDMMC_WaitReady(sMMCrecord *pMMC, unsigned uMode);
extern int SDMMC_WaitRspReceived(sMMCrecord *pMMC);
extern void SDMMC_WaitMAXTime(void);
extern void SDMMC_WaitTimer(unsigned uTick);
extern void SDMMC_DelayTimer(unsigned int uiCNT);
extern int SDMMC_check(sMMCrecord *pMMC);
extern void SDMMC_InitMMCRecord(int drv_num);
extern int SDMMC_DRV_Initialize(void);

extern int GetMMCState(sMMCrecord *pMMC);
extern void SetMMCState(sMMCrecord *pMMC, unsigned char state);
extern int SDMMC_CheckTranStatus(sMMCrecord *pMMC);

extern int SDMMC_WaitFifoLoadRqt(sMMCrecord *pMMC);
extern int SDMMC_WaitFifoFetchRqt(sMMCrecord *pMMC);
extern int SDMMC_WaitFifoEmpty(sMMCrecord *pMMC);
extern unsigned SDMMC_CalcTAAC(sCSDREG *pstCSD);
extern unsigned SDMMC_CalcTRAN(sCSDREG *pstCSD);
extern unsigned SDMMC_GetTIME(void);
extern unsigned SDMMC_LimitMAX(unsigned uTime);
extern void SDMMC_ClrIRQ(int iIRQType);
extern void SDMMC_GoTransfer(sMMCrecord *pMMC, int iRCA);
extern void SDMMC_ReadSDStatus(sMMCrecord *pMMC, int iRCA, int *iReadData);
extern int SDMMC_ReadMMCStatus(sMMCrecord *pMMC, int iRCA);
extern void SDMMC_EraseWriteBlock(sMMCrecord *pMMC, int *iEraseAddress);
extern int SDMMC_MMC_ReadEXTCSD(sMMCrecord *pMMC, unsigned char *ucBuf);
extern unsigned long SDMMC_GetSize(sMMCrecord *pMMC);		//���Ŀ� mmc_ext.c�� �̵��Ͽ��� ��.
extern unsigned SDMMC_GetAlignedNumber(unsigned uNum);
extern void SDMMC_ResetDataPath(sMMCrecord *pMMC);
extern void SDMMC_ResetHostState(sMMCrecord *pMMC);
extern int SDMMC_WaitDMATransfer(sMMCrecord *pMMC);
extern void SDMMC_SetSDMAAddress(sMMCrecord *pMMC);
extern int SDMMC_Write(sMMCrecord *pMMC, unsigned short nSector, unsigned char *ucBuf);
extern int SDMMC_WriteDMA(sMMCrecord *pMMC, unsigned short nSector, unsigned char *ucBuf);
extern void SDMMC_SetDataSize(sMMCrecord *pMMC, unsigned long blocknum, unsigned long blocksize);
extern int SDMMC_Read(sMMCrecord *pMMC, unsigned short nSector, unsigned char *ucBuf);
extern int SDMMC_ReadDMA(sMMCrecord *pMMC, unsigned short nSector, unsigned char *ucBuf);
extern void SDMMC_PortSelectAndReset(sMMCrecord *pMMC);
extern void SDMMC_DisableSDMMC(sMMCrecord *pMMC);
extern void SDMMC_AssertFunc(unsigned uNum, char *Name, unsigned uLine, ...);
extern void checkAndChangePUN(int drv_type);
extern int	MMC_setHiddenSize(sMMCrecord *pMMC, int nSector);
extern void SDMMC_SelectBW(sMMCrecord *pMMC, int bus_width);
extern unsigned SDMMC_GetRESP(sMMCrecord *pMMC, int argnum);
extern unsigned long MMC_scan (sMMCrecord *pMMC, int iMode, int mmcplus_buswidth);
extern void SDMMC_AllClockOnOff(sMMCrecord *pMMC, unsigned char ucOnOff);
extern int SDMMC_SkipSTOP(sMMCrecord *pMMC);

// ========================================================================= //

extern int MMC_HDCheck(int drv_num, unsigned LBA_addr, unsigned nSector);
extern int MMC_HD_Ioctl(int drv_num, int function, void *param);

extern int HARP_Read(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_ReadMultiStart(unsigned long ulAddr, unsigned long size);
extern int HARP_ReadMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_ReadMultiStop(void);
extern int HARP_Write(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_WriteMultiStart(unsigned long ulAddr, unsigned long size);
extern int HARP_WriteMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_WriteMultiStop(void);
extern int HARP_Ioctl(int function, void *param);

extern int HARP_HDCheck(unsigned LBA_addr, unsigned nSector);
extern int HARP_HD_Ioctl(int function, void *param);
extern int HARP_HDReadPage( unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HDWritePage( unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HDClearPages(unsigned long start_sector, unsigned long end_sector);
extern int HARP_HD_Read(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HD_ReadMultiStart(unsigned long ulAddr, unsigned long size);
extern int HARP_HD_ReadMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HD_ReadMultiStop(void);
extern int HARP_HD_Write(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HD_WriteMultiStart(unsigned long ulAddr, unsigned long size);
extern int HARP_HD_WriteMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int HARP_HD_WriteMultiStop(void);
extern int HARP_HD_Ioctl(int function, void *param);

extern int SD_Read(int drv_num, unsigned int LBA_addr, unsigned short nSector, void *buff);
extern int SD_ReadMultiStart(unsigned int ulAddr, unsigned int size);
extern int SD_ReadMulti(int drv_num, unsigned int LBA_addr, unsigned short nSector, void *buff);
extern int SD_ReadMultiStop(void);
extern int SD_Write(int drv_num, unsigned int LBA_addr, unsigned short nSector, void *buff);
extern int SD_WriteMultiStart(unsigned int ulAddr, unsigned int size);
extern int SD_WriteMulti(int drv_num, unsigned int LBA_addr, unsigned short nSector, void *buff);
extern int SD_WriteMultiStop(void);
extern int SD_Ioctl(int function, void *param);

extern int SD_HDCheck(unsigned LBA_addr, unsigned nSector);
extern int SD_HD_Ioctl(int function, void *param);
extern int SD_HD_Read(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int SD_HD_ReadMultiStart(unsigned long ulAddr, unsigned long size);
extern int SD_HD_ReadMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int SD_HD_ReadMultiStop(void);
extern int SD_HD_Write(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int SD_HD_WriteMultiStart(unsigned long ulAddr, unsigned long size);
extern int SD_HD_WriteMulti(int drv_num, unsigned long LBA_addr, unsigned short nSector, void *buff);
extern int SD_HD_WriteMultiStop(void);
extern int SD_HD_Ioctl(int function, void *param);

#endif
