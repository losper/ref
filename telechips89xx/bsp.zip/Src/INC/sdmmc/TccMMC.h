/****************************************************************************
 *   FileName    : TCCMMC.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#ifndef __TCCMMC_H__
#define __TCCMMC_H__

#define	iSPIMode  0x0101				// Normal Mode
									// SPI Mode & GSIO = 0x0101
									// SPI Mode & GPIO = 0x0100
									// SD Mode & SPI GSIO = 0x0111
									// SD Mode & SPI GPIO = 0x0110
									// Special Mode for SD Mode
									// SPI Mode & GSIO = 0x0001
									// SPI Mode & GPIO = 0x0000
									// SD Mode & SPI GSIO = 0x0011
									// SD Mode & SPI GPIO = 0x0010	


extern void Init_MMC(void) ;
#endif

/* end of file */

