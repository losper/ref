/****************************************************************************
*   FileName    : tca_gpio.h
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/


#ifndef __TCA_GPIO_H__
#define __TCA_GPIO_H__
//
#ifdef __cplusplus 
extern "C" {
#endif

unsigned int tca_allocbaseaddress(unsigned int iphysicalbaseaddress, unsigned int isize);
unsigned int tca_freebaseaddress(unsigned int ivirtualbaseaddress, unsigned int  isize);
unsigned int tca_setchangemode(void * devhandle, char * pbuffer, unsigned int isize);

#ifdef __cplusplus 
}
#endif
#endif //__TCA_GPIO_H__