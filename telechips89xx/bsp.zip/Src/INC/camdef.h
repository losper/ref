#ifndef __CAM_DEFINE_H__
#define __CAM_DEFINE_H__

enum
{
	NONE_CAMMOD = 0,
	MT9D112,
	TVP5150A,
	TVP5150A_PAL
};

#endif
