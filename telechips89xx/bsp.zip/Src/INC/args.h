/****************************************************************************
*   FileName    : args.h
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#ifndef __ARGS_H__
#define __ARGS_H__

#ifdef __cplusplus
extern "C" {
#endif

//----------------------------
// Global Version
//----------------------------
#define	EBOOT_VERSION_MAJOR	1
#define EBOOT_VERSION_MINOR	1
#define BSP_VERSION_RELEASE	1
#define CONFIG_FLAGS_DHCP                   (1 << 1)

typedef struct _KITL{
	unsigned int	nKITLMode;				// 0 -- disable, 1 -- active, 2 -- passive
	unsigned int	nDHCP;					// 0 -- disable, 1 -- enable
	unsigned int	nIPAddr;
	unsigned int	nSubnetMask;
	USHORT			chMACAddr[3];
	unsigned char	Reserved[2];
}KITL,* PKITL;

typedef struct _MEMBUF{
	unsigned int	INTBUF;
	unsigned char	CHARBUF;
	unsigned char	Reseved[3];
}MEMBUF,* PMEMBUF;

typedef struct _SYSTEMPARAM{
	unsigned char	SIGTCBOOT[32];
	unsigned char	DeviceID[32];
	unsigned char	NANDUUID[32];
	unsigned int	 CHIPID[2];
	unsigned int	nSignature;           // Config signature (used to validate).
	unsigned int	nVerMajor;            // Config major version.
    unsigned int	nVerMinor;            // Config minor version.
	unsigned int	nBootDelay;           // Bootloader count-down delay.
	unsigned int	LaunchAddress;       // Kernel region launch address.
}SYSTEMPARAM,* PSYSTEMPARAM;

typedef struct _LCDINFO{
	unsigned int	nWidth;
	unsigned int	nHeight;
	unsigned int	nMode;
	unsigned int	nChromaKey;
	unsigned int	nLcdcIdxForUI;
	unsigned int	nLcdCfgIdx;
	unsigned int	nDemoType;
}LCDINFO,* PLCDINFO;

typedef struct	_BOOTARGS {
	unsigned int	nConfigFlags;	
	KITL			mKitl;
	MEMBUF			mMemBuf;
	SYSTEMPARAM		mSystemParam;
	LCDINFO			mLcdInfo;
	unsigned int	SetFlag;
}BOOTARGS,* PBOOTARGS;

//#define GDMA_BUFF_SIZE  0x200
#define GDMA_BUFF_SIZE  0x1000

typedef struct _tDMA_BUFS {
	BYTE CH0_BUFFER[GDMA_BUFF_SIZE];
	BYTE CH1_BUFFER[GDMA_BUFF_SIZE];
	BYTE CH2_BUFFER[GDMA_BUFF_SIZE];	
}tDMA_BUFS, *ptDMA_BUFS;

typedef struct _tUDMA_BUFF {
	BYTE CON_BUFF[0x200];
	BYTE IN_BUFF[0x10000];
	BYTE OUT_BUFF[0x10000];	
}UDMA_BUFF, *PUDMA_BUFF;

typedef struct _NANDINFO{
	unsigned int	sNandInitStatus;
	unsigned char	sNandInitInfo[0x20000];
}NANDINFO, *pNANDINFO;

typedef struct _tSYSTEMP_PARAM {
	tDMA_BUFS DMA0;					// 1.5K
	tDMA_BUFS DMA1;					// 1.5K
	tDMA_BUFS DMA2;					// 1.5K
	tDMA_BUFS DMA3;					// 1.5K
	BYTE ADMA_BUFFER[0x200*16]; 	// 8KByte
	UDMA_BUFF UDMA_BUFF;			// 0x8200
	
	BOOTARGS  SYSTEM_ARGS;
	NANDINFO 	NAND_INFO;			// 128K
	unsigned int	POWER_KEY;			// 4Byte 		
	unsigned int    ClockInfo[12];	// PLL0, PLL1, PLL2, PLL3, 
									// CLKCTRL0(Core),CLKCTRL1(DDI),CLKCTRL2(MEM),CLKCTRL3(GRP),
									// CLKCTRL4(IO),CLKCTRL5(VBUS),CLKCTRL6(VPU),CLKCTRL7(SMU) - 48Byte
	unsigned int 	StateMode[2];	// PreMode, CurMode - 16Byte

}tSYSTEM_PARAM, *ptSYSTEM_PARAM; // 15KByte

#define LCD_FRAME_WIDTH_SIZE_MAX	 	800
#define LCD_FRAME_WIDTH_HEIGHT_MAX		480
#define LCD_FRAME_BIT_CONFIG_MAX 		4

#define LCD_FRAME_BUFFER_ADDRESS	0x40000000
#define LCD_FRAME_BUFFER_SIZE	 	LCD_FRAME_WIDTH_SIZE_MAX*LCD_FRAME_WIDTH_HEIGHT_MAX*LCD_FRAME_BIT_CONFIG_MAX

#define KERNEL_BASEADDRESS		(LCD_FRAME_BUFFER_ADDRESS+((LCD_FRAME_BUFFER_SIZE + 0x100000)/0x100000)*0x100000)
#define SYSTEM_PARAM_BASEADDRESS ((KERNEL_BASEADDRESS-(sizeof(tSYSTEM_PARAM)+0x1000)/0x1000*0x1000 )) 


VOID OALArgsInit(DWORD BASEADDRESS);


#define SYSTEM_ARGSMAXSIZE		0x30000


//Suspend define 
#define PWRCTL_NORMAL						1
#define PWRCTL_SUSPEND						2
#define PWRCTL_SLEEP						3

//Suspend Memory structure
/*------------------------------------------------------------------
 mask & config data  |  core relative data  | kernel relative data
 0x050 ->            |  0x100 ->            | 0x300 ->
------------------------------------------------------------------*/
//valid check for dram's data
#define PWRCTL_DRAMMASK1       	0x424E4654 //"TFNB"
#define PWRCTL_DRAMMASK2       	0x6C426E45 //"EnBl"

#define SUS_DRAM_VBASE_ADDR 	0xA01F8000
#define SUS_DRAM_PBASE_ADDR 	0x401F8000

#define SUS_DRAM_VALID1_VADDR		(SUS_DRAM_VBASE_ADDR+0x58) //dram VA of suspend valid mask1
#define SUS_DRAM_VALID2_VADDR		(SUS_DRAM_VBASE_ADDR+0x5C) //dram VA of Suspend valid mask2
#define SUS_DRAM_VALID1_PADDR		(SUS_DRAM_PBASE_ADDR+0x58) //dram VA of suspend valid mask1
#define SUS_DRAM_VALID2_PADDR		(SUS_DRAM_PBASE_ADDR+0x5C) //dram VA of Suspend valid mask2


//core relative data
#define KSUS_DRAM_START_ADDR		(SUS_DRAM_VBASE_ADDR+0x50) //dram VA of Data Start
#define BSUS_DRAM_START_ADDR		(SUS_DRAM_VBASE_ADDR+0x54) //dram PA of Data Start
#define SUS_DRAM_ARMREG_VADDR	(SUS_DRAM_VBASE_ADDR+0x100) //relative Data Backup Address  (Virtual)
#define SUS_DRAM_ARMREG_PADDR	(SUS_DRAM_PBASE_ADDR+0x100) //relative Data Backup Address  (Physical)

//kernel relative data
#define SUS_DRAM_DATA_ADDR		(SUS_DRAM_VBASE_ADDR+0x300) 

/*
#define SUS_DRAM_VALID1_VADDR		0xA01F8058 //dram VA of suspend valid mask1
#define SUS_DRAM_VALID2_VADDR		0xA01F805C //dram VA of Suspend valid mask2
#define SUS_DRAM_VALID1_PADDR		0x401F8058 //dram VA of suspend valid mask1
#define SUS_DRAM_VALID2_PADDR		0x401F805C //dram VA of Suspend valid mask2


//core relative data
#define KSUS_DRAM_START_ADDR		0xA01F8050 //dram VA of Data Start
#define BSUS_DRAM_START_ADDR		0xA01F8054 //dram PA of Data Start
#define SUS_DRAM_ARMREG_VADDR		0xA01F8100 //relative Data Backup Address  (Virtual)
#define SUS_DRAM_ARMREG_PADDR		0x401F8100 //relative Data Backup Address  (Physical)

//kernel relative data
#define SUS_DRAM_DATA_ADDR			0xA01F8300 
*/

/************************************************************************************************
*  BOOT Arguments Structures
************************************************************************************************/


#ifdef __cplusplus
}
#endif

#endif // __ARGS_H__
