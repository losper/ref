/****************************************************************************
 *   FileName    : tcc_gpioexp.h
 *   Description : 
 ****************************************************************************
*
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
*
 ****************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


/*****************************************************************************
* Defines
******************************************************************************/
 // Device Address
#define  PCA9539HIGH    0xEE
#define  PCA9539LOW     0xE8
#define  PCA9538            0xE0


#define	MODE_IN		1
#define	MODE_OUT		0

#define PCA9539H_P0CFG  0x00 // All Pins are Output
#define PCA9539H_P1CFG  0x0F // Pin0~3 are Input, Others are Output
#define PCA9539L_P0CFG  0x00 // All Pins are Output
#define PCA9539L_P1CFG  0x00 // All Pins are Output
#define PCA9538_PCFG    0x08    // Pin3 is Input mode, Others are Output

#define PORTOUTPUT 0
#define PORTINPUT 1

#define   ON           1
#define   OFF         0


// PCA9539 HIGHER
//PORT0                     // Default
#define	ETHRST_	    0x0001  // DNP : Ethernet Controller Reset
#define	DXB0RST_	0x0002  // DMB, DAB Reset
#define	CAMRST_	    0x0004  // DNP : Camera Module Reset
#define	CASRST_	    0x0008  // DNP : CAS Reset
#define	AUTHRST_	0x0010  // iPod Auth Reset
#define	FMRST_		0x0020  // FM Transceiver Reset
#define	RTCRST_	    0x0040  // DNP : RTC Reset
#define	BTWAKE		0x0080  // DNP : Bluetooth Wakeup
//PORT1
#define	DXB1IRQ	    0x0100  // INPUT
#define	BTHWK		0x0200  // INPUT : Bluetooth Host Wakeup
#define	FMIRQ		0x0400  // INPUT : FM Receiver IRQ
#define	CPREADY	    0x0800  // INPUT : iPod CP Ready
#define	DXBGP0		0x1000  // DXBGP0
#define	CAMFLEN	    0x2000  // DNP : Camera Flash Light En/Disable
#define	LCDBLEN	    0x2000  // DNP : LCD Backlight En/Disable
#define	MUTECTL	    0x4000  // Audio Mute Control
#define	CASGP	    0x8000  // CASGP
#define TVSLEEP_    0x8000  // DNP : TV Sleep Signal
#define HDDRST_     0x8000  // DNP : HDD Reset

// PCA9539 LOWER
//PORT0
#define	ATAPI		0x0001  // IDE Disk Interface
#define	LCD			0x0002  // LCD Power
#define	LVDSIVT		0x0004  // LVDS Inverter
#define	CAM			0x0008  // Camera Module Power
#define	CODEC		0x0010  // External Audio CODEC
#define	FMTC		0x0020  // FM Transceiver
#define	SD0			0x0040  // SD Card Slot 0
#define	SD1			0x0080  // SD Card Slot 1
//PORT1
#define	BT			0x0100  // Bluetooth
#define	CAS			0x0200  // CAS
#define	CAN			0x0400  // CAN Interface Controller
#define	ETH			0x0800  // Ethernet Controller
#define	DXB			0x1000  // DMB, DAB Power
#define	IPOD		0x2000  // iPOD Connection Power
#define	PWRGP4		0x4000  // GPIO4 Power
#define	LVDSLPCTRL	0x8000  // LVDS LCD Controller


//PCA9538 PORT0
#define     DVBUS       0x01    // USB Device VBUS
#define     HVBUS       0x02    // USB Host VBUS
#define     SATAHDMI    0x04    // HDMI_LVDS Power
#define     PWRGP0      0x08    // GPIO0 Power
#define     PWRGP1      0x80    // GPIO1 Power
#define     PWRGP2      0x10    // GPIO2 Power 
#define     PWRGP3      0x20    // GPIO3 Power 
#define     VCORECTL    0x40    // Core Voltage



/*****************************************************************************
* Enum
******************************************************************************/
// PCA9539
enum {
	CMD_PORT0_INPUT = 0,
	CMD_PORT1_INPUT,
	CMD_PORT0_OUTPUT,
	CMD_PORT1_OUTPUT,
	CMD_PORT0_POLINVT,
	CMD_PORT1_POLINVT,
	CMD_PORT0_CONFIG,
	CMD_PORT1_CONFIG,
};
// PCA9538
enum {
    CMD_PORT_INPUT = 0,
    CMD_PORT_OUTPUT,
    CMD_PORT_POLINVT,
    CMD_PORT_CONFIG,
};



/*****************************************************************************
* Structures
******************************************************************************/
typedef struct _GXPINFO{
    unsigned short    uiDevice;
    unsigned short    uiPort;
    unsigned int    uiState;
}GXPINFO, *PGXPINFO;


/*****************************************************************************
* External Variables
******************************************************************************/

/*****************************************************************************
* External Functions
******************************************************************************/

#ifdef __cplusplus
 } 
#endif
