/****************************************************************************
 *	 FileName	 : tcc_rtc.h
 *	 Description : 
 ****************************************************************************
 *
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCC_RTC_H__
#define __TCC_RTC_H__

#ifdef __cplusplus
extern 
"C" { 
#endif

/*****************************************************************************
* Function Name : tcc_rtc_gettime()
******************************************************************************/
void tcc_rtc_gettime(unsigned int devbaseaddresss,void *pTime);

/*****************************************************************************
* Function Name : tcc_rtc_settime()
******************************************************************************/
void tcc_rtc_settime(unsigned int devbaseaddresss, void *pTime);

/*****************************************************************************
* Function Name : tcc_rtc_checkvalidtime()
******************************************************************************/
unsigned int	tcc_rtc_checkvalidtime(unsigned int devbaseaddresss);
#ifdef __cplusplus
 } 
#endif

#endif //__TCC_RTC_H__

