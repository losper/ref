
/****************************************************************************
*   FileName    : tca_sensor_micron_MT9D111.h
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/
#ifndef __TCC_VDEC_H__
#define __TCC_VDEC_H__

#ifdef __cplusplus
extern "C" {
#endif
void tcc_vdec_hwreset(void *pGPIORegAddr);
int tcc_vdec_outputdetect(void *pGPIORegAddr);
void tcc_vdec_regcheck(void);
void tcc_vdec_initialize(void);
void tcc_vdec_outputctrl(int OnOff);
void tcc_vdec_setcampwrctl(int pwrctl_onoff);
void tcc_vdec_initializei2c(void);
void tcc_vdec_deiniti2c(void);
#ifdef __cplusplus
 } 
#endif
#endif	//__TCC_VDEC_H__
/* end of file */