#ifndef __FWDN_PROTOCOL_V2__
#define __FWDN_PROTOCOL_V2__

////////////////////////////////////////////////////////////////////////////
//
//				FWDN Protocol V3
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//		FWDN Command
////////////////////////////////////////////////////////////////////////////
#define FWDN_CMD_NONE							0x0000
#define FWDN_CMD_UBS_PING						0x0001
#define FWDN_CMD_UBS_INITCODE_LOAD				0x0002
#define FWDN_CMD_UBS_ROM_LOAD					0x0003

#define FWDN_CMD_PING							0x0100
#define FWDN_CMD_DEVICE_RESET					0x0101
#define FWDN_CMD_DEVICE_SETTING					0x0102
#define FWDN_CMD_DEVICE_INFO_READ				0x0103
#define FWDN_CMD_SERIAL_NUMBER_WRITE			0x0104
#define FWDN_CMD_FIRMWARE_WRITE					0x0105
#define FWDN_CMD_SESSION_START					0x0106
#define FWDN_CMD_SESSION_END					0x0107

#define FWDN_CMD_DISK_SELECT					0x0200
#define FWDN_CMD_DISK_INIT						0x0201
#define FWDN_CMD_DISK_INFO_READ					0x0202

#define FWDN_CMD_DISK_HIDDEN_INFO_READ			0x0210
#define FWDN_CMD_DISK_HIDDEN_CLEAN				0x0211
#define FWDN_CMD_DISK_HIDDEN_WRITE				0x0212
#define FWDN_CMD_DISK_HIDDEN_READ				0x0213
#define FWDN_CMD_DISK_MTD_WRITE					0x0214

#define FWDN_CMD_DISK_DATA_PARTITION			0x0220
#define FWDN_CMD_DISK_DATA_READ					0x0221
#define FWDN_CMD_DISK_DATA_WRITE				0x0222
#define FWDN_CMD_DISK_DATA_IMAGE_WRITE			0x0223

#define FWDN_CMD_DISK_DATA_FS_MOUNT				0x0230
#define FWDN_CMD_DISK_DATA_FS_FORMAT			0x0231
#define FWDN_CMD_DISK_DATA_FS_MKDIR				0x0232
#define FWDN_CMD_DISK_DATA_FS_CHDIR				0x0233
#define FWDN_CMD_DISK_DATA_FS_FILE_WRITE		0x0234

#define FWDN_CMD_DISK_DUMP_INFO_READ			0x0240
#define FWDN_CMD_DISK_DUMP_BLOCK_READ			0x0241

#define	FWDN_CMD_TEST_SEND						0x0300
#define FWDN_CMD_TEST_RECEIVE					0x0301

#define FWDN_CMD_TNFTL_V5_DEBUG					0x0F00


////////////////////////////////////////////////////////////////////////////
//		FWDN Response Ack Type
////////////////////////////////////////////////////////////////////////////
#define FWDN_RSP_NACK						0x00
#define FWDN_RSP_ACK						0x01
#define FWDN_RSP_NYET						0x02


////////////////////////////////////////////////////////////////////////////
//		FWDN Command / Response Signatures
////////////////////////////////////////////////////////////////////////////
#define FWDN_COMMAND_SIGNATURE				0x43445746L		//"FWDC" ; FWDn Command
#define FWDN_RESPONSE_SIGNATURE				0x52445746L		//"FWDR" ; FWDn Response


#define FWDN_EXTRA_RSP_MAX_SIZE				0xFF

#if defined(_WINCE_)
#pragma pack(push, 1)
#endif

typedef struct _tag_FWDN_COMMAND_T
{
	unsigned long	Signature;
	unsigned short	CmdType;
	unsigned short	ExtraCmdSize;
	unsigned long	DataSize;
	unsigned long	Param0;
	unsigned long	Param1;
	unsigned long	Param2;

#if defined(_LINUX_)
} __attribute__((packed)) FWDN_COMMAND_T;
#else
} FWDN_COMMAND_T;
#endif

typedef struct _tag_FWDN_RESPONSE_T
{
	unsigned long	Signature;
	unsigned short	CmdType;
	unsigned char	AckType;
	unsigned char	ExtraRspSize;
	unsigned long	DataSize;
	unsigned long	Param0;
	unsigned long	Param1;
	unsigned long	Param2;

#if defined(_LINUX_)
} __attribute__((packed)) FWDN_RESPONSE_T;
#else
} FWDN_RESPONSE_T;
#endif

#if defined(_WINCE_)
#pragma pack(pop)
#endif

void FWDN_PROT_CheckCommand(void);

#endif //__FWDN_PROTOCOL_V2__
