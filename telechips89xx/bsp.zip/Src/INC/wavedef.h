#ifndef __WAVE_DEFINE_H__
#define __WAVE_DEFINE_H__

enum
{
	NOT_INPUT = 0,
	MIC_INPUT,
	LINE_IN_INPUT,
	FMR_INPUT,
};

#endif
