/****************************************************************************
*   FileName    : reg_physical.h
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
****************************************************************************/

#ifndef __REG_PHYSICAL_H__
#define __REG_PHYSICAL_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
#if defined(TCC89X)
	#include "TCC89x_Physical.h"
	#include "TCC89x_Structures.h"
#elif defined(TCC91X)
	#include "TCC91x_Physical.h"
	#include "TCC91x_Structures.h"
#elif defined(TCC92X)
	#include "TCC92x_Physical.h"
	#include "TCC92x_Structures.h"
#endif
*/
#include "TCC89x_Physical.h"
#include "TCC89x_Structures.h"

#ifdef __cplusplus
}
#endif

#endif // __REG_PHYSICAL_H__
