/****************************************************************************
*   FileName    : tcc_adconv.h
*   Description : 
****************************************************************************
*
*   TCC Version : 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*	resivion: %v
****************************************************************************/


#ifndef __TCC_ADCONV_H__
#define __TCC_ADCONV_H__
//

#ifdef __cplusplus 
extern "C" {
#endif



unsigned int    tcc_adc_adcinitialize(void);
unsigned int    tcc_adc_portinitialize(void);
unsigned int    tcc_adc_read(unsigned int channel);
unsigned int    tcc_adc_tsautoread(int* xpos, int* ypos);
unsigned int    tcc_adc_powerdown(void);
unsigned int    tcc_adc_powerup(void);




#ifdef __cplusplus 
}
#endif
#endif //__TCC_ADCONV_H__