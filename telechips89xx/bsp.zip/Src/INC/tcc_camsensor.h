
/****************************************************************************
*   FileName    : tca_sensor_micron_MT9D111.h
*   Description : 
****************************************************************************
*
*   TCC Version 1.0
*   Copyright (c) Telechips, Inc.
*   ALL RIGHTS RESERVED
*
***************************************************************************/
#ifndef __TCC_CAMSENSOR_H__
#define __TCC_CAMSENSOR_H__

#ifdef __cplusplus
extern "C" {
#endif

int tcc_camsensor_initi2c(void);
int tcc_camsensor_deiniti2c(void);
void tcc_camsensor_capture(unsigned char ucOnOff);
void tcc_camsensor_cameramoduleinit(unsigned char ucPreviewMode);
void tcc_camsensor_contextadata(void);
void tcc_gpioexp_setcampwrctl(int pwrctl_onoff);
void tcc_camreset_onoff(void *pGPIORegAddr, unsigned int uiON);
unsigned int tcc_cam_checki2s(unsigned int cam_mod);
#ifdef __cplusplus
 } 
#endif
#endif	//__TCC_CAMSENSOR_H__
/* end of file */
