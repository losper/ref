/****************************************************************************
 *	 FileName	 : tcc_off.h
 *	 Description : 
 ****************************************************************************
 *
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#ifndef __TCC_OFF_H__
#define __TCC_OFF_H__

#ifdef __cplusplus
extern 
"C" { 
#endif

/*****************************************************************************
* Function Name : tca_off_entersleep()
******************************************************************************/
void tcc_off_entersleep(void);

/*****************************************************************************
* Function Name : tca_off_entershutdown()
******************************************************************************/
void tcc_off_entersuspend(void);
#ifdef __cplusplus
 } 
#endif

#endif //__TCC_OFF_H__

