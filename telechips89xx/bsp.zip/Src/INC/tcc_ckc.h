/****************************************************************************
 *	 FileName	 : tcc_ckc.h
 *	 Description : 
 ****************************************************************************
*
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
*
 ****************************************************************************/
/*****************************************************************************
*
* External Functions
*
******************************************************************************/
#ifndef __TCC_CKC_H__
#define __TCC_CKC_H__

#include "bsp.h"

int tcc_ckc_setiobus(unsigned int sel, unsigned int mode)
{
	int retVal = -1;

	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_SET_PERIBUS;
	stCKC.prbname = sel;
	stCKC.mode = mode;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return retVal;
}

int tcc_ckc_set_iobus_swreset(unsigned int periname)
{
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_SET_PERISWRESET;
	stCKC.prbname = periname;		

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return retVal;
}

int tcc_ckc_setperi(unsigned int periname, unsigned int isenable,unsigned int freq , unsigned int sor )
{
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_SET_PERI;
	stCKC.pckcname = periname;		//PERI79_USB11H
	stCKC.pckcenable= isenable;			//enable or disable
	stCKC.pckcsource= sor;			//CLKFROM48M
	stCKC.pckcfreq = freq;			//48 (48Mhz)

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);
	return retVal;
}


int tcc_ckc_getperi(unsigned int periname)
{
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_GET_PERI;
	stCKC.pckcname = periname;		//PERI79_USB11H

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	if(retVal != 0)
		retVal = stCKCInfo.pckcfreq;

	return retVal;
}

int tcc_ckc_setsmui2c(unsigned int freq)
{
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_SET_SMUI2C;
	stCKC.pckcfreq = freq;		//PERI79_USB11H

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	if(retVal != 0)
		retVal = stCKCInfo.pckcfreq;

	return retVal;
}

int tcc_ckc_getbus(void)
{
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_GET_BUS;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	if(retVal != 0)
		retVal = stCKCInfo.currentbusfreq;

	return retVal;
}

int tcc_ckc_getcpu(void)
{
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_GET_CPU;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	if(retVal != 0)
		retVal = stCKCInfo.currentcpufreq;

	return retVal;
}

int tcc_ckc_setfbusctrl(unsigned int clkname,unsigned int isenable,unsigned int md,unsigned int freq, unsigned int sor)
{
	// Physical Address 0xF0400000~0xF040001C 
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;
	md = 0;
	
	stCKC.ioctlcode 	= IOCTL_CKC_SET_FBUS;
	/*
	stCKC.pckcname  	= clkname;
	stCKC.pckcenable	= isenable;
	stCKC.mode			= md; // Normal Mode
	stCKC.pckcfreq		= freq;
	stCKC.pckcsource	= sor;
	*/
	stCKC.fbusname  	= clkname;
	stCKC.fbusenable	= isenable;
	stCKC.mode			= md; // Normal Mode
	stCKC.fbusfreq		= freq;
	stCKC.fbussource	= sor;
	
	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return retVal;
}

int tcc_ckc_getfbusctrl(unsigned int clkname)
{
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode 	= IOCTL_CKC_GET_FBUS;
//	stCKC.pckcname		= clkname;
	stCKC.fbusname		= clkname;
	
	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return stCKCInfo.fbusfreq;
}

int tcc_ckc_setcpu(unsigned int cpudiv)
{
	// Physical Address 0xF0400000~0xF040001C 
	int retVal = -1;
	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode 	= IOCTL_CKC_SET_CPU;
	stCKC.cpudivider	= cpudiv;
	
	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return retVal;
}


int tcc_ckc_setpmupoweroff(unsigned int sel, unsigned int mode)
{
	int retVal = -1;

	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_SET_PMUPOWER;
	stCKC.pmuoffname = sel;
	stCKC.mode = mode;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return retVal;
}

int tcc_ckc_getpmupoweroff(unsigned int sel)
{
	int retVal = -1;

	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_GET_PMUPOWER;
	stCKC.pmuoffname = sel;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return stCKCInfo.state;
}

int tcc_ckc_setddipoweroff(unsigned int sel, unsigned int mode)
{
	int retVal = -1;

	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_SET_DDIPWDN;
	stCKC.ddipdname= sel;
	stCKC.mode = mode;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return retVal;
}

int tcc_ckc_getddipoweroff(unsigned int sel)
{
	int retVal = -1;

	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_GET_DDIPWDN;
	stCKC.ddipdname= sel;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return stCKCInfo.state;
}

int tcc_ckc_setvideobuscfgpwdn(unsigned int sel, unsigned int mode)
{
	int retVal = -1;

	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_SET_VIDEOCFGPWDN;
	stCKC.videobuscfgname= sel;
	stCKC.mode = mode;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return retVal;
}

int tcc_ckc_getvideobuscfgpwdn(unsigned int sel)
{
	int retVal = -1;

	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_GET_VIDEOCFGPWDN;
	stCKC.videobuscfgname= sel;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return stCKCInfo.state;
}

int tcc_ckc_setvideobuscfgswreset(unsigned int sel, unsigned int mode)
{
	int retVal = -1;

	stckcioctl	stCKC;
	stckcinfo	stCKCInfo;
	unsigned long	returnedbyte;

	stCKC.ioctlcode = IOCTL_CKC_SET_VIDEOCFGSWRESET;
	stCKC.videobuscfgname= sel;
	stCKC.mode = mode;

	retVal = KernelIoControl(IOCTL_HAL_TCCCKC, &stCKC, sizeof(stckcioctl), &stCKCInfo, sizeof(stckcinfo), &returnedbyte);

	return retVal;
}

#endif /*__TCC_CKC_H__ */


