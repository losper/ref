
/****************************************************************************
 *   FileName    : tcc_wave.h
 *   Description : 
 ****************************************************************************
 *
 *   TCC Version 1.0
 *   Copyright (c) Telechips, Inc.
 *   ALL RIGHTS RESERVED
 *
 ****************************************************************************/
#include <windows.h>
#include "wavedef.h"
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

extern HANDLE ghI2C;

unsigned int tcc_i2c_open(void *hI2C);

int tea_wave_i2c_write(void * hI2C, unsigned char hb, unsigned char lb);
int tcc_adma_interrupt_done(void);

//Codec chip control
unsigned int tcc_setinputoutputmode(void *hI2C, unsigned int nMode);
unsigned int tcc_setinputmode(void *hI2C, unsigned int nMode);
unsigned int tcc_setoutputmode(void *hI2C, unsigned int nMode);
unsigned int tcc_setnormalmode(void *hI2C);
unsigned int tcc_setsleepmode(void *hI2C);
unsigned int tcc_setoutputgain(void *hI2C, unsigned int nGain);
unsigned int tcc_setinputgain(void *hI2C, unsigned int nGain);
unsigned int tcc_setoutputmute(void *hI2C, unsigned int nMode);
unsigned int tcc_getoutputmutestatus(void);
unsigned int tcc_setinputmute(void *hI2C, unsigned int nMode);
unsigned int tcc_initcodec(void *hI2C);

//Telechips hw control
unsigned int tcc_dma_clrstatus(void *pADMABaseAddr, unsigned int nDmanum);
unsigned int tcc_irq_getnumber(void);
unsigned int tcc_dma_getstatus(void *pADMABaseAddr, unsigned int nDmanum);
unsigned int tcc_tcc_initport(void *pGPIOBaseAddr);
unsigned int tcc_dma_setsrcaddr(void *pADMABaseAddr, unsigned int DADONum, unsigned int nDmanum, unsigned int nAddr);
unsigned int tcc_dma_setdestaddr(void *pADMABaseAddr, unsigned int DADINum, unsigned int nDmanum, unsigned int nAddr);
unsigned int tcc_dma_control(void *pADMABaseAddr, void *pADMADAIBaseAddr, void *pADMASPDIFTXBaseAddr,
	unsigned int nMode, unsigned int nDmanum, unsigned int nInMode);
unsigned int tcc_i2s_setregister(void *pADMADAIBaseAddr, unsigned int nRegval);
unsigned int tcc_i2s_getregister(void *pADMADAIBaseAddr);
unsigned int tcc_i2s_init(void *pADMADAIBaseAddr, void *pADMABaseAddr, void *pADMASPDIFTXBaseAddr, unsigned int nOutputDma, unsigned int InputDma,unsigned int AUDIO_DMA_PAGE_SIZE, 
		unsigned int AUDIO_DMA_IN_PAGE_SIZE, unsigned int AUDIO_DMA_PAGE_SIZE_SPIDF,unsigned int SAMPLERATE);
void tcc_i2s_start(void *pADMADAIBaseAddr, void *pADMASPDIFTXBaseAddr, unsigned int nMode);

void tcc_i2s_setclock(void *pADMASPDIFTXBaseAddr, unsigned int ClockRate);
void tcc_spdif_setclock(void *pADMASPDIFTXBaseAddr, unsigned int ClockRate);
void tea_gpioexp_setmutectl(int mutectl_onoff);
void tcc_gpioexp_setcodepwrctl(int pwrctl_onoff);
#ifdef __cplusplus
}
#endif
