
/****************************************************************************
 *	 FileName	 : tcc_backlight.h
 *	 Description : 
 ****************************************************************************
 *
 *	 TCC Version 1.0
 *	 Copyright (c) Telechips, Inc.
 *	 ALL RIGHTS RESERVED
 *
 ****************************************************************************/

#ifndef __TCC_BACKLIGHT_H__
#define __TCC_BACKLIGHT_H__

#ifdef __cplusplus
extern 
"C" { 
#endif
void tcc_bkl_init(unsigned int tmr_vaddr, unsigned int gpio_vaddr);
void tcc_bkl_powerup(unsigned int tmr_vaddr, unsigned int gpio_vaddr);
void tcc_bkl_powerdown(unsigned int tmr_vaddr, unsigned int gpio_vaddr);
void tcc_bkl_setpowerval(int inValue, unsigned int tmr_vaddr);
int  tcc_bkl_getpowerval(unsigned int tmr_vaddr);
int  tcc_bkl_gettmrref(unsigned int tmr_vaddr);
#ifdef __cplusplus
 } 
#endif
#endif //__TCC_BACKLIGHT_H__

