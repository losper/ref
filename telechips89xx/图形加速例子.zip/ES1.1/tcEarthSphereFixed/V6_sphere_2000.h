//#ifndef NULL
//#define NULL 0
//#endif
/* Multifunctional Resource File Format */
#include <EGL/egl.h>
#include <GLES/gl.h>

extern GLint sphere_9680pv[];
extern GLint sphere_9680pc[];
extern GLushort sphere_9680pf[];


extern const GLint sphere_980pv[];
extern const GLint sphere_980pc[];
extern const GLushort sphere_980pf[];
