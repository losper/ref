// tcEarth11.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "tcEarth11.h"
#include <windows.h>
#include <commctrl.h>

#include "V6_sphere_2000.h"
#include "GLFont.h"
#include "DeviceConfig.h"

#define USE_VBO


#define glF(x)	((GLfixed)((x)*(1<<16)))
#define glD(x)	glF(x)
#define GL_F	GL_FIXED
typedef GLfixed GLf;

//VBO variables
GLuint nBufferName980[3];
GLuint nBufferName9680[3];

enum BUFFERTYPE{
	VERTEX_BUFFER,
	INDEX_BUFFER,
	TEXTURECOORD_BUFFER,
};
//VBO variables
enum IMAGETYPE{
	EARTH_IMG,
	MARS_IMG,
};
GLfloat	xrot;							// X Rotation
GLfloat	yrot;							// Y Rotation
GLfloat xspeed;					// X Rotation Speed
GLfloat yspeed;					// Y Rotation Speed

int drawMode = GL_TRIANGLES;
int mRenderCnt;
int m_nCnt =0;
CGLFont* m_pGLFont;
float	fps = 0.0f;			// Holds The Current FPS (Frames Per Second) 

TGAImage imgSphere[2];
bool isRenderMode;

void GL_Draw();
void Render();
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val);
void InitGLES();
void OrthoBegin(void);
void OrthoEnd(void);
float framerate(int Poly);
bool AppInit();
void AppEnd();
void GetStatus(void);
double GetTime();

//TGAImage TestSphere[50];
#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle

// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);


void InitGLES()
{
	bool isb; isb = false;
	
	glClearColorx(glF(1.0f), glF(0.0f), glF(0.0f), glF(1.0f));


	glEnable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);	
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_FOG);
	
	glClearDepthx(glF(1.0f)); 
	
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	glViewport(0, 0, LCD_WIDTH, LCD_HEIGHT);

	// Set Projection 
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glPerspectivef( 3.141592654f/4.0f, 1.0f, 1.0f, 1000.0f );	

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);


    //Texture Load
    isb = LoadTGA(&imgSphere[EARTH_IMG],"NAND/data/sphereimage.tga");
	if(isb==false)
	{
		printf("===EARTH_IMG==NotLoaded====\n");
	}
	isb = LoadTGA(&imgSphere[MARS_IMG],"NAND/data/mars512.tga");
	if(isb==false)
	{
		printf("===MARS_IMG==NotLoaded====\n");
	}
	free(imgSphere[EARTH_IMG].imageData);
	imgSphere[EARTH_IMG].imageData=NULL;

	free(imgSphere[MARS_IMG].imageData);
	imgSphere[MARS_IMG].imageData=NULL;

#ifdef USE_VBO
    //980
    glGenBuffers(3,&nBufferName980[0]);
	
    glBindBuffer(GL_ARRAY_BUFFER,nBufferName980[VERTEX_BUFFER]);
	glBufferData(GL_ARRAY_BUFFER,1677*sizeof(GLfixed),sphere_980pv,GL_STATIC_DRAW);


	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,nBufferName980[INDEX_BUFFER]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,2940*sizeof(GLushort),sphere_980pf,GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER,nBufferName980[TEXTURECOORD_BUFFER]);
	glBufferData(GL_ARRAY_BUFFER,1118*sizeof(GLfixed),sphere_980pc,GL_STATIC_DRAW);

    //9680
	glGenBuffers(3,&nBufferName9680[0]);

	glBindBuffer(GL_ARRAY_BUFFER,nBufferName9680[VERTEX_BUFFER]);
	glBufferData(GL_ARRAY_BUFFER,15132*sizeof(GLfixed),sphere_9680pv,GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,nBufferName9680[INDEX_BUFFER]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,29040*sizeof(GLshort),sphere_9680pf,GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER,nBufferName9680[TEXTURECOORD_BUFFER]);
	glBufferData(GL_ARRAY_BUFFER,10088*sizeof(GLfixed),sphere_9680pc,GL_STATIC_DRAW);

#endif

}
void GL_Draw()
{

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

    glEnable(GL_TEXTURE_2D);
	

//VBO Bind
#ifdef USE_VBO

if(isRenderMode ==true)
	{

		glBindTexture(GL_TEXTURE_2D , imgSphere[EARTH_IMG].texID ); 
		
		glBindBuffer(GL_ARRAY_BUFFER,nBufferName980[VERTEX_BUFFER]);//Vertex buffer
		glVertexPointer(3, GL_FIXED, 0, 0);

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,nBufferName980[INDEX_BUFFER]);//index buffer

		glBindBuffer(GL_ARRAY_BUFFER,nBufferName980[TEXTURECOORD_BUFFER]);//Texture Coord buffer
		glTexCoordPointer(2, GL_FIXED, 0, 0);


		glScalex(glF(0.3f),glF(0.3f),glF(0.3f));

		glPushMatrix(); //1
		glTranslatex(glF(2.0f),glF(2.0f),glF(-10.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();


		glPushMatrix(); //2
		glTranslatex(glF(-2.0f),glF(2.0f),glF(-10.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();

		glPushMatrix(); //3
		glTranslatex(glF(0.0f),glF(0.0f),glF(-10.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();

		glPushMatrix(); //4
		glTranslatex(glF(2.0f),glF(-2.0f),glF(-10.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();

		glPushMatrix(); //5
		glTranslatex(glF(-2.0f),glF(-2.0f),glF(-10.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();

		glPushMatrix();
		glRotatex(glF(xrot),glF(0.0f),glF(0.0f),glF(1.0f));
		glTranslatex(glF(3.0f),glF(2.0f),glF(-16.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();


		glPushMatrix(); //2
		glTranslatex(glF(-2.0f),glF(2.0f),glF(-16.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();

		glPushMatrix(); //3
		glTranslatex(glF(1.0f),glF(0.0f),glF(-16.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();

		glPushMatrix(); //4
		glTranslatex(glF(2.0f),glF(-2.0f),glF(-16.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();

		glPushMatrix(); //5
		glTranslatex(glF(-2.0f),glF(-2.0f),glF(-16.0f));
		glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));
		glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, 0);
		glPopMatrix();

	}
	else
	{
		glBindTexture(GL_TEXTURE_2D , imgSphere[MARS_IMG].texID ); 
		
		glBindBuffer(GL_ARRAY_BUFFER,nBufferName9680[VERTEX_BUFFER]);//Vertex buffer
		glVertexPointer(3, GL_FIXED, 0, 0);//vertex buffer Disable

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,nBufferName9680[INDEX_BUFFER]);//Index buffer

		glBindBuffer(GL_ARRAY_BUFFER,nBufferName9680[TEXTURECOORD_BUFFER]);//Texture coord buffer
		glTexCoordPointer(2, GL_FIXED, 0, 0);//Texture coord Pointer Disable
		//VBO Bind

		glTranslatex(glF(0.0f),glF(1.0f),glF(-5.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));

		glDrawElements(drawMode, 9680 * 3, GL_UNSIGNED_SHORT, 0);



	}
	
	
	//VBO Mode Disable
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0); 
	glBindBuffer(GL_ARRAY_BUFFER, 0); 
	
#else
glBindTexture(GL_TEXTURE_2D , imgSphere[EARTH_IMG].texID ); 
glVertexPointer(3, GL_FIXED, 0, sphere_980pv); 
glTexCoordPointer(2, GL_FIXED, 0, sphere_980pc);

glScalex(glF(0.3f),glF(0.3f),glF(0.3f));
glPushMatrix(); //1
    glTranslatex(glF(2.0f),glF(2.0f),glF(-10.0f));
    glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
	glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));

    glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, sphere_980pf); 


glPopMatrix();


glPushMatrix(); //1
    glTranslatex(glF(-2.0f),glF(2.0f),glF(-10.0f));
    glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
	glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));

    glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, sphere_980pf); 



glPopMatrix();
  
glPushMatrix(); //1
    glTranslatex(glF(0.0f),glF(0.0f),glF(-10.0f));
    glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
	glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));

    glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, sphere_980pf); 
glPopMatrix();

glPushMatrix(); //1
    glTranslatex(glF(2.0f),glF(-2.0f),glF(-10.0f));
    glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
	glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));



    glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, sphere_980pf); 
glPopMatrix();


glPushMatrix(); //1
    glTranslatex(glF(-2.0f),glF(-2.0f),glF(-10.0f));
    glRotatex(glF(xrot),glF(1.0f),glF(0.0f),glF(0.0f));
	glRotatex(glF(yrot),glF(0.0f),glF(1.0f),(0.0f));

    glDrawElements(drawMode, 980 * 3, GL_UNSIGNED_SHORT, sphere_980pf); 
glPopMatrix();

#endif

    xrot+=2.0f;
  	yrot+=2.0f;
    
    if(xrot >=360.0f)
        xrot =0.0f;

    if(yrot >=360.0f)
        yrot =0.0f;

  

	
	

}
///////////////////////////////////////////////////////////////////////////////
void Render()
{
	
	char		text[256];	

	
	fps =  framerate(5);
	sprintf(text,"%d",(int)fps);
		
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	OrthoBegin();
	m_pGLFont->Draw2DStringLine(750*CONVERTFIXED,450*CONVERTFIXED,1*CONVERTFIXED,1*CONVERTFIXED,text,false);
	OrthoEnd();

	GL_Draw();
	EGLFlush();
	mRenderCnt++;
	if(mRenderCnt >=500)
	{
		isRenderMode = (isRenderMode == true)? false : true;
		mRenderCnt = 0;
	}

}

///////////////////////////////////////////////////////////////////////////////
//******* Main Render Loop *******************/

bool AppInit()
{
    bool isb ;
	isb = false;
    
    if(!CreateEGL())
		return false;

	InitGLES();
	GetStatus();

    isRenderMode = true;
    mRenderCnt = 0;

    m_pGLFont = new CGLFont;
	m_pGLFont->CreateASCIIFont();

	isb = LoadTGA(&m_pGLFont->sTgaFontImage,"NAND/data/font_modify.tga");

	if(isb==false)
	{
			RETAILMSG(1,(TEXT("=TGAImages load error==\n")));
	}

    return true;

}
///////////////////////////////////////////////////////////////////////////////
void AppEnd()
{	

	glDeleteTextures (1, &imgSphere[EARTH_IMG].texID);
	glDeleteTextures (1, &imgSphere[MARS_IMG].texID);
	
	glDeleteBuffers(3,&nBufferName980[0]);
	glDeleteBuffers(3,&nBufferName9680[0]);

	SAFE_DELETE(m_pGLFont);

	DeleteEGL();
	RETAILMSG(1,(TEXT("==APP==END\n")));


}


///////////////////////////////////////////////////////////////////////////////




///////////////////////////////////////////////////////////////////////////////
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val)
{
	GLfloat top = (GLfloat)(tan(fov*0.5) * near_val);
	GLfloat bottom = -top;
	GLfloat left = aspect * bottom;
	GLfloat right = aspect * top;
	
	glFrustumx(glF(left), glF(right), glF(bottom), glF(top), glF(near_val),glF(far_val));
    
}
//////////////////////////////////////////////////////////////////////////////////////


void OrthoBegin(void)
{
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrthox(0,LCD_WIDTH*65536,0,LCD_HEIGHT*65536,-1.0*65536,1.0*65536);	

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();


}

void OrthoEnd(void)
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix(); 
}

/*************Calculate frame rate********/
float framerate(int Poly)
{
    static float previous = 0;
    static int framecount = 0;
	static float finalfps = 0;
    framecount++;

    if ( framecount == 50 )
    {
        float time = (float)GetTime();
        float seconds = time - previous;
        float fps = framecount / seconds;
        previous = time;
		finalfps = fps;
        framecount = 0;
    }

  	
	return finalfps;
}

double GetTime()
{
 	clock_t sTime;
	double dSec=0;
	dSec=0.001 * GetTickCount();
 
	return dSec;
}

void GetStatus(void)
{
    int status =0;

    glGetIntegerv(GL_MAX_LIGHTS,&status);
    RETAILMSG(1,(TEXT("GL_MAX_LIGHTS %d==\n"),status));

    glGetIntegerv(GL_MAX_TEXTURE_SIZE,&status); 
    RETAILMSG(1,(TEXT("GL_MAX_TEXTURE_SIZE %d==\n"),status));

    glGetIntegerv(GL_MAX_TEXTURE_UNITS,&status); 
    RETAILMSG(1,(TEXT("GL_MAX_TEXTURE_UNITS %d==\n"),status)); 
	
	glGetIntegerv(GL_MAX_ELEMENTS_VERTICES,&status); 
    RETAILMSG(1,(TEXT("GL_MAX_ELEMENTS_VERTICES %d==\n"),status)); 

   glGetIntegerv(GL_MAX_ELEMENTS_INDICES,&status); 
   RETAILMSG(1,(TEXT("GL_MAX_ELEMENTS_INDICES %d==\n"),status)); 
  
    glGetIntegerv(GL_MAX_MODELVIEW_STACK_DEPTH,&status); 
    RETAILMSG(1,(TEXT("GL_MAX_MODELVIEW_STACK_DEPTH %d==\n"),status)); 
	
	glGetIntegerv(GL_MAX_PROJECTION_STACK_DEPTH,&status); 
    RETAILMSG(1,(TEXT("GL_MAX_PROJECTION_STACK_DEPTH %d==\n"),status)); 
	
	glGetIntegerv(GL_MAX_TEXTURE_STACK_DEPTH,&status); 
    RETAILMSG(1,(TEXT("GL_MAX_TEXTURE_STACK_DEPTH %d==\n"),status)); 

	glGetIntegerv(GL_MAX_VIEWPORT_DIMS,&status); 
    RETAILMSG(1,(TEXT("GL_MAX_VIEWPORT_DIMS %d==\n"),status)); 

}
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TCEARTH11));

	// Main message loop:
	for (;;) {
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			Render();
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TCEARTH11));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_TCEARTH11, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }

   hWnd = CreateWindowEx(WS_EX_TOPMOST,szWindowClass, szTitle, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_VISIBLE,
      0, 0, 800, 480, NULL, NULL, hInstance, NULL);

    AppInit();
	
	ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
            PostQuitMessage(0);
            break;
		case WM_KEYDOWN:
			{
				RETAILMSG(1,(TEXT("KeyDOWN %d==\n"),wParam));
					
					
				switch(wParam)
				{
				case 38:
					{
						AppEnd();			
						PostQuitMessage(0);
					}
					break;
				
				}
			}
			break;	
		case WM_LBUTTONDOWN :
			{
			int	xPos = LOWORD(lParam); 
			int	yPos = HIWORD(lParam);
				RETAILMSG(1,(TEXT("LBUTTON_DOWN %d==%d\n"),xPos,yPos));
			}
			break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
