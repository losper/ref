// tcMatrixPalette.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "tcMatrixPalette.h"
#include <windows.h>
#include <commctrl.h>
#include <math.h>

#include "MatrixPalette_hobody_img.h"
#include "DeviceConfig.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle

// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);


#define glF(x)	((GLfixed)((x)*(1<<16)))
#define glD(x)	glF(x)
#define GL_F	GL_FIXED
typedef GLfixed GLf;
	
#define BLEND_4
//////////////////DATA
#define DISTANCE glF(-5.0f)*2-glF(1.0f)
#define ONE		glF(1.0f)
#define X_ONE	glF(0.5f)

#define ZERO	glF(0.0f)
#define PLUS	glF(2.1f)
#define XPLUS	glF(1.0f)

GLfixed MatrixPalette_SkinnedMesh_Vertex_01[] = {
	X_ONE-XPLUS , -ONE*2+PLUS , DISTANCE,	X_ONE-XPLUS, -ONE+PLUS,DISTANCE,	-X_ONE-XPLUS, -ONE+PLUS, DISTANCE,
	-X_ONE-XPLUS, -ONE*2+PLUS, DISTANCE,	X_ONE-XPLUS, ZERO+PLUS, DISTANCE,	-X_ONE-XPLUS, ZERO+PLUS, DISTANCE,
	X_ONE-XPLUS,	ONE+PLUS, DISTANCE,		-X_ONE-XPLUS, ONE+PLUS, DISTANCE,	X_ONE-XPLUS, ZERO+ONE*2+PLUS, DISTANCE,
	-X_ONE-XPLUS, ONE*2+PLUS, DISTANCE,
};

GLfixed MatrixPalette_SkinnedMesh_Vertex_11[] = {
	X_ONE+XPLUS,	-ONE*2+PLUS , DISTANCE,	X_ONE+XPLUS, -ONE+PLUS,DISTANCE,	-X_ONE+XPLUS, -ONE+PLUS, DISTANCE,
	-X_ONE+XPLUS,	-ONE*2+PLUS, DISTANCE,	X_ONE+XPLUS, ZERO+PLUS, DISTANCE,	-X_ONE+XPLUS, ZERO+PLUS, DISTANCE,
	X_ONE+XPLUS,	ONE+PLUS,	DISTANCE,	-X_ONE+XPLUS, ONE+PLUS, DISTANCE,	X_ONE+XPLUS, ZERO+ONE*2+PLUS, DISTANCE,
	-X_ONE+XPLUS,	ONE*2+PLUS, DISTANCE,
};


GLfixed MatrixPalette_SkinnedMesh_Vertex_10[] = {
	X_ONE+XPLUS , -ONE*2-PLUS , DISTANCE,	X_ONE+XPLUS, -ONE-PLUS,DISTANCE,	-X_ONE+XPLUS, -ONE-PLUS, DISTANCE,
	-X_ONE+XPLUS, -ONE*2-PLUS, DISTANCE,	X_ONE+XPLUS, ZERO-PLUS, DISTANCE,	-X_ONE+XPLUS, ZERO-PLUS, DISTANCE,
	X_ONE+XPLUS,	ONE-PLUS, DISTANCE,		-X_ONE+XPLUS, ONE-PLUS, DISTANCE,	X_ONE+XPLUS, ZERO+ONE*2-PLUS, DISTANCE,
	-X_ONE+XPLUS, ONE*2-PLUS, DISTANCE,
};


GLfixed MatrixPalette_SkinnedMesh_Vertex_00[] = {
	X_ONE-XPLUS , -ONE*2-PLUS , DISTANCE,	X_ONE-XPLUS, -ONE-PLUS,DISTANCE,	-X_ONE-XPLUS, -ONE-PLUS, DISTANCE,
	-X_ONE-XPLUS, -ONE*2-PLUS, DISTANCE,	X_ONE-XPLUS, ZERO-PLUS, DISTANCE,	-X_ONE-XPLUS, ZERO-PLUS, DISTANCE,
	X_ONE-XPLUS,	ONE-PLUS, DISTANCE,		-X_ONE-XPLUS, ONE-PLUS, DISTANCE,	X_ONE-XPLUS, ONE*2-PLUS, DISTANCE,
	-X_ONE-XPLUS, ONE*2-PLUS, DISTANCE,
};

GLfixed MatrixPalette_SkinnedMesh_TxCoord[] = {
		glF(1.0f) , glF(0.0f),
		glF(1.0f) , glF(1.0f),
		glF(0.0f) , glF(1.0f),
		glF(0.0f) , glF(0.0f),
		
		glF(1.0f) , glF(0.0f),
		glF(0.0f) , glF(0.0f),
		glF(1.0f) , glF(1.0f),
		glF(0.0f) , glF(1.0f),

		glF(1.0f) , glF(0.0f),
		glF(0.0f) , glF(0.0f),
};

unsigned short MatrixPalette_SkinnedMesh_Index[] = 
			{0,1,2,  0,2,3,  1,4,5,  1,5,2,  4,6,7,   4,7,5,  6,8,9,  6,9,7 };


//16*2
#if defined( BLEND_4)
	GLubyte MatrixPalette_nIndex[] = 
	{ 
		0,1,2,3,    0,1,1,3,	0,1,2,3,
		0,1,2,1,	0,1,2,1,	0,1,2,1,
		0,1,1,1,	0,1,3,1,	1,2,3,1,
		1,2,1,1 
	};

	//16*2
	GLfixed MatrixPalette_fWeight[] = 
	{	
		glF(0.f),  glF(0.5f),	glF(0.5f),	glF(0.0f),	glF(0.2f), glF(0.8f),	glF(0.0f),glF(0.0f),
		glF(0.2f), glF(0.3f),	glF(0.0f),	glF(0.5f),	glF(0.f), glF(1.0f),glF(0.0f),glF(0.0f),
		glF(0.8f), glF(0.2f),	glF(0.0f),	glF(0.0f),	glF(0.8f), glF(0.2f), glF(0.0f),glF(0.0f),
		glF(1.0f), glF(0.0f),	glF(0.0f),	glF(0.0f),	glF(1.0f), glF(0.0f),glF(0.0f),glF(0.0f),
		glF(0.0f), glF(1.0f),	glF(0.0f),	glF(0.0f),	glF(0.0f), glF(1.0f),	glF(0.0f),glF(0.0f),	
							
	};
  

#else
	GLubyte MatrixPalette_nIndex[] = { 
						1,2,    0,1,
						1,3, 	1,1,	
						0,1,	0,1,
						0,1,	0,1,
						2,3, 	2,1 
	};

	GLfloat MatrixPalette_fWeight[] = {	
							glF(0.5f), glF(0.5f),		glF(0.2f), glF(0.8f),
							glF(0.4f), glF(0.6f),		glF(1.0f), glF(0.0f),
							glF(0.8f), glF(0.2f),		glF(0.8f), glF(0.2f),
							glF(1.0f), glF(0.0f),		glF(1.0f), glF(0.0f),
							glF(1.0f),	glF(0.0f),		glF(1.0f), glF(0.0f)
							
						};
#endif

//16*2
GLubyte MatrixPalette_nIndex_11[] = 
{ 
	4,5,6,7,    4,5,5,7,	4,5,6,7,
	4,5,6,5,	4,5,6,5,	4,5,6,5,
	4,5,5,5,	4,5,7,5,	5,6,7,5,
	5,6,5,5 
};

//////////////////////   16-19   ,,,  24- 27   ////
//16*2
GLubyte MatrixPalette_nIndex_10[] = 
{ 
	16,9,19,11,		26,9,9,11,	8,9,26,11,
	8,9,10,9,		8,26,10,9,	26,9,18,9,
	25,9,9,9,		25,9,11,9,	27,10,11,9,
	16,10,17,18 
};

///////////////   20  -  23 ,,,,    28- 31  /////////
//16*2
GLubyte MatrixPalette_nIndex_00[] = 
{ 
	20,13,22,22,    12,13,21,15,	22,20,21,15,
	12,31,14,13,	22,21,23,13,	12,23,21,13,
	31,13,13,22,	12,28,31,13,	13,14,20,31,
	21,14,22,13 
};


//16*2
  
//16*2
GLfixed MatrixPalette_fWeight2[] = 
{	
	glF(0.0f), glF(0.5f), glF(0.5f),glF(0.0f), glF(0.2f), glF(0.8f), glF(0.0f),glF(0.0f),
	glF(0.2f), glF(0.3f), glF(0.3f),glF(0.2f), glF(0.f),  glF(0.5f), glF(0.5f),glF(0.0f),
	glF(0.4f), glF(0.2f), glF(0.2f),glF(0.2f), glF(0.3f), glF(0.2f), glF(0.3f),glF(0.2f),
	glF(0.3f), glF(0.2f), glF(0.0f),glF(0.5f), glF(0.7f), glF(0.2f), glF(0.1f),glF(0.0f),
	glF(0.0f), glF(1.0f), glF(0.0f),glF(0.0f), glF(0.0f), glF(1.0f), glF(0.0f),glF(0.0f),	
};

static GLuint MatrixPalette_bufName[3];
static GLuint MatrixPalette_texName[5];

///////////////////////////////////////////////////////////////////////////////
void InitTexture();
void GL_Draw();
void Render();
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val);
void InitGLES();
void Animate(int t);
void OrthoBegin(void);
void OrthoEnd(void);
float framerate(int Poly);
bool AppInit();
void AppEnd();
double GetTime();
void GetStatus(void);

void InitGLES()
{
	
	glDisable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);	
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_FOG);
	
	glClearDepthx(glF(1.0f)); 
    glClearColorx(glF(0.3f), glF(0.3f), glF(0.3f), glF(1.0f));

	glDepthFunc( GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );	// Really Nice Perspective Calculations
	
	glEnable(GL_MATRIX_PALETTE_OES);
	glEnableClientState( GL_VERTEX_ARRAY);
	glEnableClientState( GL_TEXTURE_COORD_ARRAY);
	glEnableClientState( GL_MATRIX_INDEX_ARRAY_OES);
	glEnableClientState( GL_WEIGHT_ARRAY_OES );
	glViewport(0, 0, LCD_WIDTH, LCD_HEIGHT);
		
	// Set Projection 
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
		
    glPerspectivef( 3.141592654f/4.0f, 1.33f, 0.01f, 100.0f );	
    
	// setting perspective correction 
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();


}
void GL_Draw()
{

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
    {
		printf("draw() failed (error 0x%x)\n", err);
		exit(1);
    }
    	
	static int t = 0;
	Animate(t+=2);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	

glVertexPointer( 3, GL_FIXED, 0, MatrixPalette_SkinnedMesh_Vertex_01);
	
#if defined(BLEND_4)
	glTexCoordPointer( 2, GL_FIXED, 0, MatrixPalette_SkinnedMesh_TxCoord );
	glMatrixIndexPointerOES( 4 , GL_UNSIGNED_BYTE,  0,  MatrixPalette_nIndex);
	glWeightPointerOES( 4 ,  GL_FIXED , 0 ,  MatrixPalette_fWeight);
	glDrawElements( GL_TRIANGLES, 8*3, GL_UNSIGNED_SHORT, MatrixPalette_SkinnedMesh_Index);

#else
	glTexCoordPointer( 2, GL_FIXED, 0, MatrixPalette_SkinnedMesh_TxCoord );
	glMatrixIndexPointerOES( 2 , GL_UNSIGNED_BYTE,  0,  MatrixPalette_nIndex);
	glWeightPointerOES( 2 ,  GL_FIXED , 0 ,  MatrixPalette_fWeight);
	glDrawElements( GL_TRIANGLES, 8*3, GL_UNSIGNED_SHORT, MatrixPalette_SkinnedMesh_Index);

#endif

	//////////////// 11 ///////////////////////
	glVertexPointer( 3, GL_FIXED, 0, MatrixPalette_SkinnedMesh_Vertex_11);
	glMatrixIndexPointerOES( 4 , GL_UNSIGNED_BYTE,  0,  MatrixPalette_nIndex_11);
	glDrawElements( GL_TRIANGLES, 8*3, GL_UNSIGNED_SHORT, MatrixPalette_SkinnedMesh_Index);

	
	//////////////// 10 ///////////////////////
	glVertexPointer( 3, GL_FIXED, 0, MatrixPalette_SkinnedMesh_Vertex_10);
	glMatrixIndexPointerOES( 4 , GL_UNSIGNED_BYTE,  0,  MatrixPalette_nIndex_10);
	glDrawElements( GL_TRIANGLES, 8*3, GL_UNSIGNED_SHORT, MatrixPalette_SkinnedMesh_Index);
	
	//////////////// 00 ///////////////////////
	glVertexPointer( 3, GL_FIXED, 0, MatrixPalette_SkinnedMesh_Vertex_00);
	glMatrixIndexPointerOES( 4 , GL_UNSIGNED_BYTE,  0,  MatrixPalette_nIndex_00);
	glWeightPointerOES( 4 ,  GL_FIXED , 0 ,  MatrixPalette_fWeight2);
	glDrawElements( GL_TRIANGLES, 8*3, GL_UNSIGNED_SHORT, MatrixPalette_SkinnedMesh_Index);
	
	
}
void Render()
{
   
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_MULTISAMPLE);
    GL_Draw();
    glDisable(GL_MULTISAMPLE);

    EGLFlush();
  
 }
void Animate(int t)
{

	glPushMatrix();

	// matrix 0
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
		
	glTranslatex( glF(0.f), glF( -1.0f), glF( 0.0f));
	glTranslatex(-XPLUS , PLUS, glF( 0.0f));
	glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
	glRotatex(glF(20)+glF(t),glF(0.0f),glF(0.0f),glF(1.0f));
	glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE );
	glTranslatex( XPLUS , -PLUS, glF( 0.0f));
		
	glMatrixMode(GL_MATRIX_PALETTE_OES);	
	glCurrentPaletteMatrixOES(0);
	glLoadPaletteFromModelViewMatrixOES();
		
	// matrix 1
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	glMatrixMode(GL_MATRIX_PALETTE_OES);
	glCurrentPaletteMatrixOES(1);
	glLoadPaletteFromModelViewMatrixOES();
		
	// matrix 2
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatex( -XPLUS , PLUS, glF( 0.0f));		
	glTranslatex(glF(0.f), glF( 0.0f), DISTANCE );
	glRotatex(glF(t),glF(0.f),glF(1.0f),glF(0.0f));
	glTranslatex( glF(0.f),glF( 0.0f), -DISTANCE);
	glTranslatex(XPLUS,-PLUS,glF( 0.0f));
		
	glMatrixMode(GL_MATRIX_PALETTE_OES);
	glCurrentPaletteMatrixOES(2);
	glLoadPaletteFromModelViewMatrixOES();
		
	// matrix 3
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatex(-XPLUS,PLUS,glF( 0.0f));
	glTranslatex(glF(0.f),glF( 0.0f), DISTANCE);
	glRotatex(glF(-t),glF(1.0f),glF(0.0f),glF(0.0f));
	glTranslatex(glF(0.f),glF( 0.0f), -DISTANCE);
	glTranslatex(XPLUS,-PLUS,glF( 0.0f));
		
	glMatrixMode(GL_MATRIX_PALETTE_OES);
	glCurrentPaletteMatrixOES(   3 );
	glLoadPaletteFromModelViewMatrixOES();
	
	// matrix 444
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
		
	glTranslatex(glF(0.f),glF( -1.0f), glF( 0.0f));
	glTranslatex( XPLUS , PLUS, glF( 0.0f));
	glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
	glRotatex(glF(20)+glF(t),glF(0.0f),glF(0.0f),glF(1.0f));
	glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE );
	glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		
	glMatrixMode(GL_MATRIX_PALETTE_OES);	
	glCurrentPaletteMatrixOES( 4 );
	glLoadPaletteFromModelViewMatrixOES();
		
	// matrix 5
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

		
	glMatrixMode(GL_MATRIX_PALETTE_OES);
	glCurrentPaletteMatrixOES(5 );
	glLoadPaletteFromModelViewMatrixOES();
		
		
	// matrix 6
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatex( XPLUS , PLUS, glF( 0.0f));		
	glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
	glRotatex(glF(t),glF(0.f),glF(1.0f),glF(0.0f));
	glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
	glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		
	glMatrixMode(GL_MATRIX_PALETTE_OES);
	glCurrentPaletteMatrixOES(  6 );
	glLoadPaletteFromModelViewMatrixOES();
		
	// matrix 7
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatex( XPLUS , PLUS, glF( 0.0f));
	glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE);
	glRotatex(glF(-t),glF(1.0f),glF(0.0f),glF(0.0f));
	glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
	glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		
	glMatrixMode(GL_MATRIX_PALETTE_OES);
	glCurrentPaletteMatrixOES(   7 );
	glLoadPaletteFromModelViewMatrixOES();




		// matrix 888
	glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		glTranslatex( glF(0.f) , glF( -1.0f), glF( 0.0f));
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(20)+glF(t),glF(0.0f),glF(0.0f),glF(1.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE );
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);	
		glCurrentPaletteMatrixOES( 8 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 9
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(9 );
		glLoadPaletteFromModelViewMatrixOES();
		
		
		// matrix 10
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));		
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(t),glF(0.f),glF(1.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(  10 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 11
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE);
		glRotatex(glF(-t),glF(1.0f),glF(0.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(   11 );
		glLoadPaletteFromModelViewMatrixOES();



		// matrix 121212112
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		glTranslatex( glF(0.f) , glF( -1.0f), glF( 0.0f));
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(20)+glF(t),glF(0.0f),glF(0.0f),glF(1.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE );
		glTranslatex( XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);	
		glCurrentPaletteMatrixOES( 12 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 13
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(13 );
		glLoadPaletteFromModelViewMatrixOES();
		
		
		// matrix 14
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));		
		glTranslatex( glF(0.f) ,		glF( 0.0f), DISTANCE );
		glRotatex(glF(t),glF(0.f),	glF(1.0f),glF(0.0f));
		glTranslatex( glF(0.f) ,		glF( 0.0f), -DISTANCE);
		glTranslatex( XPLUS , PLUS,	glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(  14 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 15
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE);
		glRotatex(glF(-t),glF(1.0f),glF(0.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(   15 );
		glLoadPaletteFromModelViewMatrixOES();



		////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////
		
		// matrix 1616161616
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		glTranslatex( glF(0.f) , glF( -1.0f), glF( 0.0f));
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(20)+glF(t),glF(0.0f),glF(0.0f),glF(1.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE );
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);	
		glCurrentPaletteMatrixOES( 16 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 17
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(17 );
		glLoadPaletteFromModelViewMatrixOES();
		
		
		// matrix 18
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));		
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(t),glF(0.f),glF(1.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(  18 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 19
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE);
		glRotatex(glF(-t),glF(1.0f),glF(0.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(   19 );
		glLoadPaletteFromModelViewMatrixOES();




		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		glTranslatex( glF(0.f) , glF( -1.0f), glF( 0.0f));
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(20)+glF(t),glF(0.0f),glF(0.0f),glF(1.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE );
		glTranslatex( XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);	
		glCurrentPaletteMatrixOES( 20 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 21
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(21 );
		glLoadPaletteFromModelViewMatrixOES();
		
		
		// matrix 22
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));		
		glTranslatex( glF(0.f) ,		glF( 0.0f), DISTANCE );
		glRotatex(glF(t),glF(0.f),	glF(1.0f),glF(0.0f));
		glTranslatex( glF(0.f) ,		glF( 0.0f), -DISTANCE);
		glTranslatex( XPLUS , PLUS,	glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(  22 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 23
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE);
		glRotatex(glF(-t),glF(1.0f),glF(0.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(   23 );
		glLoadPaletteFromModelViewMatrixOES();



		// matrix 24
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		glTranslatex( glF(0.f) , glF( -1.0f), glF( 0.0f));
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(20)+glF(t),glF(0.0f),glF(0.0f),glF(1.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE );
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);	
		glCurrentPaletteMatrixOES( 24 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 25
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
	
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(25 );
		glLoadPaletteFromModelViewMatrixOES();
		
		
		// matrix 26
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));		
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(t),glF(0.f),glF(1.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(  26 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 27
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE);
		glRotatex(glF(-t),glF(1.0f),glF(0.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( -XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(   27 );
		glLoadPaletteFromModelViewMatrixOES();



		// matrix 282828282822828
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		glTranslatex( glF(0.f) , glF( -1.0f), glF( 0.0f));
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE );
		glRotatex(glF(20)+glF(t),glF(0.0f),glF(0.0f),glF(1.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE );
		glTranslatex( XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);	
		glCurrentPaletteMatrixOES( 28 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 29
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(29 );
		glLoadPaletteFromModelViewMatrixOES();
		
		
		// matrix 30
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));		
		glTranslatex( glF(0.f) ,		glF( 0.0f), DISTANCE );
		glRotatex(glF(t),glF(0.f),	glF(1.0f),glF(0.0f));
		glTranslatex( glF(0.f) ,		glF( 0.0f), -DISTANCE);
		glTranslatex( XPLUS , PLUS,	glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(  30 );
		glLoadPaletteFromModelViewMatrixOES();
		
		// matrix 31
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatex( -XPLUS , -PLUS, glF( 0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), DISTANCE);
		glRotatex(glF(-t),glF(1.0f),glF(0.0f),glF(0.0f));
		glTranslatex( glF(0.f) , glF( 0.0f), -DISTANCE);
		glTranslatex( XPLUS , PLUS, glF( 0.0f));
		
		glMatrixMode(GL_MATRIX_PALETTE_OES);
		glCurrentPaletteMatrixOES(   31 );
		glLoadPaletteFromModelViewMatrixOES();
		

	glMatrixMode(GL_MODELVIEW);	
	glPopMatrix();
}
void InitTexture()
{
    glGenTextures(1,MatrixPalette_texName);
	glBindTexture(GL_TEXTURE_2D, MatrixPalette_texName[0]);
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, __g_hobody_w, __g_hobody_h, 0, GL_RGB, GL_UNSIGNED_BYTE, __g_hobody);


}

bool AppInit()
{
     
    if(!CreateEGL())
		return false;

	InitGLES();

    InitTexture();
 
	return true;

}
///////////////////////////////////////////////////////////////////////////////
void AppEnd()
{	

    glDeleteTextures(1,MatrixPalette_texName);
    DeleteEGL();
}

///////////////////////////////////////////////////////////////////////////////
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val)
{
	GLfloat top = (GLfloat)(tan(fov*0.5) * near_val);
	GLfloat bottom = -top;
	GLfloat left = aspect * bottom;
	GLfloat right = aspect * top;
	glFrustumx(glF(left), glF(right), glF(bottom), glF(top), glF(near_val),glF(far_val));
    
}
//////////////////////////////////////////////////////////////////////////////////////


void OrthoBegin(void)
{
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrthox(0,LCD_WIDTH*65536,0,LCD_HEIGHT*65536,-1.0*65536,1.0*65536);	

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();


}

void OrthoEnd(void)
{
	glEnable(GL_DEPTH_TEST);
	//glEnable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix(); 
}

/*************Calculate frame rate********/
float framerate(int Poly)
{
    static float previous = 0;
    static int framecount = 0;
	static float finalfps = 0;
    framecount++;

    if ( framecount == 10 )
    {
        float time = (float)GetTime();
        float seconds = time - previous;
        float fps = framecount / seconds;
        previous = time;
		finalfps = fps;
        framecount = 0;
    }

	return finalfps;
}

double GetTime()
{
 	clock_t sTime;
	double dSec=0;
//	dSec=((double)clock()/CLOCKS_PER_SEC);
 
	return dSec;
}
void GetStatus(void)
{
    int status =0;

    glGetIntegerv(GL_MAX_LIGHTS,&status);
    printf( "==GL_MAX_LIGHTS=%d=\n",status);

    glGetIntegerv(GL_MAX_TEXTURE_SIZE,&status); 
    printf( "==GL_MAX_TEXTURE_SIZE=%d=\n",status); 

    glGetIntegerv(GL_MAX_TEXTURE_UNITS,&status); 
    printf( "==GL_MAX_TEXTURE_SIZE=%d=\n",status); 

  //  glGetIntegerv(GL_MAX_ELEMENTS_VERTICES,&status); 
   // printf( "==GL_MAX_TEXTURE_SIZE=%d=\n",status); 

  //  glGetIntegerv(GL_MAX_ELEMENTS_INDICES,&status); 
   // printf( "==GL_MAX_TEXTURE_SIZE=%d=\n",status); 

    glGetIntegerv(GL_MAX_PALETTE_MATRICES_OES,&status); 
    printf( "==GL_MAX_PALETTE_MATRICES_OES=%d=\n",status); 

    
}

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TCMATRIXPALETTE));

	// Main message loop:
	for (;;) {
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			Render();
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TCMATRIXPALETTE));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_TCMATRIXPALETTE, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }
/*
    hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
*/
	 hWnd = CreateWindowEx(WS_EX_TOPMOST,szWindowClass, szTitle, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_VISIBLE,
      0, 0, 800, 480, NULL, NULL, hInstance, NULL);


    if (!hWnd)
    {
        return FALSE;
    }

	 AppInit();

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            g_hWndCommandBar = CommandBar_Create(g_hInst, hWnd, 1);
            CommandBar_InsertMenubar(g_hWndCommandBar, g_hInst, IDR_MENU, 0);
            CommandBar_AddAdornments(g_hWndCommandBar, 0, 0);
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
            PostQuitMessage(0);
            break;
		case WM_KEYDOWN:
			{
				RETAILMSG(1,(TEXT("KeyDOWN %d==\n"),wParam));
				switch(wParam)
				{
				case 38:
					{
						AppEnd();			
						PostQuitMessage(0);
					}
					break;
				
				}
			}
			break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
