// tcAlphatest11.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "tcAlphatest11.h"
#include <windows.h>
#include <commctrl.h>

#include "DeviceConfig.h"
#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle


#define glF(x)	((GLfixed)((x)*(1<<16)))
#define GL_F	GL_FIXED
typedef GLfixed GLf;

////////////////////Data//////////////////////////////////////////////////////
GLfixed Plain_Vertex[] = {
	
		glF(-(LCD_WIDTH/2.0f)) , glF( (LCD_HEIGHT/2.0f)) , // 0
		glF( (LCD_WIDTH/2.0f)) , glF( (LCD_HEIGHT/2.0f)) , // 1
		glF( (LCD_WIDTH/2.0f)) , glF( -(LCD_HEIGHT/2.0f)),// 2
		glF(-(LCD_WIDTH/2.0f)) , glF( -(LCD_HEIGHT/2.0f)), // 3
};


GLfixed Plain_TxCoord[] = {
		glF(0.f) , glF(1.f),
		glF(1.f) , glF(1.f),
		glF(1.f) , glF(0.f),
		glF(0.f) , glF(0.f),
		
};

// 28*3
unsigned short Plain_Index[] = 
{
		2,1,0, 
		0,3,2
 };

unsigned short TexImageBack[]={
	0x003f,0x07c0,
	0x07FE,0xF801,
};



unsigned short TexImageFront[]={
	0xf800,0x003f,
	0x07c1,0xffc0,
};


int m_nSwitchCnt =0;
int m_nCnt =0;
GLuint g_nTextureID[2];
bool g_bAlphaTest = false;
///////////////////////////////////////////////////////////////////////////////
void GL_Draw();
void Render();
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val);
void InitGLES();
void OrthoBegin(void);
void OrthoEnd(void);
float framerate(int Poly);
bool AppInit();
void AppEnd();
double GetTime();
void GetStatus(void);
void InitTexture(void);
void InitGLES()
{
	
	glShadeModel(GL_FLAT);
	glEnable(GL_DEPTH_TEST);					// hidden surface removal
	glEnable(GL_CULL_FACE);						// do not calculate inside of poly's
	glFrontFace(GL_CCW);						// counter clock-wise polygons are out
	glCullFace(GL_BACK);// Enable Smooth Shading

	glClearColorx(glF(1.0f), glF(1.0f), glF(1.0f), glF(1.0f) );
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
		
	glEnable(GL_TEXTURE_2D);

	glViewport(0, 0, LCD_WIDTH, LCD_HEIGHT);
	glAlphaFuncx(GL_LESS,glF(1.0f));
		/*#define GL_NEVER									0x0200
		#define GL_LESS									0x0201
		#define GL_EQUAL									0x0202
		#define GL_LEQUAL									0x0203
		#define GL_GREATER									0x0204
		#define GL_NOTEQUAL								0x0205
		#define GL_GEQUAL									0x0206
		#define GL_ALWAYS									0x0207
		*/
		

	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
		
	glOrthox(glF(0.0f),glF(LCD_WIDTH),0,glF(LCD_HEIGHT),glF(-1.0f),glF(1.0f));	
		
	// setting perspective correction 
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	



}
void GL_Draw()
{
 	
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    
	glVertexPointer(2, GL_FIXED, 0, Plain_Vertex); 	
	glTexCoordPointer(2,GL_FIXED,0,Plain_TxCoord);

    glBindTexture(GL_TEXTURE_2D,g_nTextureID[0]);//back
	glPushMatrix();
		glTranslatex(glF(LCD_WIDTH/2),glF(LCD_HEIGHT/2),glF(0.0f));
		glDrawElements(GL_TRIANGLES,2*3,GL_UNSIGNED_SHORT,Plain_Index);
	glPopMatrix();


	
	glBindTexture(GL_TEXTURE_2D,g_nTextureID[1]);//Front
//	glVertexPointer(2, GL_FIXED, 0, Plain_Vertex); 	
//	glTexCoordPointer(2,GL_FIXED,0,Plain_TxCoord);
	
	glPushMatrix();
	    glTranslatex(glF(LCD_WIDTH/2),glF(LCD_HEIGHT/2),glF(0.0f));
	    glScalex(glF(0.5f),glF(0.5f),glF(0.0f));
	    glDrawElements(GL_TRIANGLES,2*3,GL_UNSIGNED_SHORT,Plain_Index);
	glPopMatrix();



	
}
void Render()
{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		m_nSwitchCnt++;
		if(m_nSwitchCnt >100)
		{
			m_nSwitchCnt = 0;

			if(g_bAlphaTest)
			{
				glDisable(GL_ALPHA_TEST);
				g_bAlphaTest=false;
			}
			else{
				glEnable(GL_ALPHA_TEST);
				g_bAlphaTest=true;
			}

		}

		GL_Draw();
		EGLFlush();
	
}

///////////////////////////////////////////////////////////////////////////////
//******* Main Render Loop *******************/

bool AppInit()
{
     
    if(!CreateEGL())
		return false;

	InitGLES();
    InitTexture();

     
	return true;

}
///////////////////////////////////////////////////////////////////////////////
void AppEnd()
{	
    glDeleteTextures(2,g_nTextureID);
    DeleteEGL();
   
}
void InitTexture(void)
{
    glEnable(GL_TEXTURE_2D);
	glGenTextures(2, g_nTextureID);

	glBindTexture(GL_TEXTURE_2D, g_nTextureID[0]);	
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 2, 2, 0, GL_RGBA, GL_UNSIGNED_SHORT_5_5_5_1, &TexImageBack[0]);


	glBindTexture(GL_TEXTURE_2D, g_nTextureID[1]);	
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 2, 2, 0, GL_RGBA, GL_UNSIGNED_SHORT_5_5_5_1, &TexImageFront[0]);

	
}
///////////////////////////////////////////////////////////////////////////////
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val)
{
	GLfloat top = (GLfloat)(tan(fov*0.5) * near_val);
	GLfloat bottom = -top;
	GLfloat left = aspect * bottom;
	GLfloat right = aspect * top;

//	glFrustumf(left, right, bottom, top, near_val, far_val);
    glFrustumx(glF(left), glF(right), glF(bottom), glF(top), glF(near_val),glF(far_val));
    
}
//////////////////////////////////////////////////////////////////////////////////////


void OrthoBegin(void)
{
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrthox(0,LCD_WIDTH*65536,0,LCD_HEIGHT*65536,-1.0*65536,1.0*65536);	

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();


}

void OrthoEnd(void)
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix(); 
}

/*************Calculate frame rate********/
float framerate(int Poly)
{
    static float previous = 0;
    static int framecount = 0;
	static float finalfps = 0;
    framecount++;

    if ( framecount == 10 )
    {
        float time = (float)GetTime();
        float seconds = time - previous;
        float fps = framecount / seconds;
        previous = time;
		finalfps = fps;
        framecount = 0;
    }

	return finalfps;
}

double GetTime()
{
 	clock_t sTime;
	double dSec=0;
//	dSec=((double)clock()/CLOCKS_PER_SEC);
 
	return dSec;
}


// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TCALPHATEST11));

	// Main message loop:
	for (;;) {
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			Render();
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TCALPHATEST11));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_TCALPHATEST11, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }
/*
 hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
*/
	hWnd = CreateWindowEx(WS_EX_TOPMOST,szWindowClass, szTitle, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_VISIBLE,
      0, 0, 800, 480, NULL, NULL, hInstance, NULL);


    if (!hWnd)
    {
        return FALSE;
    }

	AppInit();

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            g_hWndCommandBar = CommandBar_Create(g_hInst, hWnd, 1);
            CommandBar_InsertMenubar(g_hWndCommandBar, g_hInst, IDR_MENU, 0);
            CommandBar_AddAdornments(g_hWndCommandBar, 0, 0);
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
            PostQuitMessage(0);
            break;
		case WM_KEYDOWN:
			{
				RETAILMSG(1,(TEXT("KeyDOWN %d==\n"),wParam));
				switch(wParam)
				{
				case 38:
					{
						AppEnd();			
						PostQuitMessage(0);
					}
					break;
				
				}
			}
			break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
