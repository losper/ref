// tcFog11.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "tcFog11.h"
#include <windows.h>
#include <commctrl.h>

#include "DeviceConfig.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle

// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

#define glF(x)	((GLfixed)((x)*(1<<16)))
#define GL_F	GL_FIXED
typedef GLfixed GLf;

int m_nCnt =0;
float yrot =0.0f;
int m_nSwitchCnt =0;

GLfixed pCubeVertex[]={
		glF(-1.0f),  glF(-1.0f), glF(1.0f),	//0  (Front) 
		glF(1.0f),   glF(-1.0f), glF(1.0f),	//1
		glF(1.0f),   glF(1.0f),  glF(1.0f),	//2
		glF(-1.0f),  glF(1.0f),  glF(1.0f),	//3
		
		glF(-1.0f),  glF(-1.0f), glF(-1.0f),	//4  (Back)
		glF(-1.0f),  glF(1.0f),  glF(-1.0f),	//5
		glF( 1.0f),  glF(1.0f),  glF(-1.0f),	//6
		glF( 1.0f),  glF(-1.0f), glF(-1.0f),	//7
		
		glF(-1.0f),  glF(1.0f),  glF(-1.0f),	//8  (Top)
		glF(-1.0f),  glF(1.0f),  glF( 1.0f),	//9
		glF( 1.0f),  glF(1.0f),  glF( 1.0f),	//10
		glF( 1.0f),  glF(1.0f),  glF(-1.0f),	//11
		
		glF(-1.0f),  glF(-1.0f), glF(-1.0f),	//12  (Bottom)
		glF( 1.0f),  glF(-1.0f), glF(-1.0f),	//13
		glF( 1.0f),  glF(-1.0f), glF( 1.0f),	//14
		glF(-1.0f),  glF(-1.0f), glF( 1.0f),	//15
		
		glF(1.0f),   glF(-1.0f), glF(-1.0f),	//16  (Right)
		glF(1.0f),   glF( 1.0f), glF(-1.0f),	//17
		glF(1.0f),   glF( 1.0f), glF( 1.0f),	//18
		glF(1.0f),   glF(-1.0f), glF(1.0f),	//19
		
		glF(-1.0f),  glF(-1.0f), glF(-1.0f),	//20  (Left)
		glF(-1.0f),  glF(-1.0f), glF( 1.0f),	//21
		glF(-1.0f),  glF( 1.0f), glF( 1.0f),	//22
		glF(-1.0f),  glF( 1.0f), glF(-1.0f),	//23
		
};



GLfixed pTexCoord[]={
		glF(0.0f), glF(0.0f), 
		glF(1.0f), glF(0.0f), 
		glF(1.0f), glF(1.0f), 
		glF(0.0f), glF(1.0f), 
		// Back Face
		glF(1.0f), glF(0.0f), 
		glF(1.0f), glF(1.0f), 
		glF(0.0f), glF(1.0f), 
		glF(0.0f), glF(0.0f), 
		// Top Face
		glF(0.0f), glF(1.0f), 
		glF(0.0f), glF(0.0f), 
		glF(1.0f), glF(0.0f), 
		glF(1.0f), glF(1.0f), 
		// Bottom Face
		glF(1.0f), glF(1.0f), 
		glF(0.0f), glF(1.0f), 
		glF(0.0f), glF(0.0f), 
		glF(1.0f), glF(0.0f), 
		// Right face
		glF(1.0f), glF(0.0f), 
		glF(1.0f), glF(1.0f), 
		glF(0.0f), glF(1.0f), 
		glF(0.0f), glF(0.0f), 
		// Left Face
		glF(0.0f), glF(0.0f), 
		glF(1.0f), glF(0.0f), 
		glF(1.0f), glF(1.0f), 
		glF(0.0f), glF(1.0f), 
};

GLfixed pNormal[]={
		glF(0.0f), glF(0.0f), glF(1.0f), 
		glF(0.0f), glF(0.0f), glF(1.0f), 
		glF(0.0f), glF(0.0f), glF(1.0f), 
		glF(0.0f), glF(0.0f), glF(1.0f), 
		// Back Face
		glF(0.0f), glF(0.0f), glF(-1.0f), 
		glF(0.0f), glF(0.0f), glF(-1.0f), 
		glF(0.0f), glF(0.0f), glF(-1.0f), 
		glF(0.0f), glF(0.0f), glF(-1.0f), 
		// Top Face
		glF(0.0f), glF(1.0f), glF(0.0f), 
		glF(0.0f), glF(1.0f), glF(0.0f),
		glF(0.0f), glF(1.0f), glF(0.0f), 
		glF(0.0f), glF(1.0f), glF(0.0f), 
		
		// Bottom Face
		glF(0.0f), glF(-1.0f), glF(0.0f), 
		glF(0.0f), glF(-1.0f), glF(0.0f), 
		glF(0.0f), glF(-1.0f), glF(0.0f), 
		glF(0.0f), glF(-1.0f), glF(0.0f), 

		// Right face
		glF(1.0f), glF(0.0f), glF(0.0f), 
		glF(1.0f), glF(0.0f), glF(0.0f), 
		glF(1.0f), glF(0.0f), glF(0.0f), 
		glF(1.0f), glF(0.0f), glF(0.0f), 
		
		// Left Face
		glF(-1.0f), glF(0.0f), glF(0.0f),
		glF(-1.0f), glF(0.0f), glF(0.0f),
		glF(-1.0f), glF(0.0f), glF(0.0f),
		glF(-1.0f), glF(0.0f), glF(0.0f),
		
};

GLushort pCubeIndex[]={
		0,1,2,
		0,2,3,
		4,5,6,
		4,6,7,
		8,9,10,
		8,10,11,
		12,13,14,
		12,14,15,
		16,17,18,
		16,18,19,
		20,21,22,
		20,22,23,
};

GLfixed fogColor[] = {glF(0.5f), glF(0.5f), glF(0.5f),glF(1.0f)};
GLfixed fogTypes[] = { GL_EXP, GL_EXP2, GL_LINEAR };

GLfixed lightAmbient[] = {glF(1.0f),glF(1.0f), glF(1.0f), glF(1.0f)};
GLfixed matAmbient[] = { glF(1.0f), glF(1.0f), glF(1.0f), glF(1.0f) };
GLfixed lightDiffuse[]=	{glF(1.0f),glF(1.0f),glF(1.0f),glF(1.0f) };

TGAImage TextureImage;
int fogType = 0;

///////////////////////////////////////////////////////////////////////////////
void GL_Draw();
void Render();
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val);
void InitGLES();
void OrthoBegin(void);
void OrthoEnd(void);
float framerate(int Poly);
bool AppInit();
void AppEnd();
double GetTime();
void GetStatus(void);
void InitTexture(void);
void InitGLES()
{
	
	glClearColorx(glF(0.5f), glF(0.5f), glF(0.5f), glF(1.0f));

    glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);					// hidden surface removal
	glEnable(GL_CULL_FACE);						// do not calculate inside of poly's
    glEnable(GL_TEXTURE_2D);                    // Enable Smooth Shading
    glFrontFace(GL_CCW);						// counter clock-wise polygons are out
	glCullFace(GL_BACK);
    

	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	glClearDepthx(glF(1.0f));

    //Fog Setting
    glFogx(GL_FOG_MODE, GL_LINEAR);
	glFogxv(GL_FOG_COLOR, fogColor);
	glFogx(GL_FOG_DENSITY, glF(0.2f));
	glHint(GL_FOG_HINT,  GL_NICEST);
	glFogx(GL_FOG_START, glF(0.0f));
	glFogx(GL_FOG_END, glF(30.0f));
	glEnable(GL_FOG);
    
    //Lighting Setting
    glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glMaterialxv(GL_FRONT_AND_BACK, GL_AMBIENT, matAmbient);
	glLightxv(GL_LIGHT0, GL_AMBIENT, lightAmbient);
	glLightxv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);


    glDisableClientState(GL_COLOR_ARRAY);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);	
	glEnableClientState(GL_NORMAL_ARRAY);	
	
    glViewport(0, 0, LCD_WIDTH, LCD_HEIGHT);
// Set Projection 
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glPerspectivef( 3.141592654f/4.0f, 1.33f, 0.01f, 1000.0f );	
													
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

}
void GL_Draw()
{
 	
    glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	glBindTexture(GL_TEXTURE_2D,TextureImage.texID);
	glVertexPointer(3, GL_FIXED, 0, pCubeVertex); 	
	glTexCoordPointer(2,GL_FIXED,0,pTexCoord);
	glNormalPointer(GL_FIXED,0,pNormal);
	//glNormalPointer			(GLenum type, GLsizei stride, const GLvoid* ptr);

    glPushMatrix();
        glTranslatex(0,0,glF(-7.0f));
	//	glScalex(glF(2.0f),glF(2.0f),glF(2.0f));
        glRotatex(glF(yrot),glF(0.0f),glF(1.0f),glF(0.0f));
        glDrawElements(GL_TRIANGLES,12*3,GL_UNSIGNED_SHORT,pCubeIndex);
	glPopMatrix();

	glPushMatrix();
        glTranslatex(glF(6.0f),0,glF(-15.0f));
	//	glScalex(glF(2.0f),glF(2.0f),glF(2.0f));
        glRotatex(glF(yrot),glF(0.0f),glF(1.0f),glF(0.0f));
        glDrawElements(GL_TRIANGLES,12*3,GL_UNSIGNED_SHORT,pCubeIndex);
	glPopMatrix();



   yrot++;
   if(yrot>360.0f)
    yrot =0.0f;


	
}
void Render()
{
	
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		m_nSwitchCnt++;
		if(m_nSwitchCnt >300)
		{
			m_nSwitchCnt = 0;

			++fogType %= 3;
			glFogx(GL_FOG_MODE, fogTypes[fogType]);

			if(fogType > 65536)
				fogType =0;
		}

		GL_Draw();


		EGLFlush();
	
}

///////////////////////////////////////////////////////////////////////////////
//******* Main Render Loop *******************/

bool AppInit()
{
     
    if(!CreateEGL())
		return false;

	InitGLES();
    InitTexture();

   return true;

}
///////////////////////////////////////////////////////////////////////////////
void AppEnd()
{	
    glDeleteTextures(1,&TextureImage.texID);
	DeleteEGL();
   
}
void InitTexture(void)
{
    LoadTGA(&TextureImage,"NAND/data/jolly.tga");
	free(TextureImage.imageData);
	TextureImage.imageData=NULL;
}
///////////////////////////////////////////////////////////////////////////////
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val)
{
	GLfloat top = (GLfloat)(tan(fov*0.5) * near_val);
	GLfloat bottom = -top;
	GLfloat left = aspect * bottom;
	GLfloat right = aspect * top;

    glFrustumx(glF(left), glF(right), glF(bottom), glF(top), glF(near_val),glF(far_val));
    
}
//////////////////////////////////////////////////////////////////////////////////////


void OrthoBegin(void)
{
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrthox(0,LCD_WIDTH*65536,0,LCD_HEIGHT*65536,-1.0*65536,1.0*65536);	

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();


}

void OrthoEnd(void)
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix(); 
}

/*************Calculate frame rate********/
float framerate(int Poly)
{
    static float previous = 0;
    static int framecount = 0;
	static float finalfps = 0;
    framecount++;

    if ( framecount == 10 )
    {
        float time = (float)GetTime();
        float seconds = time - previous;
        float fps = framecount / seconds;
        previous = time;
		finalfps = fps;
        framecount = 0;
    }

	return finalfps;
}

double GetTime()
{
 	clock_t sTime;
	double dSec=GetTickCount();
//	dSec=((double)clock()/CLOCKS_PER_SEC);
 
	return dSec;
}

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TCFOG11));

	// Main message loop:
	for (;;) {
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			Render();
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TCFOG11));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_TCFOG11, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }
/*
    hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
*/
	 hWnd = CreateWindowEx(WS_EX_TOPMOST,szWindowClass, szTitle, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_VISIBLE,
      0, 0, 800, 480, NULL, NULL, hInstance, NULL);


    if (!hWnd)
    {
        return FALSE;
    }
	
	AppInit();
    
	ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            g_hWndCommandBar = CommandBar_Create(g_hInst, hWnd, 1);
            CommandBar_InsertMenubar(g_hWndCommandBar, g_hInst, IDR_MENU, 0);
            CommandBar_AddAdornments(g_hWndCommandBar, 0, 0);
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
            PostQuitMessage(0);
            break;
		case WM_KEYDOWN:
			{
				RETAILMSG(1,(TEXT("KeyDOWN %d==\n"),wParam));
				switch(wParam)
				{
				case 38:
					{
						AppEnd();			
						PostQuitMessage(0);
					}
					break;
				
				}
			}
			break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
