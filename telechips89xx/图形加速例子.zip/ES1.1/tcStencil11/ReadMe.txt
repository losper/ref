========================================================================
    WIN32 APPLICATION : tcStencil11 Project Overview
========================================================================

AppWizard has created this tcStencil11 application for you.  

This file contains a summary of what you will find in each of the files that
make up your tcStencil11 application.


tcStencil11.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

tcStencil11.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
AppWizard has created the following resources:

tcStencil11.rc
    This is a listing of all of the Microsoft Windows resources that the
    program uses when compiling for a platform that uses the standard Windows
    CE shell.  It includes the icons, bitmaps, and cursors that are stored
    in the RES subdirectory.  This file can be directly edited in Microsoft
    Visual C++. When the .rc file is persisted, the defines in the data
    section are persisted as the hexadecimal version of the numeric value
    they are defined to rather than the friendly name of the define.

tcStencil11.rc2
    This file contains resources that are not edited by Microsoft 
    Visual C++.  You should place all resources not editable by
    the resource editor in this file.

Resource.h
    This is the standard header file, which defines new resource IDs.
    Microsoft Visual C++ reads and updates this file.





tcStencil11.ico
    This is an icon file, which is used as the application's icon (32x32).
    This icon is included by the main resource file tcStencil11.rc.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named tcStencil11.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////s