// tcStencil11.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "tcStencil11.h"
#include <windows.h>
#include <commctrl.h>

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle

// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);


#include "DeviceConfig.h"
#include "V6_sphere_2000.h"

int m_nCnt =0;
#define glF(x)	((GLfixed)((x)*(1<<16)))
#define GL_F	GL_FIXED
typedef GLfixed GLf;

////////////////////Data//////////////////////////////////////////////////////
GLfixed g_TileVertex[]={
	glF(-5.0f), glF(0.0f), glF(5.0f),
	glF(5.0f), glF(0.0f), glF(5.0f),
	glF(5.0f), glF(0.0f),glF(-5.0f),
	glF(-5.0f), glF(0.0f),glF(-5.0f),
		
		
};

GLfixed g_TileTexCoord[]={
	glF(0.0f), glF(0.0f),
	glF(1.0f), glF(0.0f),
	glF(1.0f), glF(1.0f),
	glF(0.0f), glF(1.0f),
		
};

GLfixed g_TileNormal[]={
	glF(0.0f), glF(1.0f), glF(0.0f),
	glF(0.0f), glF(1.0f), glF(0.0f),
	glF(0.0f), glF(1.0f), glF(0.0f),
	glF(0.0f), glF(1.0f), glF(0.0f),
};



TGAImage EnvRollImage;
TGAImage EnvWallImage;
TGAImage BallImage;
GLfloat	yrot;							// Y Rotation

///////////////////////////////////////////////////////////////////////////////
void GL_Draw();
void Render();
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val);
void InitGLES();
void OrthoBegin(void);
void OrthoEnd(void);
float framerate(int Poly);
bool AppInit();
void AppEnd();
double GetTime();
void GetStatus(void);
void InitTexture(void);
void DrawFloor();
void DrawObject();
void DrawSphere(int i);
void InitGLES()
{
	
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	//glClearColor(0.2f, 0.2f, 0.6f, 1.0f);
	glClearColorx(glF(0.2f), glF(0.2f), glF(0.6f), glF(1.0f));			
	glClearDepthx(glF(1.0f));								
	glClearStencil(0);									// Clear The Stencil Buffer
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	
	glEnable(GL_TEXTURE_2D);							
	
	
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
			
	glEnable(GL_TEXTURE_2D);

	glViewport(0, 0, LCD_WIDTH, LCD_HEIGHT);
		
	// Set Projection 
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
		
    glPerspectivef( 3.141592654f/4.0f, 1.33f, 0.01f, 100.0f );	
    
	// setting perspective correction 
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	

	



}
void GL_Draw()
{
 	
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    
	glTranslatex(glF(0.0f),glF(-1.0f),glF(-10.0f));
	glRotatex(glF(4.0f),glF(1.0f),glF(0.0f),glF(0.0f));

    glColorMask(0,0,0,0);								// Set Color Mask
	glEnable(GL_STENCIL_TEST);							// Enable Stencil Buffer 
	glStencilFunc(GL_ALWAYS, 1, 1);						// Always Passes
	glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);			
	glDisable(GL_DEPTH_TEST);							// Disable Depth Testing
	DrawFloor();										// Draws To The Stencil Buffer

	glEnable(GL_DEPTH_TEST);							// Enable Depth Testing
	glColorMask(1,1,1,1);								// Set Color Mask to TRUE, TRUE, TRUE, TRUE
	glStencilFunc(GL_EQUAL, 1, 1);						
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);				
    
	glPushMatrix();
		glScalex(glF(1.0f),glF(-1.0f),glF(1.0f));					// Mirror Y Axis
		glTranslatex(glF(0.0f),glF(2.0f),glF(0.0f));
		glRotatex(glF(yrot),glF(0.0f),glF(1.0f),glF(0.0f));
		DrawObject();									// Draw The Sphere(Reflection)
	glPopMatrix();

	glDisable(GL_STENCIL_TEST);							 
	glEnable(GL_BLEND);									// Enable Blending
	//glColor4f(1.0f, 1.0f, 1.0f, 0.7f);
	glColor4x(glF(1.0f), glF(1.0f), glF(1.0f), glF(0.7f));
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);	// Blending
	DrawFloor();										
	glDisable(GL_BLEND);
	
	glPushMatrix();
		glTranslatex(glF(0.0f),glF(2.0f),glF(0.0f));
	    glRotatex(glF(yrot),glF(0.0f),glF(1.0f),glF(0.0f));
		DrawObject();										
	glPopMatrix();
  
yrot++;
if(yrot >360.0f)
    yrot = 0.0f;



	
}
void Render()
{
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	GL_Draw();
	EGLFlush();
	
 }

///////////////////////////////////////////////////////////////////////////////
bool AppInit()
{
     
    if(!CreateEGL())
		return false;

	InitGLES();
    InitTexture();

     
	return true;

}
///////////////////////////////////////////////////////////////////////////////
void AppEnd()
{	
    glDeleteTextures(1, &EnvWallImage.texID);
	glDeleteTextures(1, &EnvRollImage.texID);
	glDeleteTextures(1, &BallImage.texID);

    DeleteEGL();
   
}
void InitTexture(void)
{
    LoadTGA(&EnvWallImage,"NAND/data/BG.tga");
	LoadTGA(&BallImage,"NAND/data/Bump.tga");
	LoadTGA(&EnvRollImage,"NAND/data/Envroll.tga");

	free(EnvWallImage.imageData);
	EnvWallImage.imageData=NULL;

	free(BallImage.imageData);
	BallImage.imageData=NULL;

	free(EnvRollImage.imageData);
	EnvRollImage.imageData=NULL;


	
}
void DrawSphere(int i)
{

	glEnable(GL_TEXTURE_2D);

	if(i==1)
		glBindTexture(GL_TEXTURE_2D,BallImage.texID);
	else if(i==2)
		glBindTexture(GL_TEXTURE_2D,EnvRollImage.texID);

	glVertexPointer(3, GL_FIXED, 0, sphere_980pv); 	
	glTexCoordPointer(2, GL_FIXED, 0, sphere_980pc);

	glPushMatrix();
	glScalex(glF(0.7f),glF(0.7f),glF(0.7f));
	glDrawElements(GL_TRIANGLES, 960 * 3, GL_UNSIGNED_SHORT, sphere_980pf); 
	glPopMatrix();


}
void DrawObject()										
{
	//glColor4f(1.0f, 1.0f, 1.0f,1.0f);
	glColor4x(glF(1.0f), glF(1.0f), glF(1.0f), glF(1.0f));
	DrawSphere(1);

	//glColor4f(1.0f, 1.0f, 1.0f, 0.4f);
	glColor4x(glF(1.0f), glF(1.0f), glF(1.0f), glF(0.4f));
	glEnable(GL_BLEND);									// Enable Blending
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);					
	DrawSphere(2);
	glDisable(GL_BLEND);								
	
}



void DrawFloor()										
{
	
	glBindTexture(GL_TEXTURE_2D, EnvWallImage.texID);	

	glVertexPointer(3, GL_FIXED, 0, g_TileVertex); 	
	glTexCoordPointer(2, GL_FIXED, 0, g_TileTexCoord);
	
	glDrawArrays(GL_TRIANGLE_FAN,0,4); 

	
}
///////////////////////////////////////////////////////////////////////////////
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val)
{
	GLfloat top = (GLfloat)(tan(fov*0.5) * near_val);
	GLfloat bottom = -top;
	GLfloat left = aspect * bottom;
	GLfloat right = aspect * top;

//	glFrustumf(left, right, bottom, top, near_val, far_val);
    glFrustumx(glF(left), glF(right), glF(bottom), glF(top), glF(near_val),glF(far_val));
    
}
//////////////////////////////////////////////////////////////////////////////////////


void OrthoBegin(void)
{
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrthox(0,LCD_WIDTH*65536,0,LCD_HEIGHT*65536,-1.0*65536,1.0*65536);	

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();


}

void OrthoEnd(void)
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix(); 
}

/*************Calculate frame rate********/
float framerate(int Poly)
{
    static float previous = 0;
    static int framecount = 0;
	static float finalfps = 0;
    framecount++;

    if ( framecount == 10 )
    {
        float time = (float)GetTime();
        float seconds = time - previous;
        float fps = framecount / seconds;
        previous = time;
		finalfps = fps;
        framecount = 0;
    }

	return finalfps;
}

double GetTime()
{
 	clock_t sTime;
	double dSec=GetTickCount();
//	dSec=((double)clock()/CLOCKS_PER_SEC);
 
	return dSec;
}



int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TCSTENCIL11));

	// Main message loop:
	for (;;) {
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			Render();
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TCSTENCIL11));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_TCSTENCIL11, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }
/*
    hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
*/
	 hWnd = CreateWindowEx(WS_EX_TOPMOST,szWindowClass, szTitle, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_VISIBLE,
      0, 0, 800, 480, NULL, NULL, hInstance, NULL);

    if (!hWnd)
    {
        return FALSE;
    }

	AppInit();

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            g_hWndCommandBar = CommandBar_Create(g_hInst, hWnd, 1);
            CommandBar_InsertMenubar(g_hWndCommandBar, g_hInst, IDR_MENU, 0);
            CommandBar_AddAdornments(g_hWndCommandBar, 0, 0);
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
            PostQuitMessage(0);
            break;
		case WM_KEYDOWN:
			{
				RETAILMSG(1,(TEXT("KeyDOWN %d==\n"),wParam));
				switch(wParam)
				{
				case 38://89XX + Key
					{
						AppEnd();			
						PostQuitMessage(0);
					}
					break;
				
				}
			}
			break;
		
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
