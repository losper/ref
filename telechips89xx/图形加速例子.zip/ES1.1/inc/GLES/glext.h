/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2005-2008 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

#ifndef __gl_ext_h_
#define __gl_ext_h_

/* current khronos distributed glext.h, must be on include path */
#include <khronos/GLES/glext.h>

#include <GLES/gl.h>

#ifdef __cplusplus
extern "C" {
#endif

/** OES_query_matrix */
GL_API GLbitfield GL_APIENTRY glQueryMatrixxOES( GLfixed mantissa[16], GLint exponent[16] );

/** EXT_blend_minmax */ 
GL_API void GL_APIENTRY glBlendEquationOES( GLenum mode );
#define	GL_FUNC_ADD_OES								0x8006
#define	GL_MIN_EXT									0x8007
#define	GL_MAX_EXT									0x8008

/** EXT_blend_subtract */
#define	GL_FUNC_SUBTRACT_OES						0x800A
#define	GL_FUNC_REVERSE_SUBTRACT_OES				0x800B

/** EXT_texture_filter_anisotropic */
#define	GL_TEXTURE_MAX_ANISOTROPY_EXT				0x84FE
#define	GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT			0x84FF

/**  EXT_texture_mirror_clamp & ARB_texture_mirrored_repeat & ARB_texture_border_clamp (+ we support GL_CLAMP ) */
#define	GL_CLAMP									0x2900
#define	GL_CLAMP_TO_BORDER_ARB						0x812D
#define	GL_MIRRORED_REPEAT_ARB						0x8370
#define	GL_MIRROR_CLAMP_EXT							0x8742
#define	GL_MIRROR_CLAMP_TO_EDGE_EXT					0x8743
#define	GL_MIRROR_CLAMP_TO_BORDER_EXT				0x8912

/** EXT_texture_lod_bias */
#define	GL_TEXTURE_FILTER_CONTROL_EXT				0x8500
#define	GL_TEXTURE_LOD_BIAS_EXT						0x8501
#define	GL_MAX_TEXTURE_LOD_BIAS_EXT					0x84FD

/** EXT_stencil_wrap */
#define	GL_INCR_WRAP_EXT							0x8507
#define	GL_DECR_WRAP_EXT							0x8508

/** texture combinatorics */
#define GL_SOURCE0_RGB                    0x8580
#define GL_SOURCE1_RGB                    0x8581
#define GL_SOURCE2_RGB                    0x8582
#define GL_SOURCE0_ALPHA                  0x8588
#define GL_SOURCE1_ALPHA                  0x8589
#define GL_SOURCE2_ALPHA                  0x858A

/** ETC */
#define GL_OES_compressed_ETC1_RGB8_texture 1
#define GL_ETC1_RGB8_OES           0x8D64

/** This is missing from the gl.h available on the Khronos website */
#ifndef GL_CURRENT_PALETTE_MATRIX_OES
#define GL_CURRENT_PALETTE_MATRIX_OES 0x8843
#endif

#ifdef __cplusplus
}
#endif

#endif /* __gl_ext_h_ */
