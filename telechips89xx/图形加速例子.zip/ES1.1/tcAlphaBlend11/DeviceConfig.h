#ifndef DEVICECONFIG_H
#define DEVICECONFIG_H


#include <EGL/egl.h>
#include <GLES/gl.h>




#define  LCD_WIDTH		800.0f
#define  LCD_HEIGHT		480.0f



#define RGB16(red, green, blue) ( ((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3))
#define PI 3.1415926535897932f

//#define glF(x)	((GLfixed)((x)*(1<<16)))
#define glF(x)	((x))

//#define GL_F	GL_FIXED
//typedef GLfixed GLf;


typedef struct TGAImage											// Create A Structure
{
	GLubyte	*imageData;											// Image Data (Up To 32 Bits)
	GLuint	bpp;												// Image Color Depth In Bits Per Pixel.
	GLuint	width;												// Image Width
	GLuint	height;												// Image Height
	GLuint	texID;												// Texture ID Used To Select A Texture

} TGAImage;														// Structure Name




bool CreateEGL(void);
void DeleteEGL();
void EGLFlush();

extern bool LoadTGA(TGAImage *texture, char *filename);


#endif
