// tcMipmap11.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "tcMipmap11.h"
#include <windows.h>
#include <commctrl.h>
#include "DeviceConfig.h"

#define MAX_LOADSTRING 100


// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle

#define glF(x)	((GLfixed)((x)*(1<<16)))
#define glD(x)	glF(x)
#define GL_F	GL_FIXED
typedef GLfixed GLf;
	
float	fps = 0.0f;			// Holds The Current FPS (Frames Per Second) 

static GLuint texName;
//MipMap Texture 6
GLubyte mipmapImage32[32][32][4];
GLubyte mipmapImage16[16][16][4];
GLubyte mipmapImage8[8][8][4];
GLubyte mipmapImage4[4][4][4];
GLubyte mipmapImage2[2][2][4];
GLubyte mipmapImage1[1][1][4];
static const GLfixed coord [] = {
    glF(-2.0f), glF(-1.0f), glF(1.0f),
    glF(-2.0f), glF(1.0f), glF(1.0f),
    glF(2000.0f), glF(-1.0f), glF(-6000.0f),
    glF(2000.0f), glF(1.0f), glF(-6000.0f)
    };
    
static const GLubyte color [] = {
    255, 255, 255, 255,
    255,   0, 255, 255,
    0,     0, 255, 255,
    255, 255,   0, 255
   };

static const GLushort fanIx [] = {
    0, 1, 2,3};
   
static const GLfixed g_TexCoord[] = {
       glF(0.0), glF(0.0),
       glF(0.0), glF(8.0),
       glF(8.0), glF(0.0),
       glF(8.0), glF(8.0),
 };

///////////////////////////////////////////////////////////////////////////////
void InitTexture();
void GL_Draw();
void Render();
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val);
void InitGLES();
void OrthoBegin(void);
void OrthoEnd(void);
float framerate(int Poly);
bool AppInit();
void AppEnd();
double GetTime();
void GetStatus(void);

void InitGLES()
{
	
	glClearColorx(glF(0.0f), glF(0.7f), glF(0.9f), glF(1.0f));   
    glClearDepthx(glF(1.0f));    
 //  glEnable(GL_CULL_FACE);    
    glEnable(GL_DEPTH_TEST);    
    glEnable(GL_LINE_SMOOTH);
    glShadeModel(GL_FLAT);

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	
	glEnable(GL_TEXTURE_2D);
    glEnable(GL_MULTISAMPLE);

    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);	// Really Nice Perspective Calculations	
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations    

    glViewport(0, 0, LCD_WIDTH,LCD_HEIGHT);    

    
// Set Projection 
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glPerspectivef( 3.141592654f/4.0f, 1.0f, 1.0f, 10000.0f );	
										
    glMatrixMode(GL_MODELVIEW);    
    glLoadIdentity();	



}
void GL_Draw()
{

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
    {
		printf("draw() failed (error 0x%x)\n", err);
		exit(1);
    }
    	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
    glEnable(GL_TEXTURE_2D);

    glEnableClientState(GL_VERTEX_ARRAY);
   // glEnableClientState(GL_COLOR_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);	
	
    glVertexPointer(3, GL_FIXED, 0, coord);
    glTexCoordPointer(2, GL_FIXED, 0, g_TexCoord);
 	
    glPushMatrix();    
    //Z -3.0f ?
    glTranslatex(glF(0.0), glF(0.0), glF(-3.0f));
   
    glBindTexture(GL_TEXTURE_2D, texName);
    glDrawArrays(GL_TRIANGLE_STRIP,0,4);

    glPopMatrix();

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
 	
}
void Render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	GL_Draw();

    EGLFlush();
  
 }
void InitTexture()
{
    int i, j;
    
    //Yellow
    for (i = 0; i < 32; i++)
    {
	  for (j = 0; j < 32; j++)
        {
			mipmapImage32[i][j][0] = 255;
			mipmapImage32[i][j][1] = 255;
			mipmapImage32[i][j][2] = 0;
			mipmapImage32[i][j][3] = 255;
		}
	}

    //Violet
    for (i = 0; i < 16; i++)
    {
		for (j = 0; j < 16; j++)
         {
				mipmapImage16[i][j][0] = 255;
				mipmapImage16[i][j][1] = 0;
				mipmapImage16[i][j][2] = 255;
				mipmapImage16[i][j][3] = 255;
		 }
	}

    //red
    for (i = 0; i < 8; i++)
    {
		for (j = 0; j < 8; j++)
          {
				mipmapImage8[i][j][0] = 255;
				mipmapImage8[i][j][1] = 0;
				mipmapImage8[i][j][2] = 0;
				mipmapImage8[i][j][3] = 255;
			}
	}

    //green
    for (i = 0; i < 4; i++)
    {
		for (j = 0; j < 4; j++)
            {
				mipmapImage4[i][j][0] = 0;
				mipmapImage4[i][j][1] = 255;
				mipmapImage4[i][j][2] = 0;
				mipmapImage4[i][j][3] = 255;
			}
    }

    //blue
    for (i = 0; i < 2; i++) 
     {
		for (j = 0; j < 2; j++)
          {
			mipmapImage2[i][j][0] = 0;
			mipmapImage2[i][j][1] = 0;
			mipmapImage2[i][j][2] = 255;
			mipmapImage2[i][j][3] = 255;
		  }
	 }


        mipmapImage1[0][0][0] = 255;
		mipmapImage1[0][0][1] = 255;
		mipmapImage1[0][0][2] = 255;
		mipmapImage1[0][0][3] = 255;


 glGenTextures(1, &texName);
 glBindTexture(GL_TEXTURE_2D, texName);
	   
 glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
 glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
 glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
 glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
// glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	   
 glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 32, 32, 0,
		   GL_RGBA, GL_UNSIGNED_BYTE, mipmapImage32);

 glTexImage2D(GL_TEXTURE_2D, 1, GL_RGBA, 16, 16, 0,
		   GL_RGBA, GL_UNSIGNED_BYTE, mipmapImage16);
 glTexImage2D(GL_TEXTURE_2D, 2, GL_RGBA, 8, 8, 0,
		   GL_RGBA, GL_UNSIGNED_BYTE, mipmapImage8);
 glTexImage2D(GL_TEXTURE_2D, 3, GL_RGBA, 4, 4, 0,
		   GL_RGBA, GL_UNSIGNED_BYTE, mipmapImage4);


 glTexImage2D(GL_TEXTURE_2D, 4, GL_RGBA, 2, 2, 0,
		   GL_RGBA, GL_UNSIGNED_BYTE, mipmapImage2);

 glTexImage2D(GL_TEXTURE_2D, 5, GL_RGBA, 1, 1, 0,
                GL_RGBA, GL_UNSIGNED_BYTE, mipmapImage1);


}
///////////////////////////////////////////////////////////////////////////////
//******* Main Render Loop *******************/

bool AppInit()
{
     
    if(!CreateEGL())
		return false;

	InitGLES();

    InitTexture();
 
	return true;

}
///////////////////////////////////////////////////////////////////////////////
void AppEnd()
{	

    glDeleteTextures(1, &texName);
    DeleteEGL();
}

///////////////////////////////////////////////////////////////////////////////
void glPerspectivef(GLfloat fov, GLfloat aspect, GLfloat near_val, GLfloat far_val)
{
	GLfloat top = (GLfloat)(tan(fov*0.5) * near_val);
	GLfloat bottom = -top;
	GLfloat left = aspect * bottom;
	GLfloat right = aspect * top;
	glFrustumx(glF(left), glF(right), glF(bottom), glF(top), glF(near_val),glF(far_val));
    
}
//////////////////////////////////////////////////////////////////////////////////////


void OrthoBegin(void)
{
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);


	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrthox(0,LCD_WIDTH*65536,0,LCD_HEIGHT*65536,-1.0*65536,1.0*65536);	

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();


}

void OrthoEnd(void)
{
	glEnable(GL_DEPTH_TEST);
	
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix(); 
}

/*************Calculate frame rate********/
float framerate(int Poly)
{
    static float previous = 0;
    static int framecount = 0;
	static float finalfps = 0;
    framecount++;

    if ( framecount == 10 )
    {
        float time = (float)GetTime();
        float seconds = time - previous;
        float fps = framecount / seconds;
        previous = time;
		finalfps = fps;
        framecount = 0;
    }

	return finalfps;
}

double GetTime()
{
 	clock_t sTime;
	double dSec=0;
//	dSec=((double)clock()/CLOCKS_PER_SEC);
 
	return dSec;
}
void GetStatus(void)
{
    int status =0;

    glGetIntegerv(GL_MAX_TEXTURE_SIZE,&status);
    printf( "==GL_MAX_TEXTURE_SIZE=%d=\n",status);

    glGetIntegerv(GL_MAX_TEXTURE_UNITS,&status); 
    printf( "==GL_MAX_TEXTURE_UNITS=%d=\n",status); 
    // glGetIntegerv( GL_MAX_PALETTE_MATRICES_OES, &status);
   // printf( "==GL_MAX_PALETTE_MATRICES_OES=%d=\n",status);

}
// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);



int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TCMIPMAP11));

	// Main message loop:
	for (;;) {
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			Render();
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TCMIPMAP11));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_TCMIPMAP11, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }
/*
    hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
*/
	 hWnd = CreateWindowEx(WS_EX_TOPMOST,szWindowClass, szTitle, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_VISIBLE,
      0, 0, 800, 480, NULL, NULL, hInstance, NULL);

    if (!hWnd)
    {
        return FALSE;
    }
	 
	AppInit();

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            g_hWndCommandBar = CommandBar_Create(g_hInst, hWnd, 1);
            CommandBar_InsertMenubar(g_hWndCommandBar, g_hInst, IDR_MENU, 0);
            CommandBar_AddAdornments(g_hWndCommandBar, 0, 0);
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
            PostQuitMessage(0);
            break;
		case WM_KEYDOWN:
			{
				RETAILMSG(1,(TEXT("KeyDOWN %d==\n"),wParam));
				switch(wParam)
				{
				case 38:
					{
						AppEnd();			
						PostQuitMessage(0);
					}
					break;
				
				}
			}
			break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
