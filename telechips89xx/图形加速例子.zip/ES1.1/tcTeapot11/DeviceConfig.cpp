#include "stdafx.h"
#include "DeviceConfig.h"
#include <EGL/egl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

HWND				gHWND;

//16bit
static EGLint const attrib_list[] = {
	EGL_RED_SIZE, 5,  
	EGL_GREEN_SIZE, 6,
	EGL_BLUE_SIZE, 5,   
	EGL_ALPHA_SIZE, 0,  
	EGL_RENDERABLE_TYPE, 
	EGL_OPENGL_ES_BIT, 
	EGL_SURFACE_TYPE,
	EGL_WINDOW_BIT,  
	EGL_SAMPLE_BUFFERS, GL_FALSE,
	EGL_NONE 
	};
/*
static EGLint const attrib_list[] = {
	EGL_RED_SIZE, 8,  
	EGL_GREEN_SIZE,8,
	EGL_BLUE_SIZE, 8,   
	EGL_ALPHA_SIZE,8,  
	EGL_RENDERABLE_TYPE, 
	EGL_OPENGL_ES_BIT, 
	EGL_SURFACE_TYPE,
	EGL_WINDOW_BIT,  
	EGL_NONE 
	};
*/
EGLint ai32ContextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 1, EGL_NONE };
	
EGLConfig	m_EGLXConfig;
EGLContext	m_EGLXContext;
EGLSurface	m_EGLXSurface;
EGLDisplay	m_EGLXDisplay;
EGLint		m_EGLXNumOfConfigs;
EGLNativeWindowType  m_nativeWindow;
EGLint max_num_config;
NativeDisplayType g_dpy;

bool CreateEGL(void)
{
	
	EGLConfig *configs = NULL;
	int i;
	g_dpy = GetDC(gHWND);
	
	EGLint major, minor, num_config;
	/* see egl_config.c for a list of supported configs, this looks for 
	a 5650 (rgba) config, supporting OpenGL ES and windowed surfaces  */

	
	/* step1 - get a display */
	m_EGLXDisplay = eglGetDisplay( g_dpy );
	if ( EGL_NO_DISPLAY == m_EGLXDisplay )
	{
		printf( "eglGetDisplay() failed (error 0x%x)\n", eglGetError() );
		return 1;
	}

	if ( EGL_FALSE == eglInitialize( m_EGLXDisplay, &major, &minor ) )
	{
		printf( "eglInitialize() failed (error 0x%x)\n", eglGetError() );
		return 1;
	}
	if ( EGL_FALSE == eglGetConfigs(m_EGLXDisplay, NULL, 0, &max_num_config) )
	{
		printf( "eglGetConfigs() failed to retrive the number of configs (error 0x%x)\n", eglGetError() );
		return 1;
	}
	if(max_num_config <= 0)
	{
		printf( "No EGLconfigs found\n" );
		return 1;
	}
	configs = (EGLConfig *)malloc( sizeof( EGLConfig) * max_num_config );
	if ( NULL == configs )
	{
		printf( "Out of memory\n" );
		return 1;
	}
	eglBindAPI(EGL_OPENGL_ES_API);
	/* step2 - bind to the wanted client API */
	/* eglBindAPI( EGL_OPENGL_ES_API ); */
	/* step3 - find a suitable config */
	//eglChooseConfig( dpy, attrib_list, configs, max_num_config, &num_config )
	if ( EGL_FALSE == eglChooseConfig( m_EGLXDisplay, attrib_list, configs,max_num_config, &m_EGLXNumOfConfigs ) )
	{
		printf( "eglChooseConfig() failed (error 0x%x)\n", eglGetError() );
		return 1;
	}
	if ( 0 == m_EGLXNumOfConfigs )
	{
		printf( "eglChooseConfig() was unable to find a suitable config\n" );
		return 1;
	}
	/*Use this to explicitly check that the EGL config has the expected color depths */
	//16bit
	for ( i=0; i<m_EGLXNumOfConfigs; i++ )
	{
		EGLint value;
		
		
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_RED_SIZE, &value );
		if ( 5 != value ) continue;
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_GREEN_SIZE, &value );
		if ( 6 != value ) continue;
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_BLUE_SIZE, &value );
		if ( 5 != value ) continue;
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_ALPHA_SIZE, &value );
		if ( 0 != value ) continue;
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_SAMPLES, &value );
		if ( 4 != value ) continue;
	
		m_EGLXConfig = configs[i];
		break;
	}
	/*32bit..
	for ( i=0; i<m_EGLXNumOfConfigs; i++ )
	{
		EGLint value;
		
		
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_RED_SIZE, &value );
		if ( 8 != value ) continue;
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_GREEN_SIZE, &value );
		if ( 8 != value ) continue;
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_BLUE_SIZE, &value );
		if ( 8 != value ) continue;
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_ALPHA_SIZE, &value );
		if ( 8 != value ) continue;
		eglGetConfigAttrib( m_EGLXDisplay, configs[i], EGL_SAMPLES, &value );
		if ( 4 != value ) continue;
	
		m_EGLXConfig = configs[i];
		break;
	}
	*/	
	
	//Null Window
	m_EGLXSurface = eglCreateWindowSurface( m_EGLXDisplay, m_EGLXConfig, NULL, NULL );
	if ( EGL_NO_SURFACE == m_EGLXSurface )
	{
		printf( "eglCreateWindowSurface failed (error 0x%x)\n", eglGetError() );
		return 1;
	}
	/* step5 - create a context */
	m_EGLXContext = eglCreateContext( m_EGLXDisplay, m_EGLXConfig, EGL_NO_CONTEXT, ai32ContextAttribs );
	if ( EGL_NO_CONTEXT == m_EGLXContext )
	{
		printf( "eglCreateContext failed (error 0x%x)\n", eglGetError() );
		return 1;
	}
	/* step6 - make the context and surface current */
	if ( EGL_FALSE == eglMakeCurrent( m_EGLXDisplay, m_EGLXSurface, m_EGLXSurface, m_EGLXContext ) )
	{
		printf( "eglMakeCurrent failed (error 0x%x)\n", eglGetError() );
		return 1;
	}		/* begin user code */
	eglSwapInterval(m_EGLXDisplay,0);

	free( configs );
	return true;
}
	
void DeleteEGL()
{
	eglMakeCurrent(m_EGLXDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
	eglDestroyContext(m_EGLXDisplay, m_EGLXContext);
	eglDestroySurface(m_EGLXDisplay, m_EGLXSurface);	
	eglTerminate(m_EGLXDisplay);

	
}

void EGLFlush()
{
	eglSwapBuffers(m_EGLXDisplay,m_EGLXSurface);
	
}


bool LoadTGA(TGAImage *texture, char *filename)
{
	GLubyte		TGAheader[12]={0,0,2,0,0,0,0,0,0,0,0,0};		// Uncompressed TGA Header
	GLubyte		TGAcompare[12];									// Used To Compare TGA Header
	GLubyte		header[6];										// First 6 Useful Bytes From The Header
	GLuint		bytesPerPixel;									// Holds Number Of Bytes Per Pixel Used In The TGA File
	GLuint		imageSize;										// Used To Store The Image Size When Setting Aside Ram
	GLuint		temp;											// Temporary Variable
	GLuint		type=GL_RGBA;									// Set The Default GL Mode To RBGA (32 BPP)

	FILE *file = fopen(filename, "rb");							// Open The TGA File

	if(	file==NULL ||											// Does File Even Exist?
		fread(TGAcompare,1,sizeof(TGAcompare),file)!=sizeof(TGAcompare) ||	// Are There 12 Bytes To Read?
		memcmp(TGAheader,TGAcompare,sizeof(TGAheader))!=0				||	// Does The Header Match What We Want?
		fread(header,1,sizeof(header),file)!=sizeof(header))				// If So Read Next 6 Header Bytes
	{
		if (file == NULL)										// Did The File Even Exist? *Added Jim Strong*
			return false;										// Return False
		else													// Otherwise
		{
			fclose(file);										// If Anything Failed, Close The File
			return false;										// Return False
		}
	}

	texture->width  = header[1] * 256 + header[0];				// Determine The TGA Width	(highbyte*256+lowbyte)
	texture->height = header[3] * 256 + header[2];				// Determine The TGA Height	(highbyte*256+lowbyte)
    
 	if(	texture->width	<=0	||									// Is The Width Less Than Or Equal To Zero
		texture->height	<=0	||									// Is The Height Less Than Or Equal To Zero
		(header[4]!=24 && header[4]!=32))						// Is The TGA 24 or 32 Bit?
	{
		fclose(file);											// If Anything Failed, Close The File
		return false;											// Return False
	}

	texture->bpp	= header[4];								// Grab The TGA's Bits Per Pixel (24 or 32)
	bytesPerPixel	= texture->bpp/8;							// Divide By 8 To Get The Bytes Per Pixel
	imageSize		= texture->width*texture->height*bytesPerPixel;	// Calculate The Memory Required For The TGA Data

	texture->imageData=(GLubyte *)malloc(imageSize);			// Reserve Memory To Hold The TGA Data

	if(	texture->imageData==NULL ||								// Does The Storage Memory Exist?
		fread(texture->imageData, 1, imageSize, file)!=imageSize)	// Does The Image Size Match The Memory Reserved?
	{
		if(texture->imageData!=NULL)							// Was Image Data Loaded
			free(texture->imageData);							// If So, Release The Image Data

		fclose(file);											// Close The File
		return false;											// Return False
	}

	for(GLuint i=0; i<int(imageSize); i+=bytesPerPixel)			// Loop Through The Image Data
	{															// Swaps The 1st And 3rd Bytes ('R'ed and 'B'lue)
		temp=texture->imageData[i];								// Temporarily Store The Value At Image Data 'i'
		texture->imageData[i] = texture->imageData[i + 2];		// Set The 1st Byte To The Value Of The 3rd Byte
		texture->imageData[i + 2] = temp;						// Set The 3rd Byte To The Value In 'temp' (1st Byte Value)
	}

	fclose (file);												// Close The File

	glGenTextures(1, &texture->texID);							// Generate OpenGL texture IDs
	glBindTexture(GL_TEXTURE_2D, texture->texID);						// Bind Our Texture
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);	// Linear Filtered
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);	// Linear Filtered
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);


	if (texture[0].bpp==24)										// Was The TGA 24 Bits
	{
		type=GL_RGB;											// If So Set The 'type' To GL_RGB
	}

	glTexImage2D(GL_TEXTURE_2D, 0, type, texture->width, texture->height, 0, type, GL_UNSIGNED_BYTE, texture->imageData);

	return true;
}






