/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2007-2009 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

#ifndef _MALI_OPENVG_H_
#define _MALI_OPENVG_H_


/*
 * This is the Mali OpenVG wrapper, for use in driver development only
 *  all applications should be built with the stock openvg.h and egl.h
 */

/* current khronos distributed openvg.h, must be on include path */
#include <khronos/VG/openvg.h>

#endif /* _MALI_OPENVG_H_ */

