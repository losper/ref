#ifndef DEVICECONFIG_H
#define DEVICECONFIG_H


#include <EGL/egl.h>

#define  LCD_WIDTH		800.0f
#define  LCD_HEIGHT		480.0f

#define RGB16(red, green, blue) ( ((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3))
#define PI 3.1415926535897932f
#define glF(x)	((x))

bool CreateEGL(void);
void DeleteEGL();
void EGLFlush();



#endif
