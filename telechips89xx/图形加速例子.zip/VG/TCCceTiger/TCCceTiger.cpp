// TCCceTiger.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "TCCceTiger.h"
#include <windows.h>
#include <commctrl.h>


#include <EGL/egl.h>
#include <VG/openvg.h>
#include <VG/vgu.h>
#include "DeviceConfig.h"
#include "TigerData.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle

// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);


EGLDisplay			eglDisplay	= 0;
EGLSurface			eglSurface	= 0;
float	fps = 0.0f;			// Holds The Current FPS (Frames Per Second) 

float framerate(int Poly);
double GetTime();
int m_glutWindow; //Window Handle
bool InitOpenVG();
bool InitEGL();
void DrawVG();
void AppInit();
void AppEnd();
void RenderVG();
static const int ai32ConfigAttribs[] =
{
	EGL_RED_SIZE,       5,
	EGL_GREEN_SIZE,     6,
	EGL_BLUE_SIZE,      5,
	EGL_ALPHA_SIZE,     0,
	EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
	EGL_RENDERABLE_TYPE, EGL_OPENVG_BIT,
	EGL_NONE
};

extern const int    tigerCommandCount;
extern const char   tigerCommands[];
extern const float  tigerMinX;
extern const float  tigerMaxX;
extern const float  tigerMinY;
extern const float  tigerMaxY;
extern const int    tigerPointCount;
extern const float  tigerPoints[];

typedef struct
{ 
	VGFillRule		m_fillRule;
	VGPaintMode		m_paintMode;
	VGCapStyle		m_capStyle;
	VGJoinStyle		m_joinStyle;
	float			m_miterLimit;
	float			m_strokeWidth;
	VGPaint			m_fillPaint;
	VGPaint			m_strokePaint;
	VGPath			m_path;
} PathData;

typedef struct
{
	PathData*	    m_paths;
	int				m_numPaths;
} PS;

PS* tiger = NULL;

PS* PS_construct(const char* commands, int commandCount, const float* points, int pointCount)
{
	PS* ps = (PS*)malloc(sizeof(PS));
	int p = 0;
	int c = 0;
	int i = 0;
	int paths = 0;
	int maxElements = 0;
	unsigned char* cmd;

	while(c < commandCount)
	{
		int elements, e;
		c += 4;
		p += 8;
		elements = (int)points[p++];

		if(elements > maxElements)
			maxElements = elements;
		for(e=0;e<elements;e++)
		{
			switch(commands[c])
			{
			    case 'M': p += 2; break;
			    case 'L': p += 2; break;
			    case 'C': p += 6; break;
			    case 'E': break;
			    default: break;
			}
			c++;
		}
		paths++;
	}

	ps->m_numPaths = paths;
	ps->m_paths = (PathData*)malloc(paths * sizeof(PathData));
	cmd = (unsigned char*)malloc(maxElements);

	i = 0;
	p = 0;
	c = 0;
	while(c < commandCount)
	{
		int elements, startp, e;
		float color[4];

		//fill type
		int paintMode = 0;
		ps->m_paths[i].m_fillRule = VG_NON_ZERO;
		switch( commands[c] )
		{
		    case 'N':
			    break;
		    case 'F':
			    ps->m_paths[i].m_fillRule = VG_NON_ZERO;
			    paintMode |= VG_FILL_PATH;
			    break;
		    case 'E':
			    ps->m_paths[i].m_fillRule = VG_EVEN_ODD;
			    paintMode |= VG_FILL_PATH;
			    break;
		    default:
                break;
		}
		c++;

		//stroke
		switch( commands[c] )
		{
		    case 'N':
			    break;
		    case 'S':
			    paintMode |= VG_STROKE_PATH;
			    break;
		    default:
                break;
		}
		ps->m_paths[i].m_paintMode = (VGPaintMode)paintMode;
		c++;

		//line cap
		switch( commands[c] )
		{
		    case 'B':
			    ps->m_paths[i].m_capStyle = VG_CAP_BUTT;
			    break;
		    case 'R':
			    ps->m_paths[i].m_capStyle = VG_CAP_ROUND;
			    break;
		    case 'S':
			    ps->m_paths[i].m_capStyle = VG_CAP_SQUARE;
			    break;
		    default:
                break;
		}
		c++;

		//line join
		switch( commands[c] )
		{
		    case 'M':
			    ps->m_paths[i].m_joinStyle = VG_JOIN_MITER;
			    break;
		    case 'R':
			    ps->m_paths[i].m_joinStyle = VG_JOIN_ROUND;
			    break;
		    case 'B':
			    ps->m_paths[i].m_joinStyle = VG_JOIN_BEVEL;
			    break;
		    default:
                break;
		}
		c++;

		//the rest of stroke attributes
		ps->m_paths[i].m_miterLimit = points[p++];
		ps->m_paths[i].m_strokeWidth = points[p++];

		//paints
		color[0] = points[p++];
		color[1] = points[p++];
		color[2] = points[p++];
		color[3] = 1.0f;
		ps->m_paths[i].m_strokePaint = vgCreatePaint();
		vgSetParameteri(ps->m_paths[i].m_strokePaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
		vgSetParameterfv(ps->m_paths[i].m_strokePaint, VG_PAINT_COLOR, 4, color);

		color[0] = points[p++];
		color[1] = points[p++];
		color[2] = points[p++];
		color[3] = 1.0f;
		ps->m_paths[i].m_fillPaint = vgCreatePaint();
		vgSetParameteri(ps->m_paths[i].m_fillPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_COLOR);
		vgSetParameterfv(ps->m_paths[i].m_fillPaint, VG_PAINT_COLOR, 4, color);

		//read number of elements

		elements = (int)points[p++];
		startp = p;
		for(e=0;e<elements;e++)
		{
			switch( commands[c] )
			{
			    case 'M':
				    cmd[e] = VG_MOVE_TO | VG_ABSOLUTE;
				    p += 2;
				    break;
			    case 'L':
				    cmd[e] = VG_LINE_TO | VG_ABSOLUTE;
				    p += 2;
				    break;
			    case 'C':
				    cmd[e] = VG_CUBIC_TO | VG_ABSOLUTE;
				    p += 6;
				    break;
			    case 'E':
				    cmd[e] = VG_CLOSE_PATH;
				    break;
			    default:
                    break;
			}
			c++;
		}

		ps->m_paths[i].m_path = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F, 1.0f, 0.0f, 0, 0, (unsigned int)VG_PATH_CAPABILITY_ALL);
		vgAppendPathData(ps->m_paths[i].m_path, elements, cmd, points + startp);
		i++;
	}
	free(cmd);
	return ps;
}

void PS_destruct(PS* ps)
{
	int i;

	for(i=0;i<ps->m_numPaths;i++)
	{
		vgDestroyPaint(ps->m_paths[i].m_fillPaint);
		vgDestroyPaint(ps->m_paths[i].m_strokePaint);
		vgDestroyPath(ps->m_paths[i].m_path);
	}
	free(ps->m_paths);
	free(ps);
}

void PS_render(PS* ps)
{
	int i;

	vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);

	for(i=0;i<ps->m_numPaths;i++)
	{
		vgSeti(VG_FILL_RULE, ps->m_paths[i].m_fillRule);
		vgSetPaint(ps->m_paths[i].m_fillPaint, VG_FILL_PATH);

		if(ps->m_paths[i].m_paintMode & VG_STROKE_PATH)
		{
			vgSetf(VG_STROKE_LINE_WIDTH, ps->m_paths[i].m_strokeWidth);
			vgSeti(VG_STROKE_CAP_STYLE, ps->m_paths[i].m_capStyle);
			vgSeti(VG_STROKE_JOIN_STYLE, ps->m_paths[i].m_joinStyle);
			vgSetf(VG_STROKE_MITER_LIMIT, ps->m_paths[i].m_miterLimit);
			vgSetPaint(ps->m_paths[i].m_strokePaint, VG_STROKE_PATH);
		}
		{
			VGfloat min_x, min_y, bwidth, bheight;
			vgPathTransformedBounds( ps->m_paths[i].m_path, &min_x, &min_y, &bwidth, &bheight );
			if ( min_x + bwidth < 0 ||
				   min_y + bheight < 0 ||
				   min_x > 800 ||
				   min_y > 480 ) 
			{
				 //  printf("path %i outside screen\n", i);	
			} else {
						vgDrawPath(ps->m_paths[i].m_path, ps->m_paths[i].m_paintMode);
			}
	}
}
}
VGfloat rotate = 0.0f;
VGfloat m_fscale =0.5f; 
VGint m_nswitch =1;
void Tiger_Draw( void )
{  
    
    static VGfloat ty = 0.0f;
    static VGfloat dir = 1.0f;
    
	char		text[256];	
    
    vgClear(0, 0, LCD_WIDTH, LCD_HEIGHT );

    
	fps =  framerate(100);
	

	if ( ty > LCD_HEIGHT || ty < 0.0f )
        dir = -dir;

    ty += dir;

    vgLoadIdentity();
    
	vgTranslate( 320.0f, -200.0f );
    vgScale(0.7f , 0.7f);
    vgRotate(rotate);
    vgTranslate( -320.0f, 200.0f );
		PS_render( tiger );
    
    rotate += 2.0f;
    
#ifdef WIN32
//    InvalidateRect(hWnd, NULL, FALSE);
#endif
}

void Tiger_Init( void )
{
    VGfloat TigerclearColor[4] = { 0.8f, 0.8f, 0.8f, 1.0f };
    
    vgSetfv( VG_CLEAR_COLOR, 4, TigerclearColor );

    tiger = PS_construct(tigerCommands, tigerCommandCount, tigerPoints, tigerPointCount);
#ifdef WIN32
//    SetTimer( NULL, ALEXVG_TIMER, VGUI_TIMER_VALUE, (TIMERPROC)Tiger_Draw );
#endif
}

void Tiger_Release( void )
{
    PS_destruct( tiger );
#ifdef WIN32
//    KillTimer( NULL, ALEXVG_TIMER );
#endif
}





void DrawVG()
{

	
    Tiger_Draw();

}

void RenderVG()
{
    vgClear(0, 0, LCD_WIDTH, LCD_HEIGHT);
    DrawVG();
    EGLFlush();
}
bool InitEGL()
{
printf("===CreateEGL()===\n");
	CreateEGL();
	
printf("===CreateEGL()END===\n");	
    return true;

}
bool InitOpenVG()
{
	
	//Set the render quality so the stroke borders have some form of anti-aliasing
	
	vgSeti(VG_RENDERING_QUALITY, VG_RENDERING_QUALITY_BETTER);
	
	vgSetf(VG_STROKE_LINE_WIDTH, 1.0f);

	
	Tiger_Init();

	return true;
}

void AppInit()
{
    InitEGL();
	InitOpenVG();
}
void AppEnd()
{

    Tiger_Release();
	DeleteEGL();
}
float framerate(int Poly)
{
    static float previous = 0;
    static int framecount = 0;
	static float finalfps = 0;
    framecount++;

    if ( framecount == 5 )
    {
        float time = (float)GetTime();
        float seconds = time - previous;
        float fps = framecount / seconds;
        previous = time;
		finalfps = fps;
        framecount = 0;
    }

	return finalfps;
}

double GetTime()
{
 	clock_t sTime;
	double dSec=0;
	dSec= 0.001 * GetTickCount();
	return dSec;
}


int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TCCCETIGER));

	for (;;) {
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			RenderVG();
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TCCCETIGER));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_TCCCETIGER, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }

    hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

    if (!hWnd)
    {
        return FALSE;
    }
	 AppInit();

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            g_hWndCommandBar = CommandBar_Create(g_hInst, hWnd, 1);
            CommandBar_InsertMenubar(g_hWndCommandBar, g_hInst, IDR_MENU, 0);
            CommandBar_AddAdornments(g_hWndCommandBar, 0, 0);
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
            PostQuitMessage(0);
            break;
		case WM_KEYDOWN:
			{
				RETAILMSG(1,(TEXT("KeyDOWN %d==\n"),wParam));
				switch(wParam)
				{
				case 38:
					{
						AppEnd();			
						PostQuitMessage(0);
					}
					break;
				
				}
			}
			break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
