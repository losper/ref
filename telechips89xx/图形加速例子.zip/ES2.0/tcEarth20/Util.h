#ifndef SEO_UTIL_H
#define SEO_UTIL_H





#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <GLES2/gl2.h>

void * convert_element_to_array(void * index, int index_type, int index_size,
								void * data, int data_type, int data_num,bool bVertex);


GLuint esLoadShader( GLenum type, const char *shaderSrc );
GLuint esLoadProgram ( const char *vertShaderSrc, const char *fragShaderSrc );

char *textFileRead(char *fn);



#endif // ESUTIL_H