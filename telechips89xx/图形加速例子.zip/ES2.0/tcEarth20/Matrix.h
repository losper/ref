#ifndef SEO_MATRIX_H
#define SEO_MATRIX_H

#include <GLES2/gl2.h>

#define DEGREETORAD (float)(3.1415926535897932f/180.0f)
#define RADTODEGREE (float)(180.0f/3.1415926535897932f)
void IdentityMatf(GLfloat r[4][4]);

void MakeFrustumMatf(   GLfloat r[4][4],
                        GLfloat left,
                        GLfloat right,
                        GLfloat bottom,
                        GLfloat top,
                        GLfloat znear,
                        GLfloat zfar);

void CopyMatf(GLfloat r[4][4], const GLfloat m[4][4]);

void MultTranslateMatf(GLfloat r[4][4], const GLfloat m[4][4], GLfloat x, GLfloat y, GLfloat z);

void MultScaleMatf(GLfloat r[4][4], const GLfloat m[4][4], GLfloat x, GLfloat y, GLfloat z);

void MultRotXRadMatf(float result[4][4],const float m[4][4], float radians);
void MultRotYRadMatf(float result[4][4],const float m[4][4], float radians);
void MultRotZRadMatf(float result[4][4],const float m[4][4], float radians);
void RotXRadMatf(float r[4][4], float radians);
void RotYRadMatf(float r[4][4], float radians);
void RotZRadMatf(float r[4][4], float radians);

void Extract3x3Matf(GLfloat r[3][3], const GLfloat m[4][4]);

void MultMatf(GLfloat r[4][4], const GLfloat a[4][4], const GLfloat b[4][4]);
#endif
