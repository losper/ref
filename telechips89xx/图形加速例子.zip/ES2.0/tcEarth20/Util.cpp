

#include "Util.h"
//#include <io.h>
//#include <fcntl.h>
#include <stdio.h> 


#include <GLES2/gl2.h>
#include <windows.h>

void * convert_element_to_array(void * index, int index_type, int index_size,
								void * data, int data_type, int data_num,bool bVertex)
{
	  
	int i, j;
	int nIndex=0;
	GLfloat * pconvert_data=NULL; 
	GLfloat * porigin_data=NULL; 
	unsigned short * porigin_index = (unsigned short *)index;

	switch(data_type)
	{
	case 3:
		{
			nIndex=0;
			pconvert_data = (GLfloat *)malloc(index_size*data_num*sizeof(GLfloat));
			porigin_data = (GLfloat *)data;

			if(bVertex)
			{
				for(i=0; i<index_size; i++)
				{
					for(j=0; j<data_num; j++)
					{
						nIndex=porigin_index[i]*data_num + j;
						if((nIndex%3)==1)
							pconvert_data[i*data_num+j] = (float)((float)(porigin_data[porigin_index[i]*data_num + j]-3.5f)*(0.26f));
						else
							pconvert_data[i*data_num+j] = (float)((float)(porigin_data[porigin_index[i]*data_num + j])*(0.26f));

					}
				}

			}
			else
			{
				for(i=0; i<index_size; i++)
				{
					for(j=0; j<data_num; j++)
					{

						pconvert_data[i*data_num+j] = (porigin_data[porigin_index[i]*data_num + j]);

					}
				}

			}



			return (void *) pconvert_data;
		}
		break;
	}

	return (void *) 0;
}


GLuint esLoadShader( GLenum type, const char *shaderSrc )
{
   GLuint shader;
   GLint compiled;
   GLenum err;
   // Create the shader object
    err = glGetError();
	if (err != GL_NO_ERROR)
    {
		RETAILMSG(1,(TEXT("==GL_ERROR=0x%x=\n")),err);
	}	
	shader = glCreateShader (type);
   err = glGetError();
	if (err != GL_NO_ERROR)
    {
		RETAILMSG(1,(TEXT("==GL_ERROR=0x%x=\n")),err);
	}	


   if ( shader == 0 )
   	return 0;

   // Load the shader source
   glShaderSource(shader, 1, &shaderSrc, NULL );
   
   // Compile the shader
   glCompileShader ( shader );

   // Check the compile status
   glGetShaderiv ( shader, GL_COMPILE_STATUS, &compiled );

   if ( !compiled ) 
   {
      GLint infoLen = 0;

      glGetShaderiv ( shader, GL_INFO_LOG_LENGTH, &infoLen );
      
      if ( infoLen > 1 )
      {
         char* infoLog = (char*)malloc (sizeof(char) * infoLen );

         glGetShaderInfoLog ( shader, infoLen, NULL, infoLog );
            
         free ( infoLog );
      }

      glDeleteShader ( shader );
      return 0;
   }

   return shader;

}


//
///
/// \brief Load a vertex and fragment shader, create a program object, link program.
//         Errors output to log.
/// \param vertShaderSrc Vertex shader source code
/// \param fragShaderSrc Fragment shader source code
/// \return A new program object linked with the vertex/fragment shader pair, 0 on failure
//
GLuint esLoadProgram ( const char *vertShaderSrc, const char *fragShaderSrc )
{
   GLuint vertexShader;
   GLuint fragmentShader;
   GLuint programObject;
   GLint linked;

   // Load the vertex/fragment shaders
   vertexShader = esLoadShader (GL_VERTEX_SHADER, vertShaderSrc);
   if ( vertexShader == 0 )
      return 0;

   fragmentShader = esLoadShader (GL_FRAGMENT_SHADER, fragShaderSrc);
   if ( fragmentShader == 0 )
   {
      glDeleteShader( vertexShader );
      return 0;
   }

   // Create the program object
   programObject = glCreateProgram ( );
   
   if ( programObject == 0 )
      return 0;

   glAttachShader ( programObject, vertexShader );
   glAttachShader ( programObject, fragmentShader );

   // Link the program
   glLinkProgram ( programObject );

   // Check the link status
   glGetProgramiv ( programObject, GL_LINK_STATUS, &linked );

   

   if ( !linked ) 
   {
      GLint infoLen = 0;

      glGetProgramiv ( programObject, GL_INFO_LOG_LENGTH, &infoLen );
      
      if ( infoLen > 1 )
      {
         char* infoLog = (char*)malloc (sizeof(char) * infoLen );

         glGetProgramInfoLog ( programObject, infoLen, NULL, infoLog );
      //   esLogMessage ( "Error linking program:\n%s\n", infoLog );            
         
         free ( infoLog );
      }

      glDeleteProgram ( programObject );
      return 0;
   }

   // Free up no longer needed shader resources
   glDeleteShader ( vertexShader );
   glDeleteShader ( fragmentShader );

   return programObject;
}

char *textFileRead(char *fn) {


	FILE *fp;
	char *content = NULL;

	int count=0;

	if (fn != NULL) {
		fp = fopen(fn,"rt");

		if (fp != NULL) {
      
      fseek(fp, 0, SEEK_END);
      count = ftell(fp);
     // rewind(fp); wince�� ����?
	  fseek( fp, 0L, SEEK_SET );

			if (count > 0) {
				content = (char *)malloc(sizeof(char) * (count+1));
				count = fread(content,sizeof(char),count,fp);
				content[count] = '\0';
			}
			fclose(fp);
		}
	}
	return content;
}


/*
void InitMessageToConsole()
{
	int hCrt;
   FILE *hf;

   AllocConsole();
   hCrt = _open_osfhandle(
             (long) GetStdHandle(STD_OUTPUT_HANDLE),_O_TEXT);
   hf = _fdopen( hCrt, "w" );
   *stdout = *hf;
   int i = setvbuf( stdout, NULL, _IONBF, 0 );

}

void QuitMessageToConsole()
{
_fcloseall();
 FreeConsole();
}
*/