// tcTeapot20.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "tcTeapot20.h"
#include <windows.h>
#include <commctrl.h>

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <math.h>
#include "DeviceConfig.h"
#include "Util.h"
#include "Matrix.h"
#include "Teapot_v.h"
#include "Teapot_n.h"


#define glF(x)	((x))


enum BUFFERTYPE{
	VERTEX_BUFFER,
	INDEX_BUFFER,
	TEXTURECOORD_BUFFER,
};

////////////////holic
bool AppInit(void);
void AppEnd();
void InitGLES();
void GL_Draw();
void Render();
//float framerate(int Poly);
//float	fps = 0.0f;			// Holds The Current FPS (Frames Per Second) 


float proj_mat[4][4];
//float Ortho_mat[4][4];
float mvp[32][4][4];
GLfloat World_mat[3][3];

int   niMVPIndex=0;
GLuint ShaderprogramObject;
GLfloat yrot = 1.0f;
GLint mvpLoc;
GLint posLocationindex; 
GLint texLocationindex; 

//TeaPot Buffer Name
GLuint Teapot_g_name[2];

static const GLfloat AMBIENT_LIGHT_VAL[] = {0.1f, 0.1f, 0.1f};
static const GLfloat DIFFUSE_LIGHT_VAL[] = {0.5f, 0.5f, 0.5f};
static const GLfloat SPECULAR_LIGHT_VAL[] = {0.5f, 0.5f, 0.5f};
static const GLfloat COLOR_VAL[] = {1.0f, 0.0f, 0.0f, 1.0f};
static const GLfloat LIGHT_POSITION_VAL[] = {0.0f, 5.0f,10.0f};
static const GLfloat CAMERA_POSITION_VAL[] = {1.0f, 0.0f,1.0f};


GLint NormalposLocationindex; 

GLint Sh_Ambient_Light;
GLint Sh_Diffuse_Light;
GLint Sh_Specular_Light;
GLint Sh_Color;
GLint Sh_Light_pos;
GLint Sh_Camera_pos;
GLint Sh_World_Mat;

bool AppInit()
{
	CreateEGL();
	InitGLES();
	return true;

}

void InitGLES()
{

	
	GLfloat top ;
	GLfloat bottom; 
	GLfloat left ; 
	GLfloat right ;

	glEnable(GL_DEPTH_TEST);
	glClearDepthf(1.0f); 
	glClearColor(0.0f,0.0f,0.0f,1.0f);
	glViewport(0, 0, LCD_WIDTH, LCD_HEIGHT);

		
	IdentityMatf(proj_mat); 
	
	top = (GLfloat)(tan(3.141592654f/4.0f*0.5f) * 1);
	bottom = -top;
	left = 1 * bottom;
	right = 1 * top;
	
	MakeFrustumMatf(proj_mat, left, right, bottom, top, 1, 1000);
		
	char* vertexsource = textFileRead("NAND/data/per_fragment_lighting.vert");
	char* fragmentsource = textFileRead("NAND/data/per_fragment_lighting.frag");
	

	ShaderprogramObject =  esLoadProgram(vertexsource,fragmentsource);//Shader Create,Source,Compile,CreateProgram,Attach,Link  DeleteShader,LinkProgram 
	glUseProgram(ShaderprogramObject);

	if(vertexsource!=NULL)
		free(vertexsource);vertexsource=NULL;

	if(fragmentsource!=NULL)
		free(fragmentsource);fragmentsource=NULL;


	posLocationindex = glGetAttribLocation ( ShaderprogramObject, "POSITION" );
	NormalposLocationindex= glGetAttribLocation ( ShaderprogramObject, "NORMAL" );
	
	texLocationindex = glGetAttribLocation ( ShaderprogramObject, "TEXCOORD0" );
	
	mvpLoc = glGetUniformLocation(ShaderprogramObject,"WORLD_VIEW_PROJECTION");
	Sh_World_Mat = glGetUniformLocation(ShaderprogramObject,"WORLD");

	
	Sh_Light_pos= glGetUniformLocation(ShaderprogramObject,"LIGHT_POSITION");
	Sh_Camera_pos= glGetUniformLocation(ShaderprogramObject,"CAMERA_POSITION");

	
	/*uniform vec3 LIGHT_POSITION;
	uniform vec3 CAMERA_POSITION;*/
	glUniform3fv(Sh_Light_pos, 1,(const GLfloat *)LIGHT_POSITION_VAL);
	glUniform3fv(Sh_Camera_pos, 1,(const GLfloat *)CAMERA_POSITION_VAL);
	
	//Fragment Shader
	Sh_Ambient_Light = glGetUniformLocation(ShaderprogramObject,"AMBIENT_LIGHT");
	Sh_Diffuse_Light= glGetUniformLocation(ShaderprogramObject,"DIFFUSE_LIGHT");
	Sh_Specular_Light= glGetUniformLocation(ShaderprogramObject,"SPECULAR_LIGHT");
	Sh_Color = glGetUniformLocation(ShaderprogramObject,"COLOR");

	glUniform3fv(Sh_Ambient_Light, 1,(const GLfloat *)AMBIENT_LIGHT_VAL);
	glUniform3fv(Sh_Diffuse_Light, 1,(const GLfloat *)DIFFUSE_LIGHT_VAL);
	glUniform3fv(Sh_Specular_Light, 1,(const GLfloat *)SPECULAR_LIGHT_VAL);
	glUniform4fv(Sh_Color, 1,(const GLfloat *)COLOR_VAL);


	
	//VBO Bind
	glGenBuffers(2,&Teapot_g_name[0]);

	//Normal
	glBindBuffer(GL_ARRAY_BUFFER, Teapot_g_name[0]);
	glBufferData(GL_ARRAY_BUFFER, triangle_count * sizeof(GLfloat) * 3 * 3, teapot_n, GL_STATIC_DRAW);
	
	//Vertex
	glBindBuffer(GL_ARRAY_BUFFER, Teapot_g_name[1]);
	glBufferData(GL_ARRAY_BUFFER, triangle_count * sizeof(GLfloat) * 3 * 3, teapot_v, GL_STATIC_DRAW);
	

	
}
void AppEnd()
{	
	glDeleteProgram(ShaderprogramObject);

	//VBO Mode Disable
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0); 
	glBindBuffer(GL_ARRAY_BUFFER, 0); 
	DeleteEGL();


}
void Render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	GL_Draw();

	EGLFlush();
}

void GL_Draw()
{

	
	
	niMVPIndex=0;
	IdentityMatf(mvp[niMVPIndex]);
	CopyMatf(mvp[niMVPIndex], proj_mat);

	//VBO Bind
//	glEnable(GL_TEXTURE_2D);
//	glBindTexture(GL_TEXTURE_2D,sphereImage.texID);

	glBindBuffer(GL_ARRAY_BUFFER,Teapot_g_name[1]);//Vertex buffer
	glVertexAttribPointer(posLocationindex,3,GL_FLOAT,GL_FALSE,0,0);
	glEnableVertexAttribArray(posLocationindex);

	glBindBuffer(GL_ARRAY_BUFFER,Teapot_g_name[0]);//Normal buffer
	glVertexAttribPointer(NormalposLocationindex,3,GL_FLOAT,GL_TRUE,0,0);
	glEnableVertexAttribArray(NormalposLocationindex);


	IdentityMatf(mvp[1]);
	MultTranslateMatf(mvp[1], mvp[1], 0.0f,0.0f,-10.0f);
	MultRotYRadMatf(mvp[1], mvp[1], yrot*DEGREETORAD);
	MultRotXRadMatf(mvp[1], mvp[1], 270*DEGREETORAD);
	
	MultScaleMatf(mvp[1], mvp[1],0.5f,0.5f,0.5f);

	Extract3x3Matf(World_mat,mvp[1]);

	MultMatf(mvp[niMVPIndex],mvp[niMVPIndex],mvp[1]);
	
	glUniformMatrix4fv(mvpLoc, 1, 0, (const GLfloat *)mvp[niMVPIndex]);

	glUniformMatrix3fv(Sh_World_Mat, 1, 0, (const GLfloat *)World_mat);

	
	glDrawArrays(GL_TRIANGLES, 0, 3*triangle_count);
	glDrawArrays(GL_TRIANGLES, 350*3, 3*(triangle_count-2255));

	glBindBuffer(GL_ARRAY_BUFFER, 0); 

	 yrot++;
	 if(yrot >360)
		 yrot = 0;

	
}
/*
float framerate(int Poly)
{
	static float previous = 0;
	static int framecount = 0;
	static float finalfps = 0;
	framecount++;

	if ( framecount == 10 )
	{
		float time = (float)0.001 * GetTickCount();
		float seconds = time - previous;
		float fps = framecount / seconds;
		previous = time;
		finalfps = fps;
		framecount = 0;
	}

	return finalfps;
}

*/



// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TCTEAPOT20));

	// Main message loop:
	for (;;) {
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else {
			Render();
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TCTEAPOT20));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_TCTEAPOT20, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }
/*
    hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
*/
	hWnd = CreateWindowEx(WS_EX_TOPMOST,szWindowClass, szTitle, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_VISIBLE,
    0, 0, 800, 480, NULL, NULL, hInstance, NULL);


    if (!hWnd)
    {
        return FALSE;
    }
	AppInit();

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
        case WM_CREATE:
            g_hWndCommandBar = CommandBar_Create(g_hInst, hWnd, 1);
            CommandBar_InsertMenubar(g_hWndCommandBar, g_hInst, IDR_MENU, 0);
            CommandBar_AddAdornments(g_hWndCommandBar, 0, 0);
            break;
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            
            // TODO: Add any drawing code here...
            
            EndPaint(hWnd, &ps);
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
             AppEnd();
			PostQuitMessage(0);
            break;
		case WM_KEYDOWN:
			{
				RETAILMSG(1,(TEXT("KeyDOWN %d==\n"),wParam));
				switch(wParam)
				{
				case 38:
					{
						AppEnd();			
						PostQuitMessage(0);
					}
					break;
				
				}
			}
			break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
