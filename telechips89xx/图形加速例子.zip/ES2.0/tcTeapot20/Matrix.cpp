#include "Matrix.h"
#include <math.h>
/*
#if defined(__cplusplus)
extern "C" {
#endif
*/

//Identity 4*4 Matrix
void IdentityMatf(GLfloat r[4][4])
{
	r[0][0] = 1.0f;
    r[0][1] = 0.0f;
    r[0][2] = 0.0f;
    r[0][3] = 0.0f;

    r[1][0] = 0.0f;
    r[1][1] = 1.0f;
    r[1][2] = 0.0f;
    r[1][3] = 0.0f;

    r[2][0] = 0.0f;
    r[2][1] = 0.0f;
    r[2][2] = 1.0f;
    r[2][3] = 0.0f;

    r[3][0] = 0.0f;
    r[3][1] = 0.0f;
    r[3][2] = 0.0f;
    r[3][3] = 1.0f;

}

void MakeFrustumMatf(   GLfloat r[4][4],
					 GLfloat left,
					 GLfloat right,
					 GLfloat bottom,
					 GLfloat top,
					 GLfloat znear,
					 GLfloat zfar)
{


	GLfloat const m00 = znear * 2.0f / (right - left);
	GLfloat const m11 = znear * 2.0f / (top - bottom);
	GLfloat const m22 = -(zfar + znear) / (zfar - znear);

	GLfloat const m20 = (right + left) / (right - left);
	GLfloat const m21 = (top + bottom) / (top - bottom);

	GLfloat const m32 = -(2.0f * zfar * znear) / (zfar - znear);
	GLfloat const m23 = -1.0f;

	r[0][0] = m00;
	r[0][1] = 0.0f;
	r[0][2] = 0.0f;
	r[0][3] = 0.0f;

	r[1][0] = 0.0f;
	r[1][1] = m11;
	r[1][2] = 0.0f;
	r[1][3] = 0.0f;

	r[2][0] = m20;
	r[2][1] = m21;
	r[2][2] = m22;
	r[2][3] = m23;

	r[3][0] = 0.0f;
	r[3][1] = 0.0f;
	r[3][2] = m32;
	r[3][3] = 0.0f;
}

void CopyMatf(GLfloat r[4][4], const GLfloat m[4][4])
{
    r[0][0] = m[0][0];
    r[0][1] = m[0][1];
    r[0][2] = m[0][2];
    r[0][3] = m[0][3];

    r[1][0] = m[1][0];
    r[1][1] = m[1][1];
    r[1][2] = m[1][2];
    r[1][3] = m[1][3];

    r[2][0] = m[2][0];
    r[2][1] = m[2][1];
    r[2][2] = m[2][2];
    r[2][3] = m[2][3];

    r[3][0] = m[3][0];
    r[3][1] = m[3][1];
    r[3][2] = m[3][2];
    r[3][3] = m[3][3];
}

void MultTranslateMatf(GLfloat result[4][4],
                         const GLfloat m[4][4],
                         GLfloat x,
                         GLfloat y,
                         GLfloat z)
{
    GLfloat r[4][4]; /*temporary storage for result */

    r[0][0] = m[0][0];
    r[0][1] = m[0][1];
    r[0][2] = m[0][2];
    r[0][3] = m[0][3];

    r[1][0] = m[1][0];
    r[1][1] = m[1][1];
    r[1][2] = m[1][2];
    r[1][3] = m[1][3];

    r[2][0] = m[2][0];
    r[2][1] = m[2][1];
    r[2][2] = m[2][2];
    r[2][3] = m[2][3];

    r[3][0] = m[0][0] * x + m[1][0] * y + m[2][0] * z + m[3][0];
    r[3][1] = m[0][1] * x + m[1][1] * y + m[2][1] * z + m[3][1];
    r[3][2] = m[0][2] * x + m[1][2] * y + m[2][2] * z + m[3][2];
    r[3][3] = m[0][3] * x + m[1][3] * y + m[2][3] * z + m[3][3];

    CopyMatf(result, r);
}
void MultScaleMatf(GLfloat result[4][4],
                     const GLfloat m[4][4],
                     GLfloat x,
                     GLfloat y,
                     GLfloat z)
{

    GLfloat r[4][4];


    r[0][0] = m[0][0] * x;
    r[0][1] = m[0][1] * x;
    r[0][2] = m[0][2] * x;
    r[0][3] = m[0][3] * x;

    r[1][0] = m[1][0] * y;
    r[1][1] = m[1][1] * y;
    r[1][2] = m[1][2] * y;
    r[1][3] = m[1][3] * y;

    r[2][0] = m[2][0] * z;
    r[2][1] = m[2][1] * z;
    r[2][2] = m[2][2] * z;
    r[2][3] = m[2][3] * z;

    r[3][0] = m[3][0];
    r[3][1] = m[3][1];
    r[3][2] = m[3][2];
    r[3][3] = m[3][3];

    CopyMatf(result, r);
}


void RotXRadMatf(float r[4][4], float radians)
{
	float const s = (float)sin(radians);
	float const c = (float)cos(radians);

	r[0][0] = 1.0f;
	r[0][1] = 0.0f;
	r[0][2] = 0.0f;
	r[0][3] = 0.0f;

	r[1][0] = 0.0f;
	r[1][1] = c;
	r[1][2] = s;
	r[1][3] = 0.0f;

	r[2][0] = 0.0f;
	r[2][1] = -s;
	r[2][2] = c;
	r[2][3] = 0.0f;

	r[3][0] = 0.0f;
	r[3][1] = 0.0f;
	r[3][2] = 0.0f;
	r[3][3] = 1.0f;
}


void RotYRadMatf(float r[4][4], float radians) {

	float const s = (float)sin(radians);
	float const c = (float)cos(radians);

	r[0][0] = c;
	r[0][1] = 0.0f;
	r[0][2] = -s;
	r[0][3] = 0.0f;

	r[1][0] = 0.0f;
	r[1][1] = 1.0f;
	r[1][2] = 0.0f;
	r[1][3] = 0.0f;

	r[2][0] = s;
	r[2][1] = 0.0f;
	r[2][2] = c;
	r[2][3] = 0.0f;

	r[3][0] = 0.0f;
	r[3][1] = 0.0f;
	r[3][2] = 0.0f;
	r[3][3] = 1.0f;

}


void RotZRadMatf(float r[4][4], float radians)
{

	float const s = (float)sin(radians);
	float const c = (float)cos(radians);

	r[0][0] = c;
	r[0][1] = s;
	r[0][2] = 0.0f;
	r[0][3] = 0.0f;

	r[1][0] = -s;
	r[1][1] = c;
	r[1][2] = 0.0f;
	r[1][3] = 0.0f;

	r[2][0] = 0.0f;
	r[2][1] = 0.0f;
	r[2][2] = 1.0f;
	r[2][3] = 0.0f;

	r[3][0] = 0.0f;
	r[3][1] = 0.0f;
	r[3][2] = 0.0f;
	r[3][3] = 1.0f;
}


void MultRotXRadMatf(float result[4][4],
					   const float m[4][4],
					   float radians)
{

	float const s = (float)sin(radians);
	float const c = (float)cos(radians);

	float r[4][4];

	r[0][0] = m[0][0];
	r[0][1] = m[0][1];
	r[0][2] = m[0][2];
	r[0][3] = m[0][3];

	r[1][0] = m[1][0] *  c + m[2][0] * s;
	r[1][1] = m[1][1] *  c + m[2][1] * s;
	r[1][2] = m[1][2] *  c + m[2][2] * s;
	r[1][3] = m[1][3] *  c + m[2][3] * s;

	r[2][0] = m[1][0] * -s + m[2][0] * c;
	r[2][1] = m[1][1] * -s + m[2][1] * c;
	r[2][2] = m[1][2] * -s + m[2][2] * c;
	r[2][3] = m[1][3] * -s + m[2][3] * c;

	r[3][0] = m[3][0];
	r[3][1] = m[3][1];
	r[3][2] = m[3][2];
	r[3][3] = m[3][3];

	CopyMatf(result, r);
}



void MultRotYRadMatf(float result[4][4],
					   const float m[4][4],
					   float radians)
{

	float const s = (float)sin(radians);
	float const c = (float)cos(radians);

	float r[4][4];

	r[0][0] = m[0][0] * c + m[2][0] * -s;
	r[0][1] = m[0][1] * c + m[2][1] * -s;
	r[0][2] = m[0][2] * c + m[2][2] * -s;
	r[0][3] = m[0][3] * c + m[2][3] * -s;

	r[1][0] = m[1][0];
	r[1][1] = m[1][1];
	r[1][2] = m[1][2];
	r[1][3] = m[1][3];

	r[2][0] = m[0][0] * s + m[2][0] * c;
	r[2][1] = m[0][1] * s + m[2][1] * c;
	r[2][2] = m[0][2] * s + m[2][2] * c;
	r[2][3] = m[0][3] * s + m[2][3] * c;

	r[3][0] = m[3][0];
	r[3][1] = m[3][1];
	r[3][2] = m[3][2];
	r[3][3] = m[3][3];

	CopyMatf(result, r);
}

void MultRotZRadMatf(float result[4][4],
					   const float m[4][4],
					   float radians)
{

	float const s = (float)sin(radians);
	float const c = (float)cos(radians);

	float r[4][4];

	r[0][0] = m[0][0] * c + m[1][0] * s;
	r[0][1] = m[0][1] * c + m[1][1] * s;
	r[0][2] = m[0][2] * c + m[1][2] * s;
	r[0][3] = m[0][3] * c + m[1][3] * s;

	r[1][0] = m[0][0] * -s + m[1][0] * c;
	r[1][1] = m[0][1] * -s + m[1][1] * c;
	r[1][2] = m[0][2] * -s + m[1][2] * c;
	r[1][3] = m[0][3] * -s + m[1][3] * c;

	r[2][0] = m[2][0];
	r[2][1] = m[2][1];
	r[2][2] = m[2][2];
	r[2][3] = m[2][3];

	r[3][0] = m[3][0];
	r[3][1] = m[3][1];
	r[3][2] = m[3][2];
	r[3][3] = m[3][3];

	CopyMatf(result, r);
}

void Extract3x3Matf(GLfloat r[3][3], const GLfloat m[4][4])
{

	r[0][0] = m[0][0];
    r[0][1] = m[0][1];
    r[0][2] = m[0][2];

    r[1][0] = m[1][0];
    r[1][1] = m[1][1];
    r[1][2] = m[1][2];

    r[2][0] = m[2][0];
    r[2][1] = m[2][1];
    r[2][2] = m[2][2];

}

static void MultMat3x3f(GLfloat r[4][4], const GLfloat a[4][4], const GLfloat b[4][4])
{
  //  kdAssert(NvDifferentMatsf(r, a) && NvDifferentMatsf(r, b));

    r[0][0] = a[0][0]*b[0][0] + a[1][0]*b[0][1] + a[2][0]*b[0][2];
    r[0][1] = a[0][1]*b[0][0] + a[1][1]*b[0][1] + a[2][1]*b[0][2];
    r[0][2] = a[0][2]*b[0][0] + a[1][2]*b[0][1] + a[2][2]*b[0][2];
    r[0][3] = 0.0f;

    r[1][0] = a[0][0]*b[1][0] + a[1][0]*b[1][1] + a[2][0]*b[1][2];
    r[1][1] = a[0][1]*b[1][0] + a[1][1]*b[1][1] + a[2][1]*b[1][2];
    r[1][2] = a[0][2]*b[1][0] + a[1][2]*b[1][1] + a[2][2]*b[1][2];
    r[1][3] = 0.0f;

    r[2][0] = a[0][0]*b[2][0] + a[1][0]*b[2][1] + a[2][0]*b[2][2];
    r[2][1] = a[0][1]*b[2][0] + a[1][1]*b[2][1] + a[2][1]*b[2][2];
    r[2][2] = a[0][2]*b[2][0] + a[1][2]*b[2][1] + a[2][2]*b[2][2];
    r[2][3] = 0.0f;

    r[3][0] = 0.0f;
    r[3][1] = 0.0f;
    r[3][2] = 0.0f;
    r[3][3] = 1.0f;
}


static void MultMat4x3f(GLfloat r[4][4], const GLfloat a[4][4], const GLfloat b[4][4])
{
   // kdAssert(NvDifferentMatsf(r, a) && NvDifferentMatsf(r, b));

    r[0][0] = a[0][0]*b[0][0] + a[1][0]*b[0][1] + a[2][0]*b[0][2];
    r[0][1] = a[0][1]*b[0][0] + a[1][1]*b[0][1] + a[2][1]*b[0][2];
    r[0][2] = a[0][2]*b[0][0] + a[1][2]*b[0][1] + a[2][2]*b[0][2];
    r[0][3] = 0.0f;

    r[1][0] = a[0][0]*b[1][0] + a[1][0]*b[1][1] + a[2][0]*b[1][2];
    r[1][1] = a[0][1]*b[1][0] + a[1][1]*b[1][1] + a[2][1]*b[1][2];
    r[1][2] = a[0][2]*b[1][0] + a[1][2]*b[1][1] + a[2][2]*b[1][2];
    r[1][3] = 0.0f;

    r[2][0] = a[0][0]*b[2][0] + a[1][0]*b[2][1] + a[2][0]*b[2][2];
    r[2][1] = a[0][1]*b[2][0] + a[1][1]*b[2][1] + a[2][1]*b[2][2];
    r[2][2] = a[0][2]*b[2][0] + a[1][2]*b[2][1] + a[2][2]*b[2][2];
    r[2][3] = 0.0f;

    r[3][0] = a[0][0]*b[3][0] + a[1][0]*b[3][1] + a[2][0]*b[3][2] + a[3][0];
    r[3][1] = a[0][1]*b[3][0] + a[1][1]*b[3][1] + a[2][1]*b[3][2] + a[3][1];
    r[3][2] = a[0][2]*b[3][0] + a[1][2]*b[3][1] + a[2][2]*b[3][2] + a[3][2];
    r[3][3] = 1.0f;
}


static void MultMat4x4f(GLfloat r[4][4], const GLfloat a[4][4], const GLfloat b[4][4])
{
//    kdAssert(NvDifferentMatsf(r, a) && NvDifferentMatsf(r, b));

    r[0][0] = a[0][0]*b[0][0]+a[1][0]*b[0][1]+a[2][0]*b[0][2]+a[3][0]*b[0][3];
    r[0][1] = a[0][1]*b[0][0]+a[1][1]*b[0][1]+a[2][1]*b[0][2]+a[3][1]*b[0][3];
    r[0][2] = a[0][2]*b[0][0]+a[1][2]*b[0][1]+a[2][2]*b[0][2]+a[3][2]*b[0][3];
    r[0][3] = a[0][3]*b[0][0]+a[1][3]*b[0][1]+a[2][3]*b[0][2]+a[3][3]*b[0][3];

    r[1][0] = a[0][0]*b[1][0]+a[1][0]*b[1][1]+a[2][0]*b[1][2]+a[3][0]*b[1][3];
    r[1][1] = a[0][1]*b[1][0]+a[1][1]*b[1][1]+a[2][1]*b[1][2]+a[3][1]*b[1][3];
    r[1][2] = a[0][2]*b[1][0]+a[1][2]*b[1][1]+a[2][2]*b[1][2]+a[3][2]*b[1][3];
    r[1][3] = a[0][3]*b[1][0]+a[1][3]*b[1][1]+a[2][3]*b[1][2]+a[3][3]*b[1][3];

    r[2][0] = a[0][0]*b[2][0]+a[1][0]*b[2][1]+a[2][0]*b[2][2]+a[3][0]*b[2][3];
    r[2][1] = a[0][1]*b[2][0]+a[1][1]*b[2][1]+a[2][1]*b[2][2]+a[3][1]*b[2][3];
    r[2][2] = a[0][2]*b[2][0]+a[1][2]*b[2][1]+a[2][2]*b[2][2]+a[3][2]*b[2][3];
    r[2][3] = a[0][3]*b[2][0]+a[1][3]*b[2][1]+a[2][3]*b[2][2]+a[3][3]*b[2][3];

    r[3][0] = a[0][0]*b[3][0]+a[1][0]*b[3][1]+a[2][0]*b[3][2]+a[3][0]*b[3][3];
    r[3][1] = a[0][1]*b[3][0]+a[1][1]*b[3][1]+a[2][1]*b[3][2]+a[3][1]*b[3][3];
    r[3][2] = a[0][2]*b[3][0]+a[1][2]*b[3][1]+a[2][2]*b[3][2]+a[3][2]*b[3][3];
    r[3][3] = a[0][3]*b[3][0]+a[1][3]*b[3][1]+a[2][3]*b[3][2]+a[3][3]*b[3][3];
}
void MultMatf(GLfloat result[4][4], const GLfloat a[4][4], const GLfloat b[4][4])
{
    /*
      Use a temporary matrix for the result and copy the temporary
      into the result when finished. Doing this instead of writing
      the result directly guarantees that the routine will work even
      if the result overlaps one or more of the arguments in
      memory.
    */

    GLfloat r[4][4];

    if ((a[0][3]==0.0f) &&
        (a[1][3]==0.0f) &&
        (a[2][3]==0.0f) &&
        (a[2][3]==1.0f) &&
        (b[0][3]==0.0f) &&
        (b[1][3]==0.0f) &&
        (b[2][3]==0.0f) &&
        (b[2][3]==1.0f))
    {
        if ((a[3][0]==0.0f) &&
            (a[3][1]==0.0f) &&
            (a[3][2]==0.0f) &&
            (b[3][0]==0.0f) &&
            (b[3][1]==0.0f) &&
            (b[3][2]==0.0f))
        {
            MultMat3x3f(r, a, b);
        }
        else
        {
            MultMat4x3f(r, a, b);
        }
    }
    else
    {
         MultMat4x4f(r, a, b);
    }

    CopyMatf(result, r);
}



/*
#if defined(__cplusplus)
}
#endif
*/