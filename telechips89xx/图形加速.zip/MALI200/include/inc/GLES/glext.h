/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2005-2009 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

#ifndef __gl_ext_h_
#define __gl_ext_h_

/* current khronos distributed glext.h, must be on include path */
#include <GLES/gl.h>
#include <khronos/GLES/glext.h>

#ifdef __cplusplus
extern "C" {
#endif

/** EXT_blend_minmax */ 
#define GL_MIN_EXT                        0x8007
#define GL_MAX_EXT                        0x8008

/**  EXT_texture_mirror_clamp & ARB_texture_mirrored_repeat & ARB_texture_border_clamp (+ we support GL_CLAMP ) */
#define GL_CLAMP                          0x2900
#define GL_CLAMP_TO_BORDER_ARB            0x812D
#define GL_MIRRORED_REPEAT_ARB            0x8370
#define GL_MIRROR_CLAMP_EXT               0x8742
#define GL_MIRROR_CLAMP_TO_EDGE_EXT       0x8743
#define GL_MIRROR_CLAMP_TO_BORDER_EXT     0x8912

/** EXT_texture_lod_bias */
#define GL_TEXTURE_FILTER_CONTROL_EXT     0x8500
#define GL_TEXTURE_LOD_BIAS_EXT           0x8501
#define GL_MAX_TEXTURE_LOD_BIAS_EXT       0x84FD

/** EXT_stencil_wrap */
#define GL_INCR_WRAP_EXT                  0x8507
#define GL_DECR_WRAP_EXT                  0x8508

/** texture combinatorics */
#define GL_SOURCE0_RGB                    0x8580
#define GL_SOURCE1_RGB                    0x8581
#define GL_SOURCE2_RGB                    0x8582
#define GL_SOURCE0_ALPHA                  0x8588
#define GL_SOURCE1_ALPHA                  0x8589
#define GL_SOURCE2_ALPHA                  0x858A

/** for internal driver uses, we allow constant blending in GLES 1.x as well */
#define GL_CONSTANT_COLOR                 0x8001


#ifdef __cplusplus
}
#endif

#endif /* __gl_ext_h_ */
